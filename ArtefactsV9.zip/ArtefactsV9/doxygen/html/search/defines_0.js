var searchData=
[
  ['lcf_5finstruction_5famount',['LCF_INSTRUCTION_AMOUNT',['../lcf__instruction__executor_8h.html#a5369d4a62bc8e5229dc485f390ae582d',1,'lcf_instruction_executor.h']]],
  ['lcf_5fmemory_5fsize',['LCF_MEMORY_SIZE',['../lcf__memory__manager_8h.html#ac51f8d8c3948d6b0fd4dd34c986ea4a2',1,'lcf_memory_manager.h']]]
];
