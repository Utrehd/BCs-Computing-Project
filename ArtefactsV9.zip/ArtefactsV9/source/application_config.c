#include "application_config.h"
#include "swd_device_db_file.h"

#pragma location = "APPLICATION_CONFIG"
__root const application_config_t application_config = {
  .struct_version_tag = 2,
  .product_name = SWD_DEVICE_DB_DEVICE,
  .vendor_id.val = SWD_DEVICE_DB_VENDOR_ID,
  .device_id.val = SWD_DEVICE_DB_DEVICE_ID,
  .device_options.val = SWD_DEVICE_DB_DEVICE_OPTIONS,
  .sw_ver = 1,
  .hw_ver = 1,
  
  .jtag_dio = 0, //1 == SWD, 0 == JTAG
  
  .repeater_type = REPEATER_OFF,

  .asic2_clock.clock_SWD_Hz = 64000000,
  .asic2_clock.clock_SWSUBTIMER_1_Hz = 32000000,
  .asic2_clock.clock_WDOG_Hz = 32000000,
  .asic2_clock.clock_DEBUG_UART_Hz = 32000000,  

  .asic2_clock.clk_nres_cfg_ana_osc.bf.rcosc_hf_pd_n = CLK_NRES_RCOSC_HF_ENABLE,
  .asic2_clock.clk_nres_cfg_ana_osc.bf.qosc_pd_n = CLK_NRES_QOSC_DISABLE,
  .asic2_clock.clk_nres_cfg_ana_osc.bf.qosc_strength = 3,
  
  .asic2_clock.clk_nres_cfg_ana_pll0.bf.pll_fin_src = CLK_NRES_RCOSC_SOURCE_FOR_PLL,
  .asic2_clock.clk_nres_cfg_ana_pll0.bf.pll_oe = CLK_NRES_PLL_OUTPUT_ENABLED,
  .asic2_clock.clk_nres_cfg_ana_pll0.bf.pll_pd_n = CLK_NRES_PLL_ENABLE,

  /*
   * PLL(FOUT) = FIN  * (NF+1) / (NR+1) * 1/(2^OD) =
   *           = 16e6 * ( 3+1) / ( 0+1) * 1/(2^0) =
   *           = 16e6 * 4 = 64 MHz
   */
  .asic2_clock.clk_nres_cfg_ana_pll1.bf.pll_od = 0,
  .asic2_clock.clk_nres_cfg_ana_pll1.bf.pll_nr = 0,
  .asic2_clock.clk_nres_cfg_ana_pll1.bf.pll_nf = 3,

  .asic2_clock.clk_nres_cfg_AS0_swd_tsu.bf.clk_src = CLOCK_SOURCE_PLL,
  .asic2_clock.clk_nres_cfg_AS0_swd_tsu.bf.clk_div = 0,
  
  .asic2_clock.clk_nres_cfg_AS1_usi0.bf.clk_src = CLOCK_SOURCE_PLL,
  .asic2_clock.clk_nres_cfg_AS1_usi0.bf.clk_div = 2,
  
  .asic2_clock.clk_nres_cfg_AS2_usi1.bf.clk_src = CLOCK_SOURCE_PLL,
  .asic2_clock.clk_nres_cfg_AS2_usi1.bf.clk_div = 2,
  
  .asic2_clock.clk_nres_cfg_AS3_hipsi.bf.clk_src = CLOCK_SOURCE_PLL,
  .asic2_clock.clk_nres_cfg_AS3_hipsi.bf.clk_div = 2,
  
  /*  
   * CPU runs at 32MHz
   */
  .asic2_clock.clk_nres_cfg_M.bf.clk_src = CLOCK_SOURCE_PLL,
  .asic2_clock.clk_nres_cfg_M.bf.clk_div = 2,
  
  /* 
   * SYSTEM_CLOCK = PLL(FOUT) / M_clk_div = 64 000 000 / 2 
   */
  #define APPLICATION_CONFIG_SYSTEM_CLOCK 32000000  
    
  .asic2_clock.use_flash_half_clock_speed=true,
  
  .asic2_clock.clk_nres_cfg_rate.bf.cfg_low_rate_0 = 1,
  .asic2_clock.clk_nres_cfg_rate.bf.cfg_low_rate_1 = 1,
  .asic2_clock.clk_nres_cfg_rate.bf.cfg_high_rate = 1,
  
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_tsu = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_gpio = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_guard0 = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_guard1 = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_swtimer0 = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_swtimer1 = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_pwmn = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_vic_ext = high_rate,

  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_wdog0 = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_wdog1 = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_cpu_n_cpu = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_cctimer0 = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_cctimer1 = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_io_ctrl = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_analog_ctrl = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_access_ctrl = high_rate,

  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_hv_ctrl = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_uart = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_aout_ctrl = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_i2c = high_rate,
  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_el_ctrl = high_rate,
  
  //32MHz
  .asic2_clock.flash_timings.tnvs_tnvh = FLASH_CTRL_ACCESS_TIME_TNVS_TNVH(APPLICATION_CONFIG_SYSTEM_CLOCK),
  .asic2_clock.flash_timings.tnvh1     = FLASH_CTRL_ACCESS_TIME_TNVH1(APPLICATION_CONFIG_SYSTEM_CLOCK),
  .asic2_clock.flash_timings.tpgs      = FLASH_CTRL_ACCESS_TIME_TPGS(APPLICATION_CONFIG_SYSTEM_CLOCK),
  .asic2_clock.flash_timings.trcv      = FLASH_CTRL_ACCESS_TIME_TRCV(APPLICATION_CONFIG_SYSTEM_CLOCK),
  .asic2_clock.flash_timings.tprog     = FLASH_CTRL_ACCESS_TIME_TPROG(APPLICATION_CONFIG_SYSTEM_CLOCK),
  .asic2_clock.flash_timings.terase    = FLASH_CTRL_ACCESS_TIME_TERASE(APPLICATION_CONFIG_SYSTEM_CLOCK),
  .asic2_clock.flash_timings.tme       = FLASH_CTRL_ACCESS_TIME_TME(APPLICATION_CONFIG_SYSTEM_CLOCK),
  
  
  
  .bootloader_cfg.bootloader_flash0_crc16_start_addr = BASE_ADDR_FLASH0,
  .bootloader_cfg.bootloader_flash0_crc16_length = FLASH0_MAIN_SIZE,
  
  .bootloader_cfg.bootloader_flash1_crc16_start_addr = BASE_ADDR_FLASH1,
  .bootloader_cfg.bootloader_flash1_crc16_length = FLASH1_MAIN_SIZE,
  .bootloader_cfg.bootloader_mode = BOOTLOADER_MODE_COOKIE,
  
  // force bootloader pin disabled
  .bootloader_cfg.bootloader_force_pin_mask = (1<<4),
  .bootloader_cfg.bootloader_force_pin_group = 0xff, //function disabled = 0xff; for example 3-> p31
  .bootloader_cfg.bootloader_force_pin_value = 1, //on=1, off=0
  .bootloader_cfg.bootloader_dualcore  = true,
  
};