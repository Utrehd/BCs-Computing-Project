/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         main_app.c
*
* @brief        Example of SWD Slave Stack project
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      1.00
********************************************************************************
********************************************************************************
*/


// Serial Number: 00G0740000 

#include "hardware_api.h"
#include <slave/swd_mailbox_acpu.h>
#include <kernel/timer.h>
#include <slave/swd_slave.h>
#include "swd_device_db_file.h"
#include "bugs.h"
#include "swd_enh_prop.h" // swd_enh_prop_2mbps()

#include <errors_api.h> 

#include <lcf_state_machine.h>
#include <lcf_stack_machine_test.h>
#include <lcf_memory_manager_test.h>
#include <lcf_io_test.h>
 
/* Cyclic data received from SWD bus and used by SWD Slave */
/* 1st byte is data + status (DIAG,PRSNT,SUBST) */
/* n-byte data */
uint8_t cyclic_payload_output[1+SWD_DEVICE_DB_RX_CYCLIC_DATA_OUTPUT];

/* Flag indicate that cyclic data was received from SWD bus */
bool cyclic_payload_output_reveived = false;

/* Acyclic data counter - it counts acyclic data requests */
volatile uint8_t acyclic_data_cnt=0;

// -----------------------------------------------------------------------------
// #############################################################################
// ############################################################################# 
// ###########                __  __       _        ____              ##########
// ###########               |  \/  | __ _(_)_ __  / /\ \             ##########
// ###########               | |\/| |/ _` | | '_ \| |  | |            ##########
// ###########               | |  | | (_| | | | | | |  | |            ##########
// ###########               |_|  |_|\__,_|_|_| |_| |  | |            ##########
// ###########                                     \_\/_/             ##########
// #############################################################################
// ############################################################################# 
// -----------------------------------------------------------------------------
main (void) {

  __enable_irq ();
  mbox_init ();
    
  /* ****************** */
  /* Main infinite loop */
  /* ****************** */
  lcf_io_handler_init();
  while (1)
  {
    mbox_handle ();
    
    // **** RUN STATE MACHINE **************************************************
    lcf_state_machine_run();
    
    // **** AUTOMATIC TESTS OF LCF INTERPRETER *********************************
    /*
    lcf_io_test_run();
    lcf_stack_machine_test_error_e error1 = lcf_stack_machine_test_run_all();
    lcf_memory_manager_test_error_e error2 = lcf_memory_manager_test_run_all();
    
    while(error1 != eNO_ERROR)
    {
      // STUCK HERE IN CASE OF TEST ERROR
    }
    while(error2 != eMEMMA_NO_ERROR)
    {
      // STUCK HERE IN CASE OF TEST ERROR
    }
    */
    
    // *************************************************************************
    
    
    // Run SWD communication and call watchdog.
    uint8_t cyclic_payload_input[SWD_DEVICE_DB_TX_CYCLIC_DATA_INPUT];
    /* prepare cyclic data to be sent */
    swd_slave_cyc_data_tx_request(cyclic_payload_input);
  }
}


// -----------------------------------------------------------------------------
// #############################################################################
// ############################################################################# 
// ###########                 ______        ______                   ##########
// ###########                / ___\ \      / /  _ \                  ##########
// ###########                \___ \\ \ /\ / /| | | |                 ##########
// ###########                 ___) |\ V  V / | |_| |                 ##########
// ###########                |____/  \_/\_/  |____/                  ##########
// ###########                                                        ##########
// #############################################################################
// #############################################################################
// -----------------------------------------------------------------------------


// #############################################################################
/* 
 * This callback funtion is called when SWD request enable bootloader 
 * 
 * /see swd_slave.h
 */
uint8_t
swd_slave_request_enable_bootloader (uint16_t my_version, uint32_t my_serial, uint16_t version, uint32_t serial, uint8_t key[32])
{
  // uint8_t i;
  // printf("enable bootloader security check - my_version=0%04x my_serial=0x%08x\r\nrequest:\r\nversion=0%04x serial=0x%08x\r\nkey = ", my_version, my_serial, version, serial);
  // for (i=0; i<32; i++) printf("0x%02x ",key[i]);
  // are the AsicSerial_#s equal? (minimum check)
  if(my_version==version && my_serial==serial)
    return 1;   // allow a reactivation of bootloader
  else
    return 0;     // it's not me, denie!
}

// #############################################################################
/* 
 * returns the index of the configuration profile that has been selected 
 * as part of the project configuration
 * 
 * /see swd_slave.h
 */
void 
swd_slave_set_selected_profile_user (uint8_t bIndex) 
{
  printf ("ACPU:%s:selected profile %d\n", __FUNCTION__, bIndex);
}


// #############################################################################
/* 
 * reflects the error status of the data type diag_t on elements of the 
 * object of the message "Update Diag"
 *
 * /see swd_slave.h
 */
uint8_t 
swd_diagnose_map_user (diag_t diag) 
{
  switch (diag)
  {
  default:
  case eDiag_no_error:
    return 0;
  case eDiag_pb_pressed:
    return 0xf;
  }
}

// #############################################################################
/* 
 * rated the error states in terms of their relevance.
 * 
 * /see swd_slave.h
 */
uint8_t 
swd_diagnose_is_critical_user (uint16_t wState) 
{
  printf("ACPU:%s\n",__FUNCTION__);
  return 0; // none of the diagnose conditions are system critical
}

// #############################################################################
/*
 * Get default parameters for device
 *
 * \param bLength number of default parameters
 *
 * \param abData parameters
 * 
 * /see swd_slave.h
 */
uint8_t 
swd_slave_fetch_default_parameter (uint8_t * bLength, uint8_t * abData) 
{
  printf("ACPU:%s\n",__FUNCTION__);
  
  /* see MAX_USER_PARAMETER */
  *bLength = SWD_DEVICE_DB_NUM_OF_PAR_BYTES;
  
  /* set default parameter values */
  abData[0] = 0x00u; 

  return(0);
}

// #############################################################################
/*
 * Checks by the PLC delivered device parameters
 *
 * return 1 in case of error
 *        0 in case of success
 * 
 * /see swd_slave.h
 */
uint8_t 
swd_slave_check_new_parameter_user (uint8_t bLength, uint8_t * abData) 
{
  uint8_t i_idx;
  printf ("ACPU:%s:abData:%u: ", __FUNCTION__, bLength);
  for(i_idx=0;i_idx<bLength;i_idx++) {
    printf ("0x%02x ", abData[i_idx]);
  }
  printf ("\n");
  return 0;
}

// #############################################################################
/* 
 * Data received from SWD bus to slave
 * 
 * /see swd_slave.h
 */
void 
swd_slave_cyc_data_rx_isr (uint8_t *data) 
{
  memcpy (cyclic_payload_output, data, swd_mailbox_acpu_get_recv_length() );
  cyclic_payload_output_reveived = true;
}

// #############################################################################
/*
 * Callback for the acyclic process data, which sends the PLC to the device
 * 
 * /see swd_slave.h
 */
EC_ApplicErrors_e 
swd_slave_acyc_write_object_user (EC_Connection_t * con, uint8_t index, uint8_t * data, uint8_t length) 
{
  EC_ApplicErrors_e   eRet = eEC_APP_NO_ERROR;
  
  printf ("ACPU:%s:index:0x%02X:length:%u:", __FUNCTION__, index, length);
  
  uint8_t i_idx;
  for(i_idx=0;i_idx<length;i_idx++) {
    printf ("0x%02x ", data[i_idx]);
  }
  printf ("\n");
  
  
  
  switch(index) {

  case 0x01:    
    {
      eRet = eEC_APP_NO_ERROR;
      break;
    }
    
  default:
    {
      eRet = eEC_ACYC_SLAVE_ERR_INDEX;      
      break;
    }
    
  }
  return(eRet);
}


// #############################################################################
/*
 * Callback for the acyclic process data that reads the PLC from the device.
 * 
 * /see swd_slave.h
 */
EC_ApplicErrors_e 
swd_slave_acyc_read_object_user (EC_Connection_t * con, uint8_t index, uint8_t * data, uint8_t * length) 
{
  
  EC_ApplicErrors_e   eRet = eEC_APP_NO_ERROR;
  
  printf ("ACPU:%s:index:0x%02X:length:%u:", __FUNCTION__, index, *length);
  switch(index) {

  case 0x01:    
    {
      /* Acyclic data */
      acyclic_data_cnt++;
      printf("Acyclic data req %u\n", acyclic_data_cnt);
      data[0]=acyclic_data_cnt;
      data[1]=acyclic_data_cnt;
      data[2]=acyclic_data_cnt;
      data[3]=acyclic_data_cnt;
      *length=4;
      break;
    }
    
  case 0xF0:
    {
      /* HW info */
      printf("To Be Done\n");
      data[0]=0x11;
      *length=1;
      return(eEC_APP_NO_ERROR);
      break;
    }

  case 0xF8:
    {
      printf("2mbps\n");
      swd_enh_prop_2mbps(data, length);
      return(eEC_APP_NO_ERROR);
      break;
    }


  default:
    {
      printf("unknown index, object is not supported by this device\n");
      eRet = eEC_ACYC_SLAVE_ERR_INDEX;      
      break;
    }
    
  }
  return(eRet);
}

// #############################################################################
/* 
 * Read SWD Slave device configuration from database (swd_device_db_file.h) which is genetrated by swd_gen_device.py
 * 
 * /see swd_slave.h
 */
const cfg_t cfgs[SWD_DEVICE_DB_MAX_CFGS_COMPLETE] = SWD_DEVICE_DB_ALT_CFGS_ARRAY_COMPLETE;

int8_t 
swd_slave_get_cfg (cfg_t * cfg) 
{
  uint8_t cfg_select = cfg->type_kb.kb1.val;
  if (cfg_select >= SWD_DEVICE_DB_MAX_CFGS_COMPLETE) return -1;
  *cfg = cfgs[cfg_select];
  return cfg_select;
}

// #############################################################################
/*
 * SWD Stack request reset of CPU 
 * 
 * /see swd_slave.h
 */
void 
swd_slave_request_host_cpu_reset(void)
{
}