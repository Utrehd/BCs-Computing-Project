/***************************************************************************
 *
 *  SWD-Slave Stack 
 *  This Stack implements the behaviour required to join a Smartwire DT Bus Collection.
 *
 *  Copyright (c) 2010, Eaton Industries GmbH
 *  All rights reserved.
 *  Subject to alterations without notice.
 *
 *  All brand and product names are trademarks or registered trademarks of
 *  the owner concerned.
 *
 *  See User Guide Slave Stack.pdf Document for further information.
 *
 ****************************************************************************/

#ifndef _SWD_PARAM_H
#define _SWD_PARAM_H

/**
 * @defgroup SWDSTACK_DIAGNOSE Diagnostic Messages
 * @ingroup SWDSTACK
 *
 * The header file "swd_param.h" defines the device-specific diagnostic messages
 * and will be expanded through the device firmware, by expansion of the 
 * enumeration type "diag_t"
 * 
 * The diagnostic messages can be used with the following functions:
 * @see swd_diagnose_on
 * @see swd_diagnose_off
 * @see swd_diagnose_is_present
 * @see swd_diagnose_check
 *
 * @{
 */

/**
 * @brief Enumeration type for device-specific diagnostic messages
 *
 * The enumeration type diag_t contains all device-specific diagnostic messages
 * and will be expanded through the firmware developers. The value "0" is 
 * reserved for the type of error "No error". Because it used a 16-bit word for
 * internal storage the elements of the enumeration only assume values ​​between 
 * 0 and 15
 */

typedef enum {
	eDiag_no_error = -1,
	eDiag_pb_pressed = 0,
        eDiag1_critical = 1,  //nur für testslave
        eDiag2_non_critical = 2
} diag_t;

/**
 * @}
 */

#endif
