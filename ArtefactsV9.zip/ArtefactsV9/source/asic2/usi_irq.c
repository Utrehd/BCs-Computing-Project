#include <hardware.h>
#include <usi.h>



#ifdef __IAR_SYSTEMS_ICC__
  __weak
#else
  __attribute__((weak))
#endif
void usi_uart_dma_interrupt_subroutine(usi_num_t usi_no) {
}

#ifdef __IAR_SYSTEMS_ICC__
  __weak
#else
  __attribute__((weak))
#endif
void usi_spi_dma_interrupt_subroutine(usi_num_t usi_no) {
}


static bool usi_irq_register_spi_Nuart[NUMBER_USI];


/* ########################################################################## */
_INTERRUPT_ IRQ_USI0_Handler( void ) {
  const usi_num_t usi_no = USI0;
  const uint8_t usi_no_uint = 0;
  
  if(usi_irq_register_spi_Nuart[usi_no_uint] == USI_MODE_UART) {
    usi_uart_dma_interrupt_subroutine(usi_no);
  }
  if(usi_irq_register_spi_Nuart[usi_no_uint] == USI_MODE_SPI) {
    usi_spi_dma_interrupt_subroutine(usi_no);
  }
}
/* ########################################################################## */
_INTERRUPT_ IRQ_USI1_Handler( void ) {
  const usi_num_t usi_no = USI1;
  const uint8_t usi_no_uint = 1;
  
  if(usi_irq_register_spi_Nuart[usi_no_uint] == USI_MODE_UART) {
    usi_uart_dma_interrupt_subroutine(usi_no);
  }
  if(usi_irq_register_spi_Nuart[usi_no_uint] == USI_MODE_SPI) {
    usi_spi_dma_interrupt_subroutine(usi_no);
  }
}

/* ########################################################################## */
void usi_irq_set_spi_Nuart(usi_num_t usi_no, bool spi_Nuart) {
  
  usi_irq_register_spi_Nuart[usi_no_to_index(usi_no)]=spi_Nuart;
}