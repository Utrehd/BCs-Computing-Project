/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         el_ctrl_bf.h
*
* @brief        Electronic Label HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __EL_CTRL_BF_H__
#define __EL_CTRL_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_EL_CTRL
#define BASE_ADDR_EL_CTRL 0x40006600U
#endif

#define NUMBER_EL_CTRL 1


/* ############################################################################ */
/**
 * \brief This is an enum class for Electronic Label Control (EL_CTRL) instance
 *
 * \ingroup el_ctrl 
 */ 
typedef enum {
  /**
   * This is instance EL_CTRL
   */ 
  EL_CTRL                        = (int)BASE_ADDR_EL_CTRL
} el_ctrl_num_t;

// Register bit field definitions

/* EL_CTRL_TIA_CFG */

#define MSK_EL_CTRL_TIA_CFG_TIA_POWER_MODE                  (0x3)     /* [ 1:0] */
#define RES_EL_CTRL_TIA_CFG_TIA_POWER_MODE                  (0x0)
#define SFT_EL_CTRL_TIA_CFG_TIA_POWER_MODE                  (0)
#define LSB_EL_CTRL_TIA_CFG_TIA_POWER_MODE                  (0)
#define MSB_EL_CTRL_TIA_CFG_TIA_POWER_MODE                  (1)
#define MSK_EL_CTRL_TIA_CFG_TIA_CFG_HYST                    (0x3)     /* [ 3:2] */
#define RES_EL_CTRL_TIA_CFG_TIA_CFG_HYST                    (0x1)
#define SFT_EL_CTRL_TIA_CFG_TIA_CFG_HYST                    (2)
#define LSB_EL_CTRL_TIA_CFG_TIA_CFG_HYST                    (2)
#define MSB_EL_CTRL_TIA_CFG_TIA_CFG_HYST                    (3)

// use_GPO_SWD_LED_and_not_EL
#define STATUS_LED_EL_ON  0
#define STATUS_LED_EL_OFF 1


/* ############################################################################ */
/**
 * \brief This structure describes EL_CTRL Tia configuration
 *
 * \ingroup el_ctrl 
 */ 
typedef struct {
  /**
   * 0: TIA in power down <br>
   * 1: TIA in always on <br>
   * 2: TIA in automatic power mode
   */ 
  unsigned short tia_power_mode                :    2;       /* [ 1:0] */
  /**
   * see electrical parameters
   */ 
  unsigned short tia_cfg_hyst                  :    2;       /* [ 3:2] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :   12;
} el_ctrl_tia_cfg_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of EL_CTRL Tia configuration
 *
 * \ingroup el_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  el_ctrl_tia_cfg_bf bf;  ///< bit field representation
} el_ctrl_tia_cfg_t;


/* EL_CTRL_CYC_CFG */

#define MSK_EL_CTRL_CYC_CFG                                 (0x1)     /* [0] */

typedef unsigned short el_ctrl_cyc_cfg_t;                             /* [0] */


/* EL_CTRL_CYC_LEN */

#define MSK_EL_CTRL_CYC_LEN                                 (0xffff)  /* [15:0] */

typedef unsigned short el_ctrl_cyc_len_t;                             /* [15:0] */


/* EL_CTRL_CYC_TX_START */

#define MSK_EL_CTRL_CYC_TX_START                            (0xffff)  /* [15:0] */

typedef unsigned short el_ctrl_cyc_tx_start_t;                        /* [15:0] */


/* EL_CTRL_MEAS_CFG */

#define MSK_EL_CTRL_MEAS_CFG_EN                             (0x1)     /* [0] */
#define RES_EL_CTRL_MEAS_CFG_EN                             (0x0)
#define SFT_EL_CTRL_MEAS_CFG_EN                             (0)
#define LSB_EL_CTRL_MEAS_CFG_EN                             (0)
#define MSB_EL_CTRL_MEAS_CFG_EN                             (0)
#define BIT_EL_CTRL_MEAS_CFG_EN                             (0x1)     /* [0] */
#define MSK_EL_CTRL_MEAS_CFG_ZERO_LEVEL                     (0x1)     /* [1] */
#define RES_EL_CTRL_MEAS_CFG_ZERO_LEVEL                     (0x0)
#define SFT_EL_CTRL_MEAS_CFG_ZERO_LEVEL                     (1)
#define LSB_EL_CTRL_MEAS_CFG_ZERO_LEVEL                     (1)
#define MSB_EL_CTRL_MEAS_CFG_ZERO_LEVEL                     (1)
#define BIT_EL_CTRL_MEAS_CFG_ZERO_LEVEL                     (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes EL_CTRL Measurement Configuration
 *
 * \ingroup el_ctrl 
 */ 
typedef struct {
  /**
   * 0: disabled (MEAS_INTF is stopped and cleared) <br>
   * 1: enabled during rx phase
   */ 
  unsigned short en                            :    1;       /* [0] */
  /**
   * 0: Measurement 0-Level is led_rx=0 <br>
   * 1: Measurement 0-Level is led_rx=1
   */ 
  unsigned short zero_level                    :    1;       /* [1] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :   14;
} el_ctrl_meas_cfg_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of EL_CTRL Measurement Configuration
 *
 * \ingroup el_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  el_ctrl_meas_cfg_bf bf;  ///< bit field representation
} el_ctrl_meas_cfg_t;


/* EL_CTRL_MEAS_INTF_COEF */

#define MSK_EL_CTRL_MEAS_INTF_COEF                          (0x7fff)  /* [14:0] */

typedef unsigned short el_ctrl_meas_intf_coef_t;                      /* [14:0] */


/* EL_CTRL_TX_CFG */

#define MSK_EL_CTRL_TX_CFG_TRIGGER                          (0x3)     /* [ 1:0] */
#define RES_EL_CTRL_TX_CFG_TRIGGER                          (0x0)
#define SFT_EL_CTRL_TX_CFG_TRIGGER                          (0)
#define LSB_EL_CTRL_TX_CFG_TRIGGER                          (0)
#define MSB_EL_CTRL_TX_CFG_TRIGGER                          (1)
#define MSK_EL_CTRL_TX_CFG_NRZ                              (0x1)     /* [2] */
#define RES_EL_CTRL_TX_CFG_NRZ                              (0x0)
#define SFT_EL_CTRL_TX_CFG_NRZ                              (2)
#define LSB_EL_CTRL_TX_CFG_NRZ                              (2)
#define MSB_EL_CTRL_TX_CFG_NRZ                              (2)
#define BIT_EL_CTRL_TX_CFG_NRZ                              (0x4)     /* [2] */
#define MSK_EL_CTRL_TX_CFG_ZERO_LEVEL                       (0x1)     /* [3] */
#define RES_EL_CTRL_TX_CFG_ZERO_LEVEL                       (0x0)
#define SFT_EL_CTRL_TX_CFG_ZERO_LEVEL                       (3)
#define LSB_EL_CTRL_TX_CFG_ZERO_LEVEL                       (3)
#define MSB_EL_CTRL_TX_CFG_ZERO_LEVEL                       (3)
#define BIT_EL_CTRL_TX_CFG_ZERO_LEVEL                       (0x8)     /* [3] */
#define MSK_EL_CTRL_TX_CFG_RX2TX_LEVEL                      (0x1)     /* [4] */
#define RES_EL_CTRL_TX_CFG_RX2TX_LEVEL                      (0x0)
#define SFT_EL_CTRL_TX_CFG_RX2TX_LEVEL                      (4)
#define LSB_EL_CTRL_TX_CFG_RX2TX_LEVEL                      (4)
#define MSB_EL_CTRL_TX_CFG_RX2TX_LEVEL                      (4)
#define BIT_EL_CTRL_TX_CFG_RX2TX_LEVEL                      (0x10)    /* [4] */
#define MSK_EL_CTRL_TX_CFG_PREAMBLE_LENGTH                  (0x3f)    /* [10:5] */
#define RES_EL_CTRL_TX_CFG_PREAMBLE_LENGTH                  (0x01)
#define SFT_EL_CTRL_TX_CFG_PREAMBLE_LENGTH                  (5)
#define LSB_EL_CTRL_TX_CFG_PREAMBLE_LENGTH                  (5)
#define MSB_EL_CTRL_TX_CFG_PREAMBLE_LENGTH                  (10)
#define MSK_EL_CTRL_TX_CFG_PST_LEVEL                        (0x1)     /* [11] */
#define RES_EL_CTRL_TX_CFG_PST_LEVEL                        (0x1)
#define SFT_EL_CTRL_TX_CFG_PST_LEVEL                        (11)
#define LSB_EL_CTRL_TX_CFG_PST_LEVEL                        (11)
#define MSB_EL_CTRL_TX_CFG_PST_LEVEL                        (11)
#define BIT_EL_CTRL_TX_CFG_PST_LEVEL                        (0x800)   /* [11] */
#define MSK_EL_CTRL_TX_CFG_PAT_EN                           (0x1)     /* [12] */
#define RES_EL_CTRL_TX_CFG_PAT_EN                           (0x1)
#define SFT_EL_CTRL_TX_CFG_PAT_EN                           (12)
#define LSB_EL_CTRL_TX_CFG_PAT_EN                           (12)
#define MSB_EL_CTRL_TX_CFG_PAT_EN                           (12)
#define BIT_EL_CTRL_TX_CFG_PAT_EN                           (0x1000)  /* [12] */
#define MSK_EL_CTRL_TX_CFG_GPO_IGNORE                       (0x1)     /* [13] */
#define RES_EL_CTRL_TX_CFG_GPO_IGNORE                       (0x0)
#define SFT_EL_CTRL_TX_CFG_GPO_IGNORE                       (13)
#define LSB_EL_CTRL_TX_CFG_GPO_IGNORE                       (13)
#define MSB_EL_CTRL_TX_CFG_GPO_IGNORE                       (13)
#define BIT_EL_CTRL_TX_CFG_GPO_IGNORE                       (0x2000)  /* [13] */
#define MSK_EL_CTRL_TX_CFG_ALWAYS_PRE                       (0x1)     /* [14] */
#define RES_EL_CTRL_TX_CFG_ALWAYS_PRE                       (0x1)
#define SFT_EL_CTRL_TX_CFG_ALWAYS_PRE                       (14)
#define LSB_EL_CTRL_TX_CFG_ALWAYS_PRE                       (14)
#define MSB_EL_CTRL_TX_CFG_ALWAYS_PRE                       (14)
#define BIT_EL_CTRL_TX_CFG_ALWAYS_PRE                       (0x4000)  /* [14] */
#define MSK_EL_CTRL_TX_CFG_DRIVE_TX2RX                      (0x1)     /* [15] */
#define RES_EL_CTRL_TX_CFG_DRIVE_TX2RX                      (0x1)
#define SFT_EL_CTRL_TX_CFG_DRIVE_TX2RX                      (15)
#define LSB_EL_CTRL_TX_CFG_DRIVE_TX2RX                      (15)
#define MSB_EL_CTRL_TX_CFG_DRIVE_TX2RX                      (15)
#define BIT_EL_CTRL_TX_CFG_DRIVE_TX2RX                      (0x8000)  /* [15] */


/* ############################################################################ */
/**
 * \brief This structure describes EL_CTRL Transmitter Configuration
 *
 * \ingroup el_ctrl 
 */ 
typedef struct {
  /**
   * Selects which condition triggers rx2tx phase data transmission is only done when not tx_empty: <br>
   * 0: tx disabled <br>
   * 1: immediately <br>
   * 2: trans_start_evt detected <br>
   * 3: when CYC_TX_START occurs
   */ 
  unsigned short trigger                       :    2;       /* [ 1:0] */
  /**
   * 0: transmit uses Manchester encoding <br>
   * 1: transmit used NRZ encoding
   */ 
  unsigned short nrz                           :    1;       /* [2] */
  /**
   * Level during TX PRE and TX phase. <br>
   * Will also be used for optional TX2RX drive. <br>
   * NRZ encoding: <br>
   * 0: data '0' is el_tx=0 (led off) <br>
   * 1: data '0' is el_tx=1 (led on) <br>
   * Manchester encoding: <br>
   * 0: 0-Level is el_tx=0 (led off) <br>
   * 1: 0-Level is el_tx=1 (led on)
   */ 
  unsigned short zero_level                    :    1;       /* [3] */
  /**
   * Value of el_tx during rx2tx phase: <br>
   * 0: el_tx=0 (led off) <br>
   * 1: el_tx=1 (led on)
   */ 
  unsigned short rx2tx_level                   :    1;       /* [4] */
  /**
   * For Manchester encoding: <br>
   * 0: do not send preamble <br>
   * 1: minimal preamble <br>
   * 2: one additional zero before minimal preamble <br>
   * 3: two additional zeros before minimal preamble <br>
   * ... <br>
   * For NRZ encoding preamble_length must be set to 0, i.e. <br>
   * no preamble is send.
   */ 
  unsigned short preamble_length               :    6;       /* [10:5] */
  /**
   * Value of el_tx during tx pst phase: <br>
   * 0: el_tx=0 (led off) <br>
   * 1: el_tx=1 (led on)
   */ 
  unsigned short pst_level                     :    1;       /* [11] */
  /**
   * 0: tx pat disabled (will directly go to tx2rx phase) <br>
   * 1: send led_on pattern during tx pat until end of cycle
   */ 
  unsigned short pat_en                        :    1;       /* [12] */
  /**
   * 0: tx2rx and rx2tx states switch GPO and wait until gpo_now is equal to gpo_val <br>
   * 1: ignore GPO now and switch state directly
   */ 
  unsigned short gpo_ignore                    :    1;       /* [13] */
  /**
   * 0: go from rx2tx to tx pat when tx_empty <br>
   * 1: always send tx pre and tx pst
   */ 
  unsigned short always_pre                    :    1;       /* [14] */
  /**
   * 0: ELRX pin is high-z during tx2rx phase <br>
   * 1: ELRX pin will be driven with zero_level during tx2rx phase
   */ 
  unsigned short drive_tx2rx                   :    1;       /* [15] */
} el_ctrl_tx_cfg_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of EL_CTRL Transmitter Configuration
 *
 * \ingroup el_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  el_ctrl_tx_cfg_bf bf;  ///< bit field representation
} el_ctrl_tx_cfg_t;


/* EL_CTRL_TX_LED_ON_PATTERN */

#define MSK_EL_CTRL_TX_LED_ON_PATTERN                       (0xff)    /* [ 7:0] */

typedef unsigned short el_ctrl_tx_led_on_pattern_t;                   /* [ 7:0] */


/* EL_CTRL_MEAS_BR_MIN */

#define MSK_EL_CTRL_MEAS_BR_MIN                             (0xffff)  /* [15:0] */

typedef unsigned short el_ctrl_meas_br_min_t;                         /* [15:0] */


/* EL_CTRL_TX_BR_LW */

#define MSK_EL_CTRL_TX_BR_LW                                (0xffff)  /* [15:0] */

typedef unsigned short el_ctrl_tx_br_lw_t;                            /* [15:0] */


/* EL_CTRL_TX_BR_HW */

#define MSK_EL_CTRL_TX_BR_HW                                (0xffff)  /* [15:0] */

typedef unsigned short el_ctrl_tx_br_hw_t;                            /* [15:0] */


/* EL_CTRL_TX_LEN */

#define MSK_EL_CTRL_TX_LEN                                  (0x7f)    /* [ 6:0] */

typedef unsigned short el_ctrl_tx_len_t;                              /* [ 6:0] */


/* EL_CTRL_RX_CFG */

#define MSK_EL_CTRL_RX_CFG_EN                               (0x1)     /* [0] */
#define RES_EL_CTRL_RX_CFG_EN                               (0x0)
#define SFT_EL_CTRL_RX_CFG_EN                               (0)
#define LSB_EL_CTRL_RX_CFG_EN                               (0)
#define MSB_EL_CTRL_RX_CFG_EN                               (0)
#define BIT_EL_CTRL_RX_CFG_EN                               (0x1)     /* [0] */
#define MSK_EL_CTRL_RX_CFG_ZERO_LEVEL                       (0x1)     /* [1] */
#define RES_EL_CTRL_RX_CFG_ZERO_LEVEL                       (0x0)
#define SFT_EL_CTRL_RX_CFG_ZERO_LEVEL                       (1)
#define LSB_EL_CTRL_RX_CFG_ZERO_LEVEL                       (1)
#define MSB_EL_CTRL_RX_CFG_ZERO_LEVEL                       (1)
#define BIT_EL_CTRL_RX_CFG_ZERO_LEVEL                       (0x2)     /* [1] */
#define MSK_EL_CTRL_RX_CFG_PRE0_LENGTH                      (0x7)     /* [ 4:2] */
#define RES_EL_CTRL_RX_CFG_PRE0_LENGTH                      (0x0)
#define SFT_EL_CTRL_RX_CFG_PRE0_LENGTH                      (2)
#define LSB_EL_CTRL_RX_CFG_PRE0_LENGTH                      (2)
#define MSB_EL_CTRL_RX_CFG_PRE0_LENGTH                      (4)
#define MSK_EL_CTRL_RX_CFG_PRE1_LENGTH                      (0x7f)    /* [11:5] */
#define RES_EL_CTRL_RX_CFG_PRE1_LENGTH                      (0x00)
#define SFT_EL_CTRL_RX_CFG_PRE1_LENGTH                      (5)
#define LSB_EL_CTRL_RX_CFG_PRE1_LENGTH                      (5)
#define MSB_EL_CTRL_RX_CFG_PRE1_LENGTH                      (11)
#define MSK_EL_CTRL_RX_CFG_MIN_PREAMBLE_LEN                 (0xf)     /* [15:12] */
#define RES_EL_CTRL_RX_CFG_MIN_PREAMBLE_LEN                 (0x0)
#define SFT_EL_CTRL_RX_CFG_MIN_PREAMBLE_LEN                 (12)
#define LSB_EL_CTRL_RX_CFG_MIN_PREAMBLE_LEN                 (12)
#define MSB_EL_CTRL_RX_CFG_MIN_PREAMBLE_LEN                 (15)


/* ############################################################################ */
/**
 * \brief This structure describes EL_CTRL Receiver Configuration
 *
 * \ingroup el_ctrl 
 */ 
typedef struct {
  /**
   * 1: receiver enabled (when not transmitting) <br>
   * 0: receiver disabled and set to “wait for preamble” state
   */ 
  unsigned short en                            :    1;       /* [0] */
  /**
   * 0: Manchester 0-Level is led_rx=0 <br>
   * 1: Manchester 0-Level is led_rx=1
   */ 
  unsigned short zero_level                    :    1;       /* [1] */
  /**
   * 0: rx pre0 phase disabled <br>
   * 1..MAX: length of rx pre0 phase in bits
   */ 
  unsigned short pre0_length                   :    3;       /* [ 4:2] */
  /**
   * 0: rx pre1 phase disabled <br>
   * 1..MAX: length of rx pre1 phase in bits
   */ 
  unsigned short pre1_length                   :    7;       /* [11:5] */
  /**
   * 0: minimal preamble sufficient <br>
   * 1: at least one additional zero before minimal preamble <br>
   * 2: t least two additional zeros before minimal preamble <br>
   * ...
   */ 
  unsigned short min_preamble_len              :    4;       /* [15:12] */
} el_ctrl_rx_cfg_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of EL_CTRL Receiver Configuration
 *
 * \ingroup el_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  el_ctrl_rx_cfg_bf bf;  ///< bit field representation
} el_ctrl_rx_cfg_t;


/* EL_CTRL_RX_INTF_THR */

#define MSK_EL_CTRL_RX_INTF_THR                             (0xff)    /* [ 7:0] */

typedef unsigned short el_ctrl_rx_intf_thr_t;                         /* [ 7:0] */


/* EL_CTRL_RX_BR */

#define MSK_EL_CTRL_RX_BR                                   (0x7fff)  /* [14:0] */

typedef unsigned short el_ctrl_rx_br_t;                               /* [14:0] */


/* EL_CTRL_TX_FIFO */

#define MSK_EL_CTRL_TX_FIFO_DATA                            (0xff)    /* [ 7:0] */
#define RES_EL_CTRL_TX_FIFO_DATA                            (0x00)
#define SFT_EL_CTRL_TX_FIFO_DATA                            (0)
#define LSB_EL_CTRL_TX_FIFO_DATA                            (0)
#define MSB_EL_CTRL_TX_FIFO_DATA                            (7)
#define MSK_EL_CTRL_TX_FIFO_CLEAR                           (0x1)     /* [8] */
#define RES_EL_CTRL_TX_FIFO_CLEAR                           (0x0)
#define SFT_EL_CTRL_TX_FIFO_CLEAR                           (8)
#define LSB_EL_CTRL_TX_FIFO_CLEAR                           (8)
#define MSB_EL_CTRL_TX_FIFO_CLEAR                           (8)
#define BIT_EL_CTRL_TX_FIFO_CLEAR                           (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief This structure describes EL_CTRL TX FIFO
 *
 * \ingroup el_ctrl 
 */ 
typedef struct {
  /**
   * data byte to transmit. Length of FIFO is 8 bytes.
   */ 
  unsigned short data                          :    8;       /* [ 7:0] */
  /**
   * 1: clear transmit fifo (data field ignored)
   */ 
  unsigned short clear                         :    1;       /* [8] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    7;
} el_ctrl_tx_fifo_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of EL_CTRL TX FIFO
 *
 * \ingroup el_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  el_ctrl_tx_fifo_bf bf;  ///< bit field representation
} el_ctrl_tx_fifo_t;


/* EL_CTRL_RX_FIFO */

#define MSK_EL_CTRL_RX_FIFO_DATA                            (0xff)    /* [ 7:0] */
#define RES_EL_CTRL_RX_FIFO_DATA                            (0x00)
#define SFT_EL_CTRL_RX_FIFO_DATA                            (0)
#define LSB_EL_CTRL_RX_FIFO_DATA                            (0)
#define MSB_EL_CTRL_RX_FIFO_DATA                            (7)
#define MSK_EL_CTRL_RX_FIFO_SOF                             (0x1)     /* [8] */
#define RES_EL_CTRL_RX_FIFO_SOF                             (0x0)
#define SFT_EL_CTRL_RX_FIFO_SOF                             (8)
#define LSB_EL_CTRL_RX_FIFO_SOF                             (8)
#define MSB_EL_CTRL_RX_FIFO_SOF                             (8)
#define BIT_EL_CTRL_RX_FIFO_SOF                             (0x100)   /* [8] */
#define MSK_EL_CTRL_RX_FIFO_CLEAR                           (0x1)     /* [9] */
#define RES_EL_CTRL_RX_FIFO_CLEAR                           (0x0)
#define SFT_EL_CTRL_RX_FIFO_CLEAR                           (9)
#define LSB_EL_CTRL_RX_FIFO_CLEAR                           (9)
#define MSB_EL_CTRL_RX_FIFO_CLEAR                           (9)
#define BIT_EL_CTRL_RX_FIFO_CLEAR                           (0x200)   /* [9] */


/* ############################################################################ */
/**
 * \brief This structure describes EL_CTRL RX FIFO
 *
 * \ingroup el_ctrl 
 */ 
typedef struct {
  /**
   * data byte received. Length of FIFO is 8 bytes.
   */ 
  unsigned short data                          :    8;       /* [ 7:0] */
  /**
   * start of frame (byte is first after PRE)
   */ 
  unsigned short sof                           :    1;       /* [8] */
  /**
   * 1: clear receive fifo
   */ 
  unsigned short clear                         :    1;       /* [9] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    6;
} el_ctrl_rx_fifo_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of EL_CTRL RX FIFO
 *
 * \ingroup el_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  el_ctrl_rx_fifo_bf bf;  ///< bit field representation
} el_ctrl_rx_fifo_t;


/* EL_CTRL_STATUS */

#define MSK_EL_CTRL_STATUS                                  (0xf)     /* [ 3:0] */

typedef unsigned short el_ctrl_status_t;                              /* [ 3:0] */


/* EL_CTRL_MEAS_CYC */

#define MSK_EL_CTRL_MEAS_CYC                                (0xffff)  /* [15:0] */

typedef unsigned short el_ctrl_meas_cyc_t;                            /* [15:0] */


/* EL_CTRL_MEAS_PRE */

#define MSK_EL_CTRL_MEAS_PRE                                (0xffff)  /* [15:0] */

typedef unsigned short el_ctrl_meas_pre_t;                            /* [15:0] */


/* EL_CTRL_IRQ_STATUS */

#define MSK_EL_CTRL_IRQ_STATUS_CYC_START_EVT                (0x1)     /* [0] */
#define RES_EL_CTRL_IRQ_STATUS_CYC_START_EVT                (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_CYC_START_EVT                (0)
#define LSB_EL_CTRL_IRQ_STATUS_CYC_START_EVT                (0)
#define MSB_EL_CTRL_IRQ_STATUS_CYC_START_EVT                (0)
#define BIT_EL_CTRL_IRQ_STATUS_CYC_START_EVT                (0x1)     /* [0] */
#define MSK_EL_CTRL_IRQ_STATUS_RECV_START_EVT               (0x1)     /* [1] */
#define RES_EL_CTRL_IRQ_STATUS_RECV_START_EVT               (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_RECV_START_EVT               (1)
#define LSB_EL_CTRL_IRQ_STATUS_RECV_START_EVT               (1)
#define MSB_EL_CTRL_IRQ_STATUS_RECV_START_EVT               (1)
#define BIT_EL_CTRL_IRQ_STATUS_RECV_START_EVT               (0x2)     /* [1] */
#define MSK_EL_CTRL_IRQ_STATUS_TRANS_START_EVT              (0x1)     /* [2] */
#define RES_EL_CTRL_IRQ_STATUS_TRANS_START_EVT              (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_TRANS_START_EVT              (2)
#define LSB_EL_CTRL_IRQ_STATUS_TRANS_START_EVT              (2)
#define MSB_EL_CTRL_IRQ_STATUS_TRANS_START_EVT              (2)
#define BIT_EL_CTRL_IRQ_STATUS_TRANS_START_EVT              (0x4)     /* [2] */
#define MSK_EL_CTRL_IRQ_STATUS_TX_EMPTY                     (0x1)     /* [3] */
#define RES_EL_CTRL_IRQ_STATUS_TX_EMPTY                     (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_TX_EMPTY                     (3)
#define LSB_EL_CTRL_IRQ_STATUS_TX_EMPTY                     (3)
#define MSB_EL_CTRL_IRQ_STATUS_TX_EMPTY                     (3)
#define BIT_EL_CTRL_IRQ_STATUS_TX_EMPTY                     (0x8)     /* [3] */
#define MSK_EL_CTRL_IRQ_STATUS_TX_FULL                      (0x1)     /* [4] */
#define RES_EL_CTRL_IRQ_STATUS_TX_FULL                      (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_TX_FULL                      (4)
#define LSB_EL_CTRL_IRQ_STATUS_TX_FULL                      (4)
#define MSB_EL_CTRL_IRQ_STATUS_TX_FULL                      (4)
#define BIT_EL_CTRL_IRQ_STATUS_TX_FULL                      (0x10)    /* [4] */
#define MSK_EL_CTRL_IRQ_STATUS_TX_LOW_WATER                 (0x1)     /* [5] */
#define RES_EL_CTRL_IRQ_STATUS_TX_LOW_WATER                 (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_TX_LOW_WATER                 (5)
#define LSB_EL_CTRL_IRQ_STATUS_TX_LOW_WATER                 (5)
#define MSB_EL_CTRL_IRQ_STATUS_TX_LOW_WATER                 (5)
#define BIT_EL_CTRL_IRQ_STATUS_TX_LOW_WATER                 (0x20)    /* [5] */
#define MSK_EL_CTRL_IRQ_STATUS_TX_END_EVT                   (0x1)     /* [6] */
#define RES_EL_CTRL_IRQ_STATUS_TX_END_EVT                   (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_TX_END_EVT                   (6)
#define LSB_EL_CTRL_IRQ_STATUS_TX_END_EVT                   (6)
#define MSB_EL_CTRL_IRQ_STATUS_TX_END_EVT                   (6)
#define BIT_EL_CTRL_IRQ_STATUS_TX_END_EVT                   (0x40)    /* [6] */
#define MSK_EL_CTRL_IRQ_STATUS_RX_EMPTY                     (0x1)     /* [7] */
#define RES_EL_CTRL_IRQ_STATUS_RX_EMPTY                     (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_RX_EMPTY                     (7)
#define LSB_EL_CTRL_IRQ_STATUS_RX_EMPTY                     (7)
#define MSB_EL_CTRL_IRQ_STATUS_RX_EMPTY                     (7)
#define BIT_EL_CTRL_IRQ_STATUS_RX_EMPTY                     (0x80)    /* [7] */
#define MSK_EL_CTRL_IRQ_STATUS_RX_HIGH_WATER                (0x1)     /* [8] */
#define RES_EL_CTRL_IRQ_STATUS_RX_HIGH_WATER                (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_RX_HIGH_WATER                (8)
#define LSB_EL_CTRL_IRQ_STATUS_RX_HIGH_WATER                (8)
#define MSB_EL_CTRL_IRQ_STATUS_RX_HIGH_WATER                (8)
#define BIT_EL_CTRL_IRQ_STATUS_RX_HIGH_WATER                (0x100)   /* [8] */
#define MSK_EL_CTRL_IRQ_STATUS_RX_FIFO_TIMEOUT              (0x1)     /* [9] */
#define RES_EL_CTRL_IRQ_STATUS_RX_FIFO_TIMEOUT              (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_RX_FIFO_TIMEOUT              (9)
#define LSB_EL_CTRL_IRQ_STATUS_RX_FIFO_TIMEOUT              (9)
#define MSB_EL_CTRL_IRQ_STATUS_RX_FIFO_TIMEOUT              (9)
#define BIT_EL_CTRL_IRQ_STATUS_RX_FIFO_TIMEOUT              (0x200)   /* [9] */
#define MSK_EL_CTRL_IRQ_STATUS_RX_DATA_INCOMPLETE_EVT       (0x1)     /* [10] */
#define RES_EL_CTRL_IRQ_STATUS_RX_DATA_INCOMPLETE_EVT       (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_RX_DATA_INCOMPLETE_EVT       (10)
#define LSB_EL_CTRL_IRQ_STATUS_RX_DATA_INCOMPLETE_EVT       (10)
#define MSB_EL_CTRL_IRQ_STATUS_RX_DATA_INCOMPLETE_EVT       (10)
#define BIT_EL_CTRL_IRQ_STATUS_RX_DATA_INCOMPLETE_EVT       (0x400)   /* [10] */
#define MSK_EL_CTRL_IRQ_STATUS_RX_OVERRUN_EVT               (0x1)     /* [11] */
#define RES_EL_CTRL_IRQ_STATUS_RX_OVERRUN_EVT               (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_RX_OVERRUN_EVT               (11)
#define LSB_EL_CTRL_IRQ_STATUS_RX_OVERRUN_EVT               (11)
#define MSB_EL_CTRL_IRQ_STATUS_RX_OVERRUN_EVT               (11)
#define BIT_EL_CTRL_IRQ_STATUS_RX_OVERRUN_EVT               (0x800)   /* [11] */
#define MSK_EL_CTRL_IRQ_STATUS_RX_END_EVT                   (0x1)     /* [12] */
#define RES_EL_CTRL_IRQ_STATUS_RX_END_EVT                   (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_RX_END_EVT                   (12)
#define LSB_EL_CTRL_IRQ_STATUS_RX_END_EVT                   (12)
#define MSB_EL_CTRL_IRQ_STATUS_RX_END_EVT                   (12)
#define BIT_EL_CTRL_IRQ_STATUS_RX_END_EVT                   (0x1000)  /* [12] */
#define MSK_EL_CTRL_IRQ_STATUS_CYC_INCOMPLETE_EVT           (0x1)     /* [13] */
#define RES_EL_CTRL_IRQ_STATUS_CYC_INCOMPLETE_EVT           (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_CYC_INCOMPLETE_EVT           (13)
#define LSB_EL_CTRL_IRQ_STATUS_CYC_INCOMPLETE_EVT           (13)
#define MSB_EL_CTRL_IRQ_STATUS_CYC_INCOMPLETE_EVT           (13)
#define BIT_EL_CTRL_IRQ_STATUS_CYC_INCOMPLETE_EVT           (0x2000)  /* [13] */
#define MSK_EL_CTRL_IRQ_STATUS_MEAS_BR_EVT                  (0x1)     /* [14] */
#define RES_EL_CTRL_IRQ_STATUS_MEAS_BR_EVT                  (0x0)
#define SFT_EL_CTRL_IRQ_STATUS_MEAS_BR_EVT                  (14)
#define LSB_EL_CTRL_IRQ_STATUS_MEAS_BR_EVT                  (14)
#define MSB_EL_CTRL_IRQ_STATUS_MEAS_BR_EVT                  (14)
#define BIT_EL_CTRL_IRQ_STATUS_MEAS_BR_EVT                  (0x4000)  /* [14] */


/* ############################################################################ */
/**
 * \brief This structure describes EL_CTRL Interrupt Request Status
 *
 * \ingroup el_ctrl 
 */ 
typedef struct {
  /**
   * start of cycle
   */ 
  unsigned short cyc_start_evt                 :    1;       /* [0] */
  /**
   * preamble detected, start of rx phase
   */ 
  unsigned short recv_start_evt                :    1;       /* [1] */
  /**
   * start of transmission detected
   */ 
  unsigned short trans_start_evt               :    1;       /* [2] */
  /**
   * transmit fifo empty
   */ 
  unsigned short tx_empty                      :    1;       /* [3] */
  /**
   * transmit FIFO full
   */ 
  unsigned short tx_full                       :    1;       /* [4] */
  /**
   * transmit FIFO less than 4 elements
   */ 
  unsigned short tx_low_water                  :    1;       /* [5] */
  /**
   * tx phase completed (led pat phase might still be ongoing)
   */ 
  unsigned short tx_end_evt                    :    1;       /* [6] */
  /**
   * receive fifo empty
   */ 
  unsigned short rx_empty                      :    1;       /* [7] */
  /**
   * receive fifo more than 4 elements
   */ 
  unsigned short rx_high_water                 :    1;       /* [8] */
  /**
   * Timeout occurs when rx fifo is not empty and when Manchester decoder is idle
   */ 
  unsigned short rx_fifo_timeout               :    1;       /* [9] */
  /**
   * 1: set when Manchester decoder “idle” and received data bits mod 8 != 0
   */ 
  unsigned short rx_data_incomplete_evt        :    1;       /* [10] */
  /**
   * receive fifo overrun
   */ 
  unsigned short rx_overrun_evt                :    1;       /* [11] */
  /**
   * receive completed
   */ 
  unsigned short rx_end_evt                    :    1;       /* [12] */
  /**
   * cyc start event outside of TX PAT
   */ 
  unsigned short cyc_incomplete_evt            :    1;       /* [13] */
  /**
   * bit rate extraction result register has been updated
   */ 
  unsigned short meas_br_evt                   :    1;       /* [14] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    1;
} el_ctrl_irq_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of EL_CTRL Interrupt Request Status
 *
 * \ingroup el_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  el_ctrl_irq_status_bf bf;  ///< bit field representation
} el_ctrl_irq_status_t;


/* EL_CTRL_IRQ_MASK */

#define MSK_EL_CTRL_IRQ_MASK                                (0x7fff)  /* [14:0] */

typedef unsigned short el_ctrl_irq_mask_t;                            /* [14:0] */


/* EL_CTRL_IRQ_VENABLE */

#define MSK_EL_CTRL_IRQ_VENABLE                             (0xf)     /* [ 3:0] */

typedef unsigned short el_ctrl_irq_venable_t;                         /* [ 3:0] */


/* EL_CTRL_IRQ_VDISABLE */

#define MSK_EL_CTRL_IRQ_VDISABLE                            (0xf)     /* [ 3:0] */

typedef unsigned short el_ctrl_irq_vdisable_t;                        /* [ 3:0] */


/* EL_CTRL_IRQ_VMAX */

#define MSK_EL_CTRL_IRQ_VMAX                                (0xf)     /* [ 3:0] */

typedef unsigned short el_ctrl_irq_vmax_t;                            /* [ 3:0] */


/* EL_CTRL_IRQ_VNO */

#define MSK_EL_CTRL_IRQ_VNO                                 (0xf)     /* [ 3:0] */

typedef unsigned short el_ctrl_irq_vno_t;                             /* [ 3:0] */



// Register definitions for module
// Instance base address BASE_ADDR_EL_CTRL 0x40006600U ... 

#define ADDR_EL_CTRL_TIA_CFG                                 (0x00U)
#define A_EL_CTRL_TIA_CFG(ba)                                ((ba) + ADDR_EL_CTRL_TIA_CFG)
#define R_EL_CTRL_TIA_CFG(ba)                                (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_TIA_CFG(ba)))
#define RES_EL_CTRL_TIA_CFG                                  (0x4U)
#define MSB_EL_CTRL_TIA_CFG                                  3
#define LSB_EL_CTRL_TIA_CFG                                  0
#define AADDR_EL_CTRL_TIA_CFG                                (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_TIA_CFG)
#define REG_EL_CTRL_TIA_CFG                                  (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_TIA_CFG))

#define ADDR_EL_CTRL_CYC_CFG                                 (0x02U)
#define A_EL_CTRL_CYC_CFG(ba)                                ((ba) + ADDR_EL_CTRL_CYC_CFG)
#define R_EL_CTRL_CYC_CFG(ba)                                (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_CYC_CFG(ba)))
#define RES_EL_CTRL_CYC_CFG                                  (0x0U)
#define MSB_EL_CTRL_CYC_CFG                                  0
#define LSB_EL_CTRL_CYC_CFG                                  0
#define AADDR_EL_CTRL_CYC_CFG                                (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_CYC_CFG)
#define REG_EL_CTRL_CYC_CFG                                  (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_CYC_CFG))

#define ADDR_EL_CTRL_CYC_LEN                                 (0x04U)
#define A_EL_CTRL_CYC_LEN(ba)                                ((ba) + ADDR_EL_CTRL_CYC_LEN)
#define R_EL_CTRL_CYC_LEN(ba)                                (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_CYC_LEN(ba)))
#define RES_EL_CTRL_CYC_LEN                                  (0x0U)
#define MSB_EL_CTRL_CYC_LEN                                  15
#define LSB_EL_CTRL_CYC_LEN                                  0
#define AADDR_EL_CTRL_CYC_LEN                                (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_CYC_LEN)
#define REG_EL_CTRL_CYC_LEN                                  (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_CYC_LEN))

#define ADDR_EL_CTRL_CYC_TX_START                            (0x06U)
#define A_EL_CTRL_CYC_TX_START(ba)                           ((ba) + ADDR_EL_CTRL_CYC_TX_START)
#define R_EL_CTRL_CYC_TX_START(ba)                           (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_CYC_TX_START(ba)))
#define RES_EL_CTRL_CYC_TX_START                             (0x0U)
#define MSB_EL_CTRL_CYC_TX_START                             15
#define LSB_EL_CTRL_CYC_TX_START                             0
#define AADDR_EL_CTRL_CYC_TX_START                           (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_CYC_TX_START)
#define REG_EL_CTRL_CYC_TX_START                             (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_CYC_TX_START))

#define ADDR_EL_CTRL_MEAS_CFG                                (0x08U)
#define A_EL_CTRL_MEAS_CFG(ba)                               ((ba) + ADDR_EL_CTRL_MEAS_CFG)
#define R_EL_CTRL_MEAS_CFG(ba)                               (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_MEAS_CFG(ba)))
#define RES_EL_CTRL_MEAS_CFG                                 (0x0U)
#define MSB_EL_CTRL_MEAS_CFG                                 1
#define LSB_EL_CTRL_MEAS_CFG                                 0
#define AADDR_EL_CTRL_MEAS_CFG                               (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_MEAS_CFG)
#define REG_EL_CTRL_MEAS_CFG                                 (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_MEAS_CFG))

#define ADDR_EL_CTRL_MEAS_INTF_COEF_RISE                     (0x0AU)
#define A_EL_CTRL_MEAS_INTF_COEF_RISE(ba)                    ((ba) + ADDR_EL_CTRL_MEAS_INTF_COEF_RISE)
#define R_EL_CTRL_MEAS_INTF_COEF_RISE(ba)                    (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_MEAS_INTF_COEF_RISE(ba)))
#define RES_EL_CTRL_MEAS_INTF_COEF_RISE                      (0x0U)
#define MSB_EL_CTRL_MEAS_INTF_COEF_RISE                      14
#define LSB_EL_CTRL_MEAS_INTF_COEF_RISE                      0
#define AADDR_EL_CTRL_MEAS_INTF_COEF_RISE                    (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_MEAS_INTF_COEF_RISE)
#define REG_EL_CTRL_MEAS_INTF_COEF_RISE                      (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_MEAS_INTF_COEF_RISE))

#define ADDR_EL_CTRL_MEAS_INTF_COEF_FALL                     (0x0CU)
#define A_EL_CTRL_MEAS_INTF_COEF_FALL(ba)                    ((ba) + ADDR_EL_CTRL_MEAS_INTF_COEF_FALL)
#define R_EL_CTRL_MEAS_INTF_COEF_FALL(ba)                    (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_MEAS_INTF_COEF_FALL(ba)))
#define RES_EL_CTRL_MEAS_INTF_COEF_FALL                      (0x0U)
#define MSB_EL_CTRL_MEAS_INTF_COEF_FALL                      14
#define LSB_EL_CTRL_MEAS_INTF_COEF_FALL                      0
#define AADDR_EL_CTRL_MEAS_INTF_COEF_FALL                    (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_MEAS_INTF_COEF_FALL)
#define REG_EL_CTRL_MEAS_INTF_COEF_FALL                      (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_MEAS_INTF_COEF_FALL))

#define ADDR_EL_CTRL_TX_CFG                                  (0x0EU)
#define A_EL_CTRL_TX_CFG(ba)                                 ((ba) + ADDR_EL_CTRL_TX_CFG)
#define R_EL_CTRL_TX_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_TX_CFG(ba)))
#define RES_EL_CTRL_TX_CFG                                   (0xd820U)
#define MSB_EL_CTRL_TX_CFG                                   15
#define LSB_EL_CTRL_TX_CFG                                   0
#define AADDR_EL_CTRL_TX_CFG                                 (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_TX_CFG)
#define REG_EL_CTRL_TX_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_TX_CFG))

#define ADDR_EL_CTRL_TX_LED_ON_PATTERN                       (0x10U)
#define A_EL_CTRL_TX_LED_ON_PATTERN(ba)                      ((ba) + ADDR_EL_CTRL_TX_LED_ON_PATTERN)
#define R_EL_CTRL_TX_LED_ON_PATTERN(ba)                      (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_TX_LED_ON_PATTERN(ba)))
#define RES_EL_CTRL_TX_LED_ON_PATTERN                        (0x55U)
#define MSB_EL_CTRL_TX_LED_ON_PATTERN                        7
#define LSB_EL_CTRL_TX_LED_ON_PATTERN                        0
#define AADDR_EL_CTRL_TX_LED_ON_PATTERN                      (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_TX_LED_ON_PATTERN)
#define REG_EL_CTRL_TX_LED_ON_PATTERN                        (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_TX_LED_ON_PATTERN))

#define ADDR_EL_CTRL_MEAS_BR_MIN                             (0x12U)
#define A_EL_CTRL_MEAS_BR_MIN(ba)                            ((ba) + ADDR_EL_CTRL_MEAS_BR_MIN)
#define R_EL_CTRL_MEAS_BR_MIN(ba)                            (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_MEAS_BR_MIN(ba)))
#define RES_EL_CTRL_MEAS_BR_MIN                              (0xffffU)
#define MSB_EL_CTRL_MEAS_BR_MIN                              15
#define LSB_EL_CTRL_MEAS_BR_MIN                              0
#define AADDR_EL_CTRL_MEAS_BR_MIN                            (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_MEAS_BR_MIN)
#define REG_EL_CTRL_MEAS_BR_MIN                              (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_MEAS_BR_MIN))

#define ADDR_EL_CTRL_TX_BR_LW                                (0x14U)
#define A_EL_CTRL_TX_BR_LW(ba)                               ((ba) + ADDR_EL_CTRL_TX_BR_LW)
#define R_EL_CTRL_TX_BR_LW(ba)                               (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_TX_BR_LW(ba)))
#define RES_EL_CTRL_TX_BR_LW                                 (0x0U)
#define MSB_EL_CTRL_TX_BR_LW                                 15
#define LSB_EL_CTRL_TX_BR_LW                                 0
#define AADDR_EL_CTRL_TX_BR_LW                               (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_TX_BR_LW)
#define REG_EL_CTRL_TX_BR_LW                                 (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_TX_BR_LW))

#define ADDR_EL_CTRL_TX_BR_HW                                (0x16U)
#define A_EL_CTRL_TX_BR_HW(ba)                               ((ba) + ADDR_EL_CTRL_TX_BR_HW)
#define R_EL_CTRL_TX_BR_HW(ba)                               (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_TX_BR_HW(ba)))
#define RES_EL_CTRL_TX_BR_HW                                 (0x0U)
#define MSB_EL_CTRL_TX_BR_HW                                 15
#define LSB_EL_CTRL_TX_BR_HW                                 0
#define AADDR_EL_CTRL_TX_BR_HW                               (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_TX_BR_HW)
#define REG_EL_CTRL_TX_BR_HW                                 (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_TX_BR_HW))

#define ADDR_EL_CTRL_TX_LEN                                  (0x18U)
#define A_EL_CTRL_TX_LEN(ba)                                 ((ba) + ADDR_EL_CTRL_TX_LEN)
#define R_EL_CTRL_TX_LEN(ba)                                 (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_TX_LEN(ba)))
#define RES_EL_CTRL_TX_LEN                                   (0x0U)
#define MSB_EL_CTRL_TX_LEN                                   6
#define LSB_EL_CTRL_TX_LEN                                   0
#define AADDR_EL_CTRL_TX_LEN                                 (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_TX_LEN)
#define REG_EL_CTRL_TX_LEN                                   (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_TX_LEN))

#define ADDR_EL_CTRL_RX_CFG                                  (0x1AU)
#define A_EL_CTRL_RX_CFG(ba)                                 ((ba) + ADDR_EL_CTRL_RX_CFG)
#define R_EL_CTRL_RX_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_RX_CFG(ba)))
#define RES_EL_CTRL_RX_CFG                                   (0x0U)
#define MSB_EL_CTRL_RX_CFG                                   15
#define LSB_EL_CTRL_RX_CFG                                   0
#define AADDR_EL_CTRL_RX_CFG                                 (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_RX_CFG)
#define REG_EL_CTRL_RX_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_RX_CFG))

#define ADDR_EL_CTRL_RX_INTF_THR                             (0x1CU)
#define A_EL_CTRL_RX_INTF_THR(ba)                            ((ba) + ADDR_EL_CTRL_RX_INTF_THR)
#define R_EL_CTRL_RX_INTF_THR(ba)                            (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_RX_INTF_THR(ba)))
#define RES_EL_CTRL_RX_INTF_THR                              (0x0U)
#define MSB_EL_CTRL_RX_INTF_THR                              7
#define LSB_EL_CTRL_RX_INTF_THR                              0
#define AADDR_EL_CTRL_RX_INTF_THR                            (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_RX_INTF_THR)
#define REG_EL_CTRL_RX_INTF_THR                              (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_RX_INTF_THR))

#define ADDR_EL_CTRL_RX_BR                                   (0x1EU)
#define A_EL_CTRL_RX_BR(ba)                                  ((ba) + ADDR_EL_CTRL_RX_BR)
#define R_EL_CTRL_RX_BR(ba)                                  (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_RX_BR(ba)))
#define RES_EL_CTRL_RX_BR                                    (0x0U)
#define MSB_EL_CTRL_RX_BR                                    14
#define LSB_EL_CTRL_RX_BR                                    0
#define AADDR_EL_CTRL_RX_BR                                  (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_RX_BR)
#define REG_EL_CTRL_RX_BR                                    (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_RX_BR))

#define ADDR_EL_CTRL_TX_FIFO                                 (0x20U)
#define A_EL_CTRL_TX_FIFO(ba)                                ((ba) + ADDR_EL_CTRL_TX_FIFO)
#define R_EL_CTRL_TX_FIFO(ba)                                (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_TX_FIFO(ba)))
#define RES_EL_CTRL_TX_FIFO                                  (0x0U)
#define MSB_EL_CTRL_TX_FIFO                                  8
#define LSB_EL_CTRL_TX_FIFO                                  0
#define AADDR_EL_CTRL_TX_FIFO                                (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_TX_FIFO)
#define REG_EL_CTRL_TX_FIFO                                  (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_TX_FIFO))

#define ADDR_EL_CTRL_RX_FIFO                                 (0x22U)
#define A_EL_CTRL_RX_FIFO(ba)                                ((ba) + ADDR_EL_CTRL_RX_FIFO)
#define R_EL_CTRL_RX_FIFO(ba)                                (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_RX_FIFO(ba)))
#define RES_EL_CTRL_RX_FIFO                                  (0x0U)
#define MSB_EL_CTRL_RX_FIFO                                  9
#define LSB_EL_CTRL_RX_FIFO                                  0
#define AADDR_EL_CTRL_RX_FIFO                                (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_RX_FIFO)
#define REG_EL_CTRL_RX_FIFO                                  (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_RX_FIFO))

#define ADDR_EL_CTRL_STATUS                                  (0x24U)
#define A_EL_CTRL_STATUS(ba)                                 ((ba) + ADDR_EL_CTRL_STATUS)
#define R_EL_CTRL_STATUS(ba)                                 (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_STATUS(ba)))
#define RES_EL_CTRL_STATUS                                   (0x7U)
#define MSB_EL_CTRL_STATUS                                   3
#define LSB_EL_CTRL_STATUS                                   0
#define AADDR_EL_CTRL_STATUS                                 (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_STATUS)
#define REG_EL_CTRL_STATUS                                   (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_STATUS))

#define ADDR_EL_CTRL_MEAS_CYC_LW                             (0x28U)
#define A_EL_CTRL_MEAS_CYC_LW(ba)                            ((ba) + ADDR_EL_CTRL_MEAS_CYC_LW)
#define R_EL_CTRL_MEAS_CYC_LW(ba)                            (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_MEAS_CYC_LW(ba)))
#define RES_EL_CTRL_MEAS_CYC_LW                              (0x0U)
#define MSB_EL_CTRL_MEAS_CYC_LW                              15
#define LSB_EL_CTRL_MEAS_CYC_LW                              0
#define AADDR_EL_CTRL_MEAS_CYC_LW                            (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_MEAS_CYC_LW)
#define REG_EL_CTRL_MEAS_CYC_LW                              (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_MEAS_CYC_LW))

#define ADDR_EL_CTRL_MEAS_CYC_HW                             (0x2AU)
#define A_EL_CTRL_MEAS_CYC_HW(ba)                            ((ba) + ADDR_EL_CTRL_MEAS_CYC_HW)
#define R_EL_CTRL_MEAS_CYC_HW(ba)                            (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_MEAS_CYC_HW(ba)))
#define RES_EL_CTRL_MEAS_CYC_HW                              (0x0U)
#define MSB_EL_CTRL_MEAS_CYC_HW                              15
#define LSB_EL_CTRL_MEAS_CYC_HW                              0
#define AADDR_EL_CTRL_MEAS_CYC_HW                            (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_MEAS_CYC_HW)
#define REG_EL_CTRL_MEAS_CYC_HW                              (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_MEAS_CYC_HW))

#define ADDR_EL_CTRL_MEAS_PRE_LW                             (0x2CU)
#define A_EL_CTRL_MEAS_PRE_LW(ba)                            ((ba) + ADDR_EL_CTRL_MEAS_PRE_LW)
#define R_EL_CTRL_MEAS_PRE_LW(ba)                            (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_MEAS_PRE_LW(ba)))
#define RES_EL_CTRL_MEAS_PRE_LW                              (0x0U)
#define MSB_EL_CTRL_MEAS_PRE_LW                              15
#define LSB_EL_CTRL_MEAS_PRE_LW                              0
#define AADDR_EL_CTRL_MEAS_PRE_LW                            (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_MEAS_PRE_LW)
#define REG_EL_CTRL_MEAS_PRE_LW                              (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_MEAS_PRE_LW))

#define ADDR_EL_CTRL_MEAS_PRE_HW                             (0x2EU)
#define A_EL_CTRL_MEAS_PRE_HW(ba)                            ((ba) + ADDR_EL_CTRL_MEAS_PRE_HW)
#define R_EL_CTRL_MEAS_PRE_HW(ba)                            (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_MEAS_PRE_HW(ba)))
#define RES_EL_CTRL_MEAS_PRE_HW                              (0x0U)
#define MSB_EL_CTRL_MEAS_PRE_HW                              15
#define LSB_EL_CTRL_MEAS_PRE_HW                              0
#define AADDR_EL_CTRL_MEAS_PRE_HW                            (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_MEAS_PRE_HW)
#define REG_EL_CTRL_MEAS_PRE_HW                              (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_MEAS_PRE_HW))

#define ADDR_EL_CTRL_IRQ_STATUS                              (0x30U)
#define A_EL_CTRL_IRQ_STATUS(ba)                             ((ba) + ADDR_EL_CTRL_IRQ_STATUS)
#define R_EL_CTRL_IRQ_STATUS(ba)                             (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_IRQ_STATUS(ba)))
#define RES_EL_CTRL_IRQ_STATUS                               (0x0U)
#define MSB_EL_CTRL_IRQ_STATUS                               14
#define LSB_EL_CTRL_IRQ_STATUS                               0
#define AADDR_EL_CTRL_IRQ_STATUS                             (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_IRQ_STATUS)
#define REG_EL_CTRL_IRQ_STATUS                               (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_IRQ_STATUS))

#define ADDR_EL_CTRL_IRQ_MASK                                (0x34U)
#define A_EL_CTRL_IRQ_MASK(ba)                               ((ba) + ADDR_EL_CTRL_IRQ_MASK)
#define R_EL_CTRL_IRQ_MASK(ba)                               (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_IRQ_MASK(ba)))
#define RES_EL_CTRL_IRQ_MASK                                 (0x0U)
#define MSB_EL_CTRL_IRQ_MASK                                 14
#define LSB_EL_CTRL_IRQ_MASK                                 0
#define AADDR_EL_CTRL_IRQ_MASK                               (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_IRQ_MASK)
#define REG_EL_CTRL_IRQ_MASK                                 (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_IRQ_MASK))

#define ADDR_EL_CTRL_IRQ_VENABLE                             (0x38U)
#define A_EL_CTRL_IRQ_VENABLE(ba)                            ((ba) + ADDR_EL_CTRL_IRQ_VENABLE)
#define R_EL_CTRL_IRQ_VENABLE(ba)                            (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_IRQ_VENABLE(ba)))
#define RES_EL_CTRL_IRQ_VENABLE                              (0x0U)
#define MSB_EL_CTRL_IRQ_VENABLE                              3
#define LSB_EL_CTRL_IRQ_VENABLE                              0
#define AADDR_EL_CTRL_IRQ_VENABLE                            (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_IRQ_VENABLE)
#define REG_EL_CTRL_IRQ_VENABLE                              (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_IRQ_VENABLE))

#define ADDR_EL_CTRL_IRQ_VDISABLE                            (0x3AU)
#define A_EL_CTRL_IRQ_VDISABLE(ba)                           ((ba) + ADDR_EL_CTRL_IRQ_VDISABLE)
#define R_EL_CTRL_IRQ_VDISABLE(ba)                           (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_IRQ_VDISABLE(ba)))
#define RES_EL_CTRL_IRQ_VDISABLE                             (0x0U)
#define MSB_EL_CTRL_IRQ_VDISABLE                             3
#define LSB_EL_CTRL_IRQ_VDISABLE                             0
#define AADDR_EL_CTRL_IRQ_VDISABLE                           (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_IRQ_VDISABLE)
#define REG_EL_CTRL_IRQ_VDISABLE                             (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_IRQ_VDISABLE))

#define ADDR_EL_CTRL_IRQ_VMAX                                (0x3CU)
#define A_EL_CTRL_IRQ_VMAX(ba)                               ((ba) + ADDR_EL_CTRL_IRQ_VMAX)
#define R_EL_CTRL_IRQ_VMAX(ba)                               (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_IRQ_VMAX(ba)))
#define RES_EL_CTRL_IRQ_VMAX                                 (0xfU)
#define MSB_EL_CTRL_IRQ_VMAX                                 3
#define LSB_EL_CTRL_IRQ_VMAX                                 0
#define AADDR_EL_CTRL_IRQ_VMAX                               (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_IRQ_VMAX)
#define REG_EL_CTRL_IRQ_VMAX                                 (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_IRQ_VMAX))

#define ADDR_EL_CTRL_IRQ_VNO                                 (0x3EU)
#define A_EL_CTRL_IRQ_VNO(ba)                                ((ba) + ADDR_EL_CTRL_IRQ_VNO)
#define R_EL_CTRL_IRQ_VNO(ba)                                (*(volatile unsigned short *)((unsigned int)A_EL_CTRL_IRQ_VNO(ba)))
#define RES_EL_CTRL_IRQ_VNO                                  (0xfU)
#define MSB_EL_CTRL_IRQ_VNO                                  3
#define LSB_EL_CTRL_IRQ_VNO                                  0
#define AADDR_EL_CTRL_IRQ_VNO                                (BASE_ADDR_EL_CTRL + ADDR_EL_CTRL_IRQ_VNO)
#define REG_EL_CTRL_IRQ_VNO                                  (*(volatile unsigned short *)((unsigned int)AADDR_EL_CTRL_IRQ_VNO))




#endif
