#include "hardware.h"
#include "wdog_api.h"
#include "clk_nres_api.h"
#include "logger.h"


typedef struct WdogApi_t {
  uint32_t  dwuTimeout;
  uint16_t  nuSeqLen;
  uint8_t   cuCookie;
} WdogApiParameters_t;


WdogApiParameters_t GuardParameters_t[]={
  {
    /* GUARD0 */
    .dwuTimeout = 0xFFFFFFFF,   // 20000  Timeout of n*2us 
    .nuSeqLen   = 2,            // sequence length of 1...5..  
    .cuCookie   = 0x3E          // 0x3Eu
  },
  {
    /* GUARD1 */
    .dwuTimeout = 0xFFFFFFFF,  
    .nuSeqLen   = 2, 
    .cuCookie   = 0x3E
  }
};

WdogApiParameters_t WdogParameters_t[]={
  {
    /* WDOG0 */
    .dwuTimeout = 8,   // ((uint32_t)FREQ_CPU *8)  // SYSCLK_A*n = (2.000.000 * 1us) *2*4 = 4*4 sec  
    .nuSeqLen   = 5,   // sequence length of 1...10... 
    .cuCookie   = 0x3E
  },
  {
    /* WDOG1 */
    .dwuTimeout = 8,
    .nuSeqLen   = 5,
    .cuCookie   = 0x3E
  }
};

/* ############################################################################ */
static uint8_t wdog_api_guard_name2instance(wdog_api_guard_instance_t eInstance) {
  switch(eInstance) {
  case WDOG_API_GUARD0:
    return(0);
  case WDOG_API_GUARD1:
    return(1);
    
    
    
  default:
    fatal("Wrong parameter");
  }
  return(0);
}


/* ############################################################################ */
void wdog_api_guard_toggle(wdog_api_guard_instance_t eInstance)
{
  uint16_t  i;
  uint8_t   uCookie;
  uint8_t   uInstanceIndex = wdog_api_guard_name2instance(eInstance);
  
  
  WdogApiParameters_t tParameters = GuardParameters_t[uInstanceIndex];
  
  uCookie = tParameters.cuCookie;

  // write cookie sequence watchdog 0 (Guardian).
  // no debug output due timeout
  for (i = 0; i < tParameters.nuSeqLen; i++) {
    wdog_set_magic_cookie ((wdog_num_t)eInstance, uCookie);
    uCookie = wdog_calc_next_cookie (uCookie);
  }
  if (!wdog_get_allok ((wdog_num_t)eInstance)) {
    //error ("WD-GUARD:  could not activate guardian !\n");
  }
}

//=============================================================================
// Enable Guardian (initialize watchdog 0 ).
// no debug output due timeout
//============================================================================
void wdog_api_guard_enable(wdog_api_guard_instance_t eInstance)
{

  uint8_t   uInstanceIndex = wdog_api_guard_name2instance(eInstance);
  
  WdogApiParameters_t tParameters = GuardParameters_t[uInstanceIndex];
    
  wdog_disable ((wdog_num_t)eInstance);
  wdog_init ((wdog_num_t)eInstance, tParameters.cuCookie, tParameters.nuSeqLen, tParameters.dwuTimeout);
  if (wdog_is_running ((wdog_num_t)eInstance)) {
    return;    // guard is running
  }
  wdog_enable ((wdog_num_t)eInstance);
  wdog_api_guard_toggle(eInstance); // write cookie sequence watchdog 0 (Guardian).
  //GuardToggle();      
}


//=============================================================================
// Disable Guardian (initialize watchdog 0 ).
//=============================================================================
void wdog_api_guard_disable(wdog_api_guard_instance_t eInstance)
{
  wdog_disable ((wdog_num_t)eInstance); // GUARD disable
  while (wdog_is_running ((wdog_num_t)eInstance));
}


/* ############################################################################ */
/* ############################################################################ */
/* ############################################################################ */
/* ############################################################################ */
/* ############################################################################ */





/* ############################################################################ */
static uint8_t wdog_api_wdog_name2instance(wdog_api_wdog_instance_t eInstance) {
  switch(eInstance) {
  case WDOG_API_WDOG0:
    return(0);
  case WDOG_API_WDOG1:
    return(1);
  default:
    fatal("Wrong parameter");
  }
  return(0);
}


//=============================================================================
//
//=============================================================================
void wdog_api_wdog_toggle(wdog_api_wdog_instance_t eInstance)
{
  
  uint16_t  i;
  uint8_t   uCookie;
  uint8_t   uInstanceIndex = wdog_api_wdog_name2instance(eInstance);
  
  
  WdogApiParameters_t tParameters = WdogParameters_t[uInstanceIndex];
  
  uCookie = tParameters.cuCookie;
  
  
  // write cookie sequence watchdog 1
  for (i = 0; i < tParameters.nuSeqLen; i++) {
    wdog_set_magic_cookie (WDOG0, uCookie);
    uCookie = wdog_calc_next_cookie (uCookie);
  }
}


//=============================================================================
// Enable Watchdog 1
// It will set a time of 4 s and a sequence length of ...
//=============================================================================
void wdog_api_wdog_enable(wdog_api_wdog_instance_t eInstance)
{
  uint8_t   uCookie;
  uint8_t   uInstanceIndex;
  uint32_t  dwuWdogClk;
  
  wdog_api_guard_instance_t eGuardInstance;
  clkpno_t eWdogClkPno;
  
  switch(eInstance) {
  case WDOG_API_WDOG0:
    eGuardInstance = WDOG_API_GUARD0;
    eWdogClkPno = CLKPNO_WDOG0;
    uInstanceIndex = 0;
    break;
    
  case WDOG_API_WDOG1:
    eGuardInstance = WDOG_API_GUARD1;
    eWdogClkPno = CLKPNO_WDOG1;
    uInstanceIndex = 1;
    break;
  
  default:
    fatal("Wrong parameter!");
  }
  

  if(clk_nres_api_get_module_clock(eWdogClkPno, &dwuWdogClk)!=eError_none) {
    fatal("No correct clock freq. value get for WDOGx");
    while(1);
  }


  WdogApiParameters_t tParameters = WdogParameters_t[uInstanceIndex];
  
  uCookie = tParameters.cuCookie;

  
  
  wdog_api_guard_enable(eGuardInstance); // GUARD enable

  wdog_init ((wdog_num_t)eInstance, uCookie, tParameters.nuSeqLen, tParameters.dwuTimeout * dwuWdogClk);
  if (wdog_is_running ((wdog_num_t)eInstance)) {
    //error ("WDOG0 should not be working!\n");
  }

  wdog_enable ((wdog_num_t)eInstance);

  wdog_api_wdog_toggle(eInstance); // write cookie sequence
  

  wdog_api_guard_disable(eGuardInstance); // GUARD disable

}

