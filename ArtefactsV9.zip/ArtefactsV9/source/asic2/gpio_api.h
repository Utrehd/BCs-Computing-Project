/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         gpio_api.h
*
* @brief        General Purpose Input/Output API functions
*
* @author       Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __GPIO_API__
#define __GPIO_API__

#include "ASIC2_pinout.h"
#include "errors_api.h"

/**
 * \defgroup gpio_api ASIC2 General Purpose Input/Output API functions
 * 
 * \ingroup  gpio   asic2_api
 *
 * \brief    API function to control GPIO.
 *
 *              Filter Hardware Layout for GPIO
 *                          +---------+
 *                         | f0_rate |
 *                         +---------+
 *                               ||
 *                               +-----------------------------------+
 *                               v                   v               |
 *                                                                   |
 *     +------+                +----------+    +----------+          |
 *     | pad  +--------------> |Flip+flop +--> |Flip+flop +---+      |
 *     |      |         |      |          |    |          |   |      |
 *     +------+         |      +----------+    +----------+   |      |
 *                      |           |                |        |      |
 *                      +-------+   |    +-----------+        |      v
 *                      |       v   v    v                    |
 *                      |                                     |  +---------+
 *                      |      +----------+                   |  | f1_rate |
 *                      |      |COMPARE   |                   |  +---------+
 *                      |      |          |                   |        ||
 *                      |      +----------+                   |        +-------------------+
 *                      |            |                        |        v                   v
 *                      |            |                        |
 *                      |            |                        |      +----------+    +----------+
 *                      |            |                        +----> |Flip+flop +--> |Flip+flop |
 *                      |            |                        |      |          |    |          |
 *                      |            |                        |      +----------+    +----------+
 *                      |            |                        |           |                |
 *                      |            |                        +-------+   |    +-----------+
 *                      |            |                                v   v    v
 *                      |            |
 *                      |            |                               +----------+
 *                      |            |                               |COMPARE   |
 *                      |            |                               |          |
 *                      |            |                               +----------+
 *                      |            |                                    |
 *                      |            |                                    |
 *                      |            |                                    |
 *                      |            |                                    +-------------->  Gx_F1
 *                      |            |
 *                      |            +--------------------------------------------------->  Gx_F0
 *                      |
 *                      +---------------------------------------------------------------->  Gx_RESYN
 *
 */

/**@{*/ 

/* ############################################################################ */
/**
 * \brief Enumeration which describes the configuration of the pin: input or output
 *
 * \ingroup gpio_api 
 */
typedef enum {
  eInput,
  eOutput
} gpio_api_pin_conf_e;

/* ############################################################################ */
/**
 * \brief Enumeration which describes the level of the output
 *
 * \ingroup gpio_api 
 */
typedef enum {
  eLow,
  eHigh
} gpio_api_pin_level_e;

/* ############################################################################ */
/**
 * \brief Enumeration which describes the level of the output
 *
 * \ingroup gpio_api 
 */
typedef enum {
  eFilter_none,
  eFilter_f0,
  eFilter_f1
} gpio_api_filter_en_e;

/* ############################################################################ */
/* ############################ INTERRUPT CONFIGURATION ####################### */
/* ############################################################################ */

/* ############################################################################ */
/**
 * \brief  Check if the selected pinout has interrupt capability
 *         This function check if the desired pinout has interrupt capability
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 * \param irq Pointer to the interrupt number request corresponding to the selected pinout
 * \return Error code
 */
errors_api_code_e gpio_api_pinout_interrupt_capability( device_pinout gpio_pinout, gpio_irq_t * irq );

/* ############################################################################ */
/**
 * \brief  Enable interrupt of a concrete pin
 *         This function enable the interrupt of the desired pin
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 * \return Error code
 */
errors_api_code_e gpio_api_enable_irq( device_pinout gpio_pinout );

/* ############################################################################ */
/**
 * \brief  Disable interrupt of a concrete pin
 *         This function disable the interrupt of the desired pin
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 * \return Error code
 */
errors_api_code_e gpio_api_disable_irq( device_pinout gpio_pinout );

/* ############################################################################ */
/**
 * \brief  Set the interrupt source
 *         This function set the interrupt source to a concrete pin
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 * \param source Source
 */
void gpio_api_set_irq_source(device_pinout gpio_pinout, gpio_src_sel_t source);

/* ############################################################################ */
/**
 * \brief  Set the interrupt type
 *         This function set the interrupt type to a concrete pin
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 * \param type Interrupt type
 * \return Error code
 */
errors_api_code_e gpio_api_set_irq_type(device_pinout gpio_pinout, gpio_irq_type_t type);

/* ############################################################################ */
/**
 * \brief  Set the callback function for gpio
 *         The function written as a parameter will be call when a gpio interrupt occurs. 
 *         
 *         Example:
 *
 *              gpio_api_callback( function_example );
 *
 * \ingroup gpio_api 
 *
 * \param ptr_callback_irq Function to be call
 */
void gpio_api_callback( void (*ptr_callback_irq)(void) );

/* ############################################################################ */
/* ########################### PINOUT I/O CONFIGURATION ####################### */
/* ############################################################################ */

/* ############################################################################ */
/**
 * \brief  Set the output value of a pin
 *         This function set the desired output value of a pin
 *
 *         Example of how to set the pin value:
 *
 *         The declaration of the desired pin
 *              device_pinout pin_test = IOMUX_PAD10_STRUCT;
 *         The pin is set as an output
 *              gpio_api_pin_mode(pin_test, eOutput);
 *         The output value is high level
 *              gpio_api_digital_output(pin_test, eHigh);
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 * \param gpio_level Low level: eLow <br> High level: eHigh
 * \return Error code
 */
errors_api_code_e gpio_api_digital_output(device_pinout gpio_pinout, gpio_api_pin_level_e gpio_level);

/* ############################################################################ */
/**
 * \brief  Set the pin as an input or output
 *         This function set the desired pin as an input or output
 *
 *         Example of how to configure the gpio pin:
 *
 *         The declaration of the desired pin
 *              device_pinout pin_test = IOMUX_PAD10_STRUCT;
 *         The pin is set as in input or output (input in the example)
 *              gpio_api_pin_mode(pin_test, eInput);
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 * \param gpio_conf Input or output
 * \return Error code
 */
errors_api_code_e gpio_api_pin_mode(device_pinout gpio_pinout, gpio_api_pin_conf_e gpio_conf);

/* ############################################################################ */
/**
 * \brief  Get the input value from a concrete pin
 *         This function get the vale from a desired input pin. The value can be read from either of the two filters (f0 or f1) or without filtering
 *
 *         Example of how to get the value of a pin:
 *
 *         The declaration of the desired pin
 *              device_pinout pin_test = IOMUX_PAD10_STRUCT;
 *         The pin is set as in input
 *              gpio_api_pin_mode(pin_test, eInput);
 *         Get the value
 *              bool * input_value;
 *              gpio_api_digital_input(pin_test, eFilter_none, input_value);
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 * \param gpio_filter eFilter_none, eFilter_f0 or eFilter_f1
 * \param gpio_input_status Pointer to the value: <br> true: input 1 <br> false: input 0
 * \return Error code
 */
errors_api_code_e gpio_api_digital_input(device_pinout gpio_pinout, gpio_api_filter_en_e gpio_filter, bool * gpio_input_status);


/* ############################################################################ */
/**
 * \brief  Get the input value from a pin which is specified
 *
 *         Example of how to get the value of a pin:
 *
 *         The declaration of the desired pin
 *              device_pinout pin_test = IOMUX_PAD10_STRUCT;
 *         The pin is set as in input
 *              gpio_api_pin_mode(pin_test, eInput);
 *         Get the value
 *              
 *              data.bf.bit0 = gpio_api_bit_get(pin_test, eFilter_none);
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 * 
 * \param gpio_filter eFilter_none, eFilter_f0 or eFilter_f1
 */
uint8_t gpio_api_bit_get (device_pinout gpio_pinout, gpio_api_filter_en_e gpio_filter);


/* ############################################################################ */
/**
 * \brief  Toogle with specific pad
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin
 */
void gpio_api_toogle_digital_output(device_pinout gpio_pinout);

/* ############################################################################ */
/* ############################### FILTER FUNCTIONS ########################### */
/* ############################################################################ */

/* ############################################################################ */
/**
 * \brief  Get if the filter is enable or not for a specific pin
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired pin to be checked
 * \return true: filter enable <br> false: filter disable
 */
bool gpio_api_get_enable_filter(device_pinout gpio_pinout);

/* ############################################################################ */
/**
 * \brief  Set the filter f0 for GPIO in filter time
 *         This function enables and configures the filter f0 for the pin 
 *         selected.
 *
 *         CAUTION: The filter value is linked with the whole pin group. 
 *         Two pins inside the same group cannot have different filter values.
 *
 *         Example of how to configure the f0 filter:
 *
 *         The declaration of the desired pin
 *                  device_pinout pin_test = IOMUX_PAD10_STRUCT;
 *         If it is wanted to filter 6 us spikes
 *                  gpio_api_set_filter_f0_time(pin_test, 6);
 *
 *         Formula: f0_rate = (3 * f0_cfg) / f_gpio
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired input pin
 * \param filter_time The filter period [micro seconds]
 * \return Error code
 */
errors_api_code_e gpio_api_set_sampler_f0_time(
  device_pinout gpio_pinout, uint16_t filter_time);

/* ############################################################################ */
/**
 * \brief  Set the filter f1 for GPIO in filter time
 *         This function enables and configures the filter f1 for the pin 
 *         selected.
 *
 *         CAUTION: The filter value is linked with the whole pin group. 
 *         Two pins inside the same group cannot have different filter values.
 *
 *         Example of how to configure the f1 filter:
 *
 *         The declaration of the desired pin
 *                  device_pinout pin_test = IOMUX_PAD10_STRUCT;
 *         If it is wanted to filter 10 ms spikes
 *                  gpio_api_set_filter_f1_time(pin_test, 10);
 * 
 *         Formula: f1_rate = (3 * f0_cfg * f1_cfg) / f_gpio
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired input pin
 * \param filter_time The filter period [micro seconds]
 * \return Error code
 */
errors_api_code_e gpio_api_set_sampler_f1_time(
  device_pinout gpio_pinout, uint16_t filter_time);

/* ############################################################################ */
/**
 * \brief  Set the filter f1 for GPIO in filter time
 *         This function enables and configures the filter f1 for the pin 
 *         selected based on the current period of f0, so that the total result
 *         of f0 and f1 together equal the given filter_time.
 *
 *         CAUTION: T
 *         1. The filter value is linked with the whole pin group. 
 *         Two pins inside the same group cannot have different filter values.
 *         2. The filter f1 is based on f0 in following manner: 
 *         "f1 = filterTime / f0". Thus filter_time equals the product of both. 
 *          
 * 
 *         Example of how to configure the f1 filter:
 *
 *         The declaration of the desired pin
 *                  device_pinout pin_test = IOMUX_PAD10_STRUCT;
 *         If it is wanted to filter 10 mqs spikes and f0 is set for 1 ms.
 *                  gpio_api_set_filter_f1_time(pin_test, 10);
 *
 *         Formula: f1_rate = (3 * f0_cfg * f1_cfg) / f_gpio
 *         
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired input pin
 * \param filter_time The total filter period of f0 * f1 [micro seconds]
 * \return Error code
 */
errors_api_code_e gpio_api_set_sampler_f1_time_based_on_f0(
  device_pinout gpio_pinout, uint16_t filter_time);

/* ############################################################################ */
/**
 * \brief  Set the filter f0 for GPIO in period cycles
 *         This function enables and configures the filter f0 for the pin selected
 *
 *         Example of how to configure the f0 filter:
 *
 *         First it is needed to know the period in cycles. If it is wanted to filter 6 us spikes
 *                  uint16_t period_f0 = gpio_api_calculate_f0(6, eMicro_seconds);
 *         The declaration of the desired pin
 *                  device_pinout pin_test = IOMUX_PAD10_STRUCT;
 *         It will be the pin corresponding with the IO MUX PAD 10
 *         Then, the period value and the pin can be used to set the filter
 *                  gpio_api_set_filter_f0_period(pin_test, period_f0);
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired input pin
 * \param period Period of the f0 filter in cycles 
 */
void gpio_api_set_filter_f0_period(device_pinout gpio_pinout, uint16_t period);

/* ############################################################################ */
/**
 * \brief  Set the filter f1 for GPIO in period cycles
 *         This function enables and configures the filter f1 for the pin selected
 *
 *         Example of how to configure the f1 filter:
 *
 *         First it is needed to know the period in cycles. If it is wanted to filter 10 ms spikes (filter f0 must be enabled)
 *                  uint16_t period_f1 = gpio_api_calculate_f1(6, eMicro_seconds, period_f0);
 *         The declaration of the desired pin
 *                  device_pinout pin_test = IOMUX_PAD10_STRUCT;
 *         It will be the pin corresponding with the IO MUX PAD 10
 *         Then, the period value and the pin can be used to set the filter
 *                  gpio_api_set_filter_f1_period(pin_test, period_f1);
 *
 * \ingroup gpio_api 
 *
 * \param gpio_pinout Desired input pin
 * \param period Period of the f1 filter in cycles 
 */
void gpio_api_set_filter_f1_period(device_pinout gpio_pinout, uint16_t period);

/* ############################################################################ */
/**
 * \brief  Calculate gpio f0 filter value
 *         This function returns a pointer with
 *         the value of the proper f0 filter value for a desire filtering time.
 *
 *         Example: If it is needed to filter 6 us spikes
 *                  gpio_api_calculate_f0(6, &filter_value);
 *                  The value returned in filter_value is the value for f0filter
 *
 * -> Formula:
 *
 *            Fgpio * f0_rate
 *  f0_cfg = -----------------
 *                  3
 *
 * \ingroup gpio_api 
 *
 * \param filter_time Filtering time in micro seconds
 * \param Pointer to the correct f0 filter value
 * \return Error code
 */
errors_api_code_e gpio_api_calculate_f0(uint16_t filter_time, uint16_t *f0_cfg);

/* ############################################################################ */
/**
 * \brief  Calculate gpio f1 filter value
 *         This function returns a pointer with the value of the proper 
 *         f1 filter value for a desire filtering time.
 *
 *         Example: 
 *         If it is needed to filter 10 us spikes. 
 *         The third parameter is the f0 filter value.
 *         gpio_api_calculate_f1(10, f0_cfg, &filter_value);
 *         The value returned in filter_value is the value for f1 filter
 *
 * -> Formula:
 *
 *            Fgpio * f1_rate
 *  f1_cfg = -----------------
 *              3 * f0_cfg
 *
 * \ingroup gpio_api 
 *
 * \param filter_time Filtering time
 * \param f0_cfg f0 filter value
 * \param Pointer to the correct f1 filter value
 * \return Error code
 */
errors_api_code_e gpio_api_calculate_f1_based_on_f0(
  uint16_t filter_time, uint16_t f0_cfg, uint16_t * f1_cfg);

/* ############################################################################ */
/**
 * \brief  Calculate gpio f1 filter value
 *         This function returns a pointer with the value of the proper f1 
 *         filter value for a desire filtering time.
 *
 *         Example: 
 *         If it is needed to filter 10 ms spikes. 
 *         The third parameter is the f0 filter value.
 *         gpio_api_calculate_f1(10, eMili_seconds, f0_cfg, &filter_value);
 *         The value returned in filter_value is the value for f1 filter
 *
 * -> Formula:
 *
 *            Fgpio * f1_rate
 *  f1_cfg = -----------------
 *              3 * f0_cfg
 *
 * \ingroup gpio_api 
 *
 * \param filter_time Filtering time
 * \param Pointer to the correct f1 filter value
 * \return Error code
 */
errors_api_code_e gpio_api_calculate_f1(
  uint16_t filter_time, uint16_t * f1_cfg);

/**@}*/ 
#endif
