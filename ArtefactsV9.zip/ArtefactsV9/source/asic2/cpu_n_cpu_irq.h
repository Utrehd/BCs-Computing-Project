/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         cpu_n_cpu_irq.h
*
* @brief        CPU_N_CPU HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CPU_N_CPU_IRQ_H__
#define __CPU_N_CPU_IRQ_H__

#define CPU_N_CPU_NUM_IRQS 32

/**
  * \brief This is an enum class for CPU_N_CPU describing IRQ events
  *
  * \ingroup cpu_n_cpu
  */ 
typedef enum{
  CPU_N_CPU_IRQ_IRQ_FLAGS_0 =           0, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_1 =           1, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_2 =           2, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_3 =           3, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_4 =           4, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_5 =           5, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_6 =           6, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_7 =           7, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_8 =           8, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_9 =           9, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_10 =          10, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_11 =          11, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_12 =          12, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_13 =          13, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_14 =          14, ///< 1: irq pending
  CPU_N_CPU_IRQ_IRQ_FLAGS_15 =          15, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_0 =          16, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_1 =          17, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_2 =          18, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_3 =          19, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_4 =          20, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_5 =          21, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_6 =          22, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_7 =          23, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_8 =          24, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_9 =          25, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_10 =         26, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_11 =         27, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_12 =         28, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_13 =         29, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_14 =         30, ///< 1: irq pending
  CPU_N_CPU_IRQ_TS_FLAGS_N_15 =         31 ///< 1: irq pending
} cpu_n_cpu_irq_t;

#endif
