/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swtimer_irq.h
*
* @brief        Software Timers (SWTIMER) HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __SWTIMER_IRQ_H__
#define __SWTIMER_IRQ_H__

#define SWTIMER_NUM_IRQS 8


/* ############################################################################ */
/**
 * \brief This is an enum class for SWTIMER describing IRQ events
 *
 * \ingroup swtimer 
 */ 
typedef enum{
  /**
   * Counter 0 has been zero
   */ 
  SWTIMER_IRQ_EVT_CNT_ZERO_0 =          0,
  /**
   * Counter 1 has been zero
   */ 
  SWTIMER_IRQ_EVT_CNT_ZERO_1 =          1,
  /**
   * Counter 2 has been zero
   */ 
  SWTIMER_IRQ_EVT_CNT_ZERO_2 =          2,
  /**
   * Counter 3 has been zero
   */ 
  SWTIMER_IRQ_EVT_CNT_ZERO_3 =          3,
  /**
   * Predivider 0 has been zero
   */ 
  SWTIMER_IRQ_EVT_DIV_ZERO_0 =          4,
  /**
   * Predivider 1 has been zero
   */ 
  SWTIMER_IRQ_EVT_DIV_ZERO_1 =          5,
  /**
   * Predivider 2 has been zero
   */ 
  SWTIMER_IRQ_EVT_DIV_ZERO_2 =          6,
  /**
   * Predivider 3 has been zero
   */ 
  SWTIMER_IRQ_EVT_DIV_ZERO_3 =          7
} swtimer_irq_t;

#endif
