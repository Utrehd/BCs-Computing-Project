/* FPGA Release: 10512 */
#include "usi.h"
#include "usi_bf.h"
#include "sram.h"
#include "stdio.h"

static uint8_t revents[NUMBER_USI];

//=======================================================================
// config (set at any time)
//=======================================================================
void usi_enable(usi_num_t usi_no, bool enable){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.en = enable;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_cfg_br_inc(usi_num_t usi_no, uint16_t br_inc){
  WRITE_REG_16(usi_no + ADDR_USI_BR_INC, br_inc);
}

void usi_tx_enable(usi_num_t usi_no, bool enable){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.tx_en = enable;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_rx_enable(usi_num_t usi_no, bool enable){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.rx_en = enable;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_spi_cfg_tx_dma_mode(usi_num_t usi_no, bool mode){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.dma_tx_mode = mode;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_spi_cfg_rx_dma_mode(usi_num_t usi_no, bool mode){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.dma_rx_mode = mode;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

uint16_t usi_get_cfg_br_inc(usi_num_t usi_no){
  return READ_REG_U16(usi_no + ADDR_USI_BR_INC);
}

//=======================================================================
// Bit Rate Extraction
//=======================================================================

void usi_set_bre_mode(usi_num_t usi_no, usi_bre_mode_t mode){
  WRITE_REG_16(usi_no + ADDR_USI_CFG_BRE, (uint16_t) mode);
}
  
uint32_t usi_get_bre_res(usi_num_t usi_no){
  uint32_t res = 0;
  res = READ_REG_U16(usi_no + ADDR_USI_BRE_RES_HW);
  res <<= 16;
  res |= READ_REG_U16(usi_no + ADDR_USI_BRE_RES_LW);
  return res;
}

//=======================================================================
// config (locked by enable)
//=======================================================================
void usi_cfg_mode(usi_num_t usi_no, bool mode){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.mode = mode;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_cfg_sdi_sdo_swap(usi_num_t usi_no, bool sdi_sdo_swap){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.sdi_sdo_swap = sdi_sdo_swap;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_cfg_sdi_sdo_loopback(usi_num_t usi_no, bool sdi_sdo_loopback){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.sdi_sdo_loopback = sdi_sdo_loopback;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_cfg_sdi_uses_sdo_i(usi_num_t usi_no, bool sdi_uses_sdo_i){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.sdi_uses_sdo_i = sdi_uses_sdo_i;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_cfg_sdo_inv(usi_num_t usi_no, bool sdo_inv){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.sdo_inv = sdo_inv;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_cfg_sdi_inv(usi_num_t usi_no, bool sdi_inv){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.sdi_inv = sdi_inv;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_cfg_nss_inv(usi_num_t usi_no, bool nss_inv){
  usi_cfg_t usi_cfg;
  usi_cfg.val = READ_REG_U16(usi_no + ADDR_USI_CFG);
  usi_cfg.bf.nss_inv = nss_inv;
  WRITE_REG_16(usi_no + ADDR_USI_CFG, usi_cfg.val);
}

void usi_cfg_br_mod(usi_num_t usi_no, uint16_t br_mod){
  WRITE_REG_16(usi_no + ADDR_USI_BR_MOD, br_mod);
}

void usi_cfg_tick_bit_length(usi_num_t usi_no, uint16_t tick_bit_length){
  WRITE_REG_16(usi_no + ADDR_USI_TICK, tick_bit_length);
}

void usi_cfg_intf(usi_num_t usi_no, uint16_t intf){
  WRITE_REG_16(usi_no + ADDR_USI_CFG_INTF, intf);
}

//=======================================================================
// DMA TX
//=======================================================================
void usi_dma_set_tadr_new(usi_num_t usi_no, uint16_t tadr_new){
  WRITE_REG_16(usi_no + ADDR_USI_TADR_NEW, tadr_new);
}

uint32_t usi_dma_get_tadr_current(usi_num_t usi_no){
  return (uint32_t) BASE_ADDR_SRAM + READ_REG_U16(usi_no + ADDR_USI_TADR_CURRENT);
}

uint16_t usi_dma_get_tdlen_current(usi_num_t usi_no){
  return READ_REG_U16(usi_no + ADDR_USI_TDLEN);
}

uint32_t usi_dma_get_tadr_done(usi_num_t usi_no){
  return (uint32_t) BASE_ADDR_SRAM + READ_REG_U16(usi_no + ADDR_USI_TADR_DONE);
}

void usi_dma_clear_tadr_new(usi_num_t usi_no){
  WRITE_REG_16(usi_no + ADDR_USI_DMA_CMD, 2);
}

void usi_dma_skip_tadr_current(usi_num_t usi_no){
  WRITE_REG_16(usi_no + ADDR_USI_DMA_CMD, 1);  
}

//=======================================================================
// DMA RX
//=======================================================================
void usi_dma_cfg_rx_timeout(usi_num_t usi_no, uint32_t rx_timeout){
  WRITE_REG_16(usi_no + ADDR_USI_CFG_RX_TIMEOUT_LW, rx_timeout);
  rx_timeout  >>= 16;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_RX_TIMEOUT_HW, rx_timeout);
}

void usi_dma_set_radr_new(usi_num_t usi_no, uint16_t radr_new){
  WRITE_REG_16(usi_no + ADDR_USI_RADR_NEW, radr_new);
}

uint32_t usi_dma_get_radr_current(usi_num_t usi_no){
  return (uint32_t) BASE_ADDR_SRAM + READ_REG_U16(usi_no + ADDR_USI_RADR_CURRENT);
}

uint16_t usi_dma_get_rdlen_current(usi_num_t usi_no){
  return READ_REG_U16(usi_no + ADDR_USI_RDLEN);
}

uint32_t usi_dma_get_radr_done(usi_num_t usi_no){
  return (uint32_t) BASE_ADDR_SRAM + READ_REG_U16(usi_no + ADDR_USI_RADR_DONE);
}

void usi_dma_clear_radr_new(usi_num_t usi_no){
  WRITE_REG_16(usi_no + ADDR_USI_DMA_CMD, 8);
}

void usi_dma_skip_radr_current(usi_num_t usi_no){
  WRITE_REG_16(usi_no + ADDR_USI_DMA_CMD, 4);
}

//=======================================================================
// DMA sync
//=======================================================================
void usi_dma_cfg_sync(usi_num_t usi_no, bool sync_en, uint8_t sync_delay){
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SYNC, ((((uint16_t)sync_delay) << 1) | sync_en));
}

void usi_dma_set_tadr_new_ws(usi_num_t usi_no, uint16_t tadr_new_ws){
  WRITE_REG_16(usi_no + ADDR_USI_TADR_NEW_WS, tadr_new_ws);
}

void usi_dma_set_radr_new_ws(usi_num_t usi_no, uint16_t radr_new_ws){
  WRITE_REG_16(usi_no + ADDR_USI_RADR_NEW_WS, radr_new_ws);
}

//=======================================================================
// helper wrapper
//=======================================================================
int usi_no_to_index(usi_num_t usi_no){
  if (usi_no == USI1){
    return 1;
  } else {
    return 0;
  }
}

void usi_full_enable(usi_num_t usi_no, bool enable){
  usi_tx_enable(usi_no, enable);
  usi_rx_enable(usi_no, enable);
  usi_enable(usi_no, enable);
}

bool usi_tadr_new_is_nfull(usi_num_t usi_no){
  usi_irq_status_t usi_irq_status = usi_get_irq_status(usi_no);
  return (bool)usi_irq_status.bf.tadr_new_nfull;
}

bool usi_tadr_done_is_nempty(usi_num_t usi_no){
  usi_irq_status_t usi_irq_status = usi_get_irq_status(usi_no);
  return (bool)usi_irq_status.bf.tadr_done_nempty;
}

bool usi_radr_new_is_nfull(usi_num_t usi_no){
  usi_irq_status_t usi_irq_status = usi_get_irq_status(usi_no);
  return (bool)usi_irq_status.bf.radr_new_nfull;
}

bool usi_radr_done_is_nempty(usi_num_t usi_no){
  usi_irq_status_t usi_irq_status = usi_get_irq_status(usi_no);
  return (bool)usi_irq_status.bf.radr_done_nempty;
}

//=======================================================================
// DMA helpers
//=======================================================================

void usi_dma_prepare_txcfg(uint16_t len, void * data, uint16_t tcfg, usi_dma_txcfg_t *usi_dma_txcfg){
  usi_dma_txcfg->tdadr = POINTER_TO_ADDRESS(data);
  usi_dma_txcfg->tcfg  = tcfg;
  usi_dma_txcfg->tdlen = len;
}

void usi_dma_send_frame(usi_num_t usi_no, bool sync, volatile usi_dma_txcfg_t *usi_dma_txcfg ){
  uint16_t usi_dma_txcfg_addr = POINTER_TO_ADDRESS(usi_dma_txcfg);
  if (!sync){
    while(!usi_tadr_new_is_nfull(usi_no));
  }
  usi_dma_get_tadr_done(usi_no);
  if (sync){ 
    usi_dma_set_tadr_new_ws(usi_no, usi_dma_txcfg_addr);
  }else{ 
    usi_dma_set_tadr_new(usi_no, usi_dma_txcfg_addr);  
  }
}

void usi_dma_prepare_rxcfg(uint16_t maxlen, void * data, usi_dma_rxcfg_t *usi_dma_rxcfg){
  usi_dma_rxcfg->rdadr = POINTER_TO_ADDRESS(data);
  usi_dma_rxcfg->maxlen = maxlen;
}

bool usi_dma_provide_rxcfg(usi_num_t usi_no, volatile usi_dma_rxcfg_t *usi_dma_rxcfg, bool sync){
  if (usi_radr_new_is_nfull(usi_no)){
    //uint8_t index = usi_no_to_index(usi_no);
    uint16_t usi_dma_rxcfg_addr = POINTER_TO_ADDRESS(usi_dma_rxcfg);
//printf("-> 0x%X 0x%X \r\n", (uint16_t) usi_dma_rxcfg->rdadr, usi_dma_rxcfg_addr);
    if (sync) {
      usi_dma_set_radr_new_ws(usi_no, usi_dma_rxcfg_addr);
    } else {
      usi_dma_set_radr_new(usi_no, usi_dma_rxcfg_addr);
    }
    return true;
  }
  return false;
}

bool usi_dma_get_rx_data(usi_num_t usi_no, void ** data, uint16_t *rdlen){
  //*revents = 0;
  //*rdlen   = 0;
  if (usi_radr_done_is_nempty(usi_no)){
    usi_dma_rxcfg_t *usi_dma_rxcfg;
    usi_dma_rxcfg = (usi_dma_rxcfg_t*) usi_dma_get_radr_done(usi_no);
    revents[usi_no_to_index(usi_no)] |= usi_dma_rxcfg->revents;
    *data = (void*) ((uint32_t) BASE_ADDR_SRAM + (uint32_t) usi_dma_rxcfg->rdadr);  
    *rdlen = usi_dma_rxcfg->rdlen;
    //printf("<- ptr=0x%0X data=0x%X rdlen=%d\r\n", usi_dma_rxcfg, **data, *rdlen);
    return true;
  }
  return false;
}

uint8_t usi_get_revents(usi_num_t usi_no){
  return revents[usi_no_to_index(usi_no)];
}

void usi_clear_revents(usi_num_t usi_no){
  revents[usi_no_to_index(usi_no)] = 0;
}

//=======================================================================
// IRQ
//=======================================================================
void usi_enable_irq (usi_num_t usi_no, usi_irq_t irq, bool enable) {
  usi_irq_mask_t usi_irq_mask;
  usi_irq_mask = READ_REG_U16(usi_no + ADDR_USI_IRQ_MASK);
  if (enable) {
    usi_irq_mask |= (0x01 << irq);
  }
  else {
    usi_irq_mask &= ~(0x01 << irq);
  }
  WRITE_REG_16(usi_no + ADDR_USI_IRQ_MASK, usi_irq_mask);
}

usi_irq_t usi_get_next_pending_irq (usi_num_t usi_no) {
  return (usi_irq_t) READ_REG_U16(usi_no + ADDR_USI_IRQ_VNO);
}

usi_irq_status_t usi_get_irq_status (usi_num_t usi_no) {
  usi_irq_status_t temp;
  temp.val = READ_REG_U16(usi_no + ADDR_USI_IRQ_STATUS);
  return temp;
}

void usi_clear_irq(usi_num_t usi_no, usi_irq_t irq) {
  WRITE_REG_16(usi_no + ADDR_USI_IRQ_STATUS, (uint16_t) (0x01 << irq));
}

void usi_clear_all_irq(usi_num_t usi_no) {
  WRITE_REG_16(usi_no + ADDR_USI_IRQ_STATUS, 0xFFFF);
}
