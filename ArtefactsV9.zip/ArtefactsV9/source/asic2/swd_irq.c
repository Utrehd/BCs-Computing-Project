/* FPGA Release: 10512 */
#include "swd.h"

void swd_enable_irq (swd_irq_t irq, bool enable) {
  uint32_t addr;
  uint16_t temp;
  if (irq > 31) {
    addr = AADDR_SWD_IRQ_MASK_COMM;
  } else if (irq > 15) {
    addr = AADDR_SWD_IRQ_MASK_DMA;
  } else {
    addr = AADDR_SWD_IRQ_MASK_PE;
  }
  temp = READ_REG_U16(addr);
  if (enable) {
    temp |= (0x01 << (irq & 15));
  }
  else {
    temp &= ~(0x01 << (irq & 15));
  }
  WRITE_REG_16(addr, temp);
}

void swd_clear_irq (swd_irq_t irq) {
  WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_EVENTS, (0x01 << irq));
}

swd_irq_t swd_get_next_pending_irq (void) {
  uint16_t temp;
  temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_IRQ_NO);
  return (swd_irq_t) temp;
}

void swd_get_irq_status (swd_irq_status_t * irq_status) {
  irq_status->all.pe.val    = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_IRQ_STATUS_PE);
  irq_status->all.dma.val   = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_IRQ_STATUS_DMA);
  irq_status->all.comm.val  = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_IRQ_STATUS_COMM);
}

void swd_get_events (swd_events_t * events) {
  events->val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_EVENTS);
}
