/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         aout_ctrl.h
*
* @brief        Aout and Aout Control API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __AOUT_CTRL_API_H__
#define __AOUT_CTRL_API_H__


/**
 * \defgroup aout_ctrl_api ASIC2 Aout and Aout Control API functions
 * 
 * \ingroup  aout_ctrl   asic2_api 
 * 
 * \brief    API Functions to control Aout and Aout Control
 *
 */
/**@{*/ 


/* ############################################################################ */
/**
 * \brief   Function to init DAC
 *
 * \ingroup aout_ctrl_api
 * 
 * \param   dac_sel DAC channel
 *
 * \param   par_cfg DAC parameters, see set_aout_ctrl_cfg()
 * 
 */
void aout_ctrl_api_init(aout_ctrl_dac_sel_t par_dac_sel, aout_ctrl_cfg_t par_cfg);


/* ############################################################################ */
/**
 * \brief   Function to set DAC value
 *
 * \ingroup aout_ctrl_api
 * 
 * \param   dac_sel   channel
 *
 * \param   par_value value in 0.1mV (required 100mV output, use 1000 as parameter)
 */
void aout_ctrl_api_set_value(aout_ctrl_dac_sel_t dac_sel, uint16_t par_value_in_0p1mV);

/* ############################################################################ */
/**
 * \brief   Function to set DAC value in case of sync pulse
 *
 * \ingroup aout_ctrl_api
 * 
 * \param   dac_sel   channel
 *
 * \param   par_value value in 0.1mV (required 100mV output, use 1000 as parameter)
 */
void set_aout_api_ctrl_dac_sync(aout_ctrl_dac_sel_t dac_sel, uint16_t par_value_in_0p1mV);


/**@} */
#endif /* __AOUT_CTRL_API_H__ */
