/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         usi_uart_dma_api_errors.h
*
* @brief        Error handler for USI UART DMA API functions
*
* @author       Dedourek Pavel
*
********************************************************************************
*
********************************************************************************
********************************************************************************
*/

/**
 * \ingroup error_api
 */
#ifndef __USI_UART_DMA_API_ERRORS__
#define __USI_UART_DMA_API_ERRORS__

#define USI_UART_DMA_API_ERRORS_CODES                                          \
  /**                                                                          \
   * USI UART DMA wrong parameters                                             \
   */                                                                          \
  e_error_usi_uart_dma_wrong_instance,                                         \
                                                                               \
  /**                                                                          \
   * USI UART DMA RX FIFO is overloaded                                        \
   */                                                                          \
  e_error_usi_uart_dma_rx_fifo_overloaded,                                     \
                                                                               \
  /**                                                                          \
   * USI UART DMA TX FIFO is overloaded                                        \
   */                                                                          \
  e_error_usi_uart_dma_tx_fifo_overloaded                                     

#endif
 
