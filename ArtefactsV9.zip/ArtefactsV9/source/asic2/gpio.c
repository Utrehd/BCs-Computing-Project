/* FPGA Release: 10512 */
#include "gpio.h"

void gpio_enable_filter (gpio_group_t group, bool enable) {
    gpio_config_t gpio_config;
    gpio_config.val = READ_REG_U16(BASE_ADDR_GPIO);
    switch (group) {
    case GPIO_GROUP_0:
        gpio_config.bf.en0 = enable ? 1 : 0;
        break;
    case GPIO_GROUP_1:
        gpio_config.bf.en1 = enable ? 1 : 0;
        break;
    case GPIO_GROUP_2:
        gpio_config.bf.en2 = enable ? 1 : 0;
        break;
    case GPIO_GROUP_3:
        gpio_config.bf.en3 = enable ? 1 : 0;
        break;
    default:
        break;
    }
    WRITE_REG_16(BASE_ADDR_GPIO, gpio_config.val);
}

void gpio_enable_hwsync (bool enable) {
    gpio_config_t gpio_config;
    gpio_config.val = READ_REG_U16(BASE_ADDR_GPIO);
    gpio_config.bf.sync_en = enable ? 1 : 0;
    WRITE_REG_16(BASE_ADDR_GPIO, gpio_config.val);
}

/* GPIO Command */
void gpio_synchronize (void) {
    WRITE_REG_16(AADDR_GPIO_COMMAND, 0x0001); 
}


/* GPIO Groups */
void gpio_set_f0_period (gpio_group_t group, uint8_t period) {
    // WRITE_REG_16 is used even thou its 8bit only, its out of consitecny with
    // Other functions
    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_F0_CFG, period);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_F0_CFG, period);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_F0_CFG, period);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_F0_CFG, period);
        break;
    default:
        break;
    }
}

uint16_t gpio_get_f0_period (gpio_group_t group) {
    uint16_t period = 0;
    switch (group) {
    case GPIO_GROUP_0:
        period = READ_REG_U16(AADDR_GPIO_G0_F0_CFG);
        break;
    case GPIO_GROUP_1:
        period = READ_REG_U16(AADDR_GPIO_G1_F0_CFG);
        break;
    case GPIO_GROUP_2:
        period = READ_REG_U16(AADDR_GPIO_G2_F0_CFG);
        break;
    case GPIO_GROUP_3:
        period = READ_REG_U16(AADDR_GPIO_G3_F0_CFG);
        break;
    default:
        break;
    }
    return period;
}

void gpio_set_f1_period (gpio_group_t group, uint16_t period) {
    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_F1_CFG, period);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_F1_CFG, period);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_F1_CFG, period);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_F1_CFG, period);
        break;
    default:
        break;
    }
}

uint16_t gpio_get_f1_period (gpio_group_t group) {
    uint16_t period = 0;
    switch (group) {
    case GPIO_GROUP_0:
        period = READ_REG_U16(AADDR_GPIO_G0_F1_CFG);
        break;
    case GPIO_GROUP_1:
        period = READ_REG_U16(AADDR_GPIO_G1_F1_CFG);
        break;
    case GPIO_GROUP_2:
        period = READ_REG_U16(AADDR_GPIO_G2_F1_CFG);
        break;
    case GPIO_GROUP_3:
        period = READ_REG_U16(AADDR_GPIO_G3_F1_CFG);
        break;
    default:
        break;
    }
    return period;
}

void gpio_set_oe (gpio_group_t group, gpio_bits_t bits, bool oe) {
    uint16_t tmp = 0;
    switch (group) {
    case GPIO_GROUP_0:
        tmp = READ_REG_U16(AADDR_GPIO_G0_OE);
        break;
    case GPIO_GROUP_1:
        tmp = READ_REG_U16(AADDR_GPIO_G1_OE);
        break;
    case GPIO_GROUP_2:
        tmp = READ_REG_U16(AADDR_GPIO_G2_OE);
        break;
    case GPIO_GROUP_3:
        tmp = READ_REG_U16(AADDR_GPIO_G3_OE);
        break;
    default:
        break;
    }

    if (oe) {
      tmp |= bits;
    } else {
      tmp &= ~bits;
    }

    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_OE, tmp);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_OE, tmp);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_OE, tmp);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_OE, tmp);
        break;
    default:
        break;
    }
}

void gpio_set_ie (gpio_group_t group, gpio_bits_t bits, bool ie) {
    uint16_t tmp = 0;
    switch (group) {
    case GPIO_GROUP_0:
        tmp = READ_REG_U16(AADDR_GPIO_G0_IE);
        break;
    case GPIO_GROUP_1:
        tmp = READ_REG_U16(AADDR_GPIO_G1_IE);
        break;
    case GPIO_GROUP_2:
        tmp = READ_REG_U16(AADDR_GPIO_G2_IE);
        break;
    case GPIO_GROUP_3:
        tmp = READ_REG_U16(AADDR_GPIO_G3_IE);
        break;
    default:
        break;
    }

    if (ie){
      tmp |= bits;
    } else {
      tmp &= ~bits;
    }

    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_IE, tmp);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_IE, tmp);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_IE, tmp);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_IE, tmp);
        break;
    default:
        break;
    }
}

void gpio_set_out (gpio_group_t group, gpio_bits_t bits, uint16_t data) {
    uint16_t tmp = 0;
    switch (group) {
    case GPIO_GROUP_0:
        tmp = READ_REG_U16(AADDR_GPIO_G0_OUT);
        break;
    case GPIO_GROUP_1:
        tmp = READ_REG_U16(AADDR_GPIO_G1_OUT);
        break;
    case GPIO_GROUP_2:
        tmp = READ_REG_U16(AADDR_GPIO_G2_OUT);
        break;
    case GPIO_GROUP_3:
        tmp = READ_REG_U16(AADDR_GPIO_G3_OUT);
        break;
    default:
        break;
    }

    tmp |= (bits & data);
    tmp &= (~bits | data);

    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_OUT, tmp);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_OUT, tmp);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_OUT, tmp);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_OUT, tmp);
        break;
    default:
        break;
    }
}

void gpio_cmd_out_set (gpio_group_t group, gpio_bits_t bits){
    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_OUT_SET, bits);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_OUT_SET, bits);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_OUT_SET, bits);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_OUT_SET, bits);
        break;
    default:
        break;
    }
}

void gpio_cmd_out_clr (gpio_group_t group, gpio_bits_t bits){
    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_OUT_CLR, bits);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_OUT_CLR, bits);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_OUT_CLR, bits);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_OUT_CLR, bits);
        break;
    default:
        break;
    }
}

void gpio_cmd_out_toggle (gpio_group_t group, gpio_bits_t bits){
    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_OUT_TOGGLE, bits);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_OUT_TOGGLE, bits);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_OUT_TOGGLE, bits);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_OUT_TOGGLE, bits);
        break;
    default:
        break;
    }
}

uint16_t gpio_get_out (gpio_group_t group, gpio_bits_t bits) {
    uint16_t tmp = 0;
    switch (group) {
    case GPIO_GROUP_0:
        tmp = READ_REG_U16(AADDR_GPIO_G0_OUT);
        break;
    case GPIO_GROUP_1:
        tmp = READ_REG_U16(AADDR_GPIO_G1_OUT);
        break;
    case GPIO_GROUP_2:
        tmp = READ_REG_U16(AADDR_GPIO_G2_OUT);
        break;
    case GPIO_GROUP_3:
        tmp = READ_REG_U16(AADDR_GPIO_G3_OUT);
        break;
    default:
        break;
    }
    return (tmp & (uint16_t) bits);
}

uint16_t gpio_get_in (gpio_group_t group, gpio_bits_t bits) {
    uint16_t tmp = 0;
    switch (group) {
    case GPIO_GROUP_0:
        tmp = READ_REG_U16(AADDR_GPIO_G0_RESYN);
        break;
    case GPIO_GROUP_1:
        tmp = READ_REG_U16(AADDR_GPIO_G1_RESYN);
        break;
    case GPIO_GROUP_2:
        tmp = READ_REG_U16(AADDR_GPIO_G2_RESYN);
        break;
    case GPIO_GROUP_3:
        tmp = READ_REG_U16(AADDR_GPIO_G3_RESYN);
        break;
    default:
        break;
    }
    return (tmp & (uint16_t) bits);
}

uint16_t gpio_get_f0 (gpio_group_t group, gpio_bits_t bits) {
    uint16_t tmp = 0;
    switch (group) {
    case GPIO_GROUP_0:
        tmp = READ_REG_U16(AADDR_GPIO_G0_F0);
        break;
    case GPIO_GROUP_1:
        tmp = READ_REG_U16(AADDR_GPIO_G1_F0);
        break;
    case GPIO_GROUP_2:
        tmp = READ_REG_U16(AADDR_GPIO_G2_F0);
        break;
    case GPIO_GROUP_3:
        tmp = READ_REG_U16(AADDR_GPIO_G3_F0);
        break;
    default:
        break;
    }
    return (tmp & (uint16_t) bits);
}

uint16_t gpio_get_f1 (gpio_group_t group, gpio_bits_t bits) {
    uint16_t tmp = 0;
    switch (group) {
    case GPIO_GROUP_0:
        tmp = READ_REG_U16(AADDR_GPIO_G0_F1);
        break;
    case GPIO_GROUP_1:
        tmp = READ_REG_U16(AADDR_GPIO_G1_F1);
        break;
    case GPIO_GROUP_2:
        tmp = READ_REG_U16(AADDR_GPIO_G2_F1);
        break;
    case GPIO_GROUP_3:
        tmp = READ_REG_U16(AADDR_GPIO_G3_F1);
        break;
    default:
        break;
    }

    return (tmp & (uint16_t) bits);
}

void gpio_set_sync (gpio_group_t group, gpio_bits_t bits, uint16_t data) {
    uint16_t tmp = 0;
    switch (group) {
    case GPIO_GROUP_0:
        tmp = READ_REG_U16(AADDR_GPIO_G0_SYNC);
        break;
    case GPIO_GROUP_1:
        tmp = READ_REG_U16(AADDR_GPIO_G1_SYNC);
        break;
    case GPIO_GROUP_2:
        tmp = READ_REG_U16(AADDR_GPIO_G2_SYNC);
        break;
    case GPIO_GROUP_3:
        tmp = READ_REG_U16(AADDR_GPIO_G3_SYNC);
        break;
    default:
        break;
    }
    tmp |= (bits & data);
    tmp &= (~bits | data);
    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_SYNC, tmp);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_SYNC, tmp);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_SYNC, tmp);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_SYNC, tmp);
        break;
    default:
        break;
    }
}


uint16_t
gpio_get_sync (gpio_group_t group, gpio_bits_t bits)
{
    uint16_t tmp = 0;
    switch (group) {
    case GPIO_GROUP_0:
        tmp = READ_REG_U16(AADDR_GPIO_G0_SYNC);
        break;
    case GPIO_GROUP_1:
        tmp = READ_REG_U16(AADDR_GPIO_G1_SYNC);
        break;
    case GPIO_GROUP_2:
        tmp = READ_REG_U16(AADDR_GPIO_G2_SYNC);
        break;
    case GPIO_GROUP_3:
        tmp = READ_REG_U16(AADDR_GPIO_G3_SYNC);
        break;
    default:
        break;
    }

    return (tmp & (uint16_t) bits);
}


void
gpio_set_sync_source (gpio_group_t group, gpio_src_sel_t source)
{
    switch (group) {
    case GPIO_GROUP_0:
        WRITE_REG_16(AADDR_GPIO_G0_SYNC_SEL, (uint16_t) source);
        break;
    case GPIO_GROUP_1:
        WRITE_REG_16(AADDR_GPIO_G1_SYNC_SEL, (uint16_t) source);
        break;
    case GPIO_GROUP_2:
        WRITE_REG_16(AADDR_GPIO_G2_SYNC_SEL, (uint16_t) source);
        break;
    case GPIO_GROUP_3:
        WRITE_REG_16(AADDR_GPIO_G3_SYNC_SEL, (uint16_t) source);
        break;
    default:
        break;
    }
}


gpio_src_sel_t
gpio_get_sync_source (gpio_group_t group)
{
    uint16_t sync_source = 0;
    switch (group) {
    case GPIO_GROUP_0:
        sync_source = READ_REG_U16(AADDR_GPIO_G0_SYNC_SEL);
        break;
    case GPIO_GROUP_1:
        sync_source = READ_REG_U16(AADDR_GPIO_G1_SYNC_SEL);
        break;
    case GPIO_GROUP_2:
        sync_source = READ_REG_U16(AADDR_GPIO_G2_SYNC_SEL);
        break;
    case GPIO_GROUP_3:
        sync_source = READ_REG_U16(AADDR_GPIO_G3_SYNC_SEL);
        break;
    default:
        break;
    }

    return (gpio_src_sel_t) (sync_source);
}

// config GPIO NMI
void gpio_config_nmi(gpio_group_t group, uint8_t pin, bool ccpu0_nmi_enable, bool acpu1_nmi_enable){
  gpio_config_nmi_t gpio_config_nmi;
  gpio_config_nmi.val = 0;
  gpio_config_nmi.bf.nmi_group        = group;
  gpio_config_nmi.bf.nmi_pin          = pin;
  gpio_config_nmi.bf.ccpu0_nmi_enable = ccpu0_nmi_enable;
  gpio_config_nmi.bf.acpu1_nmi_enable = acpu1_nmi_enable;
  WRITE_REG_16(AADDR_GPIO_CONFIG_NMI, gpio_config_nmi.val);
}

void
gpio_set_irq_source (gpio_group_t group, gpio_src_sel_t source)
{
    gpio_config_t gpio_config;
    gpio_config.val = READ_REG_U16(BASE_ADDR_GPIO);
    switch (group) {
    case GPIO_GROUP_0:
        gpio_config.bf.irq_sel0 = source;
        break;
    case GPIO_GROUP_1:
        gpio_config.bf.irq_sel1 = source;
        break;
    case GPIO_GROUP_2:
        gpio_config.bf.irq_sel2 = source;
        break;
    case GPIO_GROUP_3:
        gpio_config.bf.irq_sel3 = source;
        break;
    }
    WRITE_REG_16(BASE_ADDR_GPIO, gpio_config.val);
}


void
gpio_set_irq_type (gpio_irq_t irq, gpio_irq_type_t type)
{
    gpio_irq_cfg0_t irq_cfg;

    switch (irq) {
    case GPIO_IRQ_EVT_G0_PIN1:
    case GPIO_IRQ_EVT_G0_PIN2:
    case GPIO_IRQ_EVT_G0_PIN3:
    case GPIO_IRQ_EVT_G0_PIN4:
        irq_cfg.val = READ_REG_U16(AADDR_GPIO_IRQ_CFG0);
        break;
    case GPIO_IRQ_EVT_G1_PIN1:
    case GPIO_IRQ_EVT_G1_PIN6:
    case GPIO_IRQ_EVT_G1_PIN7:
    case GPIO_IRQ_EVT_G1_PIN8:
        irq_cfg.val = READ_REG_U16(AADDR_GPIO_IRQ_CFG1);
        break;
    case GPIO_IRQ_EVT_G2_PIN2:
    case GPIO_IRQ_EVT_G2_PIN3:
    case GPIO_IRQ_EVT_G2_PIN7:
    case GPIO_IRQ_EVT_G2_PIN8:
        irq_cfg.val = READ_REG_U16(AADDR_GPIO_IRQ_CFG2);
        break;
    case GPIO_IRQ_EVT_G3_PIN3:
    case GPIO_IRQ_EVT_G3_PIN4:
    case GPIO_IRQ_EVT_G3_PIN5:
    case GPIO_IRQ_EVT_G3_PIN6:
        irq_cfg.val = READ_REG_U16(AADDR_GPIO_IRQ_CFG3);
        break;
    }

    switch (irq) {
    case GPIO_IRQ_EVT_G0_PIN1:
    case GPIO_IRQ_EVT_G1_PIN1:
    case GPIO_IRQ_EVT_G2_PIN2:
    case GPIO_IRQ_EVT_G3_PIN3:
        irq_cfg.bf.g0_irq0 = type;
        break;
    case GPIO_IRQ_EVT_G0_PIN2:
    case GPIO_IRQ_EVT_G1_PIN6:
    case GPIO_IRQ_EVT_G2_PIN3:
    case GPIO_IRQ_EVT_G3_PIN4:
        irq_cfg.bf.g0_irq1 = type;
        break;
    case GPIO_IRQ_EVT_G0_PIN3:
    case GPIO_IRQ_EVT_G1_PIN7:
    case GPIO_IRQ_EVT_G2_PIN7:
    case GPIO_IRQ_EVT_G3_PIN5:
        irq_cfg.bf.g0_irq2 = type;
        break;
    case GPIO_IRQ_EVT_G0_PIN4:
    case GPIO_IRQ_EVT_G1_PIN8:
    case GPIO_IRQ_EVT_G2_PIN8:
    case GPIO_IRQ_EVT_G3_PIN6:
        irq_cfg.bf.g0_irq3 = type;
        break;
    default:
        break;
    }

    switch (irq) {
    case GPIO_IRQ_EVT_G0_PIN1:
    case GPIO_IRQ_EVT_G0_PIN2:
    case GPIO_IRQ_EVT_G0_PIN3:
    case GPIO_IRQ_EVT_G0_PIN4:
        WRITE_REG_16(AADDR_GPIO_IRQ_CFG0, irq_cfg.val);
        break;
    case GPIO_IRQ_EVT_G1_PIN1:
    case GPIO_IRQ_EVT_G1_PIN6:
    case GPIO_IRQ_EVT_G1_PIN7:
    case GPIO_IRQ_EVT_G1_PIN8:
        WRITE_REG_16(AADDR_GPIO_IRQ_CFG1, irq_cfg.val);
        break;
    case GPIO_IRQ_EVT_G2_PIN2:
    case GPIO_IRQ_EVT_G2_PIN3:
    case GPIO_IRQ_EVT_G2_PIN7:
    case GPIO_IRQ_EVT_G2_PIN8:
        WRITE_REG_16(AADDR_GPIO_IRQ_CFG2, irq_cfg.val);
        break;
    case GPIO_IRQ_EVT_G3_PIN3:
    case GPIO_IRQ_EVT_G3_PIN4:
    case GPIO_IRQ_EVT_G3_PIN5:
    case GPIO_IRQ_EVT_G3_PIN6:
        WRITE_REG_16(AADDR_GPIO_IRQ_CFG3, irq_cfg.val);
        break;
    }
}


void
gpio_enable_irq (gpio_irq_t irq, bool enable)
{
    uint16_t irq_mask;
    irq_mask = READ_REG_U16(AADDR_GPIO_IRQ_MASK);
    if (enable) {
        irq_mask |= (0x01 << irq);
    }
    else {
        irq_mask &= ~(0x01 << irq);
    }
    WRITE_REG_16(AADDR_GPIO_IRQ_MASK, irq_mask);
}


void
gpio_venable_irq (gpio_irq_t irq)
{
    WRITE_REG_16(AADDR_GPIO_IRQ_VENABLE, irq);
}


void
gpio_vdisable_irq (gpio_irq_t irq)
{
    WRITE_REG_16(AADDR_GPIO_IRQ_VDISABLE, irq);
}


void
gpio_vclear_irq (gpio_irq_t irq)
{
    WRITE_REG_16(AADDR_GPIO_IRQ_VNO, irq);
}


void
gpio_clear_irq (gpio_irq_t irq)
{
    WRITE_REG_16(AADDR_GPIO_IRQ_STATUS, (uint16_t) (0x01 << irq));
}

void
gpio_clear_irq_vno (gpio_irq_t irq)
{
    WRITE_REG_16(AADDR_GPIO_IRQ_VNO, (uint16_t) irq);
}

uint16_t
gpio_get_irq_status (void)
{
    gpio_irq_status_t irq_status;
    irq_status.val = READ_REG_U16(AADDR_GPIO_IRQ_STATUS);
    return irq_status.val;
}


gpio_irq_t
gpio_get_next_pending_irq (void)
{
    gpio_irq_vno_t irq_no;
    irq_no = READ_REG_U16(AADDR_GPIO_IRQ_VNO);

    return (gpio_irq_t) irq_no;
}


uint16_t
gpio_get_irq_mask (void)
{
    uint16_t irq_mask;
    irq_mask = READ_REG_U16(AADDR_GPIO_IRQ_MASK);

    return irq_mask;
}
