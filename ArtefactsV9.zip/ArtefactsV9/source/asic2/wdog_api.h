/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         wdog_api.h
*
* @brief        WDOG API functions
*
* @author       Dedourek Pavel
*
********************************************************************************
*
********************************************************************************
********************************************************************************
*/

#ifndef __WDOG_API_H__
#define __WDOG_API_H__

#include "hardware.h"
#include "uart_api.h"


/** 
 *  \defgroup wdog_api API functions to control WDOGs/GUARDs
 *
 *  \ingroup  wdog   asic2_wdog
 *
 *  \brief    WDOG API functions
 *
 */
/**@{*/    


/* ############################################################################ */
/**
  * \brief This is an enum class for WDOG to define instancies.
  *
  * \ingroup wdog_api
  */ 
typedef enum {
  WDOG_API_WDOG0 = WDOG0,  ///< this is instance WDOG0
  WDOG_API_WDOG1 = WDOG1   ///< this is instance WDOG1
} wdog_api_wdog_instance_t;

/* ############################################################################ */
/**
  * \brief This is an enum class for GUARD to define instancies.
  *
  * \ingroup wdog_api
  */ 
typedef enum {
  WDOG_API_GUARD0 = GUARD0,  ///< this is instance GUARD0
  WDOG_API_GUARD1 = GUARD1   ///< this is instance GUARD1
} wdog_api_guard_instance_t;



/* ############################################################################ */
void wdog_api_guard_toggle(wdog_api_guard_instance_t eInstance);

/* ############################################################################ */
void wdog_api_guard_enable(wdog_api_guard_instance_t eInstance);

/* ############################################################################ */
void wdog_api_guard_disable(wdog_api_guard_instance_t eInstance);

/* ############################################################################ */
void wdog_api_wdog_toggle(wdog_api_wdog_instance_t eInstance);

/* ############################################################################ */
void wdog_api_wdog_enable(wdog_api_wdog_instance_t eInstance);

/* ############################################################################ */

/**@}*/ 
#endif