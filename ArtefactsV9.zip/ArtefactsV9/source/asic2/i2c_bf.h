/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         i2c_bf.h
*
* @brief        I2C Master Interface HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __I2C_BF_H__
#define __I2C_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_I2C
#define BASE_ADDR_I2C 0x40007180U
#endif

#define NUMBER_I2C 1

/**
  * \brief This is an enum class for I2C instance
  *
  * \ingroup i2c
  */ 
typedef enum {
  I2C                            = (int)BASE_ADDR_I2C
} i2c_num_t;

// Register bit field definitions

/* I2C_CMD_DATA */

#define MSK_I2C_CMD_DATA_DATA                               (0xff)    /* [ 7:0] */
#define RES_I2C_CMD_DATA_DATA                               (0x00)
#define SFT_I2C_CMD_DATA_DATA                               (0)
#define LSB_I2C_CMD_DATA_DATA                               (0)
#define MSB_I2C_CMD_DATA_DATA                               (7)
#define MSK_I2C_CMD_DATA_SEND                               (0x1)     /* [8] */
#define RES_I2C_CMD_DATA_SEND                               (0x0)
#define SFT_I2C_CMD_DATA_SEND                               (8)
#define LSB_I2C_CMD_DATA_SEND                               (8)
#define MSB_I2C_CMD_DATA_SEND                               (8)
#define BIT_I2C_CMD_DATA_SEND                               (0x100)   /* [8] */
#define MSK_I2C_CMD_DATA_START                              (0x1)     /* [9] */
#define RES_I2C_CMD_DATA_START                              (0x0)
#define SFT_I2C_CMD_DATA_START                              (9)
#define LSB_I2C_CMD_DATA_START                              (9)
#define MSB_I2C_CMD_DATA_START                              (9)
#define BIT_I2C_CMD_DATA_START                              (0x200)   /* [9] */
#define MSK_I2C_CMD_DATA_ACK                                (0x1)     /* [10] */
#define RES_I2C_CMD_DATA_ACK                                (0x0)
#define SFT_I2C_CMD_DATA_ACK                                (10)
#define LSB_I2C_CMD_DATA_ACK                                (10)
#define MSB_I2C_CMD_DATA_ACK                                (10)
#define BIT_I2C_CMD_DATA_ACK                                (0x400)   /* [10] */
#define MSK_I2C_CMD_DATA_STOP                               (0x1)     /* [11] */
#define RES_I2C_CMD_DATA_STOP                               (0x0)
#define SFT_I2C_CMD_DATA_STOP                               (11)
#define LSB_I2C_CMD_DATA_STOP                               (11)
#define MSB_I2C_CMD_DATA_STOP                               (11)
#define BIT_I2C_CMD_DATA_STOP                               (0x800)   /* [11] */

/** 
 * \brief This structure describes I2C command data
 *
 * \ingroup i2c
 */
typedef struct {
  /**
   * Data to be sent
   */
  unsigned short data                          :    8;       /* [ 7:0] */
  
  /**
   * I2C Write operation
   */
  unsigned short send                          :    1;       /* [8] */

  /**
   * Start condition
   */
  unsigned short start                         :    1;       /* [9] */
  
  /**
   * 0 - ACK<br>
   * 1 - NACK
   */
  unsigned short ack                           :    1;       /* [10] */

  /**
   * Stop condition
   */
   unsigned short stop                          :    1;       /* [11] */
  unsigned short reserved                      :    4;
} i2c_cmd_data_bf;

/**
 * \brief Conversion type between word and bit representation of I2C command data
 *
 * \ingroup i2c
 */
typedef union {
  unsigned short val; ///< word representation
  i2c_cmd_data_bf bf; ///< bit field representation
} i2c_cmd_data_t;


/* I2C_REC_DATA */

#define MSK_I2C_REC_DATA                                    (0xff)    /* [ 7:0] */

typedef unsigned short i2c_rec_data_t;                                /* [ 7:0] */


/* I2C_CONFIG */

#define MSK_I2C_CONFIG_REC_FIFO_LEVEL                       (0x7)     /* [ 2:0] */
#define RES_I2C_CONFIG_REC_FIFO_LEVEL                       (0x2)
#define SFT_I2C_CONFIG_REC_FIFO_LEVEL                       (0)
#define LSB_I2C_CONFIG_REC_FIFO_LEVEL                       (0)
#define MSB_I2C_CONFIG_REC_FIFO_LEVEL                       (2)
#define MSK_I2C_CONFIG_CMD_FIFO_LEVEL                       (0xf)     /* [ 7:4] */
#define RES_I2C_CONFIG_CMD_FIFO_LEVEL                       (0x0)
#define SFT_I2C_CONFIG_CMD_FIFO_LEVEL                       (4)
#define LSB_I2C_CONFIG_CMD_FIFO_LEVEL                       (4)
#define MSB_I2C_CONFIG_CMD_FIFO_LEVEL                       (7)

/** 
 * \brief This structure describes I2C FIFO config
 *
 * \ingroup i2c
 */
typedef struct {
  /**
   * high water receive FIFO level <br>
   * interrupt will be asserted when receive FIFO fill level increases to this
   * value
   */
  unsigned short rec_fifo_level                :    3;       /* [ 2:0] */
  unsigned short reserved3                     :    1;       /* [3] */
  /**
   * low water command FIFO level
   * interrupt will be asserted when command FIFO fill level decreases to
   * this value
   */
  unsigned short cmd_fifo_level                :    4;       /* [ 7:4] */
  unsigned short reserved                      :    8;
} i2c_config_bf;

/**
 * \brief Conversion type between word and bit representation of I2C FIFO config
 *
 * \ingroup i2c
 */
typedef union {
  unsigned short val; ///< word representation
  i2c_config_bf bf;   ///< bit field representation
} i2c_config_t;


/* I2C_BAUD_CONFIG */

#define MSK_I2C_BAUD_CONFIG                                 (0xffff)  /* [15:0] */

typedef unsigned short i2c_baud_config_t;                             /* [15:0] */


/* I2C_FIFO_CLEAR */

#define MSK_I2C_FIFO_CLEAR_REC_FIFO_CLEAR                   (0x1)     /* [0] */
#define RES_I2C_FIFO_CLEAR_REC_FIFO_CLEAR                   (0x0)
#define SFT_I2C_FIFO_CLEAR_REC_FIFO_CLEAR                   (0)
#define LSB_I2C_FIFO_CLEAR_REC_FIFO_CLEAR                   (0)
#define MSB_I2C_FIFO_CLEAR_REC_FIFO_CLEAR                   (0)
#define BIT_I2C_FIFO_CLEAR_REC_FIFO_CLEAR                   (0x1)     /* [0] */
#define MSK_I2C_FIFO_CLEAR_CMD_FIFO_CLEAR                   (0x1)     /* [1] */
#define RES_I2C_FIFO_CLEAR_CMD_FIFO_CLEAR                   (0x0)
#define SFT_I2C_FIFO_CLEAR_CMD_FIFO_CLEAR                   (1)
#define LSB_I2C_FIFO_CLEAR_CMD_FIFO_CLEAR                   (1)
#define MSB_I2C_FIFO_CLEAR_CMD_FIFO_CLEAR                   (1)
#define BIT_I2C_FIFO_CLEAR_CMD_FIFO_CLEAR                   (0x2)     /* [1] */

/** 
 * \brief This structure describes I2C FIFO clear
 *
 * \ingroup i2c
 */
typedef struct {
  /**
   * 1: receiver FIFO clear
   */
  unsigned short rec_fifo_clear                :    1;       /* [0] */
  
  /**
   * 1: transmit FIFO clear
   */
  unsigned short cmd_fifo_clear                :    1;       /* [1] */
  unsigned short reserved                      :   14;
} i2c_fifo_clear_bf;

/**
 * \brief Conversion type between word and bit representation of I2C FIFO clear
 *
 * \ingroup i2c
 */
typedef union {
  unsigned short val;   ///< word representation
  i2c_fifo_clear_bf bf; ///< bit field representation
} i2c_fifo_clear_t;


/* I2C_FIFO_LEVELS */

#define MSK_I2C_FIFO_LEVELS_REC_FIFO_LEVEL                  (0x7)     /* [ 2:0] */
#define RES_I2C_FIFO_LEVELS_REC_FIFO_LEVEL                  (0x0)
#define SFT_I2C_FIFO_LEVELS_REC_FIFO_LEVEL                  (0)
#define LSB_I2C_FIFO_LEVELS_REC_FIFO_LEVEL                  (0)
#define MSB_I2C_FIFO_LEVELS_REC_FIFO_LEVEL                  (2)
#define MSK_I2C_FIFO_LEVELS_CMD_FIFO_LEVEL                  (0xf)     /* [ 7:4] */
#define RES_I2C_FIFO_LEVELS_CMD_FIFO_LEVEL                  (0x0)
#define SFT_I2C_FIFO_LEVELS_CMD_FIFO_LEVEL                  (4)
#define LSB_I2C_FIFO_LEVELS_CMD_FIFO_LEVEL                  (4)
#define MSB_I2C_FIFO_LEVELS_CMD_FIFO_LEVEL                  (7)

/** 
 * \brief This structure describes I2C FIFO levels
 *
 * \ingroup i2c
 */
typedef struct {
  /**
   * receive FIFO fill level
   */
  unsigned short rec_fifo_level                :    3;       /* [ 2:0] */
  unsigned short reserved3                     :    1;       /* [3] */
  /**
   * transmit FIFO fill level
   */
  unsigned short cmd_fifo_level                :    4;       /* [ 7:4] */
  unsigned short reserved                      :    8;
} i2c_fifo_levels_bf;

/**
 * \brief Conversion type between word and bit representation of I2C FIFO levels
 *
 * \ingroup i2c
 */
typedef union {
  unsigned short val;    ///< word representation
  i2c_fifo_levels_bf bf; ///< bit field representation
} i2c_fifo_levels_t;


/* I2C_IRQ_STATUS */

#define MSK_I2C_IRQ_STATUS_EVT_REC_FIFO_OV_ERR              (0x1)     /* [0] */
#define RES_I2C_IRQ_STATUS_EVT_REC_FIFO_OV_ERR              (0x0)
#define SFT_I2C_IRQ_STATUS_EVT_REC_FIFO_OV_ERR              (0)
#define LSB_I2C_IRQ_STATUS_EVT_REC_FIFO_OV_ERR              (0)
#define MSB_I2C_IRQ_STATUS_EVT_REC_FIFO_OV_ERR              (0)
#define BIT_I2C_IRQ_STATUS_EVT_REC_FIFO_OV_ERR              (0x1)     /* [0] */
#define MSK_I2C_IRQ_STATUS_EVT_REC_FIFO_UR_ERR              (0x1)     /* [1] */
#define RES_I2C_IRQ_STATUS_EVT_REC_FIFO_UR_ERR              (0x0)
#define SFT_I2C_IRQ_STATUS_EVT_REC_FIFO_UR_ERR              (1)
#define LSB_I2C_IRQ_STATUS_EVT_REC_FIFO_UR_ERR              (1)
#define MSB_I2C_IRQ_STATUS_EVT_REC_FIFO_UR_ERR              (1)
#define BIT_I2C_IRQ_STATUS_EVT_REC_FIFO_UR_ERR              (0x2)     /* [1] */
#define MSK_I2C_IRQ_STATUS_EVT_CMD_FIFO_OV_ERR              (0x1)     /* [2] */
#define RES_I2C_IRQ_STATUS_EVT_CMD_FIFO_OV_ERR              (0x0)
#define SFT_I2C_IRQ_STATUS_EVT_CMD_FIFO_OV_ERR              (2)
#define LSB_I2C_IRQ_STATUS_EVT_CMD_FIFO_OV_ERR              (2)
#define MSB_I2C_IRQ_STATUS_EVT_CMD_FIFO_OV_ERR              (2)
#define BIT_I2C_IRQ_STATUS_EVT_CMD_FIFO_OV_ERR              (0x4)     /* [2] */
#define MSK_I2C_IRQ_STATUS_EVT_CMD_FIFO_UR_ERR              (0x1)     /* [3] */
#define RES_I2C_IRQ_STATUS_EVT_CMD_FIFO_UR_ERR              (0x0)
#define SFT_I2C_IRQ_STATUS_EVT_CMD_FIFO_UR_ERR              (3)
#define LSB_I2C_IRQ_STATUS_EVT_CMD_FIFO_UR_ERR              (3)
#define MSB_I2C_IRQ_STATUS_EVT_CMD_FIFO_UR_ERR              (3)
#define BIT_I2C_IRQ_STATUS_EVT_CMD_FIFO_UR_ERR              (0x8)     /* [3] */
#define MSK_I2C_IRQ_STATUS_EVT_ACK_ERR                      (0x1)     /* [4] */
#define RES_I2C_IRQ_STATUS_EVT_ACK_ERR                      (0x0)
#define SFT_I2C_IRQ_STATUS_EVT_ACK_ERR                      (4)
#define LSB_I2C_IRQ_STATUS_EVT_ACK_ERR                      (4)
#define MSB_I2C_IRQ_STATUS_EVT_ACK_ERR                      (4)
#define BIT_I2C_IRQ_STATUS_EVT_ACK_ERR                      (0x10)    /* [4] */
#define MSK_I2C_IRQ_STATUS_EVT_BIT_ERR                      (0x1)     /* [5] */
#define RES_I2C_IRQ_STATUS_EVT_BIT_ERR                      (0x0)
#define SFT_I2C_IRQ_STATUS_EVT_BIT_ERR                      (5)
#define LSB_I2C_IRQ_STATUS_EVT_BIT_ERR                      (5)
#define MSB_I2C_IRQ_STATUS_EVT_BIT_ERR                      (5)
#define BIT_I2C_IRQ_STATUS_EVT_BIT_ERR                      (0x20)    /* [5] */
#define MSK_I2C_IRQ_STATUS_REC_FIFO_NEMPTY                  (0x1)     /* [6] */
#define RES_I2C_IRQ_STATUS_REC_FIFO_NEMPTY                  (0x0)
#define SFT_I2C_IRQ_STATUS_REC_FIFO_NEMPTY                  (6)
#define LSB_I2C_IRQ_STATUS_REC_FIFO_NEMPTY                  (6)
#define MSB_I2C_IRQ_STATUS_REC_FIFO_NEMPTY                  (6)
#define BIT_I2C_IRQ_STATUS_REC_FIFO_NEMPTY                  (0x40)    /* [6] */
#define MSK_I2C_IRQ_STATUS_REC_FIFO_HIGH_WATER              (0x1)     /* [7] */
#define RES_I2C_IRQ_STATUS_REC_FIFO_HIGH_WATER              (0x0)
#define SFT_I2C_IRQ_STATUS_REC_FIFO_HIGH_WATER              (7)
#define LSB_I2C_IRQ_STATUS_REC_FIFO_HIGH_WATER              (7)
#define MSB_I2C_IRQ_STATUS_REC_FIFO_HIGH_WATER              (7)
#define BIT_I2C_IRQ_STATUS_REC_FIFO_HIGH_WATER              (0x80)    /* [7] */
#define MSK_I2C_IRQ_STATUS_REC_FIFO_FULL                    (0x1)     /* [8] */
#define RES_I2C_IRQ_STATUS_REC_FIFO_FULL                    (0x0)
#define SFT_I2C_IRQ_STATUS_REC_FIFO_FULL                    (8)
#define LSB_I2C_IRQ_STATUS_REC_FIFO_FULL                    (8)
#define MSB_I2C_IRQ_STATUS_REC_FIFO_FULL                    (8)
#define BIT_I2C_IRQ_STATUS_REC_FIFO_FULL                    (0x100)   /* [8] */
#define MSK_I2C_IRQ_STATUS_CMD_FIFO_EMPTY                   (0x1)     /* [9] */
#define RES_I2C_IRQ_STATUS_CMD_FIFO_EMPTY                   (0x1)
#define SFT_I2C_IRQ_STATUS_CMD_FIFO_EMPTY                   (9)
#define LSB_I2C_IRQ_STATUS_CMD_FIFO_EMPTY                   (9)
#define MSB_I2C_IRQ_STATUS_CMD_FIFO_EMPTY                   (9)
#define BIT_I2C_IRQ_STATUS_CMD_FIFO_EMPTY                   (0x200)   /* [9] */
#define MSK_I2C_IRQ_STATUS_CMD_FIFO_LOW_WATER               (0x1)     /* [10] */
#define RES_I2C_IRQ_STATUS_CMD_FIFO_LOW_WATER               (0x1)
#define SFT_I2C_IRQ_STATUS_CMD_FIFO_LOW_WATER               (10)
#define LSB_I2C_IRQ_STATUS_CMD_FIFO_LOW_WATER               (10)
#define MSB_I2C_IRQ_STATUS_CMD_FIFO_LOW_WATER               (10)
#define BIT_I2C_IRQ_STATUS_CMD_FIFO_LOW_WATER               (0x400)   /* [10] */
#define MSK_I2C_IRQ_STATUS_CMD_FIFO_NFULL                   (0x1)     /* [11] */
#define RES_I2C_IRQ_STATUS_CMD_FIFO_NFULL                   (0x1)
#define SFT_I2C_IRQ_STATUS_CMD_FIFO_NFULL                   (11)
#define LSB_I2C_IRQ_STATUS_CMD_FIFO_NFULL                   (11)
#define MSB_I2C_IRQ_STATUS_CMD_FIFO_NFULL                   (11)
#define BIT_I2C_IRQ_STATUS_CMD_FIFO_NFULL                   (0x800)   /* [11] */
#define MSK_I2C_IRQ_STATUS_SCL_STRETCH                      (0x1)     /* [12] */
#define RES_I2C_IRQ_STATUS_SCL_STRETCH                      (0x0)
#define SFT_I2C_IRQ_STATUS_SCL_STRETCH                      (12)
#define LSB_I2C_IRQ_STATUS_SCL_STRETCH                      (12)
#define MSB_I2C_IRQ_STATUS_SCL_STRETCH                      (12)
#define BIT_I2C_IRQ_STATUS_SCL_STRETCH                      (0x1000)  /* [12] */

/**
 * \brief This structure describes I2C IRQ status register 
 *
 * \ingroup i2c
 *
 */
typedef struct {
  /**
   * software did not read incoming data fast enough
   */
  unsigned short evt_rec_fifo_ov_err           :    1;       /* [0] */
  
  /**
   * software has read from empty receive fifo
   */
  unsigned short evt_rec_fifo_ur_err           :    1;       /* [1] */
  
  /**
   * software wrote data to full transmit fifo
   */
  unsigned short evt_cmd_fifo_ov_err           :    1;       /* [2] */
  
  /**
   * software has not written outgoing data fast enough
   */
  unsigned short evt_cmd_fifo_ur_err           :    1;       /* [3] */
  
  /**
   * acknoledge error
   */
  unsigned short evt_ack_err                   :    1;       /* [4] */
  
  /**
   * bit error (looped back transmit bit mismatch)
   */
  unsigned short evt_bit_err                   :    1;       /* [5] */
  
  /**
   * receive fifo is not empty
   */
  unsigned short rec_fifo_nempty               :    1;       /* [6] */
  
  /**
   * receive fifo elements > high water level
   */
  unsigned short rec_fifo_high_water           :    1;       /* [7] */
  
  /**
   * receive fifo is full
   */
  unsigned short rec_fifo_full                 :    1;       /* [8] */
  
  /**
   * transmit fifo is empty
   */
  unsigned short cmd_fifo_empty                :    1;       /* [9] */
  
  /**
   * transmit fifo elements <= low water level
   */
  unsigned short cmd_fifo_low_water            :    1;       /* [10] */
  
  /**
   * transmit fifo is not full
   */
  unsigned short cmd_fifo_nfull                :    1;       /* [11] */
  
  /**
   * scl is stretched by slow slave
   */
  unsigned short scl_stretch                   :    1;       /* [12] */
  unsigned short reserved                      :    3;
} i2c_irq_status_bf;

/**
 * \brief Conversion type between word and bit representation of I2C IRQ status register 
 *
 * \ingroup i2c
 */
typedef union {
  unsigned short val;   ///< word representation
  i2c_irq_status_bf bf; ///< bit field representation
} i2c_irq_status_t;


/* I2C_IRQ_MASK */

#define MSK_I2C_IRQ_MASK                                    (0x1fff)  /* [12:0] */

typedef unsigned short i2c_irq_mask_t;                                /* [12:0] */


/* I2C_IRQ_VENABLE */

#define MSK_I2C_IRQ_VENABLE                                 (0xf)     /* [ 3:0] */

typedef unsigned short i2c_irq_venable_t;                             /* [ 3:0] */


/* I2C_IRQ_VDISABLE */

#define MSK_I2C_IRQ_VDISABLE                                (0xf)     /* [ 3:0] */

typedef unsigned short i2c_irq_vdisable_t;                            /* [ 3:0] */


/* I2C_IRQ_VMAX */

#define MSK_I2C_IRQ_VMAX                                    (0xf)     /* [ 3:0] */

typedef unsigned short i2c_irq_vmax_t;                                /* [ 3:0] */


/* I2C_IRQ_VNO */

#define MSK_I2C_IRQ_VNO                                     (0xf)     /* [ 3:0] */

typedef unsigned short i2c_irq_vno_t;                                 /* [ 3:0] */



// Register definitions for module
// Instance base address BASE_ADDR_I2C 0x40007180U ... 

#define ADDR_I2C_CMD_DATA                                    (0x00U)
#define A_I2C_CMD_DATA(ba)                                   ((ba) + ADDR_I2C_CMD_DATA)
#define R_I2C_CMD_DATA(ba)                                   (*(volatile unsigned short *)((unsigned int)A_I2C_CMD_DATA(ba)))
#define RES_I2C_CMD_DATA                                     (0x0U)
#define MSB_I2C_CMD_DATA                                     11
#define LSB_I2C_CMD_DATA                                     0
#define AADDR_I2C_CMD_DATA                                   (BASE_ADDR_I2C + ADDR_I2C_CMD_DATA)
#define REG_I2C_CMD_DATA                                     (*(volatile unsigned short *)((unsigned int)AADDR_I2C_CMD_DATA))

#define ADDR_I2C_REC_DATA                                    (0x02U)
#define A_I2C_REC_DATA(ba)                                   ((ba) + ADDR_I2C_REC_DATA)
#define R_I2C_REC_DATA(ba)                                   (*(volatile unsigned short *)((unsigned int)A_I2C_REC_DATA(ba)))
#define RES_I2C_REC_DATA                                     (0x0U)
#define MSB_I2C_REC_DATA                                     7
#define LSB_I2C_REC_DATA                                     0
#define AADDR_I2C_REC_DATA                                   (BASE_ADDR_I2C + ADDR_I2C_REC_DATA)
#define REG_I2C_REC_DATA                                     (*(volatile unsigned short *)((unsigned int)AADDR_I2C_REC_DATA))

#define ADDR_I2C_CONFIG                                      (0x04U)
#define A_I2C_CONFIG(ba)                                     ((ba) + ADDR_I2C_CONFIG)
#define R_I2C_CONFIG(ba)                                     (*(volatile unsigned short *)((unsigned int)A_I2C_CONFIG(ba)))
#define RES_I2C_CONFIG                                       (0x2U)
#define MSB_I2C_CONFIG                                       7
#define LSB_I2C_CONFIG                                       0
#define AADDR_I2C_CONFIG                                     (BASE_ADDR_I2C + ADDR_I2C_CONFIG)
#define REG_I2C_CONFIG                                       (*(volatile unsigned short *)((unsigned int)AADDR_I2C_CONFIG))

#define ADDR_I2C_BAUD_CONFIG                                 (0x06U)
#define A_I2C_BAUD_CONFIG(ba)                                ((ba) + ADDR_I2C_BAUD_CONFIG)
#define R_I2C_BAUD_CONFIG(ba)                                (*(volatile unsigned short *)((unsigned int)A_I2C_BAUD_CONFIG(ba)))
#define RES_I2C_BAUD_CONFIG                                  (0x1U)
#define MSB_I2C_BAUD_CONFIG                                  15
#define LSB_I2C_BAUD_CONFIG                                  0
#define AADDR_I2C_BAUD_CONFIG                                (BASE_ADDR_I2C + ADDR_I2C_BAUD_CONFIG)
#define REG_I2C_BAUD_CONFIG                                  (*(volatile unsigned short *)((unsigned int)AADDR_I2C_BAUD_CONFIG))

#define ADDR_I2C_FIFO_CLEAR                                  (0x08U)
#define A_I2C_FIFO_CLEAR(ba)                                 ((ba) + ADDR_I2C_FIFO_CLEAR)
#define R_I2C_FIFO_CLEAR(ba)                                 (*(volatile unsigned short *)((unsigned int)A_I2C_FIFO_CLEAR(ba)))
#define RES_I2C_FIFO_CLEAR                                   (0x0U)
#define MSB_I2C_FIFO_CLEAR                                   1
#define LSB_I2C_FIFO_CLEAR                                   0
#define AADDR_I2C_FIFO_CLEAR                                 (BASE_ADDR_I2C + ADDR_I2C_FIFO_CLEAR)
#define REG_I2C_FIFO_CLEAR                                   (*(volatile unsigned short *)((unsigned int)AADDR_I2C_FIFO_CLEAR))

#define ADDR_I2C_FIFO_LEVELS                                 (0x0AU)
#define A_I2C_FIFO_LEVELS(ba)                                ((ba) + ADDR_I2C_FIFO_LEVELS)
#define R_I2C_FIFO_LEVELS(ba)                                (*(volatile unsigned short *)((unsigned int)A_I2C_FIFO_LEVELS(ba)))
#define RES_I2C_FIFO_LEVELS                                  (0x0U)
#define MSB_I2C_FIFO_LEVELS                                  7
#define LSB_I2C_FIFO_LEVELS                                  0
#define AADDR_I2C_FIFO_LEVELS                                (BASE_ADDR_I2C + ADDR_I2C_FIFO_LEVELS)
#define REG_I2C_FIFO_LEVELS                                  (*(volatile unsigned short *)((unsigned int)AADDR_I2C_FIFO_LEVELS))

#define ADDR_I2C_IRQ_STATUS                                  (0x20U)
#define A_I2C_IRQ_STATUS(ba)                                 ((ba) + ADDR_I2C_IRQ_STATUS)
#define R_I2C_IRQ_STATUS(ba)                                 (*(volatile unsigned short *)((unsigned int)A_I2C_IRQ_STATUS(ba)))
#define RES_I2C_IRQ_STATUS                                   (0xe00U)
#define MSB_I2C_IRQ_STATUS                                   12
#define LSB_I2C_IRQ_STATUS                                   0
#define AADDR_I2C_IRQ_STATUS                                 (BASE_ADDR_I2C + ADDR_I2C_IRQ_STATUS)
#define REG_I2C_IRQ_STATUS                                   (*(volatile unsigned short *)((unsigned int)AADDR_I2C_IRQ_STATUS))

#define ADDR_I2C_IRQ_MASK                                    (0x24U)
#define A_I2C_IRQ_MASK(ba)                                   ((ba) + ADDR_I2C_IRQ_MASK)
#define R_I2C_IRQ_MASK(ba)                                   (*(volatile unsigned short *)((unsigned int)A_I2C_IRQ_MASK(ba)))
#define RES_I2C_IRQ_MASK                                     (0x0U)
#define MSB_I2C_IRQ_MASK                                     12
#define LSB_I2C_IRQ_MASK                                     0
#define AADDR_I2C_IRQ_MASK                                   (BASE_ADDR_I2C + ADDR_I2C_IRQ_MASK)
#define REG_I2C_IRQ_MASK                                     (*(volatile unsigned short *)((unsigned int)AADDR_I2C_IRQ_MASK))

#define ADDR_I2C_IRQ_VENABLE                                 (0x28U)
#define A_I2C_IRQ_VENABLE(ba)                                ((ba) + ADDR_I2C_IRQ_VENABLE)
#define R_I2C_IRQ_VENABLE(ba)                                (*(volatile unsigned short *)((unsigned int)A_I2C_IRQ_VENABLE(ba)))
#define RES_I2C_IRQ_VENABLE                                  (0x0U)
#define MSB_I2C_IRQ_VENABLE                                  3
#define LSB_I2C_IRQ_VENABLE                                  0
#define AADDR_I2C_IRQ_VENABLE                                (BASE_ADDR_I2C + ADDR_I2C_IRQ_VENABLE)
#define REG_I2C_IRQ_VENABLE                                  (*(volatile unsigned short *)((unsigned int)AADDR_I2C_IRQ_VENABLE))

#define ADDR_I2C_IRQ_VDISABLE                                (0x2AU)
#define A_I2C_IRQ_VDISABLE(ba)                               ((ba) + ADDR_I2C_IRQ_VDISABLE)
#define R_I2C_IRQ_VDISABLE(ba)                               (*(volatile unsigned short *)((unsigned int)A_I2C_IRQ_VDISABLE(ba)))
#define RES_I2C_IRQ_VDISABLE                                 (0x0U)
#define MSB_I2C_IRQ_VDISABLE                                 3
#define LSB_I2C_IRQ_VDISABLE                                 0
#define AADDR_I2C_IRQ_VDISABLE                               (BASE_ADDR_I2C + ADDR_I2C_IRQ_VDISABLE)
#define REG_I2C_IRQ_VDISABLE                                 (*(volatile unsigned short *)((unsigned int)AADDR_I2C_IRQ_VDISABLE))

#define ADDR_I2C_IRQ_VMAX                                    (0x2CU)
#define A_I2C_IRQ_VMAX(ba)                                   ((ba) + ADDR_I2C_IRQ_VMAX)
#define R_I2C_IRQ_VMAX(ba)                                   (*(volatile unsigned short *)((unsigned int)A_I2C_IRQ_VMAX(ba)))
#define RES_I2C_IRQ_VMAX                                     (0xdU)
#define MSB_I2C_IRQ_VMAX                                     3
#define LSB_I2C_IRQ_VMAX                                     0
#define AADDR_I2C_IRQ_VMAX                                   (BASE_ADDR_I2C + ADDR_I2C_IRQ_VMAX)
#define REG_I2C_IRQ_VMAX                                     (*(volatile unsigned short *)((unsigned int)AADDR_I2C_IRQ_VMAX))

#define ADDR_I2C_IRQ_VNO                                     (0x2EU)
#define A_I2C_IRQ_VNO(ba)                                    ((ba) + ADDR_I2C_IRQ_VNO)
#define R_I2C_IRQ_VNO(ba)                                    (*(volatile unsigned short *)((unsigned int)A_I2C_IRQ_VNO(ba)))
#define RES_I2C_IRQ_VNO                                      (0xdU)
#define MSB_I2C_IRQ_VNO                                      3
#define LSB_I2C_IRQ_VNO                                      0
#define AADDR_I2C_IRQ_VNO                                    (BASE_ADDR_I2C + ADDR_I2C_IRQ_VNO)
#define REG_I2C_IRQ_VNO                                      (*(volatile unsigned short *)((unsigned int)AADDR_I2C_IRQ_VNO))




#endif
