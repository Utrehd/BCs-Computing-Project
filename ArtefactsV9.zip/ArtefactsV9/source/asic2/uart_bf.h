/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         uart_bf.h
*
* @brief        UART HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __UART_BF_H__
#define __UART_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_UART
#define BASE_ADDR_UART 0x40006980U
#endif

#define NUMBER_UART 1


/* ############################################################################ */
/**
 * \brief UART instance
 *
 * \ingroup uart 
 */ 
typedef enum {
  /**
   * first UART instance
   */ 
  UART                           = (int)BASE_ADDR_UART
} uart_num_t;

// Register bit field definitions

/* UART_CONFIG */

#define MSK_UART_CONFIG_RX_ENABLE                           (0x1)     /* [0] */
#define RES_UART_CONFIG_RX_ENABLE                           (0x0)
#define SFT_UART_CONFIG_RX_ENABLE                           (0)
#define LSB_UART_CONFIG_RX_ENABLE                           (0)
#define MSB_UART_CONFIG_RX_ENABLE                           (0)
#define BIT_UART_CONFIG_RX_ENABLE                           (0x1)     /* [0] */
#define MSK_UART_CONFIG_PAR_TYPE                            (0x3)     /* [ 2:1] */
#define RES_UART_CONFIG_PAR_TYPE                            (0x0)
#define SFT_UART_CONFIG_PAR_TYPE                            (1)
#define LSB_UART_CONFIG_PAR_TYPE                            (1)
#define MSB_UART_CONFIG_PAR_TYPE                            (2)
#define MSK_UART_CONFIG_STOP_BITS                           (0x1)     /* [3] */
#define RES_UART_CONFIG_STOP_BITS                           (0x0)
#define SFT_UART_CONFIG_STOP_BITS                           (3)
#define LSB_UART_CONFIG_STOP_BITS                           (3)
#define MSB_UART_CONFIG_STOP_BITS                           (3)
#define BIT_UART_CONFIG_STOP_BITS                           (0x8)     /* [3] */
#define MSK_UART_CONFIG_DATA_BITS                           (0x1)     /* [4] */
#define RES_UART_CONFIG_DATA_BITS                           (0x0)
#define SFT_UART_CONFIG_DATA_BITS                           (4)
#define LSB_UART_CONFIG_DATA_BITS                           (4)
#define MSB_UART_CONFIG_DATA_BITS                           (4)
#define BIT_UART_CONFIG_DATA_BITS                           (0x10)    /* [4] */
#define MSK_UART_CONFIG_LOOPBACK_EN                         (0x1)     /* [5] */
#define RES_UART_CONFIG_LOOPBACK_EN                         (0x0)
#define SFT_UART_CONFIG_LOOPBACK_EN                         (5)
#define LSB_UART_CONFIG_LOOPBACK_EN                         (5)
#define MSB_UART_CONFIG_LOOPBACK_EN                         (5)
#define BIT_UART_CONFIG_LOOPBACK_EN                         (0x20)    /* [5] */
#define MSK_UART_CONFIG_RX_FIFO_HIGH_WATER                  (0xf)     /* [ 9:6] */
#define RES_UART_CONFIG_RX_FIFO_HIGH_WATER                  (0x0)
#define SFT_UART_CONFIG_RX_FIFO_HIGH_WATER                  (6)
#define LSB_UART_CONFIG_RX_FIFO_HIGH_WATER                  (6)
#define MSB_UART_CONFIG_RX_FIFO_HIGH_WATER                  (9)
#define MSK_UART_CONFIG_TX_FIFO_LOW_WATER                   (0xf)     /* [13:10] */
#define RES_UART_CONFIG_TX_FIFO_LOW_WATER                   (0x0)
#define SFT_UART_CONFIG_TX_FIFO_LOW_WATER                   (10)
#define LSB_UART_CONFIG_TX_FIFO_LOW_WATER                   (10)
#define MSB_UART_CONFIG_TX_FIFO_LOW_WATER                   (13)
#define MSK_UART_CONFIG_ECHO_CANCEL                         (0x1)     /* [14] */
#define RES_UART_CONFIG_ECHO_CANCEL                         (0x0)
#define SFT_UART_CONFIG_ECHO_CANCEL                         (14)
#define LSB_UART_CONFIG_ECHO_CANCEL                         (14)
#define MSB_UART_CONFIG_ECHO_CANCEL                         (14)
#define BIT_UART_CONFIG_ECHO_CANCEL                         (0x4000)  /* [14] */


/* ############################################################################ */
/**
 * \brief UART configuration
 *
 * \ingroup uart 
 */ 
typedef struct {
  /**
   * enable receive function
   */ 
  unsigned short rx_enable                     :    1;       /* [0] */
  
  /**
   * type of parity bit <br>
   * 0: no parity bit <br>
   * 1: odd parity <br>
   * 2: even parity <br>
   */ 
  unsigned short par_type                      :    2;       /* [ 2:1] */
  
  /**
   * number of stop bits for transmit <br>
   * 0: one stop bit <br>
   * 1: two stop bits <br>
   */ 
  unsigned short stop_bits                     :    1;       /* [3] */
  
  /**
   * number of data bits <br>
   * 0: 8 data bits <br>
   * 1: 7 data bits <br>
   */ 
  unsigned short data_bits                     :    1;       /* [4] */
  
  /**
   * enable internal loopback
   */ 
  unsigned short loopback_en                   :    1;       /* [5] */
  
  /**
   * receive FIFO high water level from 0...FIFOS_SIZE-1
   */ 
  unsigned short rx_fifo_high_water            :    4;       /* [ 9:6] */
  
  /**
   * send FIFO low water level from 0...FIFOS_SIZE-1
   */ 
  unsigned short tx_fifo_low_water             :    4;       /* [13:10] */
  
  /**
   * remove all receive echo until 8 bit times after last transmitted stop bit
   */ 
  unsigned short echo_cancel                   :    1;       /* [14] */
  
  unsigned short reserved                      :    1;
} uart_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of UART configuration
 *
 * \ingroup uart 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  uart_config_bf bf;  ///< bit field representation
} uart_config_t;


/* UART_RX_FIFO_TIMEOUT */

#define MSK_UART_RX_FIFO_TIMEOUT                            (0xffff)  /* [15:0] */

typedef unsigned short uart_rx_fifo_timeout_t;                        /* [15:0] */


/* UART_BAUDRATE_LW */

#define MSK_UART_BAUDRATE_LW_FRAC                           (0x3)     /* [ 1:0] */
#define RES_UART_BAUDRATE_LW_FRAC                           (0x0)
#define SFT_UART_BAUDRATE_LW_FRAC                           (0)
#define LSB_UART_BAUDRATE_LW_FRAC                           (0)
#define MSB_UART_BAUDRATE_LW_FRAC                           (1)
#define MSK_UART_BAUDRATE_LW_DIVIDER                        (0x3fff)  /* [15:2] */
#define RES_UART_BAUDRATE_LW_DIVIDER                        (0x0000)
#define SFT_UART_BAUDRATE_LW_DIVIDER                        (2)
#define LSB_UART_BAUDRATE_LW_DIVIDER                        (2)
#define MSB_UART_BAUDRATE_LW_DIVIDER                        (15)


/* ############################################################################ */
/**
 * \brief Baudrate setting
 *
 * \ingroup uart 
 */ 
typedef struct {
  /**
   * fractional value = frac(1)/2 + frac(0)/4
   */ 
  unsigned short frac                          :    2;       /* [ 1:0] */
  /**
   * divider of interface, divider value = (system frequency / baudrate) - 1
   */ 
  unsigned short divider                       :   14;       /* [15:2] */
} uart_baudrate_lw_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of Baudrate setting
 *
 * \ingroup uart 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  uart_baudrate_lw_bf bf;  ///< bit field representation
} uart_baudrate_lw_t;


/* UART_BAUDRATE_HW */

#define MSK_UART_BAUDRATE_HW                                (0xff)    /* [ 7:0] */

typedef unsigned short uart_baudrate_hw_t;                            /* [ 7:0] */


/* UART_FIFO_CLEAR_CMD */

#define MSK_UART_FIFO_CLEAR_CMD_RX_FIFO_CLEAR               (0x1)     /* [0] */
#define RES_UART_FIFO_CLEAR_CMD_RX_FIFO_CLEAR               (0x0)
#define SFT_UART_FIFO_CLEAR_CMD_RX_FIFO_CLEAR               (0)
#define LSB_UART_FIFO_CLEAR_CMD_RX_FIFO_CLEAR               (0)
#define MSB_UART_FIFO_CLEAR_CMD_RX_FIFO_CLEAR               (0)
#define BIT_UART_FIFO_CLEAR_CMD_RX_FIFO_CLEAR               (0x1)     /* [0] */
#define MSK_UART_FIFO_CLEAR_CMD_TX_FIFO_CLEAR               (0x1)     /* [1] */
#define RES_UART_FIFO_CLEAR_CMD_TX_FIFO_CLEAR               (0x0)
#define SFT_UART_FIFO_CLEAR_CMD_TX_FIFO_CLEAR               (1)
#define LSB_UART_FIFO_CLEAR_CMD_TX_FIFO_CLEAR               (1)
#define MSB_UART_FIFO_CLEAR_CMD_TX_FIFO_CLEAR               (1)
#define BIT_UART_FIFO_CLEAR_CMD_TX_FIFO_CLEAR               (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief FIFO clear commands
 *
 * \ingroup uart 
 */ 
typedef struct {
  /**
   * clear receive fifo
   */ 
  unsigned short rx_fifo_clear                 :    1;       /* [0] */
  /**
   * clear transmit fifo
   */ 
  unsigned short tx_fifo_clear                 :    1;       /* [1] */

  unsigned short reserved                      :   14;
} uart_fifo_clear_cmd_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of FIFO clear commands
 *
 * \ingroup uart 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  uart_fifo_clear_cmd_bf bf;  ///< bit field representation
} uart_fifo_clear_cmd_t;


/* UART_RX_DATA */

#define MSK_UART_RX_DATA_RX_DATA                            (0xff)    /* [ 7:0] */
#define RES_UART_RX_DATA_RX_DATA                            (0x00)
#define SFT_UART_RX_DATA_RX_DATA                            (0)
#define LSB_UART_RX_DATA_RX_DATA                            (0)
#define MSB_UART_RX_DATA_RX_DATA                            (7)
#define MSK_UART_RX_DATA_VALID                              (0x1)     /* [8] */
#define RES_UART_RX_DATA_VALID                              (0x0)
#define SFT_UART_RX_DATA_VALID                              (8)
#define LSB_UART_RX_DATA_VALID                              (8)
#define MSB_UART_RX_DATA_VALID                              (8)
#define BIT_UART_RX_DATA_VALID                              (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief RX data
 *
 * \ingroup uart 
 */ 
typedef struct {
  /**
   * receive data from fifo (element will be removed from fifo)
   */ 
  unsigned short rx_data                       :    8;       /* [ 7:0] */
  /**
   * 1 = at least one element in receive fifo
   */ 
  unsigned short valid                         :    1;       /* [8] */

  unsigned short reserved                      :    7;
} uart_rx_data_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of RX data
 *
 * \ingroup uart 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  uart_rx_data_bf bf;  ///< bit field representation
} uart_rx_data_t;


/* UART_TX_DATA */

#define MSK_UART_TX_DATA                                    (0xff)    /* [ 7:0] */

typedef unsigned short uart_tx_data_t;                                /* [ 7:0] */


/* UART_FIFO_LEVELS */

#define MSK_UART_FIFO_LEVELS_RX_FIFO_LEVEL                  (0xf)     /* [ 3:0] */
#define RES_UART_FIFO_LEVELS_RX_FIFO_LEVEL                  (0x0)
#define SFT_UART_FIFO_LEVELS_RX_FIFO_LEVEL                  (0)
#define LSB_UART_FIFO_LEVELS_RX_FIFO_LEVEL                  (0)
#define MSB_UART_FIFO_LEVELS_RX_FIFO_LEVEL                  (3)
#define MSK_UART_FIFO_LEVELS_TX_FIFO_LEVEL                  (0xf)     /* [ 7:4] */
#define RES_UART_FIFO_LEVELS_TX_FIFO_LEVEL                  (0x0)
#define SFT_UART_FIFO_LEVELS_TX_FIFO_LEVEL                  (4)
#define LSB_UART_FIFO_LEVELS_TX_FIFO_LEVEL                  (4)
#define MSB_UART_FIFO_LEVELS_TX_FIFO_LEVEL                  (7)


/* ############################################################################ */
/**
 * \brief UART FIFO levels
 *
 * \ingroup uart 
 */ 
typedef struct {
  /**
   * number of elements in rx fifo (from 0 to FIFO_SIZE)
   */ 
  unsigned short rx_fifo_level                 :    4;       /* [ 3:0] */
  /**
   * number of elements in tx fifo (from 0 to FIFO_SIZE)
   */ 
  unsigned short tx_fifo_level                 :    4;       /* [ 7:4] */

  unsigned short reserved                      :    8;
} uart_fifo_levels_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of UART FIFO levels
 *
 * \ingroup uart 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  uart_fifo_levels_bf bf;  ///< bit field representation
} uart_fifo_levels_t;


/* UART_MIN_BIT_LENGTH_LW */

#define MSK_UART_MIN_BIT_LENGTH_LW                          (0xffff)  /* [15:0] */

typedef unsigned short uart_min_bit_length_lw_t;                      /* [15:0] */


/* UART_MIN_BIT_LENGTH_HW */

#define MSK_UART_MIN_BIT_LENGTH_HW                          (0x3f)    /* [ 5:0] */

typedef unsigned short uart_min_bit_length_hw_t;                      /* [ 5:0] */


/* UART_IRQ_STATUS */

#define MSK_UART_IRQ_STATUS_EVT_RX_FIFO_OV_ERR              (0x1)     /* [0] */
#define RES_UART_IRQ_STATUS_EVT_RX_FIFO_OV_ERR              (0x0)
#define SFT_UART_IRQ_STATUS_EVT_RX_FIFO_OV_ERR              (0)
#define LSB_UART_IRQ_STATUS_EVT_RX_FIFO_OV_ERR              (0)
#define MSB_UART_IRQ_STATUS_EVT_RX_FIFO_OV_ERR              (0)
#define BIT_UART_IRQ_STATUS_EVT_RX_FIFO_OV_ERR              (0x1)     /* [0] */
#define MSK_UART_IRQ_STATUS_EVT_RX_FIFO_UR_ERR              (0x1)     /* [1] */
#define RES_UART_IRQ_STATUS_EVT_RX_FIFO_UR_ERR              (0x0)
#define SFT_UART_IRQ_STATUS_EVT_RX_FIFO_UR_ERR              (1)
#define LSB_UART_IRQ_STATUS_EVT_RX_FIFO_UR_ERR              (1)
#define MSB_UART_IRQ_STATUS_EVT_RX_FIFO_UR_ERR              (1)
#define BIT_UART_IRQ_STATUS_EVT_RX_FIFO_UR_ERR              (0x2)     /* [1] */
#define MSK_UART_IRQ_STATUS_EVT_TX_FIFO_OV_ERR              (0x1)     /* [2] */
#define RES_UART_IRQ_STATUS_EVT_TX_FIFO_OV_ERR              (0x0)
#define SFT_UART_IRQ_STATUS_EVT_TX_FIFO_OV_ERR              (2)
#define LSB_UART_IRQ_STATUS_EVT_TX_FIFO_OV_ERR              (2)
#define MSB_UART_IRQ_STATUS_EVT_TX_FIFO_OV_ERR              (2)
#define BIT_UART_IRQ_STATUS_EVT_TX_FIFO_OV_ERR              (0x4)     /* [2] */
#define MSK_UART_IRQ_STATUS_EVT_RX_START_ERR                (0x1)     /* [3] */
#define RES_UART_IRQ_STATUS_EVT_RX_START_ERR                (0x0)
#define SFT_UART_IRQ_STATUS_EVT_RX_START_ERR                (3)
#define LSB_UART_IRQ_STATUS_EVT_RX_START_ERR                (3)
#define MSB_UART_IRQ_STATUS_EVT_RX_START_ERR                (3)
#define BIT_UART_IRQ_STATUS_EVT_RX_START_ERR                (0x8)     /* [3] */
#define MSK_UART_IRQ_STATUS_EVT_RX_PAR_ERR                  (0x1)     /* [4] */
#define RES_UART_IRQ_STATUS_EVT_RX_PAR_ERR                  (0x0)
#define SFT_UART_IRQ_STATUS_EVT_RX_PAR_ERR                  (4)
#define LSB_UART_IRQ_STATUS_EVT_RX_PAR_ERR                  (4)
#define MSB_UART_IRQ_STATUS_EVT_RX_PAR_ERR                  (4)
#define BIT_UART_IRQ_STATUS_EVT_RX_PAR_ERR                  (0x10)    /* [4] */
#define MSK_UART_IRQ_STATUS_EVT_RX_STOP_ERR                 (0x1)     /* [5] */
#define RES_UART_IRQ_STATUS_EVT_RX_STOP_ERR                 (0x0)
#define SFT_UART_IRQ_STATUS_EVT_RX_STOP_ERR                 (5)
#define LSB_UART_IRQ_STATUS_EVT_RX_STOP_ERR                 (5)
#define MSB_UART_IRQ_STATUS_EVT_RX_STOP_ERR                 (5)
#define BIT_UART_IRQ_STATUS_EVT_RX_STOP_ERR                 (0x20)    /* [5] */
#define MSK_UART_IRQ_STATUS_RX_FIFO_NEMPTY                  (0x1)     /* [6] */
#define RES_UART_IRQ_STATUS_RX_FIFO_NEMPTY                  (0x0)
#define SFT_UART_IRQ_STATUS_RX_FIFO_NEMPTY                  (6)
#define LSB_UART_IRQ_STATUS_RX_FIFO_NEMPTY                  (6)
#define MSB_UART_IRQ_STATUS_RX_FIFO_NEMPTY                  (6)
#define BIT_UART_IRQ_STATUS_RX_FIFO_NEMPTY                  (0x40)    /* [6] */
#define MSK_UART_IRQ_STATUS_RX_FIFO_TIMEOUT                 (0x1)     /* [7] */
#define RES_UART_IRQ_STATUS_RX_FIFO_TIMEOUT                 (0x0)
#define SFT_UART_IRQ_STATUS_RX_FIFO_TIMEOUT                 (7)
#define LSB_UART_IRQ_STATUS_RX_FIFO_TIMEOUT                 (7)
#define MSB_UART_IRQ_STATUS_RX_FIFO_TIMEOUT                 (7)
#define BIT_UART_IRQ_STATUS_RX_FIFO_TIMEOUT                 (0x80)    /* [7] */
#define MSK_UART_IRQ_STATUS_RX_FIFO_HIGH_WATER              (0x1)     /* [8] */
#define RES_UART_IRQ_STATUS_RX_FIFO_HIGH_WATER              (0x0)
#define SFT_UART_IRQ_STATUS_RX_FIFO_HIGH_WATER              (8)
#define LSB_UART_IRQ_STATUS_RX_FIFO_HIGH_WATER              (8)
#define MSB_UART_IRQ_STATUS_RX_FIFO_HIGH_WATER              (8)
#define BIT_UART_IRQ_STATUS_RX_FIFO_HIGH_WATER              (0x100)   /* [8] */
#define MSK_UART_IRQ_STATUS_RX_FIFO_FULL                    (0x1)     /* [9] */
#define RES_UART_IRQ_STATUS_RX_FIFO_FULL                    (0x0)
#define SFT_UART_IRQ_STATUS_RX_FIFO_FULL                    (9)
#define LSB_UART_IRQ_STATUS_RX_FIFO_FULL                    (9)
#define MSB_UART_IRQ_STATUS_RX_FIFO_FULL                    (9)
#define BIT_UART_IRQ_STATUS_RX_FIFO_FULL                    (0x200)   /* [9] */
#define MSK_UART_IRQ_STATUS_TX_FIFO_EMPTY                   (0x1)     /* [10] */
#define RES_UART_IRQ_STATUS_TX_FIFO_EMPTY                   (0x1)
#define SFT_UART_IRQ_STATUS_TX_FIFO_EMPTY                   (10)
#define LSB_UART_IRQ_STATUS_TX_FIFO_EMPTY                   (10)
#define MSB_UART_IRQ_STATUS_TX_FIFO_EMPTY                   (10)
#define BIT_UART_IRQ_STATUS_TX_FIFO_EMPTY                   (0x400)   /* [10] */
#define MSK_UART_IRQ_STATUS_TX_FIFO_LOW_WATER               (0x1)     /* [11] */
#define RES_UART_IRQ_STATUS_TX_FIFO_LOW_WATER               (0x1)
#define SFT_UART_IRQ_STATUS_TX_FIFO_LOW_WATER               (11)
#define LSB_UART_IRQ_STATUS_TX_FIFO_LOW_WATER               (11)
#define MSB_UART_IRQ_STATUS_TX_FIFO_LOW_WATER               (11)
#define BIT_UART_IRQ_STATUS_TX_FIFO_LOW_WATER               (0x800)   /* [11] */
#define MSK_UART_IRQ_STATUS_TX_FIFO_NFULL                   (0x1)     /* [12] */
#define RES_UART_IRQ_STATUS_TX_FIFO_NFULL                   (0x1)
#define SFT_UART_IRQ_STATUS_TX_FIFO_NFULL                   (12)
#define LSB_UART_IRQ_STATUS_TX_FIFO_NFULL                   (12)
#define MSB_UART_IRQ_STATUS_TX_FIFO_NFULL                   (12)
#define BIT_UART_IRQ_STATUS_TX_FIFO_NFULL                   (0x1000)  /* [12] */
#define MSK_UART_IRQ_STATUS_TX_TRANSMITTING                 (0x1)     /* [13] */
#define RES_UART_IRQ_STATUS_TX_TRANSMITTING                 (0x0)
#define SFT_UART_IRQ_STATUS_TX_TRANSMITTING                 (13)
#define LSB_UART_IRQ_STATUS_TX_TRANSMITTING                 (13)
#define MSB_UART_IRQ_STATUS_TX_TRANSMITTING                 (13)
#define BIT_UART_IRQ_STATUS_TX_TRANSMITTING                 (0x2000)  /* [13] */


/* ############################################################################ */
/**
 * \brief UART IRQ
 *
 * \ingroup uart 
 */ 
typedef struct {
  /**
   * software did not read incoming data fast enough
   */ 
  unsigned short evt_rx_fifo_ov_err            :    1;       /* [0] */
  /**
   * software has read from empty receive fifo
   */ 
  unsigned short evt_rx_fifo_ur_err            :    1;       /* [1] */
  /**
   * software wrote data to full transmit fifo
   */ 
  unsigned short evt_tx_fifo_ov_err            :    1;       /* [2] */
  /**
   * start bit error
   */ 
  unsigned short evt_rx_start_err              :    1;       /* [3] */
  /**
   * parity error
   */ 
  unsigned short evt_rx_par_err                :    1;       /* [4] */
  /**
   * stop bit error
   */ 
  unsigned short evt_rx_stop_err               :    1;       /* [5] */
  /**
   * receive fifo is not empty
   */ 
  unsigned short rx_fifo_nempty                :    1;       /* [6] */
  /**
   * receive fifo timeout
   */ 
  unsigned short rx_fifo_timeout               :    1;       /* [7] */
  /**
   * receive fifo elements > high water level
   */ 
  unsigned short rx_fifo_high_water            :    1;       /* [8] */
  /**
   * receive fifo is full
   */ 
  unsigned short rx_fifo_full                  :    1;       /* [9] */
  /**
   * transmit fifo is empty
   */ 
  unsigned short tx_fifo_empty                 :    1;       /* [10] */
  /**
   * transmit fifo elements <= low water level
   */ 
  unsigned short tx_fifo_low_water             :    1;       /* [11] */
  /**
   * transmit fifo is not full
   */ 
  unsigned short tx_fifo_nfull                 :    1;       /* [12] */
  /**
   * the UART is transmitting (TX FIFO not empty or currently sending a byte)
   */ 
  unsigned short tx_transmitting               :    1;       /* [13] */

  unsigned short reserved                      :    2;
} uart_irq_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of UART IRQ
 *
 * \ingroup uart 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  uart_irq_status_bf bf;  ///< bit field representation
} uart_irq_status_t;


/* UART_IRQ_MASK */

#define MSK_UART_IRQ_MASK                                   (0x3fff)  /* [13:0] */

typedef unsigned short uart_irq_mask_t;                               /* [13:0] */


/* UART_IRQ_VENABLE */

#define MSK_UART_IRQ_VENABLE                                (0xf)     /* [ 3:0] */

typedef unsigned short uart_irq_venable_t;                            /* [ 3:0] */


/* UART_IRQ_VDISABLE */

#define MSK_UART_IRQ_VDISABLE                               (0xf)     /* [ 3:0] */

typedef unsigned short uart_irq_vdisable_t;                           /* [ 3:0] */


/* UART_IRQ_VMAX */

#define MSK_UART_IRQ_VMAX                                   (0xf)     /* [ 3:0] */

typedef unsigned short uart_irq_vmax_t;                               /* [ 3:0] */


/* UART_IRQ_VNO */

#define MSK_UART_IRQ_VNO                                    (0xf)     /* [ 3:0] */

typedef unsigned short uart_irq_vno_t;                                /* [ 3:0] */



// Register definitions for module
// Instance base address BASE_ADDR_UART 0x40006980U ... 

#define ADDR_UART_CONFIG                                     (0x00U)
#define A_UART_CONFIG(ba)                                    ((ba) + ADDR_UART_CONFIG)
#define R_UART_CONFIG(ba)                                    (*(volatile unsigned short *)((unsigned int)A_UART_CONFIG(ba)))
#define RES_UART_CONFIG                                      (0x0U)
#define MSB_UART_CONFIG                                      14
#define LSB_UART_CONFIG                                      0
#define AADDR_UART_CONFIG                                    (BASE_ADDR_UART + ADDR_UART_CONFIG)
#define REG_UART_CONFIG                                      (*(volatile unsigned short *)((unsigned int)AADDR_UART_CONFIG))

#define ADDR_UART_RX_FIFO_TIMEOUT                            (0x02U)
#define A_UART_RX_FIFO_TIMEOUT(ba)                           ((ba) + ADDR_UART_RX_FIFO_TIMEOUT)
#define R_UART_RX_FIFO_TIMEOUT(ba)                           (*(volatile unsigned short *)((unsigned int)A_UART_RX_FIFO_TIMEOUT(ba)))
#define RES_UART_RX_FIFO_TIMEOUT                             (0x0U)
#define MSB_UART_RX_FIFO_TIMEOUT                             15
#define LSB_UART_RX_FIFO_TIMEOUT                             0
#define AADDR_UART_RX_FIFO_TIMEOUT                           (BASE_ADDR_UART + ADDR_UART_RX_FIFO_TIMEOUT)
#define REG_UART_RX_FIFO_TIMEOUT                             (*(volatile unsigned short *)((unsigned int)AADDR_UART_RX_FIFO_TIMEOUT))

#define ADDR_UART_BAUDRATE_LW                                (0x04U)
#define A_UART_BAUDRATE_LW(ba)                               ((ba) + ADDR_UART_BAUDRATE_LW)
#define R_UART_BAUDRATE_LW(ba)                               (*(volatile unsigned short *)((unsigned int)A_UART_BAUDRATE_LW(ba)))
#define RES_UART_BAUDRATE_LW                                 (0x0U)
#define MSB_UART_BAUDRATE_LW                                 15
#define LSB_UART_BAUDRATE_LW                                 0
#define AADDR_UART_BAUDRATE_LW                               (BASE_ADDR_UART + ADDR_UART_BAUDRATE_LW)
#define REG_UART_BAUDRATE_LW                                 (*(volatile unsigned short *)((unsigned int)AADDR_UART_BAUDRATE_LW))

#define ADDR_UART_BAUDRATE_HW                                (0x06U)
#define A_UART_BAUDRATE_HW(ba)                               ((ba) + ADDR_UART_BAUDRATE_HW)
#define R_UART_BAUDRATE_HW(ba)                               (*(volatile unsigned short *)((unsigned int)A_UART_BAUDRATE_HW(ba)))
#define RES_UART_BAUDRATE_HW                                 (0x0U)
#define MSB_UART_BAUDRATE_HW                                 7
#define LSB_UART_BAUDRATE_HW                                 0
#define AADDR_UART_BAUDRATE_HW                               (BASE_ADDR_UART + ADDR_UART_BAUDRATE_HW)
#define REG_UART_BAUDRATE_HW                                 (*(volatile unsigned short *)((unsigned int)AADDR_UART_BAUDRATE_HW))

#define ADDR_UART_FIFO_CLEAR_CMD                             (0x08U)
#define A_UART_FIFO_CLEAR_CMD(ba)                            ((ba) + ADDR_UART_FIFO_CLEAR_CMD)
#define R_UART_FIFO_CLEAR_CMD(ba)                            (*(volatile unsigned short *)((unsigned int)A_UART_FIFO_CLEAR_CMD(ba)))
#define RES_UART_FIFO_CLEAR_CMD                              (0x0U)
#define MSB_UART_FIFO_CLEAR_CMD                              1
#define LSB_UART_FIFO_CLEAR_CMD                              0
#define AADDR_UART_FIFO_CLEAR_CMD                            (BASE_ADDR_UART + ADDR_UART_FIFO_CLEAR_CMD)
#define REG_UART_FIFO_CLEAR_CMD                              (*(volatile unsigned short *)((unsigned int)AADDR_UART_FIFO_CLEAR_CMD))

#define ADDR_UART_RX_DATA                                    (0x0AU)
#define A_UART_RX_DATA(ba)                                   ((ba) + ADDR_UART_RX_DATA)
#define R_UART_RX_DATA(ba)                                   (*(volatile unsigned short *)((unsigned int)A_UART_RX_DATA(ba)))
#define RES_UART_RX_DATA                                     (0x0U)
#define MSB_UART_RX_DATA                                     8
#define LSB_UART_RX_DATA                                     0
#define AADDR_UART_RX_DATA                                   (BASE_ADDR_UART + ADDR_UART_RX_DATA)
#define REG_UART_RX_DATA                                     (*(volatile unsigned short *)((unsigned int)AADDR_UART_RX_DATA))

#define ADDR_UART_TX_DATA                                    (0x0CU)
#define A_UART_TX_DATA(ba)                                   ((ba) + ADDR_UART_TX_DATA)
#define R_UART_TX_DATA(ba)                                   (*(volatile unsigned short *)((unsigned int)A_UART_TX_DATA(ba)))
#define RES_UART_TX_DATA                                     (0x0U)
#define MSB_UART_TX_DATA                                     7
#define LSB_UART_TX_DATA                                     0
#define AADDR_UART_TX_DATA                                   (BASE_ADDR_UART + ADDR_UART_TX_DATA)
#define REG_UART_TX_DATA                                     (*(volatile unsigned short *)((unsigned int)AADDR_UART_TX_DATA))

#define ADDR_UART_FIFO_LEVELS                                (0x0EU)
#define A_UART_FIFO_LEVELS(ba)                               ((ba) + ADDR_UART_FIFO_LEVELS)
#define R_UART_FIFO_LEVELS(ba)                               (*(volatile unsigned short *)((unsigned int)A_UART_FIFO_LEVELS(ba)))
#define RES_UART_FIFO_LEVELS                                 (0x0U)
#define MSB_UART_FIFO_LEVELS                                 7
#define LSB_UART_FIFO_LEVELS                                 0
#define AADDR_UART_FIFO_LEVELS                               (BASE_ADDR_UART + ADDR_UART_FIFO_LEVELS)
#define REG_UART_FIFO_LEVELS                                 (*(volatile unsigned short *)((unsigned int)AADDR_UART_FIFO_LEVELS))

#define ADDR_UART_MIN_BIT_LENGTH_LW                          (0x10U)
#define A_UART_MIN_BIT_LENGTH_LW(ba)                         ((ba) + ADDR_UART_MIN_BIT_LENGTH_LW)
#define R_UART_MIN_BIT_LENGTH_LW(ba)                         (*(volatile unsigned short *)((unsigned int)A_UART_MIN_BIT_LENGTH_LW(ba)))
#define RES_UART_MIN_BIT_LENGTH_LW                           (0xffffU)
#define MSB_UART_MIN_BIT_LENGTH_LW                           15
#define LSB_UART_MIN_BIT_LENGTH_LW                           0
#define AADDR_UART_MIN_BIT_LENGTH_LW                         (BASE_ADDR_UART + ADDR_UART_MIN_BIT_LENGTH_LW)
#define REG_UART_MIN_BIT_LENGTH_LW                           (*(volatile unsigned short *)((unsigned int)AADDR_UART_MIN_BIT_LENGTH_LW))

#define ADDR_UART_MIN_BIT_LENGTH_HW                          (0x12U)
#define A_UART_MIN_BIT_LENGTH_HW(ba)                         ((ba) + ADDR_UART_MIN_BIT_LENGTH_HW)
#define R_UART_MIN_BIT_LENGTH_HW(ba)                         (*(volatile unsigned short *)((unsigned int)A_UART_MIN_BIT_LENGTH_HW(ba)))
#define RES_UART_MIN_BIT_LENGTH_HW                           (0x3fU)
#define MSB_UART_MIN_BIT_LENGTH_HW                           5
#define LSB_UART_MIN_BIT_LENGTH_HW                           0
#define AADDR_UART_MIN_BIT_LENGTH_HW                         (BASE_ADDR_UART + ADDR_UART_MIN_BIT_LENGTH_HW)
#define REG_UART_MIN_BIT_LENGTH_HW                           (*(volatile unsigned short *)((unsigned int)AADDR_UART_MIN_BIT_LENGTH_HW))

#define ADDR_UART_IRQ_STATUS                                 (0x14U)
#define A_UART_IRQ_STATUS(ba)                                ((ba) + ADDR_UART_IRQ_STATUS)
#define R_UART_IRQ_STATUS(ba)                                (*(volatile unsigned short *)((unsigned int)A_UART_IRQ_STATUS(ba)))
#define RES_UART_IRQ_STATUS                                  (0x1c00U)
#define MSB_UART_IRQ_STATUS                                  13
#define LSB_UART_IRQ_STATUS                                  0
#define AADDR_UART_IRQ_STATUS                                (BASE_ADDR_UART + ADDR_UART_IRQ_STATUS)
#define REG_UART_IRQ_STATUS                                  (*(volatile unsigned short *)((unsigned int)AADDR_UART_IRQ_STATUS))

#define ADDR_UART_IRQ_MASK                                   (0x18U)
#define A_UART_IRQ_MASK(ba)                                  ((ba) + ADDR_UART_IRQ_MASK)
#define R_UART_IRQ_MASK(ba)                                  (*(volatile unsigned short *)((unsigned int)A_UART_IRQ_MASK(ba)))
#define RES_UART_IRQ_MASK                                    (0x0U)
#define MSB_UART_IRQ_MASK                                    13
#define LSB_UART_IRQ_MASK                                    0
#define AADDR_UART_IRQ_MASK                                  (BASE_ADDR_UART + ADDR_UART_IRQ_MASK)
#define REG_UART_IRQ_MASK                                    (*(volatile unsigned short *)((unsigned int)AADDR_UART_IRQ_MASK))

#define ADDR_UART_IRQ_VENABLE                                (0x1CU)
#define A_UART_IRQ_VENABLE(ba)                               ((ba) + ADDR_UART_IRQ_VENABLE)
#define R_UART_IRQ_VENABLE(ba)                               (*(volatile unsigned short *)((unsigned int)A_UART_IRQ_VENABLE(ba)))
#define RES_UART_IRQ_VENABLE                                 (0x0U)
#define MSB_UART_IRQ_VENABLE                                 3
#define LSB_UART_IRQ_VENABLE                                 0
#define AADDR_UART_IRQ_VENABLE                               (BASE_ADDR_UART + ADDR_UART_IRQ_VENABLE)
#define REG_UART_IRQ_VENABLE                                 (*(volatile unsigned short *)((unsigned int)AADDR_UART_IRQ_VENABLE))

#define ADDR_UART_IRQ_VDISABLE                               (0x1EU)
#define A_UART_IRQ_VDISABLE(ba)                              ((ba) + ADDR_UART_IRQ_VDISABLE)
#define R_UART_IRQ_VDISABLE(ba)                              (*(volatile unsigned short *)((unsigned int)A_UART_IRQ_VDISABLE(ba)))
#define RES_UART_IRQ_VDISABLE                                (0x0U)
#define MSB_UART_IRQ_VDISABLE                                3
#define LSB_UART_IRQ_VDISABLE                                0
#define AADDR_UART_IRQ_VDISABLE                              (BASE_ADDR_UART + ADDR_UART_IRQ_VDISABLE)
#define REG_UART_IRQ_VDISABLE                                (*(volatile unsigned short *)((unsigned int)AADDR_UART_IRQ_VDISABLE))

#define ADDR_UART_IRQ_VMAX                                   (0x20U)
#define A_UART_IRQ_VMAX(ba)                                  ((ba) + ADDR_UART_IRQ_VMAX)
#define R_UART_IRQ_VMAX(ba)                                  (*(volatile unsigned short *)((unsigned int)A_UART_IRQ_VMAX(ba)))
#define RES_UART_IRQ_VMAX                                    (0xeU)
#define MSB_UART_IRQ_VMAX                                    3
#define LSB_UART_IRQ_VMAX                                    0
#define AADDR_UART_IRQ_VMAX                                  (BASE_ADDR_UART + ADDR_UART_IRQ_VMAX)
#define REG_UART_IRQ_VMAX                                    (*(volatile unsigned short *)((unsigned int)AADDR_UART_IRQ_VMAX))

#define ADDR_UART_IRQ_VNO                                    (0x22U)
#define A_UART_IRQ_VNO(ba)                                   ((ba) + ADDR_UART_IRQ_VNO)
#define R_UART_IRQ_VNO(ba)                                   (*(volatile unsigned short *)((unsigned int)A_UART_IRQ_VNO(ba)))
#define RES_UART_IRQ_VNO                                     (0xeU)
#define MSB_UART_IRQ_VNO                                     3
#define LSB_UART_IRQ_VNO                                     0
#define AADDR_UART_IRQ_VNO                                   (BASE_ADDR_UART + ADDR_UART_IRQ_VNO)
#define REG_UART_IRQ_VNO                                     (*(volatile unsigned short *)((unsigned int)AADDR_UART_IRQ_VNO))




#endif
