#include "hardware.h"
#include "uart_api.h"
#include "clk_nres_api.h"


void uart_api_init_baudrate ( uint32_t baudrate )
{
  uint32_t clk;
  uint16_t divider;
  uint16_t fractional;

  if(clk_nres_api_get_module_clock(CLKPNO_UART, &clk)!=eError_none) {
    // No correct clock freq. value get for UART */
    while(1);
  }

  divider = ( clk / baudrate ) - 1;
  fractional = ( ( ( clk * 4 ) / baudrate ) ) & 0x3;

  uart_init(UART, divider, fractional, UART_DATA_LEN_8, UART_PARITY_NONE, UART_ONE_STOP);
  
}