/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         vic_ext_bf.h
*
* @brief        External Processor Interrupt Controller (VIC_EXT) HAL functions
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/
#ifndef __VIC_EXT_BF_H__
#define __VIC_EXT_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_VIC_EXT
#define BASE_ADDR_VIC_EXT 0x40007880U
#endif

#define NUMBER_VIC_EXT 1

typedef enum {
  VIC_EXT                        = (int)BASE_ADDR_VIC_EXT
} vic_ext_num_t;

// Register bit field definitions

/* VIC_EXT_MAIN_ENABLE */

#define MSK_VIC_EXT_MAIN_ENABLE                             (0x1)     /* [0] */

typedef unsigned short vic_ext_main_enable_t;                         /* [0] */


/* VIC_EXT_IRQ_POLARITY */

#define MSK_VIC_EXT_IRQ_POLARITY                            (0x1)     /* [0] */

typedef unsigned short vic_ext_irq_polarity_t;                        /* [0] */


/* VIC_EXT_IRQ_STATUS0 */

#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_CLK_NRES_0              (0x1)     /* [0] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_CLK_NRES_0              (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_CLK_NRES_0              (0)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_CLK_NRES_0              (0)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_CLK_NRES_0              (0)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_CLK_NRES_0              (0x1)     /* [0] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER0                (0x1)     /* [1] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER0                (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER0                (1)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER0                (1)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER0                (1)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER0                (0x2)     /* [1] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_TSU                     (0x1)     /* [2] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_TSU                     (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_TSU                     (2)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_TSU                     (2)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_TSU                     (2)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_TSU                     (0x4)     /* [2] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_SWD                     (0x1)     /* [3] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_SWD                     (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_SWD                     (3)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_SWD                     (3)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_SWD                     (3)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_SWD                     (0x8)     /* [3] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_HV_CTRL                 (0x1)     /* [4] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_HV_CTRL                 (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_HV_CTRL                 (4)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_HV_CTRL                 (4)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_HV_CTRL                 (4)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_HV_CTRL                 (0x10)    /* [4] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_0             (0x1)     /* [5] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_0             (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_0             (5)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_0             (5)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_0             (5)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_0             (0x20)    /* [5] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_EL_CTRL                 (0x1)     /* [6] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_EL_CTRL                 (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_EL_CTRL                 (6)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_EL_CTRL                 (6)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_EL_CTRL                 (6)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_EL_CTRL                 (0x40)    /* [6] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER1                (0x1)     /* [7] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER1                (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER1                (7)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER1                (7)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER1                (7)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_SWTIMER1                (0x80)    /* [7] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_HISPI                   (0x1)     /* [8] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_HISPI                   (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_HISPI                   (8)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_HISPI                   (8)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_HISPI                   (8)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_HISPI                   (0x100)   /* [8] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_UART                    (0x1)     /* [9] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_UART                    (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_UART                    (9)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_UART                    (9)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_UART                    (9)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_UART                    (0x200)   /* [9] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_CRC0                    (0x1)     /* [10] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_CRC0                    (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_CRC0                    (10)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_CRC0                    (10)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_CRC0                    (10)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_CRC0                    (0x400)   /* [10] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_CRC1                    (0x1)     /* [11] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_CRC1                    (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_CRC1                    (11)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_CRC1                    (11)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_CRC1                    (11)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_CRC1                    (0x800)   /* [11] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_GPIO                    (0x1)     /* [12] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_GPIO                    (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_GPIO                    (12)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_GPIO                    (12)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_GPIO                    (12)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_GPIO                    (0x1000)  /* [12] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_SARADC_CTRL             (0x1)     /* [13] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_SARADC_CTRL             (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_SARADC_CTRL             (13)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_SARADC_CTRL             (13)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_SARADC_CTRL             (13)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_SARADC_CTRL             (0x2000)  /* [13] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_1             (0x1)     /* [14] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_1             (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_1             (14)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_1             (14)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_1             (14)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_CPU_N_CPU_1             (0x4000)  /* [14] */
#define MSK_VIC_EXT_IRQ_STATUS0_IRQ_PWMN                    (0x1)     /* [15] */
#define RES_VIC_EXT_IRQ_STATUS0_IRQ_PWMN                    (0x0)
#define SFT_VIC_EXT_IRQ_STATUS0_IRQ_PWMN                    (15)
#define LSB_VIC_EXT_IRQ_STATUS0_IRQ_PWMN                    (15)
#define MSB_VIC_EXT_IRQ_STATUS0_IRQ_PWMN                    (15)
#define BIT_VIC_EXT_IRQ_STATUS0_IRQ_PWMN                    (0x8000)  /* [15] */

/** 
 * \brief This structure describes VIC_EXT interrupt mask0 
 *
 * \ingroup vic_ext
 */
typedef struct {
  unsigned short irq_clk_nres_0                :    1;       ///< interrupt mask clk_nres_0
  unsigned short irq_swtimer0                  :    1;       ///< interrupt mask swtimer0
  unsigned short irq_tsu                       :    1;       ///< interrupt mask tsu
  unsigned short irq_swd                       :    1;       ///< interrupt mask swd
  unsigned short irq_hv_ctrl                   :    1;       ///< interrupt mask hv_ctrl
  unsigned short irq_cpu_n_cpu_0               :    1;       ///< interrupt mask cpu_n_cpu_0
  unsigned short irq_el_ctrl                   :    1;       ///< interrupt mask el_ctrl
  unsigned short irq_swtimer1                  :    1;       ///< interrupt mask swtimer1
  unsigned short irq_hispi                     :    1;       ///< interrupt mask hispi
  unsigned short irq_uart                      :    1;       ///< interrupt mask uart
  unsigned short irq_crc0                      :    1;       ///< interrupt mask crc0
  unsigned short irq_crc1                      :    1;       ///< interrupt mask crc1
  unsigned short irq_gpio                      :    1;       ///< interrupt mask gpio
  unsigned short irq_saradc_ctrl               :    1;       ///< interrupt mask saradc_ctrl
  unsigned short irq_cpu_n_cpu_1               :    1;       ///< interrupt mask cpu_n_cpu_1 
  unsigned short irq_pwmn                      :    1;       ///< interrupt mask pwmn 
} vic_ext_irq_status0_bf;

/**
 * \brief Conversion type between word and bit representation of VIC_EXT interrupt
 *        mask for STATUS0
 *
 * \ingroup vic_ext
 */
typedef union {
  unsigned short val;        ///< word representation
  vic_ext_irq_status0_bf bf; ///< bit field representation
} vic_ext_irq_status0_t;


/* VIC_EXT_IRQ_STATUS1 */

#define MSK_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER0                (0x1)     /* [0] */
#define RES_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER0                (0x0)
#define SFT_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER0                (0)
#define LSB_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER0                (0)
#define MSB_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER0                (0)
#define BIT_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER0                (0x1)     /* [0] */
#define MSK_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER1                (0x1)     /* [1] */
#define RES_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER1                (0x0)
#define SFT_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER1                (1)
#define LSB_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER1                (1)
#define MSB_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER1                (1)
#define BIT_VIC_EXT_IRQ_STATUS1_IRQ_CCTIMER1                (0x2)     /* [1] */
#define MSK_VIC_EXT_IRQ_STATUS1_IRQ_USI0                    (0x1)     /* [2] */
#define RES_VIC_EXT_IRQ_STATUS1_IRQ_USI0                    (0x0)
#define SFT_VIC_EXT_IRQ_STATUS1_IRQ_USI0                    (2)
#define LSB_VIC_EXT_IRQ_STATUS1_IRQ_USI0                    (2)
#define MSB_VIC_EXT_IRQ_STATUS1_IRQ_USI0                    (2)
#define BIT_VIC_EXT_IRQ_STATUS1_IRQ_USI0                    (0x4)     /* [2] */
#define MSK_VIC_EXT_IRQ_STATUS1_IRQ_USI1                    (0x1)     /* [3] */
#define RES_VIC_EXT_IRQ_STATUS1_IRQ_USI1                    (0x0)
#define SFT_VIC_EXT_IRQ_STATUS1_IRQ_USI1                    (3)
#define LSB_VIC_EXT_IRQ_STATUS1_IRQ_USI1                    (3)
#define MSB_VIC_EXT_IRQ_STATUS1_IRQ_USI1                    (3)
#define BIT_VIC_EXT_IRQ_STATUS1_IRQ_USI1                    (0x8)     /* [3] */
#define MSK_VIC_EXT_IRQ_STATUS1_IRQ_I2C                     (0x1)     /* [4] */
#define RES_VIC_EXT_IRQ_STATUS1_IRQ_I2C                     (0x0)
#define SFT_VIC_EXT_IRQ_STATUS1_IRQ_I2C                     (4)
#define LSB_VIC_EXT_IRQ_STATUS1_IRQ_I2C                     (4)
#define MSB_VIC_EXT_IRQ_STATUS1_IRQ_I2C                     (4)
#define BIT_VIC_EXT_IRQ_STATUS1_IRQ_I2C                     (0x10)    /* [4] */
#define MSK_VIC_EXT_IRQ_STATUS1_IRQ_CPU_N_CPU_EXT           (0x1)     /* [5] */
#define RES_VIC_EXT_IRQ_STATUS1_IRQ_CPU_N_CPU_EXT           (0x0)
#define SFT_VIC_EXT_IRQ_STATUS1_IRQ_CPU_N_CPU_EXT           (5)
#define LSB_VIC_EXT_IRQ_STATUS1_IRQ_CPU_N_CPU_EXT           (5)
#define MSB_VIC_EXT_IRQ_STATUS1_IRQ_CPU_N_CPU_EXT           (5)
#define BIT_VIC_EXT_IRQ_STATUS1_IRQ_CPU_N_CPU_EXT           (0x20)    /* [5] */

/** 
 * \brief This structure describes VIC_EXT interrupt mask1
 *
 * \ingroup vic_ext
 */
typedef struct {
  unsigned short irq_cctimer0                  :    1;       ///< interrupt mask cctimer0
  unsigned short irq_cctimer1                  :    1;       ///< interrupt mask cctimer1
  unsigned short irq_usi0                      :    1;       ///< interrupt mask usi0
  unsigned short irq_usi1                      :    1;       ///< interrupt mask usi1
  unsigned short irq_i2c                       :    1;       ///< interrupt mask i2c
  unsigned short irq_cpu_n_cpu_ext             :    1;       ///< interrupt mask cpu_n_cpu_ext
  unsigned short reserved                      :   10;
} vic_ext_irq_status1_bf;

/**
 * \brief Conversion type between word and bit representation of VIC_EXT interrupt
 *        mask for STATUS1
 *
 * \ingroup vic_ext
 */
typedef union {
  unsigned short val;
  vic_ext_irq_status1_bf bf;
} vic_ext_irq_status1_t;


/* VIC_EXT_IRQ_MASK */

#define MSK_VIC_EXT_IRQ_MASK                                (0xffff)  /* [15:0] */

typedef unsigned short vic_ext_irq_mask_t;                            /* [15:0] */


/* VIC_EXT_IRQ_VENABLE */

#define MSK_VIC_EXT_IRQ_VENABLE                             (0x3f)    /* [ 5:0] */

typedef unsigned short vic_ext_irq_venable_t;                         /* [ 5:0] */


/* VIC_EXT_IRQ_VDISABLE */

#define MSK_VIC_EXT_IRQ_VDISABLE                            (0x1f)    /* [ 4:0] */

typedef unsigned short vic_ext_irq_vdisable_t;                        /* [ 4:0] */


/* VIC_EXT_IRQ_VMAX */

#define MSK_VIC_EXT_IRQ_VMAX                                (0x1f)    /* [ 4:0] */

typedef unsigned short vic_ext_irq_vmax_t;                            /* [ 4:0] */


/* VIC_EXT_IRQ_VNO */

#define MSK_VIC_EXT_IRQ_VNO                                 (0x1f)    /* [ 4:0] */

typedef unsigned short vic_ext_irq_vno_t;                             /* [ 4:0] */



// Register definitions for module
// Instance base address BASE_ADDR_VIC_EXT 0x40007880U ... 

#define ADDR_VIC_EXT_MAIN_ENABLE                             (0x00U)
#define A_VIC_EXT_MAIN_ENABLE(ba)                            ((ba) + ADDR_VIC_EXT_MAIN_ENABLE)
#define R_VIC_EXT_MAIN_ENABLE(ba)                            (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_MAIN_ENABLE(ba)))
#define RES_VIC_EXT_MAIN_ENABLE                              (0x1U)
#define MSB_VIC_EXT_MAIN_ENABLE                              0
#define LSB_VIC_EXT_MAIN_ENABLE                              0
#define AADDR_VIC_EXT_MAIN_ENABLE                            (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_MAIN_ENABLE)
#define REG_VIC_EXT_MAIN_ENABLE                              (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_MAIN_ENABLE))

#define ADDR_VIC_EXT_IRQ_POLARITY                            (0x02U)
#define A_VIC_EXT_IRQ_POLARITY(ba)                           ((ba) + ADDR_VIC_EXT_IRQ_POLARITY)
#define R_VIC_EXT_IRQ_POLARITY(ba)                           (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_IRQ_POLARITY(ba)))
#define RES_VIC_EXT_IRQ_POLARITY                             (0x0U)
#define MSB_VIC_EXT_IRQ_POLARITY                             0
#define LSB_VIC_EXT_IRQ_POLARITY                             0
#define AADDR_VIC_EXT_IRQ_POLARITY                           (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_IRQ_POLARITY)
#define REG_VIC_EXT_IRQ_POLARITY                             (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_IRQ_POLARITY))

#define ADDR_VIC_EXT_IRQ_STATUS0                             (0x04U)
#define A_VIC_EXT_IRQ_STATUS0(ba)                            ((ba) + ADDR_VIC_EXT_IRQ_STATUS0)
#define R_VIC_EXT_IRQ_STATUS0(ba)                            (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_IRQ_STATUS0(ba)))
#define RES_VIC_EXT_IRQ_STATUS0                              (0x0U)
#define MSB_VIC_EXT_IRQ_STATUS0                              15
#define LSB_VIC_EXT_IRQ_STATUS0                              0
#define AADDR_VIC_EXT_IRQ_STATUS0                            (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_IRQ_STATUS0)
#define REG_VIC_EXT_IRQ_STATUS0                              (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_IRQ_STATUS0))

#define ADDR_VIC_EXT_IRQ_STATUS1                             (0x06U)
#define A_VIC_EXT_IRQ_STATUS1(ba)                            ((ba) + ADDR_VIC_EXT_IRQ_STATUS1)
#define R_VIC_EXT_IRQ_STATUS1(ba)                            (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_IRQ_STATUS1(ba)))
#define RES_VIC_EXT_IRQ_STATUS1                              (0x0U)
#define MSB_VIC_EXT_IRQ_STATUS1                              5
#define LSB_VIC_EXT_IRQ_STATUS1                              0
#define AADDR_VIC_EXT_IRQ_STATUS1                            (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_IRQ_STATUS1)
#define REG_VIC_EXT_IRQ_STATUS1                              (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_IRQ_STATUS1))

#define ADDR_VIC_EXT_IRQ_MASK0                               (0x08U)
#define A_VIC_EXT_IRQ_MASK0(ba)                              ((ba) + ADDR_VIC_EXT_IRQ_MASK0)
#define R_VIC_EXT_IRQ_MASK0(ba)                              (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_IRQ_MASK0(ba)))
#define RES_VIC_EXT_IRQ_MASK0                                (0x0U)
#define MSB_VIC_EXT_IRQ_MASK0                                15
#define LSB_VIC_EXT_IRQ_MASK0                                0
#define AADDR_VIC_EXT_IRQ_MASK0                              (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_IRQ_MASK0)
#define REG_VIC_EXT_IRQ_MASK0                                (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_IRQ_MASK0))

#define ADDR_VIC_EXT_IRQ_MASK1                               (0x0AU)
#define A_VIC_EXT_IRQ_MASK1(ba)                              ((ba) + ADDR_VIC_EXT_IRQ_MASK1)
#define R_VIC_EXT_IRQ_MASK1(ba)                              (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_IRQ_MASK1(ba)))
#define RES_VIC_EXT_IRQ_MASK1                                (0x0U)
#define MSB_VIC_EXT_IRQ_MASK1                                15
#define LSB_VIC_EXT_IRQ_MASK1                                0
#define AADDR_VIC_EXT_IRQ_MASK1                              (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_IRQ_MASK1)
#define REG_VIC_EXT_IRQ_MASK1                                (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_IRQ_MASK1))

#define ADDR_VIC_EXT_IRQ_VENABLE                             (0x0CU)
#define A_VIC_EXT_IRQ_VENABLE(ba)                            ((ba) + ADDR_VIC_EXT_IRQ_VENABLE)
#define R_VIC_EXT_IRQ_VENABLE(ba)                            (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_IRQ_VENABLE(ba)))
#define RES_VIC_EXT_IRQ_VENABLE                              (0x0U)
#define MSB_VIC_EXT_IRQ_VENABLE                              5
#define LSB_VIC_EXT_IRQ_VENABLE                              0
#define AADDR_VIC_EXT_IRQ_VENABLE                            (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_IRQ_VENABLE)
#define REG_VIC_EXT_IRQ_VENABLE                              (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_IRQ_VENABLE))

#define ADDR_VIC_EXT_IRQ_VDISABLE                            (0x0EU)
#define A_VIC_EXT_IRQ_VDISABLE(ba)                           ((ba) + ADDR_VIC_EXT_IRQ_VDISABLE)
#define R_VIC_EXT_IRQ_VDISABLE(ba)                           (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_IRQ_VDISABLE(ba)))
#define RES_VIC_EXT_IRQ_VDISABLE                             (0x0U)
#define MSB_VIC_EXT_IRQ_VDISABLE                             4
#define LSB_VIC_EXT_IRQ_VDISABLE                             0
#define AADDR_VIC_EXT_IRQ_VDISABLE                           (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_IRQ_VDISABLE)
#define REG_VIC_EXT_IRQ_VDISABLE                             (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_IRQ_VDISABLE))

#define ADDR_VIC_EXT_IRQ_VMAX                                (0x10U)
#define A_VIC_EXT_IRQ_VMAX(ba)                               ((ba) + ADDR_VIC_EXT_IRQ_VMAX)
#define R_VIC_EXT_IRQ_VMAX(ba)                               (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_IRQ_VMAX(ba)))
#define RES_VIC_EXT_IRQ_VMAX                                 (0x16U)
#define MSB_VIC_EXT_IRQ_VMAX                                 4
#define LSB_VIC_EXT_IRQ_VMAX                                 0
#define AADDR_VIC_EXT_IRQ_VMAX                               (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_IRQ_VMAX)
#define REG_VIC_EXT_IRQ_VMAX                                 (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_IRQ_VMAX))

#define ADDR_VIC_EXT_IRQ_VNO                                 (0x12U)
#define A_VIC_EXT_IRQ_VNO(ba)                                ((ba) + ADDR_VIC_EXT_IRQ_VNO)
#define R_VIC_EXT_IRQ_VNO(ba)                                (*(volatile unsigned short *)((unsigned int)A_VIC_EXT_IRQ_VNO(ba)))
#define RES_VIC_EXT_IRQ_VNO                                  (0x16U)
#define MSB_VIC_EXT_IRQ_VNO                                  4
#define LSB_VIC_EXT_IRQ_VNO                                  0
#define AADDR_VIC_EXT_IRQ_VNO                                (BASE_ADDR_VIC_EXT + ADDR_VIC_EXT_IRQ_VNO)
#define REG_VIC_EXT_IRQ_VNO                                  (*(volatile unsigned short *)((unsigned int)AADDR_VIC_EXT_IRQ_VNO))




#endif
