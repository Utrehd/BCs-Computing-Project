/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hv_ctrl_irq.h
*
* @brief        HV Die Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HV_CTRL_IRQ_H__
#define __HV_CTRL_IRQ_H__

#define HV_CTRL_NUM_IRQS 4


/* ############################################################################ */
/**
 * \brief List of HV CONTROL Interrupt sources 
 *
 * \ingroup hv_ctrl 
 */ 
typedef enum{
  /**
   * HV irq signal
   */ 
  HV_CTRL_IRQ_EVT_TDO_IRQ =             0,
  /**
   * JTAG idle
   */ 
  HV_CTRL_IRQ_JTAG_IDLE =               1,
  /**
   * request by CPU
   */ 
  HV_CTRL_IRQ_CPU_REQUEST =             2,
  /**
   * request by EL port
   */ 
  HV_CTRL_IRQ_EL_REQUEST =              3
} hv_ctrl_irq_t;

#endif
