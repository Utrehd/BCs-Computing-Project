/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         cctimer32_bf.h
*
* @brief        Capture and Compare Timer 32 (CCTIMER32) HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CCTIMER32_BF_H__
#define __CCTIMER32_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_CCTIMER0
#define BASE_ADDR_CCTIMER0 0x40006F00U
#endif
#ifndef BASE_ADDR_CCTIMER1
#define BASE_ADDR_CCTIMER1 0x40006F80U
#endif

#define MULTIPLE_CCTIMER32
#define NUMBER_CCTIMER32 2

/**
  * \brief This is an enum class for CCTIMER32 instance
  *
  * \ingroup cctimer32
  */ 
typedef enum {
  CCTIMER0                       = (int)BASE_ADDR_CCTIMER0, ///< this is instance CCTIMER0
  CCTIMER1                       = (int)BASE_ADDR_CCTIMER1 ///< this is instance CCTIMER1
} cctimer32_num_t;

// Register bit field definitions

/* CCTIMER32_PS */

#define MSK_CCTIMER32_PS_PRESCALER                          (0xff)    /* [ 7:0] */
#define RES_CCTIMER32_PS_PRESCALER                          (0x00)
#define SFT_CCTIMER32_PS_PRESCALER                          (0)
#define LSB_CCTIMER32_PS_PRESCALER                          (0)
#define MSB_CCTIMER32_PS_PRESCALER                          (7)
#define MSK_CCTIMER32_PS_RELOAD                             (0xff)    /* [15:8] */
#define RES_CCTIMER32_PS_RELOAD                             (0x00)
#define SFT_CCTIMER32_PS_RELOAD                             (8)
#define LSB_CCTIMER32_PS_RELOAD                             (8)
#define MSB_CCTIMER32_PS_RELOAD                             (15)

/** 
 * \brief This structure describes CCTIMER32 prescaler 
 *
 * \ingroup cctimer32
 */
typedef struct {
  unsigned short prescaler                     :    8; ///< current prescaler value
  unsigned short reload                        :    8; ///< reload value for counter clock prescale value (clock prediv by val+1)
} cctimer32_ps_bf;

/**
 * \brief Conversion type between word and bit representation of CCTIMER32 prescaler
 *
 * \ingroup cctimer32
 */
typedef union {
  unsigned short val;
  cctimer32_ps_bf bf;
} cctimer32_ps_t;


/* CCTIMER32_PSR */

#define MSK_CCTIMER32_PSR                                   (0xff)    /* [ 7:0] */

typedef unsigned short cctimer32_psr_t;                               /* [ 7:0] */


/* CCTIMER32_CONTROL */

#define MSK_CCTIMER32_CONTROL_ENABLE_A                      (0x1)     /* [0] */
#define RES_CCTIMER32_CONTROL_ENABLE_A                      (0x0)
#define SFT_CCTIMER32_CONTROL_ENABLE_A                      (0)
#define LSB_CCTIMER32_CONTROL_ENABLE_A                      (0)
#define MSB_CCTIMER32_CONTROL_ENABLE_A                      (0)
#define BIT_CCTIMER32_CONTROL_ENABLE_A                      (0x1)     /* [0] */
#define MSK_CCTIMER32_CONTROL_ENABLE_B                      (0x1)     /* [1] */
#define RES_CCTIMER32_CONTROL_ENABLE_B                      (0x0)
#define SFT_CCTIMER32_CONTROL_ENABLE_B                      (1)
#define LSB_CCTIMER32_CONTROL_ENABLE_B                      (1)
#define MSB_CCTIMER32_CONTROL_ENABLE_B                      (1)
#define BIT_CCTIMER32_CONTROL_ENABLE_B                      (0x2)     /* [1] */
#define MSK_CCTIMER32_CONTROL_ENABLE_C                      (0x1)     /* [2] */
#define RES_CCTIMER32_CONTROL_ENABLE_C                      (0x0)
#define SFT_CCTIMER32_CONTROL_ENABLE_C                      (2)
#define LSB_CCTIMER32_CONTROL_ENABLE_C                      (2)
#define MSB_CCTIMER32_CONTROL_ENABLE_C                      (2)
#define BIT_CCTIMER32_CONTROL_ENABLE_C                      (0x4)     /* [2] */
#define MSK_CCTIMER32_CONTROL_ENABLE_D                      (0x1)     /* [3] */
#define RES_CCTIMER32_CONTROL_ENABLE_D                      (0x0)
#define SFT_CCTIMER32_CONTROL_ENABLE_D                      (3)
#define LSB_CCTIMER32_CONTROL_ENABLE_D                      (3)
#define MSB_CCTIMER32_CONTROL_ENABLE_D                      (3)
#define BIT_CCTIMER32_CONTROL_ENABLE_D                      (0x8)     /* [3] */
#define MSK_CCTIMER32_CONTROL_RESTART_A                     (0x1)     /* [4] */
#define RES_CCTIMER32_CONTROL_RESTART_A                     (0x0)
#define SFT_CCTIMER32_CONTROL_RESTART_A                     (4)
#define LSB_CCTIMER32_CONTROL_RESTART_A                     (4)
#define MSB_CCTIMER32_CONTROL_RESTART_A                     (4)
#define BIT_CCTIMER32_CONTROL_RESTART_A                     (0x10)    /* [4] */
#define MSK_CCTIMER32_CONTROL_RESTART_B                     (0x1)     /* [5] */
#define RES_CCTIMER32_CONTROL_RESTART_B                     (0x0)
#define SFT_CCTIMER32_CONTROL_RESTART_B                     (5)
#define LSB_CCTIMER32_CONTROL_RESTART_B                     (5)
#define MSB_CCTIMER32_CONTROL_RESTART_B                     (5)
#define BIT_CCTIMER32_CONTROL_RESTART_B                     (0x20)    /* [5] */
#define MSK_CCTIMER32_CONTROL_RESTART_C                     (0x1)     /* [6] */
#define RES_CCTIMER32_CONTROL_RESTART_C                     (0x0)
#define SFT_CCTIMER32_CONTROL_RESTART_C                     (6)
#define LSB_CCTIMER32_CONTROL_RESTART_C                     (6)
#define MSB_CCTIMER32_CONTROL_RESTART_C                     (6)
#define BIT_CCTIMER32_CONTROL_RESTART_C                     (0x40)    /* [6] */
#define MSK_CCTIMER32_CONTROL_RESTART_D                     (0x1)     /* [7] */
#define RES_CCTIMER32_CONTROL_RESTART_D                     (0x0)
#define SFT_CCTIMER32_CONTROL_RESTART_D                     (7)
#define LSB_CCTIMER32_CONTROL_RESTART_D                     (7)
#define MSB_CCTIMER32_CONTROL_RESTART_D                     (7)
#define BIT_CCTIMER32_CONTROL_RESTART_D                     (0x80)    /* [7] */
#define MSK_CCTIMER32_CONTROL_RESTART_PS_AB                 (0x1)     /* [8] */
#define RES_CCTIMER32_CONTROL_RESTART_PS_AB                 (0x0)
#define SFT_CCTIMER32_CONTROL_RESTART_PS_AB                 (8)
#define LSB_CCTIMER32_CONTROL_RESTART_PS_AB                 (8)
#define MSB_CCTIMER32_CONTROL_RESTART_PS_AB                 (8)
#define BIT_CCTIMER32_CONTROL_RESTART_PS_AB                 (0x100)   /* [8] */
#define MSK_CCTIMER32_CONTROL_RESTART_PS_CD                 (0x1)     /* [9] */
#define RES_CCTIMER32_CONTROL_RESTART_PS_CD                 (0x0)
#define SFT_CCTIMER32_CONTROL_RESTART_PS_CD                 (9)
#define LSB_CCTIMER32_CONTROL_RESTART_PS_CD                 (9)
#define MSB_CCTIMER32_CONTROL_RESTART_PS_CD                 (9)
#define BIT_CCTIMER32_CONTROL_RESTART_PS_CD                 (0x200)   /* [9] */
#define MSK_CCTIMER32_CONTROL_READ_SYNC_C                   (0x1)     /* [10] */
#define RES_CCTIMER32_CONTROL_READ_SYNC_C                   (0x0)
#define SFT_CCTIMER32_CONTROL_READ_SYNC_C                   (10)
#define LSB_CCTIMER32_CONTROL_READ_SYNC_C                   (10)
#define MSB_CCTIMER32_CONTROL_READ_SYNC_C                   (10)
#define BIT_CCTIMER32_CONTROL_READ_SYNC_C                   (0x400)   /* [10] */
#define MSK_CCTIMER32_CONTROL_READ_SYNC_D                   (0x1)     /* [11] */
#define RES_CCTIMER32_CONTROL_READ_SYNC_D                   (0x0)
#define SFT_CCTIMER32_CONTROL_READ_SYNC_D                   (11)
#define LSB_CCTIMER32_CONTROL_READ_SYNC_D                   (11)
#define MSB_CCTIMER32_CONTROL_READ_SYNC_D                   (11)
#define BIT_CCTIMER32_CONTROL_READ_SYNC_D                   (0x800)   /* [11] */
#define MSK_CCTIMER32_CONTROL_WRITE_SYNC_C                  (0x1)     /* [12] */
#define RES_CCTIMER32_CONTROL_WRITE_SYNC_C                  (0x0)
#define SFT_CCTIMER32_CONTROL_WRITE_SYNC_C                  (12)
#define LSB_CCTIMER32_CONTROL_WRITE_SYNC_C                  (12)
#define MSB_CCTIMER32_CONTROL_WRITE_SYNC_C                  (12)
#define BIT_CCTIMER32_CONTROL_WRITE_SYNC_C                  (0x1000)  /* [12] */
#define MSK_CCTIMER32_CONTROL_WRITE_SYNC_D                  (0x1)     /* [13] */
#define RES_CCTIMER32_CONTROL_WRITE_SYNC_D                  (0x0)
#define SFT_CCTIMER32_CONTROL_WRITE_SYNC_D                  (13)
#define LSB_CCTIMER32_CONTROL_WRITE_SYNC_D                  (13)
#define MSB_CCTIMER32_CONTROL_WRITE_SYNC_D                  (13)
#define BIT_CCTIMER32_CONTROL_WRITE_SYNC_D                  (0x2000)  /* [13] */

/** 
 * \brief This structure describes CCTIMER32 control 
 *
 * \ingroup cctimer32
 */
typedef struct {
  unsigned short enable_a                      :    1; ///< A enable (0: disabled 1: enabled). In single shot mode this bis is automatically reset upon a compare match. <br> Can be enabled when CONFIG_A.restart_sel != none.
  unsigned short enable_b                      :    1; ///< B enable (0: disabled 1: enabled). In single shot mode this bis is automatically reset upon a compare match. <br> Can be enabled when CONFIG_B.restart_sel != none.
  unsigned short enable_c                      :    1; ///< C enable (0: disabled 1: enabled). In single shot mode this bis is automatically reset upon a compare match. <br> Can be enabled when CONFIG_C.restart_sel != none.
  unsigned short enable_d                      :    1; ///< D enable (0: disabled 1: enabled). In single shot mode this bis is automatically reset upon a compare match. <br> Can be enabled when CONFIG_D.restart_sel != none.
  unsigned short restart_a                     :    1; ///< 1 : generate restart event for A
  unsigned short restart_b                     :    1; ///< 1 : generate restart event for B
  unsigned short restart_c                     :    1; ///< 1 : generate restart event for C
  unsigned short restart_d                     :    1; ///< 1 : generate restart event for D
  unsigned short restart_ps_ab                 :    1; ///< 1 : restart prescaler for A & B
  unsigned short restart_ps_cd                 :    1; ///< 1 : restart prescaler for C & D
  unsigned short read_sync_c                   :    1; ///< 1: execute read sync
  unsigned short read_sync_d                   :    1; ///< 1: execute read sync
  unsigned short write_sync_c                  :    1; ///< 1: execute write sync
  unsigned short write_sync_d                  :    1; ///< 1: execute write sync
  unsigned short reserved                      :    2; ///< reserved
} cctimer32_control_bf;

/**
 * \brief Conversion type between word and bit representation of CCTIMER32 control
 *
 * \ingroup cctimer32
 */
typedef union {
  unsigned short val;
  cctimer32_control_bf bf;
} cctimer32_control_t;


/* CCTIMER32_CONFIG */

#define MSK_CCTIMER32_CONFIG_AB_16_32                       (0x1)     /* [0] */
#define RES_CCTIMER32_CONFIG_AB_16_32                       (0x0)
#define SFT_CCTIMER32_CONFIG_AB_16_32                       (0)
#define LSB_CCTIMER32_CONFIG_AB_16_32                       (0)
#define MSB_CCTIMER32_CONFIG_AB_16_32                       (0)
#define BIT_CCTIMER32_CONFIG_AB_16_32                       (0x1)     /* [0] */
#define MSK_CCTIMER32_CONFIG_C_SYNC_EN                      (0x1)     /* [1] */
#define RES_CCTIMER32_CONFIG_C_SYNC_EN                      (0x0)
#define SFT_CCTIMER32_CONFIG_C_SYNC_EN                      (1)
#define LSB_CCTIMER32_CONFIG_C_SYNC_EN                      (1)
#define MSB_CCTIMER32_CONFIG_C_SYNC_EN                      (1)
#define BIT_CCTIMER32_CONFIG_C_SYNC_EN                      (0x2)     /* [1] */
#define MSK_CCTIMER32_CONFIG_CD_16_32                       (0x1)     /* [2] */
#define RES_CCTIMER32_CONFIG_CD_16_32                       (0x0)
#define SFT_CCTIMER32_CONFIG_CD_16_32                       (2)
#define LSB_CCTIMER32_CONFIG_CD_16_32                       (2)
#define MSB_CCTIMER32_CONFIG_CD_16_32                       (2)
#define BIT_CCTIMER32_CONFIG_CD_16_32                       (0x4)     /* [2] */
#define MSK_CCTIMER32_CONFIG_D_SYNC_EN                      (0x1)     /* [3] */
#define RES_CCTIMER32_CONFIG_D_SYNC_EN                      (0x0)
#define SFT_CCTIMER32_CONFIG_D_SYNC_EN                      (3)
#define LSB_CCTIMER32_CONFIG_D_SYNC_EN                      (3)
#define MSB_CCTIMER32_CONFIG_D_SYNC_EN                      (3)
#define BIT_CCTIMER32_CONFIG_D_SYNC_EN                      (0x8)     /* [3] */
#define MSK_CCTIMER32_CONFIG_PWM_AB                         (0x3)     /* [ 5:4] */
#define RES_CCTIMER32_CONFIG_PWM_AB                         (0x0)
#define SFT_CCTIMER32_CONFIG_PWM_AB                         (4)
#define LSB_CCTIMER32_CONFIG_PWM_AB                         (4)
#define MSB_CCTIMER32_CONFIG_PWM_AB                         (5)
#define MSK_CCTIMER32_CONFIG_PWM_CD                         (0x3)     /* [ 7:6] */
#define RES_CCTIMER32_CONFIG_PWM_CD                         (0x0)
#define SFT_CCTIMER32_CONFIG_PWM_CD                         (6)
#define LSB_CCTIMER32_CONFIG_PWM_CD                         (6)
#define MSB_CCTIMER32_CONFIG_PWM_CD                         (7)
#define MSK_CCTIMER32_CONFIG_PS_DISABLE                     (0x1)     /* [8] */
#define RES_CCTIMER32_CONFIG_PS_DISABLE                     (0x0)
#define SFT_CCTIMER32_CONFIG_PS_DISABLE                     (8)
#define LSB_CCTIMER32_CONFIG_PS_DISABLE                     (8)
#define MSB_CCTIMER32_CONFIG_PS_DISABLE                     (8)
#define BIT_CCTIMER32_CONFIG_PS_DISABLE                     (0x100)   /* [8] */

/** 
 * \brief This structure describes CCTIMER32 global configuration 
 *
 * \ingroup cctimer32
 */
typedef struct {
  unsigned short ab_16_32                      :    1; ///< 0: A / B independent 2 x 16 bit counters <br> 1: A / B single 32 bit counter
  unsigned short c_sync_en                     :    1; ///< 0: C / D independent 2 x 16 bit counters <br> 1: C / D single 32 bit counter
  unsigned short cd_16_32                      :    1; ///< 1: sync input signal for c enabled
  unsigned short d_sync_en                     :    1; ///< 1: sync input signal for d enabled
  unsigned short pwm_ab                        :    2; ///< 0: PWM[0] on while COUNTER_B /= 0 <br> 1: PWM[0] toggle with compare event <br> 2: PWM[0] set to 0 <br> 3: PWM[0] set to 1
  unsigned short pwm_cd                        :    2; ///< 0: PWM[1] on while COUNTER_C /= 0 <br> 1: PWM[1] toggle with compare event <br> 2: PWM[1] set to 0 <br> 3: PWM[1] set to 1
  unsigned short ps_disable                    :    1; ///< 1: prescaler AB registers disabled and used for event decoder events
  unsigned short reserved                      :    7; ///< reserved
} cctimer32_config_bf;

/**
 * \brief Conversion type between word and bit representation of CCTIMER32 global configuration
 *
 * \ingroup cctimer32
 */
typedef union {
  unsigned short val;
  cctimer32_config_bf bf;
} cctimer32_config_t;


/* CCTIMER32_CONFIG_ED */

#define MSK_CCTIMER32_CONFIG_ED_INV_A                       (0x1)     /* [0] */
#define RES_CCTIMER32_CONFIG_ED_INV_A                       (0x0)
#define SFT_CCTIMER32_CONFIG_ED_INV_A                       (0)
#define LSB_CCTIMER32_CONFIG_ED_INV_A                       (0)
#define MSB_CCTIMER32_CONFIG_ED_INV_A                       (0)
#define BIT_CCTIMER32_CONFIG_ED_INV_A                       (0x1)     /* [0] */
#define MSK_CCTIMER32_CONFIG_ED_INV_B                       (0x1)     /* [1] */
#define RES_CCTIMER32_CONFIG_ED_INV_B                       (0x0)
#define SFT_CCTIMER32_CONFIG_ED_INV_B                       (1)
#define LSB_CCTIMER32_CONFIG_ED_INV_B                       (1)
#define MSB_CCTIMER32_CONFIG_ED_INV_B                       (1)
#define BIT_CCTIMER32_CONFIG_ED_INV_B                       (0x2)     /* [1] */
#define MSK_CCTIMER32_CONFIG_ED_INV_ZM                      (0x1)     /* [2] */
#define RES_CCTIMER32_CONFIG_ED_INV_ZM                      (0x0)
#define SFT_CCTIMER32_CONFIG_ED_INV_ZM                      (2)
#define LSB_CCTIMER32_CONFIG_ED_INV_ZM                      (2)
#define MSB_CCTIMER32_CONFIG_ED_INV_ZM                      (2)
#define BIT_CCTIMER32_CONFIG_ED_INV_ZM                      (0x4)     /* [2] */
#define MSK_CCTIMER32_CONFIG_ED_INV_GATE                    (0x1)     /* [3] */
#define RES_CCTIMER32_CONFIG_ED_INV_GATE                    (0x0)
#define SFT_CCTIMER32_CONFIG_ED_INV_GATE                    (3)
#define LSB_CCTIMER32_CONFIG_ED_INV_GATE                    (3)
#define MSB_CCTIMER32_CONFIG_ED_INV_GATE                    (3)
#define BIT_CCTIMER32_CONFIG_ED_INV_GATE                    (0x8)     /* [3] */
#define MSK_CCTIMER32_CONFIG_ED_SWAP_AB                     (0x1)     /* [4] */
#define RES_CCTIMER32_CONFIG_ED_SWAP_AB                     (0x0)
#define SFT_CCTIMER32_CONFIG_ED_SWAP_AB                     (4)
#define LSB_CCTIMER32_CONFIG_ED_SWAP_AB                     (4)
#define MSB_CCTIMER32_CONFIG_ED_SWAP_AB                     (4)
#define BIT_CCTIMER32_CONFIG_ED_SWAP_AB                     (0x10)    /* [4] */
#define MSK_CCTIMER32_CONFIG_ED_FORMAT                      (0x7)     /* [ 7:5] */
#define RES_CCTIMER32_CONFIG_ED_FORMAT                      (0x0)
#define SFT_CCTIMER32_CONFIG_ED_FORMAT                      (5)
#define LSB_CCTIMER32_CONFIG_ED_FORMAT                      (5)
#define MSB_CCTIMER32_CONFIG_ED_FORMAT                      (7)
#define MSK_CCTIMER32_CONFIG_ED_GATE                        (0x3)     /* [ 9:8] */
#define RES_CCTIMER32_CONFIG_ED_GATE                        (0x0)
#define SFT_CCTIMER32_CONFIG_ED_GATE                        (8)
#define LSB_CCTIMER32_CONFIG_ED_GATE                        (8)
#define MSB_CCTIMER32_CONFIG_ED_GATE                        (9)

/** 
 * \brief This structure describes CCTIMER32 decoder 
 *
 * \ingroup cctimer32
 */
typedef struct {
  unsigned short inv_a                         :    1; ///< 1: invert input A signal in front of the decoder
  unsigned short inv_b                         :    1; ///< 1: invert input B signal in front of the decoder
  unsigned short inv_zm                        :    1; ///< 1: invert input zero market signal in front of the decoder
  unsigned short inv_gate                      :    1; ///< 1: invert input gate signal in front of the decoder
  unsigned short swap_ab                       :    1; ///< 1: swap signals A and B in front of the decoder
  unsigned short format                        :    3; ///< 0: A B (state less) <br> 1: A B (FSM, initialized when counter A enabled) <br> 2: pulse / direction <br> 3: pulse up / pulse down
  unsigned short gate                          :    2; ///< 0: gate disabled <br> 1: gate=0 disables position increment <br> 2: gate=0 disables zero marker event
  unsigned short reserved                      :    6; ///< reserved
} cctimer32_config_ed_bf;

/**
 * \brief Conversion type between word and bit representation of CCTIMER32 decoder
 *
 * \ingroup cctimer32
 */
typedef union {
  unsigned short val;
  cctimer32_config_ed_bf bf;
} cctimer32_config_ed_t;


/* CCTIMER32_CONFIG_ABCD */

#define MSK_CCTIMER32_CONFIG_ABCD_COUNTER_SEL               (0x7)     /* [ 2:0] */
#define RES_CCTIMER32_CONFIG_ABCD_COUNTER_SEL               (0x0)
#define SFT_CCTIMER32_CONFIG_ABCD_COUNTER_SEL               (0)
#define LSB_CCTIMER32_CONFIG_ABCD_COUNTER_SEL               (0)
#define MSB_CCTIMER32_CONFIG_ABCD_COUNTER_SEL               (2)
#define MSK_CCTIMER32_CONFIG_ABCD_COUNTER_ACTION            (0x1)     /* [3] */
#define RES_CCTIMER32_CONFIG_ABCD_COUNTER_ACTION            (0x0)
#define SFT_CCTIMER32_CONFIG_ABCD_COUNTER_ACTION            (3)
#define LSB_CCTIMER32_CONFIG_ABCD_COUNTER_ACTION            (3)
#define MSB_CCTIMER32_CONFIG_ABCD_COUNTER_ACTION            (3)
#define BIT_CCTIMER32_CONFIG_ABCD_COUNTER_ACTION            (0x8)     /* [3] */
#define MSK_CCTIMER32_CONFIG_ABCD_RESTART_SEL               (0xf)     /* [ 7:4] */
#define RES_CCTIMER32_CONFIG_ABCD_RESTART_SEL               (0x1)
#define SFT_CCTIMER32_CONFIG_ABCD_RESTART_SEL               (4)
#define LSB_CCTIMER32_CONFIG_ABCD_RESTART_SEL               (4)
#define MSB_CCTIMER32_CONFIG_ABCD_RESTART_SEL               (7)
#define MSK_CCTIMER32_CONFIG_ABCD_RESTART_ACTION            (0x1)     /* [8] */
#define RES_CCTIMER32_CONFIG_ABCD_RESTART_ACTION            (0x0)
#define SFT_CCTIMER32_CONFIG_ABCD_RESTART_ACTION            (8)
#define LSB_CCTIMER32_CONFIG_ABCD_RESTART_ACTION            (8)
#define MSB_CCTIMER32_CONFIG_ABCD_RESTART_ACTION            (8)
#define BIT_CCTIMER32_CONFIG_ABCD_RESTART_ACTION            (0x100)   /* [8] */
#define MSK_CCTIMER32_CONFIG_ABCD_CC_SEL                    (0xf)     /* [12:9] */
#define RES_CCTIMER32_CONFIG_ABCD_CC_SEL                    (0x0)
#define SFT_CCTIMER32_CONFIG_ABCD_CC_SEL                    (9)
#define LSB_CCTIMER32_CONFIG_ABCD_CC_SEL                    (9)
#define MSB_CCTIMER32_CONFIG_ABCD_CC_SEL                    (12)
#define MSK_CCTIMER32_CONFIG_ABCD_CC_ACTION                 (0x1)     /* [13] */
#define RES_CCTIMER32_CONFIG_ABCD_CC_ACTION                 (0x0)
#define SFT_CCTIMER32_CONFIG_ABCD_CC_ACTION                 (13)
#define LSB_CCTIMER32_CONFIG_ABCD_CC_ACTION                 (13)
#define MSB_CCTIMER32_CONFIG_ABCD_CC_ACTION                 (13)
#define BIT_CCTIMER32_CONFIG_ABCD_CC_ACTION                 (0x2000)  /* [13] */
#define MSK_CCTIMER32_CONFIG_ABCD_MODE                      (0x3)     /* [15:14] */
#define RES_CCTIMER32_CONFIG_ABCD_MODE                      (0x0)
#define SFT_CCTIMER32_CONFIG_ABCD_MODE                      (14)
#define LSB_CCTIMER32_CONFIG_ABCD_MODE                      (14)
#define MSB_CCTIMER32_CONFIG_ABCD_MODE                      (15)

/** 
 * \brief This structure describes CCTIMER32 timer configuration 
 *
 * \ingroup cctimer32
 */
typedef struct {
/**
 * Counter event selection: <br>
 * 0 : (prescaled) system clk <br>
 * 1 : MEAS[0/1/2/3] posedge <br>
 * 2 : MEAS[0/1/2/3] negedge <br>
 * 3 : event decoder (counter_action is ignored) <br>
 * 4 : (prescaled) system clk when MEAS[0/2]=0 <br>
 * 5 : (prescaled) system clk when MEAS[0/2]=1 <br>
 * 6 : (prescaled) system clk when MEAS[1/3]=0 <br>
 * 7 : (prescaled) system clk when MEAS[1/3]=1 
 */
  unsigned short counter_sel                   :    3;
/**
 * Action when counter event occurs: <br>
 * 0 : COUNTER++ <br>
 * 1 : COUNTER-- 
 */
  unsigned short counter_action                :    1;
/**
 * Restart event selection (affects CONTROL.enable): <br>
 * 0: counter initially enabled / own CC event <br>
 * 1: none <br>
 * 2: other counter CC event <br>
 * 3 : MEAS[0/2] signal posedge <br>
 * 4 : MEAS[0/2] signal negedge <br>
 * 5 : MEAS[1/3] signal posedge <br>
 * 6 : MEAS[1/3] signal negedge <br>
 * 7 : event counter decoding step pulses <br>
 * 8 : event counter decoding direction change <br>
 * 9 : zero marker event <br>
 * 10: sync event 
 */
  unsigned short restart_sel                   :    4;
/**
 * Action when restart event occurs: <br>
 * 0: COUNTER <= 0 <br>
 * 1: COUNTER <= CAPCMP
 */
  unsigned short restart_action                :    1;
/**
 * Capture/compare (CC) event selection: <br>
 * 0 : COUNTER=CAPCMP <br>
 * 1 : COUNTER=0 <br>
 * 2-10: same as restart_sel
 */
  unsigned short cc_sel                        :    4;
/**
 * Action when cc event occurs: <br>
 * 0 : none <br>
 * 1 : CAPCMP<=COUNTER
 */
  unsigned short cc_action                     :    1;
/**
 * Mode selection: <br>
 * 0: single shot (CC event clears enable) <br>
 * 1: run continuously (loop) <br>
 * 2: like single shot but does not clear enable and restarts with every restart event (restart loop)
 */
  unsigned short mode                          :    2;
} cctimer32_config_abcd_bf;

/**
 * \brief Conversion type between word and bit representation of CCTIMER32 timer configuration
 *
 * \ingroup cctimer32
 */
typedef union {
  unsigned short val;
  cctimer32_config_abcd_bf bf;
} cctimer32_config_abcd_t;


/* CCTIMER32_CAPCMP_AB */

#define MSK_CCTIMER32_CAPCMP_AB                             (0xffff)  /* [15:0] */

typedef unsigned short cctimer32_capcmp_ab_t;                         /* [15:0] */


/* CCTIMER32_COUNTER_AB */

#define MSK_CCTIMER32_COUNTER_AB                            (0xffff)  /* [15:0] */

typedef unsigned short cctimer32_counter_ab_t;                        /* [15:0] */


/* CCTIMER32_CAPCMP_CD */

#define MSK_CCTIMER32_CAPCMP_CD                             (0xffff)  /* [15:0] */

typedef unsigned short cctimer32_capcmp_cd_t;                         /* [15:0] */


/* CCTIMER32_COUNTER_CD */

#define MSK_CCTIMER32_COUNTER_CD                            (0xffff)  /* [15:0] */

typedef unsigned short cctimer32_counter_cd_t;                        /* [15:0] */


/* CCTIMER32_IRQ_STATUS */

#define MSK_CCTIMER32_IRQ_STATUS_OVERFLOW_A                 (0x1)     /* [0] */
#define RES_CCTIMER32_IRQ_STATUS_OVERFLOW_A                 (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_OVERFLOW_A                 (0)
#define LSB_CCTIMER32_IRQ_STATUS_OVERFLOW_A                 (0)
#define MSB_CCTIMER32_IRQ_STATUS_OVERFLOW_A                 (0)
#define BIT_CCTIMER32_IRQ_STATUS_OVERFLOW_A                 (0x1)     /* [0] */
#define MSK_CCTIMER32_IRQ_STATUS_OVERFLOW_B                 (0x1)     /* [1] */
#define RES_CCTIMER32_IRQ_STATUS_OVERFLOW_B                 (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_OVERFLOW_B                 (1)
#define LSB_CCTIMER32_IRQ_STATUS_OVERFLOW_B                 (1)
#define MSB_CCTIMER32_IRQ_STATUS_OVERFLOW_B                 (1)
#define BIT_CCTIMER32_IRQ_STATUS_OVERFLOW_B                 (0x2)     /* [1] */
#define MSK_CCTIMER32_IRQ_STATUS_OVERFLOW_C                 (0x1)     /* [2] */
#define RES_CCTIMER32_IRQ_STATUS_OVERFLOW_C                 (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_OVERFLOW_C                 (2)
#define LSB_CCTIMER32_IRQ_STATUS_OVERFLOW_C                 (2)
#define MSB_CCTIMER32_IRQ_STATUS_OVERFLOW_C                 (2)
#define BIT_CCTIMER32_IRQ_STATUS_OVERFLOW_C                 (0x4)     /* [2] */
#define MSK_CCTIMER32_IRQ_STATUS_OVERFLOW_D                 (0x1)     /* [3] */
#define RES_CCTIMER32_IRQ_STATUS_OVERFLOW_D                 (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_OVERFLOW_D                 (3)
#define LSB_CCTIMER32_IRQ_STATUS_OVERFLOW_D                 (3)
#define MSB_CCTIMER32_IRQ_STATUS_OVERFLOW_D                 (3)
#define BIT_CCTIMER32_IRQ_STATUS_OVERFLOW_D                 (0x8)     /* [3] */
#define MSK_CCTIMER32_IRQ_STATUS_RESTART_A                  (0x1)     /* [4] */
#define RES_CCTIMER32_IRQ_STATUS_RESTART_A                  (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_RESTART_A                  (4)
#define LSB_CCTIMER32_IRQ_STATUS_RESTART_A                  (4)
#define MSB_CCTIMER32_IRQ_STATUS_RESTART_A                  (4)
#define BIT_CCTIMER32_IRQ_STATUS_RESTART_A                  (0x10)    /* [4] */
#define MSK_CCTIMER32_IRQ_STATUS_RESTART_B                  (0x1)     /* [5] */
#define RES_CCTIMER32_IRQ_STATUS_RESTART_B                  (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_RESTART_B                  (5)
#define LSB_CCTIMER32_IRQ_STATUS_RESTART_B                  (5)
#define MSB_CCTIMER32_IRQ_STATUS_RESTART_B                  (5)
#define BIT_CCTIMER32_IRQ_STATUS_RESTART_B                  (0x20)    /* [5] */
#define MSK_CCTIMER32_IRQ_STATUS_RESTART_C                  (0x1)     /* [6] */
#define RES_CCTIMER32_IRQ_STATUS_RESTART_C                  (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_RESTART_C                  (6)
#define LSB_CCTIMER32_IRQ_STATUS_RESTART_C                  (6)
#define MSB_CCTIMER32_IRQ_STATUS_RESTART_C                  (6)
#define BIT_CCTIMER32_IRQ_STATUS_RESTART_C                  (0x40)    /* [6] */
#define MSK_CCTIMER32_IRQ_STATUS_RESTART_D                  (0x1)     /* [7] */
#define RES_CCTIMER32_IRQ_STATUS_RESTART_D                  (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_RESTART_D                  (7)
#define LSB_CCTIMER32_IRQ_STATUS_RESTART_D                  (7)
#define MSB_CCTIMER32_IRQ_STATUS_RESTART_D                  (7)
#define BIT_CCTIMER32_IRQ_STATUS_RESTART_D                  (0x80)    /* [7] */
#define MSK_CCTIMER32_IRQ_STATUS_CAPTURE_A                  (0x1)     /* [8] */
#define RES_CCTIMER32_IRQ_STATUS_CAPTURE_A                  (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_CAPTURE_A                  (8)
#define LSB_CCTIMER32_IRQ_STATUS_CAPTURE_A                  (8)
#define MSB_CCTIMER32_IRQ_STATUS_CAPTURE_A                  (8)
#define BIT_CCTIMER32_IRQ_STATUS_CAPTURE_A                  (0x100)   /* [8] */
#define MSK_CCTIMER32_IRQ_STATUS_CAPTURE_B                  (0x1)     /* [9] */
#define RES_CCTIMER32_IRQ_STATUS_CAPTURE_B                  (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_CAPTURE_B                  (9)
#define LSB_CCTIMER32_IRQ_STATUS_CAPTURE_B                  (9)
#define MSB_CCTIMER32_IRQ_STATUS_CAPTURE_B                  (9)
#define BIT_CCTIMER32_IRQ_STATUS_CAPTURE_B                  (0x200)   /* [9] */
#define MSK_CCTIMER32_IRQ_STATUS_CAPTURE_C                  (0x1)     /* [10] */
#define RES_CCTIMER32_IRQ_STATUS_CAPTURE_C                  (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_CAPTURE_C                  (10)
#define LSB_CCTIMER32_IRQ_STATUS_CAPTURE_C                  (10)
#define MSB_CCTIMER32_IRQ_STATUS_CAPTURE_C                  (10)
#define BIT_CCTIMER32_IRQ_STATUS_CAPTURE_C                  (0x400)   /* [10] */
#define MSK_CCTIMER32_IRQ_STATUS_CAPTURE_D                  (0x1)     /* [11] */
#define RES_CCTIMER32_IRQ_STATUS_CAPTURE_D                  (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_CAPTURE_D                  (11)
#define LSB_CCTIMER32_IRQ_STATUS_CAPTURE_D                  (11)
#define MSB_CCTIMER32_IRQ_STATUS_CAPTURE_D                  (11)
#define BIT_CCTIMER32_IRQ_STATUS_CAPTURE_D                  (0x800)   /* [11] */
#define MSK_CCTIMER32_IRQ_STATUS_ED_ZM                      (0x1)     /* [12] */
#define RES_CCTIMER32_IRQ_STATUS_ED_ZM                      (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_ED_ZM                      (12)
#define LSB_CCTIMER32_IRQ_STATUS_ED_ZM                      (12)
#define MSB_CCTIMER32_IRQ_STATUS_ED_ZM                      (12)
#define BIT_CCTIMER32_IRQ_STATUS_ED_ZM                      (0x1000)  /* [12] */
#define MSK_CCTIMER32_IRQ_STATUS_ED_DIR_CHANGE              (0x1)     /* [13] */
#define RES_CCTIMER32_IRQ_STATUS_ED_DIR_CHANGE              (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_ED_DIR_CHANGE              (13)
#define LSB_CCTIMER32_IRQ_STATUS_ED_DIR_CHANGE              (13)
#define MSB_CCTIMER32_IRQ_STATUS_ED_DIR_CHANGE              (13)
#define BIT_CCTIMER32_IRQ_STATUS_ED_DIR_CHANGE              (0x2000)  /* [13] */
#define MSK_CCTIMER32_IRQ_STATUS_ED_POSCHANGE               (0x1)     /* [14] */
#define RES_CCTIMER32_IRQ_STATUS_ED_POSCHANGE               (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_ED_POSCHANGE               (14)
#define LSB_CCTIMER32_IRQ_STATUS_ED_POSCHANGE               (14)
#define MSB_CCTIMER32_IRQ_STATUS_ED_POSCHANGE               (14)
#define BIT_CCTIMER32_IRQ_STATUS_ED_POSCHANGE               (0x4000)  /* [14] */
#define MSK_CCTIMER32_IRQ_STATUS_ED_AB_ERROR                (0x1)     /* [15] */
#define RES_CCTIMER32_IRQ_STATUS_ED_AB_ERROR                (0x0)
#define SFT_CCTIMER32_IRQ_STATUS_ED_AB_ERROR                (15)
#define LSB_CCTIMER32_IRQ_STATUS_ED_AB_ERROR                (15)
#define MSB_CCTIMER32_IRQ_STATUS_ED_AB_ERROR                (15)
#define BIT_CCTIMER32_IRQ_STATUS_ED_AB_ERROR                (0x8000)  /* [15] */

/** 
 * \brief This structure describes CCTIMER32 Interrupt Request status 
 *
 * \ingroup cctimer32
 */
typedef struct {
  unsigned short overflow_a                    :    1; ///< counter A over/underflow
  unsigned short overflow_b                    :    1; ///< counter B over/underflow
  unsigned short overflow_c                    :    1; ///< counter C over/underflow
  unsigned short overflow_d                    :    1; ///< counter D over/underflow
  unsigned short restart_a                     :    1; ///< counter A restart event
  unsigned short restart_b                     :    1; ///< counter B restart event
  unsigned short restart_c                     :    1; ///< counter C restart event
  unsigned short restart_d                     :    1; ///< counter D restart event
  unsigned short capture_a                     :    1; ///< counter A capture event
  unsigned short capture_b                     :    1; ///< counter B capture event
  unsigned short capture_c                     :    1; ///< counter C capture event
  unsigned short capture_d                     :    1; ///< counter D capture event
  unsigned short ed_zm                         :    1; ///< event decoder events: zero marker
  unsigned short ed_dir_change                 :    1; ///< event decoder events: direction change
  unsigned short ed_poschange                  :    1; ///< event decoder events: position change
  unsigned short ed_ab_error                   :    1; ///< event decoder events: A/B track error
} cctimer32_irq_status_bf;

/**
 * \brief Conversion type between word and bit representation of CCTIMER32 Interrupt Request status
 *
 * \ingroup cctimer32
 */
typedef union {
  unsigned short val;
  cctimer32_irq_status_bf bf;
} cctimer32_irq_status_t;


/* CCTIMER32_IRQ_MASK */

#define MSK_CCTIMER32_IRQ_MASK                              (0xffff)  /* [15:0] */

typedef unsigned short cctimer32_irq_mask_t;                          /* [15:0] */


/* CCTIMER32_IRQ_VENABLE */

#define MSK_CCTIMER32_IRQ_VENABLE                           (0xf)     /* [ 3:0] */

typedef unsigned short cctimer32_irq_venable_t;                       /* [ 3:0] */


/* CCTIMER32_IRQ_VDISABLE */

#define MSK_CCTIMER32_IRQ_VDISABLE                          (0xf)     /* [ 3:0] */

typedef unsigned short cctimer32_irq_vdisable_t;                      /* [ 3:0] */


/* CCTIMER32_IRQ_VMAX */

#define MSK_CCTIMER32_IRQ_VMAX                              (0x1f)    /* [ 4:0] */

typedef unsigned short cctimer32_irq_vmax_t;                          /* [ 4:0] */


/* CCTIMER32_IRQ_VNO */

#define MSK_CCTIMER32_IRQ_VNO                               (0x1f)    /* [ 4:0] */

typedef unsigned short cctimer32_irq_vno_t;                           /* [ 4:0] */


/* CCTIMER32_CFG_INTF */

#define MSK_CCTIMER32_CFG_INTF_MEAS_AB                      (0xff)    /* [ 7:0] */
#define RES_CCTIMER32_CFG_INTF_MEAS_AB                      (0x00)
#define SFT_CCTIMER32_CFG_INTF_MEAS_AB                      (0)
#define LSB_CCTIMER32_CFG_INTF_MEAS_AB                      (0)
#define MSB_CCTIMER32_CFG_INTF_MEAS_AB                      (7)
#define MSK_CCTIMER32_CFG_INTF_ZM_GATE                      (0xff)    /* [15:8] */
#define RES_CCTIMER32_CFG_INTF_ZM_GATE                      (0x00)
#define SFT_CCTIMER32_CFG_INTF_ZM_GATE                      (8)
#define LSB_CCTIMER32_CFG_INTF_ZM_GATE                      (8)
#define MSB_CCTIMER32_CFG_INTF_ZM_GATE                      (15)

/** 
 * \brief This structure describes CCTIMER32 threshold
 *
 * \ingroup cctimer32
 */
typedef struct {
  unsigned short meas_ab; ///< integrator threshold for inputs meas[0] and meas[1] (A and B)
  unsigned short zm_gate; ///< integrator threshold for inputs meas[2] and meas[3] (zm and gate)
} cctimer32_cfg_intf_bf;

/**
 * \brief Conversion type between word and bit representation of CCTIMER32 threshold
 *
 * \ingroup cctimer32
 */
typedef union {
  unsigned short val;
  cctimer32_cfg_intf_bf bf;
} cctimer32_cfg_intf_t;


/* CCTIMER32_CFG_INTF_PRE */

#define MSK_CCTIMER32_CFG_INTF_PRE                          (0xffff)  /* [15:0] */

typedef unsigned short cctimer32_cfg_intf_pre_t;                      /* [15:0] */



// Register definitions for module
// Instance base address BASE_ADDR_CCTIMER0 0x40006F00U ... 
// Instance base address BASE_ADDR_CCTIMER1 0x40006F80U ... 

#define ADDR_CCTIMER32_PS_AB                                 (0x00U)
#define A_CCTIMER32_PS_AB(ba)                                ((ba) + ADDR_CCTIMER32_PS_AB)
#define R_CCTIMER32_PS_AB(ba)                                (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_PS_AB(ba)))
#define RES_CCTIMER32_PS_AB                                  (0x0U)
#define MSB_CCTIMER32_PS_AB                                  15
#define LSB_CCTIMER32_PS_AB                                  0
#define AADDR_CCTIMER0_PS_AB                                 (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_PS_AB)
#define AADDR_CCTIMER1_PS_AB                                 (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_PS_AB)
#define REG_CCTIMER0_PS_AB                                   (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_PS_AB))
#define REG_CCTIMER1_PS_AB                                   (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_PS_AB))

#define ADDR_CCTIMER32_PS_CD                                 (0x02U)
#define A_CCTIMER32_PS_CD(ba)                                ((ba) + ADDR_CCTIMER32_PS_CD)
#define R_CCTIMER32_PS_CD(ba)                                (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_PS_CD(ba)))
#define RES_CCTIMER32_PS_CD                                  (0x0U)
#define MSB_CCTIMER32_PS_CD                                  15
#define LSB_CCTIMER32_PS_CD                                  0
#define AADDR_CCTIMER0_PS_CD                                 (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_PS_CD)
#define AADDR_CCTIMER1_PS_CD                                 (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_PS_CD)
#define REG_CCTIMER0_PS_CD                                   (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_PS_CD))
#define REG_CCTIMER1_PS_CD                                   (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_PS_CD))

#define ADDR_CCTIMER32_PSR_AB                                (0x04U)
#define A_CCTIMER32_PSR_AB(ba)                               ((ba) + ADDR_CCTIMER32_PSR_AB)
#define R_CCTIMER32_PSR_AB(ba)                               (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_PSR_AB(ba)))
#define RES_CCTIMER32_PSR_AB                                 (0x0U)
#define MSB_CCTIMER32_PSR_AB                                 7
#define LSB_CCTIMER32_PSR_AB                                 0
#define AADDR_CCTIMER0_PSR_AB                                (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_PSR_AB)
#define AADDR_CCTIMER1_PSR_AB                                (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_PSR_AB)
#define REG_CCTIMER0_PSR_AB                                  (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_PSR_AB))
#define REG_CCTIMER1_PSR_AB                                  (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_PSR_AB))

#define ADDR_CCTIMER32_PSR_CD                                (0x06U)
#define A_CCTIMER32_PSR_CD(ba)                               ((ba) + ADDR_CCTIMER32_PSR_CD)
#define R_CCTIMER32_PSR_CD(ba)                               (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_PSR_CD(ba)))
#define RES_CCTIMER32_PSR_CD                                 (0x0U)
#define MSB_CCTIMER32_PSR_CD                                 7
#define LSB_CCTIMER32_PSR_CD                                 0
#define AADDR_CCTIMER0_PSR_CD                                (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_PSR_CD)
#define AADDR_CCTIMER1_PSR_CD                                (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_PSR_CD)
#define REG_CCTIMER0_PSR_CD                                  (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_PSR_CD))
#define REG_CCTIMER1_PSR_CD                                  (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_PSR_CD))

#define ADDR_CCTIMER32_CONTROL                               (0x08U)
#define A_CCTIMER32_CONTROL(ba)                              ((ba) + ADDR_CCTIMER32_CONTROL)
#define R_CCTIMER32_CONTROL(ba)                              (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CONTROL(ba)))
#define RES_CCTIMER32_CONTROL                                (0x0U)
#define MSB_CCTIMER32_CONTROL                                13
#define LSB_CCTIMER32_CONTROL                                0
#define AADDR_CCTIMER0_CONTROL                               (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CONTROL)
#define AADDR_CCTIMER1_CONTROL                               (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CONTROL)
#define REG_CCTIMER0_CONTROL                                 (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CONTROL))
#define REG_CCTIMER1_CONTROL                                 (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CONTROL))

#define ADDR_CCTIMER32_CONFIG                                (0x0AU)
#define A_CCTIMER32_CONFIG(ba)                               ((ba) + ADDR_CCTIMER32_CONFIG)
#define R_CCTIMER32_CONFIG(ba)                               (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CONFIG(ba)))
#define RES_CCTIMER32_CONFIG                                 (0x0U)
#define MSB_CCTIMER32_CONFIG                                 8
#define LSB_CCTIMER32_CONFIG                                 0
#define AADDR_CCTIMER0_CONFIG                                (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CONFIG)
#define AADDR_CCTIMER1_CONFIG                                (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CONFIG)
#define REG_CCTIMER0_CONFIG                                  (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CONFIG))
#define REG_CCTIMER1_CONFIG                                  (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CONFIG))

#define ADDR_CCTIMER32_CONFIG_ED                             (0x0CU)
#define A_CCTIMER32_CONFIG_ED(ba)                            ((ba) + ADDR_CCTIMER32_CONFIG_ED)
#define R_CCTIMER32_CONFIG_ED(ba)                            (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CONFIG_ED(ba)))
#define RES_CCTIMER32_CONFIG_ED                              (0x0U)
#define MSB_CCTIMER32_CONFIG_ED                              9
#define LSB_CCTIMER32_CONFIG_ED                              0
#define AADDR_CCTIMER0_CONFIG_ED                             (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CONFIG_ED)
#define AADDR_CCTIMER1_CONFIG_ED                             (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CONFIG_ED)
#define REG_CCTIMER0_CONFIG_ED                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CONFIG_ED))
#define REG_CCTIMER1_CONFIG_ED                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CONFIG_ED))

#define ADDR_CCTIMER32_CONFIG_A                              (0x0EU)
#define A_CCTIMER32_CONFIG_A(ba)                             ((ba) + ADDR_CCTIMER32_CONFIG_A)
#define R_CCTIMER32_CONFIG_A(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CONFIG_A(ba)))
#define RES_CCTIMER32_CONFIG_A                               (0x10U)
#define MSB_CCTIMER32_CONFIG_A                               15
#define LSB_CCTIMER32_CONFIG_A                               0
#define AADDR_CCTIMER0_CONFIG_A                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CONFIG_A)
#define AADDR_CCTIMER1_CONFIG_A                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CONFIG_A)
#define REG_CCTIMER0_CONFIG_A                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CONFIG_A))
#define REG_CCTIMER1_CONFIG_A                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CONFIG_A))

#define ADDR_CCTIMER32_CONFIG_B                              (0x10U)
#define A_CCTIMER32_CONFIG_B(ba)                             ((ba) + ADDR_CCTIMER32_CONFIG_B)
#define R_CCTIMER32_CONFIG_B(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CONFIG_B(ba)))
#define RES_CCTIMER32_CONFIG_B                               (0x10U)
#define MSB_CCTIMER32_CONFIG_B                               15
#define LSB_CCTIMER32_CONFIG_B                               0
#define AADDR_CCTIMER0_CONFIG_B                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CONFIG_B)
#define AADDR_CCTIMER1_CONFIG_B                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CONFIG_B)
#define REG_CCTIMER0_CONFIG_B                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CONFIG_B))
#define REG_CCTIMER1_CONFIG_B                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CONFIG_B))

#define ADDR_CCTIMER32_CONFIG_C                              (0x12U)
#define A_CCTIMER32_CONFIG_C(ba)                             ((ba) + ADDR_CCTIMER32_CONFIG_C)
#define R_CCTIMER32_CONFIG_C(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CONFIG_C(ba)))
#define RES_CCTIMER32_CONFIG_C                               (0x10U)
#define MSB_CCTIMER32_CONFIG_C                               15
#define LSB_CCTIMER32_CONFIG_C                               0
#define AADDR_CCTIMER0_CONFIG_C                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CONFIG_C)
#define AADDR_CCTIMER1_CONFIG_C                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CONFIG_C)
#define REG_CCTIMER0_CONFIG_C                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CONFIG_C))
#define REG_CCTIMER1_CONFIG_C                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CONFIG_C))

#define ADDR_CCTIMER32_CONFIG_D                              (0x14U)
#define A_CCTIMER32_CONFIG_D(ba)                             ((ba) + ADDR_CCTIMER32_CONFIG_D)
#define R_CCTIMER32_CONFIG_D(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CONFIG_D(ba)))
#define RES_CCTIMER32_CONFIG_D                               (0x10U)
#define MSB_CCTIMER32_CONFIG_D                               15
#define LSB_CCTIMER32_CONFIG_D                               0
#define AADDR_CCTIMER0_CONFIG_D                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CONFIG_D)
#define AADDR_CCTIMER1_CONFIG_D                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CONFIG_D)
#define REG_CCTIMER0_CONFIG_D                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CONFIG_D))
#define REG_CCTIMER1_CONFIG_D                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CONFIG_D))

#define ADDR_CCTIMER32_CAPCMP_A                              (0x16U)
#define A_CCTIMER32_CAPCMP_A(ba)                             ((ba) + ADDR_CCTIMER32_CAPCMP_A)
#define R_CCTIMER32_CAPCMP_A(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CAPCMP_A(ba)))
#define RES_CCTIMER32_CAPCMP_A                               (0x0U)
#define MSB_CCTIMER32_CAPCMP_A                               15
#define LSB_CCTIMER32_CAPCMP_A                               0
#define AADDR_CCTIMER0_CAPCMP_A                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CAPCMP_A)
#define AADDR_CCTIMER1_CAPCMP_A                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CAPCMP_A)
#define REG_CCTIMER0_CAPCMP_A                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CAPCMP_A))
#define REG_CCTIMER1_CAPCMP_A                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CAPCMP_A))

#define ADDR_CCTIMER32_CAPCMP_B                              (0x18U)
#define A_CCTIMER32_CAPCMP_B(ba)                             ((ba) + ADDR_CCTIMER32_CAPCMP_B)
#define R_CCTIMER32_CAPCMP_B(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CAPCMP_B(ba)))
#define RES_CCTIMER32_CAPCMP_B                               (0x0U)
#define MSB_CCTIMER32_CAPCMP_B                               15
#define LSB_CCTIMER32_CAPCMP_B                               0
#define AADDR_CCTIMER0_CAPCMP_B                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CAPCMP_B)
#define AADDR_CCTIMER1_CAPCMP_B                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CAPCMP_B)
#define REG_CCTIMER0_CAPCMP_B                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CAPCMP_B))
#define REG_CCTIMER1_CAPCMP_B                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CAPCMP_B))

#define ADDR_CCTIMER32_COUNTER_A                             (0x1AU)
#define A_CCTIMER32_COUNTER_A(ba)                            ((ba) + ADDR_CCTIMER32_COUNTER_A)
#define R_CCTIMER32_COUNTER_A(ba)                            (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_COUNTER_A(ba)))
#define RES_CCTIMER32_COUNTER_A                              (0x0U)
#define MSB_CCTIMER32_COUNTER_A                              15
#define LSB_CCTIMER32_COUNTER_A                              0
#define AADDR_CCTIMER0_COUNTER_A                             (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_COUNTER_A)
#define AADDR_CCTIMER1_COUNTER_A                             (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_COUNTER_A)
#define REG_CCTIMER0_COUNTER_A                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_COUNTER_A))
#define REG_CCTIMER1_COUNTER_A                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_COUNTER_A))

#define ADDR_CCTIMER32_COUNTER_B                             (0x1CU)
#define A_CCTIMER32_COUNTER_B(ba)                            ((ba) + ADDR_CCTIMER32_COUNTER_B)
#define R_CCTIMER32_COUNTER_B(ba)                            (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_COUNTER_B(ba)))
#define RES_CCTIMER32_COUNTER_B                              (0x0U)
#define MSB_CCTIMER32_COUNTER_B                              15
#define LSB_CCTIMER32_COUNTER_B                              0
#define AADDR_CCTIMER0_COUNTER_B                             (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_COUNTER_B)
#define AADDR_CCTIMER1_COUNTER_B                             (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_COUNTER_B)
#define REG_CCTIMER0_COUNTER_B                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_COUNTER_B))
#define REG_CCTIMER1_COUNTER_B                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_COUNTER_B))

#define ADDR_CCTIMER32_CAPCMP_C                              (0x1EU)
#define A_CCTIMER32_CAPCMP_C(ba)                             ((ba) + ADDR_CCTIMER32_CAPCMP_C)
#define R_CCTIMER32_CAPCMP_C(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CAPCMP_C(ba)))
#define RES_CCTIMER32_CAPCMP_C                               (0x0U)
#define MSB_CCTIMER32_CAPCMP_C                               15
#define LSB_CCTIMER32_CAPCMP_C                               0
#define AADDR_CCTIMER0_CAPCMP_C                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CAPCMP_C)
#define AADDR_CCTIMER1_CAPCMP_C                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CAPCMP_C)
#define REG_CCTIMER0_CAPCMP_C                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CAPCMP_C))
#define REG_CCTIMER1_CAPCMP_C                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CAPCMP_C))

#define ADDR_CCTIMER32_CAPCMP_D                              (0x20U)
#define A_CCTIMER32_CAPCMP_D(ba)                             ((ba) + ADDR_CCTIMER32_CAPCMP_D)
#define R_CCTIMER32_CAPCMP_D(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CAPCMP_D(ba)))
#define RES_CCTIMER32_CAPCMP_D                               (0x0U)
#define MSB_CCTIMER32_CAPCMP_D                               15
#define LSB_CCTIMER32_CAPCMP_D                               0
#define AADDR_CCTIMER0_CAPCMP_D                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CAPCMP_D)
#define AADDR_CCTIMER1_CAPCMP_D                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CAPCMP_D)
#define REG_CCTIMER0_CAPCMP_D                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CAPCMP_D))
#define REG_CCTIMER1_CAPCMP_D                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CAPCMP_D))

#define ADDR_CCTIMER32_COUNTER_C                             (0x22U)
#define A_CCTIMER32_COUNTER_C(ba)                            ((ba) + ADDR_CCTIMER32_COUNTER_C)
#define R_CCTIMER32_COUNTER_C(ba)                            (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_COUNTER_C(ba)))
#define RES_CCTIMER32_COUNTER_C                              (0x0U)
#define MSB_CCTIMER32_COUNTER_C                              15
#define LSB_CCTIMER32_COUNTER_C                              0
#define AADDR_CCTIMER0_COUNTER_C                             (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_COUNTER_C)
#define AADDR_CCTIMER1_COUNTER_C                             (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_COUNTER_C)
#define REG_CCTIMER0_COUNTER_C                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_COUNTER_C))
#define REG_CCTIMER1_COUNTER_C                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_COUNTER_C))

#define ADDR_CCTIMER32_COUNTER_D                             (0x24U)
#define A_CCTIMER32_COUNTER_D(ba)                            ((ba) + ADDR_CCTIMER32_COUNTER_D)
#define R_CCTIMER32_COUNTER_D(ba)                            (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_COUNTER_D(ba)))
#define RES_CCTIMER32_COUNTER_D                              (0x0U)
#define MSB_CCTIMER32_COUNTER_D                              15
#define LSB_CCTIMER32_COUNTER_D                              0
#define AADDR_CCTIMER0_COUNTER_D                             (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_COUNTER_D)
#define AADDR_CCTIMER1_COUNTER_D                             (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_COUNTER_D)
#define REG_CCTIMER0_COUNTER_D                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_COUNTER_D))
#define REG_CCTIMER1_COUNTER_D                               (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_COUNTER_D))

#define ADDR_CCTIMER32_IRQ_STATUS                            (0x26U)
#define A_CCTIMER32_IRQ_STATUS(ba)                           ((ba) + ADDR_CCTIMER32_IRQ_STATUS)
#define R_CCTIMER32_IRQ_STATUS(ba)                           (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_IRQ_STATUS(ba)))
#define RES_CCTIMER32_IRQ_STATUS                             (0x0U)
#define MSB_CCTIMER32_IRQ_STATUS                             15
#define LSB_CCTIMER32_IRQ_STATUS                             0
#define AADDR_CCTIMER0_IRQ_STATUS                            (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_IRQ_STATUS)
#define AADDR_CCTIMER1_IRQ_STATUS                            (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_IRQ_STATUS)
#define REG_CCTIMER0_IRQ_STATUS                              (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_IRQ_STATUS))
#define REG_CCTIMER1_IRQ_STATUS                              (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_IRQ_STATUS))

#define ADDR_CCTIMER32_IRQ_MASK                              (0x28U)
#define A_CCTIMER32_IRQ_MASK(ba)                             ((ba) + ADDR_CCTIMER32_IRQ_MASK)
#define R_CCTIMER32_IRQ_MASK(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_IRQ_MASK(ba)))
#define RES_CCTIMER32_IRQ_MASK                               (0x0U)
#define MSB_CCTIMER32_IRQ_MASK                               15
#define LSB_CCTIMER32_IRQ_MASK                               0
#define AADDR_CCTIMER0_IRQ_MASK                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_IRQ_MASK)
#define AADDR_CCTIMER1_IRQ_MASK                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_IRQ_MASK)
#define REG_CCTIMER0_IRQ_MASK                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_IRQ_MASK))
#define REG_CCTIMER1_IRQ_MASK                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_IRQ_MASK))

#define ADDR_CCTIMER32_IRQ_VENABLE                           (0x2AU)
#define A_CCTIMER32_IRQ_VENABLE(ba)                          ((ba) + ADDR_CCTIMER32_IRQ_VENABLE)
#define R_CCTIMER32_IRQ_VENABLE(ba)                          (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_IRQ_VENABLE(ba)))
#define RES_CCTIMER32_IRQ_VENABLE                            (0x0U)
#define MSB_CCTIMER32_IRQ_VENABLE                            3
#define LSB_CCTIMER32_IRQ_VENABLE                            0
#define AADDR_CCTIMER0_IRQ_VENABLE                           (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_IRQ_VENABLE)
#define AADDR_CCTIMER1_IRQ_VENABLE                           (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_IRQ_VENABLE)
#define REG_CCTIMER0_IRQ_VENABLE                             (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_IRQ_VENABLE))
#define REG_CCTIMER1_IRQ_VENABLE                             (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_IRQ_VENABLE))

#define ADDR_CCTIMER32_IRQ_VDISABLE                          (0x2CU)
#define A_CCTIMER32_IRQ_VDISABLE(ba)                         ((ba) + ADDR_CCTIMER32_IRQ_VDISABLE)
#define R_CCTIMER32_IRQ_VDISABLE(ba)                         (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_IRQ_VDISABLE(ba)))
#define RES_CCTIMER32_IRQ_VDISABLE                           (0x0U)
#define MSB_CCTIMER32_IRQ_VDISABLE                           3
#define LSB_CCTIMER32_IRQ_VDISABLE                           0
#define AADDR_CCTIMER0_IRQ_VDISABLE                          (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_IRQ_VDISABLE)
#define AADDR_CCTIMER1_IRQ_VDISABLE                          (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_IRQ_VDISABLE)
#define REG_CCTIMER0_IRQ_VDISABLE                            (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_IRQ_VDISABLE))
#define REG_CCTIMER1_IRQ_VDISABLE                            (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_IRQ_VDISABLE))

#define ADDR_CCTIMER32_IRQ_VMAX                              (0x2EU)
#define A_CCTIMER32_IRQ_VMAX(ba)                             ((ba) + ADDR_CCTIMER32_IRQ_VMAX)
#define R_CCTIMER32_IRQ_VMAX(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_IRQ_VMAX(ba)))
#define RES_CCTIMER32_IRQ_VMAX                               (0x10U)
#define MSB_CCTIMER32_IRQ_VMAX                               4
#define LSB_CCTIMER32_IRQ_VMAX                               0
#define AADDR_CCTIMER0_IRQ_VMAX                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_IRQ_VMAX)
#define AADDR_CCTIMER1_IRQ_VMAX                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_IRQ_VMAX)
#define REG_CCTIMER0_IRQ_VMAX                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_IRQ_VMAX))
#define REG_CCTIMER1_IRQ_VMAX                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_IRQ_VMAX))

#define ADDR_CCTIMER32_IRQ_VNO                               (0x30U)
#define A_CCTIMER32_IRQ_VNO(ba)                              ((ba) + ADDR_CCTIMER32_IRQ_VNO)
#define R_CCTIMER32_IRQ_VNO(ba)                              (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_IRQ_VNO(ba)))
#define RES_CCTIMER32_IRQ_VNO                                (0x10U)
#define MSB_CCTIMER32_IRQ_VNO                                4
#define LSB_CCTIMER32_IRQ_VNO                                0
#define AADDR_CCTIMER0_IRQ_VNO                               (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_IRQ_VNO)
#define AADDR_CCTIMER1_IRQ_VNO                               (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_IRQ_VNO)
#define REG_CCTIMER0_IRQ_VNO                                 (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_IRQ_VNO))
#define REG_CCTIMER1_IRQ_VNO                                 (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_IRQ_VNO))

#define ADDR_CCTIMER32_CFG_INTF                              (0x40U)
#define A_CCTIMER32_CFG_INTF(ba)                             ((ba) + ADDR_CCTIMER32_CFG_INTF)
#define R_CCTIMER32_CFG_INTF(ba)                             (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CFG_INTF(ba)))
#define RES_CCTIMER32_CFG_INTF                               (0x0U)
#define MSB_CCTIMER32_CFG_INTF                               15
#define LSB_CCTIMER32_CFG_INTF                               0
#define AADDR_CCTIMER0_CFG_INTF                              (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CFG_INTF)
#define AADDR_CCTIMER1_CFG_INTF                              (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CFG_INTF)
#define REG_CCTIMER0_CFG_INTF                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CFG_INTF))
#define REG_CCTIMER1_CFG_INTF                                (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CFG_INTF))

#define ADDR_CCTIMER32_CFG_INTF_PRE                          (0x42U)
#define A_CCTIMER32_CFG_INTF_PRE(ba)                         ((ba) + ADDR_CCTIMER32_CFG_INTF_PRE)
#define R_CCTIMER32_CFG_INTF_PRE(ba)                         (*(volatile unsigned short *)((unsigned int)A_CCTIMER32_CFG_INTF_PRE(ba)))
#define RES_CCTIMER32_CFG_INTF_PRE                           (0x0U)
#define MSB_CCTIMER32_CFG_INTF_PRE                           15
#define LSB_CCTIMER32_CFG_INTF_PRE                           0
#define AADDR_CCTIMER0_CFG_INTF_PRE                          (BASE_ADDR_CCTIMER0 + ADDR_CCTIMER32_CFG_INTF_PRE)
#define AADDR_CCTIMER1_CFG_INTF_PRE                          (BASE_ADDR_CCTIMER1 + ADDR_CCTIMER32_CFG_INTF_PRE)
#define REG_CCTIMER0_CFG_INTF_PRE                            (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER0_CFG_INTF_PRE))
#define REG_CCTIMER1_CFG_INTF_PRE                            (*(volatile unsigned short *)((unsigned int)AADDR_CCTIMER1_CFG_INTF_PRE))




#endif
