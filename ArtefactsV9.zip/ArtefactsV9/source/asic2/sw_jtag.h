/**
* \file 
*
* \brief  Software JTAG debug interface HAL functions - only for FPGA
*
* \author Eaton European Innovation Center 
*
* \version FPGA Release: 10512 / ASIC2 Specification (Revision 2.9.3)
*/
#ifndef __SW_JTAG_H__
#define __SW_JTAG_H__

void sw_jtag_init(void);
void sw_jtag_set_nres(bool value);
void sw_jtag_tap_reset(void);
void sw_jtag_pwr_config(  bool              vreg_vdd5tx_npd,
                          bool              pw_vdd5tx_npd,
                          vreg_vdd3v3_max_t vreg_vdd3v3_max,
                          pw_vpow_range_t   pw_vpow_range,
                          uint8_t                pw_vpow_hyst);

void sw_jtag_cfg_phy( bool                      hrx485_npd,
                      bool                      htx485_npd,
                      bool htx485_slew_enable,
                      htx485_bbm_fast_t         htx485_bbm_fast,
                      htx485_auto_shutdown_t htx485_auto_shutdown,
                      htx485_tempsens_enable_t htx485_tempsens_enable,
                      htx485_tempsens_mask_t htx485_tempsens_mask);
void sw_jtag_set_selout_enable(bool enable);
void sw_jtag_set_selout(bool selout);
void sw_jtag_set_gpo(bool en, bool val);

/**@} */
#endif /* __SW_JTAG_H__ */
