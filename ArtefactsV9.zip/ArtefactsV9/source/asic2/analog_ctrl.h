/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         analog_ctrl.h
*
* @brief        Analog Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __ANALOG_CTRL_H__
#define __ANALOG_CTRL_H__

/**
 * \defgroup analog_ctrl ASIC2 Analog Control HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control Analog Control
 */
/**@{*/ 

#include "device.h"

#include "utils.h"
#include "analog_ctrl_fll.h"

/**@} */
#endif /* __ANALOG_CTRL_H__ */
