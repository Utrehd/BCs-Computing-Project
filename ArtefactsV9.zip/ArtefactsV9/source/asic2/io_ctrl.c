/* FPGA Release: 10512 */
#include "io_ctrl.h"

#define BIT_SEL_MASK 0x1F
#define BIT_DS       0x20
#define BIT_PE       0x40

void io_ctrl_guard_unlock(void) {
   WRITE_REG_16(AADDR_IO_CTRL_GUARD, 0x0042);
}

void io_ctrl_guard_lock(void) {
   WRITE_REG_16(AADDR_IO_CTRL_GUARD, 0x0000);
}

void io_ctrl_config_sel(iomux_pad_t pad, io_pin_func_t value) {
  if (value > BIT_SEL_MASK)
    return;

  uint16_t temp  = (uint16_t) pad;
  uint8_t shift  = temp & 0xF;
  uint8_t offset = (temp >> 8) & 0xFF;
  uint32_t addr  = AADDR_IO_CTRL_S00 + (offset << 1);
  uint16_t reg   = READ_REG_U16(addr);
  reg       = reg & ~(BIT_SEL_MASK << shift);
  reg       = reg |  ((value & BIT_SEL_MASK ) << shift);
  WRITE_REG_16(addr, reg);
}

void io_ctrl_config_ds(iomux_pad_t pad, bool value) {
  uint16_t temp  = (uint16_t) pad;
  uint8_t shift  = temp & 0xF;
  uint8_t offset = (temp >> 8) & 0xFF;
  uint32_t addr  = AADDR_IO_CTRL_S00 + (offset << 1);
  uint16_t reg   = READ_REG_U16(addr);
  reg       = reg & ~(BIT_DS << shift);
  if (value) reg = reg |  (BIT_DS << shift);
  WRITE_REG_16(addr, reg);
}

void io_ctrl_config_pe(iomux_pad_t pad, bool value) {
  uint16_t temp  = (uint16_t) pad;
  uint8_t shift  = temp & 0xF;
  uint8_t offset = (temp >> 8) & 0xFF;
  uint32_t addr  = AADDR_IO_CTRL_S00 + (offset << 1);
  uint16_t reg   = READ_REG_U16(addr);
  reg       = reg & ~(BIT_PE << shift);
  if (value) reg = reg |  (BIT_PE << shift);
  WRITE_REG_16(addr, reg);
}

void io_ctrl_config_swd_hv_conn(io_swd_hv_conn_t swd_hv_conn){
  WRITE_REG_16(AADDR_IO_CTRL_SWD_HV, (uint16_t) swd_hv_conn); 
}

void io_ctrl_config_jtag_dio(bool is_dio){
  WRITE_REG_16(AADDR_IO_CTRL_JTAG_DIO, (uint16_t) is_dio); 
}

void io_ctrl_config_el_ctrl_tia(bool use_ext_tia){
  io_ctrl_el_rx_t io_ctrl_el_rx;
  io_ctrl_el_rx.val = READ_REG_U16(AADDR_IO_CTRL_EL_RX);
  io_ctrl_el_rx.bf.el_rx_sel = use_ext_tia ? 1 : 0;
  WRITE_REG_16(AADDR_IO_CTRL_EL_RX, io_ctrl_el_rx.val); 
}

void io_ctrl_config_el_rx_ds(bool value){
  io_ctrl_el_rx_t io_ctrl_el_rx;
  io_ctrl_el_rx.val = READ_REG_U16(AADDR_IO_CTRL_EL_RX);
  io_ctrl_el_rx.bf.el_rx_ds = value ? 1 : 0;
  WRITE_REG_16(AADDR_IO_CTRL_EL_RX, io_ctrl_el_rx.val); 
}

const iomux_pad_t io_ctrl_const_pin2iomux_pad[] = {
  IOMUX_PAD0,
  IOMUX_PAD1,
  IOMUX_PAD2,
  IOMUX_PAD3,  
  IOMUX_PAD4,
  IOMUX_PAD5,
  IOMUX_PAD6,
  IOMUX_PAD7,  
  IOMUX_PAD8,
  IOMUX_PAD9,
  IOMUX_PAD10,
  IOMUX_PAD11,  
  IOMUX_PAD12,
  IOMUX_PAD13,
  IOMUX_PAD14,
  IOMUX_PAD15,  
  IOMUX_PAD16,
  IOMUX_PAD17,
  IOMUX_PAD18,
  IOMUX_PAD19,  
  IOMUX_PAD20,
  IOMUX_PAD21,
  IOMUX_PAD22,
  IOMUX_PAD23,  
  IOMUX_PAD24,
  IOMUX_PAD25,
  IOMUX_PAD26,
  IOMUX_PAD27,  
  IOMUX_PAD28,
  IOMUX_PAD29,  
  IOMUX_PAD30,
  IOMUX_PAD31,
  IOMUX_PAD32,
  IOMUX_PAD33,  
  IOMUX_PAD34,
  IOMUX_PAD35,
};

iomux_pad_t io_ctrl_pin2iomux_pad(uint8_t i_pin) 
{
  return(io_ctrl_const_pin2iomux_pad[i_pin]);
}