#include "hardware.h"
#include "gpio_api.h"
#include "io_ctrl_api.h"
#include "clk_nres_api.h"
#include "common.h"

/* ############################################################################ */
/* ############################ INTERRUPT CONFIGURATION ####################### */
/* ############################################################################ */

/* ############################################################################ */

static void (*gpio_api_ptr_callback)(void); ///< Pointer to callback function

errors_api_code_e gpio_api_pinout_interrupt_capability( device_pinout gpio_pinout, gpio_irq_t * irq ) {

  if( (gpio_pinout.gpio_group == GPIO_GROUP_0) && ( gpio_pinout.gpio_bits == GPIO_BIT_1) ){
    *irq = GPIO_IRQ_EVT_G0_PIN1;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_0) && ( gpio_pinout.gpio_bits == GPIO_BIT_2) ){
    *irq = GPIO_IRQ_EVT_G0_PIN2;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_0) && ( gpio_pinout.gpio_bits == GPIO_BIT_3) ){
    *irq = GPIO_IRQ_EVT_G0_PIN3;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_0) && ( gpio_pinout.gpio_bits == GPIO_BIT_4) ){
    *irq = GPIO_IRQ_EVT_G0_PIN4;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_1) && ( gpio_pinout.gpio_bits == GPIO_BIT_1) ){
    *irq = GPIO_IRQ_EVT_G1_PIN1;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_1) && ( gpio_pinout.gpio_bits == GPIO_BIT_6) ){
    *irq = GPIO_IRQ_EVT_G1_PIN6;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_1) && ( gpio_pinout.gpio_bits == GPIO_BIT_7) ){
    *irq = GPIO_IRQ_EVT_G1_PIN7;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_1) && ( gpio_pinout.gpio_bits == GPIO_BIT_8) ){
    *irq = GPIO_IRQ_EVT_G1_PIN8;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_2) && ( gpio_pinout.gpio_bits == GPIO_BIT_2) ){
    *irq = GPIO_IRQ_EVT_G2_PIN2;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_2) && ( gpio_pinout.gpio_bits == GPIO_BIT_3) ){
    *irq = GPIO_IRQ_EVT_G2_PIN3;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_2) && ( gpio_pinout.gpio_bits == GPIO_BIT_7) ){
    *irq = GPIO_IRQ_EVT_G2_PIN7;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_2) && ( gpio_pinout.gpio_bits == GPIO_BIT_8) ){
    *irq = GPIO_IRQ_EVT_G2_PIN8;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_3) && ( gpio_pinout.gpio_bits == GPIO_BIT_3) ){
    *irq = GPIO_IRQ_EVT_G3_PIN3;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_3) && ( gpio_pinout.gpio_bits == GPIO_BIT_4) ){
    *irq = GPIO_IRQ_EVT_G3_PIN4;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_3) && ( gpio_pinout.gpio_bits == GPIO_BIT_5) ){
    *irq = GPIO_IRQ_EVT_G3_PIN5;
  }else if( (gpio_pinout.gpio_group == GPIO_GROUP_3) && ( gpio_pinout.gpio_bits == GPIO_BIT_6) ){
    *irq = GPIO_IRQ_EVT_G3_PIN6;
  }else{
    return eError_gpio_api_pin_no_int;
  }
  return eError_none;
}

/* ############################################################################ */

errors_api_code_e gpio_api_enable_irq( device_pinout gpio_pinout ){

  gpio_irq_t irq;

  if( gpio_api_pinout_interrupt_capability( gpio_pinout, &irq ) == eError_none ) {
    gpio_enable_irq( irq, true );
  }else{
    return eError_gpio_api_pin_no_int;
  }
  return eError_none;
}

/* ############################################################################ */

errors_api_code_e gpio_api_disable_irq( device_pinout gpio_pinout ){

  gpio_irq_t irq;

  if( gpio_api_pinout_interrupt_capability( gpio_pinout, &irq ) == eError_none ) {
    gpio_enable_irq( irq, false );
  }else{
    return eError_gpio_api_pin_no_int;
  }
  return eError_none;
}

/* ############################################################################ */

void gpio_api_set_irq_source(device_pinout gpio_pinout, gpio_src_sel_t source) {

  gpio_set_irq_source( gpio_pinout.gpio_group, source );

}

/* ############################################################################ */

errors_api_code_e gpio_api_set_irq_type(device_pinout gpio_pinout, gpio_irq_type_t type) {

  gpio_irq_t irq;

  if( gpio_api_pinout_interrupt_capability( gpio_pinout, &irq ) == eError_none ) {
    gpio_set_irq_type( irq, type );
  }else{
    return eError_gpio_api_pin_no_int;
  }
  return eError_none;
}

/* ############################################################################ */

void gpio_api_callback( void (*ptr_callback_irq)(void) ) {
  gpio_api_ptr_callback = ptr_callback_irq;
}

/* ############################################################################ */

_INTERRUPT_ IRQ_GPIO_Handler( void ) {

  if (gpio_api_ptr_callback!=NULL) {
   gpio_api_ptr_callback();
  }
}

/* ############################################################################ */
/* ########################### PINOUT I/O CONFIGURATION ####################### */
/* ############################################################################ */

errors_api_code_e gpio_api_digital_output(device_pinout gpio_pinout, gpio_api_pin_level_e gpio_level) {

  /* Set the output to low or high level */
  switch(gpio_level){

    case eLow:
      gpio_cmd_out_clr (gpio_pinout.gpio_group, gpio_pinout.gpio_bits);
      break;

    case eHigh:
      gpio_cmd_out_set (gpio_pinout.gpio_group, gpio_pinout.gpio_bits);
      break;

    default:
      return eError_gpio_api_incorrect_level;
  }
  return eError_none;
}

/* ############################################################################ */
errors_api_code_e gpio_api_pin_mode(device_pinout gpio_pinout, gpio_api_pin_conf_e gpio_conf) {

  io_ctrl_api_sel(gpio_pinout, IO_GPIO);

  /* Enable the input or output */
  switch(gpio_conf){

    case eInput:

        gpio_set_ie (gpio_pinout.gpio_group, gpio_pinout.gpio_bits, true);
        gpio_set_oe (gpio_pinout.gpio_group, gpio_pinout.gpio_bits, false);

      break;

    case eOutput:

        gpio_set_ie (gpio_pinout.gpio_group, gpio_pinout.gpio_bits, false);
        gpio_set_oe (gpio_pinout.gpio_group, gpio_pinout.gpio_bits, true);

      break;

    default:
      return eError_gpio_api_incorrect_conf;
  }
  return eError_none;
}

/* ############################################################################ */
errors_api_code_e gpio_api_digital_input(device_pinout gpio_pinout, gpio_api_filter_en_e gpio_filter, bool * gpio_input_status){

  errors_api_code_e error_code = eError_none;
  *gpio_input_status = false;

  switch(gpio_filter){

    case eFilter_none:

      *gpio_input_status = (gpio_pinout.gpio_bits == gpio_get_in (gpio_pinout.gpio_group, gpio_pinout.gpio_bits)) ? true : false;

      break;

    case eFilter_f0:

      if( gpio_api_get_enable_filter(gpio_pinout) == true){
        *gpio_input_status = (gpio_pinout.gpio_bits == gpio_get_f0 (gpio_pinout.gpio_group, gpio_pinout.gpio_bits)) ? true : false;
      }else{
        return eError_gpio_api_no_filter_enabled;
      }
      break;

    case eFilter_f1:

      if( gpio_api_get_enable_filter(gpio_pinout) == true ){
        *gpio_input_status = (gpio_pinout.gpio_bits == gpio_get_f1 (gpio_pinout.gpio_group, gpio_pinout.gpio_bits)) ? true : false;
      }else{
        return eError_gpio_api_no_filter_enabled;
      }
      break;

    default:
      return false;
  }

  return error_code;

}

/* ############################################################################ */
uint8_t gpio_api_bit_get (device_pinout gpio_pinout, gpio_api_filter_en_e gpio_filter) {
  uint16_t tmp;

   switch(gpio_filter){

    case eFilter_none:
      tmp = gpio_get_in (gpio_pinout.gpio_group, gpio_pinout.gpio_bits);
      break;

    case eFilter_f0:
      tmp = gpio_get_f0 (gpio_pinout.gpio_group, gpio_pinout.gpio_bits);
      break;

    case eFilter_f1:
      tmp =  gpio_get_f1 (gpio_pinout.gpio_group, gpio_pinout.gpio_bits);
      break;

    default:
      return false;
  }
  
  if(tmp & gpio_pinout.gpio_bits) {
    return(1);
  }
  else {
    return(0);
  }
}

/* ############################################################################ */
void gpio_api_toogle_digital_output(device_pinout gpio_pinout) {
  gpio_cmd_out_toggle (gpio_pinout.gpio_group, gpio_pinout.gpio_bits);
}

/* ############################################################################ */
/* ############################### FILTER FUNCTIONS ########################### */
/* ############################################################################ */

bool gpio_api_get_enable_filter(device_pinout gpio_pinout){

  bool filter_enable = false;
  gpio_config_t gpio_config;
  gpio_config.val = READ_REG_U16(BASE_ADDR_GPIO);

  switch (gpio_pinout.gpio_group) {
    case GPIO_GROUP_0:
        filter_enable = gpio_config.bf.en0;
        break;
    case GPIO_GROUP_1:
        filter_enable = gpio_config.bf.en1;
        break;
    case GPIO_GROUP_2:
        filter_enable = gpio_config.bf.en2;
        break;
    case GPIO_GROUP_3:
        filter_enable = gpio_config.bf.en3;
        break;
    default:
        break;
    }

  return filter_enable;
}

/* ############################################################################ */

errors_api_code_e gpio_api_set_sampler_f0_time(
  device_pinout gpio_pinout, uint16_t filter_time)
{
  // Init
  uint16_t period_f0;
  errors_api_code_e error_code;

  // Calculate the period for filter
  error_code = gpio_api_calculate_f0(filter_time, &period_f0);

  // Enable filter and set period
  gpio_enable_filter( gpio_pinout.gpio_group, true );
  gpio_set_f0_period( gpio_pinout.gpio_group, period_f0 );

  return error_code;
}

/* ############################################################################ */

errors_api_code_e gpio_api_set_sampler_f1_time_based_on_f0(
  device_pinout gpio_pinout, uint16_t filter_time)
{
  // Init
  uint16_t period_f0;
  uint16_t period_f1;
  errors_api_code_e error_code;

  // Get Filter 0 period
  period_f0 = gpio_get_f0_period(gpio_pinout.gpio_group);
  
  // Calculate f1 based on f0
  error_code = gpio_api_calculate_f1_based_on_f0(
    filter_time, period_f0, &period_f1);
  
  // Enable and set
  gpio_enable_filter( gpio_pinout.gpio_group, true );
  gpio_set_f1_period( gpio_pinout.gpio_group, period_f1 );

  return error_code;
}

/* ############################################################################ */

errors_api_code_e gpio_api_set_sampler_f1_time(
  device_pinout gpio_pinout, uint16_t filter_time)
{
  // Init
  uint16_t period_f1;
  errors_api_code_e error_code;

  // Calcualte periode of filter
  error_code = gpio_api_calculate_f1(filter_time, &period_f1);
  
  // Enable and set period
  gpio_enable_filter( gpio_pinout.gpio_group, true );
  gpio_set_f1_period( gpio_pinout.gpio_group, period_f1 );

  return error_code;
}

/* ############################################################################ */

void gpio_api_set_filter_f0_period(device_pinout gpio_pinout, uint16_t period){

  gpio_enable_filter( gpio_pinout.gpio_group, true );
  gpio_set_f0_period( gpio_pinout.gpio_group, period );

}

/* ############################################################################ */

void gpio_api_set_filter_f1_period(device_pinout gpio_pinout, uint16_t period){

  gpio_enable_filter( gpio_pinout.gpio_group, true );
  gpio_set_f1_period( gpio_pinout.gpio_group, period );

}


/* ############################################################################ */



/* ############################################################################ */

errors_api_code_e gpio_api_calculate_f0(uint16_t filter_time, uint16_t *f0_cfg)
{
  // Init the error code
  errors_api_code_e error_code = eError_none;

  // Get Clock
  uint32_t clock_freq_gpio;
  error_code = clk_nres_api_get_module_clock(CLKPNO_GPIO, &clock_freq_gpio);

  // Bring the clock up to mega HZ
  clock_freq_gpio = clock_freq_gpio / 1000000;
  
  // Calculate period for f0 in given time format
  uint32_t desired_f0_cfg;
  desired_f0_cfg = clock_freq_gpio * filter_time / 3;

  // Set Filter to at least one, for case of error
  *f0_cfg = 1;
    
  // Check if desired frequency is possible and fits in 16 bit uint
  if (common_uint32_fits_in_uint8(desired_f0_cfg))
  {
    // Check if the desired output is not 0
    if (desired_f0_cfg > 0)
    {
      // write value back into given pointer
      *f0_cfg = desired_f0_cfg;
    }
    else
    {
      // Put cannot assign 0 to GPIO
      error_code = eError_gpio_api_pin_cannot_write_zero;        
    }
  }
  else
  {
    // Put error since the desired cfg is to big for the cfg.
    error_code = eError_gpio_api_filter_cfg_period_does_not_fit_uint;
  }
  return error_code;
}

/* ############################################################################ */

errors_api_code_e gpio_api_calculate_f1_based_on_f0(
  uint16_t filter_time, uint16_t f0_cfg, uint16_t * f1_cfg)
{
  // Init the Error Code
  errors_api_code_e error_code = eError_none;

  // Calculate period for f1 in given time format
  uint32_t clock_freq_gpio;
  error_code = clk_nres_api_get_module_clock(CLKPNO_GPIO, &clock_freq_gpio);

  // Bring the clock up to mega HZ
  clock_freq_gpio = clock_freq_gpio / 1000000;
   
  // Calculate period for f1 in given time format by using f0
  uint32_t desired_f1_cfg;
  desired_f1_cfg = (clock_freq_gpio * filter_time)/(3 * f0_cfg);
  
  // Set Filter to at least one, for case of error
  *f1_cfg = 1;

  // Check if desired frequency is possible and fits in 16 bit uint
  if (common_uint32_fits_in_uint16(desired_f1_cfg))
  {
    // Check if the desired output is not 0
    if (desired_f1_cfg > 0)
    {
      // write value back into given pointer
      *f1_cfg = desired_f1_cfg;
    }
    else
    {
      // Put cannot assign 0 to GPIO
      error_code = eError_gpio_api_pin_cannot_write_zero;        
    }
  }
  else
  {
    // Put error since the desired cfg is to big for the cfg.
    error_code = eError_gpio_api_filter_cfg_period_does_not_fit_uint;
  }
  return error_code;
}

/* ############################################################################ */

errors_api_code_e gpio_api_calculate_f1(uint16_t filter_time, uint16_t *f1_cfg)
{
  // Init the Error Code
  errors_api_code_e error_code = eError_none;

  // Calculate period for f1 in given time format
  uint32_t clock_freq_gpio;
  error_code = clk_nres_api_get_module_clock(CLKPNO_GPIO, &clock_freq_gpio);

  // Bring the clock up to mega HZ
  clock_freq_gpio = clock_freq_gpio / 1000000;
  
  // Calculate period for f1 in given time format by using f0
  uint32_t desired_f1_cfg;
  desired_f1_cfg = (clock_freq_gpio * filter_time) / 3;

  // Set Filter to at least one, for case of error
  *f1_cfg = 1;

  // Check if desired frequency is possible and fits in 16 bit uint
  if (common_uint32_fits_in_uint16(desired_f1_cfg))
  {
    // Check if the desired output is not 0
    if (desired_f1_cfg > 0)
    {
      // write value back into given pointer
      *f1_cfg = desired_f1_cfg;
    }
    else
    {
      // Put cannot assign 0 to GPIO
      error_code = eError_gpio_api_pin_cannot_write_zero;        
    }
  }
  else
  {
    // Put error since the desired cfg is to big for the cfg.
    error_code = eError_gpio_api_filter_cfg_period_does_not_fit_uint;
  }
  return error_code;
}