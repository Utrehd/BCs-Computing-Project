/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hv_ctrl_bf.h
*
* @brief        HV Die Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HV_CTRL_BF_H__
#define __HV_CTRL_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_HV_CTRL
#define BASE_ADDR_HV_CTRL 0x40006400U
#endif

#define NUMBER_HV_CTRL 1


/* ############################################################################ */
/**
 * \brief This is an enum class for HV CONTROl instance
 *
 * \ingroup hv_ctrl 
 */ 
typedef enum {
  /**
   * This is instance HV_CTRL
   */ 
  HV_CTRL                        = (int)BASE_ADDR_HV_CTRL
} hv_ctrl_num_t;

// Register bit field definitions

/* HV_CTRL_JTAG_TIMING */

#define MSK_HV_CTRL_JTAG_TIMING                             (0xff)    /* [ 7:0] */

typedef unsigned short hv_ctrl_jtag_timing_t;                         /* [ 7:0] */


/* HV_CTRL_JTAG_IR_CMD */

#define MSK_HV_CTRL_JTAG_IR_CMD_IR                          (0xff)    /* [ 7:0] */
#define RES_HV_CTRL_JTAG_IR_CMD_IR                          (0x00)
#define SFT_HV_CTRL_JTAG_IR_CMD_IR                          (0)
#define LSB_HV_CTRL_JTAG_IR_CMD_IR                          (0)
#define MSB_HV_CTRL_JTAG_IR_CMD_IR                          (7)
#define MSK_HV_CTRL_JTAG_IR_CMD_READ                        (0x1)     /* [8] */
#define RES_HV_CTRL_JTAG_IR_CMD_READ                        (0x0)
#define SFT_HV_CTRL_JTAG_IR_CMD_READ                        (8)
#define LSB_HV_CTRL_JTAG_IR_CMD_READ                        (8)
#define MSB_HV_CTRL_JTAG_IR_CMD_READ                        (8)
#define BIT_HV_CTRL_JTAG_IR_CMD_READ                        (0x100)   /* [8] */
#define MSK_HV_CTRL_JTAG_IR_CMD_TAP_RESET                   (0x1)     /* [9] */
#define RES_HV_CTRL_JTAG_IR_CMD_TAP_RESET                   (0x0)
#define SFT_HV_CTRL_JTAG_IR_CMD_TAP_RESET                   (9)
#define LSB_HV_CTRL_JTAG_IR_CMD_TAP_RESET                   (9)
#define MSB_HV_CTRL_JTAG_IR_CMD_TAP_RESET                   (9)
#define BIT_HV_CTRL_JTAG_IR_CMD_TAP_RESET                   (0x200)   /* [9] */


/* ############################################################################ */
/**
 * \brief This structure describes HV CONTROl JTAG commands
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Perform JTAG IR command when status=0
   */ 
  unsigned short ir                            :    8;       /* [ 7:0] */
  /**
   * 1: perform dummy DR shift after IR shift for reading
   */ 
  unsigned short read                          :    1;       /* [8] */
  /**
   * 1: perform TAP reset sequence instead of IR shift
   */ 
  unsigned short tap_reset                     :    1;       /* [9] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    6;
} hv_ctrl_jtag_ir_cmd_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV CONTROl JTAG commands
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ctrl_jtag_ir_cmd_bf bf;  ///< bit field representation
} hv_ctrl_jtag_ir_cmd_t;


/* HV_CTRL_JTAG_DR_CMD */

#define MSK_HV_CTRL_JTAG_DR_CMD                             (0xffff)  /* [15:0] */

typedef unsigned short hv_ctrl_jtag_dr_cmd_t;                         /* [15:0] */


/* HV_CTRL_JTAG_RESET */

#define MSK_HV_CTRL_JTAG_RESET                              (0x1)     /* [0] */

typedef unsigned short hv_ctrl_jtag_reset_t;                          /* [0] */


/* HV_CTRL_JTAG_SW_CONTROL */

#define MSK_HV_CTRL_JTAG_SW_CONTROL_SW_CONTROL              (0x1)     /* [0] */
#define RES_HV_CTRL_JTAG_SW_CONTROL_SW_CONTROL              (0x0)
#define SFT_HV_CTRL_JTAG_SW_CONTROL_SW_CONTROL              (0)
#define LSB_HV_CTRL_JTAG_SW_CONTROL_SW_CONTROL              (0)
#define MSB_HV_CTRL_JTAG_SW_CONTROL_SW_CONTROL              (0)
#define BIT_HV_CTRL_JTAG_SW_CONTROL_SW_CONTROL              (0x1)     /* [0] */
#define MSK_HV_CTRL_JTAG_SW_CONTROL_TMS                     (0x1)     /* [1] */
#define RES_HV_CTRL_JTAG_SW_CONTROL_TMS                     (0x0)
#define SFT_HV_CTRL_JTAG_SW_CONTROL_TMS                     (1)
#define LSB_HV_CTRL_JTAG_SW_CONTROL_TMS                     (1)
#define MSB_HV_CTRL_JTAG_SW_CONTROL_TMS                     (1)
#define BIT_HV_CTRL_JTAG_SW_CONTROL_TMS                     (0x2)     /* [1] */
#define MSK_HV_CTRL_JTAG_SW_CONTROL_TCK                     (0x1)     /* [2] */
#define RES_HV_CTRL_JTAG_SW_CONTROL_TCK                     (0x0)
#define SFT_HV_CTRL_JTAG_SW_CONTROL_TCK                     (2)
#define LSB_HV_CTRL_JTAG_SW_CONTROL_TCK                     (2)
#define MSB_HV_CTRL_JTAG_SW_CONTROL_TCK                     (2)
#define BIT_HV_CTRL_JTAG_SW_CONTROL_TCK                     (0x4)     /* [2] */
#define MSK_HV_CTRL_JTAG_SW_CONTROL_TDI                     (0x1)     /* [3] */
#define RES_HV_CTRL_JTAG_SW_CONTROL_TDI                     (0x0)
#define SFT_HV_CTRL_JTAG_SW_CONTROL_TDI                     (3)
#define LSB_HV_CTRL_JTAG_SW_CONTROL_TDI                     (3)
#define MSB_HV_CTRL_JTAG_SW_CONTROL_TDI                     (3)
#define BIT_HV_CTRL_JTAG_SW_CONTROL_TDI                     (0x8)     /* [3] */
#define MSK_HV_CTRL_JTAG_SW_CONTROL_TDO                     (0x1)     /* [4] */
#define RES_HV_CTRL_JTAG_SW_CONTROL_TDO                     (0x0)
#define SFT_HV_CTRL_JTAG_SW_CONTROL_TDO                     (4)
#define LSB_HV_CTRL_JTAG_SW_CONTROL_TDO                     (4)
#define MSB_HV_CTRL_JTAG_SW_CONTROL_TDO                     (4)
#define BIT_HV_CTRL_JTAG_SW_CONTROL_TDO                     (0x10)    /* [4] */


/* ############################################################################ */
/**
 * \brief This structure describes HV CONTROl JTAG software control
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * 1: enable fallback software control of JTAG interface
   */ 
  unsigned short sw_control                    :    1;       /* [0] */
  /**
   * TMS (Test Mode Select) signal
   */ 
  unsigned short tms                           :    1;       /* [1] */
  /**
   * TCK (Test Clock) signal
   */ 
  unsigned short tck                           :    1;       /* [2] */
  /**
   * TDI (Test Data In) signal
   */ 
  unsigned short tdi                           :    1;       /* [3] */
  /**
   * TDO (Test Data Out) signal
   */ 
  unsigned short tdo                           :    1;       /* [4] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   11;
} hv_ctrl_jtag_sw_control_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV CONTROl JTAG software control
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ctrl_jtag_sw_control_bf bf;  ///< bit field representation
} hv_ctrl_jtag_sw_control_t;


/* HV_CTRL_GPO_FILTER */

#define MSK_HV_CTRL_GPO_FILTER_IR                           (0xff)    /* [ 7:0] */
#define RES_HV_CTRL_GPO_FILTER_IR                           (0x01)
#define SFT_HV_CTRL_GPO_FILTER_IR                           (0)
#define LSB_HV_CTRL_GPO_FILTER_IR                           (0)
#define MSB_HV_CTRL_GPO_FILTER_IR                           (7)
#define MSK_HV_CTRL_GPO_FILTER_DR_OUT                       (0x1)     /* [8] */
#define RES_HV_CTRL_GPO_FILTER_DR_OUT                       (0x0)
#define SFT_HV_CTRL_GPO_FILTER_DR_OUT                       (8)
#define LSB_HV_CTRL_GPO_FILTER_DR_OUT                       (8)
#define MSB_HV_CTRL_GPO_FILTER_DR_OUT                       (8)
#define BIT_HV_CTRL_GPO_FILTER_DR_OUT                       (0x100)   /* [8] */
#define MSK_HV_CTRL_GPO_FILTER_DR_EN                        (0x1)     /* [9] */
#define RES_HV_CTRL_GPO_FILTER_DR_EN                        (0x1)
#define SFT_HV_CTRL_GPO_FILTER_DR_EN                        (9)
#define LSB_HV_CTRL_GPO_FILTER_DR_EN                        (9)
#define MSB_HV_CTRL_GPO_FILTER_DR_EN                        (9)
#define BIT_HV_CTRL_GPO_FILTER_DR_EN                        (0x200)   /* [9] */
#define MSK_HV_CTRL_GPO_FILTER_REQ_ENABLE                   (0x1)     /* [10] */
#define RES_HV_CTRL_GPO_FILTER_REQ_ENABLE                   (0x0)
#define SFT_HV_CTRL_GPO_FILTER_REQ_ENABLE                   (10)
#define LSB_HV_CTRL_GPO_FILTER_REQ_ENABLE                   (10)
#define MSB_HV_CTRL_GPO_FILTER_REQ_ENABLE                   (10)
#define BIT_HV_CTRL_GPO_FILTER_REQ_ENABLE                   (0x400)   /* [10] */


/* ############################################################################ */
/**
 * \brief This structure describes HV CONTROl GPO filter
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * IR shift value for HV GPO access
   */ 
  unsigned short ir                            :    8;       /* [ 7:0] */
  /**
   * DR shift bit select for HV GPO out
   */ 
  unsigned short dr_out                        :    1;       /* [8] */
  /**
   * DR shift bit select for HV GPO enable
   */ 
  unsigned short dr_en                         :    1;       /* [9] */
  /**
   * Enable EL port requests
   */ 
  unsigned short req_enable                    :    1;       /* [10] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    5;
} hv_ctrl_gpo_filter_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV CONTROl GPO filter
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ctrl_gpo_filter_bf bf;  ///< bit field representation
} hv_ctrl_gpo_filter_t;


/* HV_CTRL_DRIVE_STRENGTH */

#define MSK_HV_CTRL_DRIVE_STRENGTH_JTAG_DS                  (0x1)     /* [0] */
#define RES_HV_CTRL_DRIVE_STRENGTH_JTAG_DS                  (0x0)
#define SFT_HV_CTRL_DRIVE_STRENGTH_JTAG_DS                  (0)
#define LSB_HV_CTRL_DRIVE_STRENGTH_JTAG_DS                  (0)
#define MSB_HV_CTRL_DRIVE_STRENGTH_JTAG_DS                  (0)
#define BIT_HV_CTRL_DRIVE_STRENGTH_JTAG_DS                  (0x1)     /* [0] */
#define MSK_HV_CTRL_DRIVE_STRENGTH_PHY_DS                   (0x1)     /* [1] */
#define RES_HV_CTRL_DRIVE_STRENGTH_PHY_DS                   (0x0)
#define SFT_HV_CTRL_DRIVE_STRENGTH_PHY_DS                   (1)
#define LSB_HV_CTRL_DRIVE_STRENGTH_PHY_DS                   (1)
#define MSB_HV_CTRL_DRIVE_STRENGTH_PHY_DS                   (1)
#define BIT_HV_CTRL_DRIVE_STRENGTH_PHY_DS                   (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes HV CONTROl JTAG Drive strength
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * 
   */ 
  unsigned short jtag_ds                       :    1;       /* [0] */
  /**
   * 
   */ 
  unsigned short phy_ds                        :    1;       /* [1] */
  /**
   * 
   */ 
  unsigned short reserved                      :   14;
} hv_ctrl_drive_strength_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV CONTROl JTAG Drive strength
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ctrl_drive_strength_bf bf;  ///< bit field representation
} hv_ctrl_drive_strength_t;


/* HV_CTRL_IRQ_STATUS */

#define MSK_HV_CTRL_IRQ_STATUS_EVT_TDO_IRQ                  (0x1)     /* [0] */
#define RES_HV_CTRL_IRQ_STATUS_EVT_TDO_IRQ                  (0x0)
#define SFT_HV_CTRL_IRQ_STATUS_EVT_TDO_IRQ                  (0)
#define LSB_HV_CTRL_IRQ_STATUS_EVT_TDO_IRQ                  (0)
#define MSB_HV_CTRL_IRQ_STATUS_EVT_TDO_IRQ                  (0)
#define BIT_HV_CTRL_IRQ_STATUS_EVT_TDO_IRQ                  (0x1)     /* [0] */
#define MSK_HV_CTRL_IRQ_STATUS_JTAG_IDLE                    (0x1)     /* [1] */
#define RES_HV_CTRL_IRQ_STATUS_JTAG_IDLE                    (0x1)
#define SFT_HV_CTRL_IRQ_STATUS_JTAG_IDLE                    (1)
#define LSB_HV_CTRL_IRQ_STATUS_JTAG_IDLE                    (1)
#define MSB_HV_CTRL_IRQ_STATUS_JTAG_IDLE                    (1)
#define BIT_HV_CTRL_IRQ_STATUS_JTAG_IDLE                    (0x2)     /* [1] */
#define MSK_HV_CTRL_IRQ_STATUS_CPU_REQUEST                  (0x1)     /* [2] */
#define RES_HV_CTRL_IRQ_STATUS_CPU_REQUEST                  (0x0)
#define SFT_HV_CTRL_IRQ_STATUS_CPU_REQUEST                  (2)
#define LSB_HV_CTRL_IRQ_STATUS_CPU_REQUEST                  (2)
#define MSB_HV_CTRL_IRQ_STATUS_CPU_REQUEST                  (2)
#define BIT_HV_CTRL_IRQ_STATUS_CPU_REQUEST                  (0x4)     /* [2] */
#define MSK_HV_CTRL_IRQ_STATUS_EL_REQUEST                   (0x1)     /* [3] */
#define RES_HV_CTRL_IRQ_STATUS_EL_REQUEST                   (0x0)
#define SFT_HV_CTRL_IRQ_STATUS_EL_REQUEST                   (3)
#define LSB_HV_CTRL_IRQ_STATUS_EL_REQUEST                   (3)
#define MSB_HV_CTRL_IRQ_STATUS_EL_REQUEST                   (3)
#define BIT_HV_CTRL_IRQ_STATUS_EL_REQUEST                   (0x8)     /* [3] */


/* ############################################################################ */
/**
 * \brief This structure describes HV CONTROl Interrupt status
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * HV irq signal
   */ 
  unsigned short evt_tdo_irq                   :    1;       /* [0] */
  /**
   * JTAG idle
   */ 
  unsigned short jtag_idle                     :    1;       /* [1] */
  /**
   * Request by CPU
   */ 
  unsigned short cpu_request                   :    1;       /* [2] */
  /**
   * Request by EL port
   */ 
  unsigned short el_request                    :    1;       /* [3] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   12;
} hv_ctrl_irq_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV CONTROl Interrupt status
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ctrl_irq_status_bf bf;  ///< bit field representation
} hv_ctrl_irq_status_t;


/* HV_CTRL_IRQ_MASK */

#define MSK_HV_CTRL_IRQ_MASK                                (0xf)     /* [ 3:0] */

typedef unsigned short hv_ctrl_irq_mask_t;                            /* [ 3:0] */


/* HV_CTRL_IRQ_VENABLE */

#define MSK_HV_CTRL_IRQ_VENABLE                             (0x3)     /* [ 1:0] */

typedef unsigned short hv_ctrl_irq_venable_t;                         /* [ 1:0] */


/* HV_CTRL_IRQ_VDISABLE */

#define MSK_HV_CTRL_IRQ_VDISABLE                            (0x3)     /* [ 1:0] */

typedef unsigned short hv_ctrl_irq_vdisable_t;                        /* [ 1:0] */


/* HV_CTRL_IRQ_VMAX */

#define MSK_HV_CTRL_IRQ_VMAX                                (0x7)     /* [ 2:0] */

typedef unsigned short hv_ctrl_irq_vmax_t;                            /* [ 2:0] */


/* HV_CTRL_IRQ_VNO */

#define MSK_HV_CTRL_IRQ_VNO                                 (0x7)     /* [ 2:0] */

typedef unsigned short hv_ctrl_irq_vno_t;                             /* [ 2:0] */



// Register definitions for module
// Instance base address BASE_ADDR_HV_CTRL 0x40006400U ... 

#define ADDR_HV_CTRL_JTAG_TIMING                             (0x00U)
#define A_HV_CTRL_JTAG_TIMING(ba)                            ((ba) + ADDR_HV_CTRL_JTAG_TIMING)
#define R_HV_CTRL_JTAG_TIMING(ba)                            (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_JTAG_TIMING(ba)))
#define RES_HV_CTRL_JTAG_TIMING                              (0x3U)
#define MSB_HV_CTRL_JTAG_TIMING                              7
#define LSB_HV_CTRL_JTAG_TIMING                              0
#define AADDR_HV_CTRL_JTAG_TIMING                            (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_JTAG_TIMING)
#define REG_HV_CTRL_JTAG_TIMING                              (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_JTAG_TIMING))

#define ADDR_HV_CTRL_JTAG_IR_CMD                             (0x02U)
#define A_HV_CTRL_JTAG_IR_CMD(ba)                            ((ba) + ADDR_HV_CTRL_JTAG_IR_CMD)
#define R_HV_CTRL_JTAG_IR_CMD(ba)                            (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_JTAG_IR_CMD(ba)))
#define RES_HV_CTRL_JTAG_IR_CMD                              (0x0U)
#define MSB_HV_CTRL_JTAG_IR_CMD                              9
#define LSB_HV_CTRL_JTAG_IR_CMD                              0
#define AADDR_HV_CTRL_JTAG_IR_CMD                            (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_JTAG_IR_CMD)
#define REG_HV_CTRL_JTAG_IR_CMD                              (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_JTAG_IR_CMD))

#define ADDR_HV_CTRL_JTAG_DR_CMD                             (0x04U)
#define A_HV_CTRL_JTAG_DR_CMD(ba)                            ((ba) + ADDR_HV_CTRL_JTAG_DR_CMD)
#define R_HV_CTRL_JTAG_DR_CMD(ba)                            (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_JTAG_DR_CMD(ba)))
#define RES_HV_CTRL_JTAG_DR_CMD                              (0x0U)
#define MSB_HV_CTRL_JTAG_DR_CMD                              15
#define LSB_HV_CTRL_JTAG_DR_CMD                              0
#define AADDR_HV_CTRL_JTAG_DR_CMD                            (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_JTAG_DR_CMD)
#define REG_HV_CTRL_JTAG_DR_CMD                              (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_JTAG_DR_CMD))

#define ADDR_HV_CTRL_JTAG_RESET                              (0x06U)
#define A_HV_CTRL_JTAG_RESET(ba)                             ((ba) + ADDR_HV_CTRL_JTAG_RESET)
#define R_HV_CTRL_JTAG_RESET(ba)                             (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_JTAG_RESET(ba)))
#define RES_HV_CTRL_JTAG_RESET                               (0x0U)
#define MSB_HV_CTRL_JTAG_RESET                               0
#define LSB_HV_CTRL_JTAG_RESET                               0
#define AADDR_HV_CTRL_JTAG_RESET                             (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_JTAG_RESET)
#define REG_HV_CTRL_JTAG_RESET                               (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_JTAG_RESET))

#define ADDR_HV_CTRL_JTAG_SW_CONTROL                         (0x08U)
#define A_HV_CTRL_JTAG_SW_CONTROL(ba)                        ((ba) + ADDR_HV_CTRL_JTAG_SW_CONTROL)
#define R_HV_CTRL_JTAG_SW_CONTROL(ba)                        (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_JTAG_SW_CONTROL(ba)))
#define RES_HV_CTRL_JTAG_SW_CONTROL                          (0x0U)
#define MSB_HV_CTRL_JTAG_SW_CONTROL                          4
#define LSB_HV_CTRL_JTAG_SW_CONTROL                          0
#define AADDR_HV_CTRL_JTAG_SW_CONTROL                        (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_JTAG_SW_CONTROL)
#define REG_HV_CTRL_JTAG_SW_CONTROL                          (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_JTAG_SW_CONTROL))

#define ADDR_HV_CTRL_GPO_FILTER                              (0x0AU)
#define A_HV_CTRL_GPO_FILTER(ba)                             ((ba) + ADDR_HV_CTRL_GPO_FILTER)
#define R_HV_CTRL_GPO_FILTER(ba)                             (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_GPO_FILTER(ba)))
#define RES_HV_CTRL_GPO_FILTER                               (0x201U)
#define MSB_HV_CTRL_GPO_FILTER                               10
#define LSB_HV_CTRL_GPO_FILTER                               0
#define AADDR_HV_CTRL_GPO_FILTER                             (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_GPO_FILTER)
#define REG_HV_CTRL_GPO_FILTER                               (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_GPO_FILTER))

#define ADDR_HV_CTRL_DRIVE_STRENGTH                          (0x0CU)
#define A_HV_CTRL_DRIVE_STRENGTH(ba)                         ((ba) + ADDR_HV_CTRL_DRIVE_STRENGTH)
#define R_HV_CTRL_DRIVE_STRENGTH(ba)                         (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_DRIVE_STRENGTH(ba)))
#define RES_HV_CTRL_DRIVE_STRENGTH                           (0x0U)
#define MSB_HV_CTRL_DRIVE_STRENGTH                           1
#define LSB_HV_CTRL_DRIVE_STRENGTH                           0
#define AADDR_HV_CTRL_DRIVE_STRENGTH                         (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_DRIVE_STRENGTH)
#define REG_HV_CTRL_DRIVE_STRENGTH                           (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_DRIVE_STRENGTH))

#define ADDR_HV_CTRL_IRQ_STATUS                              (0x10U)
#define A_HV_CTRL_IRQ_STATUS(ba)                             ((ba) + ADDR_HV_CTRL_IRQ_STATUS)
#define R_HV_CTRL_IRQ_STATUS(ba)                             (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_IRQ_STATUS(ba)))
#define RES_HV_CTRL_IRQ_STATUS                               (0x2U)
#define MSB_HV_CTRL_IRQ_STATUS                               3
#define LSB_HV_CTRL_IRQ_STATUS                               0
#define AADDR_HV_CTRL_IRQ_STATUS                             (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_IRQ_STATUS)
#define REG_HV_CTRL_IRQ_STATUS                               (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_IRQ_STATUS))

#define ADDR_HV_CTRL_IRQ_MASK                                (0x14U)
#define A_HV_CTRL_IRQ_MASK(ba)                               ((ba) + ADDR_HV_CTRL_IRQ_MASK)
#define R_HV_CTRL_IRQ_MASK(ba)                               (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_IRQ_MASK(ba)))
#define RES_HV_CTRL_IRQ_MASK                                 (0x0U)
#define MSB_HV_CTRL_IRQ_MASK                                 3
#define LSB_HV_CTRL_IRQ_MASK                                 0
#define AADDR_HV_CTRL_IRQ_MASK                               (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_IRQ_MASK)
#define REG_HV_CTRL_IRQ_MASK                                 (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_IRQ_MASK))

#define ADDR_HV_CTRL_IRQ_VENABLE                             (0x18U)
#define A_HV_CTRL_IRQ_VENABLE(ba)                            ((ba) + ADDR_HV_CTRL_IRQ_VENABLE)
#define R_HV_CTRL_IRQ_VENABLE(ba)                            (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_IRQ_VENABLE(ba)))
#define RES_HV_CTRL_IRQ_VENABLE                              (0x0U)
#define MSB_HV_CTRL_IRQ_VENABLE                              1
#define LSB_HV_CTRL_IRQ_VENABLE                              0
#define AADDR_HV_CTRL_IRQ_VENABLE                            (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_IRQ_VENABLE)
#define REG_HV_CTRL_IRQ_VENABLE                              (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_IRQ_VENABLE))

#define ADDR_HV_CTRL_IRQ_VDISABLE                            (0x1AU)
#define A_HV_CTRL_IRQ_VDISABLE(ba)                           ((ba) + ADDR_HV_CTRL_IRQ_VDISABLE)
#define R_HV_CTRL_IRQ_VDISABLE(ba)                           (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_IRQ_VDISABLE(ba)))
#define RES_HV_CTRL_IRQ_VDISABLE                             (0x0U)
#define MSB_HV_CTRL_IRQ_VDISABLE                             1
#define LSB_HV_CTRL_IRQ_VDISABLE                             0
#define AADDR_HV_CTRL_IRQ_VDISABLE                           (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_IRQ_VDISABLE)
#define REG_HV_CTRL_IRQ_VDISABLE                             (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_IRQ_VDISABLE))

#define ADDR_HV_CTRL_IRQ_VMAX                                (0x1CU)
#define A_HV_CTRL_IRQ_VMAX(ba)                               ((ba) + ADDR_HV_CTRL_IRQ_VMAX)
#define R_HV_CTRL_IRQ_VMAX(ba)                               (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_IRQ_VMAX(ba)))
#define RES_HV_CTRL_IRQ_VMAX                                 (0x4U)
#define MSB_HV_CTRL_IRQ_VMAX                                 2
#define LSB_HV_CTRL_IRQ_VMAX                                 0
#define AADDR_HV_CTRL_IRQ_VMAX                               (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_IRQ_VMAX)
#define REG_HV_CTRL_IRQ_VMAX                                 (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_IRQ_VMAX))

#define ADDR_HV_CTRL_IRQ_VNO                                 (0x1EU)
#define A_HV_CTRL_IRQ_VNO(ba)                                ((ba) + ADDR_HV_CTRL_IRQ_VNO)
#define R_HV_CTRL_IRQ_VNO(ba)                                (*(volatile unsigned short *)((unsigned int)A_HV_CTRL_IRQ_VNO(ba)))
#define RES_HV_CTRL_IRQ_VNO                                  (0x4U)
#define MSB_HV_CTRL_IRQ_VNO                                  2
#define LSB_HV_CTRL_IRQ_VNO                                  0
#define AADDR_HV_CTRL_IRQ_VNO                                (BASE_ADDR_HV_CTRL + ADDR_HV_CTRL_IRQ_VNO)
#define REG_HV_CTRL_IRQ_VNO                                  (*(volatile unsigned short *)((unsigned int)AADDR_HV_CTRL_IRQ_VNO))




#endif
