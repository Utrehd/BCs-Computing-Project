/* FPGA Release: 10512 */
#include "swd.h"

void swd_set_pe_enable(bool en){
  swd_pe_config_lw_t pe_config_lw;
  pe_config_lw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW);
  pe_config_lw.bf.pe_enable  = en  ? 1 : 0;
  WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW, pe_config_lw.val);
}

void swd_set_sdz_enable(bool en){
    swd_pe_config_lw_t pe_config_lw;
    pe_config_lw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW);
    pe_config_lw.bf.sdz_enable = en ? 1 : 0;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW, pe_config_lw.val);
}

void swd_set_sdg_enable(bool en){
    swd_pe_config_lw_t pe_config_lw;
    pe_config_lw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW);
    pe_config_lw.bf.sdg_enable = en ? 1 : 0;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW, pe_config_lw.val);
}

void swd_set_sdw_enable(bool en){
    swd_pe_config_lw_t pe_config_lw;
    pe_config_lw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW);
    pe_config_lw.bf.sdw_enable = en ? 1 : 0;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW, pe_config_lw.val);
}

void swd_set_sdb_enable(bool en){
    swd_pe_config_lw_t pe_config_lw;
    pe_config_lw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW);
    pe_config_lw.bf.sdb_enable = en ? 1 : 0;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW, pe_config_lw.val);
}

void swd_get_pe_config (swd_pe_config_t * config){
  (*config).all.lw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW);
  (*config).all.hw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_HW);
}

void
swd_enable_engine (
  bool pe_enable, 
  bool sdz_enable, 
  bool sdg_enable,
  bool sdw_enable, 
  bool sdb_enable)
{
  swd_set_pe_enable(pe_enable);
  swd_set_sdz_enable(sdz_enable);
  swd_set_sdg_enable(sdg_enable);
  swd_set_sdw_enable(sdw_enable);
  swd_set_sdb_enable(sdb_enable);
}

void
swd_config_engine (bool sdz_no_disack, bool sdw_no_disack,
                      bool sdw_ignore_disack, bool sdw_no_crc32,
                      bool sdb_no_disack, bool sdb_ignore_disack,
                      bool cyc_tx_update, bool cyc_succ_no_res)
{
    swd_pe_config_lw_t pe_config_lw;
    pe_config_lw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW);
    pe_config_lw.bf.sdz_no_disack      = sdz_no_disack     ? 1 : 0;
    pe_config_lw.bf.sdw_no_disack      = sdw_no_disack     ? 1 : 0;
    pe_config_lw.bf.sdw_ignore_disack  = sdw_ignore_disack ? 1 : 0;
    pe_config_lw.bf.sdw_no_crc32       = sdw_no_crc32      ? 1 : 0;
    pe_config_lw.bf.sdb_no_disack      = sdb_no_disack     ? 1 : 0;
    pe_config_lw.bf.sdb_ignore_disack  = sdb_ignore_disack ? 1 : 0;
    pe_config_lw.bf.cyc_tx_update      = cyc_tx_update     ? 1 : 0;
    pe_config_lw.bf.cyc_succ_no_res    = cyc_succ_no_res   ? 1 : 0;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW, pe_config_lw.val);
}

void swd_config_cyc_succ_no_res(bool v){
    swd_pe_config_lw_t pe_config_lw;
    pe_config_lw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW);
    pe_config_lw.bf.cyc_succ_no_res    = v   ? 1 : 0;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW, pe_config_lw.val);
}

void swd_config_sdw_all_disack(bool v){
  swd_pe_config_hw_t pe_config_hw;
  pe_config_hw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_HW);
  pe_config_hw.bf.sdw_all_disack      = v ? 1 : 0;
  WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_HW, pe_config_hw.val);
}

void swd_config_sdb_all_disack(bool v){
  swd_pe_config_hw_t pe_config_hw;
  pe_config_hw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_HW);
  pe_config_hw.bf.sdb_all_disack      = v ? 1 : 0;
  WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_HW, pe_config_hw.val);
}


void
swd_set_module_id (uint8_t module_id)
{
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_GNT_SELF, module_id);
}


void
swd_config_cycl (uint16_t offset, uint16_t length)
{
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_WRITE_OFFSET, offset);
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_WRITE_LENGTH, length);
}


void
swd_start_cycl (uint16_t len, uint8_t tag)
{
    swd_pe_command_t pe_command;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_FRAME_LENGTH, len);
    pe_command.val = 0;
    pe_command.bf.user_tag = tag;
    pe_command.bf.command = SWD_COMMAND_CYC;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_COMMAND, pe_command.val);
}


void
swd_start_acycl (uint8_t module_id, uint8_t tag)
{
    swd_pe_command_t pe_command;
    pe_command.val = 0;
    pe_command.bf.param = module_id;
    pe_command.bf.user_tag = tag;
    pe_command.bf.command = SWD_COMMAND_GNT;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_COMMAND, pe_command.val);
}

void
swd_enable_sync_mode (bool enable, uint16_t len)
{
    if (enable) {
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_FRAME_LENGTH, len);
    }

    swd_pe_config_lw_t pe_config_lw;
    pe_config_lw.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW);
    pe_config_lw.bf.pe_sync = enable ? 1 : 0;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW, pe_config_lw.val);
}

bool
swd_get_pe_result (swd_pe_result_t * pe_result)
{
    swd_pe_result_t result;
    result.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_RESULT);
    if (result.bf.valid) {
        *pe_result = result;
        return true;
    }
    else {
        return false;
    }
}

void
swd_config_status_filter (swd_stat_t status, uint8_t mask, uint16_t offset)
{
    swd_status_mask_offset_t pe_cyc_status;
    pe_cyc_status.val = 0;
    pe_cyc_status.bf.stat_mask = mask;
    pe_cyc_status.bf.stat_offset = offset;
    switch (status) {
    case SWD_STATUS0:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_STATUS0_MASK_OFFSET, pe_cyc_status.val);
        break;
    case SWD_STATUS1:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_STATUS1_MASK_OFFSET, pe_cyc_status.val);
        break;
    case SWD_STATUS2:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_STATUS2_MASK_OFFSET, pe_cyc_status.val);
        break;
    }
}

void swd_start_status_capture (swd_stat_t status)
{
  switch (status) {
  case SWD_STATUS0:
    break;
  case SWD_STATUS1:
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_STATUS1_COMMAND, 1);
    break;
  case SWD_STATUS2:
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_STATUS2_COMMAND, 1);
    break;
  }
}

bool swd_get_next_status_node (swd_stat_t status, uint8_t * module_id)
{
  swd_status_nodes_t status_nodes;
  status_nodes.val = 0;
  switch (status) {
  case SWD_STATUS0:
    break;
  case SWD_STATUS1:
    status_nodes.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_STATUS1_NODES);
    break;
  case SWD_STATUS2:
    status_nodes.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_STATUS2_NODES);
    break;
  }
  if (status_nodes.bf.valid) {
    *module_id = status_nodes.bf.node_id;
    return true;
  }
  return false;
}


bool
swd_get_timeout_id (uint8_t * sizes_entry_id)
{
    swd_pe_cyc_timeout_id_t timeout_id;
    timeout_id.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_TIMEOUT_ID);
    if (timeout_id.bf.valid) {
        *sizes_entry_id = timeout_id.bf.sizes_entry_id;
        return true;
    }
    return false;
}

bool
swd_get_not_replaced_id (uint8_t * sizes_entry_id)
{
    swd_pe_cyc_not_replaced_id_t not_replaced_id;
    not_replaced_id.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_NOT_REPLACED_ID);
    if (not_replaced_id.bf.valid) {
        *sizes_entry_id = not_replaced_id.bf.sizes_entry_id;
        return true;
    }
    return false;
}

void
swd_set_cyc_succ_res_cnt (uint8_t value)
{
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_SUCC_RES_CNT, value);
}

uint8_t 
swd_get_cyc_succ_res_cnt (void){
    return READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_SUCC_RES_CNT);
}

void
swd_set_cyc_rx_cut (swd_cyc_rx_cut_t no, uint16_t offset, uint16_t length)
{
    switch (no) {
    case SWD_CYC_RX_CUT0:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_START0, offset);
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_LENGTH0, length);
        break;
    case SWD_CYC_RX_CUT1:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_START1, offset);
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_LENGTH1, length);
    case SWD_CYC_RX_CUT2:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_START2, offset);
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_LENGTH2, length);
        break;
    }
}
