/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         usi.h
*
* @brief        USI UART DMA API functions
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __USI_UART_DMA_H__
#define __USI_UART_DMA_H__

#include <stdio.h>
#include <errors_api.h>
#include "usi_uart.h"
#include "clk_nres.h"


/**
 * \example example_usi_uart_dma.c
 * This is an example of how to use WDOG0 as system watchdog.
 */
 
/** 
 *  \defgroup usi_uart_dma DMA Function to control UART(USI) with DMA
 *
 *  \ingroup  usi_uart   asic2_api
 *
 *  \brief    USI UART DMA Control functions
 *
 */
/**@{*/    

/**
\verbatim
  When you need to use a serial asynchronous communication with DMA you can use USI.UART peripheral block in ASIC2.

  How to use it:

Set clock domain:

    usi_uart_dma_clock();

Set pads for USI:

    io_ctrl_config_sel()
        Set the specific pads

Configure UART
    
    usi_uart_dma_baudrate()
    usi_uart_dma_init()
    
Prepare DMA for Tx,Rx
    usi_uart_dma_tx()
    usi_uart_dma_rx()
    
Register callbacks
    usi_uart_dma_reg_callback();
    
\endverbatim
  *
  */

// #define     USI_UART_AUTOBAUDRATE_DETECTION_USED
    
#ifndef USI_UART_AUTOBAUDRATE_DETECTION_PERCENTAGE
#define USI_UART_AUTOBAUDRATE_DETECTION_PERCENTAGE 10
#endif

/* ########################################################################## */  
/// Number of bits in one SPI frame
typedef enum {
  DATA_FRAME_8B, ///< 8bits is SPI frame
  DATA_FRAME_16B, ///< 16bits is SPI frame
} usi_spi_data_length_t;

/* ########################################################################## */    
/*
 * This interrupt subroutine is called by NVIC in case of SPI
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 */
void usi_uart_dma_interrupt_subroutine(usi_num_t usi_no );

/* ########################################################################## */  
/**
 * Function to setup USI.UART baudrate
 * acc = (acc + BR_INC) % BR_MOD generates ticks
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_br_mod      bit rate generation: modulus [comm_clk]
 *
 * \param par_br_inc      bit rate generation: increment [comm_clk]
 *
 * \param par_bit_length  half bit length [ticks] 
 */
void usi_uart_dma_baudrate(const usi_num_t usi_no, uint16_t par_br_mod, uint16_t par_br_inc, uint16_t par_bit_length);

/* ########################################################################## */  
/**
 * Function to setup CLOCKs for USI and release reset
 * AS clock is without division and PLL is used as clock source 
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_clock_source selects clock source for USI
 *
 * \param par_as_clk_div clock divider for this AS clock
 *
 */
errors_api_code_e usi_uart_dma_clock(const usi_num_t usi_no, clock_source_t par_clock_source, uint8_t par_as_clk_div);

/* ########################################################################## */  
/**
 * Function to setup USI as UART in DMA mode. 
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_msb_first   TRUE - MSB goes first <br>
 *                        FALSE - LSB goes first 
 * 
 * \param par_data_bits   number of data bits <br>
 *                        0: 8 data bits <br>
 *                        1: 7 data bits <br>
 *
 * \param par_stop_bits   number of stop bits for transmit <br>
 *                        0: one stop bit
 *                        1: two stop bits
 *
 * \param par_par_type    type of parity bit <br>
 *                        0: no parity bit
 *                        1: odd parity bit
 *                        2: even parity bit
 *
 * \param par_cfg_rx_timeout    number of clk clock cycles until timeout event. Timeout is reset with every newly received transfer element. 
 */
void usi_uart_dma_init(const usi_num_t usi_no, usi_uart_bit_order_t par_msb_first, const usi_uart_data_len_t par_data_bits, const usi_uart_stop_bit_t par_stop_bits , const usi_uart_parity_t par_par_type, uint32_t par_cfg_rx_timeout);

/* ########################################################################## */  
/**
 * Prepare data for USI/UART to be sent
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_number_of_data 1..255
 *
 * \param par_p_snd_data pointer to send data
 */
errors_api_code_e usi_uart_dma_tx(usi_num_t usi_no, uint8_t par_number_of_data, void * par_p_snd_data);

/* ########################################################################## */  
/**
 * Prepare data for USI/UART to be received
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_number_of_data 1..255
 *
 * \param par_p_rcv_data pointer to receive data
 */
errors_api_code_e usi_uart_dma_rx(usi_num_t usi_no, uint8_t par_number_of_data, void * par_p_rcv_data);


/* ########################################################################## */  
/**
 * Register callback functions for USI/UART
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_usi_nvic_priority set NVIC priority for this USI
 *
 * \param p_fce_callback_rx_done pointer to function which will be called when buffer (def. by usi_uart_dma_rx) contains received data
 *
 * \param p_fce_callback_error pointer to function which will be called when ERROR occurs
 *
 * \param p_fce_callback_tadr_new pointer to function which will be called when TADR_NEW can accept a new pointer
 *
 */
void usi_uart_dma_reg_callback(usi_num_t usi_no, uint8_t par_usi_nvic_priority, void (*p_fce_callback_rx_done)(void), void (*p_fce_callback_error)(void), void (*p_fce_callback_tadr_new)(void));

/* ########################################################################## */  
/**
 * Get number of received bytes
 *
 * \ingroup usi_uart_dma
 *
 * \return number of received bytes
 *
 */
uint16_t usi_uart_dma_rdlen_get(usi_num_t usi_no);


/* ########################################################################## */  
/**
 * Function to turn on automatic baudrate detection
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 * 
 * \param eMode  bit rate extraction mode
 *
 * \see usi_set_bre_mode()
 */
void usi_uart_dma_autobaudrate_set(usi_num_t usi_no, usi_bre_mode_t eMode);

/* ########################################################################## */  
/**
 * Set baudrates limits
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 * 
 * \param m_dwLowLimit Low baudrate limit
 *
 * \param m_dwHighLimit High baudrate limit
 *
 */
void usi_uart_dma_autobaudrate_limits_set(usi_num_t eUSIno, uint32_t m_dwLowLimit, uint32_t m_dwHighLimit);

/* ########################################################################## */  
/**
 * Get detected baudrate
 *
 * \ingroup usi_uart_dma
 *
 * \param usi_no USI instance (USI0/USI)
 * 
 * \param p_baudrate pointer to measured baudrate
 *
 * \return new baudrate was detected
 */
bool usi_uart_dma_autobaudrate_get(usi_num_t usi_no, uint32_t *p_baudrate);

/**
  * \}
  */
#endif
