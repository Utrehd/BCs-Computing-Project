/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         usi_spi.h
*
* @brief        USI HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SPI_H
#define HAVE_SPI_H

#include "device.h"

#include "usi.h"
#include "usi_irq.h"
#include "usi_bf.h"

/**
 * \example example_usi_spi.c
 * This is an example of how to use USI SPI block.
 */
 
/**
 * \defgroup usi_spi
 *
 * \brief   functions to control SPI by USI
 *
 * \ingroup usi
 *
 * \details How to use it - see code example: @include example_usi_spi.c
 */

/**
 * \brief This enumeration describes USI SPI data bit count to transfer
 *
 * \ingroup usi_spi
 *
 */
typedef enum {
  USI_SPI_DATA_LEN_7, ///<  7 data bits in one to transfer element
  USI_SPI_DATA_LEN_8, ///<  8 data bits in one to transfer element
  USI_SPI_DATA_LEN_9, ///<  9 data bits in one to transfer element
  USI_SPI_DATA_LEN_10,///<  10 data bits in one to transfer element
  USI_SPI_DATA_LEN_11,///<  11 data bits in one to transfer element
  USI_SPI_DATA_LEN_12,///<  12 data bits in one to transfer element
  USI_SPI_DATA_LEN_13,///<  13 data bits in one to transfer element
  USI_SPI_DATA_LEN_14,///<  14 data bits in one to transfer element
  USI_SPI_DATA_LEN_15,///<  15 data bits in one to transfer element
  USI_SPI_DATA_LEN_16,///<  16 data bits in one to transfer element
} usi_spi_data_len_t;

/**
 * \brief This enumeration describes USI SPI bit length selector
 *
 * \ingroup usi_spi
 *
 */
typedef enum {
  USI_SPI_SCK_TIMEOUT_DETECT, ///< bitlength will be detected by incoming sck
  USI_SPI_SCK_TIMEOUT_TICK,   ///< bitlength is determined by internal tick generator
} usi_spi_sck_timeout_sel_t;

/**
 * \brief This enumeration describes USI SPI NSS mode
 *
 * \ingroup usi_spi
 *
 */
typedef enum {
  USI_SPI_NSS_MODE_MASTER_1BIT        = 0, ///< For SPI master - 1 bit length minimum inactive timeout between SPI frames
  USI_SPI_NSS_MODE_MASTER_2BIT        = 1, ///< For SPI master - 2 bits length minimum inactive timeout between SPI frames
  USI_SPI_NSS_MODE_SLAVE_NSS          = 0, ///< For SPI slave -  Only nss can start an SPI frame./Nss can end SPI frame.
  USI_SPI_NSS_MODE_SLAVE_SCK_TIMEOUT  = 1, ///< For SPI slave -  Nss ignored. Ony sck can start SPI frame./Only sck_timeout can end SPI frame
} usi_spi_nss_mode_t;

//=======================================================================
// config
//=======================================================================

/* ############################################################################ */
/**
 * \brief Set SPI phase
 *
 * \param  usi_no   USI instance
 *
 * \param  phase    0: 1st edge shift, 2nd edge sample<br>
 *                  1: 1st edge sample, 2nd edge shift<br>
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_cfg_phase(usi_num_t usi_no, bool phase);

/* ############################################################################ */
/**
 * \brief Set SPI clock polarity
 *
 * \param  usi_no   USI instance
 *
 * \param  polarity  0: clock off level 0<br>
 *                   1: clock off level 1<br>
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_cfg_polarity(usi_num_t usi_no, bool polarity);

/* ############################################################################ */
/**
 * \brief Set SPI data order
 *
 * \param  usi_no   USI instance
 *
 * \param  msb_first  0: LSB transmitted first<br>
 *                    1: MSB transmitted first<br>
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_cfg_msb_first(usi_num_t usi_no, bool msb_first);

/* ############################################################################ */
/**
 * \brief Set SPI mode (master/slave)
 *
 * \param  usi_no   USI instance
 *
 * \param  slave_nmaster  0: SPI master<br>
 *                        1: SPI slave<br>
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_cfg_slave_nmaster(usi_num_t usi_no, bool slave_nmaster);

/* ############################################################################ */
/**
 * \brief Set SPI data frame size
 *
 * \param  usi_no   USI instance
 *
 * \param  data_bits  7..16 data bit count to transfer<br>
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_cfg_data_bits(usi_num_t usi_no, usi_spi_data_len_t data_bits);

/* ############################################################################ */
/**
 * \brief Set SPI chip select mode
 *
 * when SPI interface is configured as master:<br>
 *   minimum SPI frame word shift NSS inactive time between SPI frames<br>
 *   0: 1 bit length<br>
 *   1: 2 bit lengths<br>
 * <br>
 * when SPI interface is configured as slave:<br>
 * 0: Only nss can start an SPI frame.<br>
 *    Nss can end SPI frame.<br>
 * 1: Nss ignored.<br>
 *    Ony sck can start SPI frame.<br>
 *    Only sck_timeout can end SPI frame (see CFG_SPI_SCK_TIMEOUT)<br>
 *
 * \see nss_mode
 *
 * \param  usi_no   USI instance
 *
 * \param  nss_mode  Chip selet mode
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_cfg_nss_mode(usi_num_t usi_no, usi_spi_nss_mode_t nss_mode);


/* ############################################################################ */
/**
 * \brief Set SPI sdo behavioral for high impedance mode
 *
 * when SPI interface is configured as master:<br>
 *   this config bit is ignored<br>
 * when SPI interface is configured as slave:<br>
 *   0: always drive sdo (sdo_oe=1)<br>
 *   1: sdo switched to high Z when nss is not asserted<br>
 *
 * \param  usi_no   USI instance
 *  
 * \param  sdo_high_z  set behavioral of sdo signal
 *  
 * \ingroup usi_spi
 * 
 */ 
void usi_spi_cfg_sdo_high_z(usi_num_t usi_no, bool sdo_high_z);

/* ############################################################################ */
/**
 * \brief Set SPI SDI interrupt level
 *
 * \param  usi_no   USI instance
 *
 * \param  sdi_irq_pol  SDI interrupt active level when nss is not asserted
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_cfg_sdi_irq_pol(usi_num_t usi_no, bool sdi_irq_pol);

/* ############################################################################ */
/**
 * \brief Set SPI SCK timeout
 *
 * when SPI interface is configured as master:
 *   this config value is ignored
 * when SPI interface is configured as slave:
 *   2..MAX: SPI frame ends when sck_timeout bit periods have
 *
 * See timing diagram on 
 * <a href="http://wavedrom.com/editor.html?%7B%20signal%3A%20%5B%0A%20%20%0A%20%20%7B%20name%3A%20%22clk%22%2C%20%20wave%3A%20%22h..lhlhlhlhlhlhlhlh..........lhlhlhlhlhlhlhlh............%22%20%7D%2C%0A%20%20%7B%20name%3A%20%22sdi%2Fsdo%22%2C%20%20wave%3A%20%22x..5...............x.........5...............x...........%22%2C%20data%3A%20%5B%22data0%22%2C%20%22data1%22%5D%20%7D%2C%0A%20%20%7B%20name%3A%20%22USI_IRQ_RADR_DONE_NEMPTY%22%2C%20wave%3A%20%220..................10........................10..........%22%20%7D%2C%0A%20%20%7B%20name%3A%20%22SCK_TIMEOUT_CNT%22%2C%20wave%3A%20%220..................33333330..................33333330....%22%20%2C%20data%3A%20%5B%226%22%2C%20%225%22%2C%20%224%22%2C%20%223%22%2C%20%222%22%2C%20%221%22%2C%20%220%22%2C%226%22%2C%20%225%22%2C%20%224%22%2C%20%223%22%2C%20%222%22%2C%20%221%22%2C%20%220%22%5D%20%7D%2C%0A%20%20%7B%20name%3A%20%22USI_IRQ_SCK_TIMEOUT%22%2C%20wave%3A%20%220........................10........................10....%22%20%7D%2C%0A%20%20%0A%20%20%7B%20name%3A%20%22USI%20needs%20new%20pointer%22%2C%20wave%3A%20%220.........................3..0......................3..0.%22%20%7D%2C%0A%20%20%0A%5D%7D%0A">SPI SLAVE USI</a>
 * where is described how this USI SPI slave works in USI_DMA_MODE_LENGTH mode.
 *
 * According this diagram you should update new pointer to DMA FIFO after SCK_TIMEOUT interrupt is received.
 *
 * \param  usi_no   USI instance
 *
 * \param  sck_timeout  value of SCK timeout 
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_cfg_sck_timeout(usi_num_t usi_no, uint8_t sck_timeout);

/* ############################################################################ */
/**
 * \brief Set SPI bitlength generator
 *
 * \param  usi_no   USI instance
 *
 * \param  bitlength_sel   0: bitlength will be detected by incoming sck.<br>
 *                         1: bitlength is determined by internal tick generator.<br>
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_cfg_sck_timeout_bitlength_sel(usi_num_t usi_no, usi_spi_sck_timeout_sel_t bitlength_sel);

/* ############################################################################ */
/**
 * \brief Set SPI early miso
 *
 *        Number of comm clock cycles after previous sampling edge,
 *        additionally to required time for resynchronization (0.5 � 1.5 comm clock cycles) and edge detection (1 comm clock cycle).
 *        Has to be selected that SDO output matches correct shift edge.
 *
 * \param  usi_no   USI instance
 *
 * \param  phase    0: disabled<br>
 *                  >0 : early sdo output is enabled only for Slave<br>
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_set_cfg_early_sdo(usi_num_t usi_no, uint8_t phase);

/* ############################################################################ */
/**
 * \brief Get SPI early miso
 *
 * \see usi_spi_set_cfg_early_sdo
 *
 * \param  usi_no   USI instance
 *
 * \return phase    0: disabled<br>
 *                  >0 : early sdo output is enabled only for Slave<br>
 *
 * \ingroup usi_spi
 * 
 */
uint8_t   usi_spi_get_cfg_early_sdo(usi_num_t usi_no);

//=======================================================================
// status
//=======================================================================

/* ############################################################################ */
/**
 * \brief Is SPI configured for process words (9bits and more long frames)
 *
 * \see usi_spi_set_cfg_early_sdo
 *
 * \param  usi_no   USI instance
 *
 * \return word frames
 *
 * \ingroup usi_spi
 * 
 */
bool usi_spi_is_word_mode(usi_num_t usi_no);

//=======================================================================
// simple usage DMA wrapper
//=======================================================================

/* ############################################################################ */
/**
 * \brief Simple SPI inicialization, to be able to send/receive 10 words. 
 *        DMA mode is set to transfer mode in case of slave, othewise to length mode
 *
 * \see   usi_spi_set_cfg_early_sdo
 *
 * \param  usi_no   USI instance
 *
 * \param slave_nmaster set slave (true) or master (false) mode 
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_init(usi_num_t usi_no, bool slave_nmaster);

// use prepare only when slave
/* ############################################################################ */
/**
 * \brief Prepare receive structure for slave only and put it into DMA when it is available
 *
 * \see   usi_spi_set_cfg_early_sdo
 *
 * \param  usi_no   USI instance
 *
 * \param slave_nmaster set slave (true) or master (false) mode 
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_prepare_recv_dma(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief Execute SPI trasaction (read/write). It uses usi_spi_prepare_recv_dma in case of SPI slave
 *
 * \see   usi_spi_set_cfg_early_sdo
 *
 * \param  usi_no   USI instance
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_immediate_transfer(usi_num_t usi_no);

// master:
// - use receive after transmit
// - calling transmit with !keep_nss will call prepare_recv_dma and perform transfer
/* ############################################################################ */
/**
 * \brief Transmit SPI data
 *
 * \see   usi_spi_receive_data
 *
 * \param  usi_no   USI instance
 *
 * \param  data     data to be sent
 *
 * \param  keep_nss calling transmit with !keep_nss will call prepare_recv_dma and perform transfer
 *
 * \ingroup usi_spi
 * 
 */
void usi_spi_transmit_data(usi_num_t usi_no, uint16_t data, bool keep_nss);

/* ############################################################################ */
/**
 * \brief Receive SPI data
 *
 * \see   usi_spi_receive_data
 *
 * \param  usi_no   USI instance
 *
 * \param  data     received data
 *
 * \ingroup usi_spi
 * 
 */
bool usi_spi_receive_data(usi_num_t usi_no, uint16_t *data);

/* ############################################################################ */
/**
 * \brief Transmit and Receive SPI data
 *
 * \see   usi_spi_receive_data
 *
 * \param  usi_no       USI instance
 *
 * \param  tdata        data to be sent
 *
 * \param  rdata        received data
 *
 * \param  rx_maxlen    maximum length of the receive buffer in words
 *
 * \param  tx_len       length of the transmit transfer elements
 *
 * \param  sdo_oe_ctrl  sdo_oe=1 from start of frame to end of transmission (tdlen reached). Output also depends on CFG_SPI_BL.sdo_high_z. 
 *
 * \ingroup usi_spi 
 * 
 */
// use either above byte-level functions or full frame transceive function
uint16_t usi_spi_transceive_frame(usi_num_t usi_no, void * tdata, void * rdata, uint16_t rx_maxlen, uint16_t tx_len, bool keep_nss, bool sdo_oe_ctrl);

#endif /* HAVE_SPI_H */

