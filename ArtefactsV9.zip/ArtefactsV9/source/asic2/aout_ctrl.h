/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         aout_ctrl.h
*
* @brief        Aout and Aout Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __AOUT_CTRL_H__
#define __AOUT_CTRL_H__

/**
 * \example example_aout_ctrl.c
 * This is an example of how to use AOUT Control block.
 */

/**
 * \defgroup aout_ctrl ASIC2 Aout and Aout Control HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control Aout and Aout Control
 *
 * \details See code example: @include example_aout_ctrl.c
 */
/**@{*/ 

#include "device.h"

#include "aout_ctrl_bf.h"

/**
 * \brief This is an enum class for AOUT Control to identify DACs
 *
 * \ingroup aout_ctrl
 *
 */
typedef enum {
  AOUT_DAC0 = 0,
  AOUT_DAC1 = 1,
} aout_ctrl_dac_sel_t;

/* ############################################################################ */
/**
 * \brief   Function to set the configuration of AOUT Control
 *
 * \ingroup aout_ctrl
 * 
 * \param cfg FLL configuration
 *
 * \param dac_sel Selection of DAC
 *
 * \note aout_ctrl_cfg_t: <br>
 *              bit 0 - en: 0: sigma delta modulator for channel 0 /1 stopped and its integrators cleared. 1: sigma delta modulator for channel 0/1 running<br>
 *              bits 6:1 - div: update period of the modulator in clock cycles (div +1) Note: For best performance, set a value that the DAC is clocked with 2 MHz<br>
 *              bits 10:7 - c1: coef1 = c1/16<br>
 *              bit 11 - sync_en: 1: DAC*_SYNC is transferred to DAC* when sync is asserted<br>
 *              bit 12 - aout_npd: 1: power on the analog aout<br>
 *              bit 13 - aout_oe: 1: Output enable for the lowpass filter<br>
 *              bit 14 - ext_feedback_enable: 1: use pad node as filter feedback (small external load currents can be compensated). 0: use internal node as filter feedback (better stability with high external cap)<br>
 *              bit 15 - reserved <br>
 *
 *  \note aout_ctrl_dac_sel_t: <br>
 *              0: DAC0 selected <br>
 *              1: DAC1 selected <br>
 *
 */
void set_aout_ctrl_cfg(aout_ctrl_dac_sel_t dac_sel, aout_ctrl_cfg_t cfg);

/* ############################################################################ */
/**
 * \brief   Function to set the value to DAC modulator
 *
 * \ingroup aout_ctrl
 * 
 * \param val Current value applied to the DAC modulators. Writing to this address will write to registers DAC? and DAC?_SYNC simultaneously
 *
 * \param dac_sel Selection of DAC
 *
 *  \note aout_ctrl_dac_sel_t: <br>
 *              0: DAC0 selected <br>
 *              1: DAC1 selected <br>
 *
 */
void set_aout_ctrl_dac(aout_ctrl_dac_sel_t dac_sel, uint16_t val);

/* ############################################################################ */
/**
 * \brief   Function to set the sync value to DAC modulator
 *
 * \ingroup aout_ctrl
 * 
 * \param val value is transfered to register DAC? when a sync pulse arrives
 *
 * \param dac_sel Selection of DAC
 *
 *  \note aout_ctrl_dac_sel_t: <br>
 *              0: DAC0 selected <br>
 *              1: DAC1 selected <br>
 *
 */
void set_aout_ctrl_dac_sync(aout_ctrl_dac_sel_t dac_sel, uint16_t val);

/* ############################################################################ */
/**
 * \brief   Function to read AOUT Control configuration
 *
 * \ingroup aout_ctrl
 * 
 * \return Current AOUT Control configuration
 */
aout_ctrl_cfg_t get_aout_ctrl_cfg(aout_ctrl_dac_sel_t dac_sel);

/* ############################################################################ */
/**
 * \brief   Function to read DAC modulator value
 *
 * \ingroup aout_ctrl
 * 
 * \return Current DAC modulator value
 */
uint16_t get_aout_ctrl_dac(aout_ctrl_dac_sel_t dac_sel);

/* ############################################################################ */
/**
 * \brief   Function to read DAC modulator sync value
 *
 * \ingroup aout_ctrl
 * 
 * \return Current DAC modulator sync value
 */
uint16_t get_aout_ctrl_dac_sync(aout_ctrl_dac_sel_t dac_sel);

/**@} */
#endif /* __AOUT_CTRL_H__ */
