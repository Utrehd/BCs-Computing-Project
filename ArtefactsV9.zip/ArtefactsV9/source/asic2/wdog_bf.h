/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         wdog_bf.h
*
* @brief        Watchdog and Guard HAL functions
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __WDOG_BF_H__
#define __WDOG_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_WDOG0
#define BASE_ADDR_WDOG0 0x40006100U
#endif
#ifndef BASE_ADDR_GUARD0
#define BASE_ADDR_GUARD0 0x40006300U
#endif
#ifndef BASE_ADDR_GUARD1
#define BASE_ADDR_GUARD1 0x40006E00U
#endif
#ifndef BASE_ADDR_WDOG1
#define BASE_ADDR_WDOG1 0x40006E80U
#endif

#define MULTIPLE_WDOG
#define NUMBER_WDOG 4

/**
  * \brief This is an enum class for WDOG to define instancies.
  *
  * \ingroup wdog
  */ 
typedef enum {
  WDOG0                          = (int)BASE_ADDR_WDOG0,  ///< this is instance WDOG0
  GUARD0                         = (int)BASE_ADDR_GUARD0, ///< this is instance GUARD0
  GUARD1                         = (int)BASE_ADDR_GUARD1, ///< this is instance GUARD1
  WDOG1                          = (int)BASE_ADDR_WDOG1   ///< this is instance WDOG1
} wdog_num_t;

// Register bit field definitions

/* WDOG_SEQ_INIT */

#define MSK_WDOG_SEQ_INIT                                   (0xff)    /* [ 7:0] */

typedef unsigned short wdog_seq_init_t;                               /* [ 7:0] */


/* WDOG_SEQ_LEN */

#define MSK_WDOG_SEQ_LEN                                    (0xff)    /* [ 7:0] */

typedef unsigned short wdog_seq_len_t;                                /* [ 7:0] */


/* WDOG_TIME_INTERVAL_LW */

#define MSK_WDOG_TIME_INTERVAL_LW                           (0xffff)  /* [15:0] */

typedef unsigned short wdog_time_interval_lw_t;                       /* [15:0] */


/* WDOG_TIME_INTERVAL_HW */

#define MSK_WDOG_TIME_INTERVAL_HW                           (0xffff)  /* [15:0] */

typedef unsigned short wdog_time_interval_hw_t;                       /* [15:0] */


/* WDOG_STATUS */

#define MSK_WDOG_STATUS_ENABLE                              (0x1)     /* [0] */
#define RES_WDOG_STATUS_ENABLE                              (0x0)
#define SFT_WDOG_STATUS_ENABLE                              (0)
#define LSB_WDOG_STATUS_ENABLE                              (0)
#define MSB_WDOG_STATUS_ENABLE                              (0)
#define BIT_WDOG_STATUS_ENABLE                              (0x1)     /* [0] */
#define MSK_WDOG_STATUS_ALLOK                               (0x1)     /* [1] */
#define RES_WDOG_STATUS_ALLOK                               (0x0)
#define SFT_WDOG_STATUS_ALLOK                               (1)
#define LSB_WDOG_STATUS_ALLOK                               (1)
#define MSB_WDOG_STATUS_ALLOK                               (1)
#define BIT_WDOG_STATUS_ALLOK                               (0x2)     /* [1] */

/** 
 * \brief This structure describes WDOG status register
 *
 * \ingroup wdog
 */
typedef struct {
  unsigned short enable                        :    1;       ///< 1: wdog is running, 0: wdog is disabled
  unsigned short allok                         :    1;       ///< current value of the outgoing all ok signal which goes to other peripherals
  unsigned short reserved                      :   14;
} wdog_status_bf;

/**
 * \brief Conversion type between word and bit representation of WDOG status register
 *
 * \ingroup wdog
 *
 */
typedef union {
  unsigned short val; ///< word representation
  wdog_status_bf bf;  ///< bit field representation
} wdog_status_t;


/* WDOG_TIME_LAST_LEFT_LW */

#define MSK_WDOG_TIME_LAST_LEFT_LW                          (0xffff)  /* [15:0] */

typedef unsigned short wdog_time_last_left_lw_t;                      /* [15:0] */


/* WDOG_TIME_LAST_LEFT_HW */

#define MSK_WDOG_TIME_LAST_LEFT_HW                          (0xffff)  /* [15:0] */

typedef unsigned short wdog_time_last_left_hw_t;                      /* [15:0] */


/* WDOG_TIMER */

#define MSK_WDOG_TIMER                                      (0xffff)  /* [15:0] */

typedef unsigned short wdog_timer_t;                                  /* [15:0] */


/* WDOG_COMMAND */

#define MSK_WDOG_COMMAND                                    (0xff)    /* [ 7:0] */

typedef unsigned short wdog_command_t;                                /* [ 7:0] */


/* WDOG_MAGIC_COOKIE */

#define MSK_WDOG_MAGIC_COOKIE                               (0xff)    /* [ 7:0] */

typedef unsigned short wdog_magic_cookie_t;                           /* [ 7:0] */



// Register definitions for module
// Instance base address BASE_ADDR_WDOG0 0x40006100U ... 
// Instance base address BASE_ADDR_GUARD0 0x40006300U ... 
// Instance base address BASE_ADDR_GUARD1 0x40006E00U ... 
// Instance base address BASE_ADDR_WDOG1 0x40006E80U ... 

#define ADDR_WDOG_SEQ_INIT                                   (0x00U)
#define A_WDOG_SEQ_INIT(ba)                                  ((ba) + ADDR_WDOG_SEQ_INIT)
#define R_WDOG_SEQ_INIT(ba)                                  (*(volatile unsigned short *)((unsigned int)A_WDOG_SEQ_INIT(ba)))
#define RES_WDOG_SEQ_INIT                                    (0x0U)
#define MSB_WDOG_SEQ_INIT                                    7
#define LSB_WDOG_SEQ_INIT                                    0
#define AADDR_WDOG0_SEQ_INIT                                 (BASE_ADDR_WDOG0 + ADDR_WDOG_SEQ_INIT)
#define AADDR_GUARD0_SEQ_INIT                                (BASE_ADDR_GUARD0 + ADDR_WDOG_SEQ_INIT)
#define AADDR_GUARD1_SEQ_INIT                                (BASE_ADDR_GUARD1 + ADDR_WDOG_SEQ_INIT)
#define AADDR_WDOG1_SEQ_INIT                                 (BASE_ADDR_WDOG1 + ADDR_WDOG_SEQ_INIT)
#define REG_WDOG0_SEQ_INIT                                   (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_SEQ_INIT))
#define REG_GUARD0_SEQ_INIT                                  (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_SEQ_INIT))
#define REG_GUARD1_SEQ_INIT                                  (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_SEQ_INIT))
#define REG_WDOG1_SEQ_INIT                                   (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_SEQ_INIT))

#define ADDR_WDOG_SEQ_LEN                                    (0x02U)
#define A_WDOG_SEQ_LEN(ba)                                   ((ba) + ADDR_WDOG_SEQ_LEN)
#define R_WDOG_SEQ_LEN(ba)                                   (*(volatile unsigned short *)((unsigned int)A_WDOG_SEQ_LEN(ba)))
#define RES_WDOG_SEQ_LEN                                     (0x0U)
#define MSB_WDOG_SEQ_LEN                                     7
#define LSB_WDOG_SEQ_LEN                                     0
#define AADDR_WDOG0_SEQ_LEN                                  (BASE_ADDR_WDOG0 + ADDR_WDOG_SEQ_LEN)
#define AADDR_GUARD0_SEQ_LEN                                 (BASE_ADDR_GUARD0 + ADDR_WDOG_SEQ_LEN)
#define AADDR_GUARD1_SEQ_LEN                                 (BASE_ADDR_GUARD1 + ADDR_WDOG_SEQ_LEN)
#define AADDR_WDOG1_SEQ_LEN                                  (BASE_ADDR_WDOG1 + ADDR_WDOG_SEQ_LEN)
#define REG_WDOG0_SEQ_LEN                                    (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_SEQ_LEN))
#define REG_GUARD0_SEQ_LEN                                   (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_SEQ_LEN))
#define REG_GUARD1_SEQ_LEN                                   (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_SEQ_LEN))
#define REG_WDOG1_SEQ_LEN                                    (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_SEQ_LEN))

#define ADDR_WDOG_TIME_INTERVAL_LW                           (0x04U)
#define A_WDOG_TIME_INTERVAL_LW(ba)                          ((ba) + ADDR_WDOG_TIME_INTERVAL_LW)
#define R_WDOG_TIME_INTERVAL_LW(ba)                          (*(volatile unsigned short *)((unsigned int)A_WDOG_TIME_INTERVAL_LW(ba)))
#define RES_WDOG_TIME_INTERVAL_LW                            (0x0U)
#define MSB_WDOG_TIME_INTERVAL_LW                            15
#define LSB_WDOG_TIME_INTERVAL_LW                            0
#define AADDR_WDOG0_TIME_INTERVAL_LW                         (BASE_ADDR_WDOG0 + ADDR_WDOG_TIME_INTERVAL_LW)
#define AADDR_GUARD0_TIME_INTERVAL_LW                        (BASE_ADDR_GUARD0 + ADDR_WDOG_TIME_INTERVAL_LW)
#define AADDR_GUARD1_TIME_INTERVAL_LW                        (BASE_ADDR_GUARD1 + ADDR_WDOG_TIME_INTERVAL_LW)
#define AADDR_WDOG1_TIME_INTERVAL_LW                         (BASE_ADDR_WDOG1 + ADDR_WDOG_TIME_INTERVAL_LW)
#define REG_WDOG0_TIME_INTERVAL_LW                           (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_TIME_INTERVAL_LW))
#define REG_GUARD0_TIME_INTERVAL_LW                          (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_TIME_INTERVAL_LW))
#define REG_GUARD1_TIME_INTERVAL_LW                          (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_TIME_INTERVAL_LW))
#define REG_WDOG1_TIME_INTERVAL_LW                           (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_TIME_INTERVAL_LW))

#define ADDR_WDOG_TIME_INTERVAL_HW                           (0x06U)
#define A_WDOG_TIME_INTERVAL_HW(ba)                          ((ba) + ADDR_WDOG_TIME_INTERVAL_HW)
#define R_WDOG_TIME_INTERVAL_HW(ba)                          (*(volatile unsigned short *)((unsigned int)A_WDOG_TIME_INTERVAL_HW(ba)))
#define RES_WDOG_TIME_INTERVAL_HW                            (0x0U)
#define MSB_WDOG_TIME_INTERVAL_HW                            15
#define LSB_WDOG_TIME_INTERVAL_HW                            0
#define AADDR_WDOG0_TIME_INTERVAL_HW                         (BASE_ADDR_WDOG0 + ADDR_WDOG_TIME_INTERVAL_HW)
#define AADDR_GUARD0_TIME_INTERVAL_HW                        (BASE_ADDR_GUARD0 + ADDR_WDOG_TIME_INTERVAL_HW)
#define AADDR_GUARD1_TIME_INTERVAL_HW                        (BASE_ADDR_GUARD1 + ADDR_WDOG_TIME_INTERVAL_HW)
#define AADDR_WDOG1_TIME_INTERVAL_HW                         (BASE_ADDR_WDOG1 + ADDR_WDOG_TIME_INTERVAL_HW)
#define REG_WDOG0_TIME_INTERVAL_HW                           (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_TIME_INTERVAL_HW))
#define REG_GUARD0_TIME_INTERVAL_HW                          (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_TIME_INTERVAL_HW))
#define REG_GUARD1_TIME_INTERVAL_HW                          (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_TIME_INTERVAL_HW))
#define REG_WDOG1_TIME_INTERVAL_HW                           (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_TIME_INTERVAL_HW))

#define ADDR_WDOG_STATUS                                     (0x0AU)
#define A_WDOG_STATUS(ba)                                    ((ba) + ADDR_WDOG_STATUS)
#define R_WDOG_STATUS(ba)                                    (*(volatile unsigned short *)((unsigned int)A_WDOG_STATUS(ba)))
#define RES_WDOG_STATUS                                      (0x0U)
#define MSB_WDOG_STATUS                                      1
#define LSB_WDOG_STATUS                                      0
#define AADDR_WDOG0_STATUS                                   (BASE_ADDR_WDOG0 + ADDR_WDOG_STATUS)
#define AADDR_GUARD0_STATUS                                  (BASE_ADDR_GUARD0 + ADDR_WDOG_STATUS)
#define AADDR_GUARD1_STATUS                                  (BASE_ADDR_GUARD1 + ADDR_WDOG_STATUS)
#define AADDR_WDOG1_STATUS                                   (BASE_ADDR_WDOG1 + ADDR_WDOG_STATUS)
#define REG_WDOG0_STATUS                                     (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_STATUS))
#define REG_GUARD0_STATUS                                    (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_STATUS))
#define REG_GUARD1_STATUS                                    (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_STATUS))
#define REG_WDOG1_STATUS                                     (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_STATUS))

#define ADDR_WDOG_TIME_LAST_LEFT_LW                          (0x0CU)
#define A_WDOG_TIME_LAST_LEFT_LW(ba)                         ((ba) + ADDR_WDOG_TIME_LAST_LEFT_LW)
#define R_WDOG_TIME_LAST_LEFT_LW(ba)                         (*(volatile unsigned short *)((unsigned int)A_WDOG_TIME_LAST_LEFT_LW(ba)))
#define RES_WDOG_TIME_LAST_LEFT_LW                           (0x0U)
#define MSB_WDOG_TIME_LAST_LEFT_LW                           15
#define LSB_WDOG_TIME_LAST_LEFT_LW                           0
#define AADDR_WDOG0_TIME_LAST_LEFT_LW                        (BASE_ADDR_WDOG0 + ADDR_WDOG_TIME_LAST_LEFT_LW)
#define AADDR_GUARD0_TIME_LAST_LEFT_LW                       (BASE_ADDR_GUARD0 + ADDR_WDOG_TIME_LAST_LEFT_LW)
#define AADDR_GUARD1_TIME_LAST_LEFT_LW                       (BASE_ADDR_GUARD1 + ADDR_WDOG_TIME_LAST_LEFT_LW)
#define AADDR_WDOG1_TIME_LAST_LEFT_LW                        (BASE_ADDR_WDOG1 + ADDR_WDOG_TIME_LAST_LEFT_LW)
#define REG_WDOG0_TIME_LAST_LEFT_LW                          (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_TIME_LAST_LEFT_LW))
#define REG_GUARD0_TIME_LAST_LEFT_LW                         (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_TIME_LAST_LEFT_LW))
#define REG_GUARD1_TIME_LAST_LEFT_LW                         (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_TIME_LAST_LEFT_LW))
#define REG_WDOG1_TIME_LAST_LEFT_LW                          (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_TIME_LAST_LEFT_LW))

#define ADDR_WDOG_TIME_LAST_LEFT_HW                          (0x0EU)
#define A_WDOG_TIME_LAST_LEFT_HW(ba)                         ((ba) + ADDR_WDOG_TIME_LAST_LEFT_HW)
#define R_WDOG_TIME_LAST_LEFT_HW(ba)                         (*(volatile unsigned short *)((unsigned int)A_WDOG_TIME_LAST_LEFT_HW(ba)))
#define RES_WDOG_TIME_LAST_LEFT_HW                           (0x0U)
#define MSB_WDOG_TIME_LAST_LEFT_HW                           15
#define LSB_WDOG_TIME_LAST_LEFT_HW                           0
#define AADDR_WDOG0_TIME_LAST_LEFT_HW                        (BASE_ADDR_WDOG0 + ADDR_WDOG_TIME_LAST_LEFT_HW)
#define AADDR_GUARD0_TIME_LAST_LEFT_HW                       (BASE_ADDR_GUARD0 + ADDR_WDOG_TIME_LAST_LEFT_HW)
#define AADDR_GUARD1_TIME_LAST_LEFT_HW                       (BASE_ADDR_GUARD1 + ADDR_WDOG_TIME_LAST_LEFT_HW)
#define AADDR_WDOG1_TIME_LAST_LEFT_HW                        (BASE_ADDR_WDOG1 + ADDR_WDOG_TIME_LAST_LEFT_HW)
#define REG_WDOG0_TIME_LAST_LEFT_HW                          (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_TIME_LAST_LEFT_HW))
#define REG_GUARD0_TIME_LAST_LEFT_HW                         (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_TIME_LAST_LEFT_HW))
#define REG_GUARD1_TIME_LAST_LEFT_HW                         (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_TIME_LAST_LEFT_HW))
#define REG_WDOG1_TIME_LAST_LEFT_HW                          (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_TIME_LAST_LEFT_HW))

#define ADDR_WDOG_TIMER_VAL_LW                               (0x10U)
#define A_WDOG_TIMER_VAL_LW(ba)                              ((ba) + ADDR_WDOG_TIMER_VAL_LW)
#define R_WDOG_TIMER_VAL_LW(ba)                              (*(volatile unsigned short *)((unsigned int)A_WDOG_TIMER_VAL_LW(ba)))
#define RES_WDOG_TIMER_VAL_LW                                (0x0U)
#define MSB_WDOG_TIMER_VAL_LW                                15
#define LSB_WDOG_TIMER_VAL_LW                                0
#define AADDR_WDOG0_TIMER_VAL_LW                             (BASE_ADDR_WDOG0 + ADDR_WDOG_TIMER_VAL_LW)
#define AADDR_GUARD0_TIMER_VAL_LW                            (BASE_ADDR_GUARD0 + ADDR_WDOG_TIMER_VAL_LW)
#define AADDR_GUARD1_TIMER_VAL_LW                            (BASE_ADDR_GUARD1 + ADDR_WDOG_TIMER_VAL_LW)
#define AADDR_WDOG1_TIMER_VAL_LW                             (BASE_ADDR_WDOG1 + ADDR_WDOG_TIMER_VAL_LW)
#define REG_WDOG0_TIMER_VAL_LW                               (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_TIMER_VAL_LW))
#define REG_GUARD0_TIMER_VAL_LW                              (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_TIMER_VAL_LW))
#define REG_GUARD1_TIMER_VAL_LW                              (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_TIMER_VAL_LW))
#define REG_WDOG1_TIMER_VAL_LW                               (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_TIMER_VAL_LW))

#define ADDR_WDOG_TIMER_VAL_HW                               (0x12U)
#define A_WDOG_TIMER_VAL_HW(ba)                              ((ba) + ADDR_WDOG_TIMER_VAL_HW)
#define R_WDOG_TIMER_VAL_HW(ba)                              (*(volatile unsigned short *)((unsigned int)A_WDOG_TIMER_VAL_HW(ba)))
#define RES_WDOG_TIMER_VAL_HW                                (0x0U)
#define MSB_WDOG_TIMER_VAL_HW                                15
#define LSB_WDOG_TIMER_VAL_HW                                0
#define AADDR_WDOG0_TIMER_VAL_HW                             (BASE_ADDR_WDOG0 + ADDR_WDOG_TIMER_VAL_HW)
#define AADDR_GUARD0_TIMER_VAL_HW                            (BASE_ADDR_GUARD0 + ADDR_WDOG_TIMER_VAL_HW)
#define AADDR_GUARD1_TIMER_VAL_HW                            (BASE_ADDR_GUARD1 + ADDR_WDOG_TIMER_VAL_HW)
#define AADDR_WDOG1_TIMER_VAL_HW                             (BASE_ADDR_WDOG1 + ADDR_WDOG_TIMER_VAL_HW)
#define REG_WDOG0_TIMER_VAL_HW                               (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_TIMER_VAL_HW))
#define REG_GUARD0_TIMER_VAL_HW                              (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_TIMER_VAL_HW))
#define REG_GUARD1_TIMER_VAL_HW                              (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_TIMER_VAL_HW))
#define REG_WDOG1_TIMER_VAL_HW                               (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_TIMER_VAL_HW))

#define ADDR_WDOG_COMMAND                                    (0x14U)
#define A_WDOG_COMMAND(ba)                                   ((ba) + ADDR_WDOG_COMMAND)
#define R_WDOG_COMMAND(ba)                                   (*(volatile unsigned short *)((unsigned int)A_WDOG_COMMAND(ba)))
#define RES_WDOG_COMMAND                                     (0x0U)
#define MSB_WDOG_COMMAND                                     7
#define LSB_WDOG_COMMAND                                     0
#define AADDR_WDOG0_COMMAND                                  (BASE_ADDR_WDOG0 + ADDR_WDOG_COMMAND)
#define AADDR_GUARD0_COMMAND                                 (BASE_ADDR_GUARD0 + ADDR_WDOG_COMMAND)
#define AADDR_GUARD1_COMMAND                                 (BASE_ADDR_GUARD1 + ADDR_WDOG_COMMAND)
#define AADDR_WDOG1_COMMAND                                  (BASE_ADDR_WDOG1 + ADDR_WDOG_COMMAND)
#define REG_WDOG0_COMMAND                                    (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_COMMAND))
#define REG_GUARD0_COMMAND                                   (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_COMMAND))
#define REG_GUARD1_COMMAND                                   (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_COMMAND))
#define REG_WDOG1_COMMAND                                    (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_COMMAND))

#define ADDR_WDOG_MAGIC_COOKIE                               (0x16U)
#define A_WDOG_MAGIC_COOKIE(ba)                              ((ba) + ADDR_WDOG_MAGIC_COOKIE)
#define R_WDOG_MAGIC_COOKIE(ba)                              (*(volatile unsigned short *)((unsigned int)A_WDOG_MAGIC_COOKIE(ba)))
#define RES_WDOG_MAGIC_COOKIE                                (0x0U)
#define MSB_WDOG_MAGIC_COOKIE                                7
#define LSB_WDOG_MAGIC_COOKIE                                0
#define AADDR_WDOG0_MAGIC_COOKIE                             (BASE_ADDR_WDOG0 + ADDR_WDOG_MAGIC_COOKIE)
#define AADDR_GUARD0_MAGIC_COOKIE                            (BASE_ADDR_GUARD0 + ADDR_WDOG_MAGIC_COOKIE)
#define AADDR_GUARD1_MAGIC_COOKIE                            (BASE_ADDR_GUARD1 + ADDR_WDOG_MAGIC_COOKIE)
#define AADDR_WDOG1_MAGIC_COOKIE                             (BASE_ADDR_WDOG1 + ADDR_WDOG_MAGIC_COOKIE)
#define REG_WDOG0_MAGIC_COOKIE                               (*(volatile unsigned short *)((unsigned int)AADDR_WDOG0_MAGIC_COOKIE))
#define REG_GUARD0_MAGIC_COOKIE                              (*(volatile unsigned short *)((unsigned int)AADDR_GUARD0_MAGIC_COOKIE))
#define REG_GUARD1_MAGIC_COOKIE                              (*(volatile unsigned short *)((unsigned int)AADDR_GUARD1_MAGIC_COOKIE))
#define REG_WDOG1_MAGIC_COOKIE                               (*(volatile unsigned short *)((unsigned int)AADDR_WDOG1_MAGIC_COOKIE))




#endif
