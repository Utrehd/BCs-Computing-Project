# ASIC2 HAL and API functions

# How to clone repository
 ~~~~~~~~~~~~~~~{.c}
cd existing-project

git clone https://bitbucket-prod.tcc.etn.com/scm/icpd_icp/asic2.git
 ~~~~~~~~~~~~~~~


# Release notes

## v1.0
* taken from TFS (tfs version 3560)
~~~~~
$/ASIC/ASIC2/sample_test/shared/include/asic2
$/ASIC/ASIC2/sample_test/shared/src/asic2
~~~~~
