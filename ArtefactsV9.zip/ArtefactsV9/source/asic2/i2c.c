/* FPGA Release: 10512 */

#include "i2c.h"
#include "utils.h"

// =======================================================================
// MODULE HANDLING                                                        
// =======================================================================

void i2c_init(uint16_t divider) {
	WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_BAUD_CONFIG, divider);
}

void i2c_set_rec_high_water(uint8_t value){
  i2c_config_t i2c_config;

  i2c_config.val = READ_REG_U16(BASE_ADDR_I2C + ADDR_I2C_CONFIG);
  i2c_config.bf.rec_fifo_level = value;
  WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_CONFIG, i2c_config.val);
}

void i2c_set_cmd_low_water(uint8_t value){
  i2c_config_t i2c_config;

  i2c_config.val = READ_REG_U16(BASE_ADDR_I2C + ADDR_I2C_CONFIG);
  i2c_config.bf.cmd_fifo_level = value;
  WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_CONFIG, i2c_config.val);
}

uint16_t i2c_get_cmd_delta(void) {
	i2c_fifo_levels_t  i2c_fifo_levels;

	i2c_fifo_levels.val = READ_REG_U16(BASE_ADDR_I2C + ADDR_I2C_FIFO_LEVELS);
	return i2c_fifo_levels.bf.cmd_fifo_level;
}

uint16_t i2c_get_rec_delta(void) {
	i2c_fifo_levels_t  i2c_fifo_levels;

	i2c_fifo_levels.val = READ_REG_U16(BASE_ADDR_I2C + ADDR_I2C_FIFO_LEVELS);
	return i2c_fifo_levels.bf.rec_fifo_level;
}

void i2c_fifo_clear(bool cmd_fifo_clr, bool rec_fifo_clr) {
	i2c_fifo_clear_t  i2c_fifo_clear;

	i2c_fifo_clear.val = 0;
	i2c_fifo_clear.bf.cmd_fifo_clear = cmd_fifo_clr;
	i2c_fifo_clear.bf.rec_fifo_clear = rec_fifo_clr;
	WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_FIFO_CLEAR, i2c_fifo_clear.val);
}

void i2c_command(uint16_t flags, uint8_t data) {

	uint16_t cmd_delta;

	// block when command fifo is full
	do {
		cmd_delta = i2c_get_cmd_delta();
	} while (cmd_delta == I2C_CMD_FIFO_DEPTH);
	WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_CMD_DATA, flags | data);
}

uint8_t i2c_get_recv_data(void){
  while (!i2c_get_rec_delta());
  return (READ_REG_U16(BASE_ADDR_I2C + ADDR_I2C_REC_DATA) & 0x00FF);
}

// =======================================================================
// INTERRUPT HANDLING                                                     
// =======================================================================

uint16_t i2c_get_irq_mask(){
  return READ_REG_U16(BASE_ADDR_I2C + ADDR_I2C_IRQ_MASK);
}

void i2c_set_irq_mask(uint16_t mask){
  WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_IRQ_MASK, mask);
}

void i2c_enable_irq(i2c_irq_t irq, bool enable){  
  if (enable) WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_IRQ_VENABLE, irq);
  else WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_IRQ_VDISABLE, irq);
}

void i2c_clear_irq(i2c_irq_t irq){
  WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_IRQ_STATUS, (1 << irq));
}

i2c_irq_status_t i2c_get_irq_status(){
  i2c_irq_status_t status;
  status.val = READ_REG_U16(BASE_ADDR_I2C + ADDR_I2C_IRQ_STATUS);
  return status;
}

void i2c_clear_all_irq_events(){
  WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_IRQ_STATUS, 0xFFFF);
}

void i2c_set_irq_vno(i2c_irq_t vno){
  WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_IRQ_VNO, vno);
}

i2c_irq_t i2c_get_next_pending_irq(){
  return (i2c_irq_t) READ_REG_U16(BASE_ADDR_I2C + ADDR_I2C_IRQ_VNO);
}
