/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         uart_api.h
*
* @brief        UART API functions
*
* @author       Dedourek Pavel
*
********************************************************************************
*
********************************************************************************
********************************************************************************
*/

#ifndef __UART_API_H__
#define __UART_API_H__

#include "hardware.h"
#include "uart_api.h"


/** 
 *  \defgroup uart_api API functions to control UART
 *
 *  \ingroup  uart   asic2_api
 *
 *  \brief    UART API functions
 *
 */
/**@{*/    

/**
\verbatim
  When you need to use a serial asynchronous communication you can use UART peripheral block in ASIC2.

  How to use it:

Set clock domain:

    clk_nres_enable_clock_partition();
    clk_nres_set_nreset();
        Enable clock domain for SAR ADC module

Set pads for UART:

    io_ctrl_config_sel()
        Set the specific pads

Configure UART
    
    uart_api_init_baudrate
\endverbatim
  *
  */


/* ########################################################################## */    
/**
 * \brief sets the desired baud rate on the serial interface that was selected
 * 
 * The function provides a fixed 8n1 as word format.
 *
 * \ingroup uart_api
 * 
 * \param baudrate baudrate in Hz
 */
void uart_api_init_baudrate ( uint32_t baudrate );

/**@}*/ 
#endif