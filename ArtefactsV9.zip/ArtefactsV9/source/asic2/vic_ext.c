/* FPGA Release: 10512 */
#include "device.h"
#include "utils.h"
#include "vic_ext.h"
#include "vic_ext_bf.h"

void vic_ext_irq_enable(vic_ext_irq_t irq_number)
{
    uint32_t mask_rel = AADDR_VIC_EXT_IRQ_MASK0;
    uint16_t irq_rel  = irq_number;
    
    if (irq_number > 15){
      mask_rel += 2;
      irq_rel  -= 16;
    }
    uint16_t irq_mask = READ_REG_U16(mask_rel);
    irq_mask |= (0x01 << irq_rel);
    WRITE_REG_16(mask_rel, irq_mask);
}


void vic_ext_irq_disable(vic_ext_irq_t irq_number)
{
    uint32_t mask_rel = AADDR_VIC_EXT_IRQ_MASK0;
    uint16_t irq_rel  = irq_number;
    
    if (irq_number > 15){
      mask_rel += 2;
      irq_rel  -= 16;
    }  
  
    uint16_t irq_mask = READ_REG_U16(mask_rel);
    irq_mask &= ~(0x01 << irq_rel);
    WRITE_REG_16(mask_rel, irq_mask);
}

void vic_ext_main_enable(bool main_enable) {
	WRITE_REG_16(AADDR_VIC_EXT_MAIN_ENABLE, main_enable);
}

void vic_ext_set_polarity(uint8_t polarity){
	WRITE_REG_16(AADDR_VIC_EXT_IRQ_POLARITY, polarity);
}