/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         crc_bf.h
*
* @brief        Cyclic redundancy check HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CRC_BF_H__
#define __CRC_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_CRC0
#define BASE_ADDR_CRC0 0x40006A00U
#endif
#ifndef BASE_ADDR_CRC1
#define BASE_ADDR_CRC1 0x40006A80U
#endif

#define MULTIPLE_CRC
#define NUMBER_CRC 2



/**
  * \brief This is an enum class for CRC instance
  *
  * \ingroup crc
  */ 
typedef enum {
  CRC0                           = (int)BASE_ADDR_CRC0, ///< this is instance CRC0
  CRC1                           = (int)BASE_ADDR_CRC1  ///< this is instance CRC1
} crc_num_t;

// Register bit field definitions

/* CRC_CFG */

#define MSK_CRC_CFG_LEN                                     (0x3f)    /* [ 5:0] */
#define RES_CRC_CFG_LEN                                     (0x00)
#define SFT_CRC_CFG_LEN                                     (0)
#define LSB_CRC_CFG_LEN                                     (0)
#define MSB_CRC_CFG_LEN                                     (5)
#define MSK_CRC_CFG_DIRECTION                               (0x1)     /* [6] */
#define RES_CRC_CFG_DIRECTION                               (0x0)
#define SFT_CRC_CFG_DIRECTION                               (6)
#define LSB_CRC_CFG_DIRECTION                               (6)
#define MSB_CRC_CFG_DIRECTION                               (6)
#define BIT_CRC_CFG_DIRECTION                               (0x40)    /* [6] */
#define MSK_CRC_CFG_REVERSE                                 (0x1)     /* [7] */
#define RES_CRC_CFG_REVERSE                                 (0x0)
#define SFT_CRC_CFG_REVERSE                                 (7)
#define LSB_CRC_CFG_REVERSE                                 (7)
#define MSB_CRC_CFG_REVERSE                                 (7)
#define BIT_CRC_CFG_REVERSE                                 (0x80)    /* [7] */
/** 
 * \brief This structure describes CRC configuration 
 *
 * \ingroup crc
 */
typedef struct {
  unsigned short len                           :    6;       ///< valid values: 0..31 <br> len = order - 1 of the highest coefficient (1..32)
  unsigned short direction                     :    1;       ///< 0: increment addresses beginning with SADR <br>1: decrement addresses beginning with SADR
  unsigned short reverse                       :    1;       ///< 0: MSB first (left shift) <br>1: LSB first (right shift)
  unsigned short reserved                      :    8;
} crc_cfg_bf;

/**
 * \brief Conversion type between word and bit representation of CRC configuration
 *
 * \ingroup crc
 */
typedef union {
  unsigned short val; ///< word representation
  crc_cfg_bf bf;      ///< bit field representation
} crc_cfg_t;


/* CRC_COEF */

#define MSK_CRC_COEF                                        (0xffff)  /* [15:0] */

typedef unsigned short crc_coef_t;                                    /* [15:0] */


/* CRC_START_VALUE */

#define MSK_CRC_START_VALUE                                 (0xffff)  /* [15:0] */

typedef unsigned short crc_start_value_t;                             /* [15:0] */


/* CRC_WAIT */

#define MSK_CRC_WAIT                                        (0xff)    /* [ 7:0] */

typedef unsigned short crc_wait_t;                                    /* [ 7:0] */


/* CRC_CMD */

#define MSK_CRC_CMD                                         (0x1)     /* [0] */

typedef unsigned short crc_cmd_t;                                     /* [0] */


/* CRC_SADR_NEW */

#define MSK_CRC_SADR_NEW                                    (0xffff)  /* [15:0] */

typedef unsigned short crc_sadr_new_t;                                /* [15:0] */


/* CRC_LEN_NEW */

#define MSK_CRC_LEN_NEW                                     (0xffff)  /* [15:0] */

typedef unsigned short crc_len_new_t;                                 /* [15:0] */


/* CRC_SADR_CURRENT */

#define MSK_CRC_SADR_CURRENT                                (0xffff)  /* [15:0] */

typedef unsigned short crc_sadr_current_t;                            /* [15:0] */


/* CRC_ADR_CURRENT */

#define MSK_CRC_ADR_CURRENT                                 (0xffff)  /* [15:0] */

typedef unsigned short crc_adr_current_t;                             /* [15:0] */


/* CRC_SADR_DONE */

#define MSK_CRC_SADR_DONE                                   (0xffff)  /* [15:0] */

typedef unsigned short crc_sadr_done_t;                               /* [15:0] */


/* CRC_CRC */

#define MSK_CRC_CRC                                         (0xffff)  /* [15:0] */

typedef unsigned short crc_crc_t;                                     /* [15:0] */


/* CRC_IRQ_STATUS */

#define MSK_CRC_IRQ_STATUS_SADR_DONE_NEMPTY                 (0x1)     /* [0] */
#define RES_CRC_IRQ_STATUS_SADR_DONE_NEMPTY                 (0x0)
#define SFT_CRC_IRQ_STATUS_SADR_DONE_NEMPTY                 (0)
#define LSB_CRC_IRQ_STATUS_SADR_DONE_NEMPTY                 (0)
#define MSB_CRC_IRQ_STATUS_SADR_DONE_NEMPTY                 (0)
#define BIT_CRC_IRQ_STATUS_SADR_DONE_NEMPTY                 (0x1)     /* [0] */
#define MSK_CRC_IRQ_STATUS_SADR_NEW_NFULL                   (0x1)     /* [1] */
#define RES_CRC_IRQ_STATUS_SADR_NEW_NFULL                   (0x1)
#define SFT_CRC_IRQ_STATUS_SADR_NEW_NFULL                   (1)
#define LSB_CRC_IRQ_STATUS_SADR_NEW_NFULL                   (1)
#define MSB_CRC_IRQ_STATUS_SADR_NEW_NFULL                   (1)
#define BIT_CRC_IRQ_STATUS_SADR_NEW_NFULL                   (0x2)     /* [1] */
#define MSK_CRC_IRQ_STATUS_IDLE                             (0x1)     /* [2] */
#define RES_CRC_IRQ_STATUS_IDLE                             (0x1)
#define SFT_CRC_IRQ_STATUS_IDLE                             (2)
#define LSB_CRC_IRQ_STATUS_IDLE                             (2)
#define MSB_CRC_IRQ_STATUS_IDLE                             (2)
#define BIT_CRC_IRQ_STATUS_IDLE                             (0x4)     /* [2] */


/**
 * \brief This structure describes CRC IRQ status register 
 *
 * \ingroup crc
 *
 */
typedef struct {
  unsigned short sadr_done_nempty              :    1;       ///< 1: *_DONE contains a completed unread CRC computation
  unsigned short sadr_new_nfull                :    1;       ///< 1: SADR_NEW can accept a new start address.
  unsigned short idle                          :    1;       ///< 0: CRC computation in progress
  unsigned short reserved                      :   13;
} crc_irq_status_bf;

/**
 * \brief Conversion type between word and bit representation of CRC IRQ status 
 *
 * \ingroup crc
 *
 */
typedef union {
  unsigned short val;    ///< word representation
  crc_irq_status_bf bf;  ///< bit field representation
} crc_irq_status_t;


/* CRC_IRQ_MASK */

#define MSK_CRC_IRQ_MASK                                    (0x7)     /* [ 2:0] */

typedef unsigned short crc_irq_mask_t;                                /* [ 2:0] */


/* CRC_IRQ_VENABLE */

#define MSK_CRC_IRQ_VENABLE                                 (0x3)     /* [ 1:0] */

typedef unsigned short crc_irq_venable_t;                             /* [ 1:0] */


/* CRC_IRQ_VDISABLE */

#define MSK_CRC_IRQ_VDISABLE                                (0x3)     /* [ 1:0] */

typedef unsigned short crc_irq_vdisable_t;                            /* [ 1:0] */


/* CRC_IRQ_VMAX */

#define MSK_CRC_IRQ_VMAX                                    (0x3)     /* [ 1:0] */

typedef unsigned short crc_irq_vmax_t;                                /* [ 1:0] */


/* CRC_IRQ_VNO */

#define MSK_CRC_IRQ_VNO                                     (0x3)     /* [ 1:0] */

typedef unsigned short crc_irq_vno_t;                                 /* [ 1:0] */



// Register definitions for module
// Instance base address BASE_ADDR_CRC0 0x40006A00U ... 
// Instance base address BASE_ADDR_CRC1 0x40006A80U ... 

#define ADDR_CRC_CFG                                         (0x00U)
#define A_CRC_CFG(ba)                                        ((ba) + ADDR_CRC_CFG)
#define R_CRC_CFG(ba)                                        (*(volatile unsigned short *)((unsigned int)A_CRC_CFG(ba)))
#define RES_CRC_CFG                                          (0x0U)
#define MSB_CRC_CFG                                          7
#define LSB_CRC_CFG                                          0
#define AADDR_CRC0_CFG                                       (BASE_ADDR_CRC0 + ADDR_CRC_CFG)
#define AADDR_CRC1_CFG                                       (BASE_ADDR_CRC1 + ADDR_CRC_CFG)
#define REG_CRC0_CFG                                         (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_CFG))
#define REG_CRC1_CFG                                         (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_CFG))

#define ADDR_CRC_COEF_LW                                     (0x04U)
#define A_CRC_COEF_LW(ba)                                    ((ba) + ADDR_CRC_COEF_LW)
#define R_CRC_COEF_LW(ba)                                    (*(volatile unsigned short *)((unsigned int)A_CRC_COEF_LW(ba)))
#define RES_CRC_COEF_LW                                      (0x0U)
#define MSB_CRC_COEF_LW                                      15
#define LSB_CRC_COEF_LW                                      0
#define AADDR_CRC0_COEF_LW                                   (BASE_ADDR_CRC0 + ADDR_CRC_COEF_LW)
#define AADDR_CRC1_COEF_LW                                   (BASE_ADDR_CRC1 + ADDR_CRC_COEF_LW)
#define REG_CRC0_COEF_LW                                     (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_COEF_LW))
#define REG_CRC1_COEF_LW                                     (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_COEF_LW))

#define ADDR_CRC_COEF_HW                                     (0x06U)
#define A_CRC_COEF_HW(ba)                                    ((ba) + ADDR_CRC_COEF_HW)
#define R_CRC_COEF_HW(ba)                                    (*(volatile unsigned short *)((unsigned int)A_CRC_COEF_HW(ba)))
#define RES_CRC_COEF_HW                                      (0x0U)
#define MSB_CRC_COEF_HW                                      15
#define LSB_CRC_COEF_HW                                      0
#define AADDR_CRC0_COEF_HW                                   (BASE_ADDR_CRC0 + ADDR_CRC_COEF_HW)
#define AADDR_CRC1_COEF_HW                                   (BASE_ADDR_CRC1 + ADDR_CRC_COEF_HW)
#define REG_CRC0_COEF_HW                                     (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_COEF_HW))
#define REG_CRC1_COEF_HW                                     (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_COEF_HW))

#define ADDR_CRC_START_VALUE_LW                              (0x08U)
#define A_CRC_START_VALUE_LW(ba)                             ((ba) + ADDR_CRC_START_VALUE_LW)
#define R_CRC_START_VALUE_LW(ba)                             (*(volatile unsigned short *)((unsigned int)A_CRC_START_VALUE_LW(ba)))
#define RES_CRC_START_VALUE_LW                               (0x0U)
#define MSB_CRC_START_VALUE_LW                               15
#define LSB_CRC_START_VALUE_LW                               0
#define AADDR_CRC0_START_VALUE_LW                            (BASE_ADDR_CRC0 + ADDR_CRC_START_VALUE_LW)
#define AADDR_CRC1_START_VALUE_LW                            (BASE_ADDR_CRC1 + ADDR_CRC_START_VALUE_LW)
#define REG_CRC0_START_VALUE_LW                              (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_START_VALUE_LW))
#define REG_CRC1_START_VALUE_LW                              (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_START_VALUE_LW))

#define ADDR_CRC_START_VALUE_HW                              (0x0AU)
#define A_CRC_START_VALUE_HW(ba)                             ((ba) + ADDR_CRC_START_VALUE_HW)
#define R_CRC_START_VALUE_HW(ba)                             (*(volatile unsigned short *)((unsigned int)A_CRC_START_VALUE_HW(ba)))
#define RES_CRC_START_VALUE_HW                               (0x0U)
#define MSB_CRC_START_VALUE_HW                               15
#define LSB_CRC_START_VALUE_HW                               0
#define AADDR_CRC0_START_VALUE_HW                            (BASE_ADDR_CRC0 + ADDR_CRC_START_VALUE_HW)
#define AADDR_CRC1_START_VALUE_HW                            (BASE_ADDR_CRC1 + ADDR_CRC_START_VALUE_HW)
#define REG_CRC0_START_VALUE_HW                              (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_START_VALUE_HW))
#define REG_CRC1_START_VALUE_HW                              (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_START_VALUE_HW))

#define ADDR_CRC_WAIT                                        (0x0CU)
#define A_CRC_WAIT(ba)                                       ((ba) + ADDR_CRC_WAIT)
#define R_CRC_WAIT(ba)                                       (*(volatile unsigned short *)((unsigned int)A_CRC_WAIT(ba)))
#define RES_CRC_WAIT                                         (0x0U)
#define MSB_CRC_WAIT                                         7
#define LSB_CRC_WAIT                                         0
#define AADDR_CRC0_WAIT                                      (BASE_ADDR_CRC0 + ADDR_CRC_WAIT)
#define AADDR_CRC1_WAIT                                      (BASE_ADDR_CRC1 + ADDR_CRC_WAIT)
#define REG_CRC0_WAIT                                        (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_WAIT))
#define REG_CRC1_WAIT                                        (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_WAIT))

#define ADDR_CRC_CMD                                         (0x10U)
#define A_CRC_CMD(ba)                                        ((ba) + ADDR_CRC_CMD)
#define R_CRC_CMD(ba)                                        (*(volatile unsigned short *)((unsigned int)A_CRC_CMD(ba)))
#define RES_CRC_CMD                                          (0x0U)
#define MSB_CRC_CMD                                          0
#define LSB_CRC_CMD                                          0
#define AADDR_CRC0_CMD                                       (BASE_ADDR_CRC0 + ADDR_CRC_CMD)
#define AADDR_CRC1_CMD                                       (BASE_ADDR_CRC1 + ADDR_CRC_CMD)
#define REG_CRC0_CMD                                         (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_CMD))
#define REG_CRC1_CMD                                         (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_CMD))

#define ADDR_CRC_SADR_NEW_LW                                 (0x14U)
#define A_CRC_SADR_NEW_LW(ba)                                ((ba) + ADDR_CRC_SADR_NEW_LW)
#define R_CRC_SADR_NEW_LW(ba)                                (*(volatile unsigned short *)((unsigned int)A_CRC_SADR_NEW_LW(ba)))
#define RES_CRC_SADR_NEW_LW                                  (0x0U)
#define MSB_CRC_SADR_NEW_LW                                  15
#define LSB_CRC_SADR_NEW_LW                                  0
#define AADDR_CRC0_SADR_NEW_LW                               (BASE_ADDR_CRC0 + ADDR_CRC_SADR_NEW_LW)
#define AADDR_CRC1_SADR_NEW_LW                               (BASE_ADDR_CRC1 + ADDR_CRC_SADR_NEW_LW)
#define REG_CRC0_SADR_NEW_LW                                 (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_SADR_NEW_LW))
#define REG_CRC1_SADR_NEW_LW                                 (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_SADR_NEW_LW))

#define ADDR_CRC_SADR_NEW_HW                                 (0x16U)
#define A_CRC_SADR_NEW_HW(ba)                                ((ba) + ADDR_CRC_SADR_NEW_HW)
#define R_CRC_SADR_NEW_HW(ba)                                (*(volatile unsigned short *)((unsigned int)A_CRC_SADR_NEW_HW(ba)))
#define RES_CRC_SADR_NEW_HW                                  (0x0U)
#define MSB_CRC_SADR_NEW_HW                                  15
#define LSB_CRC_SADR_NEW_HW                                  0
#define AADDR_CRC0_SADR_NEW_HW                               (BASE_ADDR_CRC0 + ADDR_CRC_SADR_NEW_HW)
#define AADDR_CRC1_SADR_NEW_HW                               (BASE_ADDR_CRC1 + ADDR_CRC_SADR_NEW_HW)
#define REG_CRC0_SADR_NEW_HW                                 (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_SADR_NEW_HW))
#define REG_CRC1_SADR_NEW_HW                                 (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_SADR_NEW_HW))

#define ADDR_CRC_LEN_LW                                      (0x18U)
#define A_CRC_LEN_LW(ba)                                     ((ba) + ADDR_CRC_LEN_LW)
#define R_CRC_LEN_LW(ba)                                     (*(volatile unsigned short *)((unsigned int)A_CRC_LEN_LW(ba)))
#define RES_CRC_LEN_LW                                       (0x0U)
#define MSB_CRC_LEN_LW                                       15
#define LSB_CRC_LEN_LW                                       0
#define AADDR_CRC0_LEN_LW                                    (BASE_ADDR_CRC0 + ADDR_CRC_LEN_LW)
#define AADDR_CRC1_LEN_LW                                    (BASE_ADDR_CRC1 + ADDR_CRC_LEN_LW)
#define REG_CRC0_LEN_LW                                      (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_LEN_LW))
#define REG_CRC1_LEN_LW                                      (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_LEN_LW))

#define ADDR_CRC_LEN_HW                                      (0x1AU)
#define A_CRC_LEN_HW(ba)                                     ((ba) + ADDR_CRC_LEN_HW)
#define R_CRC_LEN_HW(ba)                                     (*(volatile unsigned short *)((unsigned int)A_CRC_LEN_HW(ba)))
#define RES_CRC_LEN_HW                                       (0x0U)
#define MSB_CRC_LEN_HW                                       15
#define LSB_CRC_LEN_HW                                       0
#define AADDR_CRC0_LEN_HW                                    (BASE_ADDR_CRC0 + ADDR_CRC_LEN_HW)
#define AADDR_CRC1_LEN_HW                                    (BASE_ADDR_CRC1 + ADDR_CRC_LEN_HW)
#define REG_CRC0_LEN_HW                                      (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_LEN_HW))
#define REG_CRC1_LEN_HW                                      (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_LEN_HW))

#define ADDR_CRC_SADR_CURRENT_LW                             (0x1CU)
#define A_CRC_SADR_CURRENT_LW(ba)                            ((ba) + ADDR_CRC_SADR_CURRENT_LW)
#define R_CRC_SADR_CURRENT_LW(ba)                            (*(volatile unsigned short *)((unsigned int)A_CRC_SADR_CURRENT_LW(ba)))
#define RES_CRC_SADR_CURRENT_LW                              (0x0U)
#define MSB_CRC_SADR_CURRENT_LW                              15
#define LSB_CRC_SADR_CURRENT_LW                              0
#define AADDR_CRC0_SADR_CURRENT_LW                           (BASE_ADDR_CRC0 + ADDR_CRC_SADR_CURRENT_LW)
#define AADDR_CRC1_SADR_CURRENT_LW                           (BASE_ADDR_CRC1 + ADDR_CRC_SADR_CURRENT_LW)
#define REG_CRC0_SADR_CURRENT_LW                             (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_SADR_CURRENT_LW))
#define REG_CRC1_SADR_CURRENT_LW                             (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_SADR_CURRENT_LW))

#define ADDR_CRC_SADR_CURRENT_HW                             (0x1EU)
#define A_CRC_SADR_CURRENT_HW(ba)                            ((ba) + ADDR_CRC_SADR_CURRENT_HW)
#define R_CRC_SADR_CURRENT_HW(ba)                            (*(volatile unsigned short *)((unsigned int)A_CRC_SADR_CURRENT_HW(ba)))
#define RES_CRC_SADR_CURRENT_HW                              (0x0U)
#define MSB_CRC_SADR_CURRENT_HW                              15
#define LSB_CRC_SADR_CURRENT_HW                              0
#define AADDR_CRC0_SADR_CURRENT_HW                           (BASE_ADDR_CRC0 + ADDR_CRC_SADR_CURRENT_HW)
#define AADDR_CRC1_SADR_CURRENT_HW                           (BASE_ADDR_CRC1 + ADDR_CRC_SADR_CURRENT_HW)
#define REG_CRC0_SADR_CURRENT_HW                             (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_SADR_CURRENT_HW))
#define REG_CRC1_SADR_CURRENT_HW                             (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_SADR_CURRENT_HW))

#define ADDR_CRC_ADR_CURRENT_LW                              (0x20U)
#define A_CRC_ADR_CURRENT_LW(ba)                             ((ba) + ADDR_CRC_ADR_CURRENT_LW)
#define R_CRC_ADR_CURRENT_LW(ba)                             (*(volatile unsigned short *)((unsigned int)A_CRC_ADR_CURRENT_LW(ba)))
#define RES_CRC_ADR_CURRENT_LW                               (0x0U)
#define MSB_CRC_ADR_CURRENT_LW                               15
#define LSB_CRC_ADR_CURRENT_LW                               0
#define AADDR_CRC0_ADR_CURRENT_LW                            (BASE_ADDR_CRC0 + ADDR_CRC_ADR_CURRENT_LW)
#define AADDR_CRC1_ADR_CURRENT_LW                            (BASE_ADDR_CRC1 + ADDR_CRC_ADR_CURRENT_LW)
#define REG_CRC0_ADR_CURRENT_LW                              (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_ADR_CURRENT_LW))
#define REG_CRC1_ADR_CURRENT_LW                              (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_ADR_CURRENT_LW))

#define ADDR_CRC_ADR_CURRENT_HW                              (0x22U)
#define A_CRC_ADR_CURRENT_HW(ba)                             ((ba) + ADDR_CRC_ADR_CURRENT_HW)
#define R_CRC_ADR_CURRENT_HW(ba)                             (*(volatile unsigned short *)((unsigned int)A_CRC_ADR_CURRENT_HW(ba)))
#define RES_CRC_ADR_CURRENT_HW                               (0x0U)
#define MSB_CRC_ADR_CURRENT_HW                               15
#define LSB_CRC_ADR_CURRENT_HW                               0
#define AADDR_CRC0_ADR_CURRENT_HW                            (BASE_ADDR_CRC0 + ADDR_CRC_ADR_CURRENT_HW)
#define AADDR_CRC1_ADR_CURRENT_HW                            (BASE_ADDR_CRC1 + ADDR_CRC_ADR_CURRENT_HW)
#define REG_CRC0_ADR_CURRENT_HW                              (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_ADR_CURRENT_HW))
#define REG_CRC1_ADR_CURRENT_HW                              (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_ADR_CURRENT_HW))

#define ADDR_CRC_SADR_DONE_LW                                (0x24U)
#define A_CRC_SADR_DONE_LW(ba)                               ((ba) + ADDR_CRC_SADR_DONE_LW)
#define R_CRC_SADR_DONE_LW(ba)                               (*(volatile unsigned short *)((unsigned int)A_CRC_SADR_DONE_LW(ba)))
#define RES_CRC_SADR_DONE_LW                                 (0x0U)
#define MSB_CRC_SADR_DONE_LW                                 15
#define LSB_CRC_SADR_DONE_LW                                 0
#define AADDR_CRC0_SADR_DONE_LW                              (BASE_ADDR_CRC0 + ADDR_CRC_SADR_DONE_LW)
#define AADDR_CRC1_SADR_DONE_LW                              (BASE_ADDR_CRC1 + ADDR_CRC_SADR_DONE_LW)
#define REG_CRC0_SADR_DONE_LW                                (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_SADR_DONE_LW))
#define REG_CRC1_SADR_DONE_LW                                (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_SADR_DONE_LW))

#define ADDR_CRC_SADR_DONE_HW                                (0x26U)
#define A_CRC_SADR_DONE_HW(ba)                               ((ba) + ADDR_CRC_SADR_DONE_HW)
#define R_CRC_SADR_DONE_HW(ba)                               (*(volatile unsigned short *)((unsigned int)A_CRC_SADR_DONE_HW(ba)))
#define RES_CRC_SADR_DONE_HW                                 (0x0U)
#define MSB_CRC_SADR_DONE_HW                                 15
#define LSB_CRC_SADR_DONE_HW                                 0
#define AADDR_CRC0_SADR_DONE_HW                              (BASE_ADDR_CRC0 + ADDR_CRC_SADR_DONE_HW)
#define AADDR_CRC1_SADR_DONE_HW                              (BASE_ADDR_CRC1 + ADDR_CRC_SADR_DONE_HW)
#define REG_CRC0_SADR_DONE_HW                                (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_SADR_DONE_HW))
#define REG_CRC1_SADR_DONE_HW                                (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_SADR_DONE_HW))

#define ADDR_CRC_CRC_LW                                      (0x28U)
#define A_CRC_CRC_LW(ba)                                     ((ba) + ADDR_CRC_CRC_LW)
#define R_CRC_CRC_LW(ba)                                     (*(volatile unsigned short *)((unsigned int)A_CRC_CRC_LW(ba)))
#define RES_CRC_CRC_LW                                       (0x0U)
#define MSB_CRC_CRC_LW                                       15
#define LSB_CRC_CRC_LW                                       0
#define AADDR_CRC0_CRC_LW                                    (BASE_ADDR_CRC0 + ADDR_CRC_CRC_LW)
#define AADDR_CRC1_CRC_LW                                    (BASE_ADDR_CRC1 + ADDR_CRC_CRC_LW)
#define REG_CRC0_CRC_LW                                      (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_CRC_LW))
#define REG_CRC1_CRC_LW                                      (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_CRC_LW))

#define ADDR_CRC_CRC_HW                                      (0x2AU)
#define A_CRC_CRC_HW(ba)                                     ((ba) + ADDR_CRC_CRC_HW)
#define R_CRC_CRC_HW(ba)                                     (*(volatile unsigned short *)((unsigned int)A_CRC_CRC_HW(ba)))
#define RES_CRC_CRC_HW                                       (0x0U)
#define MSB_CRC_CRC_HW                                       15
#define LSB_CRC_CRC_HW                                       0
#define AADDR_CRC0_CRC_HW                                    (BASE_ADDR_CRC0 + ADDR_CRC_CRC_HW)
#define AADDR_CRC1_CRC_HW                                    (BASE_ADDR_CRC1 + ADDR_CRC_CRC_HW)
#define REG_CRC0_CRC_HW                                      (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_CRC_HW))
#define REG_CRC1_CRC_HW                                      (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_CRC_HW))

#define ADDR_CRC_IRQ_STATUS                                  (0x2CU)
#define A_CRC_IRQ_STATUS(ba)                                 ((ba) + ADDR_CRC_IRQ_STATUS)
#define R_CRC_IRQ_STATUS(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CRC_IRQ_STATUS(ba)))
#define RES_CRC_IRQ_STATUS                                   (0x6U)
#define MSB_CRC_IRQ_STATUS                                   2
#define LSB_CRC_IRQ_STATUS                                   0
#define AADDR_CRC0_IRQ_STATUS                                (BASE_ADDR_CRC0 + ADDR_CRC_IRQ_STATUS)
#define AADDR_CRC1_IRQ_STATUS                                (BASE_ADDR_CRC1 + ADDR_CRC_IRQ_STATUS)
#define REG_CRC0_IRQ_STATUS                                  (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_IRQ_STATUS))
#define REG_CRC1_IRQ_STATUS                                  (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_IRQ_STATUS))

#define ADDR_CRC_IRQ_MASK                                    (0x30U)
#define A_CRC_IRQ_MASK(ba)                                   ((ba) + ADDR_CRC_IRQ_MASK)
#define R_CRC_IRQ_MASK(ba)                                   (*(volatile unsigned short *)((unsigned int)A_CRC_IRQ_MASK(ba)))
#define RES_CRC_IRQ_MASK                                     (0x0U)
#define MSB_CRC_IRQ_MASK                                     2
#define LSB_CRC_IRQ_MASK                                     0
#define AADDR_CRC0_IRQ_MASK                                  (BASE_ADDR_CRC0 + ADDR_CRC_IRQ_MASK)
#define AADDR_CRC1_IRQ_MASK                                  (BASE_ADDR_CRC1 + ADDR_CRC_IRQ_MASK)
#define REG_CRC0_IRQ_MASK                                    (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_IRQ_MASK))
#define REG_CRC1_IRQ_MASK                                    (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_IRQ_MASK))

#define ADDR_CRC_IRQ_VENABLE                                 (0x34U)
#define A_CRC_IRQ_VENABLE(ba)                                ((ba) + ADDR_CRC_IRQ_VENABLE)
#define R_CRC_IRQ_VENABLE(ba)                                (*(volatile unsigned short *)((unsigned int)A_CRC_IRQ_VENABLE(ba)))
#define RES_CRC_IRQ_VENABLE                                  (0x0U)
#define MSB_CRC_IRQ_VENABLE                                  1
#define LSB_CRC_IRQ_VENABLE                                  0
#define AADDR_CRC0_IRQ_VENABLE                               (BASE_ADDR_CRC0 + ADDR_CRC_IRQ_VENABLE)
#define AADDR_CRC1_IRQ_VENABLE                               (BASE_ADDR_CRC1 + ADDR_CRC_IRQ_VENABLE)
#define REG_CRC0_IRQ_VENABLE                                 (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_IRQ_VENABLE))
#define REG_CRC1_IRQ_VENABLE                                 (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_IRQ_VENABLE))

#define ADDR_CRC_IRQ_VDISABLE                                (0x36U)
#define A_CRC_IRQ_VDISABLE(ba)                               ((ba) + ADDR_CRC_IRQ_VDISABLE)
#define R_CRC_IRQ_VDISABLE(ba)                               (*(volatile unsigned short *)((unsigned int)A_CRC_IRQ_VDISABLE(ba)))
#define RES_CRC_IRQ_VDISABLE                                 (0x0U)
#define MSB_CRC_IRQ_VDISABLE                                 1
#define LSB_CRC_IRQ_VDISABLE                                 0
#define AADDR_CRC0_IRQ_VDISABLE                              (BASE_ADDR_CRC0 + ADDR_CRC_IRQ_VDISABLE)
#define AADDR_CRC1_IRQ_VDISABLE                              (BASE_ADDR_CRC1 + ADDR_CRC_IRQ_VDISABLE)
#define REG_CRC0_IRQ_VDISABLE                                (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_IRQ_VDISABLE))
#define REG_CRC1_IRQ_VDISABLE                                (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_IRQ_VDISABLE))

#define ADDR_CRC_IRQ_VMAX                                    (0x38U)
#define A_CRC_IRQ_VMAX(ba)                                   ((ba) + ADDR_CRC_IRQ_VMAX)
#define R_CRC_IRQ_VMAX(ba)                                   (*(volatile unsigned short *)((unsigned int)A_CRC_IRQ_VMAX(ba)))
#define RES_CRC_IRQ_VMAX                                     (0x3U)
#define MSB_CRC_IRQ_VMAX                                     1
#define LSB_CRC_IRQ_VMAX                                     0
#define AADDR_CRC0_IRQ_VMAX                                  (BASE_ADDR_CRC0 + ADDR_CRC_IRQ_VMAX)
#define AADDR_CRC1_IRQ_VMAX                                  (BASE_ADDR_CRC1 + ADDR_CRC_IRQ_VMAX)
#define REG_CRC0_IRQ_VMAX                                    (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_IRQ_VMAX))
#define REG_CRC1_IRQ_VMAX                                    (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_IRQ_VMAX))

#define ADDR_CRC_IRQ_VNO                                     (0x3AU)
#define A_CRC_IRQ_VNO(ba)                                    ((ba) + ADDR_CRC_IRQ_VNO)
#define R_CRC_IRQ_VNO(ba)                                    (*(volatile unsigned short *)((unsigned int)A_CRC_IRQ_VNO(ba)))
#define RES_CRC_IRQ_VNO                                      (0x3U)
#define MSB_CRC_IRQ_VNO                                      1
#define LSB_CRC_IRQ_VNO                                      0
#define AADDR_CRC0_IRQ_VNO                                   (BASE_ADDR_CRC0 + ADDR_CRC_IRQ_VNO)
#define AADDR_CRC1_IRQ_VNO                                   (BASE_ADDR_CRC1 + ADDR_CRC_IRQ_VNO)
#define REG_CRC0_IRQ_VNO                                     (*(volatile unsigned short *)((unsigned int)AADDR_CRC0_IRQ_VNO))
#define REG_CRC1_IRQ_VNO                                     (*(volatile unsigned short *)((unsigned int)AADDR_CRC1_IRQ_VNO))

#endif
