#include "hardware.h"
#include "systick_api.h"
#include "errors_api.h"

static void (*systick_ptr_callback)(void)=NULL; ///< Pointer to callback function

static volatile uint32_t systick_sw_counter;

/* ############################################################################ */
errors_api_code_e systick_api_init( uint32_t load_cycles ) {
  if(SysTick_Config(load_cycles)) {
    return(eError_systick_api_reload_value);
  }
  systick_sw_counter=0;
  return(eError_none);
}

/* ############################################################################ */
void systick_api_callback( void (*ptr_callback_irq)(void) ) {
  systick_ptr_callback = ptr_callback_irq;
}

/* ############################################################################ */
_INTERRUPT_ SysTick_Handler( void ) {
  systick_sw_counter++;
  
  if (systick_ptr_callback!=NULL) {
   systick_ptr_callback(); 
  }
}

/* ############################################################################ */
uint32_t systick_api_get_value(void) {
  return(systick_sw_counter);
}

/* ############################################################################ */
void systick_api_clr(void) {
  SysTick->VAL=0;
  
}

/* ############################################################################ */
void systick_api_delay(uint32_t i_wait_for_load_cyces) {
  
  uint32_t i_start;
  uint32_t i_end;
  
  i_start = systick_api_get_value();
  i_end = i_start + i_wait_for_load_cyces;
  
  if (i_start < i_end) { 
    while ((systick_api_get_value() >= i_start) && (systick_api_get_value() < i_end)) { 
      // do nothing 
    } 
  } else { 
    while ((systick_api_get_value() >= i_start) || (systick_api_get_value() < i_end)) {
      // do nothing
    }
  }
}
