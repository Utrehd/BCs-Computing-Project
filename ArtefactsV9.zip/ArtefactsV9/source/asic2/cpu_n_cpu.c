/* FPGA Release: 10512 */
#include "cpu_n_cpu.h"
#include "cpu_n_cpu_irq.h"
#include "utils.h"




//******************************************************************************
// ACCESS CONTROL CONTROL
//******************************************************************************

void cpu_n_cpu_set_acc_n(uint16_t acc_n){ 
	WRITE_REG_16(CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_N, acc_n);  
}      
        
uint16_t cpu_n_cpu_get_acc_n(){  
	return READ_REG_U16(CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_N);
}   

void cpu_n_cpu_set_acc_tsf(uint16_t acc_tsf){
	WRITE_REG_16(CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_TSF, acc_tsf);
}

uint16_t cpu_n_cpu_get_acc_tsf(){
	return READ_REG_U16(CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_TSF);
}

void cpu_n_cpu_set_acc_irq_set(uint16_t acc_irq_set){
	WRITE_REG_16(CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_IRQ_SET, acc_irq_set); 
}  

uint16_t cpu_n_cpu_get_acc_irq_set(){
	return READ_REG_U16(CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_IRQ_SET);
}

void cpu_n_cpu_set_acc_irq_clr(uint16_t acc_irq_clr){
	WRITE_REG_16(CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_IRQ_CLR, acc_irq_clr);
}
	
uint16_t cpu_n_cpu_get_acc_irq_clr(){
	return READ_REG_U16(CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_IRQ_CLR); 
}

//******************************************************************************
// ACCESS CONTROL
//******************************************************************************

uint16_t cpu_n_cpu_get_ac_tsf(cpu_n_cpu_num_t cpu_n_cpu_no){
  return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_AC_TSF);
}

uint16_t cpu_n_cpu_get_ac_irq_set(cpu_n_cpu_num_t cpu_n_cpu_no){
  return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_AC_IRQ_SET);
}

uint16_t cpu_n_cpu_get_ac_irq_clr(cpu_n_cpu_num_t cpu_n_cpu_no){
  return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_AC_IRQ_CLR);
}

//******************************************************************************
// TEST/SET FLAGS
//******************************************************************************

uint16_t cpu_n_cpu_test_set_flag(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t ts_flag_no){
  return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_TSF0 + 2*ts_flag_no);
}

void cpu_n_cpu_clr_ts_flag(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t ts_flag_no){
	WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_TSF0 + 2*ts_flag_no, 0xFFFF);
}

uint16_t cpu_n_cpu_get_ts_flags(cpu_n_cpu_num_t cpu_n_cpu_no){
	return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_TS_FLAGS); 
}

      
//******************************************************************************
// SET/CLEAR IRQ FLAGS
//******************************************************************************

void cpu_n_cpu_set_irq_flag(cpu_n_cpu_num_t  cpu_n_cpu_no, uint16_t set_no){
	WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR, (0xFF00 | set_no));  
}

void cpu_n_cpu_clr_irq_flag(cpu_n_cpu_num_t  cpu_n_cpu_no, uint16_t clr_no){
	WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR, (0x00FF | (clr_no << 8)));
}

void cpu_n_cpu_set_clr_irq_flag(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t set_no, uint16_t clr_no){
	WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR, (0x0000 | set_no | clr_no << 8));
}

/* ======================================================================= */
/* CONSTANT VALUES                                                         */
/* ======================================================================= */

//const uint16_t cpu_n_cpu_bases[NUMBER_CPU_N_CPU] = {/
//	CPU_N_CPU_H430,
//	CPU_N_CPU_EXT,
//};
/*
vic_irq_t cpu_n_cpu_vic_irqs[NUMBER_CPU_N_CPU] = {
	VIC_IRQ_CPU_N_CPU_H430,
	VIC_IRQ_CPU_N_CPU_EXT,
};
*/

//******************************************************************************
// IRQ
//******************************************************************************


//======================= IRQ ===========================================

void cpu_n_cpu_set_irq_mask0(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t mask){
	WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_MASK0, mask);
}

uint16_t cpu_n_cpu_get_irq_mask0(cpu_n_cpu_num_t cpu_n_cpu_no){
	return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_MASK0);
}

void cpu_n_cpu_set_irq_mask1(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t mask){
	WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_MASK1, mask);
}

uint16_t cpu_n_cpu_get_irq_mask1(cpu_n_cpu_num_t cpu_n_cpu_no){
	return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_MASK1); 
}

uint16_t cpu_n_cpu_get_irq_status0(cpu_n_cpu_num_t cpu_n_cpu_no){
	return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_STATUS0);
}

uint16_t cpu_n_cpu_get_irq_status1(cpu_n_cpu_num_t cpu_n_cpu_no){
        return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_STATUS1); 
}

void cpu_n_cpu_irq_venable(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t vno){
  WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_VENABLE, vno);
}

void cpu_n_cpu_irq_vdisable(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t vno){
  WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_VDISABLE, vno);
}

void cpu_n_cpu_set_irq_vmax(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t vmax){
  WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_VMAX, vmax);
}

uint16_t cpu_n_cpu_get_irq_vmax(cpu_n_cpu_num_t cpu_n_cpu_no){
        return READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_VMAX); 
}
/*
cpu_n_cpu_irq_t cpu_n_cpu_get_irq_vno(cpu_n_cpu_num_t cpu_n_cpu_no){
        return (cpu_n_cpu_irq_t) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_VNO);
}
*/
