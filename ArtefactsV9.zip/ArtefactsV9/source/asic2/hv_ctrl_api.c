#include "hardware.h"
#include "hv_ctrl_api.h"

/* ############################################################################ */

uint16_t hv_ctrl_api_get_register(hv_ctrl_api_register_e hv_register){

  uint16_t data;

  data = hv_ctrl_ir_shift(hv_register, true);
  hv_ctrl_dr_shift(data);
  
  return data;
}

/* ############################################################################ */

void hv_ctrl_api_set_register(hv_ctrl_api_register_e hv_register, uint16_t data){

  hv_ctrl_ir_shift(hv_register, false);
  hv_ctrl_dr_shift(data);
  
}

/* ############################################################################ */
  
void hv_ctrl_api_init(){
  
  // 1. the timing has to be configured with the JTAG_TIMING register
  hv_ctrl_cfg_timing(5);
  
  // 2. the HV reset has to be released with the JTAG_RESET register
  hv_ctrl_set_nres(true);
  // 3. perform TAP reset with JTAG_IR_CMD and tap_reset=1
  hv_ctrl_tap_reset();
  // 4. poll JTAG_STATUS until no cpu_request
  while(hv_ctrl_is_cpu_request());
  
}

/* ############################################################################ */
static uint8_t g_isink[3];

/* ############################################################################ */
bool hv_ctrl_api_set_isink(uint8_t no, uint8_t val){
  if(no<3) {
    if(g_isink[no]!=val) {
      hv_ctrl_set_isink(no,   val);    
      g_isink[no]=val;
      return true;
    }
  }
  return false;		 
}


/* ############################################################################ */
void hv_ctrl_api_rs485_enable(bool bSlewEnable){
  hv_ctrl_cfg_phy(true,        // hrx485_npd
                  true,        // htx485_npd
                  bSlewEnable, // htx485_slew_enable
                  true,        // htx485_bbm_fast
                  true,        // htx485_auto_shutdown
                  true,        // htx485_tempsens_enable
                  true);       // htx485_tempsens_mask
}
