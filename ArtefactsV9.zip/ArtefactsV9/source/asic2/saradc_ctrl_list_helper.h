/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         saradc_ctrl_list_helper.h
*
* @brief        SAR ADC Control API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SARADC_CTRL_LIST_HELPER_H
#define HAVE_SARADC_CTRL_LIST_HELPER_H

#include "saradc_ctrl.h"
#include "device.h"

// ------------------------------------------------------------
// these structures need to be packed
// ------------------------------------------------------------
#ifdef __GNUC__
#define _PACKED_ __attribute__ ((packed))
#endif

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(push)
#pragma pack(2)
#define _PACKED_
#endif

/// @cond DEV
typedef struct {
  volatile uint16_t target_adr                    :    14;      /* [15:2]  */
  volatile uint16_t TADR_MODE                     :    2;       /* [2:0]   */
  volatile uint16_t no_sample                     :    4;       /* [19:16] */
  volatile uint16_t no_sum                        :    5;       /* [24:20] */
  volatile uint16_t ch_no                         :    5;       /* [29:25] */
  volatile uint16_t trigger_type                  :    2;       /* [31:30] */
  volatile uint16_t pwm_phase                     :    16;      /* [47:32] */
} _PACKED_ sarc_command_mpwm_type;

typedef struct {
  volatile uint16_t target_adr                    :    14;      /* [15:2]  */
  volatile uint16_t TADR_MODE                     :    2;       /* [2:0]   */
  volatile uint16_t no_sample                     :    4;       /* [19:16] */
  volatile uint16_t no_sum                        :    5;       /* [24:20] */
  volatile uint16_t ch_no                         :    5;       /* [29:25] */
  volatile uint16_t trigger_type                  :    2;       /* [31:30] */
  volatile uint16_t trigger                       :    16;      /* [47:32] */
} _PACKED_ sarc_command_mimm_type;


typedef struct {
  volatile uint16_t target_adr                    :    14;      /* [15:2]  */
  volatile uint16_t TADR_MODE                     :    2;       /* [2:0]   */
  volatile uint16_t no_sample                     :    4;       /* [19:16] */
  volatile uint16_t no_sum                        :    5;       /* [24:20] */
  volatile uint16_t ch_no                         :    5;       /* [29:25] */
  volatile uint16_t trigger_type                  :    2;       /* [31:30] */
  volatile uint16_t dte_mask                      :    8;       /* [39:32] */
  volatile uint16_t wait_time                     :    8;       /* [47:40] */
} _PACKED_ sarc_command_mdte_type;

typedef struct {
  volatile uint16_t u_bound                       :    16;      /* [15:0]  */
  volatile uint16_t l_bound                       :    15;      /* [30:16] */
  volatile uint16_t trigger_type                  :    1;       /* [31:31] */
  volatile uint16_t N                             :    4;       /* [35:32] */
  volatile uint16_t trigger                       :    12;      /* [47:36] */
} _PACKED_ sarc_command_aoor_n_type;

typedef struct {
  volatile uint16_t u_bound                       :    16;      /* [15:0]  */
  volatile uint16_t l_bound                       :    15;      /* [30:16] */
  volatile uint16_t trigger_type                  :    1;       /* [31:31] */
  volatile uint16_t N                             :    4;       /* [35:32] */
  volatile uint16_t trigger                       :    12;      /* [47:36] */
} _PACKED_ sarc_command_anoor_n_type;

typedef struct {
  volatile uint16_t u_bound                       :    16;      /* [15:0]  */
  volatile uint16_t l_bound                       :    15;      /* [30:16] */
  volatile uint16_t trigger_type                  :    1;       /* [31:31] */
  volatile uint16_t trigger                       :    16;      /* [47:32] */
} _PACKED_ sarc_command_loop_tadr_type;

typedef struct {
  volatile uint16_t u_bound                       :    16;      /* [15:0]  */
  volatile uint16_t l_bound                       :    15;      /* [30:16] */
  volatile uint16_t trigger_type                  :    1;       /* [31:31] */
  volatile uint16_t trigger                       :    16;      /* [47:32] */
} _PACKED_ sarc_command_loop_ntadr_type;

typedef struct {
  volatile uint16_t u_bound                       :    16;      /* [15:0]  */
  volatile uint16_t l_bound                       :    15;      /* [30:16] */
  volatile uint16_t trigger_type                  :    1;       /* [31:31] */
  volatile uint16_t trigger                       :    16;      /* [47:32] */
} _PACKED_ sarc_command_loop_bp_type;

typedef struct {
  volatile uint16_t u_bound                       :    16;      /* [15:0]  */
  volatile uint16_t l_bound                       :    15;      /* [30:16] */
  volatile uint16_t trigger_type                  :    1;       /* [31:31] */
  volatile uint16_t trigger                       :    16;      /* [47:32] */
} _PACKED_ sarc_command_loop_nbp_type;

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(pop)
#endif 

// ------------------------------------------------------------
// no packing needed here
// ------------------------------------------------------------

//command types incomplete
//append if necessary

/// @endcond

typedef union  sarc_command_type{
  uint16_t                      list_entry_u16[3];
  saradc_ctrl_list_entry        list_entry;
  sarc_command_mimm_type        mimm;
  sarc_command_mpwm_type        mpwm;
  sarc_command_mdte_type        mdte;
  sarc_command_aoor_n_type      aoor_n;
  sarc_command_anoor_n_type     anoor_n;
  sarc_command_loop_tadr_type   loop_tadr;
  sarc_command_loop_ntadr_type  loop_ntadr;
  sarc_command_loop_bp_type     loop_bp;
  sarc_command_loop_nbp_type    loop_nbp;
}sarc_command_type_t;

//TADR register usage
#define SARC_TADR_NONE    0
#define SARC_TADR_SET_USE 1
#define SARC_TADR_USE     3

//list item initializers, use directly in static lists
/* ############################################################################ */
/** 
 * \brief    initializer for MPWM command
 *
 * \see new_SARC_COMMAND_MPWM
 * 
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_MPWM(target_adr,TADR_mode,no_sample,no_sum,ch_no,pwm_phase) {((uint16_t)target_adr | TADR_mode),((no_sample & 0xF) | (no_sum & 0x1F) << 4 | (ch_no & 0x1F) << 9 | 0<<14),pwm_phase}

/* ############################################################################ */
/** 
 * \brief    initializer for MBP command
 *
 * \see new_SARC_COMMAND_MBP
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_MBP(target_adr,TADR_mode,no_sample,no_sum,ch_no,pwm_phase) {((uint16_t)target_adr | TADR_mode),((no_sample & 0xF) | (no_sum & 0x1F) << 4 | (ch_no & 0x1F) << 9 | (uint16_t)2<<14),base_phase}

/* ############################################################################ */
/** 
 * \brief    initializer for MDTE command
 *
 * \see new_SARC_COMMAND_MDTE
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_MDTE(target_adr,TADR_mode,no_sample,no_sum,ch_no,wait_time,dte_mask) {((uint16_t)target_adr | TADR_mode),((no_sample & 0xF) | (no_sum & 0x1F) << 4 | (ch_no & 0x1F) << 9 | 1<<14),(wait_time<<8 | dte_mask)}

/* ############################################################################ */
/** 
 * \brief    initializer for MIMM_SE command
 *
 * \see new_SARC_COMMAND_MIMM_SE
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_MIMM_SE(target_adr,TADR_mode,no_sample,no_sum,ch_no,sampling_extension) {((uint16_t)target_adr | TADR_mode),((no_sample & 0xF) | (no_sum & 0x1F) << 4 | (ch_no & 0x1F) << 9 | 1<<14),(sampling_extension<<8)}

/* ############################################################################ */
/** 
 * \brief    initializer for MIMM command
 *
 * \see new_SARC_COMMAND_MIMM
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_MIMM(target_adr,TADR_mode,no_sample,no_sum,ch_no) {((uint16_t)target_adr | TADR_mode),((no_sample & 0xF) | (no_sum & 0x1F) << 4 | (ch_no & 0x1F) << 9 | (uint16_t)2<<14),SARC_TRIGGER_MIMM}

/* ############################################################################ */
/** 
 * \brief    initializer for SMUX command
 *
 * \see new_SARC_COMMAND_SMUX
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_SMUX(ch_no, trigger_type, trigger) {0,(ch_no & 0x1F) << 9|(uint16_t)trigger_type<<14,trigger}

/// @cond DEV
#define __SARC_COMMAND_SMUX_SET_TADR(target_adr,ch_no, trigger_type, trigger) {target_adr|1,(ch_no & 0x1F) << 9|(uint16_t)trigger_type<<14,trigger}
/// @endcond

/* ############################################################################ */
/** 
 * \brief    initializer for SMUXIMM command
 *
 * \see new_SARC_COMMAND_SMUXIMM
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_SMUXIMM(ch_no) {0,(ch_no & 0x1F) << 9|1<<14,SARC_TRIGGER_SMUXIMM}

/* ############################################################################ */
/** 
 * \brief    initializer for ANOOR_N command
 *
 * \see new_SARC_COMMAND_ANOOR_N
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_ANOOR_N(N, u_bound, l_bound) {u_bound,(l_bound | (uint16_t)(1<<15)),SARC_TRIGGER_ANOOR_0+N}

/* ############################################################################ */
/** 
 * \brief    initializer for AOOR_N command
 *
 * \see new_SARC_COMMAND_AOOR_N
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_AOOR_N(N, u_bound, l_bound) {u_bound,(l_bound | (uint16_t)(1<<15)),SARC_TRIGGER_AOOR_0+N}

/* ############################################################################ */
/** 
 * \brief    initializer for BUS_WRITE command
 *
 * \see new_SARC_COMMAND_BUS_WRITE
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_BUS_WRITE(data, adr) {data, (adr|(uint16_t)(1<<15)),SARC_TRIGGER_BUS_WRITE}

/* ############################################################################ */
/** 
 * \brief    initializer for WAIT command
 *
 * \see new_SARC_COMMAND_WAIT
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_WAIT(wait_cycles) {wait_cycles,(uint16_t)(1<<15),SARC_TRIGGER_WAIT}

/* ############################################################################ */
/** 
 * \brief    initializer for WRITE_CFG command
 *
 * \see new_SARC_COMMAND_WRITE_CFG
 *
 * \ingroup saradc_ctrl
*/
#define __SARC_COMMAND_WRITE_CFG(cfg) {cfg,(uint16_t)2<<14,SARC_TRIGGER_WRITE_CFG}

/* ############################################################################ */
/** 
 * \brief    initializer for LOOP_TADR command
 *
 * \see new_SARC_COMMAND_LOOP_TADR
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_LOOP_TADR(u_bound, l_bound) {u_bound,(l_bound | (uint16_t)(1<<15)),SARC_TRIGGER_LOOP_TADR}

/* ############################################################################ */
/** 
 * \brief    initializer for LOOP_NTADR command
 *
 * \see new_SARC_COMMAND_LOOP_NTADR
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_LOOP_NTADR(u_bound, l_bound) {u_bound,(l_bound | (uint16_t)(1<<15)),SARC_TRIGGER_LOOP_NTADR}

/* ############################################################################ */
/** 
 * \brief    initializer for LOOP_BP command
 *
 * \see new_SARC_COMMAND_LOOP_BP
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_LOOP_BP(u_bound, l_bound) {u_bound,(l_bound | (uint16_t)(1<<15)),SARC_TRIGGER_LOOP_BP}

/* ############################################################################ */
/** 
 * \brief    initializer for LOOP_NBP command
 *
 * \see new_SARC_COMMAND_LOOP_NBP
 *
 * \ingroup saradc_ctrl
*/
#define __SARC_COMMAND_LOOP_NBP(u_bound, l_bound) {u_bound,(l_bound | (uint16_t)(1<<15)),SARC_TRIGGER_LOOP_NBP}

/* ############################################################################ */
/** 
 * \brief    initializer for GOTO_SUMLEQ command
 *
 * \see new_SARC_COMMAND_GOTO_SUMLEQ
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_GOTO_SUMLEQ(target_adr, compare_val) {((uint16_t)target_adr),compare_val|(uint16_t)(1<<15),SARC_TRIGGER_GOTO_SUMLEQ}

/* ############################################################################ */
/** 
 * \brief    initializer for GOTO_SUMNLEQ command
 *
 * \see new_SARC_COMMAND_GOTO_SUMNLEQ
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_GOTO_SUMNLEQ(target_adr, compare_val) {((uint16_t)target_adr),compare_val|(uint16_t)(1<<15),SARC_TRIGGER_GOTO_SUMNLEQ}

/* ############################################################################ */
/** 
 * \brief    initializer for GOTO_BPLEQ command
 *
 * \see new_SARC_COMMAND_GOTO_BPLEQ
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_GOTO_BPLEQ(target_adr, compare_val) {((uint16_t)target_adr),compare_val|(uint16_t)(1<<15),SARC_TRIGGER_GOTO_BPLEQ}

/* ############################################################################ */
/** 
 * \brief    initializer for BPNLEQ command
 *
 * \see new_SARC_COMMAND_BPNLEQ
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_GOTO_BPNLEQ(target_adr, compare_val) {((uint16_t)target_adr),compare_val|(uint16_t)(1<<15),SARC_TRIGGER_GOTO_BPNLEQ}

/* ############################################################################ */
/** 
 * \brief    initializer for GOTO command
 *
 * \see new_SARC_COMMAND_GOTO
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_GOTO(target_adr) {((uint16_t)target_adr),(uint16_t)(2<<14),SARC_TRIGGER_GOTO}

/* ############################################################################ */
/** 
 * \brief    initializer for END command
 *
 * \see new_SARC_COMMAND_END
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_END() {0,(uint16_t)2<<14,SARC_TRIGGER_END}

/* ############################################################################ */
/** 
 * \brief    initializer for SYNC_EVT command
 *
 * \see new_SARC_COMMAND_SYNC_EVT
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_SYNC_EVT() {0,(uint16_t)2<<14,SARC_TRIGGER_SYNC_EVT}

/* ############################################################################ */
/** 
 * \brief    initializer for ST_BP command
 *
 * \see new_SARC_COMMAND_ST_BP
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_ST_BP(target_adr, TADR_mode) {((uint16_t)target_adr | TADR_mode),(uint16_t)(1<<15),SARC_TRIGGER_ST_BP}

/* ############################################################################ */
/** 
 * \brief    initializer for ST_TADR command
 *
 * \see new_SARC_COMMAND_ST_TADR
 *
 * \ingroup saradc_ctrl
 */
#define __SARC_COMMAND_ST_TADR(target_adr, TADR_mode) {((uint16_t)target_adr | TADR_mode),(uint16_t)(1<<15),SARC_TRIGGER_ST_TADR}

/// @cond DEV
#define __SARC_COMMAND_MIMM_HIST(target_adr,TADR_mode,no_sample,no_sum,ch_no) {((uint16_t)target_adr | TADR_mode),((no_sample & 0xF) | (no_sum & 0x1F) << 4 | (ch_no & 0x1F) << 9 | (uint16_t)2<<14),SARC_TRIGGER_MIMM_HIST}
/// @endcond


/* ############################################################################ */
/* ############################################################################ */
/* ############################################################################ */
/* ############################################################################ */
/* ############################################################################ */
/**
 * \defgroup saradc_ctrl_commands SAR ADC commands
 *
 * \brief   Instruction for SAR ADC sequencer
 *
 * \ingroup saradc_ctrl
 */
/**@{*/ 

//list command constructors for dynamic list definitions
/* ############################################################################ */ 
/** 
 * \brief    creates a new MPWM (trigger when PWM phase matches trigger) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr   target memory for samples
 *
 * \param  TADR_mode   TADR_NONE: use target_adr directly,  
 *                         TADR_SET_USE: set TADR register to target_adr and use TADR, 
 *                         TADR_USE: use TADR register
 *
 * \param  no_sample   number of samples per sum -1 (0..15
 *
 * \param  no_sum      number of sums (1..31)
 *
 * \param  ch_no       channel to be selected after completion (1..31)
 *
 * \param  pwm_phase   trigger when PWM phase == pwm_phase (0..0xFFFF)
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_MPWM(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t pwm_phase);

/* ############################################################################ */
/** 
 * \brief  creates a new MBP (trigger when TSU basephase matches trigger) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 * 
 * \param  target_adr   target memory for samples
 *
 * \param  TADR_mode   TADR_NONE: use target_adr directly,  
 *                         TADR_SET_USE: set TADR register to target_adr and use TADR, 
 *                         TADR_USE: use TADR register
 *
 * \param  no_sample   number of samples per sum -1 (0..15
 *
 * \param  no_sum      number of sums (1..31)
 *
 * \param  ch_no       channel to be selected after completion (1..31)
 *
 * \param  base_phase   trigger when TSU base phase == base_phase (0..0x03FF)
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_MBP(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t base_phase);

/* ############################################################################ */
/** 
 * \brief  creates a new MDTE (trigger at PWM dead time event) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr   target memory for samples
 *
 * \param  TADR_mode   TADR_NONE: use target_adr directly,  
 *                     TADR_SET_USE: set TADR register to target_adr and use TADR, 
 *                     TADR_USE: use TADR register
 *
 * \param  no_sample   number of samples per sum -1 (0..15
 *
 * \param  no_sum      number of sums (1..31)
 *
 * \param  ch_no       channel to be selected after completion (1..31)
 *
 * \param  wait_time   wait time in cpu cycles after a dead time event matching dte_mask has occurred (0x00..0xFF)
 *
 * \param  dte_mask    trigger when dead time event n occurs and bit n of dte_mask is set (0x01..0xFF)
 *
 * \ingroup saradc_ctrl_commands
 */ 
void new_SARC_COMMAND_MDTE(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t wait_time, uint16_t dte_mask);

/* ############################################################################ */
/** 
 * \brief  creates a new MIMM_SE (trigger immediately with sampling extension) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr   target memory for samples
 *
 * \param  TADR_mode   TADR_NONE: use target_adr directly,  
 *                     TADR_SET_USE: set TADR register to target_adr and use TADR, 
 *                     TADR_USE: use TADR register
 * \param  no_sample   number of samples per sum -1 (0..15)
 *
 * \param  no_sum      number of sums (1..31)
 *
 * \param  ch_no       channel to be selected after completion (1..31)
 *
 * \param  sampling_extension   number of cycles for extension (1..31), refer to WAIT_PRESCALER register
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_MIMM_SE(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t sampling_extension);

/* ############################################################################ */
/** 
 * \brief  creates a new MIMM (trigger immediately) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr   target memory for sample
 *
 * \param  TADR_mode   TADR_NONE: use target_adr directly,  
 *                     TADR_SET_USE: set TADR register to target_adr and use TADR, 
 *                     TADR_USE: use TADR register
 *
 * \param  no_sample   number of samples per sum -1 (0..15
 *
 * \param  no_sum      number of sums (1..31)
 *
 * \param  ch_no       channel to be selected after completion (1..31)
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_MIMM(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no);

/* ############################################################################ */
/** 
 * \brief  creates a new SMUX (set MUX without sampling) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  ch_no       channel to be selected after completion (1..31)
 *
 * \param  trigger_type     TODO
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_SMUX(sarc_command_type_t *cmd, uint16_t ch_no, uint16_t trigger_type, uint16_t trigger);

/// @cond DEV
void new_SARC_COMMAND_SMUX_SET_TADR(sarc_command_type_t *cmd, uint16_t target_adr, uint16_t ch_no, uint16_t trigger_type, uint16_t trigger);
/// @endcond

/* ############################################################################ */
/** 
 * \brief  creates a new SMUXIMM (set MUX immediately without sampling) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  ch_no       channel to be selected
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_SMUXIMM(sarc_command_type_t *cmd, uint16_t ch_no);

/// @cond DEV
void new_SARC_COMMAND_SMUXIMM_SET_TADR(sarc_command_type_t *cmd, uint16_t target_adr, uint16_t ch_no);
/// @endcond

/* ############################################################################ */
/** 
 * \brief  creates a new ANOOR_N (assert OOR interrupt if sum isnot out of range) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  N   number of OOR interrupt to be asserted
 *
 * \param  u_bound   upper bound for NOT out of range condition
 *
 * \param  l_bound   lower bound for NOT out of range condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_ANOOR_N(sarc_command_type_t *cmd, uint16_t N, uint16_t u_bound, uint16_t l_bound);

/* ############################################################################ */
/** 
 * \brief  creates a new AOOR_N (assert OOR interrupt N if sum is out of range) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  N   number of OOR interrupt to be asserted
 *
 * \param  u_bound   upper bound for out of range condition
 *
 * \param  l_bound   lower bound for out of range condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_AOOR_N(sarc_command_type_t *cmd, uint16_t N, uint16_t u_bound, uint16_t l_bound);

/* ############################################################################ */
/** 
 * \brief    creates a new BUS_WRITE (write data to adr via DMA) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \ingroup saradc_ctrl_commands
 * TODO
 */
void new_SARC_COMMAND_BUS_WRITE(sarc_command_type_t *cmd, uint16_t data, uint16_t adr);

/* ############################################################################ */
/** 
 * \brief  creates a new WAIT (write data to adr via DMA) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  wait_cycles  number of cpu cycles to wait
 *
 * \see set_wait_prescaler
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_WAIT(sarc_command_type_t *cmd, uint16_t wait_cycles);

/* ############################################################################ */
/** 
 * \brief  creates a new WRITE_CFG (write SAR ADC CTRL cfg register via list command) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  cfg  data to write to register
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_WRITE_CFG(sarc_command_type_t *cmd, uint16_t cfg);

/* ############################################################################ */
/** 
 * \brief  creates a new LOOP_TADR (repeat list until lbound <= TADR <= ubound) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  lbound  lower bound for condition
 *
 * \param  lbound  upper bound for condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_LOOP_TADR(sarc_command_type_t *cmd, uint16_t u_bound, uint16_t l_bound);

/* ############################################################################ */
/** \brief creates a new LOOP_NTADR (repeat list until NOT(lbound <= TADR <= ubound)) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  lbound  lower bound for condition
 *
 * \param  lbound  upper bound for condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_LOOP_NTADR(sarc_command_type_t *cmd, uint16_t u_bound, uint16_t l_bound);

/* ############################################################################ */
/** 
 * \brief  creates a new LOOP_BP (repeat list until lbound <= base phase <= ubound) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  lbound  lower bound for condition
 *
 * \param  lbound  upper bound for condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_LOOP_BP(sarc_command_type_t *cmd, uint16_t u_bound, uint16_t l_bound);

/* ############################################################################ */
/** 
 * \brief  creates a new LOOP_NBP (repeat list until NOT(lbound <= base phase <= ubound)) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  lbound  lower bound for condition
 *
 * \param  lbound  upper bound for condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_LOOP_NBP(sarc_command_type_t *cmd, uint16_t u_bound, uint16_t l_bound);

/* ############################################################################ */
/** 
 * \brief  creates a new GOTO_SUMLEQ (goto target_adr if last sum <= compare_val) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr  target list address for jump
 *
 * \param  compare_val  compare value for condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_GOTO_SUMLEQ(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t compare_val);

/* ############################################################################ */
/** 
 * \brief    creates a new GOTO_SUMNLEQ (goto target_adr if NOT(last sum <= compare_val)) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr  target list address for jump
 *
 * \param  compare_val  compare value for condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_GOTO_SUMNLEQ(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t compare_val);

/* ############################################################################ */
/** 
 * \brief    creates a new GOTO_BPLEQ (goto target_adr if base_phase <= compare_val) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr  target list address for jump
 *
 * \param  compare_val  compare value for condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_GOTO_BPLEQ(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t compare_val);

/* ############################################################################ */
/** 
 * \brief    creates a new GOTO_BPLEQ (goto target_adr if NOT(base_phase <= compare_val)) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr  target list address for jump
 *
 * \param  compare_val  compare value for condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_GOTO_BPNLEQ(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t compare_val);

/* ############################################################################ */
/** 
 * \brief    creates a new GOTO(goto target_adr) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr  target list address for jump
 *
 * \param  compare_val  compare value for condition
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_GOTO(sarc_command_type_t *cmd, uint16_t *target_adr);

/* ############################################################################ */
/** 
 * \brief    creates a new END(end of list) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * more
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_END(sarc_command_type_t *cmd);

/* ############################################################################ */
/** 
 * \brief    creates a new SYNC_EVT(assert sync out) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * more
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_SYNC_EVT(sarc_command_type_t *cmd);

/* ############################################################################ */
/** 
 * \brief    creates a new ST_BP(store base phase instead of sum) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr  target address for write
 *
 * more
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_ST_BP(sarc_command_type_t *cmd, uint16_t * target_adr, uint16_t TADR_mode);

/* ############################################################################ */
/** 
 * \brief    creates a new ST_TADR(store content of TADR register instead of sum) command at the address pointed to by *cmd
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  target_adr  target address for write
 *
 * more
 *
 * \ingroup saradc_ctrl_commands
 */
void new_SARC_COMMAND_ST_TADR(sarc_command_type_t *cmd, uint16_t * target_adr, uint16_t TADR_mode);

/// @cond DEV
void new_SARC_COMMAND_MIMM_HIST(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no);
/// @endcond

/* ############################################################################ */
/** 
 * \brief  Print all instruction for SAR ADC sequencer
 *
 * \param  verbose  verbose on, print detailed description
 *
 * more
 *
 * \ingroup saradc_ctrl
 */
void print_list_command(sarc_command_type_t *cmd, bool verbose);



//other HAL functions

//void sarc_app_single_shot(uint16_t *target_adr, uint16_t ch_no);

/* ############################################################################ */
/** 
 * \brief    waits for the completion of a list by polling SARADC_CTRL irq_status register
 *
 * more
 *
 * \ingroup saradc_ctrl
 */
void wait_for_list_done();

/* ############################################################################ */
/** 
 * \brief    starts a list by writing to sadr_new register
 *
 * \param  list_adr start address of the list
 *
 * \param  list_skip if true skip the current list
 *
 * more
 *
 * \ingroup saradc_ctrl
 */
void start_list(uint16_t * list_adr, bool list_skip); 

/* ############################################################################ */
/** 
 * \brief    starts the PWM for test purposes
 *
 * \ingroup saradc_ctrl
 */
void saradc_ctrl_start_pwmn(void);

/* ############################################################################ */
/** 
 * \brief    stops the PWM for test purposes
 *
 * \ingroup saradc_ctrl
 */
void saradc_ctrl_stop_pwmn(void);
#endif
