/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         io_ctrl_bf.h
*
* @brief        IO Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __IO_CTRL_BF_H__
#define __IO_CTRL_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_IO_CTRL
#define BASE_ADDR_IO_CTRL 0x40006680U
#endif

#define NUMBER_IO_CTRL 1


/* ############################################################################ */
/**
 * \brief This is an enum class for IO CONTROL instance
 *
 * \ingroup io_ctrl 
 */ 
typedef enum {
  /**
   * This is instance IO_CTRL
   */ 
  IO_CTRL                        = (int)BASE_ADDR_IO_CTRL
} io_ctrl_num_t;

// Register bit field definitions

/* IO_CTRL_GUARD */

#define MSK_IO_CTRL_GUARD                                   (0xff)    /* [ 7:0] */

typedef unsigned short io_ctrl_guard_t;                               /* [ 7:0] */


/* IO_CTRL_S_EVEN */

#define MSK_IO_CTRL_S_EVEN_PINA                             (0xff)    /* [ 7:0] */
#define RES_IO_CTRL_S_EVEN_PINA                             (0x00)
#define SFT_IO_CTRL_S_EVEN_PINA                             (0)
#define LSB_IO_CTRL_S_EVEN_PINA                             (0)
#define MSB_IO_CTRL_S_EVEN_PINA                             (7)
#define MSK_IO_CTRL_S_EVEN_PINB                             (0xff)    /* [15:8] */
#define RES_IO_CTRL_S_EVEN_PINB                             (0x00)
#define SFT_IO_CTRL_S_EVEN_PINB                             (8)
#define LSB_IO_CTRL_S_EVEN_PINB                             (8)
#define MSB_IO_CTRL_S_EVEN_PINB                             (15)


/* ############################################################################ */
/**
 * \brief This structure describes IO CONTROL pinout group A and B
 *
 * \ingroup io_ctrl 
 */ 
typedef struct {
  /**
   * Pins group A
   */ 
  unsigned short pina                          :    8;       /* [ 7:0] */
  /**
   * Pins group B
   */ 
  unsigned short pinb                          :    8;       /* [15:8] */
} io_ctrl_s_even_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of IO CONTROL pinout group A and B
 *
 * \ingroup io_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  io_ctrl_s_even_bf bf;  ///< bit field representation
} io_ctrl_s_even_t;


/* IO_CTRL_S_ODD */

#define MSK_IO_CTRL_S_ODD_PINC                              (0xff)    /* [ 7:0] */
#define RES_IO_CTRL_S_ODD_PINC                              (0x00)
#define SFT_IO_CTRL_S_ODD_PINC                              (0)
#define LSB_IO_CTRL_S_ODD_PINC                              (0)
#define MSB_IO_CTRL_S_ODD_PINC                              (7)
#define MSK_IO_CTRL_S_ODD_PIND                              (0xff)    /* [15:8] */
#define RES_IO_CTRL_S_ODD_PIND                              (0x00)
#define SFT_IO_CTRL_S_ODD_PIND                              (8)
#define LSB_IO_CTRL_S_ODD_PIND                              (8)
#define MSB_IO_CTRL_S_ODD_PIND                              (15)


/* ############################################################################ */
/**
 * \brief This structure describes IO CONTROL pinout group C and D
 *
 * \ingroup io_ctrl 
 */ 
typedef struct {
  /**
   * Pins group C
   */ 
  unsigned short pinc                          :    8;       /* [ 7:0] */
  /**
   * Pins group D
   */ 
  unsigned short pind                          :    8;       /* [15:8] */
} io_ctrl_s_odd_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of IO CONTROL pinout group C and D
 *
 * \ingroup io_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  io_ctrl_s_odd_bf bf;  ///< bit field representation
} io_ctrl_s_odd_t;


/* IO_CTRL_SWD_HV */

#define MSK_IO_CTRL_SWD_HV                                  (0x3)     /* [ 1:0] */

typedef unsigned short io_ctrl_swd_hv_t;                              /* [ 1:0] */


/* IO_CTRL_JTAG_DIO */

#define MSK_IO_CTRL_JTAG_DIO                                (0x1)     /* [0] */

typedef unsigned short io_ctrl_jtag_dio_t;                            /* [0] */


/* IO_CTRL_EL_RX */

#define MSK_IO_CTRL_EL_RX_EL_RX_SEL                         (0x1)     /* [0] */
#define RES_IO_CTRL_EL_RX_EL_RX_SEL                         (0x0)
#define SFT_IO_CTRL_EL_RX_EL_RX_SEL                         (0)
#define LSB_IO_CTRL_EL_RX_EL_RX_SEL                         (0)
#define MSB_IO_CTRL_EL_RX_EL_RX_SEL                         (0)
#define BIT_IO_CTRL_EL_RX_EL_RX_SEL                         (0x1)     /* [0] */
#define MSK_IO_CTRL_EL_RX_EL_RX_DS                          (0x1)     /* [1] */
#define RES_IO_CTRL_EL_RX_EL_RX_DS                          (0x0)
#define SFT_IO_CTRL_EL_RX_EL_RX_DS                          (1)
#define LSB_IO_CTRL_EL_RX_EL_RX_DS                          (1)
#define MSB_IO_CTRL_EL_RX_EL_RX_DS                          (1)
#define BIT_IO_CTRL_EL_RX_EL_RX_DS                          (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes IO CONTROL Electronics Label receiver
 *
 * \ingroup io_ctrl 
 */ 
typedef struct {
  /**
   * 0: internal EL_TIA is used <br>
   * 1: external TIA can be used (through IOMUX)
   */ 
  unsigned short el_rx_sel                     :    1;       /* [0] */
  /**
   * Drive strength select of EL_RX pin
   */ 
  unsigned short el_rx_ds                      :    1;       /* [1] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   14;
} io_ctrl_el_rx_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of IO CONTROL Electronics Label receiver
 *
 * \ingroup io_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  io_ctrl_el_rx_bf bf;  ///< bit field representation
} io_ctrl_el_rx_t;



// Register definitions for module
// Instance base address BASE_ADDR_IO_CTRL 0x40006680U ... 

#define ADDR_IO_CTRL_GUARD                                   (0x00U)
#define A_IO_CTRL_GUARD(ba)                                  ((ba) + ADDR_IO_CTRL_GUARD)
#define R_IO_CTRL_GUARD(ba)                                  (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_GUARD(ba)))
#define RES_IO_CTRL_GUARD                                    (0x0U)
#define MSB_IO_CTRL_GUARD                                    7
#define LSB_IO_CTRL_GUARD                                    0
#define AADDR_IO_CTRL_GUARD                                  (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_GUARD)
#define REG_IO_CTRL_GUARD                                    (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_GUARD))

#define ADDR_IO_CTRL_S00                                     (0x02U)
#define A_IO_CTRL_S00(ba)                                    ((ba) + ADDR_IO_CTRL_S00)
#define R_IO_CTRL_S00(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S00(ba)))
#define RES_IO_CTRL_S00                                      (0x0U)
#define MSB_IO_CTRL_S00                                      15
#define LSB_IO_CTRL_S00                                      0
#define AADDR_IO_CTRL_S00                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S00)
#define REG_IO_CTRL_S00                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S00))

#define ADDR_IO_CTRL_S01                                     (0x04U)
#define A_IO_CTRL_S01(ba)                                    ((ba) + ADDR_IO_CTRL_S01)
#define R_IO_CTRL_S01(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S01(ba)))
#define RES_IO_CTRL_S01                                      (0x0U)
#define MSB_IO_CTRL_S01                                      15
#define LSB_IO_CTRL_S01                                      0
#define AADDR_IO_CTRL_S01                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S01)
#define REG_IO_CTRL_S01                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S01))

#define ADDR_IO_CTRL_S02                                     (0x06U)
#define A_IO_CTRL_S02(ba)                                    ((ba) + ADDR_IO_CTRL_S02)
#define R_IO_CTRL_S02(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S02(ba)))
#define RES_IO_CTRL_S02                                      (0x0U)
#define MSB_IO_CTRL_S02                                      15
#define LSB_IO_CTRL_S02                                      0
#define AADDR_IO_CTRL_S02                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S02)
#define REG_IO_CTRL_S02                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S02))

#define ADDR_IO_CTRL_S03                                     (0x08U)
#define A_IO_CTRL_S03(ba)                                    ((ba) + ADDR_IO_CTRL_S03)
#define R_IO_CTRL_S03(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S03(ba)))
#define RES_IO_CTRL_S03                                      (0x0U)
#define MSB_IO_CTRL_S03                                      15
#define LSB_IO_CTRL_S03                                      0
#define AADDR_IO_CTRL_S03                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S03)
#define REG_IO_CTRL_S03                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S03))

#define ADDR_IO_CTRL_S04                                     (0x0AU)
#define A_IO_CTRL_S04(ba)                                    ((ba) + ADDR_IO_CTRL_S04)
#define R_IO_CTRL_S04(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S04(ba)))
#define RES_IO_CTRL_S04                                      (0x0U)
#define MSB_IO_CTRL_S04                                      15
#define LSB_IO_CTRL_S04                                      0
#define AADDR_IO_CTRL_S04                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S04)
#define REG_IO_CTRL_S04                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S04))

#define ADDR_IO_CTRL_S05                                     (0x0CU)
#define A_IO_CTRL_S05(ba)                                    ((ba) + ADDR_IO_CTRL_S05)
#define R_IO_CTRL_S05(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S05(ba)))
#define RES_IO_CTRL_S05                                      (0x0U)
#define MSB_IO_CTRL_S05                                      15
#define LSB_IO_CTRL_S05                                      0
#define AADDR_IO_CTRL_S05                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S05)
#define REG_IO_CTRL_S05                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S05))

#define ADDR_IO_CTRL_S06                                     (0x0EU)
#define A_IO_CTRL_S06(ba)                                    ((ba) + ADDR_IO_CTRL_S06)
#define R_IO_CTRL_S06(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S06(ba)))
#define RES_IO_CTRL_S06                                      (0x0U)
#define MSB_IO_CTRL_S06                                      15
#define LSB_IO_CTRL_S06                                      0
#define AADDR_IO_CTRL_S06                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S06)
#define REG_IO_CTRL_S06                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S06))

#define ADDR_IO_CTRL_S07                                     (0x10U)
#define A_IO_CTRL_S07(ba)                                    ((ba) + ADDR_IO_CTRL_S07)
#define R_IO_CTRL_S07(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S07(ba)))
#define RES_IO_CTRL_S07                                      (0x0U)
#define MSB_IO_CTRL_S07                                      15
#define LSB_IO_CTRL_S07                                      0
#define AADDR_IO_CTRL_S07                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S07)
#define REG_IO_CTRL_S07                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S07))

#define ADDR_IO_CTRL_S08                                     (0x12U)
#define A_IO_CTRL_S08(ba)                                    ((ba) + ADDR_IO_CTRL_S08)
#define R_IO_CTRL_S08(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S08(ba)))
#define RES_IO_CTRL_S08                                      (0x0U)
#define MSB_IO_CTRL_S08                                      15
#define LSB_IO_CTRL_S08                                      0
#define AADDR_IO_CTRL_S08                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S08)
#define REG_IO_CTRL_S08                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S08))

#define ADDR_IO_CTRL_S09                                     (0x14U)
#define A_IO_CTRL_S09(ba)                                    ((ba) + ADDR_IO_CTRL_S09)
#define R_IO_CTRL_S09(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S09(ba)))
#define RES_IO_CTRL_S09                                      (0x0U)
#define MSB_IO_CTRL_S09                                      15
#define LSB_IO_CTRL_S09                                      0
#define AADDR_IO_CTRL_S09                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S09)
#define REG_IO_CTRL_S09                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S09))

#define ADDR_IO_CTRL_S10                                     (0x16U)
#define A_IO_CTRL_S10(ba)                                    ((ba) + ADDR_IO_CTRL_S10)
#define R_IO_CTRL_S10(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S10(ba)))
#define RES_IO_CTRL_S10                                      (0x0U)
#define MSB_IO_CTRL_S10                                      15
#define LSB_IO_CTRL_S10                                      0
#define AADDR_IO_CTRL_S10                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S10)
#define REG_IO_CTRL_S10                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S10))

#define ADDR_IO_CTRL_S11                                     (0x18U)
#define A_IO_CTRL_S11(ba)                                    ((ba) + ADDR_IO_CTRL_S11)
#define R_IO_CTRL_S11(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S11(ba)))
#define RES_IO_CTRL_S11                                      (0x0U)
#define MSB_IO_CTRL_S11                                      15
#define LSB_IO_CTRL_S11                                      0
#define AADDR_IO_CTRL_S11                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S11)
#define REG_IO_CTRL_S11                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S11))

#define ADDR_IO_CTRL_S12                                     (0x1AU)
#define A_IO_CTRL_S12(ba)                                    ((ba) + ADDR_IO_CTRL_S12)
#define R_IO_CTRL_S12(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S12(ba)))
#define RES_IO_CTRL_S12                                      (0x0U)
#define MSB_IO_CTRL_S12                                      15
#define LSB_IO_CTRL_S12                                      0
#define AADDR_IO_CTRL_S12                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S12)
#define REG_IO_CTRL_S12                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S12))

#define ADDR_IO_CTRL_S13                                     (0x1CU)
#define A_IO_CTRL_S13(ba)                                    ((ba) + ADDR_IO_CTRL_S13)
#define R_IO_CTRL_S13(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S13(ba)))
#define RES_IO_CTRL_S13                                      (0x0U)
#define MSB_IO_CTRL_S13                                      15
#define LSB_IO_CTRL_S13                                      0
#define AADDR_IO_CTRL_S13                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S13)
#define REG_IO_CTRL_S13                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S13))

#define ADDR_IO_CTRL_S14                                     (0x1EU)
#define A_IO_CTRL_S14(ba)                                    ((ba) + ADDR_IO_CTRL_S14)
#define R_IO_CTRL_S14(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S14(ba)))
#define RES_IO_CTRL_S14                                      (0x0U)
#define MSB_IO_CTRL_S14                                      15
#define LSB_IO_CTRL_S14                                      0
#define AADDR_IO_CTRL_S14                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S14)
#define REG_IO_CTRL_S14                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S14))

#define ADDR_IO_CTRL_S15                                     (0x20U)
#define A_IO_CTRL_S15(ba)                                    ((ba) + ADDR_IO_CTRL_S15)
#define R_IO_CTRL_S15(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S15(ba)))
#define RES_IO_CTRL_S15                                      (0x0U)
#define MSB_IO_CTRL_S15                                      15
#define LSB_IO_CTRL_S15                                      0
#define AADDR_IO_CTRL_S15                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S15)
#define REG_IO_CTRL_S15                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S15))

#define ADDR_IO_CTRL_S16                                     (0x22U)
#define A_IO_CTRL_S16(ba)                                    ((ba) + ADDR_IO_CTRL_S16)
#define R_IO_CTRL_S16(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S16(ba)))
#define RES_IO_CTRL_S16                                      (0x0U)
#define MSB_IO_CTRL_S16                                      15
#define LSB_IO_CTRL_S16                                      0
#define AADDR_IO_CTRL_S16                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S16)
#define REG_IO_CTRL_S16                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S16))

#define ADDR_IO_CTRL_S17                                     (0x24U)
#define A_IO_CTRL_S17(ba)                                    ((ba) + ADDR_IO_CTRL_S17)
#define R_IO_CTRL_S17(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S17(ba)))
#define RES_IO_CTRL_S17                                      (0x0U)
#define MSB_IO_CTRL_S17                                      15
#define LSB_IO_CTRL_S17                                      0
#define AADDR_IO_CTRL_S17                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S17)
#define REG_IO_CTRL_S17                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S17))

#define ADDR_IO_CTRL_S19                                     (0x28U)
#define A_IO_CTRL_S19(ba)                                    ((ba) + ADDR_IO_CTRL_S19)
#define R_IO_CTRL_S19(ba)                                    (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_S19(ba)))
#define RES_IO_CTRL_S19                                      (0x0U)
#define MSB_IO_CTRL_S19                                      15
#define LSB_IO_CTRL_S19                                      0
#define AADDR_IO_CTRL_S19                                    (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_S19)
#define REG_IO_CTRL_S19                                      (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_S19))

#define ADDR_IO_CTRL_SWD_HV                                  (0x2AU)
#define A_IO_CTRL_SWD_HV(ba)                                 ((ba) + ADDR_IO_CTRL_SWD_HV)
#define R_IO_CTRL_SWD_HV(ba)                                 (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_SWD_HV(ba)))
#define RES_IO_CTRL_SWD_HV                                   (0x0U)
#define MSB_IO_CTRL_SWD_HV                                   1
#define LSB_IO_CTRL_SWD_HV                                   0
#define AADDR_IO_CTRL_SWD_HV                                 (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_SWD_HV)
#define REG_IO_CTRL_SWD_HV                                   (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_SWD_HV))

#define ADDR_IO_CTRL_JTAG_DIO                                (0x2CU)
#define A_IO_CTRL_JTAG_DIO(ba)                               ((ba) + ADDR_IO_CTRL_JTAG_DIO)
#define R_IO_CTRL_JTAG_DIO(ba)                               (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_JTAG_DIO(ba)))
#define RES_IO_CTRL_JTAG_DIO                                 (0x0U)
#define MSB_IO_CTRL_JTAG_DIO                                 0
#define LSB_IO_CTRL_JTAG_DIO                                 0
#define AADDR_IO_CTRL_JTAG_DIO                               (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_JTAG_DIO)
#define REG_IO_CTRL_JTAG_DIO                                 (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_JTAG_DIO))

#define ADDR_IO_CTRL_EL_RX                                   (0x2EU)
#define A_IO_CTRL_EL_RX(ba)                                  ((ba) + ADDR_IO_CTRL_EL_RX)
#define R_IO_CTRL_EL_RX(ba)                                  (*(volatile unsigned short *)((unsigned int)A_IO_CTRL_EL_RX(ba)))
#define RES_IO_CTRL_EL_RX                                    (0x0U)
#define MSB_IO_CTRL_EL_RX                                    1
#define LSB_IO_CTRL_EL_RX                                    0
#define AADDR_IO_CTRL_EL_RX                                  (BASE_ADDR_IO_CTRL + ADDR_IO_CTRL_EL_RX)
#define REG_IO_CTRL_EL_RX                                    (*(volatile unsigned short *)((unsigned int)AADDR_IO_CTRL_EL_RX))




#endif
