  
#include "io_ctrl_api.h"
#include "device_settings.h"
#include "hv_ctrl_api.h"

#include "logger.h"

//#include "usi.h"
//#include "usi_uart.h"

#include <usi_uart_dma.h>



static usi_num_t g_rs485_usi = USI0;

static usi_uart_bit_order_t g_msb_first = USI_UART_LSB_FIRST;
static usi_uart_data_len_t g_data_bits  = USI_UART_DATA_LEN_8;
static usi_uart_stop_bit_t g_stop_bits  = USI_UART_ONE_STOP;
static usi_uart_parity_t g_par_type     = USI_UART_PARITY_EVEN;
static uint32_t g_cfg_rx_timeout        = 0; // 0 -> time out disable




/* ########################################################################## */  
errors_api_code_e rs485_api_ext_phy_init_pad(
                    const usi_num_t usi_no,
                    device_pinout pinout_usi_txen,
                    device_pinout pinout_usi_tx,
                    device_pinout pinout_usi_rx) {
    
  g_rs485_usi = usi_no;
                          
  errors_api_code_e error_code = eError_none;
  
  switch(g_rs485_usi) {
  case USI0:  
    error_code |= io_ctrl_api_set_sel_func(pinout_usi_txen, USI0_NSS);
    error_code |= io_ctrl_api_set_sel_func(pinout_usi_tx, USI0_SDO_TX);
    error_code |= io_ctrl_api_set_sel_func(pinout_usi_rx, USI0_SDI_RX);  
    break;
    
  case USI1:  
    error_code |= io_ctrl_api_set_sel_func(pinout_usi_txen, USI1_NSS);
    error_code |= io_ctrl_api_set_sel_func(pinout_usi_tx, USI1_SDO_TX);
    error_code |= io_ctrl_api_set_sel_func(pinout_usi_rx, USI1_SDI_RX);  
    break;
  default:
    error_code |= eError_unknown;
  }
  return(error_code);
}  



/* ########################################################################## */  
errors_api_code_e rs485_api_int_phy_init_pad(
                    const usi_num_t usi_no,
                    device_pinout pinout_hv_rs485_txen, device_pinout pinout_usi_txen,
                    device_pinout pinout_hv_rs485_tx,   device_pinout pinout_usi_tx,
                    device_pinout pinout_hv_rs485_rx,   device_pinout pinout_usi_rx) {
    
  errors_api_code_e error_code = eError_none;
  
  /* assign pins */
  error_code = io_ctrl_api_rs485_hv_ctrl_pins(pinout_hv_rs485_txen, pinout_hv_rs485_tx, pinout_hv_rs485_rx);
  
  /* enable RS485 */
  hv_ctrl_api_rs485_enable(false);
  
  error_code |= rs485_api_ext_phy_init_pad(usi_no, pinout_usi_txen, pinout_usi_tx, pinout_usi_rx);
    
  return(error_code);
}  



    
/* ########################################################################## */  
void rs485_api_usi_uart_set_msb_first(usi_uart_bit_order_t par_msb_first) {
  g_msb_first = par_msb_first;
}

/* ########################################################################## */  
void rs485_api_usi_uart_set_data_bits(usi_uart_data_len_t par_data_bits) {
  g_data_bits = par_data_bits;
}

/* ########################################################################## */  
void rs485_api_usi_uart_set_stopbit(usi_uart_stop_bit_t par_stop_bits) {
  g_stop_bits = par_stop_bits;
}

/* ########################################################################## */  
void rs485_api_usi_uart_set_parity(usi_uart_parity_t par_par_type) {
  g_par_type = par_par_type;
}

/* ########################################################################## */  
void rs485_api_usi_uart_set_rx_timeout(uint32_t par_rx_timeout) {
  g_cfg_rx_timeout = par_rx_timeout;
}



/* ########################################################################## */  
errors_api_code_e rs485_api_usi_uart_clock_and_baudrate(clock_source_t par_clock_source, uint8_t par_as_clk_div, uint16_t par_br_mod, uint16_t par_br_inc, uint16_t par_bit_length) {

  errors_api_code_e error_code = eError_none;
  
  error_code |= usi_uart_dma_clock(g_rs485_usi, par_clock_source, par_as_clk_div);
  
  usi_uart_dma_baudrate(g_rs485_usi, par_br_mod, par_br_inc, par_bit_length);

  return(error_code);
}

/* ########################################################################## */  
void rs485_api_usi_uart_autobaudrate_set(usi_bre_mode_t eMode) {
  usi_uart_dma_autobaudrate_set(g_rs485_usi, eMode);
}

/* ########################################################################## */  
bool rs485_api_usi_uart_autobaudrate_get(uint32_t *p_baudrate) {  
  return(usi_uart_dma_autobaudrate_get(g_rs485_usi, p_baudrate));
}
                    

/* ########################################################################## */  
void rs485_api_usi_uart_init(void) {

  
  /* Half-Duplex */
  usi_cfg_u_half_duplex_t i_hlf_dplx_cfg;
  
  /* This will disable the reception of any data word with their start bit during the own transmission time */
  i_hlf_dplx_cfg.bf.echo_cancel = 1; 
  
  /* nss controlled by USI: asserted during transmit */
  /* 
   *  0: assert nss (0 when not inverted)
   *  1: deassert nss
   *  2: nss controlled by USI: asserted during transmit
   */
  i_hlf_dplx_cfg.bf.nss_mode = 2;
  
  /* number of bit times nss respectively sdo_oe is asserted after transmission of last stop bit */
  i_hlf_dplx_cfg.bf.sdo_drv_post = 3;
  
  /* number of bit times nss respectively sdo_oe is asserted before leading edge of start bit */
  i_hlf_dplx_cfg.bf.sdo_drv_pre = 3;
  
  /* 0: assert sdo_oe / 1: sdo_oe controlled by USI: asserted during transmit */
  i_hlf_dplx_cfg.bf.sdo_mode = 1;
      
  usi_uart_cfg_half_duplex(g_rs485_usi, i_hlf_dplx_cfg); 
  
 
  
  usi_uart_dma_init(g_rs485_usi, g_msb_first, g_data_bits, g_stop_bits , g_par_type, g_cfg_rx_timeout);

  debug_api("USI%u:UART initialized\n", usi_no_to_index(g_rs485_usi));
}



/* ########################################################################## */  
errors_api_code_e rs485_api_data_send(uint8_t par_number_of_data, void * par_p_snd_data) {
  debug_api("USI%u:UART:data_send:buffer prepared\n", usi_no_to_index(g_rs485_usi));
  return(usi_uart_dma_tx(g_rs485_usi, par_number_of_data, par_p_snd_data));
}



/* ########################################################################## */  
errors_api_code_e rs485_api_data_recv(uint8_t par_number_of_data, void * par_p_rcv_data) {
  debug_api("USI%u:UART:data_recv:buffer prepared\n", usi_no_to_index(g_rs485_usi));
  return(usi_uart_dma_rx(g_rs485_usi, par_number_of_data, par_p_rcv_data));
}



/* ########################################################################## */  
void rs485_api_reg_callback(uint8_t par_usi_nvic_priority, void (*p_fce_callback_rx_done)(void), void (*p_fce_callback_error)(void), void (*p_fce_callback_tadr_new)(void)) {
  usi_uart_dma_reg_callback(g_rs485_usi, par_usi_nvic_priority,p_fce_callback_rx_done, p_fce_callback_error, p_fce_callback_tadr_new);
}


/* ########################################################################## */  
void rs485_api_irq_data_recv_done(bool par_enable) {
  usi_enable_irq(g_rs485_usi, USI_IRQ_REVENTS_0, par_enable);
}

/* ########################################################################## */  
void rs485_api_irq_data_send_ready(bool par_enable) {
  usi_enable_irq(g_rs485_usi, USI_IRQ_TADR_NEW_NFULL, par_enable);
}

/* ########################################################################## */  
uint16_t rs485_api_usi_data_rdlen_get(void) {
  return(usi_uart_dma_rdlen_get(g_rs485_usi));
}

/* ########################################################################## */  
void rs485_api_usi_uart_dma_autobaudrate_limits_set(uint32_t m_dwLowLimit, uint32_t m_dwHighLimit) {
  usi_uart_dma_autobaudrate_limits_set(g_rs485_usi, m_dwLowLimit, m_dwHighLimit);
}