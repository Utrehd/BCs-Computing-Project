#include <hardware.h>
#include <usi_uart_dma.h>
#include <errors_api.h>

#include <clk_nres_api.h>
#include <limits.h>
#include <logger.h>
#include <utils.h>

#define BUG_5473_FIX
#define USI_DMA_FIFO_LENGTH 2

static volatile uint8_t g_usi_tx_fifo=0;
static volatile uint8_t g_usi_rx_fifo=0;

/* ########################################################################## */    
static void (*ptr_fce_usi_callback_tadr_new[NUMBER_USI])(void);
static void (*ptr_fce_usi_callback_rx_done[NUMBER_USI])(void);
static void (*ptr_fce_usi_callback_error[NUMBER_USI])(void);

/* ########################################################################## */  
typedef struct {
  volatile usi_dma_rxcfg_t rx_config; ///< data structure for receive data for USI DMA
  volatile usi_dma_txcfg_t tx_config; ///< data structure for transmit data for USI DMA
} usi_wrp_struct_t;

/* ########################################################################## */  
static volatile usi_wrp_struct_t glob_usi_wrp_struct[NUMBER_USI][USI_DMA_FIFO_LENGTH];
static volatile bool glob_usi_wrp_struct_lock[NUMBER_USI][USI_DMA_FIFO_LENGTH];


/* ########################################################################## */  
typedef struct {
  volatile uint32_t result;
  volatile uint8_t  cnt;
  uint32_t low_limit;
  uint32_t high_limit;
} bit_rate_extraction_t;


typedef struct {
  uint32_t low_limit;
  uint32_t high_limit;
} baudrate_limits_t ;
  
#ifdef USI_UART_AUTOBAUDRATE_DETECTION_USED  
  static bit_rate_extraction_t g_bre[NUMBER_USI];
  static baudrate_limits_t gnBaudrateLimit[NUMBER_USI];

  static uint32_t g_comm_clock_freq;
#endif  

/* ########################################################################## */    
/*
 * This interrupt routine will work only with UART
 */
void usi_uart_dma_interrupt_subroutine(usi_num_t eUSIno ) {

  uint8_t cuUsiIndex;
#ifdef USI_UART_AUTOBAUDRATE_DETECTION_USED
  uint32_t i_bre_res;
#endif  
      
  cuUsiIndex = usi_no_to_index(eUSIno);
  
  usi_irq_t irq = usi_get_next_pending_irq(eUSIno);
  switch(irq) {

  case USI_IRQ_REVENTS_1: //uart: 1: start bit error
  case USI_IRQ_REVENTS_2: //uart: 1: parity error
  case USI_IRQ_REVENTS_3: //uart: 1: stop bit error
  case USI_IRQ_REVENTS_4: //uart: 1: break occurred
  case USI_IRQ_RADR_NEW_UDR:
    if(ptr_fce_usi_callback_error[cuUsiIndex]!=NULL) {
      /* run callback */
       ptr_fce_usi_callback_error[cuUsiIndex]();
    }
    usi_clear_revents(eUSIno);
    break;

  case USI_IRQ_BRE_UPDATED:
#ifdef USI_UART_AUTOBAUDRATE_DETECTION_USED
    //if(g_bre[cuUsiIndex].cnt<(UCHAR_MAX-1)) {
      i_bre_res = usi_get_bre_res(eUSIno);
  
      if(!(utils_cmp_in_range(g_bre[cuUsiIndex].low_limit, i_bre_res, g_bre[cuUsiIndex].high_limit))) {
        break;
      }

      if(utils_cmp_in_percentage(i_bre_res, g_bre[cuUsiIndex].result, USI_UART_AUTOBAUDRATE_DETECTION_PERCENTAGE)){
        g_bre[cuUsiIndex].cnt++;
      }
      g_bre[cuUsiIndex].result=MIN(g_bre[cuUsiIndex].result , i_bre_res); 
      
      do {
        i_bre_res = usi_get_bre_res(eUSIno);
      } while(i_bre_res != 0xFFFFFFFFu);
    //}
#endif      
    break;
    
  case USI_IRQ_TADR_NEW_NFULL:
    if(ptr_fce_usi_callback_tadr_new[cuUsiIndex]!=NULL) {
      /* run callback */
      ptr_fce_usi_callback_tadr_new[cuUsiIndex]();
    }
    
  case USI_IRQ_TADR_DONE_NEMPTY:
    /* transmit done */
    usi_dma_get_tadr_done(eUSIno);
    break;


  case USI_IRQ_REVENTS_0: //uart: 1: receive timeout ended frame  
  case USI_IRQ_RADR_DONE_NEMPTY:
    /* read done */
    usi_dma_get_radr_done(eUSIno);

    /* unlock */
    glob_usi_wrp_struct_lock[cuUsiIndex][g_usi_rx_fifo]=false;

    if(ptr_fce_usi_callback_rx_done[cuUsiIndex]!=NULL) {
      /* run callback */
      ptr_fce_usi_callback_rx_done[cuUsiIndex]();
    }
    break;
    

  default:
    break;
  }
  usi_clear_irq(eUSIno, irq);
}

/* ########################################################################## */  
void usi_uart_dma_baudrate(const usi_num_t eUSIno, uint16_t par_br_mod, uint16_t par_br_inc, uint16_t par_bit_length)
{
  usi_full_enable(eUSIno, false); // RX, TX disable to be able change config
 
  usi_cfg_br_mod(eUSIno, par_br_mod);
  usi_cfg_br_inc(eUSIno, par_br_inc);
  usi_uart_cfg_bit_length(eUSIno, par_bit_length);
  
  /* SAMPLING WINDOW */
  usi_uart_cfg_data_sampling(eUSIno, par_bit_length/3, par_bit_length/3);
  
  /* dedicated start bit filter extracts the position of the leading edge in the presence of noise */
  /* The threshold should be configured to about 0.7 bit times */
  usi_uart_cfg_start_threshold(eUSIno, (uint16_t)(par_bit_length * 0.7));
  
}

/* ########################################################################## */  
errors_api_code_e usi_uart_dma_clock(const usi_num_t eUSIno, clock_source_t par_clock_source, uint8_t par_as_clk_div) {

  clkpno_t i_clkpno;
  clk_domain_t i_as_clkpno;
  errors_api_code_e i_error_code = eError_none;
  
  switch(eUSIno) {
    case USI0: 
      i_clkpno = CLKPNO_USI0; 
      i_as_clkpno = AS_USI0;
      break;
      
    case USI1: 
      i_clkpno = CLKPNO_USI1; 
      i_as_clkpno = AS_USI1;
      break;
      
    default: 
      i_error_code |= e_error_usi_uart_dma_wrong_instance;
      return(i_error_code);
  }

  /* CLK_NRES setup */
  wdog_unlock_guard(GUARD0);
  clk_nres_unlock();  
    /* assert reset */
    clk_nres_set_as_nreset(i_as_clkpno, false);
    clk_nres_set_nreset(i_clkpno, false);

    /* clock */
    clk_nres_set_clk_divider(i_as_clkpno, par_as_clk_div);
    clk_nres_sel_clk_root(i_as_clkpno, par_clock_source);
    clk_nres_enable_as_clock_domain(CLK_NRES_0, i_as_clkpno, true);
    clk_nres_enable_clock_partition(CLK_NRES_0, i_clkpno, true);
        
    /* release reset */
    clk_nres_set_as_nreset(i_as_clkpno, true);
    clk_nres_set_nreset(i_clkpno, true);
    
  wdog_disable (GUARD0); // GUARD disable
  while (wdog_is_running (GUARD0)); 
#ifdef USI_UART_AUTOBAUDRATE_DETECTION_USED  
  i_error_code |= clk_nres_api_get_as_clock(i_as_clkpno, &g_comm_clock_freq);

  if(g_comm_clock_freq==0) {
    error("comm clock freq is not known!");
    while(1);
  }
  
  g_bre[eUSIno].low_limit = ((g_comm_clock_freq) / (gnBaudrateLimit[eUSIno].low_limit));
  g_bre[eUSIno].high_limit = ((g_comm_clock_freq) / (gnBaudrateLimit[eUSIno].high_limit));
#endif  
  return(i_error_code);   
}


/* ########################################################################## */  
void usi_uart_dma_init(const usi_num_t eUSIno, usi_uart_bit_order_t par_msb_first, const usi_uart_data_len_t par_data_bits, const usi_uart_stop_bit_t par_stop_bits , const usi_uart_parity_t par_par_type, uint32_t par_cfg_rx_timeout) {

  usi_irq_set_spi_Nuart(eUSIno, USI_MODE_UART);
  usi_full_enable(eUSIno, false); // RX, TX disable to be able change config
  usi_cfg_mode(eUSIno, false); // UART

  
  // usi_set_bre_mode(eUSIno, USI_BRE_OFF);
  
  usi_dma_cfg_rx_timeout(eUSIno, par_cfg_rx_timeout); 
  
  usi_uart_cfg_msb_first(eUSIno, par_msb_first);
  usi_uart_cfg_data_bits(eUSIno, par_data_bits);
  usi_uart_cfg_stop_bits(eUSIno, par_stop_bits);
  
  usi_uart_cfg_parity(eUSIno, par_par_type);
 
  usi_full_enable(eUSIno, true); // RX, TX enable to be able change config
  
  usi_clear_revents(eUSIno);
  
#ifdef USI_UART_AUTOBAUDRATE_DETECTION_USED    
  g_bre[usi_no_to_index(eUSIno)].result = USHRT_MAX;
  g_bre[usi_no_to_index(eUSIno)].cnt = 0;
//  g_bre[usi_no_to_index(eUSIno)].low_limit = 0;
//  g_bre[usi_no_to_index(eUSIno)].high_limit = ULONG_MAX;
#endif  
}

/* ########################################################################## */  
errors_api_code_e usi_uart_dma_tx(usi_num_t eUSIno, uint8_t par_number_of_data, void * par_p_snd_data) {

  uint8_t cuUsiIndex;
  
  cuUsiIndex = usi_no_to_index(eUSIno);
    
  /* pointer to the done data structure (output of pointer fifo) */
  usi_dma_get_tadr_done(eUSIno);
  
  /* TX */
  if (usi_tadr_new_is_nfull(eUSIno)) {  
    glob_usi_wrp_struct[cuUsiIndex][g_usi_tx_fifo].tx_config.tcfg = 0; /* do not send break */
    glob_usi_wrp_struct[cuUsiIndex][g_usi_tx_fifo].tx_config.tdadr = (uint16_t)(0x0000FFFF & POINTER_TO_ADDRESS(par_p_snd_data));
    glob_usi_wrp_struct[cuUsiIndex][g_usi_tx_fifo].tx_config.tdlen = par_number_of_data;

    usi_dma_set_tadr_new(eUSIno, 0x0000FFFF&(POINTER_TO_ADDRESS(&(glob_usi_wrp_struct[cuUsiIndex][g_usi_tx_fifo].tx_config))));
    g_usi_tx_fifo=((g_usi_tx_fifo+1)%USI_DMA_FIFO_LENGTH);
  }
  else {
    /* USI DMA FIFO overloaded */
    return(e_error_usi_uart_dma_tx_fifo_overloaded);
  }
  return(eError_none);   
}

/* ########################################################################## */  
errors_api_code_e usi_uart_dma_rx(usi_num_t eUSIno, uint8_t par_number_of_data, void * par_p_rcv_data) {

  uint8_t cuUsiIndex;
  
  cuUsiIndex = usi_no_to_index(eUSIno);
  
  /* pointer to the done data structure (output of pointer fifo) */
  usi_dma_get_radr_done(eUSIno);


  /* Fill in DMAs */
  /* RX */
  if (usi_radr_new_is_nfull(eUSIno)) {
    glob_usi_wrp_struct[cuUsiIndex][g_usi_rx_fifo].rx_config.maxlen = par_number_of_data;
    glob_usi_wrp_struct[cuUsiIndex][g_usi_rx_fifo].rx_config.rdadr = (uint16_t)(0x0000FFFF & POINTER_TO_ADDRESS(par_p_rcv_data));
    glob_usi_wrp_struct[cuUsiIndex][g_usi_rx_fifo].rx_config.rdlen = 0; /* JUST CLEAR - NO FUNCTIONALITY */

    usi_dma_set_radr_new(eUSIno, 0x0000FFFF&(POINTER_TO_ADDRESS(&(glob_usi_wrp_struct[cuUsiIndex][g_usi_rx_fifo].rx_config))));
    g_usi_rx_fifo=((g_usi_rx_fifo+1)%USI_DMA_FIFO_LENGTH);
  }
  else {
    // USI DMA FIFO overloaded 
    return(e_error_usi_uart_dma_rx_fifo_overloaded);
  }
  return(eError_none);   
}

/* ########################################################################## */  
void usi_uart_dma_reg_callback(usi_num_t eUSIno, uint8_t par_usi_nvic_priority, void (*p_fce_callback_rx_done)(void), void (*p_fce_callback_error)(void), void (*p_fce_callback_tadr_new)(void)) {

  uint8_t cuUsiIndex;
  IRQn_Type i_IRQn;
  
  switch(eUSIno) {
    case USI0: 
      cuUsiIndex = 0;
      i_IRQn = IRQ_USI0;
      break;
      
    case USI1: 
      cuUsiIndex = 1;
      i_IRQn = IRQ_USI1;
      break;
      
    default: 
      /* ERROR */
      return; 
  }  
  
  /* register callbacks */
  ptr_fce_usi_callback_tadr_new[cuUsiIndex]=p_fce_callback_tadr_new;
  ptr_fce_usi_callback_rx_done[cuUsiIndex]=p_fce_callback_rx_done;
  ptr_fce_usi_callback_error[cuUsiIndex]=p_fce_callback_error;
  
  /* NVIC Interrupt */
  NVIC_SetPriority(i_IRQn, par_usi_nvic_priority);
  NVIC_EnableIRQ(i_IRQn);
}

/* ########################################################################## */  
uint16_t usi_uart_dma_rdlen_get(usi_num_t eUSIno) {
  usi_dma_rxcfg_t *i_rx_config;
  
  i_rx_config = (usi_dma_rxcfg_t *)(BASE_ADDR_SRAM | usi_dma_get_radr_current(eUSIno));
  
  return(i_rx_config->rdlen);
}

/* ########################################################################## */  
void usi_uart_dma_autobaudrate_set(usi_num_t eUSIno, usi_bre_mode_t eMode) {
#ifdef USI_UART_AUTOBAUDRATE_DETECTION_USED  
  bool bEnable=true;
  
  usi_set_bre_mode(eUSIno, eMode);
  

  if(eMode==USI_BRE_MIN) {
    /* To clear BRE_RES (needed in mode 4) */
    usi_get_bre_res(eUSIno);
  }  
  
  if(eMode==USI_BRE_OFF) {
    bEnable=false;
  }
  
  usi_enable_irq(eUSIno, USI_IRQ_BRE_UPDATED, bEnable);    
#endif  
}

/* ########################################################################## */  
void usi_uart_dma_autobaudrate_limits_set(usi_num_t eUSIno, uint32_t m_dwLowLimit, uint32_t m_dwHighLimit) {
#ifdef USI_UART_AUTOBAUDRATE_DETECTION_USED  
  uint8_t cuUsiIndex=usi_no_to_index(eUSIno);
  gnBaudrateLimit[cuUsiIndex].low_limit=m_dwLowLimit;
  gnBaudrateLimit[cuUsiIndex].high_limit=m_dwHighLimit;
#endif  
}

/* ########################################################################## */  
bool usi_uart_dma_autobaudrate_get(usi_num_t eUSIno, uint32_t *p_baudrate) {
#ifdef USI_UART_AUTOBAUDRATE_DETECTION_USED  
  uint8_t cuUsiIndex=usi_no_to_index(eUSIno);
  if(g_bre[cuUsiIndex].cnt>5) {
    //debug_api("BR CNT: %u\n",g_bre[cuUsiIndex].cnt);
    //debug_api("BR RESULT: %u\n",g_bre[cuUsiIndex].result);
    
     *p_baudrate = ((g_comm_clock_freq) / (g_bre[cuUsiIndex].result));
     g_bre[cuUsiIndex].result=USHRT_MAX;
     g_bre[cuUsiIndex].cnt=0;
     return(true);
  }
  else {
    return(false);
  }
#endif  
  return(false);
}
