#include "hardware.h"
#include "clk_nres_api.h"
#include "errors_api.h"

/* ############################################################################ */
errors_api_code_e flash_ctrl_api_set_timings(void) {

  uint32_t i_system_clock;
  errors_api_code_e i_error_code;
  
  
  i_error_code = clk_nres_api_get_system_clock(&i_system_clock);
  if (i_error_code == eError_none)
  {
    
    if (i_system_clock >= 16.5e6) 
    {
      flash_ctrl_use_half_clock_speed(true);
    }
    else {
      flash_ctrl_use_half_clock_speed(false);
    }
    
    WRITE_REG_16(AADDR_FLASH_CTRL0_TNVS_TNVH, (uint16_t)(FLASH_CTRL_ACCESS_TIME_TNVS_TNVH(i_system_clock)));
    WRITE_REG_16(AADDR_FLASH_CTRL0_TNVH1    , (uint16_t)(FLASH_CTRL_ACCESS_TIME_TNVH1(i_system_clock)));
    WRITE_REG_16(AADDR_FLASH_CTRL0_TPGS     , (uint16_t)(FLASH_CTRL_ACCESS_TIME_TPGS(i_system_clock)));
    WRITE_REG_16(AADDR_FLASH_CTRL0_TRCV     , (uint16_t)(FLASH_CTRL_ACCESS_TIME_TRCV(i_system_clock)));
    WRITE_REG_16(AADDR_FLASH_CTRL0_TPROG    , (uint16_t)(FLASH_CTRL_ACCESS_TIME_TPROG(i_system_clock)));          
    WRITE_REG_16(AADDR_FLASH_CTRL0_TERASE   , (uint16_t)(FLASH_CTRL_ACCESS_TIME_TERASE(i_system_clock)));
    WRITE_REG_16(AADDR_FLASH_CTRL0_TME      , (uint16_t)(FLASH_CTRL_ACCESS_TIME_TME(i_system_clock)));
  
  }
  return(i_error_code);
}

/* ############################################################################ */
bool flash_ctrl_api_page_erase(uint32_t page_base_addr) {
  bool i_return;
  __disable_irq();
  i_return=flash_page_erase( page_base_addr );
  __enable_irq();
  return(i_return);
}