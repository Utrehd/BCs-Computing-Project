/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         tsu_bf.h
*
* @brief        TSU Module HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __TSU_BF_H__
#define __TSU_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_TSU
#define BASE_ADDR_TSU 0x40006180U
#endif

#define NUMBER_TSU 1


/* ############################################################################ */
/**
 * \brief TSU instances
 *
 * \ingroup tsu 
 */ 
typedef enum {
  /**
   * TSU instance
   */ 
  TSU                            = (int)BASE_ADDR_TSU
} tsu_num_t;

// Register bit field definitions

/* TSU_TRANSFER_STATUS */

#define MSK_TSU_TRANSFER_STATUS                             (0x1)     /* [0] */

typedef unsigned short tsu_transfer_status_t;                         /* [0] */


/* TSU_TRANSFER_READ */

#define MSK_TSU_TRANSFER_READ                               (0xffff)  /* [15:0] */

typedef unsigned short tsu_transfer_read_t;                           /* [15:0] */


/* TSU_RWS_STATUS */

#define MSK_TSU_RWS_STATUS                                  (0x1)     /* [0] */

typedef unsigned short tsu_rws_status_t;                              /* [0] */


/* TSU_IRQ_STATUS */

#define MSK_TSU_IRQ_STATUS_EVT_TIMEBASE_OF                  (0x1)     /* [0] */
#define RES_TSU_IRQ_STATUS_EVT_TIMEBASE_OF                  (0x0)
#define SFT_TSU_IRQ_STATUS_EVT_TIMEBASE_OF                  (0)
#define LSB_TSU_IRQ_STATUS_EVT_TIMEBASE_OF                  (0)
#define MSB_TSU_IRQ_STATUS_EVT_TIMEBASE_OF                  (0)
#define BIT_TSU_IRQ_STATUS_EVT_TIMEBASE_OF                  (0x1)     /* [0] */
#define MSK_TSU_IRQ_STATUS_EVT_SYNC_IN_EXT                  (0x1)     /* [1] */
#define RES_TSU_IRQ_STATUS_EVT_SYNC_IN_EXT                  (0x0)
#define SFT_TSU_IRQ_STATUS_EVT_SYNC_IN_EXT                  (1)
#define LSB_TSU_IRQ_STATUS_EVT_SYNC_IN_EXT                  (1)
#define MSB_TSU_IRQ_STATUS_EVT_SYNC_IN_EXT                  (1)
#define BIT_TSU_IRQ_STATUS_EVT_SYNC_IN_EXT                  (0x2)     /* [1] */
#define MSK_TSU_IRQ_STATUS_SYNC_OUT                         (0x3ff)   /* [11:2] */
#define RES_TSU_IRQ_STATUS_SYNC_OUT                         (0x000)
#define SFT_TSU_IRQ_STATUS_SYNC_OUT                         (2)
#define LSB_TSU_IRQ_STATUS_SYNC_OUT                         (2)
#define MSB_TSU_IRQ_STATUS_SYNC_OUT                         (11)
#define MSK_TSU_IRQ_STATUS_SYNC_OUT_EXT                     (0x3)     /* [13:12] */
#define RES_TSU_IRQ_STATUS_SYNC_OUT_EXT                     (0x0)
#define SFT_TSU_IRQ_STATUS_SYNC_OUT_EXT                     (12)
#define LSB_TSU_IRQ_STATUS_SYNC_OUT_EXT                     (12)
#define MSB_TSU_IRQ_STATUS_SYNC_OUT_EXT                     (13)


/* ############################################################################ */
/**
 * \brief  This structure describes TSU interrupts
 *
 * \ingroup tsu 
 */ 
typedef struct {
  /**
   * timebase overflow
   */ 
  unsigned short evt_timebase_of               :    1;       /* [0] */
  /**
   * configured sync_in_ext event
   */ 
  unsigned short evt_sync_in_ext               :    1;       /* [1] */
  /**
   * sync_out[9:0] event
   */ 
  unsigned short sync_out                      :   10;       /* [11:2] */
  /**
   * start of sync_out_ext[1:0] event
   */ 
  unsigned short sync_out_ext                  :    2;       /* [13:12] */

  unsigned short reserved                      :    2;
} tsu_irq_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of TSU interrupts
 *
 * \ingroup tsu 
 */ 
typedef union {
  unsigned short val;    ///< word representation
  tsu_irq_status_bf bf;  ///< bit field representation
} tsu_irq_status_t;


/* TSU_IRQ_MASK */

#define MSK_TSU_IRQ_MASK                                    (0x3fff)  /* [13:0] */

typedef unsigned short tsu_irq_mask_t;                                /* [13:0] */


/* TSU_IRQ_VENABLE */

#define MSK_TSU_IRQ_VENABLE                                 (0xf)     /* [ 3:0] */

typedef unsigned short tsu_irq_venable_t;                             /* [ 3:0] */


/* TSU_IRQ_VDISABLE */

#define MSK_TSU_IRQ_VDISABLE                                (0xf)     /* [ 3:0] */

typedef unsigned short tsu_irq_vdisable_t;                            /* [ 3:0] */


/* TSU_IRQ_VMAX */

#define MSK_TSU_IRQ_VMAX                                    (0xf)     /* [ 3:0] */

typedef unsigned short tsu_irq_vmax_t;                                /* [ 3:0] */


/* TSU_IRQ_VNO */

#define MSK_TSU_IRQ_VNO                                     (0xf)     /* [ 3:0] */

typedef unsigned short tsu_irq_vno_t;                                 /* [ 3:0] */


/* TSU_UP_TIMEBASE_INC_0 */

#define MSK_TSU_UP_TIMEBASE_INC_0                           (0xffff)  /* [15:0] */

typedef unsigned short tsu_up_timebase_inc_0_t;                       /* [15:0] */


/* TSU_UP_TIMEBASE_INC_1 */

#define MSK_TSU_UP_TIMEBASE_INC_1                           (0xffff)  /* [15:0] */

typedef unsigned short tsu_up_timebase_inc_1_t;                       /* [15:0] */


/* TSU_CFG */

#define MSK_TSU_CFG_ENABLE                                  (0x1)     /* [0] */
#define RES_TSU_CFG_ENABLE                                  (0x0)
#define SFT_TSU_CFG_ENABLE                                  (0)
#define LSB_TSU_CFG_ENABLE                                  (0)
#define MSB_TSU_CFG_ENABLE                                  (0)
#define BIT_TSU_CFG_ENABLE                                  (0x1)     /* [0] */
#define MSK_TSU_CFG_UP_TB_INC_S0                            (0x1)     /* [1] */
#define RES_TSU_CFG_UP_TB_INC_S0                            (0x0)
#define SFT_TSU_CFG_UP_TB_INC_S0                            (1)
#define LSB_TSU_CFG_UP_TB_INC_S0                            (1)
#define MSB_TSU_CFG_UP_TB_INC_S0                            (1)
#define BIT_TSU_CFG_UP_TB_INC_S0                            (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes TSU configuration
 *
 * \ingroup tsu 
 */ 
typedef struct {
  /**
   * 0 : timebase is stopped, i.e. not incremented
   */ 
  unsigned short enable                        :    1;       /* [0] */
  /**
   * 1: update timebase_inc on sync[0] event
   */ 
  unsigned short up_tb_inc_s0                  :    1;       /* [1] */

  unsigned short reserved                      :   14;
} tsu_cfg_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of TSU configuration
 *
 * \ingroup tsu 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  tsu_cfg_bf bf;       ///< bit field representation
} tsu_cfg_t;


/* TSU_CFG_TIMEBASE_MODULUS */

#define MSK_TSU_CFG_TIMEBASE_MODULUS                        (0x3f)    /* [ 5:0] */

typedef unsigned short tsu_cfg_timebase_modulus_t;                    /* [ 5:0] */


/* TSU_CFG_BASE_PERIOD_RELOAD */

#define MSK_TSU_CFG_BASE_PERIOD_RELOAD                      (0xffff)  /* [15:0] */

typedef unsigned short tsu_cfg_base_period_reload_t;                  /* [15:0] */


/* TSU_CFG_SUB_PERIOD_RELOAD */

#define MSK_TSU_CFG_SUB_PERIOD_RELOAD_P0_MAX                (0x1f)    /* [ 4:0] */
#define RES_TSU_CFG_SUB_PERIOD_RELOAD_P0_MAX                (0x00)
#define SFT_TSU_CFG_SUB_PERIOD_RELOAD_P0_MAX                (0)
#define LSB_TSU_CFG_SUB_PERIOD_RELOAD_P0_MAX                (0)
#define MSB_TSU_CFG_SUB_PERIOD_RELOAD_P0_MAX                (4)
#define MSK_TSU_CFG_SUB_PERIOD_RELOAD_P1_MAX                (0x3ff)   /* [14:5] */
#define RES_TSU_CFG_SUB_PERIOD_RELOAD_P1_MAX                (0x000)
#define SFT_TSU_CFG_SUB_PERIOD_RELOAD_P1_MAX                (5)
#define LSB_TSU_CFG_SUB_PERIOD_RELOAD_P1_MAX                (5)
#define MSB_TSU_CFG_SUB_PERIOD_RELOAD_P1_MAX                (14)


/* ############################################################################ */
/**
 * \brief This structure describes TSU sub phase configuration
 *
 * \ingroup tsu 
 */ 
typedef struct {
  /**
   * (p0_width -1:0) The counter SUB_PHASE.p0 counts from this value to 0.
   */ 
  unsigned short p0_max                        :    5;       /* [ 4:0] */
  /**
   * (( p1_width+p0_width -1): p0_width ) The counter SUB_PHASE.p1 counts from this value to 0.
   */ 
  unsigned short p1_max                        :   10;       /* [14:5] */

  unsigned short reserved                      :    1;
} tsu_cfg_sub_period_reload_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of TSU sub phase configuration
 *
 * \ingroup tsu 
 */ 
typedef union {
  unsigned short val;               ///< word representation
  tsu_cfg_sub_period_reload_bf bf;  ///< bit field representation
} tsu_cfg_sub_period_reload_t;


/* TSU_CFG_SYNC_OUT_EXT */

#define MSK_TSU_CFG_SYNC_OUT_EXT_POLARITY0                  (0x1)     /* [0] */
#define RES_TSU_CFG_SYNC_OUT_EXT_POLARITY0                  (0x1)
#define SFT_TSU_CFG_SYNC_OUT_EXT_POLARITY0                  (0)
#define LSB_TSU_CFG_SYNC_OUT_EXT_POLARITY0                  (0)
#define MSB_TSU_CFG_SYNC_OUT_EXT_POLARITY0                  (0)
#define BIT_TSU_CFG_SYNC_OUT_EXT_POLARITY0                  (0x1)     /* [0] */
#define MSK_TSU_CFG_SYNC_OUT_EXT_LENGTH0                    (0x7f)    /* [ 7:1] */
#define RES_TSU_CFG_SYNC_OUT_EXT_LENGTH0                    (0x01)
#define SFT_TSU_CFG_SYNC_OUT_EXT_LENGTH0                    (1)
#define LSB_TSU_CFG_SYNC_OUT_EXT_LENGTH0                    (1)
#define MSB_TSU_CFG_SYNC_OUT_EXT_LENGTH0                    (7)
#define MSK_TSU_CFG_SYNC_OUT_EXT_POLARITY1                  (0x1)     /* [8] */
#define RES_TSU_CFG_SYNC_OUT_EXT_POLARITY1                  (0x1)
#define SFT_TSU_CFG_SYNC_OUT_EXT_POLARITY1                  (8)
#define LSB_TSU_CFG_SYNC_OUT_EXT_POLARITY1                  (8)
#define MSB_TSU_CFG_SYNC_OUT_EXT_POLARITY1                  (8)
#define BIT_TSU_CFG_SYNC_OUT_EXT_POLARITY1                  (0x100)   /* [8] */
#define MSK_TSU_CFG_SYNC_OUT_EXT_LENGTH1                    (0x7f)    /* [15:9] */
#define RES_TSU_CFG_SYNC_OUT_EXT_LENGTH1                    (0x01)
#define SFT_TSU_CFG_SYNC_OUT_EXT_LENGTH1                    (9)
#define LSB_TSU_CFG_SYNC_OUT_EXT_LENGTH1                    (9)
#define MSB_TSU_CFG_SYNC_OUT_EXT_LENGTH1                    (15)


/* ############################################################################ */
/**
 * \brief This structure describes TSU configuration for external synchonization signals
 *
 * \ingroup tsu 
 */ 
typedef struct {
  /**
   * active polarity of sync_out_ext[0]
   */ 
  unsigned short polarity0                     :    1;       /* [0] */
  /**
   * duration of the sync_out_ext[0] pulse in comm_clk cycles = {1..127}
   */ 
  unsigned short length0                       :    7;       /* [ 7:1] */
  /**
   * active polarity of sync_out_ext[1]
   */ 
  unsigned short polarity1                     :    1;       /* [8] */
  /**
   * duration of the sync_out_ext[1] pulse in comm_clk cycles = {1..127}
   */ 
  unsigned short length1                       :    7;       /* [15:9] */
} tsu_cfg_sync_out_ext_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of TSU configuration for external synchonization signals
 *
 * \ingroup tsu 
 */ 
typedef union {
  unsigned short val;          ///< word representation
  tsu_cfg_sync_out_ext_bf bf;  ///< bit field representation
} tsu_cfg_sync_out_ext_t;


/* TSU_CFG_SYNC_IN */

#define MSK_TSU_CFG_SYNC_IN                                 (0x3)     /* [ 1:0] */

typedef unsigned short tsu_cfg_sync_in_t;                             /* [ 1:0] */


/* TSU_CFG_SYNC_ENABLE */

#define MSK_TSU_CFG_SYNC_ENABLE                             (0xfff)   /* [11:0] */

typedef unsigned short tsu_cfg_sync_enable_t;                         /* [11:0] */


/* TSU_CFG_SYNC_BASE_PHASE */

#define MSK_TSU_CFG_SYNC_BASE_PHASE                         (0xffff)  /* [15:0] */

typedef unsigned short tsu_cfg_sync_base_phase_t;                     /* [15:0] */


/* TSU_CFG_SYNC_SUB_PHASE */

#define MSK_TSU_CFG_SYNC_SUB_PHASE_MODE                     (0x3)     /* [ 1:0] */
#define RES_TSU_CFG_SYNC_SUB_PHASE_MODE                     (0x0)
#define SFT_TSU_CFG_SYNC_SUB_PHASE_MODE                     (0)
#define LSB_TSU_CFG_SYNC_SUB_PHASE_MODE                     (0)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_MODE                     (1)
#define MSK_TSU_CFG_SYNC_SUB_PHASE_SUB_PHASE                (0x3ff)   /* [11:2] */
#define RES_TSU_CFG_SYNC_SUB_PHASE_SUB_PHASE                (0x000)
#define SFT_TSU_CFG_SYNC_SUB_PHASE_SUB_PHASE                (2)
#define LSB_TSU_CFG_SYNC_SUB_PHASE_SUB_PHASE                (2)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_SUB_PHASE                (11)


/* ############################################################################ */
/**
 * \brief This structure describes TSU configuration of sync sub phases and modes
 *
 * \ingroup tsu 
 */ 
typedef struct {
  /**
   * 00: Periodic sync generation disabled. <br>
   * 01: The sync generator N must only match the base period. <br>
   * 10:The sync generator N must match the base period and SUB_PHASE.p0 <br>
   * 11:The sync generator N must match the base period and SUB_PHASE.p1 <br>
   */ 
  unsigned short mode                          :    2;       /* [ 1:0] */
  /**
   * ( p_max_width+1:2) Value for matching the SUB_PHASE selected above
   */ 
  unsigned short sub_phase                     :   10;       /* [11:2] */
  /**
   * 
   */ 
  unsigned short reserved                      :    4;
} tsu_cfg_sync_sub_phase_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of TSU configuration of sync sub phases and modes
 *
 * \ingroup tsu 
 */ 
typedef union {
  unsigned short val;            ///< word representation
  tsu_cfg_sync_sub_phase_bf bf;  ///< bit field representation
} tsu_cfg_sync_sub_phase_t;


/* TSU_CMD_SYNC_OUT */

#define MSK_TSU_CMD_SYNC_OUT                                (0xfff)   /* [11:0] */

typedef unsigned short tsu_cmd_sync_out_t;                            /* [11:0] */


/* TSU_UP_TIMEBASE_INC_CMD */

#define MSK_TSU_UP_TIMEBASE_INC_CMD                         (0x1)     /* [0] */

typedef unsigned short tsu_up_timebase_inc_cmd_t;                     /* [0] */


/* TSU_RWS_CMD */

#define MSK_TSU_RWS_CMD                                     (0x7)     /* [ 2:0] */

typedef unsigned short tsu_rws_cmd_t;                                 /* [ 2:0] */


/* TSU_RWS_TIMEBASE_INC_0 */

#define MSK_TSU_RWS_TIMEBASE_INC_0                          (0xffff)  /* [15:0] */

typedef unsigned short tsu_rws_timebase_inc_0_t;                      /* [15:0] */


/* TSU_RWS_TIMEBASE_INC_1 */

#define MSK_TSU_RWS_TIMEBASE_INC_1                          (0xffff)  /* [15:0] */

typedef unsigned short tsu_rws_timebase_inc_1_t;                      /* [15:0] */


/* TSU_RWS_TIMEBASE_0 */

#define MSK_TSU_RWS_TIMEBASE_0                              (0xffff)  /* [15:0] */

typedef unsigned short tsu_rws_timebase_0_t;                          /* [15:0] */


/* TSU_RWS_TIMEBASE_1 */

#define MSK_TSU_RWS_TIMEBASE_1                              (0xffff)  /* [15:0] */

typedef unsigned short tsu_rws_timebase_1_t;                          /* [15:0] */


/* TSU_RWS_TIMEBASE_2 */

#define MSK_TSU_RWS_TIMEBASE_2                              (0xffff)  /* [15:0] */

typedef unsigned short tsu_rws_timebase_2_t;                          /* [15:0] */


/* TSU_RWS_TIMEBASE_3 */

#define MSK_TSU_RWS_TIMEBASE_3                              (0xffff)  /* [15:0] */

typedef unsigned short tsu_rws_timebase_3_t;                          /* [15:0] */


/* TSU_RWS_BASE_PHASE */

#define MSK_TSU_RWS_BASE_PHASE                              (0xffff)  /* [15:0] */

typedef unsigned short tsu_rws_base_phase_t;                          /* [15:0] */


/* TSU_RWS_SUB_PHASE */

#define MSK_TSU_RWS_SUB_PHASE_P0                            (0x1f)    /* [ 4:0] */
#define RES_TSU_RWS_SUB_PHASE_P0                            (0x00)
#define SFT_TSU_RWS_SUB_PHASE_P0                            (0)
#define LSB_TSU_RWS_SUB_PHASE_P0                            (0)
#define MSB_TSU_RWS_SUB_PHASE_P0                            (4)
#define MSK_TSU_RWS_SUB_PHASE_P1                            (0x3ff)   /* [14:5] */
#define RES_TSU_RWS_SUB_PHASE_P1                            (0x000)
#define SFT_TSU_RWS_SUB_PHASE_P1                            (5)
#define LSB_TSU_RWS_SUB_PHASE_P1                            (5)
#define MSB_TSU_RWS_SUB_PHASE_P1                            (14)


/* ############################################################################ */
/**
 * \brief This structure describes TSU RWS sub phase configuration
 *
 * \ingroup tsu 
 */ 
typedef struct {
  /**
   * (p0_width -1:0) The counter SUB_PHASE.p0 counts from this value to 0.
   */ 
  unsigned short p0                            :    5;       /* [ 4:0] */
  /**
   * (( p1_width+p0_width -1): p0_width ) The counter SUB_PHASE.p1 counts from this value to 0.
   */ 
  unsigned short p1                            :   10;       /* [14:5] */
  /**
   * 
   */ 
  unsigned short reserved                      :    1;
} tsu_rws_sub_phase_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of TSU RWS sub phase configuration
 *
 * \ingroup tsu 
 */ 
typedef union {
  unsigned short val;       ///< word representation
  tsu_rws_sub_phase_bf bf;  ///< bit field representation
} tsu_rws_sub_phase_t;



// Register definitions for module
// Instance base address BASE_ADDR_TSU 0x40006180U ... 

#define ADDR_TSU_TRANSFER_STATUS                             (0x00U)
#define A_TSU_TRANSFER_STATUS(ba)                            ((ba) + ADDR_TSU_TRANSFER_STATUS)
#define R_TSU_TRANSFER_STATUS(ba)                            (*(volatile unsigned short *)((unsigned int)A_TSU_TRANSFER_STATUS(ba)))
#define RES_TSU_TRANSFER_STATUS                              (0x0U)
#define MSB_TSU_TRANSFER_STATUS                              0
#define LSB_TSU_TRANSFER_STATUS                              0
#define AADDR_TSU_TRANSFER_STATUS                            (BASE_ADDR_TSU + ADDR_TSU_TRANSFER_STATUS)
#define REG_TSU_TRANSFER_STATUS                              (*(volatile unsigned short *)((unsigned int)AADDR_TSU_TRANSFER_STATUS))

#define ADDR_TSU_TRANSFER_READ                               (0x02U)
#define A_TSU_TRANSFER_READ(ba)                              ((ba) + ADDR_TSU_TRANSFER_READ)
#define R_TSU_TRANSFER_READ(ba)                              (*(volatile unsigned short *)((unsigned int)A_TSU_TRANSFER_READ(ba)))
#define RES_TSU_TRANSFER_READ                                (0x0U)
#define MSB_TSU_TRANSFER_READ                                15
#define LSB_TSU_TRANSFER_READ                                0
#define AADDR_TSU_TRANSFER_READ                              (BASE_ADDR_TSU + ADDR_TSU_TRANSFER_READ)
#define REG_TSU_TRANSFER_READ                                (*(volatile unsigned short *)((unsigned int)AADDR_TSU_TRANSFER_READ))

#define ADDR_TSU_RWS_STATUS                                  (0x04U)
#define A_TSU_RWS_STATUS(ba)                                 ((ba) + ADDR_TSU_RWS_STATUS)
#define R_TSU_RWS_STATUS(ba)                                 (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_STATUS(ba)))
#define RES_TSU_RWS_STATUS                                   (0x0U)
#define MSB_TSU_RWS_STATUS                                   0
#define LSB_TSU_RWS_STATUS                                   0
#define AADDR_TSU_RWS_STATUS                                 (BASE_ADDR_TSU + ADDR_TSU_RWS_STATUS)
#define REG_TSU_RWS_STATUS                                   (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_STATUS))

#define ADDR_TSU_IRQ_STATUS                                  (0x06U)
#define A_TSU_IRQ_STATUS(ba)                                 ((ba) + ADDR_TSU_IRQ_STATUS)
#define R_TSU_IRQ_STATUS(ba)                                 (*(volatile unsigned short *)((unsigned int)A_TSU_IRQ_STATUS(ba)))
#define RES_TSU_IRQ_STATUS                                   (0x0U)
#define MSB_TSU_IRQ_STATUS                                   13
#define LSB_TSU_IRQ_STATUS                                   0
#define AADDR_TSU_IRQ_STATUS                                 (BASE_ADDR_TSU + ADDR_TSU_IRQ_STATUS)
#define REG_TSU_IRQ_STATUS                                   (*(volatile unsigned short *)((unsigned int)AADDR_TSU_IRQ_STATUS))

#define ADDR_TSU_IRQ_MASK                                    (0x0AU)
#define A_TSU_IRQ_MASK(ba)                                   ((ba) + ADDR_TSU_IRQ_MASK)
#define R_TSU_IRQ_MASK(ba)                                   (*(volatile unsigned short *)((unsigned int)A_TSU_IRQ_MASK(ba)))
#define RES_TSU_IRQ_MASK                                     (0x0U)
#define MSB_TSU_IRQ_MASK                                     13
#define LSB_TSU_IRQ_MASK                                     0
#define AADDR_TSU_IRQ_MASK                                   (BASE_ADDR_TSU + ADDR_TSU_IRQ_MASK)
#define REG_TSU_IRQ_MASK                                     (*(volatile unsigned short *)((unsigned int)AADDR_TSU_IRQ_MASK))

#define ADDR_TSU_IRQ_VENABLE                                 (0x0EU)
#define A_TSU_IRQ_VENABLE(ba)                                ((ba) + ADDR_TSU_IRQ_VENABLE)
#define R_TSU_IRQ_VENABLE(ba)                                (*(volatile unsigned short *)((unsigned int)A_TSU_IRQ_VENABLE(ba)))
#define RES_TSU_IRQ_VENABLE                                  (0x0U)
#define MSB_TSU_IRQ_VENABLE                                  3
#define LSB_TSU_IRQ_VENABLE                                  0
#define AADDR_TSU_IRQ_VENABLE                                (BASE_ADDR_TSU + ADDR_TSU_IRQ_VENABLE)
#define REG_TSU_IRQ_VENABLE                                  (*(volatile unsigned short *)((unsigned int)AADDR_TSU_IRQ_VENABLE))

#define ADDR_TSU_IRQ_VDISABLE                                (0x10U)
#define A_TSU_IRQ_VDISABLE(ba)                               ((ba) + ADDR_TSU_IRQ_VDISABLE)
#define R_TSU_IRQ_VDISABLE(ba)                               (*(volatile unsigned short *)((unsigned int)A_TSU_IRQ_VDISABLE(ba)))
#define RES_TSU_IRQ_VDISABLE                                 (0x0U)
#define MSB_TSU_IRQ_VDISABLE                                 3
#define LSB_TSU_IRQ_VDISABLE                                 0
#define AADDR_TSU_IRQ_VDISABLE                               (BASE_ADDR_TSU + ADDR_TSU_IRQ_VDISABLE)
#define REG_TSU_IRQ_VDISABLE                                 (*(volatile unsigned short *)((unsigned int)AADDR_TSU_IRQ_VDISABLE))

#define ADDR_TSU_IRQ_VMAX                                    (0x12U)
#define A_TSU_IRQ_VMAX(ba)                                   ((ba) + ADDR_TSU_IRQ_VMAX)
#define R_TSU_IRQ_VMAX(ba)                                   (*(volatile unsigned short *)((unsigned int)A_TSU_IRQ_VMAX(ba)))
#define RES_TSU_IRQ_VMAX                                     (0xeU)
#define MSB_TSU_IRQ_VMAX                                     3
#define LSB_TSU_IRQ_VMAX                                     0
#define AADDR_TSU_IRQ_VMAX                                   (BASE_ADDR_TSU + ADDR_TSU_IRQ_VMAX)
#define REG_TSU_IRQ_VMAX                                     (*(volatile unsigned short *)((unsigned int)AADDR_TSU_IRQ_VMAX))

#define ADDR_TSU_IRQ_VNO                                     (0x14U)
#define A_TSU_IRQ_VNO(ba)                                    ((ba) + ADDR_TSU_IRQ_VNO)
#define R_TSU_IRQ_VNO(ba)                                    (*(volatile unsigned short *)((unsigned int)A_TSU_IRQ_VNO(ba)))
#define RES_TSU_IRQ_VNO                                      (0xeU)
#define MSB_TSU_IRQ_VNO                                      3
#define LSB_TSU_IRQ_VNO                                      0
#define AADDR_TSU_IRQ_VNO                                    (BASE_ADDR_TSU + ADDR_TSU_IRQ_VNO)
#define REG_TSU_IRQ_VNO                                      (*(volatile unsigned short *)((unsigned int)AADDR_TSU_IRQ_VNO))

#define ADDR_TSU_UP_TIMEBASE_INC_0                           (0x20U)
#define A_TSU_UP_TIMEBASE_INC_0(ba)                          ((ba) + ADDR_TSU_UP_TIMEBASE_INC_0)
#define R_TSU_UP_TIMEBASE_INC_0(ba)                          (*(volatile unsigned short *)((unsigned int)A_TSU_UP_TIMEBASE_INC_0(ba)))
#define RES_TSU_UP_TIMEBASE_INC_0                            (0x0U)
#define MSB_TSU_UP_TIMEBASE_INC_0                            15
#define LSB_TSU_UP_TIMEBASE_INC_0                            0
#define AADDR_TSU_UP_TIMEBASE_INC_0                          (BASE_ADDR_TSU + ADDR_TSU_UP_TIMEBASE_INC_0)
#define REG_TSU_UP_TIMEBASE_INC_0                            (*(volatile unsigned short *)((unsigned int)AADDR_TSU_UP_TIMEBASE_INC_0))

#define ADDR_TSU_UP_TIMEBASE_INC_1                           (0x22U)
#define A_TSU_UP_TIMEBASE_INC_1(ba)                          ((ba) + ADDR_TSU_UP_TIMEBASE_INC_1)
#define R_TSU_UP_TIMEBASE_INC_1(ba)                          (*(volatile unsigned short *)((unsigned int)A_TSU_UP_TIMEBASE_INC_1(ba)))
#define RES_TSU_UP_TIMEBASE_INC_1                            (0x0U)
#define MSB_TSU_UP_TIMEBASE_INC_1                            15
#define LSB_TSU_UP_TIMEBASE_INC_1                            0
#define AADDR_TSU_UP_TIMEBASE_INC_1                          (BASE_ADDR_TSU + ADDR_TSU_UP_TIMEBASE_INC_1)
#define REG_TSU_UP_TIMEBASE_INC_1                            (*(volatile unsigned short *)((unsigned int)AADDR_TSU_UP_TIMEBASE_INC_1))

#define ADDR_TSU_CFG                                         (0x24U)
#define A_TSU_CFG(ba)                                        ((ba) + ADDR_TSU_CFG)
#define R_TSU_CFG(ba)                                        (*(volatile unsigned short *)((unsigned int)A_TSU_CFG(ba)))
#define RES_TSU_CFG                                          (0x0U)
#define MSB_TSU_CFG                                          1
#define LSB_TSU_CFG                                          0
#define AADDR_TSU_CFG                                        (BASE_ADDR_TSU + ADDR_TSU_CFG)
#define REG_TSU_CFG                                          (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG))

#define ADDR_TSU_CFG_TIMEBASE_MODULUS                        (0x26U)
#define A_TSU_CFG_TIMEBASE_MODULUS(ba)                       ((ba) + ADDR_TSU_CFG_TIMEBASE_MODULUS)
#define R_TSU_CFG_TIMEBASE_MODULUS(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_TIMEBASE_MODULUS(ba)))
#define RES_TSU_CFG_TIMEBASE_MODULUS                         (0x3fU)
#define MSB_TSU_CFG_TIMEBASE_MODULUS                         5
#define LSB_TSU_CFG_TIMEBASE_MODULUS                         0
#define AADDR_TSU_CFG_TIMEBASE_MODULUS                       (BASE_ADDR_TSU + ADDR_TSU_CFG_TIMEBASE_MODULUS)
#define REG_TSU_CFG_TIMEBASE_MODULUS                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_TIMEBASE_MODULUS))

#define ADDR_TSU_CFG_BASE_PERIOD_RELOAD                      (0x28U)
#define A_TSU_CFG_BASE_PERIOD_RELOAD(ba)                     ((ba) + ADDR_TSU_CFG_BASE_PERIOD_RELOAD)
#define R_TSU_CFG_BASE_PERIOD_RELOAD(ba)                     (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_BASE_PERIOD_RELOAD(ba)))
#define RES_TSU_CFG_BASE_PERIOD_RELOAD                       (0x0U)
#define MSB_TSU_CFG_BASE_PERIOD_RELOAD                       15
#define LSB_TSU_CFG_BASE_PERIOD_RELOAD                       0
#define AADDR_TSU_CFG_BASE_PERIOD_RELOAD                     (BASE_ADDR_TSU + ADDR_TSU_CFG_BASE_PERIOD_RELOAD)
#define REG_TSU_CFG_BASE_PERIOD_RELOAD                       (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_BASE_PERIOD_RELOAD))

#define ADDR_TSU_CFG_SUB_PERIOD_RELOAD                       (0x2AU)
#define A_TSU_CFG_SUB_PERIOD_RELOAD(ba)                      ((ba) + ADDR_TSU_CFG_SUB_PERIOD_RELOAD)
#define R_TSU_CFG_SUB_PERIOD_RELOAD(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SUB_PERIOD_RELOAD(ba)))
#define RES_TSU_CFG_SUB_PERIOD_RELOAD                        (0x0U)
#define MSB_TSU_CFG_SUB_PERIOD_RELOAD                        14
#define LSB_TSU_CFG_SUB_PERIOD_RELOAD                        0
#define AADDR_TSU_CFG_SUB_PERIOD_RELOAD                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SUB_PERIOD_RELOAD)
#define REG_TSU_CFG_SUB_PERIOD_RELOAD                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SUB_PERIOD_RELOAD))

#define ADDR_TSU_CFG_SYNC_OUT_EXT                            (0x2CU)
#define A_TSU_CFG_SYNC_OUT_EXT(ba)                           ((ba) + ADDR_TSU_CFG_SYNC_OUT_EXT)
#define R_TSU_CFG_SYNC_OUT_EXT(ba)                           (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_OUT_EXT(ba)))
#define RES_TSU_CFG_SYNC_OUT_EXT                             (0x303U)
#define MSB_TSU_CFG_SYNC_OUT_EXT                             15
#define LSB_TSU_CFG_SYNC_OUT_EXT                             0
#define AADDR_TSU_CFG_SYNC_OUT_EXT                           (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_OUT_EXT)
#define REG_TSU_CFG_SYNC_OUT_EXT                             (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_OUT_EXT))

#define ADDR_TSU_CFG_SYNC_IN                                 (0x2EU)
#define A_TSU_CFG_SYNC_IN(ba)                                ((ba) + ADDR_TSU_CFG_SYNC_IN)
#define R_TSU_CFG_SYNC_IN(ba)                                (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_IN(ba)))
#define RES_TSU_CFG_SYNC_IN                                  (0x0U)
#define MSB_TSU_CFG_SYNC_IN                                  1
#define LSB_TSU_CFG_SYNC_IN                                  0
#define AADDR_TSU_CFG_SYNC_IN                                (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_IN)
#define REG_TSU_CFG_SYNC_IN                                  (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_IN))

#define ADDR_TSU_CFG_SYNC_ENABLE                             (0x30U)
#define A_TSU_CFG_SYNC_ENABLE(ba)                            ((ba) + ADDR_TSU_CFG_SYNC_ENABLE)
#define R_TSU_CFG_SYNC_ENABLE(ba)                            (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_ENABLE(ba)))
#define RES_TSU_CFG_SYNC_ENABLE                              (0x0U)
#define MSB_TSU_CFG_SYNC_ENABLE                              11
#define LSB_TSU_CFG_SYNC_ENABLE                              0
#define AADDR_TSU_CFG_SYNC_ENABLE                            (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_ENABLE)
#define REG_TSU_CFG_SYNC_ENABLE                              (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_ENABLE))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_0                       (0x32U)
#define A_TSU_CFG_SYNC_BASE_PHASE_0(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_0)
#define R_TSU_CFG_SYNC_BASE_PHASE_0(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_0(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_0                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_0                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_0                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_0                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_0)
#define REG_TSU_CFG_SYNC_BASE_PHASE_0                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_0))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_1                       (0x34U)
#define A_TSU_CFG_SYNC_BASE_PHASE_1(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_1)
#define R_TSU_CFG_SYNC_BASE_PHASE_1(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_1(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_1                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_1                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_1                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_1                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_1)
#define REG_TSU_CFG_SYNC_BASE_PHASE_1                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_1))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_2                       (0x36U)
#define A_TSU_CFG_SYNC_BASE_PHASE_2(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_2)
#define R_TSU_CFG_SYNC_BASE_PHASE_2(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_2(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_2                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_2                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_2                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_2                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_2)
#define REG_TSU_CFG_SYNC_BASE_PHASE_2                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_2))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_3                       (0x38U)
#define A_TSU_CFG_SYNC_BASE_PHASE_3(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_3)
#define R_TSU_CFG_SYNC_BASE_PHASE_3(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_3(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_3                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_3                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_3                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_3                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_3)
#define REG_TSU_CFG_SYNC_BASE_PHASE_3                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_3))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_4                       (0x3AU)
#define A_TSU_CFG_SYNC_BASE_PHASE_4(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_4)
#define R_TSU_CFG_SYNC_BASE_PHASE_4(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_4(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_4                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_4                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_4                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_4                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_4)
#define REG_TSU_CFG_SYNC_BASE_PHASE_4                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_4))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_5                       (0x3CU)
#define A_TSU_CFG_SYNC_BASE_PHASE_5(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_5)
#define R_TSU_CFG_SYNC_BASE_PHASE_5(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_5(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_5                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_5                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_5                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_5                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_5)
#define REG_TSU_CFG_SYNC_BASE_PHASE_5                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_5))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_6                       (0x3EU)
#define A_TSU_CFG_SYNC_BASE_PHASE_6(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_6)
#define R_TSU_CFG_SYNC_BASE_PHASE_6(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_6(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_6                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_6                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_6                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_6                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_6)
#define REG_TSU_CFG_SYNC_BASE_PHASE_6                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_6))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_7                       (0x40U)
#define A_TSU_CFG_SYNC_BASE_PHASE_7(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_7)
#define R_TSU_CFG_SYNC_BASE_PHASE_7(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_7(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_7                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_7                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_7                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_7                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_7)
#define REG_TSU_CFG_SYNC_BASE_PHASE_7                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_7))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_8                       (0x42U)
#define A_TSU_CFG_SYNC_BASE_PHASE_8(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_8)
#define R_TSU_CFG_SYNC_BASE_PHASE_8(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_8(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_8                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_8                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_8                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_8                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_8)
#define REG_TSU_CFG_SYNC_BASE_PHASE_8                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_8))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_9                       (0x44U)
#define A_TSU_CFG_SYNC_BASE_PHASE_9(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_9)
#define R_TSU_CFG_SYNC_BASE_PHASE_9(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_9(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_9                        (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_9                        15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_9                        0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_9                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_9)
#define REG_TSU_CFG_SYNC_BASE_PHASE_9                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_9))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_10                      (0x46U)
#define A_TSU_CFG_SYNC_BASE_PHASE_10(ba)                     ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_10)
#define R_TSU_CFG_SYNC_BASE_PHASE_10(ba)                     (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_10(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_10                       (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_10                       15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_10                       0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_10                     (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_10)
#define REG_TSU_CFG_SYNC_BASE_PHASE_10                       (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_10))

#define ADDR_TSU_CFG_SYNC_BASE_PHASE_11                      (0x48U)
#define A_TSU_CFG_SYNC_BASE_PHASE_11(ba)                     ((ba) + ADDR_TSU_CFG_SYNC_BASE_PHASE_11)
#define R_TSU_CFG_SYNC_BASE_PHASE_11(ba)                     (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_BASE_PHASE_11(ba)))
#define RES_TSU_CFG_SYNC_BASE_PHASE_11                       (0x0U)
#define MSB_TSU_CFG_SYNC_BASE_PHASE_11                       15
#define LSB_TSU_CFG_SYNC_BASE_PHASE_11                       0
#define AADDR_TSU_CFG_SYNC_BASE_PHASE_11                     (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_11)
#define REG_TSU_CFG_SYNC_BASE_PHASE_11                       (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_BASE_PHASE_11))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_0                        (0x4AU)
#define A_TSU_CFG_SYNC_SUB_PHASE_0(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_0)
#define R_TSU_CFG_SYNC_SUB_PHASE_0(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_0(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_0                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_0                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_0                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_0                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_0)
#define REG_TSU_CFG_SYNC_SUB_PHASE_0                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_0))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_1                        (0x4CU)
#define A_TSU_CFG_SYNC_SUB_PHASE_1(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_1)
#define R_TSU_CFG_SYNC_SUB_PHASE_1(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_1(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_1                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_1                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_1                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_1                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_1)
#define REG_TSU_CFG_SYNC_SUB_PHASE_1                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_1))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_2                        (0x4EU)
#define A_TSU_CFG_SYNC_SUB_PHASE_2(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_2)
#define R_TSU_CFG_SYNC_SUB_PHASE_2(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_2(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_2                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_2                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_2                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_2                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_2)
#define REG_TSU_CFG_SYNC_SUB_PHASE_2                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_2))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_3                        (0x50U)
#define A_TSU_CFG_SYNC_SUB_PHASE_3(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_3)
#define R_TSU_CFG_SYNC_SUB_PHASE_3(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_3(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_3                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_3                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_3                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_3                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_3)
#define REG_TSU_CFG_SYNC_SUB_PHASE_3                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_3))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_4                        (0x52U)
#define A_TSU_CFG_SYNC_SUB_PHASE_4(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_4)
#define R_TSU_CFG_SYNC_SUB_PHASE_4(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_4(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_4                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_4                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_4                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_4                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_4)
#define REG_TSU_CFG_SYNC_SUB_PHASE_4                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_4))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_5                        (0x54U)
#define A_TSU_CFG_SYNC_SUB_PHASE_5(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_5)
#define R_TSU_CFG_SYNC_SUB_PHASE_5(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_5(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_5                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_5                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_5                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_5                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_5)
#define REG_TSU_CFG_SYNC_SUB_PHASE_5                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_5))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_6                        (0x56U)
#define A_TSU_CFG_SYNC_SUB_PHASE_6(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_6)
#define R_TSU_CFG_SYNC_SUB_PHASE_6(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_6(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_6                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_6                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_6                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_6                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_6)
#define REG_TSU_CFG_SYNC_SUB_PHASE_6                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_6))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_7                        (0x58U)
#define A_TSU_CFG_SYNC_SUB_PHASE_7(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_7)
#define R_TSU_CFG_SYNC_SUB_PHASE_7(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_7(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_7                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_7                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_7                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_7                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_7)
#define REG_TSU_CFG_SYNC_SUB_PHASE_7                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_7))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_8                        (0x5AU)
#define A_TSU_CFG_SYNC_SUB_PHASE_8(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_8)
#define R_TSU_CFG_SYNC_SUB_PHASE_8(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_8(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_8                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_8                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_8                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_8                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_8)
#define REG_TSU_CFG_SYNC_SUB_PHASE_8                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_8))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_9                        (0x5CU)
#define A_TSU_CFG_SYNC_SUB_PHASE_9(ba)                       ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_9)
#define R_TSU_CFG_SYNC_SUB_PHASE_9(ba)                       (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_9(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_9                         (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_9                         11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_9                         0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_9                       (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_9)
#define REG_TSU_CFG_SYNC_SUB_PHASE_9                         (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_9))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_10                       (0x5EU)
#define A_TSU_CFG_SYNC_SUB_PHASE_10(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_10)
#define R_TSU_CFG_SYNC_SUB_PHASE_10(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_10(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_10                        (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_10                        11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_10                        0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_10                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_10)
#define REG_TSU_CFG_SYNC_SUB_PHASE_10                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_10))

#define ADDR_TSU_CFG_SYNC_SUB_PHASE_11                       (0x60U)
#define A_TSU_CFG_SYNC_SUB_PHASE_11(ba)                      ((ba) + ADDR_TSU_CFG_SYNC_SUB_PHASE_11)
#define R_TSU_CFG_SYNC_SUB_PHASE_11(ba)                      (*(volatile unsigned short *)((unsigned int)A_TSU_CFG_SYNC_SUB_PHASE_11(ba)))
#define RES_TSU_CFG_SYNC_SUB_PHASE_11                        (0x0U)
#define MSB_TSU_CFG_SYNC_SUB_PHASE_11                        11
#define LSB_TSU_CFG_SYNC_SUB_PHASE_11                        0
#define AADDR_TSU_CFG_SYNC_SUB_PHASE_11                      (BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_11)
#define REG_TSU_CFG_SYNC_SUB_PHASE_11                        (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CFG_SYNC_SUB_PHASE_11))

#define ADDR_TSU_CMD_SYNC_OUT                                (0x62U)
#define A_TSU_CMD_SYNC_OUT(ba)                               ((ba) + ADDR_TSU_CMD_SYNC_OUT)
#define R_TSU_CMD_SYNC_OUT(ba)                               (*(volatile unsigned short *)((unsigned int)A_TSU_CMD_SYNC_OUT(ba)))
#define RES_TSU_CMD_SYNC_OUT                                 (0x0U)
#define MSB_TSU_CMD_SYNC_OUT                                 11
#define LSB_TSU_CMD_SYNC_OUT                                 0
#define AADDR_TSU_CMD_SYNC_OUT                               (BASE_ADDR_TSU + ADDR_TSU_CMD_SYNC_OUT)
#define REG_TSU_CMD_SYNC_OUT                                 (*(volatile unsigned short *)((unsigned int)AADDR_TSU_CMD_SYNC_OUT))

#define ADDR_TSU_UP_TIMEBASE_INC_CMD                         (0x64U)
#define A_TSU_UP_TIMEBASE_INC_CMD(ba)                        ((ba) + ADDR_TSU_UP_TIMEBASE_INC_CMD)
#define R_TSU_UP_TIMEBASE_INC_CMD(ba)                        (*(volatile unsigned short *)((unsigned int)A_TSU_UP_TIMEBASE_INC_CMD(ba)))
#define RES_TSU_UP_TIMEBASE_INC_CMD                          (0x0U)
#define MSB_TSU_UP_TIMEBASE_INC_CMD                          0
#define LSB_TSU_UP_TIMEBASE_INC_CMD                          0
#define AADDR_TSU_UP_TIMEBASE_INC_CMD                        (BASE_ADDR_TSU + ADDR_TSU_UP_TIMEBASE_INC_CMD)
#define REG_TSU_UP_TIMEBASE_INC_CMD                          (*(volatile unsigned short *)((unsigned int)AADDR_TSU_UP_TIMEBASE_INC_CMD))

#define ADDR_TSU_RWS_CMD                                     (0x66U)
#define A_TSU_RWS_CMD(ba)                                    ((ba) + ADDR_TSU_RWS_CMD)
#define R_TSU_RWS_CMD(ba)                                    (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_CMD(ba)))
#define RES_TSU_RWS_CMD                                      (0x0U)
#define MSB_TSU_RWS_CMD                                      2
#define LSB_TSU_RWS_CMD                                      0
#define AADDR_TSU_RWS_CMD                                    (BASE_ADDR_TSU + ADDR_TSU_RWS_CMD)
#define REG_TSU_RWS_CMD                                      (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_CMD))

#define ADDR_TSU_RWS_TIMEBASE_INC_0                          (0x68U)
#define A_TSU_RWS_TIMEBASE_INC_0(ba)                         ((ba) + ADDR_TSU_RWS_TIMEBASE_INC_0)
#define R_TSU_RWS_TIMEBASE_INC_0(ba)                         (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_TIMEBASE_INC_0(ba)))
#define RES_TSU_RWS_TIMEBASE_INC_0                           (0x0U)
#define MSB_TSU_RWS_TIMEBASE_INC_0                           15
#define LSB_TSU_RWS_TIMEBASE_INC_0                           0
#define AADDR_TSU_RWS_TIMEBASE_INC_0                         (BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_INC_0)
#define REG_TSU_RWS_TIMEBASE_INC_0                           (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_TIMEBASE_INC_0))

#define ADDR_TSU_RWS_TIMEBASE_INC_1                          (0x6AU)
#define A_TSU_RWS_TIMEBASE_INC_1(ba)                         ((ba) + ADDR_TSU_RWS_TIMEBASE_INC_1)
#define R_TSU_RWS_TIMEBASE_INC_1(ba)                         (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_TIMEBASE_INC_1(ba)))
#define RES_TSU_RWS_TIMEBASE_INC_1                           (0x0U)
#define MSB_TSU_RWS_TIMEBASE_INC_1                           15
#define LSB_TSU_RWS_TIMEBASE_INC_1                           0
#define AADDR_TSU_RWS_TIMEBASE_INC_1                         (BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_INC_1)
#define REG_TSU_RWS_TIMEBASE_INC_1                           (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_TIMEBASE_INC_1))

#define ADDR_TSU_RWS_TIMEBASE_0                              (0x6CU)
#define A_TSU_RWS_TIMEBASE_0(ba)                             ((ba) + ADDR_TSU_RWS_TIMEBASE_0)
#define R_TSU_RWS_TIMEBASE_0(ba)                             (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_TIMEBASE_0(ba)))
#define RES_TSU_RWS_TIMEBASE_0                               (0x0U)
#define MSB_TSU_RWS_TIMEBASE_0                               15
#define LSB_TSU_RWS_TIMEBASE_0                               0
#define AADDR_TSU_RWS_TIMEBASE_0                             (BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_0)
#define REG_TSU_RWS_TIMEBASE_0                               (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_TIMEBASE_0))

#define ADDR_TSU_RWS_TIMEBASE_1                              (0x6EU)
#define A_TSU_RWS_TIMEBASE_1(ba)                             ((ba) + ADDR_TSU_RWS_TIMEBASE_1)
#define R_TSU_RWS_TIMEBASE_1(ba)                             (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_TIMEBASE_1(ba)))
#define RES_TSU_RWS_TIMEBASE_1                               (0x0U)
#define MSB_TSU_RWS_TIMEBASE_1                               15
#define LSB_TSU_RWS_TIMEBASE_1                               0
#define AADDR_TSU_RWS_TIMEBASE_1                             (BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_1)
#define REG_TSU_RWS_TIMEBASE_1                               (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_TIMEBASE_1))

#define ADDR_TSU_RWS_TIMEBASE_2                              (0x70U)
#define A_TSU_RWS_TIMEBASE_2(ba)                             ((ba) + ADDR_TSU_RWS_TIMEBASE_2)
#define R_TSU_RWS_TIMEBASE_2(ba)                             (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_TIMEBASE_2(ba)))
#define RES_TSU_RWS_TIMEBASE_2                               (0x0U)
#define MSB_TSU_RWS_TIMEBASE_2                               15
#define LSB_TSU_RWS_TIMEBASE_2                               0
#define AADDR_TSU_RWS_TIMEBASE_2                             (BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_2)
#define REG_TSU_RWS_TIMEBASE_2                               (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_TIMEBASE_2))

#define ADDR_TSU_RWS_TIMEBASE_3                              (0x72U)
#define A_TSU_RWS_TIMEBASE_3(ba)                             ((ba) + ADDR_TSU_RWS_TIMEBASE_3)
#define R_TSU_RWS_TIMEBASE_3(ba)                             (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_TIMEBASE_3(ba)))
#define RES_TSU_RWS_TIMEBASE_3                               (0x0U)
#define MSB_TSU_RWS_TIMEBASE_3                               15
#define LSB_TSU_RWS_TIMEBASE_3                               0
#define AADDR_TSU_RWS_TIMEBASE_3                             (BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_3)
#define REG_TSU_RWS_TIMEBASE_3                               (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_TIMEBASE_3))

#define ADDR_TSU_RWS_BASE_PHASE                              (0x74U)
#define A_TSU_RWS_BASE_PHASE(ba)                             ((ba) + ADDR_TSU_RWS_BASE_PHASE)
#define R_TSU_RWS_BASE_PHASE(ba)                             (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_BASE_PHASE(ba)))
#define RES_TSU_RWS_BASE_PHASE                               (0x0U)
#define MSB_TSU_RWS_BASE_PHASE                               15
#define LSB_TSU_RWS_BASE_PHASE                               0
#define AADDR_TSU_RWS_BASE_PHASE                             (BASE_ADDR_TSU + ADDR_TSU_RWS_BASE_PHASE)
#define REG_TSU_RWS_BASE_PHASE                               (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_BASE_PHASE))

#define ADDR_TSU_RWS_SUB_PHASE                               (0x76U)
#define A_TSU_RWS_SUB_PHASE(ba)                              ((ba) + ADDR_TSU_RWS_SUB_PHASE)
#define R_TSU_RWS_SUB_PHASE(ba)                              (*(volatile unsigned short *)((unsigned int)A_TSU_RWS_SUB_PHASE(ba)))
#define RES_TSU_RWS_SUB_PHASE                                (0x0U)
#define MSB_TSU_RWS_SUB_PHASE                                14
#define LSB_TSU_RWS_SUB_PHASE                                0
#define AADDR_TSU_RWS_SUB_PHASE                              (BASE_ADDR_TSU + ADDR_TSU_RWS_SUB_PHASE)
#define REG_TSU_RWS_SUB_PHASE                                (*(volatile unsigned short *)((unsigned int)AADDR_TSU_RWS_SUB_PHASE))




#endif
