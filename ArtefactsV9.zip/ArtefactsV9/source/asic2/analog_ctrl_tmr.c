/* FPGA Release: 10512 */
#include "analog_ctrl_tmr.h"

bool analog_ctrl_tmr_has_control(void){
  return (READ_REG_U16(AADDR_ANALOG_CTRL_TMR_STATUS) ? true : false);
}

void analog_ctrl_tmr_write(uint8_t adr, uint16_t data){
  WRITE_REG_16(AADDR_ANALOG_CTRL_TMR_ADDR, adr);
  WRITE_REG_16(AADDR_ANALOG_CTRL_TMR_DATA, data);
}

uint16_t analog_ctrl_tmr_read(uint8_t adr){
  WRITE_REG_16(AADDR_ANALOG_CTRL_TMR_ADDR, adr);
  return READ_REG_U16(AADDR_ANALOG_CTRL_TMR_DATA);
}
