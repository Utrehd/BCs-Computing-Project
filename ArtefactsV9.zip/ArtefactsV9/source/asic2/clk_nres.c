/* FPGA Release: 10512 */
#include "clk_nres.h"
#include "clk_nres_irq.h"
#include "utils.h"

//******************************************************************************
// HELPER FUNCTIONS
//******************************************************************************


//******************************************************************************
// CONFIG
//******************************************************************************

void clk_nres_unlock(void){
  clk_nres_guard_enable(CLK_NRES_0);
  clk_nres_set_cfg_sw_onoff_en(CLK_NRES_0, 0, 0, 0xFFFF);
  clk_nres_set_cfg_sw_onoff_en(CLK_NRES_0, 0, 1, 0xFFFF);
  clk_nres_set_cfg_sw_onoff_en(CLK_NRES_0, 0, 2, 0xFFFF);
  clk_nres_set_cfg_sw_onoff_en(CLK_NRES_0, 1, 0, 0xFFFF);
  clk_nres_set_cfg_sw_onoff_en(CLK_NRES_0, 1, 1, 0xFFFF);
  clk_nres_set_cfg_sw_onoff_en(CLK_NRES_0, 1, 2, 0xFFFF);  
  clk_nres_set_cfg_as_onoff_en(CLK_NRES_0, 0, 0xFF);
  clk_nres_set_cfg_as_onoff_en(CLK_NRES_0, 1, 0xFF);
}

void clk_nres_guard_enable(clk_nres_num_t sel) {
  WRITE_REG_16(sel + ADDR_CLK_NRES_GUARD, 0x00A2);
}

void clk_nres_guard_disable(clk_nres_num_t sel) {
  WRITE_REG_16(sel + ADDR_CLK_NRES_GUARD, 0x0000);
}

bool clk_nres_is_enabled(clk_nres_num_t sel) {
  return (bool) (READ_REG_U16(sel + ADDR_CLK_NRES_CFG_WRITE_ENABLED) & 0x0001);
}

void clk_nres_enable_wdog1_global_reset(bool val){
  uint16_t enable = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET);
  if (val) enable |=  1;
  else     enable &= ~1;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET, enable);
}

void clk_nres_enable_nres_peri0_off_acc(bool val){
  uint16_t enable = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET);
  if (val) enable |=   (uint16_t) BIT_CLK_NRES_CFG_RESET_PERI0_OFF_ACC;
  else     enable &= ~ (uint16_t) BIT_CLK_NRES_CFG_RESET_PERI0_OFF_ACC;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET, enable);
}

void clk_nres_enable_nres_peri1_off_acc(bool val){
  uint16_t enable = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET);
  if (val) enable |=   (uint16_t) BIT_CLK_NRES_CFG_RESET_PERI1_OFF_ACC;
  else     enable &= ~ (uint16_t) BIT_CLK_NRES_CFG_RESET_PERI1_OFF_ACC;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET, enable);
}

void clk_nres_enable_nres_perie_off_acc(bool val){
  uint16_t enable = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET);
  if (val) enable |=   (uint16_t) BIT_CLK_NRES_CFG_RESET_PERIE_OFF_ACC;
  else     enable &= ~ (uint16_t) BIT_CLK_NRES_CFG_RESET_PERIE_OFF_ACC;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET, enable);
}

void clk_nres_enable_nres_ccpu0_lockup(bool val){
  uint16_t enable = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET);
  if (val) enable |=   (uint16_t) BIT_CLK_NRES_CFG_RESET_CCPU0_LOCKUP;
  else     enable &= ~ (uint16_t) BIT_CLK_NRES_CFG_RESET_CCPU0_LOCKUP;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET, enable);
}

void clk_nres_enable_nres_acpu1_lockup(bool val){
  uint16_t enable = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET);
  if (val) enable |=   (uint16_t) BIT_CLK_NRES_CFG_RESET_ACPU1_LOCKUP;
  else     enable &= ~ (uint16_t) BIT_CLK_NRES_CFG_RESET_ACPU1_LOCKUP;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET, enable);
}

bool clk_nres_is_enable_wdog1_global_reset(void){
  return (bool) (READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET) & 0x0001);
}

void clk_nres_set_cfg_wdog1_nres_en(uint8_t nr, uint16_t mask){
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_0 + 2*nr, mask);
}

void clk_nres_set_cfg_wdog1_nres_en_as(uint8_t mask){
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_AS, (uint16_t) mask);
}

void clk_nres_sel_clk_root(clk_domain_t domain, clock_source_t clock_source) {
  clk_nres_cfg_t clk_nres_cfg;
  switch(domain){
  case AS_SWD_TSU:  
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS0_SWD_TSU);
    clk_nres_cfg.bf.clk_src = clock_source;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS0_SWD_TSU, clk_nres_cfg.val);
    break;
  case AS_USI0:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS1_USI0);
    clk_nres_cfg.bf.clk_src = clock_source;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS1_USI0, clk_nres_cfg.val);
    break;
  case AS_USI1:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS2_USI1);
    clk_nres_cfg.bf.clk_src = clock_source;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS2_USI1, clk_nres_cfg.val);
    break;
  case AS_HISPI:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS3_HISPI);
    clk_nres_cfg.bf.clk_src = clock_source;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS3_HISPI, clk_nres_cfg.val);
    break;
  case MAIN:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_M);
    clk_nres_cfg.bf.clk_src = clock_source;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_M, clk_nres_cfg.val);
    break;
  default:
      break;
  }
}

void clk_nres_set_clk_divider(clk_domain_t domain, uint8_t div){
  clk_nres_cfg_t clk_nres_cfg;
  switch(domain){
  case AS_SWD_TSU:  
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS0_SWD_TSU);
    clk_nres_cfg.bf.clk_div = div;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS0_SWD_TSU, clk_nres_cfg.val);
    break;
  case AS_USI0:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS1_USI0);
    clk_nres_cfg.bf.clk_div = div;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS1_USI0, clk_nres_cfg.val);
    break;
  case AS_USI1:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS2_USI1);
    clk_nres_cfg.bf.clk_div = div;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS2_USI1, clk_nres_cfg.val);
    break;
  case AS_HISPI:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS3_HISPI);
    clk_nres_cfg.bf.clk_div = div;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS3_HISPI, clk_nres_cfg.val);
    break;
  case MAIN:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_M);
    clk_nres_cfg.bf.clk_div = div;
    WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_M, clk_nres_cfg.val);
    break;
  default:
      break;
  }
}

void clk_nres_set_clk_rate(clk_rate_t clk_rate, uint8_t rate) {
  clk_nres_cfg_rate_t cfg_reg;
  cfg_reg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE);
  
  switch (clk_rate) {
  case high_rate:
      cfg_reg.bf.cfg_high_rate = rate;
      break;
  case low_rate_0:
      cfg_reg.bf.cfg_low_rate_0 = rate;
      break;
  case low_rate_1:
      cfg_reg.bf.cfg_low_rate_1 = rate;
      break;
  default:
      break;
  }  
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE, cfg_reg.val);
}

void clk_nres_set_rate_sel(clkpno_t clkpno, clk_rate_t clk_rate) {
  uint32_t rel_adr = 0;

  if (clkpno < CLKPNO_MASTERS) return;
  else clkpno -= CLKPNO_MASTERS;
  
  while (clkpno >= 8) {
    clkpno -= 8;
    rel_adr += 2;
  }
  
  uint16_t cfg_rate_sel = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE_SEL_0 + rel_adr);
  
  cfg_rate_sel &= ~(       3 << 2*clkpno); //delete old content and rewrite new selector
  cfg_rate_sel |=  (clk_rate << 2*clkpno);
  
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE_SEL_0 + rel_adr, cfg_rate_sel);
  
}

void clk_nres_set_cfg_sw_onoff_en(clk_nres_num_t sel, uint8_t wbbus, uint8_t nr, uint16_t mask) {
  if (wbbus == 0) WRITE_REG_16(sel + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0 + 2*nr, (uint16_t) mask);
  else            WRITE_REG_16(sel + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0 + 2*nr, (uint16_t) mask);
}

uint16_t clk_nres_get_cfg_sw_onoff_en(clk_nres_num_t sel, uint8_t wbbus, uint8_t nr) {
  if (wbbus == 0) return READ_REG_U16(sel + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0 + 2*nr);
  else            return READ_REG_U16(sel + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0 + 2*nr);
}

void clk_nres_set_cfg_as_onoff_en(clk_nres_num_t sel, uint8_t wbbus, uint8_t mask){
  if (wbbus == 0) WRITE_REG_16(sel + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS, (uint16_t) mask);
  else            WRITE_REG_16(sel + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS, (uint16_t) mask);
}

uint8_t clk_nres_get_cfg_as_onoff_en(clk_nres_num_t sel, uint8_t wbbus){
  if (wbbus == 0) return (uint8_t) READ_REG_U16(sel + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS);
    else          return (uint8_t) READ_REG_U16(sel + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS);
}

//******************************************************************************
// ANALOG
//******************************************************************************
void clk_nres_config_pll(clk_pll_src_t src, bool PD_N, uint8_t NR, uint8_t NF, uint8_t OD){
  // disable
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL0, 0);
  // config
  uint16_t cfg_pll0 = 0;
  if (src)  cfg_pll0 |=  BIT_CLK_NRES_CFG_ANA_PLL0_PLL_FIN_SRC;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL0, cfg_pll0);
  uint16_t cfg_pll1 = 0;
  cfg_pll1 |=  (OD & MSK_CLK_NRES_CFG_ANA_PLL1_PLL_OD) << SFT_CLK_NRES_CFG_ANA_PLL1_PLL_OD;
  cfg_pll1 |=  (NR & MSK_CLK_NRES_CFG_ANA_PLL1_PLL_NR) << SFT_CLK_NRES_CFG_ANA_PLL1_PLL_NR;
  cfg_pll1 |=  (NF & MSK_CLK_NRES_CFG_ANA_PLL1_PLL_NF) << SFT_CLK_NRES_CFG_ANA_PLL1_PLL_NF;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL1, cfg_pll1);
  // enable
  if (PD_N) cfg_pll0 |=  BIT_CLK_NRES_CFG_ANA_PLL0_PLL_PD_N;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL0, cfg_pll0);
}

void clk_nres_set_pll_oe(bool OE){
  uint16_t cfg_pll0 = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL0);
  if (OE) cfg_pll0 |=  BIT_CLK_NRES_CFG_ANA_PLL0_PLL_OE;
  else    cfg_pll0 &= ~BIT_CLK_NRES_CFG_ANA_PLL0_PLL_OE;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL0, cfg_pll0);
}

void clk_nres_set_rcosc_hf_enable(bool rcosc_hf_enable){
  clk_nres_cfg_ana_osc_t clk_nres_cfg_ana_osc; 
  clk_nres_cfg_ana_osc.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC);
  clk_nres_cfg_ana_osc.bf.rcosc_hf_pd_n = rcosc_hf_enable;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC, clk_nres_cfg_ana_osc.val);
}

void clk_nres_set_qosc_enable(bool qosc_enable){
  clk_nres_cfg_ana_osc_t clk_nres_cfg_ana_osc; 
  clk_nres_cfg_ana_osc.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC);
  clk_nres_cfg_ana_osc.bf.qosc_pd_n = qosc_enable;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC, clk_nres_cfg_ana_osc.val);
}

void clk_nres_set_qosc_strength(uint8_t qosc_strength){
  clk_nres_cfg_ana_osc_t clk_nres_cfg_ana_osc; 
  clk_nres_cfg_ana_osc.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC);
  clk_nres_cfg_ana_osc.bf.qosc_strength = qosc_strength;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC, clk_nres_cfg_ana_osc.val);
}

void clk_nres_set_qosc_clk_bypass(bool qosc_clk_bypass){
  clk_nres_cfg_ana_osc_t clk_nres_cfg_ana_osc; 
  clk_nres_cfg_ana_osc.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC);
  clk_nres_cfg_ana_osc.bf.qosc_clk_bypass = qosc_clk_bypass;
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC, clk_nres_cfg_ana_osc.val);
}

//******************************************************************************
// SW CONTROL
//******************************************************************************
void clk_nres_enable_clock_partition(clk_nres_num_t sel, clkpno_t clkpno, bool enable) {
  uint32_t rel_adr = ADDR_CLK_NRES_CLK_SW_ON_0;
  if (!enable) {
    rel_adr = ADDR_CLK_NRES_CLK_SW_OFF_0;
  }

  while (clkpno >= 16) {
    clkpno -= 16;
    rel_adr += 2;
  }
  
  WRITE_REG_16(sel + rel_adr, onehot16[(uint16_t) clkpno]);
}


void clk_nres_set_nreset(clkpno_t clkpno, bool nreset) {
  uint32_t rel_adr = 0;
  
  while (clkpno >= 16) {
    clkpno -= 16;
    rel_adr += 2;
  }
  
  uint16_t cfg = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_NRESET_SW_0 + rel_adr);
  
  if (nreset) {
    cfg |=  onehot16[(uint16_t) clkpno];
  } else {
    cfg &= ~onehot16[(uint16_t) clkpno];
  }
  
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_NRESET_SW_0 + rel_adr, cfg);
}

void clk_nres_enable_as_clock_domain(clk_nres_num_t sel, clk_domain_t as_clkpno, bool enable){
  uint32_t rel_adr = ADDR_CLK_NRES_CLK_SW_ON_AS;
  if (!enable) {
    rel_adr = ADDR_CLK_NRES_CLK_SW_OFF_AS;
  }
  WRITE_REG_16(sel + rel_adr, onehot16[(uint16_t) as_clkpno]);  
}

void clk_nres_set_as_nreset(clk_domain_t as_clkpno, bool nreset){
  uint16_t cfg = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_NRESET_AS);
  
  if (nreset) {
    cfg |=  onehot16[(uint16_t) as_clkpno];
  } else {
    cfg &= ~onehot16[(uint16_t) as_clkpno];
  }
  
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_NRESET_AS, cfg);
}

uint16_t  clk_nres_get_nres_sources(){
  return READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_NRESET_SOURCES);
}

void clk_nres_clear_nres_sources(uint16_t sources){
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_NRESET_SOURCES, sources);
}

void clk_nres_wake_cpu1(void){
  WRITE_REG_16(AADDR_CLK_NRES_0_CMD_CPU1_WAKE, 1);
}

//******************************************************************************
// CW 
//******************************************************************************
void clk_nres_get_cw_cfg(clk_cw_t cw, clk_nres_cfg_cw_t * cfg){
  cfg->val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0 + 2*cw);
}

void clk_nres_set_cw_cfg(clk_cw_t cw, clk_nres_cfg_cw_t cfg){
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0 + 2*cw, cfg.val);  
}

void clk_nres_set_cw_min(clk_cw_t cw, uint16_t min){
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0_MIN + 2*cw, min);
}

void clk_nres_set_cw_max(clk_cw_t cw, uint16_t max){
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0_MAX + 2*cw, max);
}

clk_nres_cfg_cw_t clk_nres_get_cfg_cw(clk_cw_t cw){
  clk_nres_cfg_cw_t cfg;
  cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0 + 2*cw);
  return cfg;
}

uint16_t clk_nres_get_cw_min(clk_cw_t cw){
  return READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0_MIN + 2*cw);
}

uint16_t clk_nres_get_cw_max(clk_cw_t cw){
  return READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0_MAX + 2*cw);
}

uint16_t clk_nres_get_cw_measurement(clk_cw_t cw){
  if (cw==0) return READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CW0_MEASUREMENT);
  else       return READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CW1_MEASUREMENT);
}

//******************************************************************************
// STATUS
//******************************************************************************

uint16_t clk_nres_get_clk_status(clk_nres_num_t sel, uint8_t nr) {
  return READ_REG_U16(sel + ADDR_CLK_NRES_CLK_STATUS_0 + 2*nr);
}


uint8_t clk_nres_get_clk_status_as(clk_nres_num_t sel) {
  return (uint8_t)(READ_REG_U16(sel + ADDR_CLK_NRES_CLK_STATUS_AS));
}

//******************************************************************************
// IRQ
//******************************************************************************

void clk_nres_set_irq_mask(clk_nres_irq_t irq, bool enable){  
  uint16_t irqs;
  irqs = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_IRQ_MASK);
  if (enable) {
      irqs |= onehot16[(uint16_t) irq];
  }
  else {
      irqs &= ~onehot16[(uint16_t) irq];
  }  
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_IRQ_MASK, irqs);
}

void clk_nres_enable_irq(clk_nres_irq_t irq, bool enable){  
  if (enable) WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_IRQ_VENABLE, irq);
  else WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_IRQ_VDISABLE, irq);
}

clk_nres_irq_status_t clk_nres_get_irq_status(void){
  clk_nres_irq_status_t status;
  status.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_IRQ_STATUS);
  return status;
}

void clk_nres_clear_all_irq_events(void){
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_IRQ_STATUS,0xFFFF);
}

clk_nres_irq_t clk_nres_get_pending_irq(void){
    return (clk_nres_irq_t) READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_IRQ_VNO);
}

void clk_nres_set_irq_vno(clk_nres_irq_t vno){
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_IRQ_VNO, vno);
}
