/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         analog_ctrl_bf.h
*
* @brief        Analog Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __ANALOG_CTRL_BF_H__
#define __ANALOG_CTRL_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_ANALOG_CTRL
#define BASE_ADDR_ANALOG_CTRL 0x40006480U
#endif

#define NUMBER_ANALOG_CTRL 1

/**
  * \brief This is an enum class for Analog Control instance
  *
  * \ingroup analog_ctrl
  */ 
typedef enum {
  ANALOG_CTRL                    = (int)BASE_ADDR_ANALOG_CTRL ///< This is instance Analog Control
} analog_ctrl_num_t;

// Register bit field definitions

/* ANALOG_CTRL_CAL_GUARD */

#define MSK_ANALOG_CTRL_CAL_GUARD                           (0xff)    /* [ 7:0] */

/**
  * \brief This structure describes Analog Control Access Protection
  *
  * \ingroup analog_ctrl
  */ 
typedef unsigned short analog_ctrl_cal_guard_t; ///< <B>bits 7:0</B> <br> Writing A2h with allok_in asserted will enable write access by software to the calibration (CAL_*) registers until either allok_in is deasserted or any other value than A2h is written to this register.


/* ANALOG_CTRL_CFG_ANA_PW_VDD3V3 */

#define MSK_ANALOG_CTRL_CFG_ANA_PW_VDD3V3                   (0x1)     /* [0] */

/**
  * \brief This structure describes Analog Control Power Watch
  *
  * \ingroup analog_ctrl
  */ 
typedef unsigned short analog_ctrl_cfg_ana_pw_vdd3v3_t; ///< <B>bit 0</B> <br> 1 : Monitor against 85% of 3.3V <br> 0: Monitor against 85% of 2.75V


/* ANALOG_CTRL_CFG_ANA_VREF */

#define MSK_ANALOG_CTRL_CFG_ANA_VREF                        (0x1)     /* [0] */

/**
  * \brief This structure describes Analog Control Voltage reference activation
  *
  * \ingroup analog_ctrl
  */ 
typedef unsigned short analog_ctrl_cfg_ana_vref_t; ///< <B>bit 0</B> <br> Turns on the 2.5V Reference output


/* ANALOG_CTRL_CAL_ANA_VREF */

#define MSK_ANALOG_CTRL_CAL_ANA_VREF_CAL_FINE               (0x1f)    /* [ 4:0] */
#define RES_ANALOG_CTRL_CAL_ANA_VREF_CAL_FINE               (0x0F)
#define SFT_ANALOG_CTRL_CAL_ANA_VREF_CAL_FINE               (0)
#define LSB_ANALOG_CTRL_CAL_ANA_VREF_CAL_FINE               (0)
#define MSB_ANALOG_CTRL_CAL_ANA_VREF_CAL_FINE               (4)
#define MSK_ANALOG_CTRL_CAL_ANA_VREF_CAL_ROUGH              (0xf)     /* [ 8:5] */
#define RES_ANALOG_CTRL_CAL_ANA_VREF_CAL_ROUGH              (0x7)
#define SFT_ANALOG_CTRL_CAL_ANA_VREF_CAL_ROUGH              (5)
#define LSB_ANALOG_CTRL_CAL_ANA_VREF_CAL_ROUGH              (5)
#define MSB_ANALOG_CTRL_CAL_ANA_VREF_CAL_ROUGH              (8)
#define MSK_ANALOG_CTRL_CAL_ANA_VREF_CAL_BG                 (0xf)     /* [12:9] */
#define RES_ANALOG_CTRL_CAL_ANA_VREF_CAL_BG                 (0x7)
#define SFT_ANALOG_CTRL_CAL_ANA_VREF_CAL_BG                 (9)
#define LSB_ANALOG_CTRL_CAL_ANA_VREF_CAL_BG                 (9)
#define MSB_ANALOG_CTRL_CAL_ANA_VREF_CAL_BG                 (12)

/**
  * \brief This structure describes Analog Control Voltage Regulators register
  *
  * \ingroup analog_ctrl
  */ 
typedef struct {
  unsigned short cal_fine                      :    5; ///< <B>bits4:0</B> <br> Fine calibration of the 2.5V Reference output
  unsigned short cal_rough                     :    4; ///< <B>bits 8:5</B> <br> Rough calibration of the 2.5V Reference output
  unsigned short cal_bg                        :    4; ///< <B>bits 12:9</B> <br> Calibration of Bandgap Temperature Coefficient
  unsigned short reserved                      :    3; ///< <B>bits 15:13</B> <br> Reserved
} analog_ctrl_cal_ana_vref_bf;

/**
  * \brief Conversion type between word and bit representation of Analog Control Voltage Regulators
  *
  * \ingroup analog_ctrl
  */ 
typedef union {
  unsigned short val;
  analog_ctrl_cal_ana_vref_bf bf;
} analog_ctrl_cal_ana_vref_t;


/* ANALOG_CTRL_CAL_ANA_IREF */

#define MSK_ANALOG_CTRL_CAL_ANA_IREF                        (0x1f)    /* [ 4:0] */

/**
  * \brief This structure describes Analog Control calibration internal current
  *
  * \ingroup analog_ctrl
  */ 
typedef unsigned short analog_ctrl_cal_ana_iref_t; ///< <B>bits 4:0</B> <br> Calibration of the internal bias currents


/* ANALOG_CTRL_CAL_ANA_HFOSC */

#define MSK_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_FINE              (0xff)    /* [ 7:0] */
#define RES_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_FINE              (0x00)
#define SFT_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_FINE              (0)
#define LSB_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_FINE              (0)
#define MSB_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_FINE              (7)
#define MSK_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_ROUGH             (0x7)     /* [10:8] */
#define RES_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_ROUGH             (0x0)
#define SFT_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_ROUGH             (8)
#define LSB_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_ROUGH             (8)
#define MSB_ANALOG_CTRL_CAL_ANA_HFOSC_CAL_ROUGH             (10)

/**
  * \brief This structure describes Analog Control High Frequency Oscilator register
  *
  * \ingroup analog_ctrl
  */ 
typedef struct {
  unsigned short cal_fine                      :    8; ///< <B>bits 7:0</B> <br> Fine calibration of the Oscillator <br> This points to the same Flipflops as FLL _SW_CTRL.sw_val
  unsigned short cal_rough                     :    3; ///< <B>bits 10:8</B> <br> Rough calibration of the Oscillator
  unsigned short reserved                      :    5; ///< <B>bits 15:11</B> <br> Reserved
} analog_ctrl_cal_ana_hfosc_bf;

/**
  * \brief Conversion type between word and bit representation of Analog Control High Frequency Oscilator
  *
  * \ingroup analog_ctrl
  */ 
typedef union {
  unsigned short val;
  analog_ctrl_cal_ana_hfosc_bf bf;
} analog_ctrl_cal_ana_hfosc_t;


/* ANALOG_CTRL_CAL_ANA_PLL */

#define MSK_ANALOG_CTRL_CAL_ANA_PLL_CAL_VCO                 (0x3)     /* [ 1:0] */
#define RES_ANALOG_CTRL_CAL_ANA_PLL_CAL_VCO                 (0x1)
#define SFT_ANALOG_CTRL_CAL_ANA_PLL_CAL_VCO                 (0)
#define LSB_ANALOG_CTRL_CAL_ANA_PLL_CAL_VCO                 (0)
#define MSB_ANALOG_CTRL_CAL_ANA_PLL_CAL_VCO                 (1)
#define MSK_ANALOG_CTRL_CAL_ANA_PLL_CAL_CP_BIAS             (0x1)     /* [2] */
#define RES_ANALOG_CTRL_CAL_ANA_PLL_CAL_CP_BIAS             (0x1)
#define SFT_ANALOG_CTRL_CAL_ANA_PLL_CAL_CP_BIAS             (2)
#define LSB_ANALOG_CTRL_CAL_ANA_PLL_CAL_CP_BIAS             (2)
#define MSB_ANALOG_CTRL_CAL_ANA_PLL_CAL_CP_BIAS             (2)
#define BIT_ANALOG_CTRL_CAL_ANA_PLL_CAL_CP_BIAS             (0x4)     /* [2] */

/**
  * \brief This structure describes Analog Control PLL register
  *
  * \ingroup analog_ctrl
  */
typedef struct {
  unsigned short cal_vco                       :    2; ///< <B>bits 1:0</B> <br> Calibration of VCO
  unsigned short cal_cp_bias                   :    1; ///< <B>bit 2</B> <br> Calibration of Chargpump Biassing <br> 0: constant <br> 1: adaptive
  unsigned short reserved                      :   13; ///< <B>bits 15:3</B> <br> Reserved
} analog_ctrl_cal_ana_pll_bf;

/**
  * \brief Conversion type between word and bit representation of Analog Control PLL
  *
  * \ingroup analog_ctrl
  */ 
typedef union {
  unsigned short val;
  analog_ctrl_cal_ana_pll_bf bf;
} analog_ctrl_cal_ana_pll_t;


/* ANALOG_CTRL_FLL_GUARD */

#define MSK_ANALOG_CTRL_FLL_GUARD                           (0xff)    /* [ 7:0] */

/**
  * \brief This structure describes Analog Control FLL Guard
  *
  * \ingroup analog_ctrl
  */ 
typedef unsigned short analog_ctrl_fll_guard_t; ///< <B>bits 7:0</B> <br> Writing A2h with allok_in asserted will enable write access by software to the FLL_* registers until either allok_in is deasserted or any other value than A2h is written to this register.


/* ANALOG_CTRL_FLL_CONFIG */

#define MSK_ANALOG_CTRL_FLL_CONFIG_EVAL_RATE                (0x1f)    /* [ 4:0] */
#define RES_ANALOG_CTRL_FLL_CONFIG_EVAL_RATE                (0x00)
#define SFT_ANALOG_CTRL_FLL_CONFIG_EVAL_RATE                (0)
#define LSB_ANALOG_CTRL_FLL_CONFIG_EVAL_RATE                (0)
#define MSB_ANALOG_CTRL_FLL_CONFIG_EVAL_RATE                (4)
#define MSK_ANALOG_CTRL_FLL_CONFIG_FREEZE                   (0x1)     /* [15] */
#define RES_ANALOG_CTRL_FLL_CONFIG_FREEZE                   (0x0)
#define SFT_ANALOG_CTRL_FLL_CONFIG_FREEZE                   (15)
#define LSB_ANALOG_CTRL_FLL_CONFIG_FREEZE                   (15)
#define MSB_ANALOG_CTRL_FLL_CONFIG_FREEZE                   (15)
#define BIT_ANALOG_CTRL_FLL_CONFIG_FREEZE                   (0x8000)  /* [15] */

/**
  * \brief This structure describes Analog Control FLL register
  *
  * \ingroup analog_ctrl
  */
typedef struct {
  unsigned short eval_rate                     :    5; ///< <B>bits 4:0</B> <br> Clk divider of lf-osc "1 << eval_rate" clock-cycles of lf clock are measured
  unsigned short reserved14                    :   10; ///< <B>bits 14:5</B> <br> Do not change trim_val
  unsigned short freeze                        :    1; ///< <B>bit 15</B> <br> Reserved
} analog_ctrl_fll_config_bf;

/**
  * \brief Conversion type between word and bit representation of Analog Control FLL
  *
  * \ingroup analog_ctrl
  */ 
typedef union {
  unsigned short val;
  analog_ctrl_fll_config_bf bf;
} analog_ctrl_fll_config_t;


/* ANALOG_CTRL_FLL_EVAL_VAL */

#define MSK_ANALOG_CTRL_FLL_EVAL_VAL                        (0xffff)  /* [15:0] */

/**
  * \brief This structure describes Analog Control FLL evaluation value
  *
  * \ingroup analog_ctrl
  */
typedef unsigned short analog_ctrl_fll_eval_val_t; ///< <B>bits 15:0</B> <br> Measured number of HF clock-cycles during divided LF clock-cycles


/* ANALOG_CTRL_FLL_SET_VAL */

#define MSK_ANALOG_CTRL_FLL_SET_VAL                         (0xffff)  /* [15:0] */

/**
  * \brief This structure describes Analog Control FLL value
  *
  * \ingroup analog_ctrl
  */
typedef unsigned short analog_ctrl_fll_set_val_t; ///< <B>bits 15:0</B> <br> Target number of HF clock-cycles during divided LF clock-cycles


/* ANALOG_CTRL_FLL_SET_RANGE */

#define MSK_ANALOG_CTRL_FLL_SET_RANGE                       (0xffff)  /* [15:0] */

/**
  * \brief This structure describes Analog Control FLL range
  *
  * \ingroup analog_ctrl
  */
typedef unsigned short analog_ctrl_fll_set_range_t; ///< <B>bits 15:0</B> <br> Allowed range for target


/* ANALOG_CTRL_FLL_SW_CTRL */

#define MSK_ANALOG_CTRL_FLL_SW_CTRL_SW_VAL                  (0xff)    /* [ 7:0] */
#define RES_ANALOG_CTRL_FLL_SW_CTRL_SW_VAL                  (0x00)
#define SFT_ANALOG_CTRL_FLL_SW_CTRL_SW_VAL                  (0)
#define LSB_ANALOG_CTRL_FLL_SW_CTRL_SW_VAL                  (0)
#define MSB_ANALOG_CTRL_FLL_SW_CTRL_SW_VAL                  (7)
#define MSK_ANALOG_CTRL_FLL_SW_CTRL_USE_SW                  (0x1)     /* [15] */
#define RES_ANALOG_CTRL_FLL_SW_CTRL_USE_SW                  (0x1)
#define SFT_ANALOG_CTRL_FLL_SW_CTRL_USE_SW                  (15)
#define LSB_ANALOG_CTRL_FLL_SW_CTRL_USE_SW                  (15)
#define MSB_ANALOG_CTRL_FLL_SW_CTRL_USE_SW                  (15)
#define BIT_ANALOG_CTRL_FLL_SW_CTRL_USE_SW                  (0x8000)  /* [15] */

/**
  * \brief This structure describes Analog Control FLL Software Control register
  *
  * \ingroup analog_ctrl
  */
typedef struct {
  unsigned short sw_val                        :    8; ///< <B>bits 7:0</B> <br> Trim_val when use_sw = 1
  unsigned short reserved14                    :    7; ///< <B>bits 14:8</B> <br> 1: enable software control trim_val = sw_val
  unsigned short use_sw                        :    1; ///< <B>bit 15</B> <br> Reserved
} analog_ctrl_fll_sw_ctrl_bf;

/**
  * \brief Conversion type between word and bit representation of Analog Control FLL Software Control
  *
  * \ingroup analog_ctrl
  */ 
typedef union {
  unsigned short val;
  analog_ctrl_fll_sw_ctrl_bf bf;
} analog_ctrl_fll_sw_ctrl_t;


/* ANALOG_CTRL_FLL_TRIM_VAL */

#define MSK_ANALOG_CTRL_FLL_TRIM_VAL                        (0xff)    /* [ 7:0] */

/**
  * \brief This structure describes Analog Control FLL trim value
  *
  * \ingroup analog_ctrl
  */
typedef unsigned short analog_ctrl_fll_trim_val_t; ///< <B>bits 7:0</B> <br> Current value applied to osc


/* ANALOG_CTRL_FLL_STATUS */

#define MSK_ANALOG_CTRL_FLL_STATUS_EVAL_GT                  (0x1)     /* [0] */
#define RES_ANALOG_CTRL_FLL_STATUS_EVAL_GT                  (0x0)
#define SFT_ANALOG_CTRL_FLL_STATUS_EVAL_GT                  (0)
#define LSB_ANALOG_CTRL_FLL_STATUS_EVAL_GT                  (0)
#define MSB_ANALOG_CTRL_FLL_STATUS_EVAL_GT                  (0)
#define BIT_ANALOG_CTRL_FLL_STATUS_EVAL_GT                  (0x1)     /* [0] */
#define MSK_ANALOG_CTRL_FLL_STATUS_EVAL_LW                  (0x1)     /* [1] */
#define RES_ANALOG_CTRL_FLL_STATUS_EVAL_LW                  (0x0)
#define SFT_ANALOG_CTRL_FLL_STATUS_EVAL_LW                  (1)
#define LSB_ANALOG_CTRL_FLL_STATUS_EVAL_LW                  (1)
#define MSB_ANALOG_CTRL_FLL_STATUS_EVAL_LW                  (1)
#define BIT_ANALOG_CTRL_FLL_STATUS_EVAL_LW                  (0x2)     /* [1] */

/**
  * \brief This structure describes Analog Control FLL Status
  *
  * \ingroup analog_ctrl
  */
typedef struct {
  unsigned short eval_gt                       :    1; ///< <B>bit 0</B> <br> Osc is too fast
  unsigned short eval_lw                       :    1; ///< <B>bit 1</B> <br> Osc is too slow
  unsigned short reserved                      :   14; ///< <B>bits 15:2</B> <br> Reserved
} analog_ctrl_fll_status_bf;

/**
  * \brief Conversion type between word and bit representation of Analog Control FLL Status
  *
  * \ingroup analog_ctrl
  */ 
typedef union {
  unsigned short val;
  analog_ctrl_fll_status_bf bf;
} analog_ctrl_fll_status_t;


/* ANALOG_CTRL_TMR_ADDR */

#define MSK_ANALOG_CTRL_TMR_ADDR                            (0xffff)  /* [15:0] */

/**
  * \brief This structure describes Analog Control Testmode Registers address
  *
  * \ingroup analog_ctrl
  */
typedef unsigned short analog_ctrl_tmr_addr_t; ///< <B>bits 15:0</B> <br> TMR address


/* ANALOG_CTRL_TMR_DATA */

#define MSK_ANALOG_CTRL_TMR_DATA                            (0xffff)  /* [15:0] */

/**
  * \brief This structure describes Analog Control Testmode Registers data
  *
  * \ingroup analog_ctrl
  */
typedef unsigned short analog_ctrl_tmr_data_t; ///< <B>bits 15:0</B> <br> TMR data


/* ANALOG_CTRL_TMR_STATUS */

#define MSK_ANALOG_CTRL_TMR_STATUS                          (0x1)     /* [0] */

/**
  * \brief This structure describes Analog Control Testmode Registers control
  *
  * \ingroup analog_ctrl
  */
typedef unsigned short analog_ctrl_tmr_status_t; ///< <B>bit 0</B> <br> 1: CPU has control


/* ANALOG_CTRL_CAL_SARADC_CORR */

#define MSK_ANALOG_CTRL_CAL_SARADC_CORR                     (0xffff)  /* [15:0] */

/**
  * \brief This structure describes Analog Control SARADC
  *
  * \ingroup analog_ctrl
  */
typedef unsigned short analog_ctrl_cal_saradc_corr_t; ///< <B>bits 15:0</B> <br> Calibration of SARADC (signed)



// Register definitions for module
// Instance base address BASE_ADDR_ANALOG_CTRL 0x40006480U ... 

#define ADDR_ANALOG_CTRL_CAL_GUARD                           (0x00U)
#define A_ANALOG_CTRL_CAL_GUARD(ba)                          ((ba) + ADDR_ANALOG_CTRL_CAL_GUARD)
#define R_ANALOG_CTRL_CAL_GUARD(ba)                          (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CAL_GUARD(ba)))
#define RES_ANALOG_CTRL_CAL_GUARD                            (0x0U)
#define MSB_ANALOG_CTRL_CAL_GUARD                            7
#define LSB_ANALOG_CTRL_CAL_GUARD                            0
#define AADDR_ANALOG_CTRL_CAL_GUARD                          (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CAL_GUARD)
#define REG_ANALOG_CTRL_CAL_GUARD                            (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CAL_GUARD))

#define ADDR_ANALOG_CTRL_CFG_ANA_PW_VDD3V3                   (0x02U)
#define A_ANALOG_CTRL_CFG_ANA_PW_VDD3V3(ba)                  ((ba) + ADDR_ANALOG_CTRL_CFG_ANA_PW_VDD3V3)
#define R_ANALOG_CTRL_CFG_ANA_PW_VDD3V3(ba)                  (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CFG_ANA_PW_VDD3V3(ba)))
#define RES_ANALOG_CTRL_CFG_ANA_PW_VDD3V3                    (0x0U)
#define MSB_ANALOG_CTRL_CFG_ANA_PW_VDD3V3                    0
#define LSB_ANALOG_CTRL_CFG_ANA_PW_VDD3V3                    0
#define AADDR_ANALOG_CTRL_CFG_ANA_PW_VDD3V3                  (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CFG_ANA_PW_VDD3V3)
#define REG_ANALOG_CTRL_CFG_ANA_PW_VDD3V3                    (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CFG_ANA_PW_VDD3V3))

#define ADDR_ANALOG_CTRL_CFG_ANA_VREF                        (0x04U)
#define A_ANALOG_CTRL_CFG_ANA_VREF(ba)                       ((ba) + ADDR_ANALOG_CTRL_CFG_ANA_VREF)
#define R_ANALOG_CTRL_CFG_ANA_VREF(ba)                       (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CFG_ANA_VREF(ba)))
#define RES_ANALOG_CTRL_CFG_ANA_VREF                         (0x0U)
#define MSB_ANALOG_CTRL_CFG_ANA_VREF                         0
#define LSB_ANALOG_CTRL_CFG_ANA_VREF                         0
#define AADDR_ANALOG_CTRL_CFG_ANA_VREF                       (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CFG_ANA_VREF)
#define REG_ANALOG_CTRL_CFG_ANA_VREF                         (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CFG_ANA_VREF))

#define ADDR_ANALOG_CTRL_CAL_ANA_VREF                        (0x06U)
#define A_ANALOG_CTRL_CAL_ANA_VREF(ba)                       ((ba) + ADDR_ANALOG_CTRL_CAL_ANA_VREF)
#define R_ANALOG_CTRL_CAL_ANA_VREF(ba)                       (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CAL_ANA_VREF(ba)))
#define RES_ANALOG_CTRL_CAL_ANA_VREF                         (0xeefU)
#define MSB_ANALOG_CTRL_CAL_ANA_VREF                         12
#define LSB_ANALOG_CTRL_CAL_ANA_VREF                         0
#define AADDR_ANALOG_CTRL_CAL_ANA_VREF                       (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CAL_ANA_VREF)
#define REG_ANALOG_CTRL_CAL_ANA_VREF                         (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CAL_ANA_VREF))

#define ADDR_ANALOG_CTRL_CAL_ANA_IREF                        (0x08U)
#define A_ANALOG_CTRL_CAL_ANA_IREF(ba)                       ((ba) + ADDR_ANALOG_CTRL_CAL_ANA_IREF)
#define R_ANALOG_CTRL_CAL_ANA_IREF(ba)                       (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CAL_ANA_IREF(ba)))
#define RES_ANALOG_CTRL_CAL_ANA_IREF                         (0xfU)
#define MSB_ANALOG_CTRL_CAL_ANA_IREF                         4
#define LSB_ANALOG_CTRL_CAL_ANA_IREF                         0
#define AADDR_ANALOG_CTRL_CAL_ANA_IREF                       (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CAL_ANA_IREF)
#define REG_ANALOG_CTRL_CAL_ANA_IREF                         (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CAL_ANA_IREF))

#define ADDR_ANALOG_CTRL_CAL_ANA_HFOSC                       (0x0AU)
#define A_ANALOG_CTRL_CAL_ANA_HFOSC(ba)                      ((ba) + ADDR_ANALOG_CTRL_CAL_ANA_HFOSC)
#define R_ANALOG_CTRL_CAL_ANA_HFOSC(ba)                      (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CAL_ANA_HFOSC(ba)))
#define RES_ANALOG_CTRL_CAL_ANA_HFOSC                        (0x0U)
#define MSB_ANALOG_CTRL_CAL_ANA_HFOSC                        10
#define LSB_ANALOG_CTRL_CAL_ANA_HFOSC                        0
#define AADDR_ANALOG_CTRL_CAL_ANA_HFOSC                      (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CAL_ANA_HFOSC)
#define REG_ANALOG_CTRL_CAL_ANA_HFOSC                        (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CAL_ANA_HFOSC))

#define ADDR_ANALOG_CTRL_CAL_ANA_PLL                         (0x0CU)
#define A_ANALOG_CTRL_CAL_ANA_PLL(ba)                        ((ba) + ADDR_ANALOG_CTRL_CAL_ANA_PLL)
#define R_ANALOG_CTRL_CAL_ANA_PLL(ba)                        (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CAL_ANA_PLL(ba)))
#define RES_ANALOG_CTRL_CAL_ANA_PLL                          (0x5U)
#define MSB_ANALOG_CTRL_CAL_ANA_PLL                          2
#define LSB_ANALOG_CTRL_CAL_ANA_PLL                          0
#define AADDR_ANALOG_CTRL_CAL_ANA_PLL                        (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CAL_ANA_PLL)
#define REG_ANALOG_CTRL_CAL_ANA_PLL                          (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CAL_ANA_PLL))

#define ADDR_ANALOG_CTRL_FLL_GUARD                           (0x10U)
#define A_ANALOG_CTRL_FLL_GUARD(ba)                          ((ba) + ADDR_ANALOG_CTRL_FLL_GUARD)
#define R_ANALOG_CTRL_FLL_GUARD(ba)                          (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_FLL_GUARD(ba)))
#define RES_ANALOG_CTRL_FLL_GUARD                            (0x0U)
#define MSB_ANALOG_CTRL_FLL_GUARD                            7
#define LSB_ANALOG_CTRL_FLL_GUARD                            0
#define AADDR_ANALOG_CTRL_FLL_GUARD                          (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_GUARD)
#define REG_ANALOG_CTRL_FLL_GUARD                            (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_FLL_GUARD))

#define ADDR_ANALOG_CTRL_FLL_CONFIG                          (0x12U)
#define A_ANALOG_CTRL_FLL_CONFIG(ba)                         ((ba) + ADDR_ANALOG_CTRL_FLL_CONFIG)
#define R_ANALOG_CTRL_FLL_CONFIG(ba)                         (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_FLL_CONFIG(ba)))
#define RES_ANALOG_CTRL_FLL_CONFIG                           (0x0U)
#define MSB_ANALOG_CTRL_FLL_CONFIG                           15
#define LSB_ANALOG_CTRL_FLL_CONFIG                           0
#define AADDR_ANALOG_CTRL_FLL_CONFIG                         (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_CONFIG)
#define REG_ANALOG_CTRL_FLL_CONFIG                           (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_FLL_CONFIG))

#define ADDR_ANALOG_CTRL_FLL_EVAL_VAL                        (0x14U)
#define A_ANALOG_CTRL_FLL_EVAL_VAL(ba)                       ((ba) + ADDR_ANALOG_CTRL_FLL_EVAL_VAL)
#define R_ANALOG_CTRL_FLL_EVAL_VAL(ba)                       (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_FLL_EVAL_VAL(ba)))
#define RES_ANALOG_CTRL_FLL_EVAL_VAL                         (0x0U)
#define MSB_ANALOG_CTRL_FLL_EVAL_VAL                         15
#define LSB_ANALOG_CTRL_FLL_EVAL_VAL                         0
#define AADDR_ANALOG_CTRL_FLL_EVAL_VAL                       (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_EVAL_VAL)
#define REG_ANALOG_CTRL_FLL_EVAL_VAL                         (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_FLL_EVAL_VAL))

#define ADDR_ANALOG_CTRL_FLL_SET_VAL                         (0x16U)
#define A_ANALOG_CTRL_FLL_SET_VAL(ba)                        ((ba) + ADDR_ANALOG_CTRL_FLL_SET_VAL)
#define R_ANALOG_CTRL_FLL_SET_VAL(ba)                        (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_FLL_SET_VAL(ba)))
#define RES_ANALOG_CTRL_FLL_SET_VAL                          (0x0U)
#define MSB_ANALOG_CTRL_FLL_SET_VAL                          15
#define LSB_ANALOG_CTRL_FLL_SET_VAL                          0
#define AADDR_ANALOG_CTRL_FLL_SET_VAL                        (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SET_VAL)
#define REG_ANALOG_CTRL_FLL_SET_VAL                          (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_FLL_SET_VAL))

#define ADDR_ANALOG_CTRL_FLL_SET_RANGE                       (0x18U)
#define A_ANALOG_CTRL_FLL_SET_RANGE(ba)                      ((ba) + ADDR_ANALOG_CTRL_FLL_SET_RANGE)
#define R_ANALOG_CTRL_FLL_SET_RANGE(ba)                      (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_FLL_SET_RANGE(ba)))
#define RES_ANALOG_CTRL_FLL_SET_RANGE                        (0x0U)
#define MSB_ANALOG_CTRL_FLL_SET_RANGE                        15
#define LSB_ANALOG_CTRL_FLL_SET_RANGE                        0
#define AADDR_ANALOG_CTRL_FLL_SET_RANGE                      (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SET_RANGE)
#define REG_ANALOG_CTRL_FLL_SET_RANGE                        (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_FLL_SET_RANGE))

#define ADDR_ANALOG_CTRL_FLL_SW_CTRL                         (0x1AU)
#define A_ANALOG_CTRL_FLL_SW_CTRL(ba)                        ((ba) + ADDR_ANALOG_CTRL_FLL_SW_CTRL)
#define R_ANALOG_CTRL_FLL_SW_CTRL(ba)                        (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_FLL_SW_CTRL(ba)))
#define RES_ANALOG_CTRL_FLL_SW_CTRL                          (0x8000U)
#define MSB_ANALOG_CTRL_FLL_SW_CTRL                          15
#define LSB_ANALOG_CTRL_FLL_SW_CTRL                          0
#define AADDR_ANALOG_CTRL_FLL_SW_CTRL                        (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SW_CTRL)
#define REG_ANALOG_CTRL_FLL_SW_CTRL                          (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_FLL_SW_CTRL))

#define ADDR_ANALOG_CTRL_FLL_TRIM_VAL                        (0x1CU)
#define A_ANALOG_CTRL_FLL_TRIM_VAL(ba)                       ((ba) + ADDR_ANALOG_CTRL_FLL_TRIM_VAL)
#define R_ANALOG_CTRL_FLL_TRIM_VAL(ba)                       (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_FLL_TRIM_VAL(ba)))
#define RES_ANALOG_CTRL_FLL_TRIM_VAL                         (0x0U)
#define MSB_ANALOG_CTRL_FLL_TRIM_VAL                         7
#define LSB_ANALOG_CTRL_FLL_TRIM_VAL                         0
#define AADDR_ANALOG_CTRL_FLL_TRIM_VAL                       (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_TRIM_VAL)
#define REG_ANALOG_CTRL_FLL_TRIM_VAL                         (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_FLL_TRIM_VAL))

#define ADDR_ANALOG_CTRL_FLL_STATUS                          (0x1EU)
#define A_ANALOG_CTRL_FLL_STATUS(ba)                         ((ba) + ADDR_ANALOG_CTRL_FLL_STATUS)
#define R_ANALOG_CTRL_FLL_STATUS(ba)                         (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_FLL_STATUS(ba)))
#define RES_ANALOG_CTRL_FLL_STATUS                           (0x0U)
#define MSB_ANALOG_CTRL_FLL_STATUS                           1
#define LSB_ANALOG_CTRL_FLL_STATUS                           0
#define AADDR_ANALOG_CTRL_FLL_STATUS                         (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_STATUS)
#define REG_ANALOG_CTRL_FLL_STATUS                           (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_FLL_STATUS))

#define ADDR_ANALOG_CTRL_TMR_ADDR                            (0x20U)
#define A_ANALOG_CTRL_TMR_ADDR(ba)                           ((ba) + ADDR_ANALOG_CTRL_TMR_ADDR)
#define R_ANALOG_CTRL_TMR_ADDR(ba)                           (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_TMR_ADDR(ba)))
#define RES_ANALOG_CTRL_TMR_ADDR                             (0x0U)
#define MSB_ANALOG_CTRL_TMR_ADDR                             15
#define LSB_ANALOG_CTRL_TMR_ADDR                             0
#define AADDR_ANALOG_CTRL_TMR_ADDR                           (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_TMR_ADDR)
#define REG_ANALOG_CTRL_TMR_ADDR                             (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_TMR_ADDR))

#define ADDR_ANALOG_CTRL_TMR_DATA                            (0x22U)
#define A_ANALOG_CTRL_TMR_DATA(ba)                           ((ba) + ADDR_ANALOG_CTRL_TMR_DATA)
#define R_ANALOG_CTRL_TMR_DATA(ba)                           (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_TMR_DATA(ba)))
#define RES_ANALOG_CTRL_TMR_DATA                             (0x0U)
#define MSB_ANALOG_CTRL_TMR_DATA                             15
#define LSB_ANALOG_CTRL_TMR_DATA                             0
#define AADDR_ANALOG_CTRL_TMR_DATA                           (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_TMR_DATA)
#define REG_ANALOG_CTRL_TMR_DATA                             (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_TMR_DATA))

#define ADDR_ANALOG_CTRL_TMR_STATUS                          (0x24U)
#define A_ANALOG_CTRL_TMR_STATUS(ba)                         ((ba) + ADDR_ANALOG_CTRL_TMR_STATUS)
#define R_ANALOG_CTRL_TMR_STATUS(ba)                         (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_TMR_STATUS(ba)))
#define RES_ANALOG_CTRL_TMR_STATUS                           (0x0U)
#define MSB_ANALOG_CTRL_TMR_STATUS                           0
#define LSB_ANALOG_CTRL_TMR_STATUS                           0
#define AADDR_ANALOG_CTRL_TMR_STATUS                         (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_TMR_STATUS)
#define REG_ANALOG_CTRL_TMR_STATUS                           (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_TMR_STATUS))

#define ADDR_ANALOG_CTRL_CAL_SARADC_CORR11                   (0x26U)
#define A_ANALOG_CTRL_CAL_SARADC_CORR11(ba)                  ((ba) + ADDR_ANALOG_CTRL_CAL_SARADC_CORR11)
#define R_ANALOG_CTRL_CAL_SARADC_CORR11(ba)                  (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CAL_SARADC_CORR11(ba)))
#define RES_ANALOG_CTRL_CAL_SARADC_CORR11                    (0x0U)
#define MSB_ANALOG_CTRL_CAL_SARADC_CORR11                    15
#define LSB_ANALOG_CTRL_CAL_SARADC_CORR11                    0
#define AADDR_ANALOG_CTRL_CAL_SARADC_CORR11                  (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CAL_SARADC_CORR11)
#define REG_ANALOG_CTRL_CAL_SARADC_CORR11                    (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CAL_SARADC_CORR11))

#define ADDR_ANALOG_CTRL_CAL_SARADC_CORR10                   (0x28U)
#define A_ANALOG_CTRL_CAL_SARADC_CORR10(ba)                  ((ba) + ADDR_ANALOG_CTRL_CAL_SARADC_CORR10)
#define R_ANALOG_CTRL_CAL_SARADC_CORR10(ba)                  (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CAL_SARADC_CORR10(ba)))
#define RES_ANALOG_CTRL_CAL_SARADC_CORR10                    (0x0U)
#define MSB_ANALOG_CTRL_CAL_SARADC_CORR10                    15
#define LSB_ANALOG_CTRL_CAL_SARADC_CORR10                    0
#define AADDR_ANALOG_CTRL_CAL_SARADC_CORR10                  (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CAL_SARADC_CORR10)
#define REG_ANALOG_CTRL_CAL_SARADC_CORR10                    (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CAL_SARADC_CORR10))

#define ADDR_ANALOG_CTRL_CAL_SARADC_CORR09                   (0x2AU)
#define A_ANALOG_CTRL_CAL_SARADC_CORR09(ba)                  ((ba) + ADDR_ANALOG_CTRL_CAL_SARADC_CORR09)
#define R_ANALOG_CTRL_CAL_SARADC_CORR09(ba)                  (*(volatile unsigned short *)((unsigned int)A_ANALOG_CTRL_CAL_SARADC_CORR09(ba)))
#define RES_ANALOG_CTRL_CAL_SARADC_CORR09                    (0x0U)
#define MSB_ANALOG_CTRL_CAL_SARADC_CORR09                    15
#define LSB_ANALOG_CTRL_CAL_SARADC_CORR09                    0
#define AADDR_ANALOG_CTRL_CAL_SARADC_CORR09                  (BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_CAL_SARADC_CORR09)
#define REG_ANALOG_CTRL_CAL_SARADC_CORR09                    (*(volatile unsigned short *)((unsigned int)AADDR_ANALOG_CTRL_CAL_SARADC_CORR09))




#endif
