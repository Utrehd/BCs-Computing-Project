/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         usi_uart_dma_api_errors.h
*
* @brief        Error handler for USI UART DMA API functions
*
* @author       Cid Mateo
*
********************************************************************************
*
********************************************************************************
********************************************************************************
*/

/**
 * \ingroup error_api
 */
#ifndef __EL_CTRL_API_ERRORS__
#define __EL_CTRL_API_ERRORS__

#define EL_CTRL_API_ERRORS_CODES                                          \
  /**                                                                          \
   * USI UART DMA TX FIFO is overloaded                                        \
   */                                                                          \
  eError_el_ctrl_api_no_recv_byte                                     

#endif
 
