/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         access_control_bf.h
*
* @brief        Access Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __ACCESS_CONTROL_BF_H__
#define __ACCESS_CONTROL_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_ACCESS_CONTROL
#define BASE_ADDR_ACCESS_CONTROL 0x40006380U
#endif

#define NUMBER_ACCESS_CONTROL 1

/**
  * \brief This is an enum class for Access Control instance
  *
  * \ingroup access_control
  */
typedef enum {
  ACCESS_CONTROL                 = (int)BASE_ADDR_ACCESS_CONTROL ///< this is instance Access Control
} access_control_num_t;

// Register bit field definitions

/* ACCESS_CONTROL_M0_M1_M3_M7 */

#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD              (0x1)     /* [0] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD              (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD              (0)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD              (0)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD              (0)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD              (0x1)     /* [0] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_WR              (0x1)     /* [1] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_WR              (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_WR              (1)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_WR              (1)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_WR              (1)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_WR              (0x2)     /* [1] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD              (0x1)     /* [2] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD              (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD              (2)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD              (2)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD              (2)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD              (0x4)     /* [2] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_WR              (0x1)     /* [3] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_WR              (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_WR              (3)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_WR              (3)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_WR              (3)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_WR              (0x8)     /* [3] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD              (0x1)     /* [4] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD              (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD              (4)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD              (4)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD              (4)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD              (0x10)    /* [4] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_RAME_WR              (0x1)     /* [5] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_RAME_WR              (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAME_WR              (5)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_RAME_WR              (5)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_RAME_WR              (5)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_RAME_WR              (0x20)    /* [5] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD             (0x1)     /* [6] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD             (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD             (6)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD             (6)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD             (6)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD             (0x40)    /* [6] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_WR             (0x1)     /* [7] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_WR             (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_WR             (7)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_WR             (7)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_WR             (7)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_WR             (0x80)    /* [7] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_RD             (0x1)     /* [8] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_RD             (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_RD             (8)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_RD             (8)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_RD             (8)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_RD             (0x100)   /* [8] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_WR             (0x1)     /* [9] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_WR             (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_WR             (9)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_WR             (9)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_WR             (9)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_PERI1_WR             (0x200)   /* [9] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_RD             (0x1)     /* [10] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_RD             (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_RD             (10)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_RD             (10)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_RD             (10)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_RD             (0x400)   /* [10] */
#define MSK_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_WR             (0x1)     /* [11] */
#define RES_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_WR             (0x1)
#define SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_WR             (11)
#define LSB_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_WR             (11)
#define MSB_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_WR             (11)
#define BIT_ACCESS_CONTROL_M0_M1_M3_M7_PERIE_WR             (0x800)   /* [11] */

/** 
 * \brief This structure describes Access Control read and write access
 *
 * \ingroup access_control
 */
typedef struct {
  unsigned short ram0_rd                       :    1; ///< 1: read access of master to the entire memory enabled
  unsigned short ram0_wr                       :    1; ///< 1: write access of master to the entire memory enabled
  unsigned short ram1_rd                       :    1; ///< 1: read access of master to the entire memory enabled
  unsigned short ram1_wr                       :    1; ///< 1: write access of master to the entire memory enabled
  unsigned short rame_rd                       :    1; ///< 1: read access of master to the entire memory enabled
  unsigned short rame_wr                       :    1; ///< 1: write access of master to the entire memory enabled
  unsigned short peri0_rd                      :    1; ///< 1: read access of master to the peripheral bus peri0 enabled.To access a module on the bus the corresponding bits in M*_WBUS? register must be set
  unsigned short peri0_wr                      :    1; ///< 1: write access of master to the peripheral bus peri0 enabled.To access a module on the bus the corresponding bits in M*_WBUS? register must be set
  unsigned short peri1_rd                      :    1; ///< 1: read access of master to the peripheral bus peri1 enabled.To access a module on the bus the corresponding bits in M*_WBUS? register must be set
  unsigned short peri1_wr                      :    1; ///< 1: write access of master to the peripheral bus peri1 enabled.To access a module on the bus the corresponding bits in M*_WBUS? register must be set
  unsigned short perie_rd                      :    1; ///< 1: read access of master to the peripheral bus perie enabled.To access a module on the bus the corresponding bits in M*_WBUS? register must be set
  unsigned short perie_wr                      :    1; ///< 1: write access of master to the peripheral bus perie enabled.To access a module on the bus the corresponding bits in M*_WBUS? register must be set
  unsigned short reserved                      :    4; ///< reserved
} access_control_m0_m1_m3_m7_bf;


/** 
 * \brief Conversion type between word and bit representation of Access Control read and write access
 *
 * \ingroup access_control
 */
typedef union {
  unsigned short val;
  access_control_m0_m1_m3_m7_bf bf;
} access_control_m0_m1_m3_m7_t;


/* ACCESS_CONTROL_M2_M4_M5_M6 */

#define MSK_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD              (0x1)     /* [0] */
#define RES_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD              (0x1)
#define SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD              (0)
#define LSB_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD              (0)
#define MSB_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD              (0)
#define BIT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD              (0x1)     /* [0] */
#define MSK_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_WR              (0x1)     /* [1] */
#define RES_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_WR              (0x1)
#define SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_WR              (1)
#define LSB_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_WR              (1)
#define MSB_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_WR              (1)
#define BIT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_WR              (0x2)     /* [1] */
#define MSK_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_RD              (0x1)     /* [2] */
#define RES_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_RD              (0x1)
#define SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_RD              (2)
#define LSB_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_RD              (2)
#define MSB_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_RD              (2)
#define BIT_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_RD              (0x4)     /* [2] */
#define MSK_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_WR              (0x1)     /* [3] */
#define RES_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_WR              (0x1)
#define SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_WR              (3)
#define LSB_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_WR              (3)
#define MSB_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_WR              (3)
#define BIT_ACCESS_CONTROL_M2_M4_M5_M6_RAM1_WR              (0x8)     /* [3] */
#define MSK_ACCESS_CONTROL_M2_M4_M5_M6_RAME_RD              (0x1)     /* [4] */
#define RES_ACCESS_CONTROL_M2_M4_M5_M6_RAME_RD              (0x1)
#define SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAME_RD              (4)
#define LSB_ACCESS_CONTROL_M2_M4_M5_M6_RAME_RD              (4)
#define MSB_ACCESS_CONTROL_M2_M4_M5_M6_RAME_RD              (4)
#define BIT_ACCESS_CONTROL_M2_M4_M5_M6_RAME_RD              (0x10)    /* [4] */
#define MSK_ACCESS_CONTROL_M2_M4_M5_M6_RAME_WR              (0x1)     /* [5] */
#define RES_ACCESS_CONTROL_M2_M4_M5_M6_RAME_WR              (0x1)
#define SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAME_WR              (5)
#define LSB_ACCESS_CONTROL_M2_M4_M5_M6_RAME_WR              (5)
#define MSB_ACCESS_CONTROL_M2_M4_M5_M6_RAME_WR              (5)
#define BIT_ACCESS_CONTROL_M2_M4_M5_M6_RAME_WR              (0x20)    /* [5] */

/** 
 * \brief This structure describes Access Control read and write access for SRAM
 *
 * \ingroup access_control
 */
typedef struct {
  unsigned short ram0_rd                       :    1; ///< 1: read access of master to the entire memory enabled
  unsigned short ram0_wr                       :    1; ///< 1: write access of master to the entire memory enabled
  unsigned short ram1_rd                       :    1; ///< 1: read access of master to the entire memory enabled
  unsigned short ram1_wr                       :    1; ///< 1: write access of master to the entire memory enabled
  unsigned short rame_rd                       :    1; ///< 1: read access of master to the entire memory enabled
  unsigned short rame_wr                       :    1; ///< 1: write access of master to the entire memory enabled
  unsigned short reserved                      :   10; ///< reserved
} access_control_m2_m4_m5_m6_bf;

/** 
 * \brief Conversion type between word and bit representation of Access Control read and write access for SRAM
 *
 * \ingroup access_control
 */
typedef union {
  unsigned short val;
  access_control_m2_m4_m5_m6_bf bf;
} access_control_m2_m4_m5_m6_t;


/* ACCESS_CONTROL_WBUS0 */

#define MSK_ACCESS_CONTROL_WBUS0_WBID0_RD                   (0x1)     /* [0] */
#define RES_ACCESS_CONTROL_WBUS0_WBID0_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID0_RD                   (0)
#define LSB_ACCESS_CONTROL_WBUS0_WBID0_RD                   (0)
#define MSB_ACCESS_CONTROL_WBUS0_WBID0_RD                   (0)
#define BIT_ACCESS_CONTROL_WBUS0_WBID0_RD                   (0x1)     /* [0] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID0_WR                   (0x1)     /* [1] */
#define RES_ACCESS_CONTROL_WBUS0_WBID0_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID0_WR                   (1)
#define LSB_ACCESS_CONTROL_WBUS0_WBID0_WR                   (1)
#define MSB_ACCESS_CONTROL_WBUS0_WBID0_WR                   (1)
#define BIT_ACCESS_CONTROL_WBUS0_WBID0_WR                   (0x2)     /* [1] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID1_RD                   (0x1)     /* [2] */
#define RES_ACCESS_CONTROL_WBUS0_WBID1_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID1_RD                   (2)
#define LSB_ACCESS_CONTROL_WBUS0_WBID1_RD                   (2)
#define MSB_ACCESS_CONTROL_WBUS0_WBID1_RD                   (2)
#define BIT_ACCESS_CONTROL_WBUS0_WBID1_RD                   (0x4)     /* [2] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID1_WR                   (0x1)     /* [3] */
#define RES_ACCESS_CONTROL_WBUS0_WBID1_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID1_WR                   (3)
#define LSB_ACCESS_CONTROL_WBUS0_WBID1_WR                   (3)
#define MSB_ACCESS_CONTROL_WBUS0_WBID1_WR                   (3)
#define BIT_ACCESS_CONTROL_WBUS0_WBID1_WR                   (0x8)     /* [3] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID2_RD                   (0x1)     /* [4] */
#define RES_ACCESS_CONTROL_WBUS0_WBID2_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID2_RD                   (4)
#define LSB_ACCESS_CONTROL_WBUS0_WBID2_RD                   (4)
#define MSB_ACCESS_CONTROL_WBUS0_WBID2_RD                   (4)
#define BIT_ACCESS_CONTROL_WBUS0_WBID2_RD                   (0x10)    /* [4] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID2_WR                   (0x1)     /* [5] */
#define RES_ACCESS_CONTROL_WBUS0_WBID2_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID2_WR                   (5)
#define LSB_ACCESS_CONTROL_WBUS0_WBID2_WR                   (5)
#define MSB_ACCESS_CONTROL_WBUS0_WBID2_WR                   (5)
#define BIT_ACCESS_CONTROL_WBUS0_WBID2_WR                   (0x20)    /* [5] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID3_RD                   (0x1)     /* [6] */
#define RES_ACCESS_CONTROL_WBUS0_WBID3_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID3_RD                   (6)
#define LSB_ACCESS_CONTROL_WBUS0_WBID3_RD                   (6)
#define MSB_ACCESS_CONTROL_WBUS0_WBID3_RD                   (6)
#define BIT_ACCESS_CONTROL_WBUS0_WBID3_RD                   (0x40)    /* [6] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID3_WR                   (0x1)     /* [7] */
#define RES_ACCESS_CONTROL_WBUS0_WBID3_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID3_WR                   (7)
#define LSB_ACCESS_CONTROL_WBUS0_WBID3_WR                   (7)
#define MSB_ACCESS_CONTROL_WBUS0_WBID3_WR                   (7)
#define BIT_ACCESS_CONTROL_WBUS0_WBID3_WR                   (0x80)    /* [7] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID4_RD                   (0x1)     /* [8] */
#define RES_ACCESS_CONTROL_WBUS0_WBID4_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID4_RD                   (8)
#define LSB_ACCESS_CONTROL_WBUS0_WBID4_RD                   (8)
#define MSB_ACCESS_CONTROL_WBUS0_WBID4_RD                   (8)
#define BIT_ACCESS_CONTROL_WBUS0_WBID4_RD                   (0x100)   /* [8] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID4_WR                   (0x1)     /* [9] */
#define RES_ACCESS_CONTROL_WBUS0_WBID4_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID4_WR                   (9)
#define LSB_ACCESS_CONTROL_WBUS0_WBID4_WR                   (9)
#define MSB_ACCESS_CONTROL_WBUS0_WBID4_WR                   (9)
#define BIT_ACCESS_CONTROL_WBUS0_WBID4_WR                   (0x200)   /* [9] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID5_RD                   (0x1)     /* [10] */
#define RES_ACCESS_CONTROL_WBUS0_WBID5_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID5_RD                   (10)
#define LSB_ACCESS_CONTROL_WBUS0_WBID5_RD                   (10)
#define MSB_ACCESS_CONTROL_WBUS0_WBID5_RD                   (10)
#define BIT_ACCESS_CONTROL_WBUS0_WBID5_RD                   (0x400)   /* [10] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID5_WR                   (0x1)     /* [11] */
#define RES_ACCESS_CONTROL_WBUS0_WBID5_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID5_WR                   (11)
#define LSB_ACCESS_CONTROL_WBUS0_WBID5_WR                   (11)
#define MSB_ACCESS_CONTROL_WBUS0_WBID5_WR                   (11)
#define BIT_ACCESS_CONTROL_WBUS0_WBID5_WR                   (0x800)   /* [11] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID6_RD                   (0x1)     /* [12] */
#define RES_ACCESS_CONTROL_WBUS0_WBID6_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID6_RD                   (12)
#define LSB_ACCESS_CONTROL_WBUS0_WBID6_RD                   (12)
#define MSB_ACCESS_CONTROL_WBUS0_WBID6_RD                   (12)
#define BIT_ACCESS_CONTROL_WBUS0_WBID6_RD                   (0x1000)  /* [12] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID6_WR                   (0x1)     /* [13] */
#define RES_ACCESS_CONTROL_WBUS0_WBID6_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID6_WR                   (13)
#define LSB_ACCESS_CONTROL_WBUS0_WBID6_WR                   (13)
#define MSB_ACCESS_CONTROL_WBUS0_WBID6_WR                   (13)
#define BIT_ACCESS_CONTROL_WBUS0_WBID6_WR                   (0x2000)  /* [13] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID7_RD                   (0x1)     /* [14] */
#define RES_ACCESS_CONTROL_WBUS0_WBID7_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID7_RD                   (14)
#define LSB_ACCESS_CONTROL_WBUS0_WBID7_RD                   (14)
#define MSB_ACCESS_CONTROL_WBUS0_WBID7_RD                   (14)
#define BIT_ACCESS_CONTROL_WBUS0_WBID7_RD                   (0x4000)  /* [14] */
#define MSK_ACCESS_CONTROL_WBUS0_WBID7_WR                   (0x1)     /* [15] */
#define RES_ACCESS_CONTROL_WBUS0_WBID7_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS0_WBID7_WR                   (15)
#define LSB_ACCESS_CONTROL_WBUS0_WBID7_WR                   (15)
#define MSB_ACCESS_CONTROL_WBUS0_WBID7_WR                   (15)
#define BIT_ACCESS_CONTROL_WBUS0_WBID7_WR                   (0x8000)  /* [15] */

/** 
 * \brief This structure describes Access Control peripheral module access number from 0 to 7
 *
 * \ingroup access_control
 */
typedef struct {
  unsigned short wbid0_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid0_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid1_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid1_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid2_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid2_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid3_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid3_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid4_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid4_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid5_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid5_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid6_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid6_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid7_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid7_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
} access_control_wbus0_bf;

/** 
 * \brief Conversion type between word and bit representation of Access Control peripheral module access number from 0 to 7
 *
 * \ingroup access_control
 */
typedef union {
  unsigned short val;
  access_control_wbus0_bf bf;
} access_control_wbus0_t;


/* ACCESS_CONTROL_WBUS1 */

#define MSK_ACCESS_CONTROL_WBUS1_WBID8_RD                   (0x1)     /* [0] */
#define RES_ACCESS_CONTROL_WBUS1_WBID8_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID8_RD                   (0)
#define LSB_ACCESS_CONTROL_WBUS1_WBID8_RD                   (0)
#define MSB_ACCESS_CONTROL_WBUS1_WBID8_RD                   (0)
#define BIT_ACCESS_CONTROL_WBUS1_WBID8_RD                   (0x1)     /* [0] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID8_WR                   (0x1)     /* [1] */
#define RES_ACCESS_CONTROL_WBUS1_WBID8_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID8_WR                   (1)
#define LSB_ACCESS_CONTROL_WBUS1_WBID8_WR                   (1)
#define MSB_ACCESS_CONTROL_WBUS1_WBID8_WR                   (1)
#define BIT_ACCESS_CONTROL_WBUS1_WBID8_WR                   (0x2)     /* [1] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID9_RD                   (0x1)     /* [2] */
#define RES_ACCESS_CONTROL_WBUS1_WBID9_RD                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID9_RD                   (2)
#define LSB_ACCESS_CONTROL_WBUS1_WBID9_RD                   (2)
#define MSB_ACCESS_CONTROL_WBUS1_WBID9_RD                   (2)
#define BIT_ACCESS_CONTROL_WBUS1_WBID9_RD                   (0x4)     /* [2] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID9_WR                   (0x1)     /* [3] */
#define RES_ACCESS_CONTROL_WBUS1_WBID9_WR                   (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID9_WR                   (3)
#define LSB_ACCESS_CONTROL_WBUS1_WBID9_WR                   (3)
#define MSB_ACCESS_CONTROL_WBUS1_WBID9_WR                   (3)
#define BIT_ACCESS_CONTROL_WBUS1_WBID9_WR                   (0x8)     /* [3] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID10_RD                  (0x1)     /* [4] */
#define RES_ACCESS_CONTROL_WBUS1_WBID10_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID10_RD                  (4)
#define LSB_ACCESS_CONTROL_WBUS1_WBID10_RD                  (4)
#define MSB_ACCESS_CONTROL_WBUS1_WBID10_RD                  (4)
#define BIT_ACCESS_CONTROL_WBUS1_WBID10_RD                  (0x10)    /* [4] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID10_WR                  (0x1)     /* [5] */
#define RES_ACCESS_CONTROL_WBUS1_WBID10_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID10_WR                  (5)
#define LSB_ACCESS_CONTROL_WBUS1_WBID10_WR                  (5)
#define MSB_ACCESS_CONTROL_WBUS1_WBID10_WR                  (5)
#define BIT_ACCESS_CONTROL_WBUS1_WBID10_WR                  (0x20)    /* [5] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID11_RD                  (0x1)     /* [6] */
#define RES_ACCESS_CONTROL_WBUS1_WBID11_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID11_RD                  (6)
#define LSB_ACCESS_CONTROL_WBUS1_WBID11_RD                  (6)
#define MSB_ACCESS_CONTROL_WBUS1_WBID11_RD                  (6)
#define BIT_ACCESS_CONTROL_WBUS1_WBID11_RD                  (0x40)    /* [6] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID11_WR                  (0x1)     /* [7] */
#define RES_ACCESS_CONTROL_WBUS1_WBID11_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID11_WR                  (7)
#define LSB_ACCESS_CONTROL_WBUS1_WBID11_WR                  (7)
#define MSB_ACCESS_CONTROL_WBUS1_WBID11_WR                  (7)
#define BIT_ACCESS_CONTROL_WBUS1_WBID11_WR                  (0x80)    /* [7] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID12_RD                  (0x1)     /* [8] */
#define RES_ACCESS_CONTROL_WBUS1_WBID12_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID12_RD                  (8)
#define LSB_ACCESS_CONTROL_WBUS1_WBID12_RD                  (8)
#define MSB_ACCESS_CONTROL_WBUS1_WBID12_RD                  (8)
#define BIT_ACCESS_CONTROL_WBUS1_WBID12_RD                  (0x100)   /* [8] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID12_WR                  (0x1)     /* [9] */
#define RES_ACCESS_CONTROL_WBUS1_WBID12_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID12_WR                  (9)
#define LSB_ACCESS_CONTROL_WBUS1_WBID12_WR                  (9)
#define MSB_ACCESS_CONTROL_WBUS1_WBID12_WR                  (9)
#define BIT_ACCESS_CONTROL_WBUS1_WBID12_WR                  (0x200)   /* [9] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID13_RD                  (0x1)     /* [10] */
#define RES_ACCESS_CONTROL_WBUS1_WBID13_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID13_RD                  (10)
#define LSB_ACCESS_CONTROL_WBUS1_WBID13_RD                  (10)
#define MSB_ACCESS_CONTROL_WBUS1_WBID13_RD                  (10)
#define BIT_ACCESS_CONTROL_WBUS1_WBID13_RD                  (0x400)   /* [10] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID13_WR                  (0x1)     /* [11] */
#define RES_ACCESS_CONTROL_WBUS1_WBID13_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID13_WR                  (11)
#define LSB_ACCESS_CONTROL_WBUS1_WBID13_WR                  (11)
#define MSB_ACCESS_CONTROL_WBUS1_WBID13_WR                  (11)
#define BIT_ACCESS_CONTROL_WBUS1_WBID13_WR                  (0x800)   /* [11] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID14_RD                  (0x1)     /* [12] */
#define RES_ACCESS_CONTROL_WBUS1_WBID14_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID14_RD                  (12)
#define LSB_ACCESS_CONTROL_WBUS1_WBID14_RD                  (12)
#define MSB_ACCESS_CONTROL_WBUS1_WBID14_RD                  (12)
#define BIT_ACCESS_CONTROL_WBUS1_WBID14_RD                  (0x1000)  /* [12] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID14_WR                  (0x1)     /* [13] */
#define RES_ACCESS_CONTROL_WBUS1_WBID14_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID14_WR                  (13)
#define LSB_ACCESS_CONTROL_WBUS1_WBID14_WR                  (13)
#define MSB_ACCESS_CONTROL_WBUS1_WBID14_WR                  (13)
#define BIT_ACCESS_CONTROL_WBUS1_WBID14_WR                  (0x2000)  /* [13] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID15_RD                  (0x1)     /* [14] */
#define RES_ACCESS_CONTROL_WBUS1_WBID15_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID15_RD                  (14)
#define LSB_ACCESS_CONTROL_WBUS1_WBID15_RD                  (14)
#define MSB_ACCESS_CONTROL_WBUS1_WBID15_RD                  (14)
#define BIT_ACCESS_CONTROL_WBUS1_WBID15_RD                  (0x4000)  /* [14] */
#define MSK_ACCESS_CONTROL_WBUS1_WBID15_WR                  (0x1)     /* [15] */
#define RES_ACCESS_CONTROL_WBUS1_WBID15_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS1_WBID15_WR                  (15)
#define LSB_ACCESS_CONTROL_WBUS1_WBID15_WR                  (15)
#define MSB_ACCESS_CONTROL_WBUS1_WBID15_WR                  (15)
#define BIT_ACCESS_CONTROL_WBUS1_WBID15_WR                  (0x8000)  /* [15] */

/** 
 * \brief This structure describes Access Control peripheral module access number from 8 to 15
 *
 * \ingroup access_control
 */
typedef struct {
  unsigned short wbid8_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid8_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid9_rd                      :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid9_wr                      :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid10_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid10_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid11_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid11_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid12_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid12_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid13_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid13_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid14_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid14_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid15_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid15_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
} access_control_wbus1_bf;

/** 
 * \brief Conversion type between word and bit representation of Access Control peripheral module access number from 8 to 15
 *
 * \ingroup access_control
 */
typedef union {
  unsigned short val;
  access_control_wbus1_bf bf;
} access_control_wbus1_t;


/* ACCESS_CONTROL_WBUS2 */

#define MSK_ACCESS_CONTROL_WBUS2_WBID16_RD                  (0x1)     /* [0] */
#define RES_ACCESS_CONTROL_WBUS2_WBID16_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID16_RD                  (0)
#define LSB_ACCESS_CONTROL_WBUS2_WBID16_RD                  (0)
#define MSB_ACCESS_CONTROL_WBUS2_WBID16_RD                  (0)
#define BIT_ACCESS_CONTROL_WBUS2_WBID16_RD                  (0x1)     /* [0] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID16_WR                  (0x1)     /* [1] */
#define RES_ACCESS_CONTROL_WBUS2_WBID16_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID16_WR                  (1)
#define LSB_ACCESS_CONTROL_WBUS2_WBID16_WR                  (1)
#define MSB_ACCESS_CONTROL_WBUS2_WBID16_WR                  (1)
#define BIT_ACCESS_CONTROL_WBUS2_WBID16_WR                  (0x2)     /* [1] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID17_RD                  (0x1)     /* [2] */
#define RES_ACCESS_CONTROL_WBUS2_WBID17_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID17_RD                  (2)
#define LSB_ACCESS_CONTROL_WBUS2_WBID17_RD                  (2)
#define MSB_ACCESS_CONTROL_WBUS2_WBID17_RD                  (2)
#define BIT_ACCESS_CONTROL_WBUS2_WBID17_RD                  (0x4)     /* [2] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID17_WR                  (0x1)     /* [3] */
#define RES_ACCESS_CONTROL_WBUS2_WBID17_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID17_WR                  (3)
#define LSB_ACCESS_CONTROL_WBUS2_WBID17_WR                  (3)
#define MSB_ACCESS_CONTROL_WBUS2_WBID17_WR                  (3)
#define BIT_ACCESS_CONTROL_WBUS2_WBID17_WR                  (0x8)     /* [3] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID18_RD                  (0x1)     /* [4] */
#define RES_ACCESS_CONTROL_WBUS2_WBID18_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID18_RD                  (4)
#define LSB_ACCESS_CONTROL_WBUS2_WBID18_RD                  (4)
#define MSB_ACCESS_CONTROL_WBUS2_WBID18_RD                  (4)
#define BIT_ACCESS_CONTROL_WBUS2_WBID18_RD                  (0x10)    /* [4] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID18_WR                  (0x1)     /* [5] */
#define RES_ACCESS_CONTROL_WBUS2_WBID18_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID18_WR                  (5)
#define LSB_ACCESS_CONTROL_WBUS2_WBID18_WR                  (5)
#define MSB_ACCESS_CONTROL_WBUS2_WBID18_WR                  (5)
#define BIT_ACCESS_CONTROL_WBUS2_WBID18_WR                  (0x20)    /* [5] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID19_RD                  (0x1)     /* [6] */
#define RES_ACCESS_CONTROL_WBUS2_WBID19_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID19_RD                  (6)
#define LSB_ACCESS_CONTROL_WBUS2_WBID19_RD                  (6)
#define MSB_ACCESS_CONTROL_WBUS2_WBID19_RD                  (6)
#define BIT_ACCESS_CONTROL_WBUS2_WBID19_RD                  (0x40)    /* [6] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID19_WR                  (0x1)     /* [7] */
#define RES_ACCESS_CONTROL_WBUS2_WBID19_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID19_WR                  (7)
#define LSB_ACCESS_CONTROL_WBUS2_WBID19_WR                  (7)
#define MSB_ACCESS_CONTROL_WBUS2_WBID19_WR                  (7)
#define BIT_ACCESS_CONTROL_WBUS2_WBID19_WR                  (0x80)    /* [7] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID20_RD                  (0x1)     /* [8] */
#define RES_ACCESS_CONTROL_WBUS2_WBID20_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID20_RD                  (8)
#define LSB_ACCESS_CONTROL_WBUS2_WBID20_RD                  (8)
#define MSB_ACCESS_CONTROL_WBUS2_WBID20_RD                  (8)
#define BIT_ACCESS_CONTROL_WBUS2_WBID20_RD                  (0x100)   /* [8] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID20_WR                  (0x1)     /* [9] */
#define RES_ACCESS_CONTROL_WBUS2_WBID20_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID20_WR                  (9)
#define LSB_ACCESS_CONTROL_WBUS2_WBID20_WR                  (9)
#define MSB_ACCESS_CONTROL_WBUS2_WBID20_WR                  (9)
#define BIT_ACCESS_CONTROL_WBUS2_WBID20_WR                  (0x200)   /* [9] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID21_RD                  (0x1)     /* [10] */
#define RES_ACCESS_CONTROL_WBUS2_WBID21_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID21_RD                  (10)
#define LSB_ACCESS_CONTROL_WBUS2_WBID21_RD                  (10)
#define MSB_ACCESS_CONTROL_WBUS2_WBID21_RD                  (10)
#define BIT_ACCESS_CONTROL_WBUS2_WBID21_RD                  (0x400)   /* [10] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID21_WR                  (0x1)     /* [11] */
#define RES_ACCESS_CONTROL_WBUS2_WBID21_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID21_WR                  (11)
#define LSB_ACCESS_CONTROL_WBUS2_WBID21_WR                  (11)
#define MSB_ACCESS_CONTROL_WBUS2_WBID21_WR                  (11)
#define BIT_ACCESS_CONTROL_WBUS2_WBID21_WR                  (0x800)   /* [11] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID22_RD                  (0x1)     /* [12] */
#define RES_ACCESS_CONTROL_WBUS2_WBID22_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID22_RD                  (12)
#define LSB_ACCESS_CONTROL_WBUS2_WBID22_RD                  (12)
#define MSB_ACCESS_CONTROL_WBUS2_WBID22_RD                  (12)
#define BIT_ACCESS_CONTROL_WBUS2_WBID22_RD                  (0x1000)  /* [12] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID22_WR                  (0x1)     /* [13] */
#define RES_ACCESS_CONTROL_WBUS2_WBID22_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID22_WR                  (13)
#define LSB_ACCESS_CONTROL_WBUS2_WBID22_WR                  (13)
#define MSB_ACCESS_CONTROL_WBUS2_WBID22_WR                  (13)
#define BIT_ACCESS_CONTROL_WBUS2_WBID22_WR                  (0x2000)  /* [13] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID23_RD                  (0x1)     /* [14] */
#define RES_ACCESS_CONTROL_WBUS2_WBID23_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID23_RD                  (14)
#define LSB_ACCESS_CONTROL_WBUS2_WBID23_RD                  (14)
#define MSB_ACCESS_CONTROL_WBUS2_WBID23_RD                  (14)
#define BIT_ACCESS_CONTROL_WBUS2_WBID23_RD                  (0x4000)  /* [14] */
#define MSK_ACCESS_CONTROL_WBUS2_WBID23_WR                  (0x1)     /* [15] */
#define RES_ACCESS_CONTROL_WBUS2_WBID23_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS2_WBID23_WR                  (15)
#define LSB_ACCESS_CONTROL_WBUS2_WBID23_WR                  (15)
#define MSB_ACCESS_CONTROL_WBUS2_WBID23_WR                  (15)
#define BIT_ACCESS_CONTROL_WBUS2_WBID23_WR                  (0x8000)  /* [15] */

/** 
 * \brief This structure describes Access Control peripheral module access number from 16 to 23
 *
 * \ingroup access_control
 */
typedef struct {
  unsigned short wbid16_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid16_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid17_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid17_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid18_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid18_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid19_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid19_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid20_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid20_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid21_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid21_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid22_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid22_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid23_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid23_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
} access_control_wbus2_bf;

/** 
 * \brief Conversion type between word and bit representation of Access Control peripheral module access number from 16 to 24
 *
 * \ingroup access_control
 */
typedef union {
  unsigned short val;
  access_control_wbus2_bf bf;
} access_control_wbus2_t;


/* ACCESS_CONTROL_WBUS3 */

#define MSK_ACCESS_CONTROL_WBUS3_WBID24_RD                  (0x1)     /* [0] */
#define RES_ACCESS_CONTROL_WBUS3_WBID24_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID24_RD                  (0)
#define LSB_ACCESS_CONTROL_WBUS3_WBID24_RD                  (0)
#define MSB_ACCESS_CONTROL_WBUS3_WBID24_RD                  (0)
#define BIT_ACCESS_CONTROL_WBUS3_WBID24_RD                  (0x1)     /* [0] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID24_WR                  (0x1)     /* [1] */
#define RES_ACCESS_CONTROL_WBUS3_WBID24_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID24_WR                  (1)
#define LSB_ACCESS_CONTROL_WBUS3_WBID24_WR                  (1)
#define MSB_ACCESS_CONTROL_WBUS3_WBID24_WR                  (1)
#define BIT_ACCESS_CONTROL_WBUS3_WBID24_WR                  (0x2)     /* [1] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID25_RD                  (0x1)     /* [2] */
#define RES_ACCESS_CONTROL_WBUS3_WBID25_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID25_RD                  (2)
#define LSB_ACCESS_CONTROL_WBUS3_WBID25_RD                  (2)
#define MSB_ACCESS_CONTROL_WBUS3_WBID25_RD                  (2)
#define BIT_ACCESS_CONTROL_WBUS3_WBID25_RD                  (0x4)     /* [2] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID25_WR                  (0x1)     /* [3] */
#define RES_ACCESS_CONTROL_WBUS3_WBID25_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID25_WR                  (3)
#define LSB_ACCESS_CONTROL_WBUS3_WBID25_WR                  (3)
#define MSB_ACCESS_CONTROL_WBUS3_WBID25_WR                  (3)
#define BIT_ACCESS_CONTROL_WBUS3_WBID25_WR                  (0x8)     /* [3] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID26_RD                  (0x1)     /* [4] */
#define RES_ACCESS_CONTROL_WBUS3_WBID26_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID26_RD                  (4)
#define LSB_ACCESS_CONTROL_WBUS3_WBID26_RD                  (4)
#define MSB_ACCESS_CONTROL_WBUS3_WBID26_RD                  (4)
#define BIT_ACCESS_CONTROL_WBUS3_WBID26_RD                  (0x10)    /* [4] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID26_WR                  (0x1)     /* [5] */
#define RES_ACCESS_CONTROL_WBUS3_WBID26_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID26_WR                  (5)
#define LSB_ACCESS_CONTROL_WBUS3_WBID26_WR                  (5)
#define MSB_ACCESS_CONTROL_WBUS3_WBID26_WR                  (5)
#define BIT_ACCESS_CONTROL_WBUS3_WBID26_WR                  (0x20)    /* [5] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID27_RD                  (0x1)     /* [6] */
#define RES_ACCESS_CONTROL_WBUS3_WBID27_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID27_RD                  (6)
#define LSB_ACCESS_CONTROL_WBUS3_WBID27_RD                  (6)
#define MSB_ACCESS_CONTROL_WBUS3_WBID27_RD                  (6)
#define BIT_ACCESS_CONTROL_WBUS3_WBID27_RD                  (0x40)    /* [6] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID27_WR                  (0x1)     /* [7] */
#define RES_ACCESS_CONTROL_WBUS3_WBID27_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID27_WR                  (7)
#define LSB_ACCESS_CONTROL_WBUS3_WBID27_WR                  (7)
#define MSB_ACCESS_CONTROL_WBUS3_WBID27_WR                  (7)
#define BIT_ACCESS_CONTROL_WBUS3_WBID27_WR                  (0x80)    /* [7] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID28_RD                  (0x1)     /* [8] */
#define RES_ACCESS_CONTROL_WBUS3_WBID28_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID28_RD                  (8)
#define LSB_ACCESS_CONTROL_WBUS3_WBID28_RD                  (8)
#define MSB_ACCESS_CONTROL_WBUS3_WBID28_RD                  (8)
#define BIT_ACCESS_CONTROL_WBUS3_WBID28_RD                  (0x100)   /* [8] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID28_WR                  (0x1)     /* [9] */
#define RES_ACCESS_CONTROL_WBUS3_WBID28_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID28_WR                  (9)
#define LSB_ACCESS_CONTROL_WBUS3_WBID28_WR                  (9)
#define MSB_ACCESS_CONTROL_WBUS3_WBID28_WR                  (9)
#define BIT_ACCESS_CONTROL_WBUS3_WBID28_WR                  (0x200)   /* [9] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID29_RD                  (0x1)     /* [10] */
#define RES_ACCESS_CONTROL_WBUS3_WBID29_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID29_RD                  (10)
#define LSB_ACCESS_CONTROL_WBUS3_WBID29_RD                  (10)
#define MSB_ACCESS_CONTROL_WBUS3_WBID29_RD                  (10)
#define BIT_ACCESS_CONTROL_WBUS3_WBID29_RD                  (0x400)   /* [10] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID29_WR                  (0x1)     /* [11] */
#define RES_ACCESS_CONTROL_WBUS3_WBID29_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID29_WR                  (11)
#define LSB_ACCESS_CONTROL_WBUS3_WBID29_WR                  (11)
#define MSB_ACCESS_CONTROL_WBUS3_WBID29_WR                  (11)
#define BIT_ACCESS_CONTROL_WBUS3_WBID29_WR                  (0x800)   /* [11] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID30_RD                  (0x1)     /* [12] */
#define RES_ACCESS_CONTROL_WBUS3_WBID30_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID30_RD                  (12)
#define LSB_ACCESS_CONTROL_WBUS3_WBID30_RD                  (12)
#define MSB_ACCESS_CONTROL_WBUS3_WBID30_RD                  (12)
#define BIT_ACCESS_CONTROL_WBUS3_WBID30_RD                  (0x1000)  /* [12] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID30_WR                  (0x1)     /* [13] */
#define RES_ACCESS_CONTROL_WBUS3_WBID30_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID30_WR                  (13)
#define LSB_ACCESS_CONTROL_WBUS3_WBID30_WR                  (13)
#define MSB_ACCESS_CONTROL_WBUS3_WBID30_WR                  (13)
#define BIT_ACCESS_CONTROL_WBUS3_WBID30_WR                  (0x2000)  /* [13] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID31_RD                  (0x1)     /* [14] */
#define RES_ACCESS_CONTROL_WBUS3_WBID31_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID31_RD                  (14)
#define LSB_ACCESS_CONTROL_WBUS3_WBID31_RD                  (14)
#define MSB_ACCESS_CONTROL_WBUS3_WBID31_RD                  (14)
#define BIT_ACCESS_CONTROL_WBUS3_WBID31_RD                  (0x4000)  /* [14] */
#define MSK_ACCESS_CONTROL_WBUS3_WBID31_WR                  (0x1)     /* [15] */
#define RES_ACCESS_CONTROL_WBUS3_WBID31_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS3_WBID31_WR                  (15)
#define LSB_ACCESS_CONTROL_WBUS3_WBID31_WR                  (15)
#define MSB_ACCESS_CONTROL_WBUS3_WBID31_WR                  (15)
#define BIT_ACCESS_CONTROL_WBUS3_WBID31_WR                  (0x8000)  /* [15] */

/** 
 * \brief This structure describes Access Control peripheral module access number from 24 to 31
 *
 * \ingroup access_control
 */
typedef struct {
  unsigned short wbid24_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid24_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid25_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid25_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid26_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid26_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid27_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid27_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid28_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid28_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid29_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid29_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid30_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid30_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid31_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid31_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
} access_control_wbus3_bf;

/** 
 * \brief Conversion type between word and bit representation of Access Control peripheral module access number from 24 to 31
 *
 * \ingroup access_control
 */
typedef union {
  unsigned short val;
  access_control_wbus3_bf bf;
} access_control_wbus3_t;


/* ACCESS_CONTROL_WBUS4 */

#define MSK_ACCESS_CONTROL_WBUS4_WBID32_RD                  (0x1)     /* [0] */
#define RES_ACCESS_CONTROL_WBUS4_WBID32_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS4_WBID32_RD                  (0)
#define LSB_ACCESS_CONTROL_WBUS4_WBID32_RD                  (0)
#define MSB_ACCESS_CONTROL_WBUS4_WBID32_RD                  (0)
#define BIT_ACCESS_CONTROL_WBUS4_WBID32_RD                  (0x1)     /* [0] */
#define MSK_ACCESS_CONTROL_WBUS4_WBID32_WR                  (0x1)     /* [1] */
#define RES_ACCESS_CONTROL_WBUS4_WBID32_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS4_WBID32_WR                  (1)
#define LSB_ACCESS_CONTROL_WBUS4_WBID32_WR                  (1)
#define MSB_ACCESS_CONTROL_WBUS4_WBID32_WR                  (1)
#define BIT_ACCESS_CONTROL_WBUS4_WBID32_WR                  (0x2)     /* [1] */
#define MSK_ACCESS_CONTROL_WBUS4_WBID33_RD                  (0x1)     /* [2] */
#define RES_ACCESS_CONTROL_WBUS4_WBID33_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS4_WBID33_RD                  (2)
#define LSB_ACCESS_CONTROL_WBUS4_WBID33_RD                  (2)
#define MSB_ACCESS_CONTROL_WBUS4_WBID33_RD                  (2)
#define BIT_ACCESS_CONTROL_WBUS4_WBID33_RD                  (0x4)     /* [2] */
#define MSK_ACCESS_CONTROL_WBUS4_WBID33_WR                  (0x1)     /* [3] */
#define RES_ACCESS_CONTROL_WBUS4_WBID33_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS4_WBID33_WR                  (3)
#define LSB_ACCESS_CONTROL_WBUS4_WBID33_WR                  (3)
#define MSB_ACCESS_CONTROL_WBUS4_WBID33_WR                  (3)
#define BIT_ACCESS_CONTROL_WBUS4_WBID33_WR                  (0x8)     /* [3] */
#define MSK_ACCESS_CONTROL_WBUS4_WBID34_RD                  (0x1)     /* [4] */
#define RES_ACCESS_CONTROL_WBUS4_WBID34_RD                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS4_WBID34_RD                  (4)
#define LSB_ACCESS_CONTROL_WBUS4_WBID34_RD                  (4)
#define MSB_ACCESS_CONTROL_WBUS4_WBID34_RD                  (4)
#define BIT_ACCESS_CONTROL_WBUS4_WBID34_RD                  (0x10)    /* [4] */
#define MSK_ACCESS_CONTROL_WBUS4_WBID34_WR                  (0x1)     /* [5] */
#define RES_ACCESS_CONTROL_WBUS4_WBID34_WR                  (0x1)
#define SFT_ACCESS_CONTROL_WBUS4_WBID34_WR                  (5)
#define LSB_ACCESS_CONTROL_WBUS4_WBID34_WR                  (5)
#define MSB_ACCESS_CONTROL_WBUS4_WBID34_WR                  (5)
#define BIT_ACCESS_CONTROL_WBUS4_WBID34_WR                  (0x20)    /* [5] */

/** 
 * \brief This structure describes Access Control peripheral module access number from 32 to 34
 *
 * \ingroup access_control
 */
typedef struct {
  unsigned short wbid32_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid32_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid33_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid33_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short wbid34_rd                     :    1; ///< 1: read access to peripheral module with wishbone number 0 enabled
  unsigned short wbid34_wr                     :    1; ///< 1: write access to peripheral module with wishbone number 0 enabled
  unsigned short reserved                      :   10; ///< reserved
} access_control_wbus4_bf;

/** 
 * \brief Conversion type between word and bit representation of Access Control peripheral module access number from 31 to 34
 *
 * \ingroup access_control
 */
typedef union {
  unsigned short val;
  access_control_wbus4_bf bf;
} access_control_wbus4_t;


/* ACCESS_CONTROL_LOW */

#define MSK_ACCESS_CONTROL_LOW_RD                           (0x1)     /* [0] */
#define RES_ACCESS_CONTROL_LOW_RD                           (0x1)
#define SFT_ACCESS_CONTROL_LOW_RD                           (0)
#define LSB_ACCESS_CONTROL_LOW_RD                           (0)
#define MSB_ACCESS_CONTROL_LOW_RD                           (0)
#define BIT_ACCESS_CONTROL_LOW_RD                           (0x1)     /* [0] */
#define MSK_ACCESS_CONTROL_LOW_WR                           (0x1)     /* [1] */
#define RES_ACCESS_CONTROL_LOW_WR                           (0x1)
#define SFT_ACCESS_CONTROL_LOW_WR                           (1)
#define LSB_ACCESS_CONTROL_LOW_WR                           (1)
#define MSB_ACCESS_CONTROL_LOW_WR                           (1)
#define BIT_ACCESS_CONTROL_LOW_WR                           (0x2)     /* [1] */
#define MSK_ACCESS_CONTROL_LOW_A15_6                        (0x3ff)   /* [15:6] */
#define RES_ACCESS_CONTROL_LOW_A15_6                        (0x000)
#define SFT_ACCESS_CONTROL_LOW_A15_6                        (6)
#define LSB_ACCESS_CONTROL_LOW_A15_6                        (6)
#define MSB_ACCESS_CONTROL_LOW_A15_6                        (15)

/** 
 * \brief This structure describes Access Control address range and control
 *
 * \ingroup access_control
 */
typedef struct {
  unsigned short rd                            :    1; ///< 1: read enabled for address range
  unsigned short wr                            :    1; ///< 1: write enabled for address range
  unsigned short reserved5                     :    4; ///< reserved
  unsigned short a15_6                         :   10; ///< start of address range (lower address bits 5:0 are'0')
} access_control_low_bf;

/** 
 * \brief Conversion type between word and bit representation of Access Control address range and control
 *
 * \ingroup access_control
 */
typedef union {
  unsigned short val;
  access_control_low_bf bf;
} access_control_low_t;


/* ACCESS_CONTROL_HIGH */

#define MSK_ACCESS_CONTROL_HIGH_A15_6                       (0x3ff)   /* [15:6] */
#define RES_ACCESS_CONTROL_HIGH_A15_6                       (0x3FF)
#define SFT_ACCESS_CONTROL_HIGH_A15_6                       (6)
#define LSB_ACCESS_CONTROL_HIGH_A15_6                       (6)
#define MSB_ACCESS_CONTROL_HIGH_A15_6                       (15)

/** 
 * \brief This structure describes Access Control address range
 *
 * \ingroup access_control
 */
typedef struct {
  unsigned short reserved5                     :    6; ///< reserved
  unsigned short a15_6                         :   10; ///< end of address range (lower address bits 5:0 are '0'). Must be larger or equal to M?_R?_LOW.a15_6
} access_control_high_bf;

/** 
 * \brief Conversion type between word and bit representation of Access Control address range
 *
 * \ingroup access_control
 */
typedef union {
  unsigned short val;
  access_control_high_bf bf;
} access_control_high_t;



// Register definitions for module
// Instance base address BASE_ADDR_ACCESS_CONTROL 0x40006380U ... 

#define ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI                 (0x00U)
#define A_ACCESS_CONTROL_M0_M1_HIAD_HISPI(ba)                ((ba) + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI)
#define R_ACCESS_CONTROL_M0_M1_HIAD_HISPI(ba)                (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M0_M1_HIAD_HISPI(ba)))
#define RES_ACCESS_CONTROL_M0_M1_HIAD_HISPI                  (0xfffU)
#define MSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI                  11
#define LSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI                  0
#define AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI                (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI)
#define REG_ACCESS_CONTROL_M0_M1_HIAD_HISPI                  (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI))

#define ADDR_ACCESS_CONTROL_M2_SWD                           (0x02U)
#define A_ACCESS_CONTROL_M2_SWD(ba)                          ((ba) + ADDR_ACCESS_CONTROL_M2_SWD)
#define R_ACCESS_CONTROL_M2_SWD(ba)                          (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M2_SWD(ba)))
#define RES_ACCESS_CONTROL_M2_SWD                            (0x3fU)
#define MSB_ACCESS_CONTROL_M2_SWD                            5
#define LSB_ACCESS_CONTROL_M2_SWD                            0
#define AADDR_ACCESS_CONTROL_M2_SWD                          (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M2_SWD)
#define REG_ACCESS_CONTROL_M2_SWD                            (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M2_SWD))

#define ADDR_ACCESS_CONTROL_M4_SARC                          (0x04U)
#define A_ACCESS_CONTROL_M4_SARC(ba)                         ((ba) + ADDR_ACCESS_CONTROL_M4_SARC)
#define R_ACCESS_CONTROL_M4_SARC(ba)                         (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M4_SARC(ba)))
#define RES_ACCESS_CONTROL_M4_SARC                           (0x3fU)
#define MSB_ACCESS_CONTROL_M4_SARC                           5
#define LSB_ACCESS_CONTROL_M4_SARC                           0
#define AADDR_ACCESS_CONTROL_M4_SARC                         (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M4_SARC)
#define REG_ACCESS_CONTROL_M4_SARC                           (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M4_SARC))

#define ADDR_ACCESS_CONTROL_M5_USI0                          (0x06U)
#define A_ACCESS_CONTROL_M5_USI0(ba)                         ((ba) + ADDR_ACCESS_CONTROL_M5_USI0)
#define R_ACCESS_CONTROL_M5_USI0(ba)                         (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M5_USI0(ba)))
#define RES_ACCESS_CONTROL_M5_USI0                           (0x3fU)
#define MSB_ACCESS_CONTROL_M5_USI0                           5
#define LSB_ACCESS_CONTROL_M5_USI0                           0
#define AADDR_ACCESS_CONTROL_M5_USI0                         (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M5_USI0)
#define REG_ACCESS_CONTROL_M5_USI0                           (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M5_USI0))

#define ADDR_ACCESS_CONTROL_M6_USI1                          (0x08U)
#define A_ACCESS_CONTROL_M6_USI1(ba)                         ((ba) + ADDR_ACCESS_CONTROL_M6_USI1)
#define R_ACCESS_CONTROL_M6_USI1(ba)                         (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M6_USI1(ba)))
#define RES_ACCESS_CONTROL_M6_USI1                           (0x3fU)
#define MSB_ACCESS_CONTROL_M6_USI1                           5
#define LSB_ACCESS_CONTROL_M6_USI1                           0
#define AADDR_ACCESS_CONTROL_M6_USI1                         (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M6_USI1)
#define REG_ACCESS_CONTROL_M6_USI1                           (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M6_USI1))

#define ADDR_ACCESS_CONTROL_M3_CCPU0                         (0x0AU)
#define A_ACCESS_CONTROL_M3_CCPU0(ba)                        ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0)
#define R_ACCESS_CONTROL_M3_CCPU0(ba)                        (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0                          (0xfffU)
#define MSB_ACCESS_CONTROL_M3_CCPU0                          11
#define LSB_ACCESS_CONTROL_M3_CCPU0                          0
#define AADDR_ACCESS_CONTROL_M3_CCPU0                        (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0)
#define REG_ACCESS_CONTROL_M3_CCPU0                          (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0))

#define ADDR_ACCESS_CONTROL_M7_ACPU1                         (0x0CU)
#define A_ACCESS_CONTROL_M7_ACPU1(ba)                        ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1)
#define R_ACCESS_CONTROL_M7_ACPU1(ba)                        (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1                          (0xfffU)
#define MSB_ACCESS_CONTROL_M7_ACPU1                          11
#define LSB_ACCESS_CONTROL_M7_ACPU1                          0
#define AADDR_ACCESS_CONTROL_M7_ACPU1                        (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1)
#define REG_ACCESS_CONTROL_M7_ACPU1                          (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1))

#define ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0           (0x16U)
#define A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0(ba)          ((ba) + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0)
#define R_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0(ba)          (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0(ba)))
#define RES_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0            (0xffffU)
#define MSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0            15
#define LSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0            0
#define AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0          (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0)
#define REG_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0            (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0))

#define ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS0                   (0x18U)
#define A_ACCESS_CONTROL_M3_CCPU0_WBUS0(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS0)
#define R_ACCESS_CONTROL_M3_CCPU0_WBUS0(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0_WBUS0(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0_WBUS0                    (0xffffU)
#define MSB_ACCESS_CONTROL_M3_CCPU0_WBUS0                    15
#define LSB_ACCESS_CONTROL_M3_CCPU0_WBUS0                    0
#define AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS0                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS0)
#define REG_ACCESS_CONTROL_M3_CCPU0_WBUS0                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS0))

#define ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS0                   (0x1AU)
#define A_ACCESS_CONTROL_M7_ACPU1_WBUS0(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS0)
#define R_ACCESS_CONTROL_M7_ACPU1_WBUS0(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1_WBUS0(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1_WBUS0                    (0xffffU)
#define MSB_ACCESS_CONTROL_M7_ACPU1_WBUS0                    15
#define LSB_ACCESS_CONTROL_M7_ACPU1_WBUS0                    0
#define AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS0                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS0)
#define REG_ACCESS_CONTROL_M7_ACPU1_WBUS0                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS0))

#define ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1           (0x1CU)
#define A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1(ba)          ((ba) + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1)
#define R_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1(ba)          (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1(ba)))
#define RES_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1            (0xffffU)
#define MSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1            15
#define LSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1            0
#define AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1          (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1)
#define REG_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1            (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS1))

#define ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS1                   (0x1EU)
#define A_ACCESS_CONTROL_M3_CCPU0_WBUS1(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS1)
#define R_ACCESS_CONTROL_M3_CCPU0_WBUS1(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0_WBUS1(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0_WBUS1                    (0xffffU)
#define MSB_ACCESS_CONTROL_M3_CCPU0_WBUS1                    15
#define LSB_ACCESS_CONTROL_M3_CCPU0_WBUS1                    0
#define AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS1                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS1)
#define REG_ACCESS_CONTROL_M3_CCPU0_WBUS1                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS1))

#define ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS1                   (0x20U)
#define A_ACCESS_CONTROL_M7_ACPU1_WBUS1(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS1)
#define R_ACCESS_CONTROL_M7_ACPU1_WBUS1(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1_WBUS1(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1_WBUS1                    (0xffffU)
#define MSB_ACCESS_CONTROL_M7_ACPU1_WBUS1                    15
#define LSB_ACCESS_CONTROL_M7_ACPU1_WBUS1                    0
#define AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS1                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS1)
#define REG_ACCESS_CONTROL_M7_ACPU1_WBUS1                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS1))

#define ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2           (0x22U)
#define A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2(ba)          ((ba) + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2)
#define R_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2(ba)          (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2(ba)))
#define RES_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2            (0xffffU)
#define MSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2            15
#define LSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2            0
#define AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2          (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2)
#define REG_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2            (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS2))

#define ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS2                   (0x24U)
#define A_ACCESS_CONTROL_M3_CCPU0_WBUS2(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS2)
#define R_ACCESS_CONTROL_M3_CCPU0_WBUS2(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0_WBUS2(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0_WBUS2                    (0xffffU)
#define MSB_ACCESS_CONTROL_M3_CCPU0_WBUS2                    15
#define LSB_ACCESS_CONTROL_M3_CCPU0_WBUS2                    0
#define AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS2                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS2)
#define REG_ACCESS_CONTROL_M3_CCPU0_WBUS2                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS2))

#define ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS2                   (0x26U)
#define A_ACCESS_CONTROL_M7_ACPU1_WBUS2(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS2)
#define R_ACCESS_CONTROL_M7_ACPU1_WBUS2(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1_WBUS2(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1_WBUS2                    (0xffffU)
#define MSB_ACCESS_CONTROL_M7_ACPU1_WBUS2                    15
#define LSB_ACCESS_CONTROL_M7_ACPU1_WBUS2                    0
#define AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS2                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS2)
#define REG_ACCESS_CONTROL_M7_ACPU1_WBUS2                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS2))

#define ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3           (0x28U)
#define A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3(ba)          ((ba) + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3)
#define R_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3(ba)          (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3(ba)))
#define RES_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3            (0xffffU)
#define MSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3            15
#define LSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3            0
#define AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3          (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3)
#define REG_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3            (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS3))

#define ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS3                   (0x2AU)
#define A_ACCESS_CONTROL_M3_CCPU0_WBUS3(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS3)
#define R_ACCESS_CONTROL_M3_CCPU0_WBUS3(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0_WBUS3(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0_WBUS3                    (0xffffU)
#define MSB_ACCESS_CONTROL_M3_CCPU0_WBUS3                    15
#define LSB_ACCESS_CONTROL_M3_CCPU0_WBUS3                    0
#define AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS3                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS3)
#define REG_ACCESS_CONTROL_M3_CCPU0_WBUS3                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS3))

#define ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS3                   (0x2CU)
#define A_ACCESS_CONTROL_M7_ACPU1_WBUS3(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS3)
#define R_ACCESS_CONTROL_M7_ACPU1_WBUS3(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1_WBUS3(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1_WBUS3                    (0xffffU)
#define MSB_ACCESS_CONTROL_M7_ACPU1_WBUS3                    15
#define LSB_ACCESS_CONTROL_M7_ACPU1_WBUS3                    0
#define AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS3                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS3)
#define REG_ACCESS_CONTROL_M7_ACPU1_WBUS3                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS3))

#define ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4           (0x2EU)
#define A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4(ba)          ((ba) + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4)
#define R_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4(ba)          (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4(ba)))
#define RES_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4            (0x3fU)
#define MSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4            5
#define LSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4            0
#define AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4          (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4)
#define REG_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4            (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS4))

#define ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS4                   (0x30U)
#define A_ACCESS_CONTROL_M3_CCPU0_WBUS4(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS4)
#define R_ACCESS_CONTROL_M3_CCPU0_WBUS4(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0_WBUS4(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0_WBUS4                    (0x3fU)
#define MSB_ACCESS_CONTROL_M3_CCPU0_WBUS4                    5
#define LSB_ACCESS_CONTROL_M3_CCPU0_WBUS4                    0
#define AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS4                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0_WBUS4)
#define REG_ACCESS_CONTROL_M3_CCPU0_WBUS4                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS4))

#define ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS4                   (0x32U)
#define A_ACCESS_CONTROL_M7_ACPU1_WBUS4(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS4)
#define R_ACCESS_CONTROL_M7_ACPU1_WBUS4(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1_WBUS4(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1_WBUS4                    (0x3fU)
#define MSB_ACCESS_CONTROL_M7_ACPU1_WBUS4                    5
#define LSB_ACCESS_CONTROL_M7_ACPU1_WBUS4                    0
#define AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS4                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1_WBUS4)
#define REG_ACCESS_CONTROL_M7_ACPU1_WBUS4                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS4))

#define ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW          (0x34U)
#define A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW(ba)         ((ba) + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW)
#define R_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW(ba)         (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW(ba)))
#define RES_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW           (0x3U)
#define MSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW           15
#define LSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW           0
#define AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW         (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW)
#define REG_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW           (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW))

#define ADDR_ACCESS_CONTROL_M2_SWD_R0_LOW                    (0x36U)
#define A_ACCESS_CONTROL_M2_SWD_R0_LOW(ba)                   ((ba) + ADDR_ACCESS_CONTROL_M2_SWD_R0_LOW)
#define R_ACCESS_CONTROL_M2_SWD_R0_LOW(ba)                   (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M2_SWD_R0_LOW(ba)))
#define RES_ACCESS_CONTROL_M2_SWD_R0_LOW                     (0x3U)
#define MSB_ACCESS_CONTROL_M2_SWD_R0_LOW                     15
#define LSB_ACCESS_CONTROL_M2_SWD_R0_LOW                     0
#define AADDR_ACCESS_CONTROL_M2_SWD_R0_LOW                   (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M2_SWD_R0_LOW)
#define REG_ACCESS_CONTROL_M2_SWD_R0_LOW                     (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M2_SWD_R0_LOW))

#define ADDR_ACCESS_CONTROL_M2_SWD_R1_LOW                    (0x38U)
#define A_ACCESS_CONTROL_M2_SWD_R1_LOW(ba)                   ((ba) + ADDR_ACCESS_CONTROL_M2_SWD_R1_LOW)
#define R_ACCESS_CONTROL_M2_SWD_R1_LOW(ba)                   (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M2_SWD_R1_LOW(ba)))
#define RES_ACCESS_CONTROL_M2_SWD_R1_LOW                     (0x3U)
#define MSB_ACCESS_CONTROL_M2_SWD_R1_LOW                     15
#define LSB_ACCESS_CONTROL_M2_SWD_R1_LOW                     0
#define AADDR_ACCESS_CONTROL_M2_SWD_R1_LOW                   (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M2_SWD_R1_LOW)
#define REG_ACCESS_CONTROL_M2_SWD_R1_LOW                     (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M2_SWD_R1_LOW))

#define ADDR_ACCESS_CONTROL_M3_CCPU0_R0_LOW                  (0x3AU)
#define A_ACCESS_CONTROL_M3_CCPU0_R0_LOW(ba)                 ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0_R0_LOW)
#define R_ACCESS_CONTROL_M3_CCPU0_R0_LOW(ba)                 (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0_R0_LOW(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0_R0_LOW                   (0x3U)
#define MSB_ACCESS_CONTROL_M3_CCPU0_R0_LOW                   15
#define LSB_ACCESS_CONTROL_M3_CCPU0_R0_LOW                   0
#define AADDR_ACCESS_CONTROL_M3_CCPU0_R0_LOW                 (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0_R0_LOW)
#define REG_ACCESS_CONTROL_M3_CCPU0_R0_LOW                   (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0_R0_LOW))

#define ADDR_ACCESS_CONTROL_M3_CCPU0_R1_LOW                  (0x3CU)
#define A_ACCESS_CONTROL_M3_CCPU0_R1_LOW(ba)                 ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0_R1_LOW)
#define R_ACCESS_CONTROL_M3_CCPU0_R1_LOW(ba)                 (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0_R1_LOW(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0_R1_LOW                   (0x3U)
#define MSB_ACCESS_CONTROL_M3_CCPU0_R1_LOW                   15
#define LSB_ACCESS_CONTROL_M3_CCPU0_R1_LOW                   0
#define AADDR_ACCESS_CONTROL_M3_CCPU0_R1_LOW                 (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0_R1_LOW)
#define REG_ACCESS_CONTROL_M3_CCPU0_R1_LOW                   (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0_R1_LOW))

#define ADDR_ACCESS_CONTROL_M4_SARC_R0_LOW                   (0x3EU)
#define A_ACCESS_CONTROL_M4_SARC_R0_LOW(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M4_SARC_R0_LOW)
#define R_ACCESS_CONTROL_M4_SARC_R0_LOW(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M4_SARC_R0_LOW(ba)))
#define RES_ACCESS_CONTROL_M4_SARC_R0_LOW                    (0x3U)
#define MSB_ACCESS_CONTROL_M4_SARC_R0_LOW                    15
#define LSB_ACCESS_CONTROL_M4_SARC_R0_LOW                    0
#define AADDR_ACCESS_CONTROL_M4_SARC_R0_LOW                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M4_SARC_R0_LOW)
#define REG_ACCESS_CONTROL_M4_SARC_R0_LOW                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M4_SARC_R0_LOW))

#define ADDR_ACCESS_CONTROL_M5_USI0_R0_LOW                   (0x40U)
#define A_ACCESS_CONTROL_M5_USI0_R0_LOW(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M5_USI0_R0_LOW)
#define R_ACCESS_CONTROL_M5_USI0_R0_LOW(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M5_USI0_R0_LOW(ba)))
#define RES_ACCESS_CONTROL_M5_USI0_R0_LOW                    (0x3U)
#define MSB_ACCESS_CONTROL_M5_USI0_R0_LOW                    15
#define LSB_ACCESS_CONTROL_M5_USI0_R0_LOW                    0
#define AADDR_ACCESS_CONTROL_M5_USI0_R0_LOW                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M5_USI0_R0_LOW)
#define REG_ACCESS_CONTROL_M5_USI0_R0_LOW                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M5_USI0_R0_LOW))

#define ADDR_ACCESS_CONTROL_M6_USI1_R0_LOW                   (0x42U)
#define A_ACCESS_CONTROL_M6_USI1_R0_LOW(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M6_USI1_R0_LOW)
#define R_ACCESS_CONTROL_M6_USI1_R0_LOW(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M6_USI1_R0_LOW(ba)))
#define RES_ACCESS_CONTROL_M6_USI1_R0_LOW                    (0x3U)
#define MSB_ACCESS_CONTROL_M6_USI1_R0_LOW                    15
#define LSB_ACCESS_CONTROL_M6_USI1_R0_LOW                    0
#define AADDR_ACCESS_CONTROL_M6_USI1_R0_LOW                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M6_USI1_R0_LOW)
#define REG_ACCESS_CONTROL_M6_USI1_R0_LOW                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M6_USI1_R0_LOW))

#define ADDR_ACCESS_CONTROL_M7_ACPU1_R0_LOW                  (0x44U)
#define A_ACCESS_CONTROL_M7_ACPU1_R0_LOW(ba)                 ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1_R0_LOW)
#define R_ACCESS_CONTROL_M7_ACPU1_R0_LOW(ba)                 (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1_R0_LOW(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1_R0_LOW                   (0x3U)
#define MSB_ACCESS_CONTROL_M7_ACPU1_R0_LOW                   15
#define LSB_ACCESS_CONTROL_M7_ACPU1_R0_LOW                   0
#define AADDR_ACCESS_CONTROL_M7_ACPU1_R0_LOW                 (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1_R0_LOW)
#define REG_ACCESS_CONTROL_M7_ACPU1_R0_LOW                   (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1_R0_LOW))

#define ADDR_ACCESS_CONTROL_M7_ACPU1_R1_LOW                  (0x46U)
#define A_ACCESS_CONTROL_M7_ACPU1_R1_LOW(ba)                 ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1_R1_LOW)
#define R_ACCESS_CONTROL_M7_ACPU1_R1_LOW(ba)                 (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1_R1_LOW(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1_R1_LOW                   (0x3U)
#define MSB_ACCESS_CONTROL_M7_ACPU1_R1_LOW                   15
#define LSB_ACCESS_CONTROL_M7_ACPU1_R1_LOW                   0
#define AADDR_ACCESS_CONTROL_M7_ACPU1_R1_LOW                 (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1_R1_LOW)
#define REG_ACCESS_CONTROL_M7_ACPU1_R1_LOW                   (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1_R1_LOW))

#define ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH         (0x50U)
#define A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH(ba)        ((ba) + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH)
#define R_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH(ba)        (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH(ba)))
#define RES_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH          (0xffc0U)
#define MSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH          15
#define LSB_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH          0
#define AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH        (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH)
#define REG_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH          (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH))

#define ADDR_ACCESS_CONTROL_M2_SWD_R0_HIGH                   (0x52U)
#define A_ACCESS_CONTROL_M2_SWD_R0_HIGH(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M2_SWD_R0_HIGH)
#define R_ACCESS_CONTROL_M2_SWD_R0_HIGH(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M2_SWD_R0_HIGH(ba)))
#define RES_ACCESS_CONTROL_M2_SWD_R0_HIGH                    (0xffc0U)
#define MSB_ACCESS_CONTROL_M2_SWD_R0_HIGH                    15
#define LSB_ACCESS_CONTROL_M2_SWD_R0_HIGH                    0
#define AADDR_ACCESS_CONTROL_M2_SWD_R0_HIGH                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M2_SWD_R0_HIGH)
#define REG_ACCESS_CONTROL_M2_SWD_R0_HIGH                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M2_SWD_R0_HIGH))

#define ADDR_ACCESS_CONTROL_M2_SWD_R1_HIGH                   (0x54U)
#define A_ACCESS_CONTROL_M2_SWD_R1_HIGH(ba)                  ((ba) + ADDR_ACCESS_CONTROL_M2_SWD_R1_HIGH)
#define R_ACCESS_CONTROL_M2_SWD_R1_HIGH(ba)                  (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M2_SWD_R1_HIGH(ba)))
#define RES_ACCESS_CONTROL_M2_SWD_R1_HIGH                    (0xffc0U)
#define MSB_ACCESS_CONTROL_M2_SWD_R1_HIGH                    15
#define LSB_ACCESS_CONTROL_M2_SWD_R1_HIGH                    0
#define AADDR_ACCESS_CONTROL_M2_SWD_R1_HIGH                  (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M2_SWD_R1_HIGH)
#define REG_ACCESS_CONTROL_M2_SWD_R1_HIGH                    (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M2_SWD_R1_HIGH))

#define ADDR_ACCESS_CONTROL_M3_CCPU0_R0_HIGH                 (0x56U)
#define A_ACCESS_CONTROL_M3_CCPU0_R0_HIGH(ba)                ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0_R0_HIGH)
#define R_ACCESS_CONTROL_M3_CCPU0_R0_HIGH(ba)                (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0_R0_HIGH(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0_R0_HIGH                  (0xffc0U)
#define MSB_ACCESS_CONTROL_M3_CCPU0_R0_HIGH                  15
#define LSB_ACCESS_CONTROL_M3_CCPU0_R0_HIGH                  0
#define AADDR_ACCESS_CONTROL_M3_CCPU0_R0_HIGH                (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0_R0_HIGH)
#define REG_ACCESS_CONTROL_M3_CCPU0_R0_HIGH                  (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0_R0_HIGH))

#define ADDR_ACCESS_CONTROL_M3_CCPU0_R1_HIGH                 (0x58U)
#define A_ACCESS_CONTROL_M3_CCPU0_R1_HIGH(ba)                ((ba) + ADDR_ACCESS_CONTROL_M3_CCPU0_R1_HIGH)
#define R_ACCESS_CONTROL_M3_CCPU0_R1_HIGH(ba)                (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M3_CCPU0_R1_HIGH(ba)))
#define RES_ACCESS_CONTROL_M3_CCPU0_R1_HIGH                  (0xffc0U)
#define MSB_ACCESS_CONTROL_M3_CCPU0_R1_HIGH                  15
#define LSB_ACCESS_CONTROL_M3_CCPU0_R1_HIGH                  0
#define AADDR_ACCESS_CONTROL_M3_CCPU0_R1_HIGH                (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M3_CCPU0_R1_HIGH)
#define REG_ACCESS_CONTROL_M3_CCPU0_R1_HIGH                  (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M3_CCPU0_R1_HIGH))

#define ADDR_ACCESS_CONTROL_M4_SARC_R0_HIGH                  (0x5AU)
#define A_ACCESS_CONTROL_M4_SARC_R0_HIGH(ba)                 ((ba) + ADDR_ACCESS_CONTROL_M4_SARC_R0_HIGH)
#define R_ACCESS_CONTROL_M4_SARC_R0_HIGH(ba)                 (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M4_SARC_R0_HIGH(ba)))
#define RES_ACCESS_CONTROL_M4_SARC_R0_HIGH                   (0xffc0U)
#define MSB_ACCESS_CONTROL_M4_SARC_R0_HIGH                   15
#define LSB_ACCESS_CONTROL_M4_SARC_R0_HIGH                   0
#define AADDR_ACCESS_CONTROL_M4_SARC_R0_HIGH                 (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M4_SARC_R0_HIGH)
#define REG_ACCESS_CONTROL_M4_SARC_R0_HIGH                   (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M4_SARC_R0_HIGH))

#define ADDR_ACCESS_CONTROL_M5_USI0_R0_HIGH                  (0x5CU)
#define A_ACCESS_CONTROL_M5_USI0_R0_HIGH(ba)                 ((ba) + ADDR_ACCESS_CONTROL_M5_USI0_R0_HIGH)
#define R_ACCESS_CONTROL_M5_USI0_R0_HIGH(ba)                 (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M5_USI0_R0_HIGH(ba)))
#define RES_ACCESS_CONTROL_M5_USI0_R0_HIGH                   (0xffc0U)
#define MSB_ACCESS_CONTROL_M5_USI0_R0_HIGH                   15
#define LSB_ACCESS_CONTROL_M5_USI0_R0_HIGH                   0
#define AADDR_ACCESS_CONTROL_M5_USI0_R0_HIGH                 (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M5_USI0_R0_HIGH)
#define REG_ACCESS_CONTROL_M5_USI0_R0_HIGH                   (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M5_USI0_R0_HIGH))

#define ADDR_ACCESS_CONTROL_M6_USI1_R0_HIGH                  (0x5EU)
#define A_ACCESS_CONTROL_M6_USI1_R0_HIGH(ba)                 ((ba) + ADDR_ACCESS_CONTROL_M6_USI1_R0_HIGH)
#define R_ACCESS_CONTROL_M6_USI1_R0_HIGH(ba)                 (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M6_USI1_R0_HIGH(ba)))
#define RES_ACCESS_CONTROL_M6_USI1_R0_HIGH                   (0xffc0U)
#define MSB_ACCESS_CONTROL_M6_USI1_R0_HIGH                   15
#define LSB_ACCESS_CONTROL_M6_USI1_R0_HIGH                   0
#define AADDR_ACCESS_CONTROL_M6_USI1_R0_HIGH                 (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M6_USI1_R0_HIGH)
#define REG_ACCESS_CONTROL_M6_USI1_R0_HIGH                   (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M6_USI1_R0_HIGH))

#define ADDR_ACCESS_CONTROL_M7_ACPU1_R0_HIGH                 (0x60U)
#define A_ACCESS_CONTROL_M7_ACPU1_R0_HIGH(ba)                ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1_R0_HIGH)
#define R_ACCESS_CONTROL_M7_ACPU1_R0_HIGH(ba)                (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1_R0_HIGH(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1_R0_HIGH                  (0xffc0U)
#define MSB_ACCESS_CONTROL_M7_ACPU1_R0_HIGH                  15
#define LSB_ACCESS_CONTROL_M7_ACPU1_R0_HIGH                  0
#define AADDR_ACCESS_CONTROL_M7_ACPU1_R0_HIGH                (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1_R0_HIGH)
#define REG_ACCESS_CONTROL_M7_ACPU1_R0_HIGH                  (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1_R0_HIGH))

#define ADDR_ACCESS_CONTROL_M7_ACPU1_R1_HIGH                 (0x62U)
#define A_ACCESS_CONTROL_M7_ACPU1_R1_HIGH(ba)                ((ba) + ADDR_ACCESS_CONTROL_M7_ACPU1_R1_HIGH)
#define R_ACCESS_CONTROL_M7_ACPU1_R1_HIGH(ba)                (*(volatile unsigned short *)((unsigned int)A_ACCESS_CONTROL_M7_ACPU1_R1_HIGH(ba)))
#define RES_ACCESS_CONTROL_M7_ACPU1_R1_HIGH                  (0xffc0U)
#define MSB_ACCESS_CONTROL_M7_ACPU1_R1_HIGH                  15
#define LSB_ACCESS_CONTROL_M7_ACPU1_R1_HIGH                  0
#define AADDR_ACCESS_CONTROL_M7_ACPU1_R1_HIGH                (BASE_ADDR_ACCESS_CONTROL + ADDR_ACCESS_CONTROL_M7_ACPU1_R1_HIGH)
#define REG_ACCESS_CONTROL_M7_ACPU1_R1_HIGH                  (*(volatile unsigned short *)((unsigned int)AADDR_ACCESS_CONTROL_M7_ACPU1_R1_HIGH))




#endif
