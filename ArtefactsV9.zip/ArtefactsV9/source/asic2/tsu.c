/* FPGA Release: 10512 */
#include <tsu.h>

// functions executable directly by clk

uint16_t tsu_get_transfer_status(void){
        return READ_REG_U16(BASE_ADDR_TSU + ADDR_TSU_TRANSFER_STATUS);
}

uint16_t tsu_get_rws_status(void){
        return READ_REG_U16(BASE_ADDR_TSU + ADDR_TSU_RWS_STATUS);
}

static void tsu_wait_transfer_done(void){
  while (tsu_get_transfer_status() != 0);
}

static void tsu_write_resync_reg(uint32_t addr, uint16_t value){
  tsu_wait_transfer_done();
	WRITE_REG_16(addr, value);
}

static uint16_t tsu_read_resync_reg(uint32_t addr){
  tsu_wait_transfer_done();
  READ_REG_U16(addr);
  tsu_wait_transfer_done();
  return READ_REG_U16(BASE_ADDR_TSU + ADDR_TSU_TRANSFER_READ);
}

// irq

void tsu_enable_irq(tsu_irq_t irq, bool enable){
  uint16_t temp;
  
  temp = READ_REG_U16(BASE_ADDR_TSU + ADDR_TSU_IRQ_MASK);
  if (enable) {
    temp |= (0x01 << irq);
  }
  else {
    temp &= ~(0x01 << irq);
  }
  WRITE_REG_16(BASE_ADDR_TSU + ADDR_TSU_IRQ_MASK, temp);
}

tsu_irq_t tsu_get_next_pending_irq(void){
  return (tsu_irq_t) READ_REG_U16(BASE_ADDR_TSU + ADDR_TSU_IRQ_VNO);
}

tsu_irq_status_t tsu_get_irq_status(void){
  tsu_irq_status_t temp;
  temp.val = READ_REG_U16(BASE_ADDR_TSU + ADDR_TSU_IRQ_STATUS);
  return temp;
}

tsu_irq_mask_t tsu_get_irq_mask(void){
  return READ_REG_U16(BASE_ADDR_TSU + ADDR_TSU_IRQ_MASK);
}

void tsu_clear_irq(tsu_irq_t irq) {
    WRITE_REG_16(BASE_ADDR_TSU + ADDR_TSU_IRQ_STATUS, (uint16_t) (0x01 << irq));
}

void tsu_clear_irq_vno(tsu_irq_t irq) {
    WRITE_REG_16(BASE_ADDR_TSU + ADDR_TSU_IRQ_VNO, irq);
}

void tsu_clear_all_irq(void){
   WRITE_REG_16(BASE_ADDR_TSU + ADDR_TSU_IRQ_STATUS, 0xFFFF);
}

// functions accessing comm_clk domain registers

// write

void tsu_set_up_timebase_inc(uint32_t up_timebase_inc){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_UP_TIMEBASE_INC_0, (uint16_t) (up_timebase_inc & 0x0000FFFF));
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_UP_TIMEBASE_INC_1, (uint16_t) ((up_timebase_inc >> 0x10) & 0x0000FFFF));
}

void tsu_set_cfg(uint16_t config){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG, config);
}

void tsu_set_cfg_timebase_modulus(uint16_t cfg_timebase_modulus){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_TIMEBASE_MODULUS, cfg_timebase_modulus);
}

void tsu_set_cfg_base_period_reload(uint16_t cfg_base_period_reload){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_BASE_PERIOD_RELOAD, cfg_base_period_reload);
}

void tsu_set_cfg_sub_period_reload(uint16_t p0_max, uint16_t p1_max){
  tsu_cfg_sub_period_reload_t tsu_cfg_sub_period_reload;
  tsu_cfg_sub_period_reload.val = 0;
  tsu_cfg_sub_period_reload.bf.p0_max = p0_max;
  tsu_cfg_sub_period_reload.bf.p1_max = p1_max;
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SUB_PERIOD_RELOAD, tsu_cfg_sub_period_reload.val);
}

void tsu_set_cfg_sync_out_ext(uint8_t polarity0, uint8_t length0, uint8_t polarity1, uint8_t length1){
  tsu_cfg_sync_out_ext_t cfg_sync_out_ext;
  cfg_sync_out_ext.val = 0;
  cfg_sync_out_ext.bf.polarity0 = polarity0;
  cfg_sync_out_ext.bf.length0   = length0;
  cfg_sync_out_ext.bf.polarity1 = polarity1;
  cfg_sync_out_ext.bf.length1   = length1;
  
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_OUT_EXT, cfg_sync_out_ext.val);
}

void tsu_set_cfg_sync_in(uint16_t cfg_sync_in){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_IN, cfg_sync_in);
}

void tsu_set_cfg_sync_enable(uint16_t cfg_sync_enable){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_ENABLE, cfg_sync_enable);
}

void tsu_set_cfg_sync_base_phase(uint16_t sync, uint16_t cfg_sync_base_phase){
  switch (sync){
  case SYNC_GEN_0:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_0, cfg_sync_base_phase);
    break;
  case SYNC_GEN_1:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_1, cfg_sync_base_phase);
    break;
  case SYNC_GEN_2:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_2, cfg_sync_base_phase);
    break;
  case SYNC_GEN_3:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_3, cfg_sync_base_phase);
    break;
  case SYNC_GEN_4:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_4, cfg_sync_base_phase);
    break;
  case SYNC_GEN_5:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_5, cfg_sync_base_phase);
    break;
  case SYNC_GEN_6:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_6, cfg_sync_base_phase);
    break;
  case SYNC_GEN_7:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_7, cfg_sync_base_phase);
    break;
  case SYNC_GEN_8:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_8, cfg_sync_base_phase);
    break;
  case SYNC_GEN_9:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_9, cfg_sync_base_phase);
    break;
  case SYNC_GEN_10:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_10, cfg_sync_base_phase);
    break;
  case SYNC_GEN_11:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_BASE_PHASE_11, cfg_sync_base_phase);
    break;
  default:
    break;
  }
}

void tsu_set_cfg_sync_sub_phase(uint16_t sync, uint8_t mode, uint16_t sub_phase){
  tsu_cfg_sync_sub_phase_t cfg_sync_sub_phase;
  cfg_sync_sub_phase.val = 0;
  cfg_sync_sub_phase.bf.mode = mode;
  cfg_sync_sub_phase.bf.sub_phase = sub_phase;
  switch (sync){
  case SYNC_GEN_0:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_0, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_1:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_1, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_2:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_2, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_3:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_3, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_4:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_4, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_5:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_5, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_6:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_6, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_7:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_7, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_8:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_8, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_9:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_9, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_10:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_10, cfg_sync_sub_phase.val);
    break;
  case SYNC_GEN_11:
    tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_SUB_PHASE_11, cfg_sync_sub_phase.val);
    break;    
  default:
    break;
  }
}

void tsu_set_cmd_sync_out(uint16_t cmd_sync_out){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CMD_SYNC_OUT, cmd_sync_out);
}

void tsu_set_cmd_sync_out_no(uint8_t sync_out_no){
  tsu_set_cmd_sync_out(0x01 << sync_out_no);
}

void tsu_set_rws_cmd(uint16_t rws_cmd){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_CMD, rws_cmd);
}

void tsu_set_rws_timebase_inc(uint32_t rws_timebase_inc){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_INC_0, (uint16_t) (rws_timebase_inc & 0x0000FFFF));
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_INC_1, (uint16_t) ((rws_timebase_inc >> 16) & 0x0000FFFF));
}

void tsu_set_rws_timebase(uint64_t rws_timebase){
  tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_0, (uint16_t) (rws_timebase));
  rws_timebase = rws_timebase >> 16;
  tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_1, (uint16_t) (rws_timebase));
  rws_timebase = rws_timebase >> 16;
  tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_2, (uint16_t) (rws_timebase));
  rws_timebase = rws_timebase >> 16;
  tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_3, (uint16_t) (rws_timebase));
}

void tsu_set_rws_base_phase(uint16_t rws_base_phase){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_BASE_PHASE, rws_base_phase);
}

void tsu_set_rws_sub_phase(uint16_t p0, uint16_t p1){
  tsu_rws_sub_phase_t rws_sub_phase;
  rws_sub_phase.val = 0;
  rws_sub_phase.bf.p0 = p0;
  rws_sub_phase.bf.p1 = p1;
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_SUB_PHASE, rws_sub_phase.val);
}

void tsu_up_timebase_inc(void){
	tsu_write_resync_reg(BASE_ADDR_TSU + ADDR_TSU_UP_TIMEBASE_INC_CMD, 1);
}


// read

uint32_t tsu_get_up_timebase_inc(void){
  uint32_t ret;
  ret  = tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_UP_TIMEBASE_INC_1); ret = ret << 16;
  ret |= tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_UP_TIMEBASE_INC_0);
  return ret;
}

uint16_t tsu_get_cfg(void){
  return tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG);
}

uint16_t tsu_get_cfg_timebase_modulus(void){
	return tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_TIMEBASE_MODULUS);
}

uint16_t tsu_get_cfg_base_period_reload(void){
	return tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_BASE_PERIOD_RELOAD);
}

tsu_cfg_sub_period_reload_t tsu_get_cfg_sub_period_reload(void){
  tsu_cfg_sub_period_reload_t temp;
  temp.val = tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SUB_PERIOD_RELOAD);
  return temp;
}

tsu_cfg_sync_out_ext_t tsu_get_cfg_sync_out_ext(void){
  tsu_cfg_sync_out_ext_t temp;
  temp.val = tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_OUT_EXT);
  return temp;
}

uint16_t tsu_get_cfg_sync_in(void){
	return tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_CFG_SYNC_IN);
}

uint32_t tsu_get_rws_timebase_inc(void){
  uint32_t ret;
  ret  = tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_INC_1); ret = ret << 16;
  ret |= tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_INC_0);
  return ret;
}

uint64_t tsu_get_rws_timebase(void){
  uint64_t ret;
  ret  = tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_3); ret = ret << 16;
  ret |= tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_2); ret = ret << 16;
  ret |= tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_1); ret = ret << 16;
  ret |= tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_TIMEBASE_0);
  return ret;
}

uint16_t tsu_get_rws_base_phase(void){
  return tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_BASE_PHASE);
}

tsu_rws_sub_phase_t tsu_get_rws_sub_phase(void){
  tsu_rws_sub_phase_t temp;
  //temp.val = READ_REG_U16(BASE_ADDR_TSU + ADDR_TSU_RWS_SUB_PHASE);
  temp.val = tsu_read_resync_reg(BASE_ADDR_TSU + ADDR_TSU_RWS_SUB_PHASE);
  return temp;
}

uint16_t tsu_get_rws_sub_phase_0(void){
	tsu_rws_sub_phase_t tsu_rws_sub_phase;
  tsu_rws_sub_phase.val = 0;
  
  tsu_rws_sub_phase = tsu_get_rws_sub_phase();
  return (uint16_t) tsu_rws_sub_phase.bf.p0;
}

uint16_t tsu_get_rws_sub_phase_1(void){
	tsu_rws_sub_phase_t tsu_rws_sub_phase;
  tsu_rws_sub_phase.val = 0;
  
  tsu_rws_sub_phase = tsu_get_rws_sub_phase();
  return (uint16_t) tsu_rws_sub_phase.bf.p1;
}
