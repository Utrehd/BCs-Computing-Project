/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         usi_bf.h
*
* @brief        USI HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __USI_BF_H__
#define __USI_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_USI0
#define BASE_ADDR_USI0 0x40007000U
#endif
#ifndef BASE_ADDR_USI1
#define BASE_ADDR_USI1 0x40007080U
#endif

#define MULTIPLE_USI
#define NUMBER_USI 2

/**
  * \brief This is an enum class for USI instance
  *
  * \ingroup usi
  */ 
typedef enum {
  USI0                           = (int)BASE_ADDR_USI0, ///< this is instance USI0
  USI1                           = (int)BASE_ADDR_USI1  ///< this is instance USI1
} usi_num_t;

// Register bit field definitions

/* USI_CFG */

#define MSK_USI_CFG_EN                                      (0x1)     /* [0] */
#define RES_USI_CFG_EN                                      (0x0)
#define SFT_USI_CFG_EN                                      (0)
#define LSB_USI_CFG_EN                                      (0)
#define MSB_USI_CFG_EN                                      (0)
#define BIT_USI_CFG_EN                                      (0x1)     /* [0] */
#define MSK_USI_CFG_MODE                                    (0x1)     /* [1] */
#define RES_USI_CFG_MODE                                    (0x0)
#define SFT_USI_CFG_MODE                                    (1)
#define LSB_USI_CFG_MODE                                    (1)
#define MSB_USI_CFG_MODE                                    (1)
#define BIT_USI_CFG_MODE                                    (0x2)     /* [1] */
#define MSK_USI_CFG_DMA_TX_MODE                             (0x1)     /* [2] */
#define RES_USI_CFG_DMA_TX_MODE                             (0x0)
#define SFT_USI_CFG_DMA_TX_MODE                             (2)
#define LSB_USI_CFG_DMA_TX_MODE                             (2)
#define MSB_USI_CFG_DMA_TX_MODE                             (2)
#define BIT_USI_CFG_DMA_TX_MODE                             (0x4)     /* [2] */
#define MSK_USI_CFG_DMA_RX_MODE                             (0x1)     /* [3] */
#define RES_USI_CFG_DMA_RX_MODE                             (0x0)
#define SFT_USI_CFG_DMA_RX_MODE                             (3)
#define LSB_USI_CFG_DMA_RX_MODE                             (3)
#define MSB_USI_CFG_DMA_RX_MODE                             (3)
#define BIT_USI_CFG_DMA_RX_MODE                             (0x8)     /* [3] */
#define MSK_USI_CFG_TX_EN                                   (0x1)     /* [4] */
#define RES_USI_CFG_TX_EN                                   (0x0)
#define SFT_USI_CFG_TX_EN                                   (4)
#define LSB_USI_CFG_TX_EN                                   (4)
#define MSB_USI_CFG_TX_EN                                   (4)
#define BIT_USI_CFG_TX_EN                                   (0x10)    /* [4] */
#define MSK_USI_CFG_RX_EN                                   (0x1)     /* [5] */
#define RES_USI_CFG_RX_EN                                   (0x0)
#define SFT_USI_CFG_RX_EN                                   (5)
#define LSB_USI_CFG_RX_EN                                   (5)
#define MSB_USI_CFG_RX_EN                                   (5)
#define BIT_USI_CFG_RX_EN                                   (0x20)    /* [5] */
#define MSK_USI_CFG_SDI_SDO_SWAP                            (0x1)     /* [6] */
#define RES_USI_CFG_SDI_SDO_SWAP                            (0x0)
#define SFT_USI_CFG_SDI_SDO_SWAP                            (6)
#define LSB_USI_CFG_SDI_SDO_SWAP                            (6)
#define MSB_USI_CFG_SDI_SDO_SWAP                            (6)
#define BIT_USI_CFG_SDI_SDO_SWAP                            (0x40)    /* [6] */
#define MSK_USI_CFG_SDI_SDO_LOOPBACK                        (0x1)     /* [7] */
#define RES_USI_CFG_SDI_SDO_LOOPBACK                        (0x0)
#define SFT_USI_CFG_SDI_SDO_LOOPBACK                        (7)
#define LSB_USI_CFG_SDI_SDO_LOOPBACK                        (7)
#define MSB_USI_CFG_SDI_SDO_LOOPBACK                        (7)
#define BIT_USI_CFG_SDI_SDO_LOOPBACK                        (0x80)    /* [7] */
#define MSK_USI_CFG_SDI_USES_SDO_I                          (0x1)     /* [8] */
#define RES_USI_CFG_SDI_USES_SDO_I                          (0x0)
#define SFT_USI_CFG_SDI_USES_SDO_I                          (8)
#define LSB_USI_CFG_SDI_USES_SDO_I                          (8)
#define MSB_USI_CFG_SDI_USES_SDO_I                          (8)
#define BIT_USI_CFG_SDI_USES_SDO_I                          (0x100)   /* [8] */
#define MSK_USI_CFG_SDO_INV                                 (0x1)     /* [9] */
#define RES_USI_CFG_SDO_INV                                 (0x0)
#define SFT_USI_CFG_SDO_INV                                 (9)
#define LSB_USI_CFG_SDO_INV                                 (9)
#define MSB_USI_CFG_SDO_INV                                 (9)
#define BIT_USI_CFG_SDO_INV                                 (0x200)   /* [9] */
#define MSK_USI_CFG_SDI_INV                                 (0x1)     /* [10] */
#define RES_USI_CFG_SDI_INV                                 (0x0)
#define SFT_USI_CFG_SDI_INV                                 (10)
#define LSB_USI_CFG_SDI_INV                                 (10)
#define MSB_USI_CFG_SDI_INV                                 (10)
#define BIT_USI_CFG_SDI_INV                                 (0x400)   /* [10] */
#define MSK_USI_CFG_NSS_INV                                 (0x1)     /* [11] */
#define RES_USI_CFG_NSS_INV                                 (0x0)
#define SFT_USI_CFG_NSS_INV                                 (11)
#define LSB_USI_CFG_NSS_INV                                 (11)
#define MSB_USI_CFG_NSS_INV                                 (11)
#define BIT_USI_CFG_NSS_INV                                 (0x800)   /* [11] */

/** 
 * \brief This structure describes USI configuration 
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * USI enabled
   * Disabling the module will stop all transfers and DMA operations
   * in progress and clear all data and pointer FIFOs.
   */
  unsigned short en                            :    1;       /* [0] */
   
  /**
   * 0: Uart mode<br>
   * 1: SPI mode<br>
   * Mode may only be changed when CFG.en=0<br>
   */
  unsigned short mode                          :    1;       /* [1] */
  
  /**
   * 0: DMA transfer ends when tdlen is reached <br>
   * 1: like "0" but also when SPI slave transfer ends <br>
   */
  unsigned short dma_tx_mode                   :    1;       /* [2] */
  
  /** 
   * 0: DMA transfer ends when maxlen is reached <br>
   * 1: like "0" but also when SPI slave transfer ends <br>
   */
  unsigned short dma_rx_mode                   :    1;       /* [3] */
  
  /**
   * enable transmit function
   */
  unsigned short tx_en                         :    1;       /* [4] */
  
  /**
   * enable receive function
   */
  unsigned short rx_en                         :    1;       /* [5] */
  
  /**
   * swap sdi and sdo assignment at module interface
   */
  unsigned short sdi_sdo_swap                  :    1;       /* [6] */
  
  /**
   * connect sdo to sdi internally
   */
  unsigned short sdi_sdo_loopback              :    1;       /* [7] */
  
  /**
   * sdi connected to sdo_i for half duplex communication without external phy
   */
  unsigned short sdi_uses_sdo_i                :    1;       /* [8] */
  
  /**
   * invert sdo_o and sdo_i
   */
  unsigned short sdo_inv                       :    1;       /* [9] */
  
  /**
   * invert sdi_i
   */
  unsigned short sdi_inv                       :    1;       /* [10] */
  
  /**
   * invert nss_o and nss_i
   */
  unsigned short nss_inv                       :    1;       /* [11] */
  
  unsigned short reserved                      :    4;
} usi_cfg_bf;

/**
 * \brief Conversion type between word and bit representation of USI configuration
 *
 * \ingroup usi
 */
typedef union {
  unsigned short val; ///< word representation
  usi_cfg_bf bf;      ///< bit field representation
} usi_cfg_t;


/* USI_CFG_BRE */

#define MSK_USI_CFG_BRE                                     (0x7)     /* [ 2:0] */

typedef unsigned short usi_cfg_bre_t;                                 /* [ 2:0] */


/* USI_BRE_RES */

#define MSK_USI_BRE_RES                                     (0xffff)  /* [15:0] */

typedef unsigned short usi_bre_res_t;                                 /* [15:0] */


/* USI_BR_INC */

#define MSK_USI_BR_INC                                      (0xffff)  /* [15:0] */

typedef unsigned short usi_br_inc_t;                                  /* [15:0] */


/* USI_BR_MOD */

#define MSK_USI_BR_MOD                                      (0xffff)  /* [15:0] */

typedef unsigned short usi_br_mod_t;                                  /* [15:0] */


/* USI_TICK */

#define MSK_USI_TICK                                        (0x1ff)   /* [ 8:0] */

typedef unsigned short usi_tick_t;                                    /* [ 8:0] */


/* USI_CFG_INTF */

#define MSK_USI_CFG_INTF                                    (0xffff)  /* [15:0] */

typedef unsigned short usi_cfg_intf_t;                                /* [15:0] */


/* USI_CFG_U_BL */

#define MSK_USI_CFG_U_BL_MSB_FIRST                          (0x1)     /* [0] */
#define RES_USI_CFG_U_BL_MSB_FIRST                          (0x0)
#define SFT_USI_CFG_U_BL_MSB_FIRST                          (0)
#define LSB_USI_CFG_U_BL_MSB_FIRST                          (0)
#define MSB_USI_CFG_U_BL_MSB_FIRST                          (0)
#define BIT_USI_CFG_U_BL_MSB_FIRST                          (0x1)     /* [0] */
#define MSK_USI_CFG_U_BL_DATA_BITS                          (0x1)     /* [1] */
#define RES_USI_CFG_U_BL_DATA_BITS                          (0x0)
#define SFT_USI_CFG_U_BL_DATA_BITS                          (1)
#define LSB_USI_CFG_U_BL_DATA_BITS                          (1)
#define MSB_USI_CFG_U_BL_DATA_BITS                          (1)
#define BIT_USI_CFG_U_BL_DATA_BITS                          (0x2)     /* [1] */
#define MSK_USI_CFG_U_BL_STOP_BITS                          (0x1)     /* [2] */
#define RES_USI_CFG_U_BL_STOP_BITS                          (0x0)
#define SFT_USI_CFG_U_BL_STOP_BITS                          (2)
#define LSB_USI_CFG_U_BL_STOP_BITS                          (2)
#define MSB_USI_CFG_U_BL_STOP_BITS                          (2)
#define BIT_USI_CFG_U_BL_STOP_BITS                          (0x4)     /* [2] */
#define MSK_USI_CFG_U_BL_PAR_TYPE                           (0x3)     /* [ 4:3] */
#define RES_USI_CFG_U_BL_PAR_TYPE                           (0x0)
#define SFT_USI_CFG_U_BL_PAR_TYPE                           (3)
#define LSB_USI_CFG_U_BL_PAR_TYPE                           (3)
#define MSB_USI_CFG_U_BL_PAR_TYPE                           (4)
#define MSK_USI_CFG_U_BL_BREAK_TX_LEN                       (0x7)     /* [ 7:5] */
#define RES_USI_CFG_U_BL_BREAK_TX_LEN                       (0x0)
#define SFT_USI_CFG_U_BL_BREAK_TX_LEN                       (5)
#define LSB_USI_CFG_U_BL_BREAK_TX_LEN                       (5)
#define MSB_USI_CFG_U_BL_BREAK_TX_LEN                       (7)
#define MSK_USI_CFG_U_BL_BREAK_RX_THR                       (0x7)     /* [10:8] */
#define RES_USI_CFG_U_BL_BREAK_RX_THR                       (0x0)
#define SFT_USI_CFG_U_BL_BREAK_RX_THR                       (8)
#define LSB_USI_CFG_U_BL_BREAK_RX_THR                       (8)
#define MSB_USI_CFG_U_BL_BREAK_RX_THR                       (10)
#define MSK_USI_CFG_U_BL_BREAK_CONC                         (0x1)     /* [11] */
#define RES_USI_CFG_U_BL_BREAK_CONC                         (0x0)
#define SFT_USI_CFG_U_BL_BREAK_CONC                         (11)
#define LSB_USI_CFG_U_BL_BREAK_CONC                         (11)
#define MSB_USI_CFG_U_BL_BREAK_CONC                         (11)
#define BIT_USI_CFG_U_BL_BREAK_CONC                         (0x800)   /* [11] */



/** 
 * \brief This structure describes USI UART mode configuration 
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * 0: data bits transmitted LSB first
   * 1: data bits transmitted MSB first
   */
  unsigned short msb_first                     :    1;       /* [0] */
  
  /**
   * number of data bits
   * 0: 8 data bits
   * 1: 7 data bits
   */
  unsigned short data_bits                     :    1;       /* [1] */
  
  /**
   * number of stop bits for transmit<br>
   * 0: one stop bit<br>
   * 1: two stop bits<br>
   */
  unsigned short stop_bits                     :    1;       /* [2] */
  
  /**
   * type of parity bit<br>
   * 0: no parity bit<br>
   * 1: odd parity bit<br>
   * 2: even parity bit<br>
   */
  unsigned short par_type                      :    2;       /* [ 4:3] */
  
  /**
   * number of transmitted break bits = 10 + break_tx_len
   */
  unsigned short break_tx_len                  :    3;       /* [ 7:5] */
  
  /** 
   * threshold (inclusive) for detecting break word = 10 + break_rx_thr
   */
  unsigned short break_rx_thr                  :    3;       /* [10:8] */
  
  /**
   * 0: disable concurrent break detection. A break can only start at
   * the beginning of a Uart word.<br>
   * 1: enable concurrent break detection. A break can also start
   * within any position of a Uart word.<br>
   */
  unsigned short break_conc                    :    1;       /* [11] */
  
  unsigned short reserved                      :    4;
} usi_cfg_u_bl_bf;

/**
 * \brief Conversion type between word and bit representation of USI UART mode configuration 
 *
 * \ingroup usi
 */
typedef union {
  unsigned short val; ///< word representation
  usi_cfg_u_bl_bf bf; ///< bit field representation
} usi_cfg_u_bl_t;


/* USI_CFG_U_TICK */

#define MSK_USI_CFG_U_TICK_RX_START                         (0xff)    /* [ 7:0] */
#define RES_USI_CFG_U_TICK_RX_START                         (0x00)
#define SFT_USI_CFG_U_TICK_RX_START                         (0)
#define LSB_USI_CFG_U_TICK_RX_START                         (0)
#define MSB_USI_CFG_U_TICK_RX_START                         (7)
#define MSK_USI_CFG_U_TICK_RX_LEN                           (0xff)    /* [15:8] */
#define RES_USI_CFG_U_TICK_RX_LEN                           (0x00)
#define SFT_USI_CFG_U_TICK_RX_LEN                           (8)
#define LSB_USI_CFG_U_TICK_RX_LEN                           (8)
#define MSB_USI_CFG_U_TICK_RX_LEN                           (15)

/** 
 * \brief This structure describes USI UART ticks definition (sampling)
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * start of sampling window in ticks from the start of the bit
   */
  unsigned short rx_start                      :    8;       /* [ 7:0] */
  
  /**
   * duration of sampling window in ticks
   */
  unsigned short rx_len                        :    8;       /* [15:8] */
} usi_cfg_u_tick_bf;

/**
 * \brief Conversion type between word and bit representation of USI UART ticks definition (sampling)
 *
 * \ingroup usi
 */
typedef union {
  unsigned short val;   ///< word representation
  usi_cfg_u_tick_bf bf; ///< bit field representation
} usi_cfg_u_tick_t;


/* USI_CFG_U_START_THRESHOLD */

#define MSK_USI_CFG_U_START_THRESHOLD                       (0xffff)  /* [15:0] */

typedef unsigned short usi_cfg_u_start_threshold_t;                   /* [15:0] */


/* USI_CFG_U_HALF_DUPLEX */

#define MSK_USI_CFG_U_HALF_DUPLEX_NSS_MODE                  (0x3)     /* [ 1:0] */
#define RES_USI_CFG_U_HALF_DUPLEX_NSS_MODE                  (0x0)
#define SFT_USI_CFG_U_HALF_DUPLEX_NSS_MODE                  (0)
#define LSB_USI_CFG_U_HALF_DUPLEX_NSS_MODE                  (0)
#define MSB_USI_CFG_U_HALF_DUPLEX_NSS_MODE                  (1)
#define MSK_USI_CFG_U_HALF_DUPLEX_SDO_MODE                  (0x1)     /* [2] */
#define RES_USI_CFG_U_HALF_DUPLEX_SDO_MODE                  (0x0)
#define SFT_USI_CFG_U_HALF_DUPLEX_SDO_MODE                  (2)
#define LSB_USI_CFG_U_HALF_DUPLEX_SDO_MODE                  (2)
#define MSB_USI_CFG_U_HALF_DUPLEX_SDO_MODE                  (2)
#define BIT_USI_CFG_U_HALF_DUPLEX_SDO_MODE                  (0x4)     /* [2] */
#define MSK_USI_CFG_U_HALF_DUPLEX_SDO_DRV_PRE               (0xf)     /* [ 6:3] */
#define RES_USI_CFG_U_HALF_DUPLEX_SDO_DRV_PRE               (0x1)
#define SFT_USI_CFG_U_HALF_DUPLEX_SDO_DRV_PRE               (3)
#define LSB_USI_CFG_U_HALF_DUPLEX_SDO_DRV_PRE               (3)
#define MSB_USI_CFG_U_HALF_DUPLEX_SDO_DRV_PRE               (6)
#define MSK_USI_CFG_U_HALF_DUPLEX_SDO_DRV_POST              (0xf)     /* [10:7] */
#define RES_USI_CFG_U_HALF_DUPLEX_SDO_DRV_POST              (0x1)
#define SFT_USI_CFG_U_HALF_DUPLEX_SDO_DRV_POST              (7)
#define LSB_USI_CFG_U_HALF_DUPLEX_SDO_DRV_POST              (7)
#define MSB_USI_CFG_U_HALF_DUPLEX_SDO_DRV_POST              (10)
#define MSK_USI_CFG_U_HALF_DUPLEX_ECHO_CANCEL               (0x1)     /* [11] */
#define RES_USI_CFG_U_HALF_DUPLEX_ECHO_CANCEL               (0x0)
#define SFT_USI_CFG_U_HALF_DUPLEX_ECHO_CANCEL               (11)
#define LSB_USI_CFG_U_HALF_DUPLEX_ECHO_CANCEL               (11)
#define MSB_USI_CFG_U_HALF_DUPLEX_ECHO_CANCEL               (11)
#define BIT_USI_CFG_U_HALF_DUPLEX_ECHO_CANCEL               (0x800)   /* [11] */

/** 
 * \brief This structure describes USI UART hal duplex configuration 
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * 0: assert nss (0 when not inverted) <br>
   * 1: deassert nss<br>
   * 2: nss controlled by USI: asserted during transmit<br>
   */     
  unsigned short nss_mode                      :    2;       /* [ 1:0] */
  
  /**
   * 0: assert sdo_oe<br>
   * 1: sdo_oe controlled by USI: asserted during transmit<br>
   */
  unsigned short sdo_mode                      :    1;       /* [2] */
  
  /** 
   * 1..MAX number of bit times nss respectively sdo_oe is asserted
   * before leading edge of start bit
   */
  unsigned short sdo_drv_pre                   :    4;       /* [ 6:3] */
  
  /**
   * 1..MAX number of bit times nss respectively sdo_oe is asserted
   * after transmission of last stop bit
   */
  unsigned short sdo_drv_post                  :    4;       /* [10:7] */
  
  /**
   * 1: prevent reception of data words with start bit during own transmission
   */
  unsigned short echo_cancel                   :    1;       /* [11] */
  unsigned short reserved                      :    4;
} usi_cfg_u_half_duplex_bf;

/**
 * \brief Conversion type between word and bit representation of USI UART hal duplex configuration 
 *
 * \ingroup usi
 */
typedef union {
  unsigned short val;
  usi_cfg_u_half_duplex_bf bf; ///< word representation
} usi_cfg_u_half_duplex_t;     ///< bit field representation


/* USI_CFG_SPI_BL */

#define MSK_USI_CFG_SPI_BL_PHASE                            (0x1)     /* [0] */
#define RES_USI_CFG_SPI_BL_PHASE                            (0x0)
#define SFT_USI_CFG_SPI_BL_PHASE                            (0)
#define LSB_USI_CFG_SPI_BL_PHASE                            (0)
#define MSB_USI_CFG_SPI_BL_PHASE                            (0)
#define BIT_USI_CFG_SPI_BL_PHASE                            (0x1)     /* [0] */
#define MSK_USI_CFG_SPI_BL_POLARITY                         (0x1)     /* [1] */
#define RES_USI_CFG_SPI_BL_POLARITY                         (0x0)
#define SFT_USI_CFG_SPI_BL_POLARITY                         (1)
#define LSB_USI_CFG_SPI_BL_POLARITY                         (1)
#define MSB_USI_CFG_SPI_BL_POLARITY                         (1)
#define BIT_USI_CFG_SPI_BL_POLARITY                         (0x2)     /* [1] */
#define MSK_USI_CFG_SPI_BL_MSB_FIRST                        (0x1)     /* [2] */
#define RES_USI_CFG_SPI_BL_MSB_FIRST                        (0x0)
#define SFT_USI_CFG_SPI_BL_MSB_FIRST                        (2)
#define LSB_USI_CFG_SPI_BL_MSB_FIRST                        (2)
#define MSB_USI_CFG_SPI_BL_MSB_FIRST                        (2)
#define BIT_USI_CFG_SPI_BL_MSB_FIRST                        (0x4)     /* [2] */
#define MSK_USI_CFG_SPI_BL_DATA_BITS                        (0x1f)    /* [ 7:3] */
#define RES_USI_CFG_SPI_BL_DATA_BITS                        (0x08)
#define SFT_USI_CFG_SPI_BL_DATA_BITS                        (3)
#define LSB_USI_CFG_SPI_BL_DATA_BITS                        (3)
#define MSB_USI_CFG_SPI_BL_DATA_BITS                        (7)
#define MSK_USI_CFG_SPI_BL_SLAVE                            (0x1)     /* [8] */
#define RES_USI_CFG_SPI_BL_SLAVE                            (0x0)
#define SFT_USI_CFG_SPI_BL_SLAVE                            (8)
#define LSB_USI_CFG_SPI_BL_SLAVE                            (8)
#define MSB_USI_CFG_SPI_BL_SLAVE                            (8)
#define BIT_USI_CFG_SPI_BL_SLAVE                            (0x100)   /* [8] */
#define MSK_USI_CFG_SPI_BL_NSS_MODE                         (0x1)     /* [9] */
#define RES_USI_CFG_SPI_BL_NSS_MODE                         (0x0)
#define SFT_USI_CFG_SPI_BL_NSS_MODE                         (9)
#define LSB_USI_CFG_SPI_BL_NSS_MODE                         (9)
#define MSB_USI_CFG_SPI_BL_NSS_MODE                         (9)
#define BIT_USI_CFG_SPI_BL_NSS_MODE                         (0x200)   /* [9] */
#define MSK_USI_CFG_SPI_BL_SDO_HIGH_Z                       (0x1)     /* [10] */
#define RES_USI_CFG_SPI_BL_SDO_HIGH_Z                       (0x0)
#define SFT_USI_CFG_SPI_BL_SDO_HIGH_Z                       (10)
#define LSB_USI_CFG_SPI_BL_SDO_HIGH_Z                       (10)
#define MSB_USI_CFG_SPI_BL_SDO_HIGH_Z                       (10)
#define BIT_USI_CFG_SPI_BL_SDO_HIGH_Z                       (0x400)   /* [10] */
#define MSK_USI_CFG_SPI_BL_SDI_IRQ_POL                      (0x1)     /* [11] */
#define RES_USI_CFG_SPI_BL_SDI_IRQ_POL                      (0x0)
#define SFT_USI_CFG_SPI_BL_SDI_IRQ_POL                      (11)
#define LSB_USI_CFG_SPI_BL_SDI_IRQ_POL                      (11)
#define MSB_USI_CFG_SPI_BL_SDI_IRQ_POL                      (11)
#define BIT_USI_CFG_SPI_BL_SDI_IRQ_POL                      (0x800)   /* [11] */

/** 
 * \brief This structure describes USI SPI mode configuration
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * phase<br>
   * 0: 1st edge shift, 2nd edge sample<br>
   * 1: 1st edge sample, 2nd edge shift<br>
   */
  unsigned short phase                         :    1;       /* [0] */
  
  /**
   * polarity<br>
   * 0: clock off level 0<br>
   * 1: clock off level 1<br>
   */
  unsigned short polarity                      :    1;       /* [1] */
  
  /**
   * 0: LSB transmitted first<br>
   * 1: MSB transmitted first<br>
   */
  unsigned short msb_first                     :    1;       /* [2] */
  
  /**
   * 7..16 data bit count to transfer
   */
  unsigned short data_bits                     :    5;       /* [ 7:3] */
  
  /** 
   * 0: SPI master<br>
   * 1: SPI slave<br>
   */
  unsigned short slave                         :    1;       /* [8] */
  
  /**
   * when SPI interface is configured as master:<br>
   *   minimum SPI frame word shift NSS inactive time between SPI frames<br>
   *   0: 1 bit length<br>
   *   1: 2 bit lengths<br>
   * <br>
   * when SPI interface is configured as slave:<br>
   * 0: Only nss can start an SPI frame.<br>
   *    Nss can end SPI frame.<br>
   * 1: Nss ignored.<br>
   *    Ony sck can start SPI frame.<br>
   *    Only sck_timeout can end SPI frame (see CFG_SPI_SCK_TIMEOUT)<br>
   */
  unsigned short nss_mode                      :    1;       /* [9] */
  
  /**
   * when SPI interface is configured as master:<br>
   *   this config bit is ignored<br>
   * when SPI interface is configured as slave:<br>
   *   0: always drive sdo (sdo_oe=1)<br>
   *   1: sdo switched to high Z when nss is not asserted<br>
   */
  unsigned short sdo_high_z                    :    1;       /* [10] */
  
  /**
   * SDI interrupt active level when nss is not asserted
   */
  unsigned short sdi_irq_pol                   :    1;       /* [11] */
  unsigned short reserved                      :    4;
} usi_cfg_spi_bl_bf;

/**
 * \brief Conversion type between word and bit representation of USI SPI mode configuration
 *
 * \ingroup usi
 */
typedef union {
  unsigned short val;   ///< word representation
  usi_cfg_spi_bl_bf bf; ///< bit field representation
} usi_cfg_spi_bl_t;


/* USI_CFG_SPI_EARLY_SDO */

#define MSK_USI_CFG_SPI_EARLY_SDO                           (0xf)     /* [ 3:0] */

typedef unsigned short usi_cfg_spi_early_sdo_t;                       /* [ 3:0] */


/* USI_CFG_SPI_SCK_TIMEOUT */

#define MSK_USI_CFG_SPI_SCK_TIMEOUT_SCK_TIMEOUT             (0xff)    /* [ 7:0] */
#define RES_USI_CFG_SPI_SCK_TIMEOUT_SCK_TIMEOUT             (0x03)
#define SFT_USI_CFG_SPI_SCK_TIMEOUT_SCK_TIMEOUT             (0)
#define LSB_USI_CFG_SPI_SCK_TIMEOUT_SCK_TIMEOUT             (0)
#define MSB_USI_CFG_SPI_SCK_TIMEOUT_SCK_TIMEOUT             (7)
#define MSK_USI_CFG_SPI_SCK_TIMEOUT_BITLENGTH_SEL           (0x1)     /* [8] */
#define RES_USI_CFG_SPI_SCK_TIMEOUT_BITLENGTH_SEL           (0x0)
#define SFT_USI_CFG_SPI_SCK_TIMEOUT_BITLENGTH_SEL           (8)
#define LSB_USI_CFG_SPI_SCK_TIMEOUT_BITLENGTH_SEL           (8)
#define MSB_USI_CFG_SPI_SCK_TIMEOUT_BITLENGTH_SEL           (8)
#define BIT_USI_CFG_SPI_SCK_TIMEOUT_BITLENGTH_SEL           (0x100)   /* [8] */

/** 
 * \brief This structure describes USI SPI sck timeout configuration
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * when SPI interface is configured as master:
   *   this config value is ignored
   * when SPI interface is configured as slave:
   *   2..MAX: SPI frame ends when sck_timeout bit periods have
   */
  unsigned short sck_timeout                   :    8;       /* [ 7:0] */
  
  /**
   * 0: bitlength will be detected by incoming sck.
   * 1: bitlength is determined by internal tick generator.
   */
  unsigned short bitlength_sel                 :    1;       /* [8] */
  unsigned short reserved                      :    7;
} usi_cfg_spi_sck_timeout_bf;

/**
 * \brief Conversion type between word and bit representation of USI SPI sck timeout configuration
 *
 * \ingroup usi
 */
typedef union {
  unsigned short val;            ///< word representation
  usi_cfg_spi_sck_timeout_bf bf; ///< bit field representation
} usi_cfg_spi_sck_timeout_t;     


/* USI_DMA_CMD */

#define MSK_USI_DMA_CMD_TADR_CURRENT_SKIP                   (0x1)     /* [0] */
#define RES_USI_DMA_CMD_TADR_CURRENT_SKIP                   (0x0)
#define SFT_USI_DMA_CMD_TADR_CURRENT_SKIP                   (0)
#define LSB_USI_DMA_CMD_TADR_CURRENT_SKIP                   (0)
#define MSB_USI_DMA_CMD_TADR_CURRENT_SKIP                   (0)
#define BIT_USI_DMA_CMD_TADR_CURRENT_SKIP                   (0x1)     /* [0] */
#define MSK_USI_DMA_CMD_TADR_NEW_CLR                        (0x1)     /* [1] */
#define RES_USI_DMA_CMD_TADR_NEW_CLR                        (0x0)
#define SFT_USI_DMA_CMD_TADR_NEW_CLR                        (1)
#define LSB_USI_DMA_CMD_TADR_NEW_CLR                        (1)
#define MSB_USI_DMA_CMD_TADR_NEW_CLR                        (1)
#define BIT_USI_DMA_CMD_TADR_NEW_CLR                        (0x2)     /* [1] */
#define MSK_USI_DMA_CMD_RADR_CURRENT_SKIP                   (0x1)     /* [2] */
#define RES_USI_DMA_CMD_RADR_CURRENT_SKIP                   (0x0)
#define SFT_USI_DMA_CMD_RADR_CURRENT_SKIP                   (2)
#define LSB_USI_DMA_CMD_RADR_CURRENT_SKIP                   (2)
#define MSB_USI_DMA_CMD_RADR_CURRENT_SKIP                   (2)
#define BIT_USI_DMA_CMD_RADR_CURRENT_SKIP                   (0x4)     /* [2] */
#define MSK_USI_DMA_CMD_RADR_NEW_CLR                        (0x1)     /* [3] */
#define RES_USI_DMA_CMD_RADR_NEW_CLR                        (0x0)
#define SFT_USI_DMA_CMD_RADR_NEW_CLR                        (3)
#define LSB_USI_DMA_CMD_RADR_NEW_CLR                        (3)
#define MSB_USI_DMA_CMD_RADR_NEW_CLR                        (3)
#define BIT_USI_DMA_CMD_RADR_NEW_CLR                        (0x8)     /* [3] */

/** 
 * \brief This structure describes USI DMA command
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * terminate (skip) current transmit data structure TADR_CURRENT and
   * continue with the next
   */
  unsigned short tadr_current_skip             :    1;       /* [0] */
  
  /**
   * 1: clear the FIFO TADR_NEW
   */
  unsigned short tadr_new_clr                  :    1;       /* [1] */
  
  /**
   * Write rdlen and then terminate (skip) current receive data structure
   * RADR_CURRENT and continue with the next
   */
  unsigned short radr_current_skip             :    1;       /* [2] */
  
  /**
   * 1: clear the FIFO RADR_NEW
   */
  unsigned short radr_new_clr                  :    1;       /* [3] */
  
  unsigned short reserved                      :   12;
} usi_dma_cmd_bf;

/**
 * \brief Conversion type between word and bit representation of USI DMA command
 *
 * \ingroup usi
 */
typedef union {
  unsigned short val; ///< word representation
  usi_dma_cmd_bf bf;  ///< bit field representation
} usi_dma_cmd_t;


/* USI_CFG_SYNC */

#define MSK_USI_CFG_SYNC_EN                                 (0x1)     /* [0] */
#define RES_USI_CFG_SYNC_EN                                 (0x0)
#define SFT_USI_CFG_SYNC_EN                                 (0)
#define LSB_USI_CFG_SYNC_EN                                 (0)
#define MSB_USI_CFG_SYNC_EN                                 (0)
#define BIT_USI_CFG_SYNC_EN                                 (0x1)     /* [0] */
#define MSK_USI_CFG_SYNC_DELAY                              (0xff)    /* [ 8:1] */
#define RES_USI_CFG_SYNC_DELAY                              (0x2A)
#define SFT_USI_CFG_SYNC_DELAY                              (1)
#define LSB_USI_CFG_SYNC_DELAY                              (1)
#define MSB_USI_CFG_SYNC_DELAY                              (8)

/** 
 * \brief This structure describes USI synchronization system configuration
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * 1: Uart transmit and SPI master frame wait for sync strobe to start
   */
  unsigned short en                            :    1;       /* [0] */
  
  /**
   * number of clock cycles after sync pulse occurred to start
   * of transmission. This gives the DMA machines time to
   * fetch the DMA structures. ( recommended > 23  )
   */
  unsigned short delay                         :    8;       /* [ 8:1] */
  unsigned short reserved                      :    7;
} usi_cfg_sync_bf;

/**
 * \brief Conversion type between word and bit representation of USI synchronization system configuration
 *
 * \ingroup usi
 */
typedef union {
  unsigned short val; ///< word representation
  usi_cfg_sync_bf bf; ///< bit field representation
} usi_cfg_sync_t;


/* USI_TADR_NEW_WS */

#define MSK_USI_TADR_NEW_WS                                 (0xffff)  /* [15:0] */

typedef unsigned short usi_tadr_new_ws_t;                             /* [15:0] */


/* USI_TADR_NEW */

#define MSK_USI_TADR_NEW                                    (0xffff)  /* [15:0] */

typedef unsigned short usi_tadr_new_t;                                /* [15:0] */


/* USI_TADR_CURRENT */

#define MSK_USI_TADR_CURRENT                                (0xffff)  /* [15:0] */

typedef unsigned short usi_tadr_current_t;                            /* [15:0] */


/* USI_TDLEN */

#define MSK_USI_TDLEN                                       (0x3fff)  /* [13:0] */

typedef unsigned short usi_tdlen_t;                                   /* [13:0] */


/* USI_TADR_DONE */

#define MSK_USI_TADR_DONE                                   (0xffff)  /* [15:0] */

typedef unsigned short usi_tadr_done_t;                               /* [15:0] */


/* USI_RADR_NEW_WS */

#define MSK_USI_RADR_NEW_WS                                 (0xffff)  /* [15:0] */

typedef unsigned short usi_radr_new_ws_t;                             /* [15:0] */


/* USI_RADR_NEW */

#define MSK_USI_RADR_NEW                                    (0xffff)  /* [15:0] */

typedef unsigned short usi_radr_new_t;                                /* [15:0] */


/* USI_RADR_CURRENT */

#define MSK_USI_RADR_CURRENT                                (0xffff)  /* [15:0] */

typedef unsigned short usi_radr_current_t;                            /* [15:0] */


/* USI_RDLEN */

#define MSK_USI_RDLEN                                       (0x3fff)  /* [13:0] */

typedef unsigned short usi_rdlen_t;                                   /* [13:0] */


/* USI_RADR_DONE */

#define MSK_USI_RADR_DONE                                   (0xffff)  /* [15:0] */

typedef unsigned short usi_radr_done_t;                               /* [15:0] */


/* USI_IRQ_STATUS */

#define MSK_USI_IRQ_STATUS_REVENTS                          (0x1f)    /* [ 4:0] */
#define RES_USI_IRQ_STATUS_REVENTS                          (0x00)
#define SFT_USI_IRQ_STATUS_REVENTS                          (0)
#define LSB_USI_IRQ_STATUS_REVENTS                          (0)
#define MSB_USI_IRQ_STATUS_REVENTS                          (4)
#define MSK_USI_IRQ_STATUS_RADR_NEW_UDR                     (0x1)     /* [5] */
#define RES_USI_IRQ_STATUS_RADR_NEW_UDR                     (0x0)
#define SFT_USI_IRQ_STATUS_RADR_NEW_UDR                     (5)
#define LSB_USI_IRQ_STATUS_RADR_NEW_UDR                     (5)
#define MSB_USI_IRQ_STATUS_RADR_NEW_UDR                     (5)
#define BIT_USI_IRQ_STATUS_RADR_NEW_UDR                     (0x20)    /* [5] */
#define MSK_USI_IRQ_STATUS_BRE_UPDATED                      (0x1)     /* [6] */
#define RES_USI_IRQ_STATUS_BRE_UPDATED                      (0x0)
#define SFT_USI_IRQ_STATUS_BRE_UPDATED                      (6)
#define LSB_USI_IRQ_STATUS_BRE_UPDATED                      (6)
#define MSB_USI_IRQ_STATUS_BRE_UPDATED                      (6)
#define BIT_USI_IRQ_STATUS_BRE_UPDATED                      (0x40)    /* [6] */
#define MSK_USI_IRQ_STATUS_EVT_SDI                          (0x1)     /* [7] */
#define RES_USI_IRQ_STATUS_EVT_SDI                          (0x0)
#define SFT_USI_IRQ_STATUS_EVT_SDI                          (7)
#define LSB_USI_IRQ_STATUS_EVT_SDI                          (7)
#define MSB_USI_IRQ_STATUS_EVT_SDI                          (7)
#define BIT_USI_IRQ_STATUS_EVT_SDI                          (0x80)    /* [7] */
#define MSK_USI_IRQ_STATUS_TADR_NEW_NFULL                   (0x1)     /* [8] */
#define RES_USI_IRQ_STATUS_TADR_NEW_NFULL                   (0x0)
#define SFT_USI_IRQ_STATUS_TADR_NEW_NFULL                   (8)
#define LSB_USI_IRQ_STATUS_TADR_NEW_NFULL                   (8)
#define MSB_USI_IRQ_STATUS_TADR_NEW_NFULL                   (8)
#define BIT_USI_IRQ_STATUS_TADR_NEW_NFULL                   (0x100)   /* [8] */
#define MSK_USI_IRQ_STATUS_TADR_DONE_NEMPTY                 (0x1)     /* [9] */
#define RES_USI_IRQ_STATUS_TADR_DONE_NEMPTY                 (0x0)
#define SFT_USI_IRQ_STATUS_TADR_DONE_NEMPTY                 (9)
#define LSB_USI_IRQ_STATUS_TADR_DONE_NEMPTY                 (9)
#define MSB_USI_IRQ_STATUS_TADR_DONE_NEMPTY                 (9)
#define BIT_USI_IRQ_STATUS_TADR_DONE_NEMPTY                 (0x200)   /* [9] */
#define MSK_USI_IRQ_STATUS_RADR_NEW_NFULL                   (0x1)     /* [10] */
#define RES_USI_IRQ_STATUS_RADR_NEW_NFULL                   (0x0)
#define SFT_USI_IRQ_STATUS_RADR_NEW_NFULL                   (10)
#define LSB_USI_IRQ_STATUS_RADR_NEW_NFULL                   (10)
#define MSB_USI_IRQ_STATUS_RADR_NEW_NFULL                   (10)
#define BIT_USI_IRQ_STATUS_RADR_NEW_NFULL                   (0x400)   /* [10] */
#define MSK_USI_IRQ_STATUS_RADR_DONE_NEMPTY                 (0x1)     /* [11] */
#define RES_USI_IRQ_STATUS_RADR_DONE_NEMPTY                 (0x0)
#define SFT_USI_IRQ_STATUS_RADR_DONE_NEMPTY                 (11)
#define LSB_USI_IRQ_STATUS_RADR_DONE_NEMPTY                 (11)
#define MSB_USI_IRQ_STATUS_RADR_DONE_NEMPTY                 (11)
#define BIT_USI_IRQ_STATUS_RADR_DONE_NEMPTY                 (0x800)   /* [11] */
#define MSK_USI_IRQ_STATUS_TRANSMITTING                     (0x1)     /* [12] */
#define RES_USI_IRQ_STATUS_TRANSMITTING                     (0x0)
#define SFT_USI_IRQ_STATUS_TRANSMITTING                     (12)
#define LSB_USI_IRQ_STATUS_TRANSMITTING                     (12)
#define MSB_USI_IRQ_STATUS_TRANSMITTING                     (12)
#define BIT_USI_IRQ_STATUS_TRANSMITTING                     (0x1000)  /* [12] */
#define MSK_USI_IRQ_STATUS_RECEIVING                        (0x1)     /* [13] */
#define RES_USI_IRQ_STATUS_RECEIVING                        (0x0)
#define SFT_USI_IRQ_STATUS_RECEIVING                        (13)
#define LSB_USI_IRQ_STATUS_RECEIVING                        (13)
#define MSB_USI_IRQ_STATUS_RECEIVING                        (13)
#define BIT_USI_IRQ_STATUS_RECEIVING                        (0x2000)  /* [13] */

/**
 * \brief This structure describes USI IRQ status register 
 *
 * \ingroup usi
 *
 */
typedef struct {
  /**
   * see RADR field of receive DMA structure <br>
   * receive events - usi_dma_rxcfg_t::revents <br>
   * interrupt type: event
   */
  unsigned short revents                       :    5;       /* [ 4:0] */
  
  /**
   * receive data has been lost as no data structure is available <br>
   * interrupt type: event
   */
  unsigned short radr_new_udr                  :    1;       /* [5] */
  
  /**
   * bit rate extraction result register has been updated<br>
   * interrupt type: event
   */
  unsigned short bre_updated                   :    1;       /* [6] */
  
  /**
   * SDI had CFG.sdi_irq_pol polarity while nss was not asserted<br>
   * interrupt type: event
   */
  unsigned short evt_sdi                       :    1;       /* [7] */
  
  /**
   * 1: TADR_NEW can accept a new pointer.<br>
   * interrupt type: status
   */
  unsigned short tadr_new_nfull                :    1;       /* [8] */
  
  /**
   * 1: TADR_DONE contains a newly completed pointer.<br>
   * interrupt type: status
   */
  unsigned short tadr_done_nempty              :    1;       /* [9] */
  
  /**
   * 1: RADR_NEW can accept a new pointer.<br>
   * interrupt type: status
   */
  unsigned short radr_new_nfull                :    1;       /* [10] */
  
  /**
   * 1: RADR_DONE contains a newly completed pointer.<br>
   * interrupt type: status
   */
  unsigned short radr_done_nempty              :    1;       /* [11] */
  
  /**
   * transmit transfer in progress<br>
   * interrupt type: status
   */
  unsigned short transmitting                  :    1;       /* [12] */
  
  /**
   * receive transfer in progress<br>
   * interrupt type: status
   */
  unsigned short receiving                     :    1;       /* [13] */
  unsigned short reserved                      :    2;
} usi_irq_status_bf;

typedef union {
  unsigned short val;
  usi_irq_status_bf bf;
} usi_irq_status_t;


/* USI_IRQ_MASK */

#define MSK_USI_IRQ_MASK                                    (0x3fff)  /* [13:0] */

typedef unsigned short usi_irq_mask_t;                                /* [13:0] */


/* USI_IRQ_VENABLE */

#define MSK_USI_IRQ_VENABLE                                 (0xf)     /* [ 3:0] */

typedef unsigned short usi_irq_venable_t;                             /* [ 3:0] */


/* USI_IRQ_VDISABLE */

#define MSK_USI_IRQ_VDISABLE                                (0xf)     /* [ 3:0] */

typedef unsigned short usi_irq_vdisable_t;                            /* [ 3:0] */


/* USI_IRQ_VMAX */

#define MSK_USI_IRQ_VMAX                                    (0xf)     /* [ 3:0] */

typedef unsigned short usi_irq_vmax_t;                                /* [ 3:0] */


/* USI_IRQ_VNO */

#define MSK_USI_IRQ_VNO                                     (0xf)     /* [ 3:0] */

typedef unsigned short usi_irq_vno_t;                                 /* [ 3:0] */


/* USI_CFG_RX_TIMEOUT_LW */

#define MSK_USI_CFG_RX_TIMEOUT_LW                           (0xffff)  /* [15:0] */

typedef unsigned short usi_cfg_rx_timeout_lw_t;                       /* [15:0] */


/* USI_CFG_RX_TIMEOUT_HW */

#define MSK_USI_CFG_RX_TIMEOUT_HW                           (0xffff)  /* [15:0] */

typedef unsigned short usi_cfg_rx_timeout_hw_t;                       /* [15:0] */



// Register definitions for module
// Instance base address BASE_ADDR_USI0 0x40007000U ... 
// Instance base address BASE_ADDR_USI1 0x40007080U ... 

#define ADDR_USI_CFG                                         (0x00U)
#define A_USI_CFG(ba)                                        ((ba) + ADDR_USI_CFG)
#define R_USI_CFG(ba)                                        (*(volatile unsigned short *)((unsigned int)A_USI_CFG(ba)))
#define RES_USI_CFG                                          (0x0U)
#define MSB_USI_CFG                                          11
#define LSB_USI_CFG                                          0
#define AADDR_USI0_CFG                                       (BASE_ADDR_USI0 + ADDR_USI_CFG)
#define AADDR_USI1_CFG                                       (BASE_ADDR_USI1 + ADDR_USI_CFG)
#define REG_USI0_CFG                                         (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG))
#define REG_USI1_CFG                                         (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG))

#define ADDR_USI_CFG_BRE                                     (0x02U)
#define A_USI_CFG_BRE(ba)                                    ((ba) + ADDR_USI_CFG_BRE)
#define R_USI_CFG_BRE(ba)                                    (*(volatile unsigned short *)((unsigned int)A_USI_CFG_BRE(ba)))
#define RES_USI_CFG_BRE                                      (0x0U)
#define MSB_USI_CFG_BRE                                      2
#define LSB_USI_CFG_BRE                                      0
#define AADDR_USI0_CFG_BRE                                   (BASE_ADDR_USI0 + ADDR_USI_CFG_BRE)
#define AADDR_USI1_CFG_BRE                                   (BASE_ADDR_USI1 + ADDR_USI_CFG_BRE)
#define REG_USI0_CFG_BRE                                     (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_BRE))
#define REG_USI1_CFG_BRE                                     (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_BRE))

#define ADDR_USI_BRE_RES_LW                                  (0x04U)
#define A_USI_BRE_RES_LW(ba)                                 ((ba) + ADDR_USI_BRE_RES_LW)
#define R_USI_BRE_RES_LW(ba)                                 (*(volatile unsigned short *)((unsigned int)A_USI_BRE_RES_LW(ba)))
#define RES_USI_BRE_RES_LW                                   (0x0U)
#define MSB_USI_BRE_RES_LW                                   15
#define LSB_USI_BRE_RES_LW                                   0
#define AADDR_USI0_BRE_RES_LW                                (BASE_ADDR_USI0 + ADDR_USI_BRE_RES_LW)
#define AADDR_USI1_BRE_RES_LW                                (BASE_ADDR_USI1 + ADDR_USI_BRE_RES_LW)
#define REG_USI0_BRE_RES_LW                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI0_BRE_RES_LW))
#define REG_USI1_BRE_RES_LW                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI1_BRE_RES_LW))

#define ADDR_USI_BRE_RES_HW                                  (0x06U)
#define A_USI_BRE_RES_HW(ba)                                 ((ba) + ADDR_USI_BRE_RES_HW)
#define R_USI_BRE_RES_HW(ba)                                 (*(volatile unsigned short *)((unsigned int)A_USI_BRE_RES_HW(ba)))
#define RES_USI_BRE_RES_HW                                   (0x0U)
#define MSB_USI_BRE_RES_HW                                   15
#define LSB_USI_BRE_RES_HW                                   0
#define AADDR_USI0_BRE_RES_HW                                (BASE_ADDR_USI0 + ADDR_USI_BRE_RES_HW)
#define AADDR_USI1_BRE_RES_HW                                (BASE_ADDR_USI1 + ADDR_USI_BRE_RES_HW)
#define REG_USI0_BRE_RES_HW                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI0_BRE_RES_HW))
#define REG_USI1_BRE_RES_HW                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI1_BRE_RES_HW))

#define ADDR_USI_BR_INC                                      (0x08U)
#define A_USI_BR_INC(ba)                                     ((ba) + ADDR_USI_BR_INC)
#define R_USI_BR_INC(ba)                                     (*(volatile unsigned short *)((unsigned int)A_USI_BR_INC(ba)))
#define RES_USI_BR_INC                                       (0x0U)
#define MSB_USI_BR_INC                                       15
#define LSB_USI_BR_INC                                       0
#define AADDR_USI0_BR_INC                                    (BASE_ADDR_USI0 + ADDR_USI_BR_INC)
#define AADDR_USI1_BR_INC                                    (BASE_ADDR_USI1 + ADDR_USI_BR_INC)
#define REG_USI0_BR_INC                                      (*(volatile unsigned short *)((unsigned int)AADDR_USI0_BR_INC))
#define REG_USI1_BR_INC                                      (*(volatile unsigned short *)((unsigned int)AADDR_USI1_BR_INC))

#define ADDR_USI_BR_MOD                                      (0x0AU)
#define A_USI_BR_MOD(ba)                                     ((ba) + ADDR_USI_BR_MOD)
#define R_USI_BR_MOD(ba)                                     (*(volatile unsigned short *)((unsigned int)A_USI_BR_MOD(ba)))
#define RES_USI_BR_MOD                                       (0x0U)
#define MSB_USI_BR_MOD                                       15
#define LSB_USI_BR_MOD                                       0
#define AADDR_USI0_BR_MOD                                    (BASE_ADDR_USI0 + ADDR_USI_BR_MOD)
#define AADDR_USI1_BR_MOD                                    (BASE_ADDR_USI1 + ADDR_USI_BR_MOD)
#define REG_USI0_BR_MOD                                      (*(volatile unsigned short *)((unsigned int)AADDR_USI0_BR_MOD))
#define REG_USI1_BR_MOD                                      (*(volatile unsigned short *)((unsigned int)AADDR_USI1_BR_MOD))

#define ADDR_USI_TICK                                        (0x0CU)
#define A_USI_TICK(ba)                                       ((ba) + ADDR_USI_TICK)
#define R_USI_TICK(ba)                                       (*(volatile unsigned short *)((unsigned int)A_USI_TICK(ba)))
#define RES_USI_TICK                                         (0x0U)
#define MSB_USI_TICK                                         8
#define LSB_USI_TICK                                         0
#define AADDR_USI0_TICK                                      (BASE_ADDR_USI0 + ADDR_USI_TICK)
#define AADDR_USI1_TICK                                      (BASE_ADDR_USI1 + ADDR_USI_TICK)
#define REG_USI0_TICK                                        (*(volatile unsigned short *)((unsigned int)AADDR_USI0_TICK))
#define REG_USI1_TICK                                        (*(volatile unsigned short *)((unsigned int)AADDR_USI1_TICK))

#define ADDR_USI_CFG_INTF                                    (0x0EU)
#define A_USI_CFG_INTF(ba)                                   ((ba) + ADDR_USI_CFG_INTF)
#define R_USI_CFG_INTF(ba)                                   (*(volatile unsigned short *)((unsigned int)A_USI_CFG_INTF(ba)))
#define RES_USI_CFG_INTF                                     (0x0U)
#define MSB_USI_CFG_INTF                                     15
#define LSB_USI_CFG_INTF                                     0
#define AADDR_USI0_CFG_INTF                                  (BASE_ADDR_USI0 + ADDR_USI_CFG_INTF)
#define AADDR_USI1_CFG_INTF                                  (BASE_ADDR_USI1 + ADDR_USI_CFG_INTF)
#define REG_USI0_CFG_INTF                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_INTF))
#define REG_USI1_CFG_INTF                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_INTF))

#define ADDR_USI_CFG_U_BL                                    (0x10U)
#define A_USI_CFG_U_BL(ba)                                   ((ba) + ADDR_USI_CFG_U_BL)
#define R_USI_CFG_U_BL(ba)                                   (*(volatile unsigned short *)((unsigned int)A_USI_CFG_U_BL(ba)))
#define RES_USI_CFG_U_BL                                     (0x0U)
#define MSB_USI_CFG_U_BL                                     11
#define LSB_USI_CFG_U_BL                                     0
#define AADDR_USI0_CFG_U_BL                                  (BASE_ADDR_USI0 + ADDR_USI_CFG_U_BL)
#define AADDR_USI1_CFG_U_BL                                  (BASE_ADDR_USI1 + ADDR_USI_CFG_U_BL)
#define REG_USI0_CFG_U_BL                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_U_BL))
#define REG_USI1_CFG_U_BL                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_U_BL))

#define ADDR_USI_CFG_U_TICK                                  (0x12U)
#define A_USI_CFG_U_TICK(ba)                                 ((ba) + ADDR_USI_CFG_U_TICK)
#define R_USI_CFG_U_TICK(ba)                                 (*(volatile unsigned short *)((unsigned int)A_USI_CFG_U_TICK(ba)))
#define RES_USI_CFG_U_TICK                                   (0x0U)
#define MSB_USI_CFG_U_TICK                                   15
#define LSB_USI_CFG_U_TICK                                   0
#define AADDR_USI0_CFG_U_TICK                                (BASE_ADDR_USI0 + ADDR_USI_CFG_U_TICK)
#define AADDR_USI1_CFG_U_TICK                                (BASE_ADDR_USI1 + ADDR_USI_CFG_U_TICK)
#define REG_USI0_CFG_U_TICK                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_U_TICK))
#define REG_USI1_CFG_U_TICK                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_U_TICK))

#define ADDR_USI_CFG_U_START_THRESHOLD                       (0x16U)
#define A_USI_CFG_U_START_THRESHOLD(ba)                      ((ba) + ADDR_USI_CFG_U_START_THRESHOLD)
#define R_USI_CFG_U_START_THRESHOLD(ba)                      (*(volatile unsigned short *)((unsigned int)A_USI_CFG_U_START_THRESHOLD(ba)))
#define RES_USI_CFG_U_START_THRESHOLD                        (0x1U)
#define MSB_USI_CFG_U_START_THRESHOLD                        15
#define LSB_USI_CFG_U_START_THRESHOLD                        0
#define AADDR_USI0_CFG_U_START_THRESHOLD                     (BASE_ADDR_USI0 + ADDR_USI_CFG_U_START_THRESHOLD)
#define AADDR_USI1_CFG_U_START_THRESHOLD                     (BASE_ADDR_USI1 + ADDR_USI_CFG_U_START_THRESHOLD)
#define REG_USI0_CFG_U_START_THRESHOLD                       (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_U_START_THRESHOLD))
#define REG_USI1_CFG_U_START_THRESHOLD                       (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_U_START_THRESHOLD))

#define ADDR_USI_CFG_U_HALF_DUPLEX                           (0x18U)
#define A_USI_CFG_U_HALF_DUPLEX(ba)                          ((ba) + ADDR_USI_CFG_U_HALF_DUPLEX)
#define R_USI_CFG_U_HALF_DUPLEX(ba)                          (*(volatile unsigned short *)((unsigned int)A_USI_CFG_U_HALF_DUPLEX(ba)))
#define RES_USI_CFG_U_HALF_DUPLEX                            (0x88U)
#define MSB_USI_CFG_U_HALF_DUPLEX                            11
#define LSB_USI_CFG_U_HALF_DUPLEX                            0
#define AADDR_USI0_CFG_U_HALF_DUPLEX                         (BASE_ADDR_USI0 + ADDR_USI_CFG_U_HALF_DUPLEX)
#define AADDR_USI1_CFG_U_HALF_DUPLEX                         (BASE_ADDR_USI1 + ADDR_USI_CFG_U_HALF_DUPLEX)
#define REG_USI0_CFG_U_HALF_DUPLEX                           (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_U_HALF_DUPLEX))
#define REG_USI1_CFG_U_HALF_DUPLEX                           (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_U_HALF_DUPLEX))

#define ADDR_USI_CFG_SPI_BL                                  (0x1AU)
#define A_USI_CFG_SPI_BL(ba)                                 ((ba) + ADDR_USI_CFG_SPI_BL)
#define R_USI_CFG_SPI_BL(ba)                                 (*(volatile unsigned short *)((unsigned int)A_USI_CFG_SPI_BL(ba)))
#define RES_USI_CFG_SPI_BL                                   (0x40U)
#define MSB_USI_CFG_SPI_BL                                   11
#define LSB_USI_CFG_SPI_BL                                   0
#define AADDR_USI0_CFG_SPI_BL                                (BASE_ADDR_USI0 + ADDR_USI_CFG_SPI_BL)
#define AADDR_USI1_CFG_SPI_BL                                (BASE_ADDR_USI1 + ADDR_USI_CFG_SPI_BL)
#define REG_USI0_CFG_SPI_BL                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_SPI_BL))
#define REG_USI1_CFG_SPI_BL                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_SPI_BL))

#define ADDR_USI_CFG_SPI_EARLY_SDO                           (0x1CU)
#define A_USI_CFG_SPI_EARLY_SDO(ba)                          ((ba) + ADDR_USI_CFG_SPI_EARLY_SDO)
#define R_USI_CFG_SPI_EARLY_SDO(ba)                          (*(volatile unsigned short *)((unsigned int)A_USI_CFG_SPI_EARLY_SDO(ba)))
#define RES_USI_CFG_SPI_EARLY_SDO                            (0x0U)
#define MSB_USI_CFG_SPI_EARLY_SDO                            3
#define LSB_USI_CFG_SPI_EARLY_SDO                            0
#define AADDR_USI0_CFG_SPI_EARLY_SDO                         (BASE_ADDR_USI0 + ADDR_USI_CFG_SPI_EARLY_SDO)
#define AADDR_USI1_CFG_SPI_EARLY_SDO                         (BASE_ADDR_USI1 + ADDR_USI_CFG_SPI_EARLY_SDO)
#define REG_USI0_CFG_SPI_EARLY_SDO                           (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_SPI_EARLY_SDO))
#define REG_USI1_CFG_SPI_EARLY_SDO                           (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_SPI_EARLY_SDO))

#define ADDR_USI_CFG_SPI_SCK_TIMEOUT                         (0x1EU)
#define A_USI_CFG_SPI_SCK_TIMEOUT(ba)                        ((ba) + ADDR_USI_CFG_SPI_SCK_TIMEOUT)
#define R_USI_CFG_SPI_SCK_TIMEOUT(ba)                        (*(volatile unsigned short *)((unsigned int)A_USI_CFG_SPI_SCK_TIMEOUT(ba)))
#define RES_USI_CFG_SPI_SCK_TIMEOUT                          (0x3U)
#define MSB_USI_CFG_SPI_SCK_TIMEOUT                          8
#define LSB_USI_CFG_SPI_SCK_TIMEOUT                          0
#define AADDR_USI0_CFG_SPI_SCK_TIMEOUT                       (BASE_ADDR_USI0 + ADDR_USI_CFG_SPI_SCK_TIMEOUT)
#define AADDR_USI1_CFG_SPI_SCK_TIMEOUT                       (BASE_ADDR_USI1 + ADDR_USI_CFG_SPI_SCK_TIMEOUT)
#define REG_USI0_CFG_SPI_SCK_TIMEOUT                         (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_SPI_SCK_TIMEOUT))
#define REG_USI1_CFG_SPI_SCK_TIMEOUT                         (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_SPI_SCK_TIMEOUT))

#define ADDR_USI_DMA_CMD                                     (0x20U)
#define A_USI_DMA_CMD(ba)                                    ((ba) + ADDR_USI_DMA_CMD)
#define R_USI_DMA_CMD(ba)                                    (*(volatile unsigned short *)((unsigned int)A_USI_DMA_CMD(ba)))
#define RES_USI_DMA_CMD                                      (0x0U)
#define MSB_USI_DMA_CMD                                      3
#define LSB_USI_DMA_CMD                                      0
#define AADDR_USI0_DMA_CMD                                   (BASE_ADDR_USI0 + ADDR_USI_DMA_CMD)
#define AADDR_USI1_DMA_CMD                                   (BASE_ADDR_USI1 + ADDR_USI_DMA_CMD)
#define REG_USI0_DMA_CMD                                     (*(volatile unsigned short *)((unsigned int)AADDR_USI0_DMA_CMD))
#define REG_USI1_DMA_CMD                                     (*(volatile unsigned short *)((unsigned int)AADDR_USI1_DMA_CMD))

#define ADDR_USI_CFG_SYNC                                    (0x24U)
#define A_USI_CFG_SYNC(ba)                                   ((ba) + ADDR_USI_CFG_SYNC)
#define R_USI_CFG_SYNC(ba)                                   (*(volatile unsigned short *)((unsigned int)A_USI_CFG_SYNC(ba)))
#define RES_USI_CFG_SYNC                                     (0x54U)
#define MSB_USI_CFG_SYNC                                     8
#define LSB_USI_CFG_SYNC                                     0
#define AADDR_USI0_CFG_SYNC                                  (BASE_ADDR_USI0 + ADDR_USI_CFG_SYNC)
#define AADDR_USI1_CFG_SYNC                                  (BASE_ADDR_USI1 + ADDR_USI_CFG_SYNC)
#define REG_USI0_CFG_SYNC                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_SYNC))
#define REG_USI1_CFG_SYNC                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_SYNC))

#define ADDR_USI_TADR_NEW_WS                                 (0x26U)
#define A_USI_TADR_NEW_WS(ba)                                ((ba) + ADDR_USI_TADR_NEW_WS)
#define R_USI_TADR_NEW_WS(ba)                                (*(volatile unsigned short *)((unsigned int)A_USI_TADR_NEW_WS(ba)))
#define RES_USI_TADR_NEW_WS                                  (0x0U)
#define MSB_USI_TADR_NEW_WS                                  15
#define LSB_USI_TADR_NEW_WS                                  0
#define AADDR_USI0_TADR_NEW_WS                               (BASE_ADDR_USI0 + ADDR_USI_TADR_NEW_WS)
#define AADDR_USI1_TADR_NEW_WS                               (BASE_ADDR_USI1 + ADDR_USI_TADR_NEW_WS)
#define REG_USI0_TADR_NEW_WS                                 (*(volatile unsigned short *)((unsigned int)AADDR_USI0_TADR_NEW_WS))
#define REG_USI1_TADR_NEW_WS                                 (*(volatile unsigned short *)((unsigned int)AADDR_USI1_TADR_NEW_WS))

#define ADDR_USI_TADR_NEW                                    (0x28U)
#define A_USI_TADR_NEW(ba)                                   ((ba) + ADDR_USI_TADR_NEW)
#define R_USI_TADR_NEW(ba)                                   (*(volatile unsigned short *)((unsigned int)A_USI_TADR_NEW(ba)))
#define RES_USI_TADR_NEW                                     (0x0U)
#define MSB_USI_TADR_NEW                                     15
#define LSB_USI_TADR_NEW                                     0
#define AADDR_USI0_TADR_NEW                                  (BASE_ADDR_USI0 + ADDR_USI_TADR_NEW)
#define AADDR_USI1_TADR_NEW                                  (BASE_ADDR_USI1 + ADDR_USI_TADR_NEW)
#define REG_USI0_TADR_NEW                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI0_TADR_NEW))
#define REG_USI1_TADR_NEW                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI1_TADR_NEW))

#define ADDR_USI_TADR_CURRENT                                (0x2AU)
#define A_USI_TADR_CURRENT(ba)                               ((ba) + ADDR_USI_TADR_CURRENT)
#define R_USI_TADR_CURRENT(ba)                               (*(volatile unsigned short *)((unsigned int)A_USI_TADR_CURRENT(ba)))
#define RES_USI_TADR_CURRENT                                 (0x0U)
#define MSB_USI_TADR_CURRENT                                 15
#define LSB_USI_TADR_CURRENT                                 0
#define AADDR_USI0_TADR_CURRENT                              (BASE_ADDR_USI0 + ADDR_USI_TADR_CURRENT)
#define AADDR_USI1_TADR_CURRENT                              (BASE_ADDR_USI1 + ADDR_USI_TADR_CURRENT)
#define REG_USI0_TADR_CURRENT                                (*(volatile unsigned short *)((unsigned int)AADDR_USI0_TADR_CURRENT))
#define REG_USI1_TADR_CURRENT                                (*(volatile unsigned short *)((unsigned int)AADDR_USI1_TADR_CURRENT))

#define ADDR_USI_TDLEN                                       (0x2CU)
#define A_USI_TDLEN(ba)                                      ((ba) + ADDR_USI_TDLEN)
#define R_USI_TDLEN(ba)                                      (*(volatile unsigned short *)((unsigned int)A_USI_TDLEN(ba)))
#define RES_USI_TDLEN                                        (0x0U)
#define MSB_USI_TDLEN                                        13
#define LSB_USI_TDLEN                                        0
#define AADDR_USI0_TDLEN                                     (BASE_ADDR_USI0 + ADDR_USI_TDLEN)
#define AADDR_USI1_TDLEN                                     (BASE_ADDR_USI1 + ADDR_USI_TDLEN)
#define REG_USI0_TDLEN                                       (*(volatile unsigned short *)((unsigned int)AADDR_USI0_TDLEN))
#define REG_USI1_TDLEN                                       (*(volatile unsigned short *)((unsigned int)AADDR_USI1_TDLEN))

#define ADDR_USI_TADR_DONE                                   (0x2EU)
#define A_USI_TADR_DONE(ba)                                  ((ba) + ADDR_USI_TADR_DONE)
#define R_USI_TADR_DONE(ba)                                  (*(volatile unsigned short *)((unsigned int)A_USI_TADR_DONE(ba)))
#define RES_USI_TADR_DONE                                    (0x0U)
#define MSB_USI_TADR_DONE                                    15
#define LSB_USI_TADR_DONE                                    0
#define AADDR_USI0_TADR_DONE                                 (BASE_ADDR_USI0 + ADDR_USI_TADR_DONE)
#define AADDR_USI1_TADR_DONE                                 (BASE_ADDR_USI1 + ADDR_USI_TADR_DONE)
#define REG_USI0_TADR_DONE                                   (*(volatile unsigned short *)((unsigned int)AADDR_USI0_TADR_DONE))
#define REG_USI1_TADR_DONE                                   (*(volatile unsigned short *)((unsigned int)AADDR_USI1_TADR_DONE))

#define ADDR_USI_RADR_NEW_WS                                 (0x30U)
#define A_USI_RADR_NEW_WS(ba)                                ((ba) + ADDR_USI_RADR_NEW_WS)
#define R_USI_RADR_NEW_WS(ba)                                (*(volatile unsigned short *)((unsigned int)A_USI_RADR_NEW_WS(ba)))
#define RES_USI_RADR_NEW_WS                                  (0x0U)
#define MSB_USI_RADR_NEW_WS                                  15
#define LSB_USI_RADR_NEW_WS                                  0
#define AADDR_USI0_RADR_NEW_WS                               (BASE_ADDR_USI0 + ADDR_USI_RADR_NEW_WS)
#define AADDR_USI1_RADR_NEW_WS                               (BASE_ADDR_USI1 + ADDR_USI_RADR_NEW_WS)
#define REG_USI0_RADR_NEW_WS                                 (*(volatile unsigned short *)((unsigned int)AADDR_USI0_RADR_NEW_WS))
#define REG_USI1_RADR_NEW_WS                                 (*(volatile unsigned short *)((unsigned int)AADDR_USI1_RADR_NEW_WS))

#define ADDR_USI_RADR_NEW                                    (0x32U)
#define A_USI_RADR_NEW(ba)                                   ((ba) + ADDR_USI_RADR_NEW)
#define R_USI_RADR_NEW(ba)                                   (*(volatile unsigned short *)((unsigned int)A_USI_RADR_NEW(ba)))
#define RES_USI_RADR_NEW                                     (0x0U)
#define MSB_USI_RADR_NEW                                     15
#define LSB_USI_RADR_NEW                                     0
#define AADDR_USI0_RADR_NEW                                  (BASE_ADDR_USI0 + ADDR_USI_RADR_NEW)
#define AADDR_USI1_RADR_NEW                                  (BASE_ADDR_USI1 + ADDR_USI_RADR_NEW)
#define REG_USI0_RADR_NEW                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI0_RADR_NEW))
#define REG_USI1_RADR_NEW                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI1_RADR_NEW))

#define ADDR_USI_RADR_CURRENT                                (0x34U)
#define A_USI_RADR_CURRENT(ba)                               ((ba) + ADDR_USI_RADR_CURRENT)
#define R_USI_RADR_CURRENT(ba)                               (*(volatile unsigned short *)((unsigned int)A_USI_RADR_CURRENT(ba)))
#define RES_USI_RADR_CURRENT                                 (0x0U)
#define MSB_USI_RADR_CURRENT                                 15
#define LSB_USI_RADR_CURRENT                                 0
#define AADDR_USI0_RADR_CURRENT                              (BASE_ADDR_USI0 + ADDR_USI_RADR_CURRENT)
#define AADDR_USI1_RADR_CURRENT                              (BASE_ADDR_USI1 + ADDR_USI_RADR_CURRENT)
#define REG_USI0_RADR_CURRENT                                (*(volatile unsigned short *)((unsigned int)AADDR_USI0_RADR_CURRENT))
#define REG_USI1_RADR_CURRENT                                (*(volatile unsigned short *)((unsigned int)AADDR_USI1_RADR_CURRENT))

#define ADDR_USI_RDLEN                                       (0x36U)
#define A_USI_RDLEN(ba)                                      ((ba) + ADDR_USI_RDLEN)
#define R_USI_RDLEN(ba)                                      (*(volatile unsigned short *)((unsigned int)A_USI_RDLEN(ba)))
#define RES_USI_RDLEN                                        (0x0U)
#define MSB_USI_RDLEN                                        13
#define LSB_USI_RDLEN                                        0
#define AADDR_USI0_RDLEN                                     (BASE_ADDR_USI0 + ADDR_USI_RDLEN)
#define AADDR_USI1_RDLEN                                     (BASE_ADDR_USI1 + ADDR_USI_RDLEN)
#define REG_USI0_RDLEN                                       (*(volatile unsigned short *)((unsigned int)AADDR_USI0_RDLEN))
#define REG_USI1_RDLEN                                       (*(volatile unsigned short *)((unsigned int)AADDR_USI1_RDLEN))

#define ADDR_USI_RADR_DONE                                   (0x38U)
#define A_USI_RADR_DONE(ba)                                  ((ba) + ADDR_USI_RADR_DONE)
#define R_USI_RADR_DONE(ba)                                  (*(volatile unsigned short *)((unsigned int)A_USI_RADR_DONE(ba)))
#define RES_USI_RADR_DONE                                    (0x0U)
#define MSB_USI_RADR_DONE                                    15
#define LSB_USI_RADR_DONE                                    0
#define AADDR_USI0_RADR_DONE                                 (BASE_ADDR_USI0 + ADDR_USI_RADR_DONE)
#define AADDR_USI1_RADR_DONE                                 (BASE_ADDR_USI1 + ADDR_USI_RADR_DONE)
#define REG_USI0_RADR_DONE                                   (*(volatile unsigned short *)((unsigned int)AADDR_USI0_RADR_DONE))
#define REG_USI1_RADR_DONE                                   (*(volatile unsigned short *)((unsigned int)AADDR_USI1_RADR_DONE))

#define ADDR_USI_IRQ_STATUS                                  (0x3AU)
#define A_USI_IRQ_STATUS(ba)                                 ((ba) + ADDR_USI_IRQ_STATUS)
#define R_USI_IRQ_STATUS(ba)                                 (*(volatile unsigned short *)((unsigned int)A_USI_IRQ_STATUS(ba)))
#define RES_USI_IRQ_STATUS                                   (0x0U)
#define MSB_USI_IRQ_STATUS                                   13
#define LSB_USI_IRQ_STATUS                                   0
#define AADDR_USI0_IRQ_STATUS                                (BASE_ADDR_USI0 + ADDR_USI_IRQ_STATUS)
#define AADDR_USI1_IRQ_STATUS                                (BASE_ADDR_USI1 + ADDR_USI_IRQ_STATUS)
#define REG_USI0_IRQ_STATUS                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI0_IRQ_STATUS))
#define REG_USI1_IRQ_STATUS                                  (*(volatile unsigned short *)((unsigned int)AADDR_USI1_IRQ_STATUS))

#define ADDR_USI_IRQ_MASK                                    (0x3EU)
#define A_USI_IRQ_MASK(ba)                                   ((ba) + ADDR_USI_IRQ_MASK)
#define R_USI_IRQ_MASK(ba)                                   (*(volatile unsigned short *)((unsigned int)A_USI_IRQ_MASK(ba)))
#define RES_USI_IRQ_MASK                                     (0x0U)
#define MSB_USI_IRQ_MASK                                     13
#define LSB_USI_IRQ_MASK                                     0
#define AADDR_USI0_IRQ_MASK                                  (BASE_ADDR_USI0 + ADDR_USI_IRQ_MASK)
#define AADDR_USI1_IRQ_MASK                                  (BASE_ADDR_USI1 + ADDR_USI_IRQ_MASK)
#define REG_USI0_IRQ_MASK                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI0_IRQ_MASK))
#define REG_USI1_IRQ_MASK                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI1_IRQ_MASK))

#define ADDR_USI_IRQ_VENABLE                                 (0x42U)
#define A_USI_IRQ_VENABLE(ba)                                ((ba) + ADDR_USI_IRQ_VENABLE)
#define R_USI_IRQ_VENABLE(ba)                                (*(volatile unsigned short *)((unsigned int)A_USI_IRQ_VENABLE(ba)))
#define RES_USI_IRQ_VENABLE                                  (0x0U)
#define MSB_USI_IRQ_VENABLE                                  3
#define LSB_USI_IRQ_VENABLE                                  0
#define AADDR_USI0_IRQ_VENABLE                               (BASE_ADDR_USI0 + ADDR_USI_IRQ_VENABLE)
#define AADDR_USI1_IRQ_VENABLE                               (BASE_ADDR_USI1 + ADDR_USI_IRQ_VENABLE)
#define REG_USI0_IRQ_VENABLE                                 (*(volatile unsigned short *)((unsigned int)AADDR_USI0_IRQ_VENABLE))
#define REG_USI1_IRQ_VENABLE                                 (*(volatile unsigned short *)((unsigned int)AADDR_USI1_IRQ_VENABLE))

#define ADDR_USI_IRQ_VDISABLE                                (0x44U)
#define A_USI_IRQ_VDISABLE(ba)                               ((ba) + ADDR_USI_IRQ_VDISABLE)
#define R_USI_IRQ_VDISABLE(ba)                               (*(volatile unsigned short *)((unsigned int)A_USI_IRQ_VDISABLE(ba)))
#define RES_USI_IRQ_VDISABLE                                 (0x0U)
#define MSB_USI_IRQ_VDISABLE                                 3
#define LSB_USI_IRQ_VDISABLE                                 0
#define AADDR_USI0_IRQ_VDISABLE                              (BASE_ADDR_USI0 + ADDR_USI_IRQ_VDISABLE)
#define AADDR_USI1_IRQ_VDISABLE                              (BASE_ADDR_USI1 + ADDR_USI_IRQ_VDISABLE)
#define REG_USI0_IRQ_VDISABLE                                (*(volatile unsigned short *)((unsigned int)AADDR_USI0_IRQ_VDISABLE))
#define REG_USI1_IRQ_VDISABLE                                (*(volatile unsigned short *)((unsigned int)AADDR_USI1_IRQ_VDISABLE))

#define ADDR_USI_IRQ_VMAX                                    (0x46U)
#define A_USI_IRQ_VMAX(ba)                                   ((ba) + ADDR_USI_IRQ_VMAX)
#define R_USI_IRQ_VMAX(ba)                                   (*(volatile unsigned short *)((unsigned int)A_USI_IRQ_VMAX(ba)))
#define RES_USI_IRQ_VMAX                                     (0xeU)
#define MSB_USI_IRQ_VMAX                                     3
#define LSB_USI_IRQ_VMAX                                     0
#define AADDR_USI0_IRQ_VMAX                                  (BASE_ADDR_USI0 + ADDR_USI_IRQ_VMAX)
#define AADDR_USI1_IRQ_VMAX                                  (BASE_ADDR_USI1 + ADDR_USI_IRQ_VMAX)
#define REG_USI0_IRQ_VMAX                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI0_IRQ_VMAX))
#define REG_USI1_IRQ_VMAX                                    (*(volatile unsigned short *)((unsigned int)AADDR_USI1_IRQ_VMAX))

#define ADDR_USI_IRQ_VNO                                     (0x48U)
#define A_USI_IRQ_VNO(ba)                                    ((ba) + ADDR_USI_IRQ_VNO)
#define R_USI_IRQ_VNO(ba)                                    (*(volatile unsigned short *)((unsigned int)A_USI_IRQ_VNO(ba)))
#define RES_USI_IRQ_VNO                                      (0xeU)
#define MSB_USI_IRQ_VNO                                      3
#define LSB_USI_IRQ_VNO                                      0
#define AADDR_USI0_IRQ_VNO                                   (BASE_ADDR_USI0 + ADDR_USI_IRQ_VNO)
#define AADDR_USI1_IRQ_VNO                                   (BASE_ADDR_USI1 + ADDR_USI_IRQ_VNO)
#define REG_USI0_IRQ_VNO                                     (*(volatile unsigned short *)((unsigned int)AADDR_USI0_IRQ_VNO))
#define REG_USI1_IRQ_VNO                                     (*(volatile unsigned short *)((unsigned int)AADDR_USI1_IRQ_VNO))

#define ADDR_USI_CFG_RX_TIMEOUT_LW                           (0x4CU)
#define A_USI_CFG_RX_TIMEOUT_LW(ba)                          ((ba) + ADDR_USI_CFG_RX_TIMEOUT_LW)
#define R_USI_CFG_RX_TIMEOUT_LW(ba)                          (*(volatile unsigned short *)((unsigned int)A_USI_CFG_RX_TIMEOUT_LW(ba)))
#define RES_USI_CFG_RX_TIMEOUT_LW                            (0xffffU)
#define MSB_USI_CFG_RX_TIMEOUT_LW                            15
#define LSB_USI_CFG_RX_TIMEOUT_LW                            0
#define AADDR_USI0_CFG_RX_TIMEOUT_LW                         (BASE_ADDR_USI0 + ADDR_USI_CFG_RX_TIMEOUT_LW)
#define AADDR_USI1_CFG_RX_TIMEOUT_LW                         (BASE_ADDR_USI1 + ADDR_USI_CFG_RX_TIMEOUT_LW)
#define REG_USI0_CFG_RX_TIMEOUT_LW                           (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_RX_TIMEOUT_LW))
#define REG_USI1_CFG_RX_TIMEOUT_LW                           (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_RX_TIMEOUT_LW))

#define ADDR_USI_CFG_RX_TIMEOUT_HW                           (0x4EU)
#define A_USI_CFG_RX_TIMEOUT_HW(ba)                          ((ba) + ADDR_USI_CFG_RX_TIMEOUT_HW)
#define R_USI_CFG_RX_TIMEOUT_HW(ba)                          (*(volatile unsigned short *)((unsigned int)A_USI_CFG_RX_TIMEOUT_HW(ba)))
#define RES_USI_CFG_RX_TIMEOUT_HW                            (0x0U)
#define MSB_USI_CFG_RX_TIMEOUT_HW                            15
#define LSB_USI_CFG_RX_TIMEOUT_HW                            0
#define AADDR_USI0_CFG_RX_TIMEOUT_HW                         (BASE_ADDR_USI0 + ADDR_USI_CFG_RX_TIMEOUT_HW)
#define AADDR_USI1_CFG_RX_TIMEOUT_HW                         (BASE_ADDR_USI1 + ADDR_USI_CFG_RX_TIMEOUT_HW)
#define REG_USI0_CFG_RX_TIMEOUT_HW                           (*(volatile unsigned short *)((unsigned int)AADDR_USI0_CFG_RX_TIMEOUT_HW))
#define REG_USI1_CFG_RX_TIMEOUT_HW                           (*(volatile unsigned short *)((unsigned int)AADDR_USI1_CFG_RX_TIMEOUT_HW))




#endif
