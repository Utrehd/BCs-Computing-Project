/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hiad.h
*
* @brief        Parallel Host-Interface HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_HIAD_H
#define HAVE_HIAD_H

/**
 * \defgroup hiad ASIC2 Parallel Host-Interface HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control Parallel Host-Interface
 * 
 * Instructions:
 * -# The host interface must be configured first
 * -# Then the IOMUX must be configured
 * -# Afterwards, the host interface must be activated
 */
/**@{*/

#include "hiad_bf.h"


/* ############################################################################ */
/**
 * \brief This is an enum class for HIAD to identify bus width
 *
 * \ingroup hiad 
 */ 
typedef enum {
  /**
   * 16 bit bus width
   */ 
    HIAD_BUS_WIDTH_16           = 0,
  /**
   * 8 bit bus width
   */ 
    HIAD_BUS_WIDTH_8            = 1,
} hiad_bus_width_t;


/* ############################################################################ */
/**
 * \brief Function to set HIAD configuration
 *
 * \ingroup hiad 
 * 
 * \param enable_oe                         0 : the output drivers are never enabled (i.e. reads are executed as normal, but the result is never driven by the pads) <br>
 *                                          1 : the ouput drivers operate normally
 * 
 * \param bus_width                         0: 16 bit bus width <br>
 *                                          1: 8 bit bus width
 * 
 * \param muxed                             1: multiplexed addresses
 * 
 * \param muxed_8_addr                      Valid for 8-Bit MUXED Mode: <br>
 *                                          0: upper Addr. Lines taken from addr_i <br>
 *                                          1: upper Addr. Lines taken from ad_i
 * 
 * \param ncs_active                        Active polarity of ncs.vAn A/D bus cycle takes place when ncs is active.
 * 
 * \param nrd_active                        Active polarity of nrd (-> rising / falling Edge)
 * 
 * \param nwr_active                        Active polarity of nwr (-> rising / falling Edge). <B> Also valid for wrl / wrh </B>
 * 
 * \param nwait_active                      Active polarity of nwait (-> rising / falling Edge)
 * 
 * \param nwait_extend                      0: nwait ends at the same rising edge of the clk at the same edge the data becomes valid. Can only be used if the A/D bus master samples the nwait signal before the data <br>
 *                                          1: nwait ends at a falling edge of the clk, half a clock cycle after the data becomes valid
 * 
 * \param ale_edge                          0: sample multiplexed addresses at rising edge of ale <br>
 *                                          1: sample multiplexed addresses at falling edge of ale
 * 
 * \param write_sample                      0: sample write data at the same time as addresses <br>
 *                                          1: sample write data one clk cycle later than addresses
 */ 
void hiad_config (bool enable_oe,
                  hiad_bus_width_t bus_width, 
                  bool muxed, bool muxed_8_addr,
                  bool ncs_active, bool nrd_active, bool nwr_active, 
                  bool nwait_active, bool nwait_extend,
                  bool ale_edge, bool write_sample);


/* ############################################################################ */
/**
 * \brief Function to set HIAD mask for adr[13]
 *
 * \ingroup hiad 
 * 
 * \param mask                       0: adr[13] is used <br>
 *                                   1: adr[13] is ignored (decreases addressable range)
 */ 
void hiad_set_mask_adr13(bool mask);


/* ############################################################################ */
/**
 * \brief Function to set HIAD mask for adr[14]
 *
 * \ingroup hiad 
 * 
 * \param mask                       0: adr[14] is used <br>
 *                                   1: adr[14] is ignored (decreases addressable range)
 */ 
void hiad_set_mask_adr14(bool mask);

/* ############################################################################ */
/**
 * \brief Function to enable HIAD
 *
 * \ingroup hiad 
 * 
 * \param enable 1: enable bus interface. When not enabled no AHBL access will be performed.
 */ 
void hiad_set_enable(bool enable);


/* ############################################################################ */
/**
 * \brief Function to configure HIAD Access Control
 *
 * \ingroup hiad 
 * 
 * \param addr0_low Lower limit for memory area 0
 * 
 * \param addr0_high Upper limit for memory area 0
 * 
 * \param addr1_low Lower limit for memory area 1
 * 
 * \param addr1_high Upper limit for memory area 1
 * 
 * \note The host can only access two address ranges
 */ 
void hiad_config_access_control (uint16_t addr0_low, uint16_t addr0_high,
                                 uint16_t addr1_low, uint16_t addr1_high);

/**@} */
#endif /* HAVE_HIAD_H */
