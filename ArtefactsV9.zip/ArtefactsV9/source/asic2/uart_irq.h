/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         uart_irq.h
*
* @brief        UART HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __UART_IRQ_H__
#define __UART_IRQ_H__

#define UART_NUM_IRQS 14

/* ############################################################################ */
/**
 * \brief 
 *
 * \ingroup uart 
 */ 
typedef enum{
  /**
   * software did not read incoming data fast enough
   */ 
  UART_IRQ_EVT_RX_FIFO_OV_ERR =         0,
  /**
   * software has read from empty receive fifo
   */ 
  UART_IRQ_EVT_RX_FIFO_UR_ERR =         1,
  /**
   * software wrote data to full transmit fifo
   */ 
  UART_IRQ_EVT_TX_FIFO_OV_ERR =         2,
  /**
   * start bit error
   */ 
  UART_IRQ_EVT_RX_START_ERR =           3,
  /**
   * parity error
   */ 
  UART_IRQ_EVT_RX_PAR_ERR =             4,
  /**
   * stop bit error
   */ 
  UART_IRQ_EVT_RX_STOP_ERR =            5,
  /**
   * receive fifo is not empty
   */ 
  UART_IRQ_RX_FIFO_NEMPTY =             6,
  /**
   * receive fifo timeout
   */ 
  UART_IRQ_RX_FIFO_TIMEOUT =            7,
  /**
   * receive fifo elements > high water level
   */ 
  UART_IRQ_RX_FIFO_HIGH_WATER =         8,
  /**
   * receive fifo is full
   */ 
  UART_IRQ_RX_FIFO_FULL =               9,
  /**
   * transmit fifo is empty
   */ 
  UART_IRQ_TX_FIFO_EMPTY =              10,
  /**
   * transmit fifo elements <= low water level
   */ 
  UART_IRQ_TX_FIFO_LOW_WATER =          11,
  /**
   * transmit fifo is not full
   */ 
  UART_IRQ_TX_FIFO_NFULL =              12,
  /**
   * the UART is transmitting (TX FIFO not empty or currently sending a byte)
   */ 
  UART_IRQ_TX_TRANSMITTING =            13
} uart_irq_t;

#endif
