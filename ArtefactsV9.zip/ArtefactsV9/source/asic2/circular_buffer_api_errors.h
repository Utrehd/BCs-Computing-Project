/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         circular_buffer_api_errors.h
*
* @brief        Error handler for Circular buffer API functions
*
* @author       Dedourek Pavel, Cid Mateo
*
********************************************************************************
*
********************************************************************************
********************************************************************************
*/

/**
 * \ingroup error_api
 */
#ifndef __CIRCULAR_BUFFER_API_ERRORS__
#define __CIRCULAR_BUFFER_API_ERRORS__

#define CIRCULAR_BUFFER_API_ERRORS_CODES                                              \
  /**                                                                          \
   * Circullar Buffer is full                                                  \
   */                                                                          \
  eError_circular_buffer_api_full,                                             \
                                                                               \
  /**                                                                          \
   * Circullar Buffer is empty                                                 \
   */                                                                          \
  eError_circular_buffer_api_empty,                                            \
                                                                               \
  /**                                                                          \
   * race condition, you have to wait                                          \
   * low_rate_0 or low_rate_1                                                  \
   */                                                                          \
  eError_circular_buffer_api_wait                                               
    
#endif
 
