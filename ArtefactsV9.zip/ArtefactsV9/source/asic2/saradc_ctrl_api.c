#include "hardware_api.h"
#include "saradc_ctrl_api.h"
#include "clk_nres.h"


#pragma pack(push)
#pragma pack(4)
static uint16_t g_saradc_ctrl_api_saradc_sample_mem[8];
static sarc_command_type_t saradc_ctrl_api_cmd_list [4];
#pragma pack(pop)


/* ############################################################################ */
void saradc_ctrl_api_clock(bool enable) {
  wdog_unlock_guard(GUARD0);
  clk_nres_unlock();

    // clock for UART (printf)
    clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_SARADC_CTRL, enable);
    clk_nres_set_nreset(CLKPNO_SARADC_CTRL, enable);

  wdog_disable (GUARD0); // GUARD disable
  while (wdog_is_running (GUARD0))  ;  
}

/* ############################################################################ */
void saradc_ctrl_api_init(void) {
  
  saradc_ctrl_api_clock(true);
  
  saradc_ctrl_cfg_t cfg;
  cfg.val = 0;
  cfg.bf.adc_on = 1;
  cfg.bf.buffer_on = 1;
  cfg.bf.adc_reset = 1;
  saradc_ctrl_set_cfg(cfg);          
  saradc_ctrl_cfg_sar_timing_t cfg_sar_timing;
  cfg_sar_timing.val = 0;
  
  cfg_sar_timing.bf.adc_clk_div = 2;
  cfg_sar_timing.bf.mux_phase = 20;
  saradc_ctrl_set_cfg_sar_timing(cfg_sar_timing);
  
  //sync_out_cfg
  saradc_ctrl_sync_out_cfg_t sync_out_cfg;
  sync_out_cfg.val = 3 | 1 <<8;
  saradc_ctrl_set_sync_out_cfg(sync_out_cfg);
  saradc_ctrl_set_sync_out_trig(100);
  
  //wait prescaler cfg
  saradc_ctrl_wait_prescaler_t wait_prescaler;
  wait_prescaler.val = 0x0204;
  saradc_ctrl_set_wait_prescaler(wait_prescaler);
  saradc_ctrl_wadr_min_t wadr_min;
  wadr_min.val = 0x0000;
  saradc_ctrl_set_wadr_min(wadr_min);
  
  saradc_ctrl_wadr_max_t wadr_max;
  wadr_max.val = 0xFFFF;                                                       
  saradc_ctrl_set_wadr_max(wadr_max);  
}

/* ############################################################################ */
errors_api_code_e saradc_ctrl_api_get_sample(uint8_t par_input, uint16_t *par_output) {

  g_saradc_ctrl_api_saradc_sample_mem[0]=0;
  
  uint16_t i_timeout = 65000;
  
  new_SARC_COMMAND_SMUXIMM(&saradc_ctrl_api_cmd_list[0],par_input);
  new_SARC_COMMAND_MIMM(&saradc_ctrl_api_cmd_list[1],ADR_TO_SARC(g_saradc_ctrl_api_saradc_sample_mem),SARC_TADR_NONE,0,1, par_input);
  new_SARC_COMMAND_END(&saradc_ctrl_api_cmd_list[2]);
     
  start_list(ADR_TO_SARC(saradc_ctrl_api_cmd_list), true); // SARC offset! 
    
  //wait_for_list_done();
  while (!(saradc_ctrl_get_irq_status().val & (1<<SARADC_CTRL_IRQ_SADR_DONE_NEMPTY))) {
    wait_cpu_cycles(32); //16 
    i_timeout--;
    if(i_timeout==0) {
      //printf("%s:TIMEOUT EXPIRED\n",__FUNCTION__);
      return(eError_saradc_ctrl_api_get_sample_timeout);
    }
  }
  
  saradc_ctrl_get_sadr_done();
  
  *par_output=g_saradc_ctrl_api_saradc_sample_mem[0];
    
  return(eError_none);
}

