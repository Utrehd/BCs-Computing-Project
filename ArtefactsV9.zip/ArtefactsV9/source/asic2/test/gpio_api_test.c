/**
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "gpio_api_test.h"
#include "gpio_api.h"           // The GPIO API
#include "clk_nres_api.h"
#include "test_msg.h"

/**
********************************************************************************
*               TEST FUNCTIONS gpio_api_set_sampler_f0
********************************************************************************
*/
bool gpio_api_set_sampler_f0_time_test_zero_time()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should = eError_gpio_api_pin_cannot_write_zero;
  
  // Value
  uint32_t f0_is;
  uint32_t f0_should = 1;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f0_time(BTN1, 0);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f0_is = gpio_get_f0_period(BTN1.gpio_group);
  
  if (f0_is == f0_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  return result;
}

/**
********************************************************************************
*/
bool gpio_api_set_sampler_f0_time_test_time_to_long()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should;
  error_should = eError_gpio_api_filter_cfg_period_does_not_fit_uint;
  
  // Value
  uint32_t f0_is;
  uint32_t f0_should = 1;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f0_time(BTN1, 24);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f0_is = gpio_get_f0_period(BTN1.gpio_group);
  
  if (f0_is == f0_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  return result;
}
/**
********************************************************************************
*/

bool gpio_api_set_sampler_f0_time_test_time()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should = eError_none;
  
  // Value
  uint32_t f0_is;
  uint32_t f0_should = 245;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f0_time(BTN1, 23);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f0_is = gpio_get_f0_period(BTN1.gpio_group);
  
  if (f0_is == f0_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    printf("%d instead of %d \n", f0_is, f0_should);
    result = false;
  }
  return result;
}
/**
********************************************************************************
*               TEST FUNCTIONS gpio_api_set_sampler_f1
********************************************************************************
*/


bool gpio_api_set_sampler_f1_time_test_zero_time()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should = eError_gpio_api_pin_cannot_write_zero;
  
  // Value
  uint32_t f1_is;
  uint32_t f1_should = 1;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f1_time(BTN1, 0);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f1_is = gpio_get_f1_period(BTN1.gpio_group);
  
  if (f1_is == f1_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  return result;
}

/**
********************************************************************************
*/
bool gpio_api_set_sampler_f1_time_test_time_to_long()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should;
  error_should = eError_gpio_api_filter_cfg_period_does_not_fit_uint;
  
  // Value
  uint32_t f1_is;
  uint32_t f1_should = 1;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f1_time(BTN1, 7000);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f1_is = gpio_get_f1_period(BTN1.gpio_group);
  
  if (f1_is == f1_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  return result;
}
/**
********************************************************************************
*/

bool gpio_api_set_sampler_f1_time_test_time()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should = eError_none;
  
  // Value
  uint32_t f1_is;
  uint32_t f1_should = 64000;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f1_time(BTN1, 6000);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f1_is = gpio_get_f1_period(BTN1.gpio_group);
  
  if (f1_is == f1_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    printf("%d instead of %d \n", f1_is, f1_should);
    result = false;
  }
  return result;
}
/**
********************************************************************************
*/
/**
********************************************************************************
*               TEST FUNCTIONS gpio_api_set_sampler_f1_based_on_f0
********************************************************************************
*/


bool gpio_api_set_sampler_f1_time_based_on_f0_test_zero_time()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should = eError_gpio_api_pin_cannot_write_zero;
  
  // Value
  uint32_t f1_is;
  uint32_t f1_should = 1;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f1_time_based_on_f0(BTN1, 0);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f1_is = gpio_get_f1_period(BTN1.gpio_group);
  
  if (f1_is == f1_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  return result;
}

/**
********************************************************************************
*/
bool gpio_api_set_sampler_f1_time_based_on_f0_test_time_to_long()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should;
  error_should = eError_gpio_api_filter_cfg_period_does_not_fit_uint;
  
  // Value
  uint32_t f1_is;
  uint32_t f1_should = 1;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f0_time(BTN1, 0);
  error_is = gpio_api_set_sampler_f1_time_based_on_f0(BTN1, 7000);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f1_is = gpio_get_f1_period(BTN1.gpio_group);
  
  if (f1_is == f1_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  return result;
}
/**
********************************************************************************
*/

bool gpio_api_set_sampler_f1_time_based_on_f0_test_time()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should = eError_none;
  
  // Value
  uint32_t f1_is;
  uint32_t f1_should = 64000;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f0_time(BTN1, 0);
  error_is = gpio_api_set_sampler_f1_time_based_on_f0(BTN1, 6000);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f1_is = gpio_get_f1_period(BTN1.gpio_group);
  
  if (f1_is == f1_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    printf("%d instead of %d \n", f1_is, f1_should);
    result = false;
  }
  return result;
}
/**
********************************************************************************
*/

bool gpio_api_set_sampler_f1_time_based_on_f0_test_time_2()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should = eError_none;
  
  // Value
  uint32_t f1_is;
  // Should be 1500 but because of rounding errors its less
  uint32_t f1_should = 1523;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f0_time(BTN1, 4);
  error_is = gpio_api_set_sampler_f1_time_based_on_f0(BTN1, 6000);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f1_is = gpio_get_f1_period(BTN1.gpio_group);
  
  if (f1_is == f1_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    printf("%d instead of %d \n", f1_is, f1_should);
    result = false;
  }
  return result;
}
/**
********************************************************************************
*/

bool gpio_api_set_sampler_f1_time_based_on_f0_test_time_f0_bigger()
{
  // ****** ARRANGE *******************
  PRINT_FNC_NAME;
  bool result = true;
  
  // Error
  errors_api_code_e error_is;
  errors_api_code_e error_should = eError_gpio_api_pin_cannot_write_zero;
  
  // Value
  uint32_t f1_is;
  // Should be 1500 but because of rounding errors its less
  uint32_t f1_should = 1;
  
  // Misc
  const device_pinout BTN1 = IOMUX_PAD29_STRUCT;
  
  // ****** ACT ***********************
  error_is = gpio_api_set_sampler_f0_time(BTN1, 4);
  error_is = gpio_api_set_sampler_f1_time_based_on_f0(BTN1, 1);
  
  // ****** ASSERT ********************
  
  // Check if error is set correctly  
  if (error_should == error_is)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    result = false;
  }
  
  // Check if register has value 1
  f1_is = gpio_get_f1_period(BTN1.gpio_group);
  
  if (f1_is == f1_should)
  {
    TEST_MSG_OK;
  }
  else
  {
    TEST_MSG_ERROR;
    printf("%d instead of %d \n", f1_is, f1_should);
    result = false;
  }
  return result;
}
/**
********************************************************************************
*/

bool gpio_api_test_all()
{
  // ARRANGE
  bool result = true;
  
  printf("\n\nTHE GPIO_API_TESTS\n\n");
  
  // ACT
  result |= gpio_api_set_sampler_f0_time_test_zero_time();
  result |= gpio_api_set_sampler_f0_time_test_time_to_long();
  result |= gpio_api_set_sampler_f0_time_test_time();
  
  result |= gpio_api_set_sampler_f1_time_test_zero_time();
  result |= gpio_api_set_sampler_f1_time_test_time_to_long();
  result |= gpio_api_set_sampler_f1_time_test_time();
  
  result |= gpio_api_set_sampler_f1_time_based_on_f0_test_zero_time();
  result |= gpio_api_set_sampler_f1_time_based_on_f0_test_time_to_long();
  result |= gpio_api_set_sampler_f1_time_based_on_f0_test_time();
  result |= gpio_api_set_sampler_f1_time_based_on_f0_test_time_2();
  result |= gpio_api_set_sampler_f1_time_based_on_f0_test_time_f0_bigger();
  
    
  // ASSERT
  return result;
}

/**
********************************************************************************
*/
