/**
* @file
*
* @brief Test messages - for requirments purposes
* This module is used to write special comments to standard output. This output 
* can be saved to log file and parsed by (perl) script.
*
*/
#ifndef HAVE_TEST_MSG_H
#define HAVE_TEST_MSG_H

#include <stdio.h>



extern volatile uint8_t  _i_module_; ///< Number of test module

// __no_init - do not init. variable after power-up

#define CLEAR_SCREEN            "\033[2J"
#define CURSOR_STORE_POSITION    "\033[s"
#define CURSOR_RESTORE_POSITION  "\033[u"

// GREEN
#define G_CLR "\033[38;5;2m"

// RED
#define R_CLR "\033[38;5;1m"

// WHITE
#define W_CLR "\033[38;5;7m"

#define TEST_MSG_INIT                          __no_init volatile uint8_t _i_module_                                                   ///< Test module variable declaration
#define TEST_MSG_START(_MODULE_)               _i_module_= _MODULE_; printf("%s:TEST START:%02d\nASIC_ID:0x%08x\n",__FUNCTION__,_i_module_,get_asic2_serial())   ///< Prints TEST START message with module number
#define TEST_MSG_CHK                           printf("%u:%s:CHK:%02d:",__LINE__,__FUNCTION__,_i_module_)                                     ///< Print check message 

#define TEST_MSG_TC4(_1st_,_2nd_,_3rd_,_4th_)  printf("%u:%s:TC:%02d.%d.%d.%d.%d:",__LINE__,__FUNCTION__,_i_module_,_1st_,_2nd_,_3rd_,_4th_) ///< Test Case (1st, 2nd, 3rd, 4th level)
#define TEST_MSG_TC3(_1st_,_2nd_,_3rd_)        printf("%u:%s:TC:%02d.%d.%d.%d:",__LINE__,__FUNCTION__,_i_module_,_1st_,_2nd_,_3rd_)          ///< Test Case (1st, 2nd, 3rd level)
#define TEST_MSG_TC2(_1st_,_2nd_)              printf("%u:%s:TC:%02d.%d.%d:",__LINE__,__FUNCTION__,_i_module_,_1st_,_2nd_)                   ///< Test Case (1st, 2nd level)
#define TEST_MSG_TC1(_1st_)                    printf("%u:%s:TC:%02d.%d:",__LINE__,__FUNCTION__,_i_module_,_1st_)                            ///< Test Case (1st level)
#define TEST_MSG_TC(_1st_,_2nd_,_3rd_)         TEST_MSG_TC3(_1st_,_2nd_,_3rd_)

#define TEST_MSG_REQ4(_1st_,_2nd_,_3rd_,_4th_) TEST_MSG_TC4(_1st_,_2nd_,_3rd_,_4th_)
#define TEST_MSG_REQ3(_1st_,_2nd_,_3rd_)       TEST_MSG_TC3(_1st_,_2nd_,_3rd_)
#define TEST_MSG_REQ2(_1st_,_2nd_)             TEST_MSG_TC2(_1st_,_2nd_)
#define TEST_MSG_REQ1(_1st_)                   TEST_MSG_TC1(_1st_)
#define TEST_MSG_REQ(_1st_,_2nd_,_3rd_)        TEST_MSG_TC3(_1st_,_2nd_,_3rd_)


#ifdef COLORIZE
  #define TEST_MSG_OK                            printf("%sOK%s\n",G_CLR,W_CLR);                                                    ///< print OK (colorize)
  #define TEST_MSG_ERROR                         printf("%sERROR%s\n",R_CLR,W_CLR);                                                 ///< print ERROR (colorize)
#else
  #define TEST_MSG_OK                            printf("OK\n");                                                                    ///< print OK
  #define TEST_MSG_ERROR                         printf("ERROR\n");                                                                 ///< print ERROR
#endif


#define TEST_MSG_STOP                          printf("%s:TEST STOP\n",__FUNCTION__)                                              ///< print TEST STOP
#define TEST_MSG_DELIMITER                     for(uint8_t t_m_i=0;t_m_i<80;t_m_i++) putchar('#');putchar('\n');                       ///< PRINT LINE DELIMITER

#define TEST_MSG_RESULT(i_test)                if(i_test) { TEST_MSG_OK; } else {TEST_MSG_ERROR;};                                ///< print OK/ERRO according to parameter

#define TEST_MSG_PRESS_P_F                     printf("Press p - PASS or f - FAIL\n"); \
                                               uint16_t i_uart_char; \
                                               do { \
                                               i_uart_char = getchar(); \
                                               } while( i_uart_char != 'p' && i_uart_char != 'f');


#define PASS    1   ///< the test result - test pass - it is sign value - not to have zero as default value
#define FAIL   -1   ///< the test result - test fail - it is sign value - not to have zero as default value


#define WHILE_WITH_TO(_i_con_,_i_init_to_) u32 i_timeout=_i_init_to_;while (_i_con_ && i_timeout > 0 ) i_timeout--; ///<While with timeout (cpu cycles)
#define WAIT_UNTIL_KEYPRESSED   while( getchar() == EOF ) ///< Wait until some byte is received
                                               
#define NEW_LINE             putchar('\n')

#define PRINT_FNC_NAME       printf("%s\n",__FUNCTION__)

#endif /* HAVE_TEST_MSG_H */