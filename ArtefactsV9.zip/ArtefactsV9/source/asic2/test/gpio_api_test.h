/**
********************************************************************************
********************************************************************************
* \copyright    Copyright (c) 2018 Eaton Industries GmbH,
*               GERMANY, All rights reserved
* \file         gpio_api_test.h
* \brief        Containts the test functions
* \author       Samuel.A Marti
*
********************************************************************************
* \version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
* \defgroup     common General porpuse functions
* \brief        Contains functions for general purpose useage
********************************************************************************
*/

#ifndef __GPIO_API_TEST__
#define __GPIO_API_TEST__

#include "errors_api.h"
#include "ASIC2_pinout.h"

/**
********************************************************************************
* \brief        Will run all tests defined in the gpio test file
*               Requires 32 MHZ as GPIO Clock.
*               
* \return       Bool, True if test sucessfull
* \retval       True:   The Test was sucessfull
* \retval       False:  The Test Failed
*
********************************************************************************
*/

bool gpio_api_test_all();

#endif
