/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         cctimer32.h
*
* @brief        Capture and Compare Timer 32 (CCTIMER32) HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CCTIMER32_H__
#define __CCTIMER32_H__

/**
 * \example example_CCTIMER32.c
 * This is an example of how to use CCTIMER32 block.
 */
 
/**
 * \defgroup cctimer32 ASIC2 Capture and Compare Timer 32 (CCTIMER32)  HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control Capture and Compare Timer 32 (CCTIMER32) 
 *
 *
 * How to use it (PWM Mode):
 * -# Configure the iomux for the CCTimer
 * -# Configure CCTimer: cctimer32_set_prescaler(), cctimer32_set_config() (for Timer A & B), cctimer32_set_capcmp(), cctimer32_set_capcmp()
 * -# Configure measurement: cctimer32_set_prescaler(), cctimer32_set_config_global(), cctimer32_set_config() (for Timer A & B)
 * -# Set the thresholds: cctimer_set_intf_thresholds()
 * -# Set control: cctimer32_set_control()
 * -# Set PWM desired value: cctimer32_set_capcmp()
 *
 *
 * \details See code example: @include example_CCTIMER32.c
 */

/**@{*/ 

#include "device.h"
#include "cctimer32_bf.h"

/**
  * \brief This is an enum class for CCTIMER32 to identify measurement source
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_MEAS_A    = 0x0, ///< measurement of signal A
  CCTIMER32_MEAS_B    = 0x1, ///< measurement of signal B
  CCTIMER32_MEAS_ZM   = 0x2, ///< measurement of Zero Marker signal
  CCTIMER32_MEAS_GATE = 0x3 ///< measurement of gate signal
} cctimer32_meas_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify the prescaler
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_AB = 0x0, ///< Select prescaler timer AB
  CCTIMER32_CD = 0x1 ///< Select prescaler timer CD
} cctimer32_prescaler_sel_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify timer
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_A = 0x0, ///< Select timer A
  CCTIMER32_B = 0x1, ///< Select timer B
  CCTIMER32_C = 0x2, ///< Select timer C
  CCTIMER32_D = 0x3 ///< Select timer D
} cctimer32_timer_sel_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify pwm mode
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_PWM_ON_B_EQ_0 = 0x0, ///< Active when COUNTER_B /= 0
  CCTIMER32_PWM_ON_D_EQ_0 = CCTIMER32_PWM_ON_B_EQ_0, ///< Active when COUNTER_D /= 0
  CCTIMER32_PWM_CC_TOGGLE = 0x1, ///< Toggle with compare event
  CCTIMER32_PWM_SET_0     = 0x2, ///< Set to 0
  CCTIMER32_PWM_SET_1     = 0x3 ///< Set to 1
} cctimer32_pwm_mode_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify encoder format
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_ED_STATE_LESS    = 0x0, ///< A, B signals. State less
  CCTIMER32_ED_FSM           = 0x1, ///< A, B signals. FSM, initialized when counter A enabled
  CCTIMER32_ED_PULSE_DIR     = 0x2, ///< pulse / direction
  CCTIMER32_ED_PULSE_UP_DOWN = 0x3 ///< pulse up / pulse down
} cctimer32_ed_format_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify encoder gate
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_ED_DISABLED = 0x0, ///< gate disabled
  CCTIMER32_ED_DIS_POS  = 0x1, ///< disables position increment
  CCTIMER32_ED_DIS_ZM   = 0x2 ///< disables zero marker event
} cctimer32_ed_gate_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify counter even selection
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_COUNT_CLK        = 0x0, ///< (prescaled) system clk
  CCTIMER32_COUNT_MEAS0_POS  = 0x1, ///< MEAS[0/1/2/3] positive edge
  CCTIMER32_COUNT_MEAS0_NEG  = 0x2, ///< MEAS[0/1/2/3] negative edge
  CCTIMER32_COUNT_ED         = 0x3, ///< event decoder (counter_action is ignored)
  CCTIMER32_COUNT_NMEAS0_CLK = 0x4, ///< (prescaled) system clk when MEAS[0/2]=0
  CCTIMER32_COUNT_MEAS0_CLK  = 0x5, ///< (prescaled) system clk when MEAS[0/2]=1
  CCTIMER32_COUNT_NMEAS1_CLK = 0x6, ///< (prescaled) system clk when MEAS[1/3]=0
  CCTIMER32_COUNT_MEAS1_CLK  = 0x7 ///< (prescaled) system clk when MEAS[1/3]=1
} cctimer32_conf_counter_sel_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify counter action
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_COUNT_INC = 0x0, ///< counter increases
  CCTIMER32_COUNT_DEC = 0x1 ///< counter decreases
} cctimer32_conf_counter_act_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify restart event selection
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_RES_OWN_CC     = 0x0, ///< counter initially enabled / own CC event
  CCTIMER32_RES_NONE       = 0x1, ///< none
  CCTIMER32_RES_OTHER_CC   = 0x2, ///< other counter CC event
  CCTIMER32_RES_MEAS0_POS  = 0x3, ///< MEAS[0/2] signal posisitve edge
  CCTIMER32_RES_MEAS0_NEG  = 0x4, ///< MEAS[0/2] signal negative edge
  CCTIMER32_RES_MEAS1_POS  = 0x5, ///< MEAS[1/3] signal positive edge
  CCTIMER32_RES_MEAS1_NEG  = 0x6, ///< MEAS[1/3] signal negative edge
  CCTIMER32_RES_ED_STEP    = 0x7, ///< event counter decoding step pulses
  CCTIMER32_RES_ED_DIR     = 0x8, ///< event counter decoding direction change
  CCTIMER32_RES_ED_ZM      = 0x9, ///< zero marker event
  CCTIMER32_RES_SYNC       = 0xA ///< sync event
} cctimer32_conf_restart_sel_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify action when restart event occurs
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_RES_0      = 0x0, ///< COUNTER <= 0
  CCTIMER32_RES_CAPCMP = 0x1 ///< COUNTER <= CAPCMP
} cctimer32_conf_restart_act_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify Capture/Compare (CC) event selection
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_CC_EQ_CAPCMP  = 0x0, ///< COUNTER=CAPCMP
  CCTIMER32_CC_EQ_0       = 0x1, ///< COUNTER=0
  CCTIMER32_CC_OTHER_CC   = 0x2, ///< other counter CC event
  CCTIMER32_CC_MEAS0_POS  = 0x3, ///< MEAS[0/2] signal posisitve edge
  CCTIMER32_CC_MEAS0_NEG  = 0x4, ///< MEAS[0/2] signal negative edge
  CCTIMER32_CC_MEAS1_POS  = 0x5, ///< MEAS[1/3] signal positive edge
  CCTIMER32_CC_MEAS1_NEG  = 0x6, ///< MEAS[1/3] signal negative edge
  CCTIMER32_CC_ED_STEP    = 0x7, ///< event counter decoding step pulses
  CCTIMER32_CC_ED_DIR     = 0x8, ///< event counter decoding direction change
  CCTIMER32_CC_ED_ZM      = 0x9, ///< zero marker event
  CCTIMER32_CC_SYNC       = 0xA ///< sync event
} cctimer32_conf_cc_sel_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify action when Capture/Compare (CC) occurs
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_CC_NONE   = 0x0, ///< none 
  CCTIMER32_CC_CAPCMP = 0x1 ///< CAPCMP <= COUNTER
} cctimer32_conf_cc_act_t;

/**
  * \brief This is an enum class for CCTIMER32 to identify timer mode selection
  *
  * \ingroup cctimer32
  */
typedef enum {
  CCTIMER32_MODE_SINGLE  = 0x0, ///< single shot (CC event clears enable)
  CCTIMER32_MODE_LOOP    = 0x1, ///< run continuously (loop)
  CCTIMER32_MODE_RESTART = 0x2 ///< like single shot but does not clear enable and restarts with every restart event (restart loop)
} cctimer32_conf_mode_t;

/**
  * \brief This structure describes CCTIMER32 registers
  *
  * \ingroup cctimer32
  */
typedef struct {
  uint32_t addr; ///< address which is located the desired value
  uint16_t value; ///< value in a specific address
} cctimer32_compr_conf_t;

/* ############################################################################ */
/**
 * \brief   Function to configure CCTIMER32 prescaler
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * 
 * \param sel Select the prescaler
 *
 * \param prescaler value of the prescaler
 *
 * \param reload reload value of the prescaler
 *
 */
void cctimer32_set_prescaler(cctimer32_num_t timer, cctimer32_prescaler_sel_t sel, uint8_t prescaler, uint8_t reload);

/* ############################################################################ */
/**
 * \brief   Function to get CCTIMER32 current prescaler value
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * 
 * \param sel Select the prescaler
 *
 * \return Current CRC configuration
 */
uint16_t  cctimer32_get_ps_ab(cctimer32_num_t timer, cctimer32_prescaler_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to change CCTIMER32 prescaler reload value
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * 
 * \param sel Select the prescaler
 *
 * \param reload reload value of the prescaler
 *
 */
void cctimer32_set_pre_reload(cctimer32_num_t timer, cctimer32_prescaler_sel_t sel, uint8_t reload);

/* ############################################################################ */
/**
 * \brief   Function to configure CCTIMER32 control
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param enable_a A enable (0: disabled 1: enabled)
 * \param enable_b B enable (0: disabled 1: enabled)
 * \param enable_c C enable (0: disabled 1: enabled)
 * \param enable_d D enable (0: disabled 1: enabled)
 * \param restart_a 1: restart event for A
 * \param restart_b 1: restart event for B
 * \param restart_c 1: restart event for C
 * \param restart_d 1: restart event for D
 * \param restart_ps_ab 1: restart AB prescaler
 * \param restart_ps_cd 1: restart CD prescaler
 * \param read_sync_c 1: execute read sync
 * \param read_sync_d 1: execute read sync
 * \param write_sync_c 1: execute write sync
 * \param write_sync_d 1: execute write sync
 */
void cctimer32_set_control(
  cctimer32_num_t timer,
  bool enable_a, 
  bool enable_b, 
  bool enable_c, 
  bool enable_d,
  bool restart_a, 
  bool restart_b, 
  bool restart_c, 
  bool restart_d, 
  bool restart_ps_ab, 
  bool restart_ps_cd,
  bool read_sync_c, 
  bool read_sync_d, 
  bool write_sync_c, 
  bool write_sync_d);

/* ############################################################################ */
/**
 * \brief   Function to set CCTIMER32 global configuration
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param ab_16_32 0: A / B independent 2 x 16 bit counters <br> 1: A / B single 32 bit counter
 * \param cd_16_32 0: C / D independent 2 x 16 bit counters <br> 1: C / D single 32 bit counter
 * \param sync_en_c 1: sync input signal for c enabled
 * \param sync_en_d 1: sync input signal for d enabled
 * \param pwm_ab 0: PWM[0] on while COUNTER_B /= 0 <br> 1: PWM[0] toggle with compare event <br> 2: PWM[0] set to 0 <br> 3: PWM[0] set to 1
 * \param pwm_cd 0: PWM[1] on while COUNTER_C /= 0 <br> 1: PWM[1] toggle with compare event <br> 2: PWM[1] set to 0 <br> 3: PWM[1] set to 1
 * \param ps_disable_ab 1: prescaler AB registers disabled and used for event decoder events
 */
void cctimer32_set_config_global(
  cctimer32_num_t timer,
  bool ab_16_32, 
  bool cd_16_32, 
  bool sync_en_c, 
  bool sync_en_d,
  cctimer32_pwm_mode_t pwm_ab, 
  cctimer32_pwm_mode_t pwm_cd,
  bool ps_disable_ab);

/* ############################################################################ */
/**
 * \brief   Function to configure CCTIMER32 encoder
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param inv_a 1: invert input A signal in front of the decoder
 * \param inv_b 1: invert input B signal in front of the decoder
 * \param inv_zm 1: invert input zero market signal in front of the decoder
 * \param inv_gate 1: invert input gate signal in front of the decoder
 * \param swap_ab 1: swap signals A and B in front of the decoder
 * \param cctimer32_ed_format_t 0: A B (state less) <br> 1: A B (FSM, initialized when counter A enabled) <br> 2: pulse / direction <br> 3: pulse up / pulse down
 * \param cctimer32_ed_gate_t 0: gate disabled <br> 1: gate=0 disables position increment <br> 2: gate=0 disables zero marker event
 */
void cctimer32_set_config_ed(
  cctimer32_num_t timer,
  bool inv_a, 
  bool inv_b, 
  bool inv_zm, 
  bool inv_gate,
  bool swap_ab, 
  cctimer32_ed_format_t format, 
  cctimer32_ed_gate_t gate);

/* ############################################################################ */
/**
 * \brief   Function to configure CCTIMER32
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \param counter_sel counter event selection
 * \param counter_act action when counter event occurs
 * \param restart_sel restart event selection (affects CONTROL.enable)
 * \param restart_act action when restart event occurs
 * \param cc_sel capture/compare (CC) event selection
 * \param cc_act action when cc event occurs
 * \param mode mode selection
 */
void cctimer32_set_config(
  cctimer32_num_t timer, 
  cctimer32_timer_sel_t sel, 
  cctimer32_conf_counter_sel_t counter_sel, 
  cctimer32_conf_counter_act_t counter_act,
  cctimer32_conf_restart_sel_t restart_sel, 
  cctimer32_conf_restart_act_t restart_act,
  cctimer32_conf_cc_sel_t cc_sel, 
  cctimer32_conf_cc_act_t cc_act,
  cctimer32_conf_mode_t mode);

/* ############################################################################ */
/**
 * \brief   Function to configure CCTIMER32 thresholds
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param intf_ab integrator threshold for inputs meas[0] and meas[1] (a and b)
 * \param intf_zm_gate integrator threshold for inputs meas[2] and meas[3] (zm and gate)
 * \param intf_clk_div clock divider for the integrators of all inputs
 */
void cctimer_set_intf_thresholds(cctimer32_num_t timer, uint8_t intf_ab, uint8_t intf_zm_gate, uint16_t intf_clk_div);

/* ############################################################################ */
/**
 * \brief   Function to write CCTIMER32 Capture/Compare value
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \param val compare value OR captured value
 */
void cctimer32_set_capcmp(cctimer32_num_t timer, cctimer32_timer_sel_t sel, uint16_t val);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Capture/Compare value
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return compare value OR captured value
 */
uint16_t cctimer32_get_capcmp(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 counter
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return current counter value
 */
uint16_t cctimer32_get_counter(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to read specific bit in CCTIMER32 Interrupt Request Status register
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param pos offset of the desired address inside Interrupt Request Status register
 * \return current value in the specified position
 */
bool cctimer32_is_irq_pos(cctimer32_num_t timer, uint8_t pos);

/* ############################################################################ */
/**
 * \brief   Function to read full CCTIMER32 Interrupt Request Status register
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \return current Interrupt Request Status register value
 */
uint16_t  cctimer32_get_irqs(cctimer32_num_t timer);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request overflow status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return Current counter A over/underflow status
 */
bool cctimer32_is_overflow(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request restart status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return Current counter A restart event status
 */
bool cctimer32_is_restart(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request capture status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return Current counter 0 capture event status
 */
bool cctimer32_is_capture(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request zero marker status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return Current decoder events: zero marker status
 */
bool cctimer32_is_zm(cctimer32_num_t timer);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request direction change status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return Current decoder events: direction change status
 */
bool cctimer32_is_dir_change(cctimer32_num_t timer);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request position change status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return Current decoder events: position change status
 */
bool cctimer32_is_pos_change(cctimer32_num_t timer);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request A/B track error status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return Current decoder events: A/B track error status
 */
bool cctimer32_is_ab_error(cctimer32_num_t timer);

/* ############################################################################ */
/**
 * \brief Function to clear specific bit in CCTIMER32 Interrupt Request Status register
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param pos offset of the desired address inside Interrupt Request Status register
 */
void cctimer32_clear_irq_pos(cctimer32_num_t timer, uint8_t pos);

/* ############################################################################ */
/**
 * \brief   Function to clear full CCTIMER32 Interrupt Request Status register
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 */
void cctimer32_clear_all_irqs(cctimer32_num_t timer);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request A/B track error status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return Current decoder events: A/B track error status
 */
void cctimer32_clear_overflow(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to clear CCTIMER32 Interrupt Request overflow status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 */
void cctimer32_clear_restart(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to clear CCTIMER32 Interrupt Request capture status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 */
void cctimer32_clear_capture(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to clear CCTIMER32 Interrupt Request zero marker status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 */
void cctimer32_clear_zm(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to clear CCTIMER32 Interrupt Request direction change status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 */
void cctimer32_clear_dir_change(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to clear CCTIMER32 Interrupt Request position change status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 */
void cctimer32_clear_pos_change(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to clear CCTIMER32 Interrupt Request A/B track error status
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 */
void cctimer32_clear_ab_error(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/* ############################################################################ */
/**
 * \brief   Function to set CCTIMER32 Interrupt Request mask
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param mask Interrupt mask: <br> 1: enabled <br> 0: disabled
 */
void cctimer32_set_irq_mask(cctimer32_num_t timer, uint16_t mask);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request mask
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \return current interrupt mask
 */
uint16_t cctimer32_get_irq_mask(cctimer32_num_t timer);

/* ############################################################################ */
/**
 * \brief   Function to read CCTIMER32 Interrupt Request Status register
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \return current interrupt request status
 */
cctimer32_irq_status_t cctimer32_get_irq_status(cctimer32_num_t timer);

/* ############################################################################ */
/**
 * \brief   Function to load CCTIMER32 configuration into a data structure
 *
 * \ingroup cctimer32
 * 
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \param counter_sel counter event selection
 * \param counter_act action when counter event occurs
 * \param restart_sel restart event selection (affects CONTROL.enable)
 * \param restart_act action when restart event occurs
 * \param cc_sel capture/compare (CC) event selection
 * \param cc_act action when cc event occurs
 * \param mode mode selection
 * \return current configuration
 */
cctimer32_compr_conf_t cctimer32_convert_compr_config(
  cctimer32_num_t timer, 
  cctimer32_timer_sel_t sel, 
  cctimer32_conf_counter_sel_t counter_sel, 
  cctimer32_conf_counter_act_t counter_act,
  cctimer32_conf_restart_sel_t restart_sel, 
  cctimer32_conf_restart_act_t restart_act,
  cctimer32_conf_cc_sel_t cc_sel, 
  cctimer32_conf_cc_act_t cc_act,
  cctimer32_conf_mode_t mode);

/* ############################################################################ */
/**
 * \brief  Function to configure CCTIMER32 through data structure
 *
 * \ingroup cctimer32
 * 
 * \param compr_config CCTIMER32 configuration in a data structure
 */
void cctimer_set_compr_config(cctimer32_compr_conf_t compr_config);

/* ############################################################################ */
/**
 * \brief  Function to load CCTIMER32 configuration into a data structure
 *
 * \ingroup cctimer32
 *
 * \param timer Select CCTIMER32 instance
 * \param sel Select the prescaler
 * \return Current CCTIMER32 configuration in a data structure
 */
cctimer32_compr_conf_t cctimer_get_compr_config(cctimer32_num_t timer, cctimer32_timer_sel_t sel);

/**@} */
#endif /* __CCTIMER32_H__ */
