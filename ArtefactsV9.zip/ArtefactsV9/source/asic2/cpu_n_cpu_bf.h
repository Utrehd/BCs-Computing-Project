/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         cpu_n_cpu_bf.h
*
* @brief        CPU_N_CPU HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CPU_N_CPU_BF_H__
#define __CPU_N_CPU_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_CPU_N_CPU_0
#define BASE_ADDR_CPU_N_CPU_0 0x40006580U
#endif
#ifndef BASE_ADDR_CPU_N_CPU_1
#define BASE_ADDR_CPU_N_CPU_1 0x40006C80U
#endif
#ifndef BASE_ADDR_CPU_N_CPU_EXT
#define BASE_ADDR_CPU_N_CPU_EXT 0x40007800U
#endif

#define MULTIPLE_CPU_N_CPU
#define NUMBER_CPU_N_CPU 3

/**
  * \brief This is an enum class for CPU_N_CPU instance
  *
  * \ingroup cpu_n_cpu
  */ 
typedef enum {
  CPU_N_CPU_0                    = (int)BASE_ADDR_CPU_N_CPU_0, ///< This is instance CPU_N_CPU_0
  CPU_N_CPU_1                    = (int)BASE_ADDR_CPU_N_CPU_1, ///< This is instance CPU_N_CPU_1
  CPU_N_CPU_EXT                  = (int)BASE_ADDR_CPU_N_CPU_EXT ///< This is instance CPU_N_CPU_EXT
} cpu_n_cpu_num_t;

// Register bit field definitions

/* CPU_N_CPU_ACC_N */

#define MSK_CPU_N_CPU_ACC_N                                 (0x7)     /* [ 2:0] */

typedef unsigned short cpu_n_cpu_acc_n_t;                             /* [ 2:0] */


/* CPU_N_CPU_ACC_TSF */

#define MSK_CPU_N_CPU_ACC_TSF                               (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_acc_tsf_t;                           /* [15:0] */


/* CPU_N_CPU_ACC_IRQ_SET */

#define MSK_CPU_N_CPU_ACC_IRQ_SET                           (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_acc_irq_set_t;                       /* [15:0] */


/* CPU_N_CPU_ACC_IRQ_CLR */

#define MSK_CPU_N_CPU_ACC_IRQ_CLR                           (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_acc_irq_clr_t;                       /* [15:0] */


/* CPU_N_CPU_AC_TSF */

#define MSK_CPU_N_CPU_AC_TSF                                (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_ac_tsf_t;                            /* [15:0] */


/* CPU_N_CPU_AC_IRQ_SET */

#define MSK_CPU_N_CPU_AC_IRQ_SET                            (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_ac_irq_set_t;                        /* [15:0] */


/* CPU_N_CPU_AC_IRQ_CLR */

#define MSK_CPU_N_CPU_AC_IRQ_CLR                            (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_ac_irq_clr_t;                        /* [15:0] */


/* CPU_N_CPU_TSF */

#define MSK_CPU_N_CPU_TSF                                   (0x1)     /* [0] */

typedef unsigned short cpu_n_cpu_tsf_t;                               /* [0] */


/* CPU_N_CPU_TS_FLAGS */

#define MSK_CPU_N_CPU_TS_FLAGS                              (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_ts_flags_t;                          /* [15:0] */


/* CPU_N_CPU_IRQFLAGS_SET_CLR */

#define MSK_CPU_N_CPU_IRQFLAGS_SET_CLR_SET_NO               (0x1f)    /* [ 4:0] */
#define RES_CPU_N_CPU_IRQFLAGS_SET_CLR_SET_NO               (0x00)
#define SFT_CPU_N_CPU_IRQFLAGS_SET_CLR_SET_NO               (0)
#define LSB_CPU_N_CPU_IRQFLAGS_SET_CLR_SET_NO               (0)
#define MSB_CPU_N_CPU_IRQFLAGS_SET_CLR_SET_NO               (4)
#define MSK_CPU_N_CPU_IRQFLAGS_SET_CLR_CLR_NO               (0x1f)    /* [12:8] */
#define RES_CPU_N_CPU_IRQFLAGS_SET_CLR_CLR_NO               (0x00)
#define SFT_CPU_N_CPU_IRQFLAGS_SET_CLR_CLR_NO               (8)
#define LSB_CPU_N_CPU_IRQFLAGS_SET_CLR_CLR_NO               (8)
#define MSB_CPU_N_CPU_IRQFLAGS_SET_CLR_CLR_NO               (12)

/** 
 * \brief This structure describes CPU_N_CPU IRQ Flags
 *
 * \ingroup cpu_n_cpu
 */
typedef struct {
/**
 * <B>bits 4:0</B> <br> 
 * When access is permitted (AC_IRQ_SET(set_no)='1'): <br>
 * -> set_no=0..15: sets interrupt flag with number set_no <br>
 * -> set_no >15: no action <br>
 * When access is disallowed (AC_IRQ_SET(set_no)='0'): <br>
 * -> no action <br>
 */
  unsigned short set_no                        :    5;
  unsigned short reserved7                     :    3; ///< <B>bits 7:5</B> <br> reserved
/**
 * <B>bits 12:8</B> <br> 
 * When access is permitted (AC_IRQ_CLR(clr_no)='1'): <br>
 * -> set_no=0..15 clears interrupt flag with number clr_no <br>
 * -> clr_no>15: no action <br>
 * When access is disallowed (AC_IRQ_CLR(clr_no)='0'): <br>
 * -> no action <br>
 */
  unsigned short clr_no                        :    5;
  unsigned short reserved                      :    3; ///< <B>bits 15:13</B> <br> reserved
} cpu_n_cpu_irqflags_set_clr_bf;

/**
 * \brief Conversion type between word and bit representation of CPU_N_CPU IRQ Flags
 *
 * \ingroup cpu_n_cpu
 */
typedef union {
  unsigned short val;
  cpu_n_cpu_irqflags_set_clr_bf bf;
} cpu_n_cpu_irqflags_set_clr_t;


/* CPU_N_CPU_IRQ_STATUS0 */

#define MSK_CPU_N_CPU_IRQ_STATUS0                           (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_irq_status0_t;                       /* [15:0] */


/* CPU_N_CPU_IRQ_STATUS1 */

#define MSK_CPU_N_CPU_IRQ_STATUS1                           (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_irq_status1_t;                       /* [15:0] */


/* CPU_N_CPU_IRQ_MASK0 */

#define MSK_CPU_N_CPU_IRQ_MASK0                             (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_irq_mask0_t;                         /* [15:0] */


/* CPU_N_CPU_IRQ_MASK1 */

#define MSK_CPU_N_CPU_IRQ_MASK1                             (0xffff)  /* [15:0] */

typedef unsigned short cpu_n_cpu_irq_mask1_t;                         /* [15:0] */


/* CPU_N_CPU_IRQ_VENABLE */

#define MSK_CPU_N_CPU_IRQ_VENABLE                           (0x1f)    /* [ 4:0] */

typedef unsigned short cpu_n_cpu_irq_venable_t;                       /* [ 4:0] */


/* CPU_N_CPU_IRQ_VDISABLE */

#define MSK_CPU_N_CPU_IRQ_VDISABLE                          (0x1f)    /* [ 4:0] */

typedef unsigned short cpu_n_cpu_irq_vdisable_t;                      /* [ 4:0] */


/* CPU_N_CPU_IRQ_VMAX */

#define MSK_CPU_N_CPU_IRQ_VMAX                              (0x3f)    /* [ 5:0] */

typedef unsigned short cpu_n_cpu_irq_vmax_t;                          /* [ 5:0] */


/* CPU_N_CPU_IRQ_VNO */

#define MSK_CPU_N_CPU_IRQ_VNO                               (0x3f)    /* [ 5:0] */

typedef unsigned short cpu_n_cpu_irq_vno_t;                           /* [ 5:0] */



// Register definitions for module
// Instance base address BASE_ADDR_CPU_N_CPU_0 0x40006580U ... 
// Instance base address BASE_ADDR_CPU_N_CPU_1 0x40006C80U ... 
// Instance base address BASE_ADDR_CPU_N_CPU_EXT 0x40007800U ... 

#define ADDR_CPU_N_CPU_ACC_N                                 (0x00U)
#define A_CPU_N_CPU_ACC_N(ba)                                ((ba) + ADDR_CPU_N_CPU_ACC_N)
#define R_CPU_N_CPU_ACC_N(ba)                                (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_ACC_N(ba)))
#define RES_CPU_N_CPU_ACC_N                                  (0x0U)
#define MSB_CPU_N_CPU_ACC_N                                  2
#define LSB_CPU_N_CPU_ACC_N                                  0
#define AADDR_CPU_N_CPU_0_ACC_N                              (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_N)
#define AADDR_CPU_N_CPU_1_ACC_N                              (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_ACC_N)
#define AADDR_CPU_N_CPU_EXT_ACC_N                            (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_ACC_N)
#define REG_CPU_N_CPU_0_ACC_N                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_ACC_N))
#define REG_CPU_N_CPU_1_ACC_N                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_ACC_N))
#define REG_CPU_N_CPU_EXT_ACC_N                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_ACC_N))

#define ADDR_CPU_N_CPU_ACC_TSF                               (0x02U)
#define A_CPU_N_CPU_ACC_TSF(ba)                              ((ba) + ADDR_CPU_N_CPU_ACC_TSF)
#define R_CPU_N_CPU_ACC_TSF(ba)                              (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_ACC_TSF(ba)))
#define RES_CPU_N_CPU_ACC_TSF                                (0xffffU)
#define MSB_CPU_N_CPU_ACC_TSF                                15
#define LSB_CPU_N_CPU_ACC_TSF                                0
#define AADDR_CPU_N_CPU_0_ACC_TSF                            (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_TSF)
#define AADDR_CPU_N_CPU_1_ACC_TSF                            (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_ACC_TSF)
#define AADDR_CPU_N_CPU_EXT_ACC_TSF                          (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_ACC_TSF)
#define REG_CPU_N_CPU_0_ACC_TSF                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_ACC_TSF))
#define REG_CPU_N_CPU_1_ACC_TSF                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_ACC_TSF))
#define REG_CPU_N_CPU_EXT_ACC_TSF                            (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_ACC_TSF))

#define ADDR_CPU_N_CPU_ACC_IRQ_SET                           (0x04U)
#define A_CPU_N_CPU_ACC_IRQ_SET(ba)                          ((ba) + ADDR_CPU_N_CPU_ACC_IRQ_SET)
#define R_CPU_N_CPU_ACC_IRQ_SET(ba)                          (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_ACC_IRQ_SET(ba)))
#define RES_CPU_N_CPU_ACC_IRQ_SET                            (0xffffU)
#define MSB_CPU_N_CPU_ACC_IRQ_SET                            15
#define LSB_CPU_N_CPU_ACC_IRQ_SET                            0
#define AADDR_CPU_N_CPU_0_ACC_IRQ_SET                        (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_IRQ_SET)
#define AADDR_CPU_N_CPU_1_ACC_IRQ_SET                        (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_ACC_IRQ_SET)
#define AADDR_CPU_N_CPU_EXT_ACC_IRQ_SET                      (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_ACC_IRQ_SET)
#define REG_CPU_N_CPU_0_ACC_IRQ_SET                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_ACC_IRQ_SET))
#define REG_CPU_N_CPU_1_ACC_IRQ_SET                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_ACC_IRQ_SET))
#define REG_CPU_N_CPU_EXT_ACC_IRQ_SET                        (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_ACC_IRQ_SET))

#define ADDR_CPU_N_CPU_ACC_IRQ_CLR                           (0x06U)
#define A_CPU_N_CPU_ACC_IRQ_CLR(ba)                          ((ba) + ADDR_CPU_N_CPU_ACC_IRQ_CLR)
#define R_CPU_N_CPU_ACC_IRQ_CLR(ba)                          (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_ACC_IRQ_CLR(ba)))
#define RES_CPU_N_CPU_ACC_IRQ_CLR                            (0xffffU)
#define MSB_CPU_N_CPU_ACC_IRQ_CLR                            15
#define LSB_CPU_N_CPU_ACC_IRQ_CLR                            0
#define AADDR_CPU_N_CPU_0_ACC_IRQ_CLR                        (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_ACC_IRQ_CLR)
#define AADDR_CPU_N_CPU_1_ACC_IRQ_CLR                        (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_ACC_IRQ_CLR)
#define AADDR_CPU_N_CPU_EXT_ACC_IRQ_CLR                      (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_ACC_IRQ_CLR)
#define REG_CPU_N_CPU_0_ACC_IRQ_CLR                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_ACC_IRQ_CLR))
#define REG_CPU_N_CPU_1_ACC_IRQ_CLR                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_ACC_IRQ_CLR))
#define REG_CPU_N_CPU_EXT_ACC_IRQ_CLR                        (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_ACC_IRQ_CLR))

#define ADDR_CPU_N_CPU_AC_TSF                                (0x08U)
#define A_CPU_N_CPU_AC_TSF(ba)                               ((ba) + ADDR_CPU_N_CPU_AC_TSF)
#define R_CPU_N_CPU_AC_TSF(ba)                               (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_AC_TSF(ba)))
#define RES_CPU_N_CPU_AC_TSF                                 (0xffffU)
#define MSB_CPU_N_CPU_AC_TSF                                 15
#define LSB_CPU_N_CPU_AC_TSF                                 0
#define AADDR_CPU_N_CPU_0_AC_TSF                             (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_AC_TSF)
#define AADDR_CPU_N_CPU_1_AC_TSF                             (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_AC_TSF)
#define AADDR_CPU_N_CPU_EXT_AC_TSF                           (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_AC_TSF)
#define REG_CPU_N_CPU_0_AC_TSF                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_AC_TSF))
#define REG_CPU_N_CPU_1_AC_TSF                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_AC_TSF))
#define REG_CPU_N_CPU_EXT_AC_TSF                             (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_AC_TSF))

#define ADDR_CPU_N_CPU_AC_IRQ_SET                            (0x0AU)
#define A_CPU_N_CPU_AC_IRQ_SET(ba)                           ((ba) + ADDR_CPU_N_CPU_AC_IRQ_SET)
#define R_CPU_N_CPU_AC_IRQ_SET(ba)                           (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_AC_IRQ_SET(ba)))
#define RES_CPU_N_CPU_AC_IRQ_SET                             (0xffffU)
#define MSB_CPU_N_CPU_AC_IRQ_SET                             15
#define LSB_CPU_N_CPU_AC_IRQ_SET                             0
#define AADDR_CPU_N_CPU_0_AC_IRQ_SET                         (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_AC_IRQ_SET)
#define AADDR_CPU_N_CPU_1_AC_IRQ_SET                         (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_AC_IRQ_SET)
#define AADDR_CPU_N_CPU_EXT_AC_IRQ_SET                       (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_AC_IRQ_SET)
#define REG_CPU_N_CPU_0_AC_IRQ_SET                           (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_AC_IRQ_SET))
#define REG_CPU_N_CPU_1_AC_IRQ_SET                           (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_AC_IRQ_SET))
#define REG_CPU_N_CPU_EXT_AC_IRQ_SET                         (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_AC_IRQ_SET))

#define ADDR_CPU_N_CPU_AC_IRQ_CLR                            (0x0CU)
#define A_CPU_N_CPU_AC_IRQ_CLR(ba)                           ((ba) + ADDR_CPU_N_CPU_AC_IRQ_CLR)
#define R_CPU_N_CPU_AC_IRQ_CLR(ba)                           (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_AC_IRQ_CLR(ba)))
#define RES_CPU_N_CPU_AC_IRQ_CLR                             (0xffffU)
#define MSB_CPU_N_CPU_AC_IRQ_CLR                             15
#define LSB_CPU_N_CPU_AC_IRQ_CLR                             0
#define AADDR_CPU_N_CPU_0_AC_IRQ_CLR                         (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_AC_IRQ_CLR)
#define AADDR_CPU_N_CPU_1_AC_IRQ_CLR                         (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_AC_IRQ_CLR)
#define AADDR_CPU_N_CPU_EXT_AC_IRQ_CLR                       (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_AC_IRQ_CLR)
#define REG_CPU_N_CPU_0_AC_IRQ_CLR                           (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_AC_IRQ_CLR))
#define REG_CPU_N_CPU_1_AC_IRQ_CLR                           (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_AC_IRQ_CLR))
#define REG_CPU_N_CPU_EXT_AC_IRQ_CLR                         (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_AC_IRQ_CLR))

#define ADDR_CPU_N_CPU_TSF0                                  (0x0EU)
#define A_CPU_N_CPU_TSF0(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF0)
#define R_CPU_N_CPU_TSF0(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF0(ba)))
#define RES_CPU_N_CPU_TSF0                                   (0x0U)
#define MSB_CPU_N_CPU_TSF0                                   0
#define LSB_CPU_N_CPU_TSF0                                   0
#define AADDR_CPU_N_CPU_0_TSF0                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF0)
#define AADDR_CPU_N_CPU_1_TSF0                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF0)
#define AADDR_CPU_N_CPU_EXT_TSF0                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF0)
#define REG_CPU_N_CPU_0_TSF0                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF0))
#define REG_CPU_N_CPU_1_TSF0                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF0))
#define REG_CPU_N_CPU_EXT_TSF0                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF0))

#define ADDR_CPU_N_CPU_TSF1                                  (0x10U)
#define A_CPU_N_CPU_TSF1(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF1)
#define R_CPU_N_CPU_TSF1(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF1(ba)))
#define RES_CPU_N_CPU_TSF1                                   (0x0U)
#define MSB_CPU_N_CPU_TSF1                                   0
#define LSB_CPU_N_CPU_TSF1                                   0
#define AADDR_CPU_N_CPU_0_TSF1                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF1)
#define AADDR_CPU_N_CPU_1_TSF1                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF1)
#define AADDR_CPU_N_CPU_EXT_TSF1                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF1)
#define REG_CPU_N_CPU_0_TSF1                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF1))
#define REG_CPU_N_CPU_1_TSF1                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF1))
#define REG_CPU_N_CPU_EXT_TSF1                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF1))

#define ADDR_CPU_N_CPU_TSF2                                  (0x12U)
#define A_CPU_N_CPU_TSF2(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF2)
#define R_CPU_N_CPU_TSF2(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF2(ba)))
#define RES_CPU_N_CPU_TSF2                                   (0x0U)
#define MSB_CPU_N_CPU_TSF2                                   0
#define LSB_CPU_N_CPU_TSF2                                   0
#define AADDR_CPU_N_CPU_0_TSF2                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF2)
#define AADDR_CPU_N_CPU_1_TSF2                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF2)
#define AADDR_CPU_N_CPU_EXT_TSF2                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF2)
#define REG_CPU_N_CPU_0_TSF2                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF2))
#define REG_CPU_N_CPU_1_TSF2                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF2))
#define REG_CPU_N_CPU_EXT_TSF2                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF2))

#define ADDR_CPU_N_CPU_TSF3                                  (0x14U)
#define A_CPU_N_CPU_TSF3(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF3)
#define R_CPU_N_CPU_TSF3(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF3(ba)))
#define RES_CPU_N_CPU_TSF3                                   (0x0U)
#define MSB_CPU_N_CPU_TSF3                                   0
#define LSB_CPU_N_CPU_TSF3                                   0
#define AADDR_CPU_N_CPU_0_TSF3                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF3)
#define AADDR_CPU_N_CPU_1_TSF3                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF3)
#define AADDR_CPU_N_CPU_EXT_TSF3                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF3)
#define REG_CPU_N_CPU_0_TSF3                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF3))
#define REG_CPU_N_CPU_1_TSF3                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF3))
#define REG_CPU_N_CPU_EXT_TSF3                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF3))

#define ADDR_CPU_N_CPU_TSF4                                  (0x16U)
#define A_CPU_N_CPU_TSF4(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF4)
#define R_CPU_N_CPU_TSF4(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF4(ba)))
#define RES_CPU_N_CPU_TSF4                                   (0x0U)
#define MSB_CPU_N_CPU_TSF4                                   0
#define LSB_CPU_N_CPU_TSF4                                   0
#define AADDR_CPU_N_CPU_0_TSF4                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF4)
#define AADDR_CPU_N_CPU_1_TSF4                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF4)
#define AADDR_CPU_N_CPU_EXT_TSF4                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF4)
#define REG_CPU_N_CPU_0_TSF4                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF4))
#define REG_CPU_N_CPU_1_TSF4                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF4))
#define REG_CPU_N_CPU_EXT_TSF4                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF4))

#define ADDR_CPU_N_CPU_TSF5                                  (0x18U)
#define A_CPU_N_CPU_TSF5(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF5)
#define R_CPU_N_CPU_TSF5(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF5(ba)))
#define RES_CPU_N_CPU_TSF5                                   (0x0U)
#define MSB_CPU_N_CPU_TSF5                                   0
#define LSB_CPU_N_CPU_TSF5                                   0
#define AADDR_CPU_N_CPU_0_TSF5                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF5)
#define AADDR_CPU_N_CPU_1_TSF5                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF5)
#define AADDR_CPU_N_CPU_EXT_TSF5                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF5)
#define REG_CPU_N_CPU_0_TSF5                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF5))
#define REG_CPU_N_CPU_1_TSF5                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF5))
#define REG_CPU_N_CPU_EXT_TSF5                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF5))

#define ADDR_CPU_N_CPU_TSF6                                  (0x1AU)
#define A_CPU_N_CPU_TSF6(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF6)
#define R_CPU_N_CPU_TSF6(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF6(ba)))
#define RES_CPU_N_CPU_TSF6                                   (0x0U)
#define MSB_CPU_N_CPU_TSF6                                   0
#define LSB_CPU_N_CPU_TSF6                                   0
#define AADDR_CPU_N_CPU_0_TSF6                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF6)
#define AADDR_CPU_N_CPU_1_TSF6                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF6)
#define AADDR_CPU_N_CPU_EXT_TSF6                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF6)
#define REG_CPU_N_CPU_0_TSF6                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF6))
#define REG_CPU_N_CPU_1_TSF6                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF6))
#define REG_CPU_N_CPU_EXT_TSF6                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF6))

#define ADDR_CPU_N_CPU_TSF7                                  (0x1CU)
#define A_CPU_N_CPU_TSF7(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF7)
#define R_CPU_N_CPU_TSF7(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF7(ba)))
#define RES_CPU_N_CPU_TSF7                                   (0x0U)
#define MSB_CPU_N_CPU_TSF7                                   0
#define LSB_CPU_N_CPU_TSF7                                   0
#define AADDR_CPU_N_CPU_0_TSF7                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF7)
#define AADDR_CPU_N_CPU_1_TSF7                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF7)
#define AADDR_CPU_N_CPU_EXT_TSF7                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF7)
#define REG_CPU_N_CPU_0_TSF7                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF7))
#define REG_CPU_N_CPU_1_TSF7                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF7))
#define REG_CPU_N_CPU_EXT_TSF7                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF7))

#define ADDR_CPU_N_CPU_TSF8                                  (0x1EU)
#define A_CPU_N_CPU_TSF8(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF8)
#define R_CPU_N_CPU_TSF8(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF8(ba)))
#define RES_CPU_N_CPU_TSF8                                   (0x0U)
#define MSB_CPU_N_CPU_TSF8                                   0
#define LSB_CPU_N_CPU_TSF8                                   0
#define AADDR_CPU_N_CPU_0_TSF8                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF8)
#define AADDR_CPU_N_CPU_1_TSF8                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF8)
#define AADDR_CPU_N_CPU_EXT_TSF8                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF8)
#define REG_CPU_N_CPU_0_TSF8                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF8))
#define REG_CPU_N_CPU_1_TSF8                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF8))
#define REG_CPU_N_CPU_EXT_TSF8                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF8))

#define ADDR_CPU_N_CPU_TSF9                                  (0x20U)
#define A_CPU_N_CPU_TSF9(ba)                                 ((ba) + ADDR_CPU_N_CPU_TSF9)
#define R_CPU_N_CPU_TSF9(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF9(ba)))
#define RES_CPU_N_CPU_TSF9                                   (0x0U)
#define MSB_CPU_N_CPU_TSF9                                   0
#define LSB_CPU_N_CPU_TSF9                                   0
#define AADDR_CPU_N_CPU_0_TSF9                               (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF9)
#define AADDR_CPU_N_CPU_1_TSF9                               (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF9)
#define AADDR_CPU_N_CPU_EXT_TSF9                             (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF9)
#define REG_CPU_N_CPU_0_TSF9                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF9))
#define REG_CPU_N_CPU_1_TSF9                                 (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF9))
#define REG_CPU_N_CPU_EXT_TSF9                               (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF9))

#define ADDR_CPU_N_CPU_TSF10                                 (0x22U)
#define A_CPU_N_CPU_TSF10(ba)                                ((ba) + ADDR_CPU_N_CPU_TSF10)
#define R_CPU_N_CPU_TSF10(ba)                                (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF10(ba)))
#define RES_CPU_N_CPU_TSF10                                  (0x0U)
#define MSB_CPU_N_CPU_TSF10                                  0
#define LSB_CPU_N_CPU_TSF10                                  0
#define AADDR_CPU_N_CPU_0_TSF10                              (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF10)
#define AADDR_CPU_N_CPU_1_TSF10                              (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF10)
#define AADDR_CPU_N_CPU_EXT_TSF10                            (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF10)
#define REG_CPU_N_CPU_0_TSF10                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF10))
#define REG_CPU_N_CPU_1_TSF10                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF10))
#define REG_CPU_N_CPU_EXT_TSF10                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF10))

#define ADDR_CPU_N_CPU_TSF11                                 (0x24U)
#define A_CPU_N_CPU_TSF11(ba)                                ((ba) + ADDR_CPU_N_CPU_TSF11)
#define R_CPU_N_CPU_TSF11(ba)                                (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF11(ba)))
#define RES_CPU_N_CPU_TSF11                                  (0x0U)
#define MSB_CPU_N_CPU_TSF11                                  0
#define LSB_CPU_N_CPU_TSF11                                  0
#define AADDR_CPU_N_CPU_0_TSF11                              (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF11)
#define AADDR_CPU_N_CPU_1_TSF11                              (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF11)
#define AADDR_CPU_N_CPU_EXT_TSF11                            (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF11)
#define REG_CPU_N_CPU_0_TSF11                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF11))
#define REG_CPU_N_CPU_1_TSF11                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF11))
#define REG_CPU_N_CPU_EXT_TSF11                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF11))

#define ADDR_CPU_N_CPU_TSF12                                 (0x26U)
#define A_CPU_N_CPU_TSF12(ba)                                ((ba) + ADDR_CPU_N_CPU_TSF12)
#define R_CPU_N_CPU_TSF12(ba)                                (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF12(ba)))
#define RES_CPU_N_CPU_TSF12                                  (0x0U)
#define MSB_CPU_N_CPU_TSF12                                  0
#define LSB_CPU_N_CPU_TSF12                                  0
#define AADDR_CPU_N_CPU_0_TSF12                              (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF12)
#define AADDR_CPU_N_CPU_1_TSF12                              (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF12)
#define AADDR_CPU_N_CPU_EXT_TSF12                            (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF12)
#define REG_CPU_N_CPU_0_TSF12                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF12))
#define REG_CPU_N_CPU_1_TSF12                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF12))
#define REG_CPU_N_CPU_EXT_TSF12                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF12))

#define ADDR_CPU_N_CPU_TSF13                                 (0x28U)
#define A_CPU_N_CPU_TSF13(ba)                                ((ba) + ADDR_CPU_N_CPU_TSF13)
#define R_CPU_N_CPU_TSF13(ba)                                (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF13(ba)))
#define RES_CPU_N_CPU_TSF13                                  (0x0U)
#define MSB_CPU_N_CPU_TSF13                                  0
#define LSB_CPU_N_CPU_TSF13                                  0
#define AADDR_CPU_N_CPU_0_TSF13                              (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF13)
#define AADDR_CPU_N_CPU_1_TSF13                              (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF13)
#define AADDR_CPU_N_CPU_EXT_TSF13                            (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF13)
#define REG_CPU_N_CPU_0_TSF13                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF13))
#define REG_CPU_N_CPU_1_TSF13                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF13))
#define REG_CPU_N_CPU_EXT_TSF13                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF13))

#define ADDR_CPU_N_CPU_TSF14                                 (0x2AU)
#define A_CPU_N_CPU_TSF14(ba)                                ((ba) + ADDR_CPU_N_CPU_TSF14)
#define R_CPU_N_CPU_TSF14(ba)                                (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF14(ba)))
#define RES_CPU_N_CPU_TSF14                                  (0x0U)
#define MSB_CPU_N_CPU_TSF14                                  0
#define LSB_CPU_N_CPU_TSF14                                  0
#define AADDR_CPU_N_CPU_0_TSF14                              (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF14)
#define AADDR_CPU_N_CPU_1_TSF14                              (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF14)
#define AADDR_CPU_N_CPU_EXT_TSF14                            (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF14)
#define REG_CPU_N_CPU_0_TSF14                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF14))
#define REG_CPU_N_CPU_1_TSF14                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF14))
#define REG_CPU_N_CPU_EXT_TSF14                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF14))

#define ADDR_CPU_N_CPU_TSF15                                 (0x2CU)
#define A_CPU_N_CPU_TSF15(ba)                                ((ba) + ADDR_CPU_N_CPU_TSF15)
#define R_CPU_N_CPU_TSF15(ba)                                (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TSF15(ba)))
#define RES_CPU_N_CPU_TSF15                                  (0x0U)
#define MSB_CPU_N_CPU_TSF15                                  0
#define LSB_CPU_N_CPU_TSF15                                  0
#define AADDR_CPU_N_CPU_0_TSF15                              (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TSF15)
#define AADDR_CPU_N_CPU_1_TSF15                              (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TSF15)
#define AADDR_CPU_N_CPU_EXT_TSF15                            (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TSF15)
#define REG_CPU_N_CPU_0_TSF15                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TSF15))
#define REG_CPU_N_CPU_1_TSF15                                (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TSF15))
#define REG_CPU_N_CPU_EXT_TSF15                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TSF15))

#define ADDR_CPU_N_CPU_TS_FLAGS                              (0x2EU)
#define A_CPU_N_CPU_TS_FLAGS(ba)                             ((ba) + ADDR_CPU_N_CPU_TS_FLAGS)
#define R_CPU_N_CPU_TS_FLAGS(ba)                             (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_TS_FLAGS(ba)))
#define RES_CPU_N_CPU_TS_FLAGS                               (0x0U)
#define MSB_CPU_N_CPU_TS_FLAGS                               15
#define LSB_CPU_N_CPU_TS_FLAGS                               0
#define AADDR_CPU_N_CPU_0_TS_FLAGS                           (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_TS_FLAGS)
#define AADDR_CPU_N_CPU_1_TS_FLAGS                           (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_TS_FLAGS)
#define AADDR_CPU_N_CPU_EXT_TS_FLAGS                         (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_TS_FLAGS)
#define REG_CPU_N_CPU_0_TS_FLAGS                             (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_TS_FLAGS))
#define REG_CPU_N_CPU_1_TS_FLAGS                             (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_TS_FLAGS))
#define REG_CPU_N_CPU_EXT_TS_FLAGS                           (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_TS_FLAGS))

#define ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR                      (0x30U)
#define A_CPU_N_CPU_IRQFLAGS_SET_CLR(ba)                     ((ba) + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR)
#define R_CPU_N_CPU_IRQFLAGS_SET_CLR(ba)                     (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_IRQFLAGS_SET_CLR(ba)))
#define RES_CPU_N_CPU_IRQFLAGS_SET_CLR                       (0x0U)
#define MSB_CPU_N_CPU_IRQFLAGS_SET_CLR                       12
#define LSB_CPU_N_CPU_IRQFLAGS_SET_CLR                       0
#define AADDR_CPU_N_CPU_0_IRQFLAGS_SET_CLR                   (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR)
#define AADDR_CPU_N_CPU_1_IRQFLAGS_SET_CLR                   (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR)
#define AADDR_CPU_N_CPU_EXT_IRQFLAGS_SET_CLR                 (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR)
#define REG_CPU_N_CPU_0_IRQFLAGS_SET_CLR                     (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_IRQFLAGS_SET_CLR))
#define REG_CPU_N_CPU_1_IRQFLAGS_SET_CLR                     (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_IRQFLAGS_SET_CLR))
#define REG_CPU_N_CPU_EXT_IRQFLAGS_SET_CLR                   (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_IRQFLAGS_SET_CLR))

#define ADDR_CPU_N_CPU_IRQ_STATUS0                           (0x32U)
#define A_CPU_N_CPU_IRQ_STATUS0(ba)                          ((ba) + ADDR_CPU_N_CPU_IRQ_STATUS0)
#define R_CPU_N_CPU_IRQ_STATUS0(ba)                          (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_IRQ_STATUS0(ba)))
#define RES_CPU_N_CPU_IRQ_STATUS0                            (0x0U)
#define MSB_CPU_N_CPU_IRQ_STATUS0                            15
#define LSB_CPU_N_CPU_IRQ_STATUS0                            0
#define AADDR_CPU_N_CPU_0_IRQ_STATUS0                        (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_IRQ_STATUS0)
#define AADDR_CPU_N_CPU_1_IRQ_STATUS0                        (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_IRQ_STATUS0)
#define AADDR_CPU_N_CPU_EXT_IRQ_STATUS0                      (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_IRQ_STATUS0)
#define REG_CPU_N_CPU_0_IRQ_STATUS0                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_IRQ_STATUS0))
#define REG_CPU_N_CPU_1_IRQ_STATUS0                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_IRQ_STATUS0))
#define REG_CPU_N_CPU_EXT_IRQ_STATUS0                        (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_IRQ_STATUS0))

#define ADDR_CPU_N_CPU_IRQ_STATUS1                           (0x34U)
#define A_CPU_N_CPU_IRQ_STATUS1(ba)                          ((ba) + ADDR_CPU_N_CPU_IRQ_STATUS1)
#define R_CPU_N_CPU_IRQ_STATUS1(ba)                          (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_IRQ_STATUS1(ba)))
#define RES_CPU_N_CPU_IRQ_STATUS1                            (0xffffU)
#define MSB_CPU_N_CPU_IRQ_STATUS1                            15
#define LSB_CPU_N_CPU_IRQ_STATUS1                            0
#define AADDR_CPU_N_CPU_0_IRQ_STATUS1                        (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_IRQ_STATUS1)
#define AADDR_CPU_N_CPU_1_IRQ_STATUS1                        (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_IRQ_STATUS1)
#define AADDR_CPU_N_CPU_EXT_IRQ_STATUS1                      (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_IRQ_STATUS1)
#define REG_CPU_N_CPU_0_IRQ_STATUS1                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_IRQ_STATUS1))
#define REG_CPU_N_CPU_1_IRQ_STATUS1                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_IRQ_STATUS1))
#define REG_CPU_N_CPU_EXT_IRQ_STATUS1                        (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_IRQ_STATUS1))

#define ADDR_CPU_N_CPU_IRQ_MASK0                             (0x36U)
#define A_CPU_N_CPU_IRQ_MASK0(ba)                            ((ba) + ADDR_CPU_N_CPU_IRQ_MASK0)
#define R_CPU_N_CPU_IRQ_MASK0(ba)                            (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_IRQ_MASK0(ba)))
#define RES_CPU_N_CPU_IRQ_MASK0                              (0x0U)
#define MSB_CPU_N_CPU_IRQ_MASK0                              15
#define LSB_CPU_N_CPU_IRQ_MASK0                              0
#define AADDR_CPU_N_CPU_0_IRQ_MASK0                          (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_IRQ_MASK0)
#define AADDR_CPU_N_CPU_1_IRQ_MASK0                          (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_IRQ_MASK0)
#define AADDR_CPU_N_CPU_EXT_IRQ_MASK0                        (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_IRQ_MASK0)
#define REG_CPU_N_CPU_0_IRQ_MASK0                            (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_IRQ_MASK0))
#define REG_CPU_N_CPU_1_IRQ_MASK0                            (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_IRQ_MASK0))
#define REG_CPU_N_CPU_EXT_IRQ_MASK0                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_IRQ_MASK0))

#define ADDR_CPU_N_CPU_IRQ_MASK1                             (0x38U)
#define A_CPU_N_CPU_IRQ_MASK1(ba)                            ((ba) + ADDR_CPU_N_CPU_IRQ_MASK1)
#define R_CPU_N_CPU_IRQ_MASK1(ba)                            (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_IRQ_MASK1(ba)))
#define RES_CPU_N_CPU_IRQ_MASK1                              (0x0U)
#define MSB_CPU_N_CPU_IRQ_MASK1                              15
#define LSB_CPU_N_CPU_IRQ_MASK1                              0
#define AADDR_CPU_N_CPU_0_IRQ_MASK1                          (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_IRQ_MASK1)
#define AADDR_CPU_N_CPU_1_IRQ_MASK1                          (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_IRQ_MASK1)
#define AADDR_CPU_N_CPU_EXT_IRQ_MASK1                        (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_IRQ_MASK1)
#define REG_CPU_N_CPU_0_IRQ_MASK1                            (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_IRQ_MASK1))
#define REG_CPU_N_CPU_1_IRQ_MASK1                            (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_IRQ_MASK1))
#define REG_CPU_N_CPU_EXT_IRQ_MASK1                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_IRQ_MASK1))

#define ADDR_CPU_N_CPU_IRQ_VENABLE                           (0x3AU)
#define A_CPU_N_CPU_IRQ_VENABLE(ba)                          ((ba) + ADDR_CPU_N_CPU_IRQ_VENABLE)
#define R_CPU_N_CPU_IRQ_VENABLE(ba)                          (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_IRQ_VENABLE(ba)))
#define RES_CPU_N_CPU_IRQ_VENABLE                            (0x0U)
#define MSB_CPU_N_CPU_IRQ_VENABLE                            4
#define LSB_CPU_N_CPU_IRQ_VENABLE                            0
#define AADDR_CPU_N_CPU_0_IRQ_VENABLE                        (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_IRQ_VENABLE)
#define AADDR_CPU_N_CPU_1_IRQ_VENABLE                        (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_IRQ_VENABLE)
#define AADDR_CPU_N_CPU_EXT_IRQ_VENABLE                      (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_IRQ_VENABLE)
#define REG_CPU_N_CPU_0_IRQ_VENABLE                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_IRQ_VENABLE))
#define REG_CPU_N_CPU_1_IRQ_VENABLE                          (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_IRQ_VENABLE))
#define REG_CPU_N_CPU_EXT_IRQ_VENABLE                        (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_IRQ_VENABLE))

#define ADDR_CPU_N_CPU_IRQ_VDISABLE                          (0x3CU)
#define A_CPU_N_CPU_IRQ_VDISABLE(ba)                         ((ba) + ADDR_CPU_N_CPU_IRQ_VDISABLE)
#define R_CPU_N_CPU_IRQ_VDISABLE(ba)                         (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_IRQ_VDISABLE(ba)))
#define RES_CPU_N_CPU_IRQ_VDISABLE                           (0x0U)
#define MSB_CPU_N_CPU_IRQ_VDISABLE                           4
#define LSB_CPU_N_CPU_IRQ_VDISABLE                           0
#define AADDR_CPU_N_CPU_0_IRQ_VDISABLE                       (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_IRQ_VDISABLE)
#define AADDR_CPU_N_CPU_1_IRQ_VDISABLE                       (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_IRQ_VDISABLE)
#define AADDR_CPU_N_CPU_EXT_IRQ_VDISABLE                     (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_IRQ_VDISABLE)
#define REG_CPU_N_CPU_0_IRQ_VDISABLE                         (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_IRQ_VDISABLE))
#define REG_CPU_N_CPU_1_IRQ_VDISABLE                         (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_IRQ_VDISABLE))
#define REG_CPU_N_CPU_EXT_IRQ_VDISABLE                       (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_IRQ_VDISABLE))

#define ADDR_CPU_N_CPU_IRQ_VMAX                              (0x3EU)
#define A_CPU_N_CPU_IRQ_VMAX(ba)                             ((ba) + ADDR_CPU_N_CPU_IRQ_VMAX)
#define R_CPU_N_CPU_IRQ_VMAX(ba)                             (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_IRQ_VMAX(ba)))
#define RES_CPU_N_CPU_IRQ_VMAX                               (0x20U)
#define MSB_CPU_N_CPU_IRQ_VMAX                               5
#define LSB_CPU_N_CPU_IRQ_VMAX                               0
#define AADDR_CPU_N_CPU_0_IRQ_VMAX                           (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_IRQ_VMAX)
#define AADDR_CPU_N_CPU_1_IRQ_VMAX                           (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_IRQ_VMAX)
#define AADDR_CPU_N_CPU_EXT_IRQ_VMAX                         (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_IRQ_VMAX)
#define REG_CPU_N_CPU_0_IRQ_VMAX                             (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_IRQ_VMAX))
#define REG_CPU_N_CPU_1_IRQ_VMAX                             (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_IRQ_VMAX))
#define REG_CPU_N_CPU_EXT_IRQ_VMAX                           (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_IRQ_VMAX))

#define ADDR_CPU_N_CPU_IRQ_VNO                               (0x40U)
#define A_CPU_N_CPU_IRQ_VNO(ba)                              ((ba) + ADDR_CPU_N_CPU_IRQ_VNO)
#define R_CPU_N_CPU_IRQ_VNO(ba)                              (*(volatile unsigned short *)((unsigned int)A_CPU_N_CPU_IRQ_VNO(ba)))
#define RES_CPU_N_CPU_IRQ_VNO                                (0x20U)
#define MSB_CPU_N_CPU_IRQ_VNO                                5
#define LSB_CPU_N_CPU_IRQ_VNO                                0
#define AADDR_CPU_N_CPU_0_IRQ_VNO                            (BASE_ADDR_CPU_N_CPU_0 + ADDR_CPU_N_CPU_IRQ_VNO)
#define AADDR_CPU_N_CPU_1_IRQ_VNO                            (BASE_ADDR_CPU_N_CPU_1 + ADDR_CPU_N_CPU_IRQ_VNO)
#define AADDR_CPU_N_CPU_EXT_IRQ_VNO                          (BASE_ADDR_CPU_N_CPU_EXT + ADDR_CPU_N_CPU_IRQ_VNO)
#define REG_CPU_N_CPU_0_IRQ_VNO                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_0_IRQ_VNO))
#define REG_CPU_N_CPU_1_IRQ_VNO                              (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_1_IRQ_VNO))
#define REG_CPU_N_CPU_EXT_IRQ_VNO                            (*(volatile unsigned short *)((unsigned int)AADDR_CPU_N_CPU_EXT_IRQ_VNO))




#endif
