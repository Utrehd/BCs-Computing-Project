/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         i2c_api_errors.h
*
* @brief        Error handler for I2C API functions
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

/**
 * \ingroup error_api
 */

#ifndef __I2C_API_ERRORS__
#define __I2C_API_ERRORS__

#define I2C_API_ERRORS_CODES                                                  \
  /**                                                                          \
   * I2C error                                                                 \
   */                                                                          \
  eError_i2c_api_error
#endif
