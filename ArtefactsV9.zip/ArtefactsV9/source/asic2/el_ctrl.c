/* FPGA Release: 10512 */
#include "el_ctrl.h"

//==========================================================================
// TIA
//==========================================================================
void el_ctrl_tia_config(
  el_ctrl_tia_power_t tia_power_mode, 
  uint8_t             tia_cfg_hyst){
  el_ctrl_tia_cfg_t el_ctrl_tia_cfg;
  el_ctrl_tia_cfg.val = 0;
  el_ctrl_tia_cfg.bf.tia_power_mode = (uint8_t) tia_power_mode;
  el_ctrl_tia_cfg.bf.tia_cfg_hyst   = tia_cfg_hyst;
  WRITE_REG_16(AADDR_EL_CTRL_TIA_CFG, el_ctrl_tia_cfg.val);
}

//==========================================================================
// Cycle Control
//==========================================================================
void el_ctrl_cyc_enable(bool cyc_en){
  WRITE_REG_16(AADDR_EL_CTRL_CYC_CFG, cyc_en);
}

void el_ctrl_set_cyc_len(uint16_t cyc_len){
  WRITE_REG_16(AADDR_EL_CTRL_CYC_LEN, cyc_len);
}

uint16_t el_ctrl_get_cyc_len(void){
  return READ_REG_U16(AADDR_EL_CTRL_CYC_LEN);
}

void el_ctrl_set_cyc_tx_start(uint16_t cyc_tx_start){
  WRITE_REG_16(AADDR_EL_CTRL_CYC_TX_START, cyc_tx_start);
}

//==========================================================================
// Meas Control
//==========================================================================
void el_ctrl_meas_enable(bool meas_en){
  el_ctrl_meas_cfg_t el_ctrl_meas_cfg;
  el_ctrl_meas_cfg.val = READ_REG_U16(AADDR_EL_CTRL_MEAS_CFG);
  el_ctrl_meas_cfg.bf.en = meas_en;
  WRITE_REG_16(AADDR_EL_CTRL_MEAS_CFG, el_ctrl_meas_cfg.val);
}

void el_ctrl_set_meas_zero_level(uint8_t meas_zero_level){
  el_ctrl_meas_cfg_t el_ctrl_meas_cfg;
  el_ctrl_meas_cfg.val = READ_REG_U16(AADDR_EL_CTRL_MEAS_CFG);
  el_ctrl_meas_cfg.bf.zero_level = meas_zero_level;
  WRITE_REG_16(AADDR_EL_CTRL_MEAS_CFG, el_ctrl_meas_cfg.val);
}

void el_ctrl_set_meas_intf_rise_fall(uint16_t rise, uint16_t fall){
  WRITE_REG_16(AADDR_EL_CTRL_MEAS_INTF_COEF_RISE, rise);
  WRITE_REG_16(AADDR_EL_CTRL_MEAS_INTF_COEF_FALL, fall);
}

uint32_t el_ctrl_get_meas_cyc_len(void){
  uint32_t temp = READ_REG_U16(AADDR_EL_CTRL_MEAS_CYC_HW);
  temp <<= 16;
  temp |= READ_REG_U16(AADDR_EL_CTRL_MEAS_CYC_LW);
  return temp;
}

uint32_t el_ctrl_get_meas_pre_len(void){
  uint32_t temp = READ_REG_U16(AADDR_EL_CTRL_MEAS_PRE_HW);
  temp <<= 16;
  temp |= READ_REG_U16(AADDR_EL_CTRL_MEAS_PRE_LW);
  return temp;
}

uint16_t el_ctrl_get_meas_br_min(void){
  return READ_REG_U16(AADDR_EL_CTRL_MEAS_BR_MIN);
}

//==========================================================================
// TX Control
//==========================================================================
void el_ctrl_set_tx_trigger(el_ctrl_tx_trigger_t tx_trigger){
  el_ctrl_tx_cfg_t el_ctrl_tx_cfg;
  el_ctrl_tx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_TX_CFG);
  el_ctrl_tx_cfg.bf.trigger = tx_trigger;
  WRITE_REG_16(AADDR_EL_CTRL_TX_CFG, el_ctrl_tx_cfg.val);
}

void el_ctrl_set_tx_use_nrz(bool tx_use_nrz){
  el_ctrl_tx_cfg_t el_ctrl_tx_cfg;
  el_ctrl_tx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_TX_CFG);
  el_ctrl_tx_cfg.bf.nrz = tx_use_nrz;
  WRITE_REG_16(AADDR_EL_CTRL_TX_CFG, el_ctrl_tx_cfg.val);
}

void el_ctrl_set_tx_zero_level(uint8_t tx_zero_level){
  el_ctrl_tx_cfg_t el_ctrl_tx_cfg;
  el_ctrl_tx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_TX_CFG);
  el_ctrl_tx_cfg.bf.zero_level = tx_zero_level;
  WRITE_REG_16(AADDR_EL_CTRL_TX_CFG, el_ctrl_tx_cfg.val);
}

void el_ctrl_set_tx_rx2tx_level(uint8_t tx_rx2tx_level){
  el_ctrl_tx_cfg_t el_ctrl_tx_cfg;
  el_ctrl_tx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_TX_CFG);
  el_ctrl_tx_cfg.bf.rx2tx_level = tx_rx2tx_level;
  WRITE_REG_16(AADDR_EL_CTRL_TX_CFG, el_ctrl_tx_cfg.val);
}

void el_ctrl_set_tx_pst_level(uint8_t tx_pst_level){
  el_ctrl_tx_cfg_t el_ctrl_tx_cfg;
  el_ctrl_tx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_TX_CFG);
  el_ctrl_tx_cfg.bf.pst_level = tx_pst_level;
  WRITE_REG_16(AADDR_EL_CTRL_TX_CFG, el_ctrl_tx_cfg.val);
}

void el_ctrl_set_tx_preamble_length(uint8_t tx_preamble_length){
  el_ctrl_tx_cfg_t el_ctrl_tx_cfg;
  el_ctrl_tx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_TX_CFG);
  el_ctrl_tx_cfg.bf.preamble_length = tx_preamble_length;
  WRITE_REG_16(AADDR_EL_CTRL_TX_CFG, el_ctrl_tx_cfg.val);
}

void el_ctrl_set_tx_gpo_ignore(bool tx_gpo_ignore){
  el_ctrl_tx_cfg_t el_ctrl_tx_cfg;
  el_ctrl_tx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_TX_CFG);
  el_ctrl_tx_cfg.bf.gpo_ignore = tx_gpo_ignore;
  WRITE_REG_16(AADDR_EL_CTRL_TX_CFG, el_ctrl_tx_cfg.val);
}

void el_ctrl_set_tx_always_pre(bool tx_always_pre){
  el_ctrl_tx_cfg_t el_ctrl_tx_cfg;
  el_ctrl_tx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_TX_CFG);
  el_ctrl_tx_cfg.bf.always_pre = tx_always_pre;
  WRITE_REG_16(AADDR_EL_CTRL_TX_CFG, el_ctrl_tx_cfg.val);
}

void el_ctrl_tx_pat_enable(bool tx_pat_enable){
  el_ctrl_tx_cfg_t el_ctrl_tx_cfg;
  el_ctrl_tx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_TX_CFG);
  el_ctrl_tx_cfg.bf.pat_en = tx_pat_enable;
  WRITE_REG_16(AADDR_EL_CTRL_TX_CFG, el_ctrl_tx_cfg.val);
}

void el_ctrl_set_tx_led_on_pattern(uint8_t tx_led_on_pattern){
  WRITE_REG_16(AADDR_EL_CTRL_TX_LED_ON_PATTERN, tx_led_on_pattern);
}

// in clock cycles
void el_ctrl_set_tx_half_bit_length(uint32_t tx_half_bit_length){
  WRITE_REG_16(AADDR_EL_CTRL_TX_BR_LW, tx_half_bit_length);
  tx_half_bit_length  >>= 16;
  WRITE_REG_16(AADDR_EL_CTRL_TX_BR_HW, tx_half_bit_length);
}

void el_ctrl_set_tx_max_bytes(uint8_t tx_max_bytes){
  WRITE_REG_16(AADDR_EL_CTRL_TX_LEN, tx_max_bytes);
}

//==========================================================================
// RX Control
//==========================================================================
void el_ctrl_rx_enable(bool rx_enable){
  el_ctrl_rx_cfg_t el_ctrl_rx_cfg;
  el_ctrl_rx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_RX_CFG);
  el_ctrl_rx_cfg.bf.en = rx_enable;
  WRITE_REG_16(AADDR_EL_CTRL_RX_CFG, el_ctrl_rx_cfg.val);
}

void el_ctrl_set_rx_zero_level(uint8_t rx_zero_level){
  el_ctrl_rx_cfg_t el_ctrl_rx_cfg;
  el_ctrl_rx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_RX_CFG);
  el_ctrl_rx_cfg.bf.zero_level = rx_zero_level;
  WRITE_REG_16(AADDR_EL_CTRL_RX_CFG, el_ctrl_rx_cfg.val);
}

// in bits
void el_ctrl_set_rx_pre0_phase_length(uint8_t rx_pre0_phase_length){
  el_ctrl_rx_cfg_t el_ctrl_rx_cfg;
  el_ctrl_rx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_RX_CFG);
  el_ctrl_rx_cfg.bf.pre0_length = rx_pre0_phase_length;
  WRITE_REG_16(AADDR_EL_CTRL_RX_CFG, el_ctrl_rx_cfg.val);
}

void el_ctrl_set_rx_pre1_phase_length(uint8_t rx_pre1_phase_length){
  el_ctrl_rx_cfg_t el_ctrl_rx_cfg;
  el_ctrl_rx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_RX_CFG);
  el_ctrl_rx_cfg.bf.pre1_length = rx_pre1_phase_length;
  WRITE_REG_16(AADDR_EL_CTRL_RX_CFG, el_ctrl_rx_cfg.val);
}

void el_ctrl_set_rx_min_preamble_length(uint8_t rx_min_preamble_length){
  el_ctrl_rx_cfg_t el_ctrl_rx_cfg;
  el_ctrl_rx_cfg.val = READ_REG_U16(AADDR_EL_CTRL_RX_CFG);
  el_ctrl_rx_cfg.bf.min_preamble_len = rx_min_preamble_length;
  WRITE_REG_16(AADDR_EL_CTRL_RX_CFG, el_ctrl_rx_cfg.val);
}

// in clock cycles
void el_ctrl_set_rx_intf_threshold(uint8_t rx_intf_threshold){
  WRITE_REG_16(AADDR_EL_CTRL_RX_INTF_THR, rx_intf_threshold);
}

// in clock cycles
void el_ctrl_set_rx_bit_length(uint16_t rx_bit_length){
  WRITE_REG_16(AADDR_EL_CTRL_RX_BR, rx_bit_length);
}

//==========================================================================
// Data Fifos
//==========================================================================
static bool el_ctrl_sof_flag;

void el_ctrl_clear_tx_fifo(void){
  WRITE_REG_16(AADDR_EL_CTRL_TX_FIFO, BIT_EL_CTRL_TX_FIFO_CLEAR);
}

bool el_ctrl_tx_fifo_full(void){
  el_ctrl_irq_status_t el_ctrl_irq_status = el_ctrl_get_irq_status();
  return el_ctrl_irq_status.bf.tx_full ? true : false;
}

// non blocking
void el_ctrl_send_byte_nb(uint8_t tx_data){
  WRITE_REG_16(AADDR_EL_CTRL_TX_FIFO, tx_data);
}

void el_ctrl_send_byte(uint8_t tx_data){
  while(el_ctrl_tx_fifo_full());
  el_ctrl_send_byte_nb(tx_data);
}


void el_ctrl_clear_rx_fifo(void){
  WRITE_REG_16(AADDR_EL_CTRL_RX_FIFO, BIT_EL_CTRL_RX_FIFO_CLEAR);
}

bool el_ctrl_rx_fifo_empty(void){
  el_ctrl_irq_status_t el_ctrl_irq_status = el_ctrl_get_irq_status();
  return el_ctrl_irq_status.bf.rx_empty ? true : false;
}

// non blocking
uint8_t el_ctrl_recv_byte_nb(void){
  el_ctrl_rx_fifo_t el_ctrl_rx_fifo;
  el_ctrl_rx_fifo.val = READ_REG_U16(AADDR_EL_CTRL_RX_FIFO);
  el_ctrl_sof_flag    = el_ctrl_rx_fifo.bf.sof ? true : false;
  return el_ctrl_rx_fifo.bf.data;
}

uint8_t el_ctrl_recv_byte(void){
  while(el_ctrl_rx_fifo_empty());
  return el_ctrl_recv_byte_nb();
}

bool el_ctrl_was_sof_flag(void){
  return el_ctrl_sof_flag;
}

//==========================================================================
// Status
//==========================================================================

el_ctrl_state_t el_ctrl_get_state(void){
  return (el_ctrl_state_t) READ_REG_U16(AADDR_EL_CTRL_STATUS);
}

//==========================================================================
// IRQs
//==========================================================================

void el_ctrl_enable_irq(el_ctrl_irq_t irq, bool enable){  
  if (enable) WRITE_REG_16(AADDR_EL_CTRL_IRQ_VENABLE,  irq);
  else        WRITE_REG_16(AADDR_EL_CTRL_IRQ_VDISABLE, irq);
}

el_ctrl_irq_status_t el_ctrl_get_irq_status(void){
  el_ctrl_irq_status_t status;
  status.val = READ_REG_U16(AADDR_EL_CTRL_IRQ_STATUS);
  return status;
}

void el_ctrl_clear_all_irqs(void){
  WRITE_REG_16(AADDR_EL_CTRL_IRQ_STATUS, 0xFFFF);
}

void el_ctrl_clear_irqs_vno(uint16_t vno){
  WRITE_REG_16(AADDR_EL_CTRL_IRQ_VNO, vno);
}

el_ctrl_irq_t el_ctrl_get_pending_irq(void){
    return (el_ctrl_irq_t) READ_REG_U16(AADDR_EL_CTRL_IRQ_VNO);
}
