/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2018 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         i2c_api.h
*
* @brief        I2C API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __I2C_API__
#define __I2C_API__

/**
 * \example example_i2c_api_master.c
 * This is an example of how to use USI SPI block.
 */


/**
 * \defgroup i2c_api ASIC2 I2C API functions
 * 
 * \ingroup  i2c   asic2_api
 *
 * \brief    API function to control I2C
 *
 * \details How to use it - see code example: @include example_i2c_api_master.c
 *
 */


/**
 * \defgroup i2c_api_master ASIC2 I2C Master Interface
 *
 * \brief    API function to control I2C
 * 
 * \ingroup  i2c_api
 *
 * \details How to use it - see code example: @include example_i2c_api_master.c
 *
 */

#include "errors_api.h"

   
/* ############################################################################ */
/**
 * \brief  Initialize I2C
 *
 * \ingroup i2c_api 
 *
 * \param i2c_freq Desired frequency value in Hertz for I2C communication
 */
void i2c_api_init(uint32_t i2c_freq);

/* ############################################################################ */
/**
 * \brief  Write array of data to I2C device (handshake, blocking)
 *
 * \ingroup i2c_api_master
 *
 * \param device_address Device I2C original address
 *
 * \param data Array containing the desired data to write into the I2C device
 *
 * \param data_size Number of bytes to write into the I2C device
 */
void i2c_api_master_write_data(uint8_t device_address, uint8_t *data, uint16_t data_size);

/* ############################################################################ */
/**
 * \brief  Read array of data from I2C device (handshake, blocking)
 *
 * \ingroup i2c_api_master
 *
 * \param device_address Device I2C original address
 *
 * \param data Array containing the read data from the I2C device
 *
 * \param data_size Number of bytes to read from the I2C device
 */
void i2c_api_master_read_data(uint8_t device_address, uint8_t *data, uint16_t data_size);


/* ############################################################################ */
/**
 * \brief  Write array of data to I2C device (interrupt, non-blocking)
 *
 * \ingroup i2c_api_master
 *
 * \param device_address Device I2C original address
 *
 * \param data Array containing the desired data to write into the I2C device
 *
 * \param data_size Number of bytes to write into the I2C device
 */
void i2c_api_master_write_data_irq(uint8_t device_address, uint8_t *data, uint16_t data_size);

/* ############################################################################ */
/**
 * \brief   Get flag to know if I2C Command are sending (Command sending have not finished)
 *
 * \ingroup i2c_api_master
 *
 * \return  data are sending
 */
bool i2c_api_master_cmd_data_busy_get(void);

/* ########################################################################## */    
/**
 * \brief  Read array of data from I2C device (interrupt, non-blocking)
 *
 * \ingroup i2c_api_master
 *
 * \param device_address Device I2C original address
 *
 * \param data Array containing the read data from the I2C device
 *
 * \param data_size Number of bytes to read from the I2C device
 */
void i2c_api_master_read_data_irq(uint8_t device_address, uint16_t data_size);

/* ########################################################################## */    
/**
 * \brief  Clear interrupt error flags
 *
 * \ingroup i2c_api
 */
void i2c_api_error_clr(void);

/* ########################################################################## */    
/**
 * \brief  Get interrupt error flags
 *
 * \ingroup i2c_api
 */    
errors_api_code_e i2c_api_error_get(void);


/* ############################################################################ */
/* ############################ INTERRUPT CONFIGURATION ####################### */
/* ############################################################################ */

/* ########################################################################## */    
/**
 * \brief  Enable and Set interrupt I2C priority, prepare buffers for I2C 
 *         commands and data
 *
 * \ingroup i2c_api
 *
 * \param par_usi_nvic_priority I2C interrupt priority
 *
 * \param pnuReadData buffer for read data
 *
 * \param pnuCmdData  buffer for command data
 *
 */  
void i2c_api_init_irq(uint8_t par_usi_nvic_priority, uint8_t *pnuReadData, uint8_t nuReadDataSize, uint16_t *pnuCmdData, uint8_t nuCmdDataSize);

/* ########################################################################## */    
/**
 * \brief  Register callback function which is called when all requested data have been read
 *
 * \ingroup i2c_api_master
 *
 * \param p_fce_callback_read_done pointer to function which is called when data are received
 *
 */  
void i2c_api_master_read_done_reg_callback(void (*p_fce_callback_read_done)(void));

#endif