#ifndef __TEST_USI_SPI_DMA_H__
#define __TEST_USI_SPI_DMA_H__

#include <stdio.h>

/** \defgroup usi_spi_dma DMA Function to control SPI(USI) with DMA
 *
 *  \ingroup  usi_spi   asic2_api
 *
 *  \brief    DMA SPI Control functions
 *
 *
 * In case of SPI slave see timing diagram on 
 * <a href="http://wavedrom.com/editor.html?%7B%20signal%3A%20%5B%0A%20%20%0A%20%20%7B%20name%3A%20%22clk%22%2C%20%20wave%3A%20%22h..lhlhlhlhlhlhlhlh..........lhlhlhlhlhlhlhlh............%22%20%7D%2C%0A%20%20%7B%20name%3A%20%22sdi%2Fsdo%22%2C%20%20wave%3A%20%22x..5...............x.........5...............x...........%22%2C%20data%3A%20%5B%22data0%22%2C%20%22data1%22%5D%20%7D%2C%0A%20%20%7B%20name%3A%20%22USI_IRQ_RADR_DONE_NEMPTY%22%2C%20wave%3A%20%220..................10........................10..........%22%20%7D%2C%0A%20%20%7B%20name%3A%20%22SCK_TIMEOUT_CNT%22%2C%20wave%3A%20%220..................33333330..................33333330....%22%20%2C%20data%3A%20%5B%226%22%2C%20%225%22%2C%20%224%22%2C%20%223%22%2C%20%222%22%2C%20%221%22%2C%20%220%22%2C%226%22%2C%20%225%22%2C%20%224%22%2C%20%223%22%2C%20%222%22%2C%20%221%22%2C%20%220%22%5D%20%7D%2C%0A%20%20%7B%20name%3A%20%22USI_IRQ_SCK_TIMEOUT%22%2C%20wave%3A%20%220........................10........................10....%22%20%7D%2C%0A%20%20%0A%20%20%7B%20name%3A%20%22USI%20needs%20new%20pointer%22%2C%20wave%3A%20%220.........................3..0......................3..0.%22%20%7D%2C%0A%20%20%0A%5D%7D%0A">SPI SLAVE USI</a>
 * where is described how this USI SPI slave works in USI_DMA_MODE_LENGTH mode.
 *
 * According this diagram you should update new pointer to DMA FIFO after SCK_TIMEOUT interrupt is received.
 */
/**@{*/    

/**




\verbatim
  HOW TO USE IT:

1/ Make pad interconnection: io_ctrl_config_sel(IOMUX_PADy, IO_USIx)
2/ init: usi_spi_slave_init(USI0, DATA_FRAME_8B, true, true, true, true);
3/ register callbacks: usi_spi_slave_reg_callback(USI0, 9, usi_rcv_data, usi_error);
4/ send/recv data usi_spi_slave_frame(USI0, 6, p_spi_snd, p_spi_rcv);
5/ implement callbacks:

  void usi_rcv_data(void) {
    / Prepare data for next transfer /
    usi_spi_slave_frame(USI0, 6, p_spi_snd, p_spi_rcv);
  }
 
  void usi_error(void) {
    / ERROR /
  }
\endverbatim
  *
  */




/* ########################################################################## */  
/// Number of bits in one SPI frame
typedef enum {
  DATA_FRAME_8B, ///< 8bits is SPI frame
  DATA_FRAME_16B, ///< 16bits is SPI frame
} usi_spi_data_length_t;

/* ########################################################################## */    
/*
 * This interrupt subroutine is called by NVIC in case of SPI
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 */
void usi_spi_dma_interrupt_subroutine(usi_num_t usi_no );
  

/* ########################################################################## */  
/**
 * Function to setup USI.SPI baudrate
 * acc = (acc + BR_INC) % BR_MOD generates ticks
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_br_mod      bit rate generation: modulus [comm_clk]
 *
 * \param par_br_inc      bit rate generation: increment [comm_clk]
 *
 * \param par_bit_length  half bit length [ticks] 
 */
void usi_spi_dma_baudrate(const usi_num_t usi_no, uint16_t par_br_mod, uint16_t par_br_inc, uint8_t par_bit_length); 

/* ########################################################################## */  
/**
 * Function to setup CLOCKs for USI and release reset
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 * 
 * \param par_as_clock_source AS clock source (communication clock domain)
 *
 * \param par_div divider on AS clock
 *
 */
void usi_spi_dma_clock(const usi_num_t usi_no, clock_source_t par_as_clock_source, uint8_t par_div);

/* ########################################################################## */  
/**
 * Function to setup USI as SPI in DMA mode. 
 * Callback is run when End of Transfer is triggered 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param i_slave_nmaster TRUE - SLAVE
 *                        FALSE - MASTER (is not implemented)
 * 
 * \param par_bit_data_length 8/16
 *
 * \param par_phase       0: 1st edge shift, 2nd edge sample    / 1: 1st edge sample, 2nd edge shift
 *
 * \param par_polarity    polarity - 0: clock off level 0       / 1: clock off level 1
 *
 * \param par_msb_first   msb_first: 0: LSB transmitted first   / 1: MSB transmitted first
 *
 * \param par_nss_mode    TRUE: Nss ignored. Only sck can start SPI frame. Only sck_timeout can end SPI frame (see CFG_SPI_SCK_TIMEOUT)
 */
void usi_spi_dma_init(const usi_num_t usi_no, const bool i_slave_nmaster, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode);

/* ########################################################################## */  
/**
 * Prepare data for USI/SPI 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_number_of_data 1..255
 *
 * \param par_p_snd_data pointer to send data
 *
 * \param par_p_rcv_data pointer to receive data
 */
void usi_spi_dma_frame(usi_num_t usi_no, uint8_t par_number_of_data, void * par_p_snd_data, void * par_p_rcv_data);
 
/* ########################################################################## */  
/**
 * DUMMY - SLAVE does not known baudrates
 */
void usi_spi_dma_slave_baudrate(uint16_t par_br_mod, uint16_t par_br_inc, uint8_t par_bit_length);

/* ########################################################################## */  
/**
 * Wrapper for usi_spi_dma_clock() + usi_spi_dma_init()
 * 
 * \see usi_spi_dma_clock()
 * \see usi_spi_dma_init() 
 *
 * Function to setup USI as SPI in SLAVE - DMA mode. It sets USI clock
 * Callback is run when End of Transfer is triggered 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_as_clock_source AS clock source (communication clock domain)
 *
 * \param par_div divider on AS clock
 *
 * \param par_bit_data_length 8/16
 *
 * \param par_phase       0: 1st edge shift, 2nd edge sample, [CPHA=1]<br>
 *                        1: 1st edge sample, 2nd edge shift, [CPHA=0]<br>
 *
 * \param par_polarity    0: clock off level 0, [CPOL=0]<br>
 *                        1: clock off level 1, [CPOL=1]<br>
 *
 * \param par_msb_first   msb_first: 0: LSB transmitted first   / 1: MSB transmitted first
 *
 * \param par_nss_mode    TRUE: Nss ignored. Only sck can start SPI frame. Only sck_timeout can end SPI frame (see CFG_SPI_SCK_TIMEOUT)
 */
void usi_spi_dma_slave_init(const usi_num_t usi_no, clock_source_t par_as_clock_source, uint8_t par_div, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode);
  
/* ########################################################################## */  
/**
 * Wrapper for usi_spi_dma_clock() + usi_spi_dma_init()
 *
 * MASTER is not implemented
 * 
 * \see usi_spi_dma_clock()
 * \see usi_spi_dma_init() 
 *
 * Function to setup USI as SPI in MASTER - DMA mode. It sets USI clock
 * Callback is run when End of Transfer is triggered 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_as_clock_source AS clock source (communication clock domain)
 *
 * \param par_div divider on AS clock
 *
 * \param par_bit_data_length 8/16
 *
 * \param par_phase       0: 1st edge shift, 2nd edge sample    / 1: 1st edge sample, 2nd edge shift
 *
 * \param par_polarity    polarity - 0: clock off level 0       / 1: clock off level 1
 *
 * \param par_msb_first   msb_first: 0: LSB transmitted first   / 1: MSB transmitted first
 *
 * \param par_nss_mode    TRUE: Nss ignored. Only sck can start SPI frame. Only sck_timeout can end SPI frame (see CFG_SPI_SCK_TIMEOUT)
 */
void usi_spi_dma_master_init(const usi_num_t usi_no, clock_source_t par_as_clock_source, uint8_t par_div, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode);
  
/* ########################################################################## */  
/**
 * Wrapper for usi_spi_dma_init()
 * 
 * \see usi_spi_dma_init() 
 *
 * Function to setup USI as SPI in SLAVE - DMA mode. It does not set USI clock
 * Callback is run when End of Transfer is triggered 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_bit_data_length 8/16
 *
 * \param par_phase       0: 1st edge shift, 2nd edge sample    / 1: 1st edge sample, 2nd edge shift
 *
 * \param par_polarity    polarity - 0: clock off level 0       / 1: clock off level 1
 *
 * \param par_msb_first   msb_first: 0: LSB transmitted first   / 1: MSB transmitted first
 *
 * \param par_nss_mode    TRUE: Nss ignored. Only sck can start SPI frame. Only sck_timeout can end SPI frame (see CFG_SPI_SCK_TIMEOUT)
 */
void usi_spi_dma_slave_init_no_clk_init(const usi_num_t usi_no, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode);

/* ########################################################################## */  
/**
 * Wrapper for usi_spi_dma_init()
 *
 * MASTER (is not implemented)
 *
 * \see usi_spi_dma_init() 
 *
 * Function to setup USI as SPI in MASTER - DMA mode. It does not set USI clock
 * Callback is run when End of Transfer is triggered 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_bit_data_length 8/16
 *
 * \param par_phase       0: 1st edge shift, 2nd edge sample    / 1: 1st edge sample, 2nd edge shift
 *
 * \param par_polarity    polarity - 0: clock off level 0       / 1: clock off level 1
 *
 * \param par_msb_first   msb_first: 0: LSB transmitted first   / 1: MSB transmitted first
 *
 * \param par_nss_mode    TRUE: Nss ignored. Only sck can start SPI frame. Only sck_timeout can end SPI frame (see CFG_SPI_SCK_TIMEOUT)
 */
void usi_spi_dma_master_init_no_clk_init(const usi_num_t usi_no, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode);

/* ########################################################################## */  
/**
 * Wrapper for usi_spi_dma_frame()
 *
 * \see usi_spi_dma_frame()
 *
 * Prepare data for USI/SPI 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_number_of_data 1..255
 *
 * \param par_p_snd_data pointer to send data
 *
 * \param par_p_rcv_data pointer to receive data
 */
void usi_spi_dma_slave_frame(usi_num_t usi_no, uint8_t par_number_of_data, void * par_p_snd_data, void * par_p_rcv_data);

/* ########################################################################## */  
/**
 * Wrapper for usi_spi_slave_reg_callback()
 *
 * \see usi_spi_slave_reg_callback()
 *
 * Register callback functions for USI/SPI 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_usi_nvic_priority set NVIC priority for this USI
 *
 * \param p_fce_callback_rx_done pointer to function which will be called when end of the transfer occurs
 *
 * \param p_fce_callback_error pointer to function which will be called when ERROR occurs
 *
 */
void usi_spi_dma_slave_reg_callback(usi_num_t usi_no, uint8_t par_usi_nvic_priority, void (*p_fce_callback_rx_done)(void), void (*p_fce_callback_error)(void));

/* ########################################################################## */  
/**
 * Get flag status 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 */
bool usi_spi_status_flag(usi_num_t usi_no);

/* ########################################################################## */  
/**
 * Register callback functions for USI/SPI 
 *
 * \ingroup usi_spi_dma
 *
 * \param usi_no USI instance (USI0/USI)
 *
 * \param par_usi_nvic_priority set NVIC priority for this USI
 *
 * \param p_fce_callback_rx_done pointer to function which will be called when end of the transfer occurs
 *
 * \param p_fce_callback_error pointer to function which will be called when ERROR occurs
 *
 */
void usi_spi_dma_reg_callback(usi_num_t usi_no, uint8_t par_usi_nvic_priority, void (*p_fce_callback_rx_done)(void), void (*p_fce_callback_error)(void));

/**
  * \}
  */
#endif
