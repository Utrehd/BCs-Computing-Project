/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         io_ctrl.h
*
* @brief        IO Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __IO_CTRL_H__
#define __IO_CTRL_H__

#include "device.h"

#include "io_ctrl_bf.h"


/**
 * \example example_gpio.c
 * This is an example of how to use IO Control to set GPIO.
 */

/**
 * \image html IOMUX.png
 * block schematic of Clock and Reset Control block
 */

/**
 * \defgroup io_ctrl ASIC2 IO Control HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control IO Control
 *
 * \details See code example: @include example_gpio.c
 */
/**@{*/ 




/* ############################################################################ */
/**
 * \brief This is an enum class for IO CONTROL to identify pinout
 *
 * \ingroup io_ctrl 
 */ 
typedef enum {
  /**
   * Pinout 0 (p0)
   */ 
  IOMUX_PAD0  = 0x1300,
  /**
   * Pinout 1 (p1)
   */ 
  IOMUX_PAD1  = 0x0000,
  /**
   * Pinout 2 (p2)
   */ 
  IOMUX_PAD2  = 0x0008,
  /**
   * Pinout 3 (p3)
   */ 
  IOMUX_PAD3  = 0x0100,
  /**
   * Pinout 4 (p4)
   */ 
  IOMUX_PAD4  = 0x0108,
  /**
   * Pinout 5 (p5)
   */ 
  IOMUX_PAD5  = 0x0200,
  /**
   * Pinout 6 (p6)
   */ 
  IOMUX_PAD6  = 0x0208,
  /**
   * Pinout 7 (p7)
   */ 
  IOMUX_PAD7  = 0x0300,
  /**
   * Pinout 8 (p8)
   */ 
  IOMUX_PAD8  = 0x0308,
  /**
   * Pinout 9 (p9)
   */ 
  IOMUX_PAD9  = 0x0400,
  /**
   * Pinout 10 (p10)
   */ 
  IOMUX_PAD10 = 0x0408,
  /**
   * Pinout 11 (p11)
   */ 
  IOMUX_PAD11 = 0x0F00,
  /**
   * Pinout 12 (p12)
   */ 
  IOMUX_PAD12 = 0x0F08,
  /**
   * Pinout 13 (p13)
   */ 
  IOMUX_PAD13 = 0x0E00,
  /**
   * Pinout 14 (p14)
   */ 
  IOMUX_PAD14 = 0x0E08,
  /**
   * Pinout 15 (p15)
   */ 
  IOMUX_PAD15 = 0x0500,
  /**
   * Pinout 16 (p16)
   */ 
  IOMUX_PAD16 = 0x0508,
  /**
   * Pinout 17 (p17)
   */ 
  IOMUX_PAD17 = 0x0600,
  /**
   * Pinout 18 (p18)
   */ 
  IOMUX_PAD18 = 0x0608,
  /**
   * Pinout 19 (p19)
   */ 
  IOMUX_PAD19 = 0x0700,
  /**
   * Pinout 20 (p20)
   */ 
  IOMUX_PAD20 = 0x0708,
  /**
   * Pinout 21 (p21)
   */ 
  IOMUX_PAD21 = 0x0800,
  /**
   * Pinout 22 (p22)
   */ 
  IOMUX_PAD22 = 0x1008,
  /**
   * Pinout 23 (p23)
   */ 
  IOMUX_PAD23 = 0x1100,
  /**
   * Pinout 24 (p24)
   */ 
  IOMUX_PAD24 = 0x1108,
  /**
   * Pinout 25 (p25)
   */ 
  IOMUX_PAD25 = 0x0808,
  /**
   * Pinout 26 (p26)
   */ 
  IOMUX_PAD26 = 0x0900,
  /**
   * Pinout 27 (p27)
   */ 
  IOMUX_PAD27 = 0x0908,
  /**
   * Pinout 28 (p28)
   */ 
  IOMUX_PAD28 = 0x0A00,
  /**
   * Pinout 29 (p29)
   */ 
  IOMUX_PAD29 = 0x0A08,
  /**
   * Pinout 30 (p30)
   */ 
  IOMUX_PAD30 = 0x0B00,
  /**
   * Pinout 31 (p31)
   */ 
  IOMUX_PAD31 = 0x0B08,
  /**
   * Pinout 32 (p32)
   */ 
  IOMUX_PAD32 = 0x0C00,
  /**
   * Pinout 33 (p33)
   */ 
  IOMUX_PAD33 = 0x0C08,
  /**
   * Pinout 34 (p34)
   */ 
  IOMUX_PAD34 = 0x0D00,
  /**
   * Pinout 35 (p35)
   */ 
  IOMUX_PAD35 = 0x0D08,
} iomux_pad_t;

/* ############################################################################ */
/**
 * \brief This is an enum class for IO CONTROL to identify module
 *
 * \ingroup io_ctrl 
 */ 
typedef enum {
  /**
   * General Purpose Input/Output module
   */ 
  IO_GPIO             = 0 ,
  /**
   * Parallel Host-Interface (HIAD) module
   */ 
  IO_HIAD             = 1 ,
  /**
   * Analog Control module
   */ 
  IO_ANALOG           = 2 ,
  /**
   * Transmitter UART module
   */ 
  IO_UART_OE_RX       = 3 ,
  /**
   * Receiver UART module
   */ 
  IO_UART_TX          = 4 ,
  /**
   * SPI Host Interface (HISPI) module
   */ 
  IO_HISPI            = 5 ,
  /**
   * I2C Master Interface module
   */ 
  IO_I2C              = 6 ,
  /**
   * External Processor Interrupt Controller (VIC_EXT) module
   */ 
  IO_VIC_EXT          = 7 ,
  /**
   * HV module
   */ 
  IO_HV_RS485         = 8 ,
  /**
   * SWD 0 module
   */ 
  IO_SWD_0            = 9 ,
  /**
   * SWD 1 module
   */ 
  IO_SWD_1            = 10,
  /**
   * USI 0 module
   */ 
  IO_USI0             = 11,
  /**
   * USI 1 module
   */ 
  IO_USI1             = 12,
  /**
   * TSU module
   */ 
  IO_TSU              = 13,
  /**
   * PWMN 0 and 1 module
   */ 
  IO_PWMN_01          = 14,
  /**
   * PWMN 2 and 3 module
   */ 
  IO_PWMN_23          = 15,
  /**
   * PWMN NALLOFF module
   */ 
  IO_PWMN_NALLOFF     = 16,
  /**
   * Parallel Host-Interface (HIAD) Address Latch Enable (ALE) module
   */ 
  IO_HIAD_ALE         = 17,
  /**
   * Capture and Compare Timer 32 (CCTIMER32) 0 Measurement module
   */ 
  IO_CCTIMER0_MEAS    = 18,
  /**
   * Capture and Compare Timer 32 (CCTIMER32) 0 PWM module
   */ 
  IO_CCTIMER0_PWM     = 19,
  /**
   * Capture and Compare Timer 32 (CCTIMER32) 1 Measurement module
   */ 
  IO_CCTIMER1_MEAS    = 20,
  /**
   * Capture and Compare Timer 32 (CCTIMER32) 1 PWM module
   */ 
  IO_CCTIMER1_PWM     = 21,
  /**
   * SAR A/D Converter module
   */ 
  IO_SARADC           = 22,
  /**
   * Electronic Label module
   */ 
  IO_EL_CTRL          = 23,
} io_pin_func_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for IO CONTROL to identify SWD and HV-RS485 routing
 *
 * \ingroup io_ctrl 
 */ 
typedef enum {
  /**
   * HV-RS485 controlled by SWD0
   */ 
  IOMUX_HV_SWD0_CONN    = 0,
  /**
   * SWD0 routed to Pads (through IOMUX)
   */ 
  IOMUX_SWD0_PADS_CONN  = 1,
  /**
   * HV-RS485 controlled by Pads (through IOMUX)
   */ 
  IOMUX_HV_PADS_CONN    = 2,
} io_swd_hv_conn_t;


/* ############################################################################ */
/**
 * \brief Function to lock IO CONTROL guard
 *
 * \ingroup io_ctrl 
 */ 
void io_ctrl_guard_lock(void);


/* ############################################################################ */
/**
 * \brief Function to unlock IO CONTROL guard
 *
 * \ingroup io_ctrl 
 */ 
void io_ctrl_guard_unlock(void);


/* ############################################################################ */
/**
 * \brief Function to set IO CONTROL pinout with corresponding module
 *
 * \ingroup io_ctrl 
 * 
 * \param pad                Select desired pinout
 *                           \see iomux_pad_t
 * 
 * \param value 			 Select desired module
 *                           \see io_pin_func_t
 */ 
void io_ctrl_config_sel(iomux_pad_t pad, io_pin_func_t value);


/* ############################################################################ */
/**
 * \brief Function to enable IO CONTROL pinout drive strength
 *
 * \ingroup io_ctrl 
 * 
 * \param pad                Select desired pinout
 *                           \see iomux_pad_t
 * 
 * \param value              1: Enable
 */ 
void io_ctrl_config_ds(iomux_pad_t pad, bool value);


/* ############################################################################ */
/**
 * \brief Function to enable IO CONTROL pinout pullup
 *
 * \ingroup io_ctrl 
 * 
 * \param pad                Select desired pinout
 *                           \see iomux_pad_t
 * 
 * \param value              1: Enable
 */ 
void io_ctrl_config_pe(iomux_pad_t pad, bool value);


/* ############################################################################ */
/**
 * \brief Function to set IO CONTROL SWD and HV-RS485 connection
 *
 * \ingroup io_ctrl 
 * 
 * \param swd_hv_conn        00: HV-RS485 controlled by SWD0 <br>
 *                           01: SWD0 routed to Pads (through IOMUX) <br>
 *                           10: HV-RS485 controlled by Pads (through IOMUX)
 *                           \see io_swd_hv_conn_t
 */ 
void io_ctrl_config_swd_hv_conn(io_swd_hv_conn_t swd_hv_conn);


/* ############################################################################ */
/**
 * \brief Function to set IO CONTROL JTAG I/O
 *
 * \ingroup io_ctrl 
 * 
 * \param is_dio             0: TDO_p[n] and TDI_p[m] used as JTAG Pins <br>
 *                           1: TDO_p[n] and TDI_p[m] used as digital IO <br>
 *                           (can be multiplexed with corresponding select)
 */ 
void io_ctrl_config_jtag_dio(bool is_dio);


/* ############################################################################ */
/**
 * \brief Function to enable IO CONTROL external TIA
 *
 * \ingroup io_ctrl 
 * 
 * \param use_ext_tia        0: internal EL_TIA is used <br>
 *                           1: external TIA can be used (through IOMUX)
 */ 
void io_ctrl_config_el_ctrl_tia(bool use_ext_tia);


/* ############################################################################ */
/**
 * \brief Function to enable IO CONTROL drive strength
 *
 * \ingroup io_ctrl 
 * 
 * \param value              Drive strength select of EL_RX pin
 */ 
void io_ctrl_config_el_rx_ds(bool value);

/* ############################################################################ */
/**
 * \brief Function to convert from pin number to IO_MUX name pad
 *
 * \ingroup io_ctrl 
 * 
 * \param value              pin number
 *
 * \return IO_MUX pad
 */ 
iomux_pad_t io_ctrl_pin2iomux_pad(uint8_t i_pin);
/**@} */
#endif /* __IO_CTRL_H__ */
