/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         task_manager_api.h
*
* @brief        Task Manager API functions
*
* @author       Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __TASK_MANAGER_API__
#define __TASK_MANAGER_API__


/**
 * \defgroup task_manager_api Task Manager API functions
 *
 * \ingroup  asic2_api
 *
 * \brief    API function to control GPIO
 *
 */

#include "hardware_api.h"
#include "task_manager_api.h"


#define TASK_MANAGER_API_TASK_LIST_MAX 8 ///< How many tasks can be in task list
#define TASK_MANAGER_API_DEFRAG_LEVEL  80 ///< The percentage of task when defragmatation should be run

#define TASK_MANAGER_API_NONE        0 ///< without inicialization
#define TASK_MANAGER_API_READY       1 ///< task is ready to run
#define TASK_MANAGER_API_RUNING      2 ///< task is currently running
#define TASK_MANAGER_API_BLOCKED     3 ///< task is blocked (sleep) can be woken-up
#define TASK_MANAGER_API_TERMINATED  4 ///< task has already finished

#define TASK_MANAGER_API_RUN_FOREVER 255 ///< parameter for i_iteraction to run task forever

#define TASK_MANAGER_API_TASK_PERIOD 10 ///< how often task are run [ms]

/* ############################################################################ */
/** 
 * \brief Task description, ID, status, etc.
 *
 * \ingroup task_manager_api
 */
typedef struct
{
 uint8_t  id;           ///< process ID
 uint32_t curr_time;    ///< how long have already run this task
 uint32_t time_period;  ///< what periody has this task 
 uint8_t iteraction;    ///< how many time run this task (255 = always)
 uint8_t stat;          ///< status of task READY/RUNNING/BLOCKED/TERMINATED
 void (*ptr_app)(void); ///< pointer to function which represent this task
} TASK_MANAGER_API_TASK_ITEM;

/* ############################################################################ */
/**
 * \brief This function prints status of tasks in task list
 *
 * \ingroup task_manager_api
 */
void task_manager_api_info(void);

/* ############################################################################ */
/**
 * \brief Find task ID in task list and return index to this task list
 *
 * \ingroup task_manager_api
 *
 * \return task_manager_api_task_list index for specific task ID
 */
uint8_t task_manager_api_find(uint8_t i_task_ID);

/* ############################################################################ */
/**
 * \brief Terminate task with defined ID.
 *
 * \ingroup task_manager_api
 */
void task_manager_api_kill(uint8_t i_task_ID);

/* ############################################################################ */
/**
 * \brief Put task with ID to sleep mode
 *
 * \ingroup task_manager_api
 */
void task_manager_api_sleep(uint8_t i_task_ID);

/* ############################################################################ */
/**
 * \brief Wake-up task with ID from sleep mode
 *
 * \ingroup task_manager_api
 */
void task_manager_api_wkup(uint8_t i_task_ID);

/* ############################################################################ */
/**
 * \brief Defragment tasks in task list - remove task which has been already terminated
 *
 * \ingroup task_manager_api
 */
void task_manager_api_defrag(void);

/* ############################################################################ */
/**
 * \brief Add task to task list and return task ID 
 *
 * \ingroup task_manager_api
 * 
 * \param i_ptr_app pointer to function which represent task
 * 
 * \param i_per_time after what time this task should be run/how often [TASK_MANAGER_API_TASK_PERIOD]
 * 
 * \param i_iteraction how many times should be run <br>
 *                     1-once, <br>
 *                     244->244times, <br>
 *                     255 - forever (see TASK_MANAGER_API_RUN_FOREVER) <br>
 *
 * \return task ID 
 */
uint8_t task_manager_api_add(void (*i_ptr_app)(void), uint32_t i_per_time, uint8_t i_iteraction);

/* ############################################################################ */
/**
 * \brief This function should be run periodically with period needed by parameter
 *        i_per_time of function task_manager_api_add()
 *
 * \ingroup task_manager_api
 * 
 */
void task_manager_api_run(void);

/* ############################################################################ */
/**
 * \brief Init SysTick to run task_manager_api_run every TASK_MANAGER_API_TASK_PERIOD ms
 *
 * \ingroup task_manager_api
 * 
 */
void task_manager_api_init(void);

#endif