/* FPGA Release: 10512 */
#include "swd.h"

void swd_set_period(uint16_t period) {
    int MAX_PERIOD =(65535 / 50) - 1;

    if(period > MAX_PERIOD) {
        period = MAX_PERIOD;
    }

    swd_set_dpll_integrator_threshold(period);
    swd_set_disack_integrator_threshold(10 * period);
    swd_set_disack2_integrator_threshold(15 * period);
    swd_set_idle_disack2_detect_start_threshold(15 * period);
    swd_set_idle_disack2_detect_end_threshold(40 * period);
    swd_set_idle_disack2_send_threshold(20 * period);
    swd_set_idle_dpll_threshold(50 * period);
    swd_set_idle_pe_threshold(60 * period);
    swd_config_dpll(period / 2, (period * 3) >> 1, 0);
    swd_config_startbit_detection(period-1);
    //swd_config_data_reconstruction((period >> 1) - 1, period - 2);
    swd_set_data_offset((period >> 1) - 1);
    swd_set_data_length(period - 2);
    swd_set_disack_timeout(20 * period);
    swd_config_transmitter((period * 3) >> 1, 50 * period, period, 1);
    swd_set_takeover_disack2(5 * period);
    swd_set_disack2_length(20);
    //swd_config_disack2(15 * period, 25 * period, 0, 20, 40 * period);
    swd_config_stop_bit_extension((period * 3) >> 1);
    swd_enable_disack2(true);
}


uint16_t swd_get_period(void) {
    uint16_t period;
    period = READ_REG_U16(AADDR_SWD_INTEGRATOR_DPLL_THRESHOLD);
    return period;
}


void swd_config_phy(swd_bus_t bus, bool invert_rxd, bool invert_txd, bool invert_oe){
    swd_phy_config_t phy_config;
    phy_config.val = READ_REG_U16(AADDR_SWD_PHY_CONFIG);
    if (bus == SWD_BUS1){
      phy_config.bf.inv_oe_1  = invert_oe  ? 1 : 0;
      phy_config.bf.inv_rxd_1 = invert_rxd ? 1 : 0;
      phy_config.bf.inv_txd_1 = invert_txd ? 1 : 0;
    } else {
      phy_config.bf.inv_oe_0  = invert_oe  ? 1 : 0;
      phy_config.bf.inv_rxd_0 = invert_rxd ? 1 : 0;
      phy_config.bf.inv_txd_0 = invert_txd ? 1 : 0;
    }
    WRITE_REG_16(AADDR_SWD_PHY_CONFIG, phy_config.val);
}

void swd_set_phy_invert_txd0(bool val){
    swd_phy_config_t phy_config;
    phy_config.val = READ_REG_U16(AADDR_SWD_PHY_CONFIG);
    phy_config.bf.inv_txd_0 = val ? 1 : 0;
    WRITE_REG_16(AADDR_SWD_PHY_CONFIG, phy_config.val);
}

void swd_config_local_feedback(swd_bus_t bus, bool local_feedback){
    swd_phy_config_t phy_config;
    phy_config.val = READ_REG_U16(AADDR_SWD_PHY_CONFIG);
    if (bus == SWD_BUS1){
      phy_config.bf.local_feedback_1 = local_feedback ? 1 : 0;
    } else {
      phy_config.bf.local_feedback_0 = local_feedback ? 1 : 0;
    }
    WRITE_REG_16(AADDR_SWD_PHY_CONFIG, phy_config.val);
}

void swd_set_dpll_integrator_threshold(uint16_t dpll_threshold){
    WRITE_REG_16(AADDR_SWD_INTEGRATOR_DPLL_THRESHOLD, dpll_threshold);
}

void swd_set_disack_integrator_threshold(uint16_t disack_threshold){
    WRITE_REG_16(AADDR_SWD_INTEGRATOR_DISACK_THRESHOLD, disack_threshold);
}

void swd_set_disack2_integrator_threshold(uint16_t disack2_threshold){
    WRITE_REG_16(AADDR_SWD_INTEGRATOR_DISACK2_THRESHOLD, disack2_threshold);
}

//void swd_set_integrator_thresholds(uint16_t dpll_threshold, uint16_t disack_threshold){
//    WRITE_REG_16(AADDR_SWD_INTEGRATOR_DPLL_THRESHOLD, dpll_threshold);
//    WRITE_REG_16(AADDR_SWD_INTEGRATOR_DISACK_THRESHOLD, disack_threshold);
//}

void swd_set_idle_dpll_threshold(uint32_t dpll_threshold) {
    WRITE_REG_16(AADDR_SWD_IDLE_DPLL_THRESHOLD_LW, dpll_threshold);
    WRITE_REG_16(AADDR_SWD_IDLE_DPLL_THRESHOLD_HW, dpll_threshold >> 16);
}

void swd_set_idle_pe_threshold(uint32_t pe_threshold) {
    WRITE_REG_16(AADDR_SWD_IDLE_PE_THRESHOLD_LW, pe_threshold);
    WRITE_REG_16(AADDR_SWD_IDLE_PE_THRESHOLD_HW, pe_threshold >> 16);
}

void swd_set_idle_disack2_detect_start_threshold(uint32_t disack2_detect_start_threshold) {
    WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW, disack2_detect_start_threshold);
    WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW, disack2_detect_start_threshold >> 16);
}

void swd_set_idle_disack2_send_threshold(uint32_t disack2_send_threshold) {
    WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW, disack2_send_threshold);
    WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW, disack2_send_threshold >> 16);
}

void swd_set_idle_disack2_detect_end_threshold(uint32_t disack2_detect_end_threshold) {
    WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW, disack2_detect_end_threshold);
    WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW, disack2_detect_end_threshold >> 16);
}

//void swd_set_idle_thresholds(uint32_t dpll_threshold, uint32_t pe_threshold) {
//    WRITE_REG_16(AADDR_SWD_IDLE_DPLL_THRESHOLD_LW, dpll_threshold);
//    WRITE_REG_16(AADDR_SWD_IDLE_DPLL_THRESHOLD_HW, dpll_threshold >> 16);
//    WRITE_REG_16(AADDR_SWD_IDLE_PE_THRESHOLD_LW, pe_threshold);
//    WRITE_REG_16(AADDR_SWD_IDLE_PE_THRESHOLD_HW, pe_threshold >> 16);
//}

void swd_config_dpll(uint16_t min_period, uint16_t max_period, uint8_t mean_alpha) {
    WRITE_REG_16(AADDR_SWD_DPLL_MIN_PERIOD, min_period);
    WRITE_REG_16(AADDR_SWD_DPLL_MAX_PERIOD, max_period);
    WRITE_REG_16(AADDR_SWD_DPLL_MEAN_ALPHA, mean_alpha);
}


void swd_get_dpll_last_frac_period(swd_dpll_frac_period_t * period) {
    period->val = READ_REG_U16(AADDR_SWD_DPLL_LAST_FRAC_PERIOD);
}


void swd_get_dpll_mean_frac_period(swd_dpll_frac_period_t * period) {
    period->val = READ_REG_U16(AADDR_SWD_DPLL_MEAN_FRAC_PERIOD);
}


uint16_t swd_get_dpll_min_period(void) {
    uint16_t min_period;
    min_period = READ_REG_U16(AADDR_SWD_DPLL_MIN_PERIOD);
    return min_period;
}


uint16_t swd_get_dpll_max_period(void) {
    uint16_t max_period;
    max_period = READ_REG_U16(AADDR_SWD_DPLL_MAX_PERIOD);
    return max_period;
}


uint16_t swd_get_dpll_last_period(void) {
    swd_dpll_frac_period_t frac_period;
    swd_get_dpll_last_frac_period(&frac_period);
    return frac_period.bf.period;
}


uint16_t swd_get_dpll_mean_period(void) {
    swd_dpll_frac_period_t frac_period;
    swd_get_dpll_mean_frac_period(&frac_period);
    return frac_period.bf.period;
}


void swd_config_dpll_override(bool enable_override, uint16_t period, uint8_t fractional) {
    swd_dpll_ov_frac_period_t dpll_ov_frac_period;
    dpll_ov_frac_period.val = 0;
    dpll_ov_frac_period.bf.ov_en = enable_override ? 1 : 0;
    dpll_ov_frac_period.bf.ov_fracval = fractional;
    dpll_ov_frac_period.bf.ov_period = period;
    WRITE_REG_16(AADDR_SWD_DPLL_OV_FRAC_PERIOD, dpll_ov_frac_period.val);
}


void swd_config_startbit_detection(uint16_t start_threshold) {
    WRITE_REG_16(AADDR_SWD_START_THRESHOLD, start_threshold);
}

void swd_config_stop_bit_extension(uint16_t stop_bit_ext) {
    WRITE_REG_16(AADDR_SWD_TX_STOP_BIT_EXT, stop_bit_ext);
}


void swd_set_data_offset(uint16_t data_offset) {
  WRITE_REG_16(AADDR_SWD_DATA_OFFSET, data_offset);
}

void swd_set_data_length(uint16_t data_length) {
  WRITE_REG_16(AADDR_SWD_DATA_LENGTH, data_length);
}

//void swd_config_data_reconstruction(uint8_t data_offset, uint16_t data_length) {
//    swd_data_offset_length_t data_offset_length;
//    data_offset_length.val = 0;
//    data_offset_length.bf.data_offset = data_offset;
//    data_offset_length.bf.data_length = data_length;
//    WRITE_REG_16(AADDR_SWD_DATA_OFFSET_LENGTH, data_offset_length.val);
//}


void swd_set_receive_timeout(uint8_t timeout) {
    WRITE_REG_16(AADDR_SWD_TIMEOUT_RX, timeout);
}


void swd_set_replace_timeout(uint8_t timeout) {
    WRITE_REG_16(AADDR_SWD_TIMEOUT_REPLACE, timeout);
}


void swd_set_disack_timeout(uint16_t timeout) {
    WRITE_REG_16(AADDR_SWD_TIMEOUT_DISACK, timeout);
}


void swd_config_comm(bool comm_enable, bool rx_enable) {
    swd_comm_config_t comm_config;
    comm_config.val = READ_REG_U16(AADDR_SWD_COMM_CONFIG);
    comm_config.bf.comm_enable  = comm_enable ? 1 : 0;
    comm_config.bf.rx_enable    = rx_enable   ? 1 : 0;
    WRITE_REG_16(AADDR_SWD_COMM_CONFIG, comm_config.val);
}

void swd_get_comm_config(swd_comm_config_t * comm_config) {
    comm_config->val = READ_REG_U16(AADDR_SWD_COMM_CONFIG);
}

void swd_config_variable_state(swd_bus_t bus, bool variable_state){
    swd_comm_config_t comm_config;
    comm_config.val = READ_REG_U16(AADDR_SWD_COMM_CONFIG);
    if (bus == SWD_BUS1){
      comm_config.bf.variable_state_1 = variable_state ? 1 : 0;
    } else {
      comm_config.bf.variable_state_0 = variable_state ? 1 : 0;
    }
    WRITE_REG_16(AADDR_SWD_COMM_CONFIG, comm_config.val);
}

void swd_bus_select(swd_bus_t bus) {
    swd_comm_config_t comm_config;
    comm_config.val = READ_REG_U16(AADDR_SWD_COMM_CONFIG);
    comm_config.bf.bus_select    = (bus == SWD_BUS1)   ? 1 : 0;
    WRITE_REG_16(AADDR_SWD_COMM_CONFIG, comm_config.val);
}

void swd_config_repeater(bool repeater_enable) {
    swd_comm_config_t comm_config;
    comm_config.val = READ_REG_U16(AADDR_SWD_COMM_CONFIG);
    comm_config.bf.repeater_enable  = repeater_enable ? 1 : 0;
    WRITE_REG_16(AADDR_SWD_COMM_CONFIG, comm_config.val);
}


void swd_config_transmitter(uint16_t takeover_data_disack, uint16_t prestart_sync, uint16_t prestart_data, uint8_t end_of_sync) {
    WRITE_REG_16(AADDR_SWD_TAKEOVER_DATA, takeover_data_disack);
    WRITE_REG_16(AADDR_SWD_TAKEOVER_DISACK, takeover_data_disack);
    WRITE_REG_16(AADDR_SWD_TX_PRESTART_SYNC, prestart_sync);
    WRITE_REG_16(AADDR_SWD_TX_PRESTART_DATA, prestart_data);
    WRITE_REG_16(AADDR_SWD_TX_END_OF_SYNC, end_of_sync);
}


/*
void
swd_reset_busstat(void)
{
    WRITE_REG_16(AADDR_SWD_BUSSTAT_CMD, 1);
}

void
swd_enable_busstat(bool enable)
{
    WRITE_REG_16(AADDR_SWD_BUSSTAT_CONFIG, enable ? 1 : 0);
}

void
swd_set_busstat_thresholds(swd_busstat_thresholds_t * thresholds)
{
    WRITE_REG_16(AADDR_SWD_BUSSTAT_THRESHOLD0, thresholds->threshold0);
    WRITE_REG_16(AADDR_SWD_BUSSTAT_THRESHOLD1, thresholds->threshold1);
    WRITE_REG_16(AADDR_SWD_BUSSTAT_THRESHOLD2, thresholds->threshold2);
    WRITE_REG_16(AADDR_SWD_BUSSTAT_THRESHOLD3, thresholds->threshold3);
    WRITE_REG_16(AADDR_SWD_BUSSTAT_THRESHOLD4, thresholds->threshold4);
}


u16
swd_get_busstat_minvalue(void)
{
    uint16_t temp;
    temp = READ_REG_U16(AADDR_SWD_BUSSTAT_MINVALUE);
    return temp;
}

void
swd_get_busstat_counts(swd_busstat_counts_t * counts)
{
    counts->count0 = READ_REG_U16(AADDR_SWD_BUSSTAT_COUNT0);
    counts->count1 = READ_REG_U16(AADDR_SWD_BUSSTAT_COUNT1);
    counts->count2 = READ_REG_U16(AADDR_SWD_BUSSTAT_COUNT2);
    counts->count3 = READ_REG_U16(AADDR_SWD_BUSSTAT_COUNT3);
}
*/

void swd_enable_disack2(bool enable){
  uint16_t comm_config = READ_REG_U16(AADDR_SWD_COMM_CONFIG);
  comm_config &= ~BIT_SWD_COMM_CONFIG_DISACK2_ENABLE;
  if (enable){
    comm_config |= BIT_SWD_COMM_CONFIG_DISACK2_ENABLE;
  }
  WRITE_REG_16(AADDR_SWD_COMM_CONFIG, comm_config);
}

void swd_set_takeover_disack2(uint16_t takeover){
  WRITE_REG_16(AADDR_SWD_TAKEOVER_DISACK2, takeover);
}

void swd_set_disack2_length(uint8_t length){
  WRITE_REG_16(AADDR_SWD_TX_DISACK2_LENGTH, length);
}

//void swd_config_disack2(uint16_t integrator_threshold, uint32_t idle_send, uint16_t takeover, uint8_t length, uint32_t idle_detect){
//  WRITE_REG_16(AADDR_SWD_COMM_CONFIG, READ_REG_U16(AADDR_SWD_COMM_CONFIG) | BIT_SWD_COMM_CONFIG_DISACK2_ENABLE);
//  WRITE_REG_16(AADDR_SWD_INTEGRATOR_DISACK2_THRESHOLD, integrator_threshold);
//  WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW, idle_send);
//  WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW, idle_send >> 16);
//  WRITE_REG_16(AADDR_SWD_TAKEOVER_DISACK2, takeover);
//  WRITE_REG_16(AADDR_SWD_TX_DISACK2_LENGTH, length);
//  WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_DETECT_THRESHOLD_LW, idle_detect);
//  WRITE_REG_16(AADDR_SWD_IDLE_DISACK2_DETECT_THRESHOLD_HW, idle_detect >> 16);
//}

swd_comm_status_t swd_get_comm_status(void) {
  swd_comm_status_t temp;
  temp.val = READ_REG_U16(AADDR_SWD_COMM_STATUS);
  return temp;
}

bool swd_get_comm_idle_dpll(void){
  swd_comm_status_t swd_comm_status = swd_get_comm_status();
  return swd_comm_status.bf.idle_dpll ? true : false;
}

bool swd_get_repeater_idle_state_in(void){
  return READ_REG_U16(AADDR_SWD_REPEATER_IDLE_STATE_IN);
}

void swd_set_repeater_idle_state_out(bool force_state, bool idle_state){
    swd_repeater_idle_state_out_t repeater_idle_state_out;
    repeater_idle_state_out.val = 0;
    repeater_idle_state_out.bf.force_state  = force_state ? 1 : 0;
    repeater_idle_state_out.bf.idle_state   = idle_state  ? 1 : 0;
    WRITE_REG_16(AADDR_SWD_REPEATER_IDLE_STATE_OUT, repeater_idle_state_out.val);
}

