/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swd_comm.h
*
* @brief        SWD_PM HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SWD_COMM_H
#define HAVE_SWD_COMM_H

#ifndef HAVE_SWD_H
#error "Please include swd.h instead of this file."
#endif

/* ############################################################################ */
/**
 * \brief This function sets all the registers of the filter core, which depend on the bit length
 *
 * \ingroup swd_pm 
 * 
 * \param period      The length of a bit in half clock cycles
 */ 
void swd_set_period (uint16_t period);


/* ############################################################################ */
/**
 * \brief This function assumes that the bit length has previously been set with the function
 *        <code> swd_set_period </ code>. If it is not set the return value must not be used!
 *
 * \ingroup swd_pm 
 * 
 * \return Returns the length of a bit. The length of a bit in half clock cycles
 */ 
uint16_t swd_get_period (void);


/* ############################################################################ */
/**
 * \brief Configures the control signals of a PHY.
 *
 * \ingroup swd_pm 
 * 
 * \param bus SWD bus instance (SWD_BUS0/SWD_BUS1) see SWD and HV-RS485 Routing in specification
 * 
 * \param invert_rxd 1: invert RXD
 * 
 * \param invert_txd 1: invert TXD
 * 
 * \param invert_oe 1: invert OE
 */ 
void swd_config_phy (swd_bus_t bus, bool invert_rxd, bool invert_txd, bool invert_oe);


/* ############################################################################ */
/**
 * \brief invert TXD on SWD_BUS0
 *
 * \ingroup swd_pm 
 * 
 * \param val invert TXD
 */ 
void swd_set_phy_invert_txd0(bool val);


/* ############################################################################ */
/**
 * \brief Enable local feedback from TX to RX
 *
 * \ingroup swd_pm 
 * 
 * \param bus SWD bus instance (SWD_BUS0/SWD_BUS1) see SWD and HV-RS485 Routing in specification
 * 
 * \param local_feedback 1: enable local feedback from TX to RX
 */ 
void swd_config_local_feedback(swd_bus_t bus, bool local_feedback);


/* ############################################################################ */
/**
 * \brief Sets the thresholds of the integrators.
 *
 * \ingroup swd_pm 
 * 
 * \param dpll_threshold     Integrator (DPLL) Threshold.
 * 
 * \param disack_threshold   Integrator (DisAck) Threshold.
 * 
 * \return 
 */ 
//void swd_set_integrator_thresholds (uint16_t dpll_threshold,
//                                       uint16_t disack_threshold);

/* ############################################################################ */
/**
 * \brief Integrator (DPLL) hysteresis threshold in half clock cycles (0 = half clock cycle)
 *
 * \ingroup swd_pm 
 * 
 * \param dpll_threshold hysteresis threshold in half clock cycles
 *
 * \remarks Writing threshold will reset Integrator with new value.
 *
 * \warning An integrator threshold of 0 could lead to incorrect behavior.
 */ 
void swd_set_dpll_integrator_threshold(uint16_t dpll_threshold);


/* ############################################################################ */
/**
 * \brief Integrator (DisAck) hysteresis threshold in half clock cycles (0 = half clock cycle)
 *
 * \ingroup swd_pm 
 * 
 * \param disack_threshold hysteresis threshold in half clock cycles
 *
 * \remarks Writing threshold will reset Integrator with new value.
 *
 * \warning An integrator threshold of 0 could lead to incorrect behavior.
 */ 
void swd_set_disack_integrator_threshold(uint16_t disack_threshold);


/* ############################################################################ */
/**
 * \brief Integrator (DisAck2) hysteresis threshold in half clock cycles (0 = half clock cycle)
 *
 * \ingroup swd_pm 
 * 
 * \param disack2_threshold hysteresis threshold in half clock cycles
 *
 * \remarks Writing threshold will reset Integrator with new value.
 *
 * \warning An integrator threshold of 0 could lead to incorrect behavior.
 */ 
void swd_set_disack2_integrator_threshold(uint16_t disack2_threshold);


/* ############################################################################ */
/**
 * \brief Sets the thresholds of idle detection.
 *
 * \ingroup swd_pm 
 * 
 * \param dpll_threshold Idle DPLL Threshold (Pause before Accept the preamble).
 * 
 * \param pe_threshold   Idle PE Threshold (Minimum pause before Sending
 *                       the preamble from the coordinator)
 */ 
//void swd_set_idle_thresholds (uint32_t dpll_threshold, uint32_t pe_threshold);


/* ############################################################################ */
/**
 * \brief pause before accept preamble
 *
 * \ingroup swd_pm 
 * 
 * \param dpll_threshold pause before accept preamble
 *
 * \remarks Writing threshold will reset Idle detection with new value.
 */ 
void swd_set_idle_dpll_threshold(uint32_t dpll_threshold);


/* ############################################################################ */
/**
 * \brief pause before sending preamble
 *
 * \ingroup swd_pm 
 * 
 * \param pe_threshold pause before sending preamble
 *
 * \remarks Writing threshold will reset Idle detection with new value.
 */ 
void swd_set_idle_pe_threshold(uint32_t pe_threshold);


/* ############################################################################ */
/**
 * \brief time until accepting a DisAck2
 *
 * \ingroup swd_pm 
 * 
 * \param disack2_detect_start_threshold time until accepting a DisAck2
 *
 * \remarks Writing threshold will reset Idle detection with new value.
 */ 
void swd_set_idle_disack2_detect_start_threshold(uint32_t disack2_detect_start_threshold);


/* ############################################################################ */
/**
 * \brief time until DisAck2 has to be seen on the bus
 *
 * \ingroup swd_pm 
 * 
 * \param disack2_detect_end_threshold time until DisAck2 has to be seen on the bus
 *
 * \remarks Writing threshold will reset Idle detection with new value.
 */ 
void swd_set_idle_disack2_detect_end_threshold(uint32_t disack2_detect_end_threshold);


/* ############################################################################ */
/**
 * \brief required until sending DisAck2
 *
 * \ingroup swd_pm 
 * 
 * \param disack2_send_threshold required until sending DisAck2
 *
 * \remarks Writing threshold will reset Idle detection with new value.
 */ 
void swd_set_idle_disack2_send_threshold(uint32_t disack2_send_threshold);


/* ############################################################################ */
/**
 * \brief Configures the DPLL
 *
 * \ingroup swd_pm 
 * 
 * \param min_period The minimum bit length, minimum allowed period value for DPLL (see formula in DPLL_OV_PERIOD)
 * 
 * \param max_period The maximum bit length, maximum allowed period value for DPLL (see formula in DPLL_OV_PERIOD)
 * 
 * \param mean_alpha The filter coefficient 'alpha', filter coefficient alpha a= 1 / (2^alpha) , with alpha = {0...5}
 */ 
void swd_config_dpll (uint16_t min_period, uint16_t max_period, uint8_t mean_alpha);


/* ############################################################################ */
/**
 * \brief Get last detected fractional value, last detected bit length
 *
 * \ingroup swd_pm 
 * 
 * \param frac_period pointer to data which will be returned
 */ 
void swd_get_dpll_last_frac_period (swd_dpll_frac_period_t * frac_period);


/* ############################################################################ */
/**
 * \brief Get last calculated mean fractional value, last calculated mean entitlement
 *
 * \ingroup swd_pm 
 * 
 * \param frac_period pointer to data which will be returned
 */ 
void swd_get_dpll_mean_frac_period (swd_dpll_frac_period_t * frac_period);


/* ############################################################################ */
/**
 * \brief Returns the currently set minimum DPLL bit length
 *
 * \ingroup swd_pm 
 * 
 * \return minimum allowed period value for DPLL (see formula in DPLL_OV_PERIOD)
 */ 
uint16_t swd_get_dpll_min_period (void);


/* ############################################################################ */
/**
 * \brief Returns the currently set maximum DPLL bit length
 *
 * \ingroup swd_pm 
 * 
 * \return maximum allowed period value for DPLL (see formula in DPLL_OV_PERIOD)
 */ 
uint16_t swd_get_dpll_max_period (void);


/* ############################################################################ */
/**
 * \brief Returns the bit length detected by the DPLL.
 *
 * \ingroup swd_pm 
 * 
 * \return last detected fractional value, last detected bit length
 */ 
uint16_t swd_get_dpll_last_period (void);


/* ############################################################################ */
/**
 * \brief Returns the average bit length detected by the DPLL.
 *
 * \ingroup swd_pm 
 * 
 * \return last calculated mean fractional value, last calculated mean entitlement
 */ 
uint16_t swd_get_dpll_mean_period (void);


/* ############################################################################ */
/**
 * \brief Configures override values ??for fractional and period of DPLL.
 *
 * \ingroup swd_pm 
 * 
 * \param enable_override Override Fractional and Period value for TX DPLL (must be enabled for coordinator)
 * 
 * \param period          The override value for Period. Fractional value for DPLL (  val=(3b)/2 + (2b)/4 + (1b)/8
 * 
 * \param fractional      The override value for fractional. Period value for DPLL  period=COMM frequency / busspeed
 */ 
void swd_config_dpll_override (bool enable_override, uint16_t period, uint8_t fractional);


/* ############################################################################ */
/**
 * \brief Configures start bit detection.
 *
 * \ingroup swd_pm 
 * 
 * \param start_threshold Threshold for start bit detection. Start Detection Threshold in Half Clock Cycles (0 = half Clock Cycle)
 */ 
void swd_config_startbit_detection (uint16_t start_threshold);


/* ############################################################################ */
/**
 * \brief Set length of added driven '1' after last sent Stop Bit in clock cycles
 *
 * \ingroup swd_pm 
 * 
 * \param stop_bit_ext 0 = off (only normal Stop Bit is sent) ,br>
 *                     has to match TAKEOVER and PRESTART times        
 */ 
void swd_config_stop_bit_extension(uint16_t stop_bit_ext);


/* ############################################################################ */
/**
 * \brief Configures data reconstruction.
 *
 * \ingroup swd_pm 
 * 
 * \param data_offset Offset of the sample points.
 * 
 * \param data_length Number of sample points.
 * 
 * \return 
 */ 
//void swd_config_data_reconstruction (uint8_t data_offset, uint16_t data_length);


/* ############################################################################ */
/**
 * \brief Set Data Reconstruction Sampling Offset
 *
 * \ingroup swd_pm 
 * 
 * \param data_offset Data Reconstruction Sampling Offset in Half Clock Cycles (0 = half Clock Cycle)<br>
                      has to be > 0
 */ 
void swd_set_data_offset(uint16_t data_offset);


/* ############################################################################ */
/**
 * \brief Set Data Reconstruction Sampling Length
 *
 * \ingroup swd_pm 
 * 
 * \param data_length Data Reconstruction Sampling Length in Half Clock Cycles (0 = half Clock Cycle)<br>
 *                    has to be > 0
 */ 
void swd_set_data_length(uint16_t data_length);


/* ############################################################################ */
/**
 * \brief Sets the receive timeout.
 *
 * \ingroup swd_pm 
 * 
 * \param timeout Receive timeout in bits.
 */ 
void swd_set_receive_timeout (uint8_t timeout);


/* ############################################################################ */
/**
 * \brief Sets the replacement timeout
 *
 * \ingroup swd_pm 
 * 
 * \param timeout Replacement timeout in bits. Receive timeout before replacing node in bits (0 = 1 bit)
 */ 
void swd_set_replace_timeout (uint8_t timeout);


/* ############################################################################ */
/**
 * \brief Configures the DisACK timeout.
 *
 * \ingroup swd_pm 
 * 
 * \param timeout time in clock cycles after last stop-bit while accepting DisAck
 *
 * \warning The Disack timeout should have at least a value of 10 clock cycles to avoid incorrect behavior.
 */ 
void swd_set_disack_timeout (uint16_t timeout);


/* ############################################################################ */
/**
 * \brief Activates the filter core and receiver + transmitter.
 *
 * Since the sender and the recipient can not be active at the same time,
 * Activate the receiver to deactivate the sender.
 *
 * \ingroup swd_pm
 *
 * \param comm_enable    If TRUE is given here, the
 *                       Filter core activated. Otherwise the
 *                       Filter core disabled and reset.
 * 
 * \param rx_enable      If TRUE is given here, the
 *                       Receiver + Transmitter activated. Otherwise
 *                       it is disabled.
 *
 * \remarks because of coupling of transmitter with receiver, the transmitter is also disabled when receiver is not enabled.
 */ 
void swd_config_comm (bool comm_enable, bool rx_enable);


/* ############################################################################ */
/**
 * \brief Read COMM_CONFIG - communication configuration
 *
 * \ingroup swd_pm 
 * 
 * \param comm_config current communication configuration state
 */ 
void swd_get_comm_config(swd_comm_config_t * comm_config);


/* ############################################################################ */
/**
 * \brief Ser variable idle state
 *
 * \ingroup swd_pm 
 * 
 * \param bus SWD bus instance (SWD_BUS0/SWD_BUS1) see SWD and HV-RS485 Routing in specification
 * 
 * \param variable_state enable variable idle state for SWD bus
 */ 
void swd_config_variable_state(swd_bus_t bus, bool variable_state);


/* ############################################################################ */
/**
 * \brief Set connection to DPLL, RX, Timeout, SelIn (selection of upstream bus) to SWD bus (selected by parameter bus)
 *
 * \ingroup swd_pm 
 * 
 * \param bus SWD bus instance (SWD_BUS0/SWD_BUS1) see SWD and HV-RS485 Routing in specification
 */ 
void swd_bus_select (swd_bus_t bus);


/* ############################################################################ */
/**
 * \brief  Enable repeater mode
 *
 * \ingroup swd_pm 
 * 
 * \param repeater_enable enable/disable
 */ 
void swd_config_repeater (bool repeater_enable);

/* ############################################################################ */
/**
 * \brief Configures the transmitter.
 *
 * \ingroup swd_pm 
 * 
 * \param takeover_data_disack   min. time for UART packet start in comm clock cycles = min. time for DisAck start in comm clock cycles
 * 
 * \param prestart_sync          prestart time for SYNC packet
 * 
 * \param prestart_data          prestart time for first self send data packet
 * 
 * \param end_of_sync            length of stop-bits after SYNC (length in bits = end_of_sync +1) <br>
 *                               should be min. 2 stop-bits long (end_of_sync >= 1)
 */ 
void swd_config_transmitter (uint16_t takeover_data_disack,
                                uint16_t prestart_sync,
                                uint16_t prestart_data,
                                uint8_t end_of_sync);


/* ############################################################################ */
/**
 * \brief Control DisAck2 function
 *
 * \ingroup swd_pm 
 * 
 * \param enable enabled DisAck2 function
 */ 
void swd_enable_disack2(bool enable);


/* ############################################################################ */
/**
 * \brief 
 *
 * \ingroup swd_pm 
 * 
 * \param integrator_threshold 
 * 
 * \param idle_send 
 * 
 * \param takeover 
 * 
 * \param length 
 * 
 * \param idle_detect 
 * 
 * \return 
 */ 
//void swd_config_disack2(uint16_t integrator_threshold, uint32_t idle_send, uint16_t takeover, uint8_t length, uint32_t idle_detect);


/* ############################################################################ */
/**
 * \brief Set min. time for DisAck2 start
 *
 * \ingroup swd_pm 
 * 
 * \param takeover min. time for DisAck2 start in comm clock cycles
 */ 
void swd_set_takeover_disack2(uint16_t takeover);


/* ############################################################################ */
/**
 * \brief Set length of disack2
 *
 * \ingroup swd_pm 
 * 
 * \param length length of disack2 in bits (length in bits = 3 + disack2_length)
 */ 
void swd_set_disack2_length(uint8_t length);


/* ############################################################################ */
/**
 * \brief Resets counter and minimum value in the bus statistics module.
 *        The bit is reset by the hardware.
 *
 * \ingroup swd_pm 
 */ 
void swd_reset_busstat (void);


/* ############################################################################ */
/**
 * \brief Enables or disables the bus statistics module.
 *
 * \ingroup swd_pm 
 * 
 * \param enable 
 */ 
//void swd_enable_busstat (bool enable);


/* ############################################################################ */
/**
 * \brief Sets the thresholds of the bus statistics module.
 *
 * \ingroup swd_pm 
 * 
 * \param thresholds 
 */ 
//void swd_set_busstat_thresholds (swd_busstat_thresholds_t * thresholds);


/* ############################################################################ */
/**
 * \brief Returns the minimum time between two edges.
 *        This value depends on how the DPLL integrator is configured.
 *
 * \ingroup swd_pm 
 * 
 * \return 
 */ 
//uint16_t swd_get_busstat_minvalue (void);


/* ############################################################################ */
/**
 * \brief 
 *
 * \ingroup swd_pm 
 * 
 * \param counts 
 */ 
//void swd_get_busstat_counts (swd_busstat_counts_t * counts);


/* ############################################################################ */
/**
 * \brief Get communication module status
 *
 * \ingroup swd_pm 
 * 
 * \return COMM status
 */ 
swd_comm_status_t swd_get_comm_status(void);


/* ############################################################################ */
/**
 * \brief Is the idle threshold reached on selected bus (DPLL may lock)?
 *
 * \ingroup swd_pm 
 * 
 * \return Idle threshold reached on selected bus (DPLL may lock)
 */ 
bool swd_get_comm_idle_dpll(void);


/* ############################################################################ */
/**
 * \brief Is detected bus idle state on selected bus (can be used as selin, only for repeater)?
 *
 * \ingroup swd_pm 
 * 
 * \return detected bus idle state on selected bus (can be used as selin, only for repeater)
 */ 
bool swd_get_repeater_idle_state_in(void);


/* ############################################################################ */
/**
 * \brief ???Configure idle state for repeater???
 *
 * \ingroup swd_pm 
 * 
 * \param force_state 1: force idle_state on not selected bus <br>
 *                       (can be used as selout, only for repeater)
 * 
 * \param idle_state  forced idle state on not selected bus
 */ 
void swd_set_repeater_idle_state_out(bool force_state, bool idle_state);

#endif /* HAVE_SWD_COMM_H */
