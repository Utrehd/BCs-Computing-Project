/* FPGA Release: 10512 */
#include "aout_ctrl.h"

void set_aout_ctrl_cfg(aout_ctrl_dac_sel_t dac_sel, aout_ctrl_cfg_t cfg) {
  uint32_t adr = (dac_sel == AOUT_DAC1) ? AADDR_AOUT_CTRL_CFG1 : AADDR_AOUT_CTRL_CFG0;
  WRITE_REG_16(adr, cfg.val);
}

void set_aout_ctrl_dac(aout_ctrl_dac_sel_t dac_sel, uint16_t val) {
  uint32_t adr = (dac_sel == AOUT_DAC1) ? AADDR_AOUT_CTRL_DAC1 : AADDR_AOUT_CTRL_DAC0;
  WRITE_REG_16(adr, val);
}

void set_aout_ctrl_dac_sync(aout_ctrl_dac_sel_t dac_sel, uint16_t val) {
  uint32_t adr = (dac_sel == AOUT_DAC1) ? AADDR_AOUT_CTRL_DAC1_SYNC : AADDR_AOUT_CTRL_DAC0_SYNC;
  WRITE_REG_16(adr, val);
}

aout_ctrl_cfg_t get_aout_ctrl_cfg(aout_ctrl_dac_sel_t dac_sel) {
  aout_ctrl_cfg_t cfg;
  uint32_t adr = (dac_sel == AOUT_DAC1) ? AADDR_AOUT_CTRL_CFG1 : AADDR_AOUT_CTRL_CFG0;
  cfg.val = READ_REG_U16(adr);
  return cfg;
}

uint16_t get_aout_ctrl_dac(aout_ctrl_dac_sel_t dac_sel) {
  uint32_t adr = (dac_sel == AOUT_DAC1) ? AADDR_AOUT_CTRL_DAC1 : AADDR_AOUT_CTRL_DAC0;
  return READ_REG_U16(adr);
}

uint16_t get_aout_ctrl_dac_sync(aout_ctrl_dac_sel_t dac_sel) {
  uint32_t adr = (dac_sel == AOUT_DAC1) ? AADDR_AOUT_CTRL_DAC1_SYNC : AADDR_AOUT_CTRL_DAC0_SYNC;
  return READ_REG_U16(adr);
}
