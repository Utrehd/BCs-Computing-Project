/* FPGA Release: 10512 */
#include "wdog.h"


void
wdog_init (wdog_num_t wdog, uint16_t seq_init, uint16_t seq_len, uint32_t time_interval)
{
    WRITE_REG_16(wdog + ADDR_WDOG_SEQ_INIT, seq_init);
    WRITE_REG_16(wdog + ADDR_WDOG_SEQ_LEN, seq_len);
    WRITE_REG_16(wdog + ADDR_WDOG_TIME_INTERVAL_LW,   (uint16_t) (time_interval >> 0));
    WRITE_REG_16(wdog + ADDR_WDOG_TIME_INTERVAL_HW,   (uint16_t) (time_interval >> 16));
}

void
wdog_enable (wdog_num_t wdog)
{
    WRITE_REG_16(wdog + ADDR_WDOG_COMMAND, 0x0088);
}

void
wdog_disable (wdog_num_t wdog)
{
  if ((wdog == GUARD0)||(wdog == GUARD1)||(wdog == WDOG1)){
    WRITE_REG_16(wdog + ADDR_WDOG_COMMAND, 0x0055);
  }
}

bool
wdog_is_running (wdog_num_t wdog)
{
    wdog_status_t status;
    status.val = READ_REG_U16(wdog + ADDR_WDOG_STATUS);

    return status.bf.enable ? true : false;
}


uint32_t
wdog_get_time_last_left (wdog_num_t wdog)
{

    uint16_t time_last_left_lw;
    uint16_t time_last_left_hw;
    time_last_left_lw = READ_REG_U16(wdog + ADDR_WDOG_TIME_LAST_LEFT_LW);
    time_last_left_hw = READ_REG_U16(wdog + ADDR_WDOG_TIME_LAST_LEFT_HW);

    uint32_t time_last_left = time_last_left_hw;
    time_last_left = (time_last_left << 16);
    time_last_left |= time_last_left_lw;

    return time_last_left;
}

uint32_t wdog_get_timer_val (wdog_num_t wdog)
{
    uint16_t time_last_left_lw;
    uint16_t time_last_left_hw;
    time_last_left_lw = READ_REG_U16(wdog + ADDR_WDOG_TIMER_VAL_LW);
    time_last_left_hw = READ_REG_U16(wdog + ADDR_WDOG_TIMER_VAL_HW);

    uint32_t time_last_left = time_last_left_hw;
    time_last_left = (time_last_left << 16);
    time_last_left |= time_last_left_lw;

    return time_last_left;
}

void
wdog_set_magic_cookie (wdog_num_t wdog, uint8_t magic_cookie)
{
    WRITE_REG_16(wdog + ADDR_WDOG_MAGIC_COOKIE, magic_cookie);
}


uint8_t
wdog_calc_next_cookie (const uint8_t prev_cookie)
{
    uint8_t tmp = 0x00;
    uint8_t next_cookie = 0x00;

    if (prev_cookie & 0x08) {
        tmp++;
    }
    if (prev_cookie & 0x10) {
        tmp++;
    }
    if (prev_cookie & 0x20) {
        tmp++;
    }
    if (prev_cookie & 0x80) {
        tmp++;
    }

    tmp = (tmp % 2);

    next_cookie = ((prev_cookie >> 1) & 0x7F) | (tmp << 7);

    return next_cookie;
}


bool
wdog_get_allok (wdog_num_t wdog)
{
    wdog_status_t status;
    status.val = READ_REG_U16(wdog + ADDR_WDOG_STATUS);
    return status.bf.allok ? true : false;
}

void wdog_unlock_guard(wdog_num_t wdog){
  uint8_t         cookie   = 0x3E;
  wdog_disable(wdog);
  wdog_init(wdog, cookie, 1, 0xFFFFFFFF);
  if (wdog_is_running (wdog)) {
    return;
  }
  wdog_enable(wdog);
  wdog_set_magic_cookie(wdog, cookie);
  if (!wdog_get_allok(wdog)) {
    return;
  }
}

