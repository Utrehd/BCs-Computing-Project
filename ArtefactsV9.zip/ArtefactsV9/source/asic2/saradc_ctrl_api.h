/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         saradc_ctrl_api.h
*
* @brief        SAR ADC Control API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SARADC_CTRL_API_H
#define HAVE_SARADC_CTRL_API_H

#include "errors_api.h"

/**
 * @defgroup saradc_ctrl_api ASIC2 ADC API functions
 * 
 * @ingroup  saradc_ctrl   asic2_api
 *
 * @brief    API function/definition for ADC
 *
 */
 
/**@{*/ 


/* ############################################################################ */
/**
 * @brief Enumeration which describes the ADC inputs
 */
typedef enum {
  /**
   * external general purpose 0
   */
  eSARADC_p17 = 0,
  
  /**
   * external general purpose 1
   */
  eSARADC_p18 = 1,
  
  /**
   * external general purpose 2
   */
  eSARADC_p19 = 2,
  
  /**
   * external general purpose 3
   */
  eSARADC_p20 = 3,
  
  /**
   * external general purpose 4
   */
  eSARADC_p21 = 4,
  
  /**
   * external general purpose 5
   */
  eSARADC_p25 = 5,
  
  /**
   * external general purpose 6
   */
  eSARADC_p26 = 6,
  
  /**
   * external general purpose 7
   */
  eSARADC_p27 = 7,
  
  /**
   * external general purpose 8
   */
  eSARADC_p1 = 8,
  
  /**
   * external general purpose 9
   */
  eSARADC_p2 = 9,
  
  /**
   * HV die housekeeping multiplexer <br>
   * Recommended Configuration: buffered <br>
   * Min. Required Settling Time: ? <br>
   */
  eSARADC_hv_adc = 10,
  
  /**
   * vdd3v3a (scaled) - 3.3V analog supply  <br>
   * Recommended Configuration: buffered <br>
   * Min. Required Settling Time: 1 us <br>
   */
  eSARADC_vdd3v3a = 11,
  
  /**
   * vdd3v3 (scaled) - 3.3V digital supply / IO Supply 
   * Recommended Configuration: buffered <br>
   * Min. Required Settling Time: 1 us <br>
   */
  eSARADC_vdd3v3 = 12,
  
  /**
   * vdd1v8a 1.8V analog supply 
   * Recommended Configuration: direct <br>
   * Min. Required Settling Time: 120 ns <br>
   */   
  eSARADC_vdd1v8a = 13,

  /**
   * vdd1v8a 1.8V digital supply 
   * Recommended Configuration: direct <br>
   * Min. Required Settling Time: 120 ns <br>
   */   
  eSARADC_vdd1v8 = 14,
  
  /**
   * internal temperature sensor 
   * Recommended Configuration: buffered <br>
   * Min. Required Settling Time: 1 us <br>
   */
  eSARADC_temperature = 15,
} saradc_act_api_mux_e;


/* ############################################################################ */
/**
 * @brief  Enable clocks for SARADC in CLK_NRES
 *
 * @ingroup saradc_ctrl_api 
 *
 * @param enable Enable clocks in CLKNRES
 *
 */
void saradc_ctrl_api_clock(bool enable);

/* ############################################################################ */
/**
 * @brief  Init SARADC
 *         - enable clocks for SARADC in CLK_NRES
 *         - set basic timing for ADC (needs to be improved)
 *         - no memory protection
 *
 * @ingroup saradc_ctrl_api 
 *
 */
void saradc_ctrl_api_init(void);

/* ############################################################################ */
/**
 * @brief  Get one sample from SARADC
 *         
 *
 * @ingroup saradc_ctrl_api 
 *
 * @param enable Select SARADC input
 *
 * @param enable Returns measured value 
 *
 * @return Error code
 * @retval eError_none:                                    No Error
 * @retval eError_saradc_ctrl_api_get_sample_timeout:      SARADC did not return measured sample in specific time
 */
errors_api_code_e saradc_ctrl_api_get_sample(uint8_t par_input, uint16_t *par_output);



/**@}*/ 
#endif
