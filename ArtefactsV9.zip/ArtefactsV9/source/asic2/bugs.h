/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
* @file       	bugs.h
* @brief      	List of all bugs from bug tracker - to be able to control it in firmware
*
* @author     	Pavel Dedourek
********************************************************************************
*
********************************************************************************
********************************************************************************
*/
#ifndef HAVE_BUGS_H
#define HAVE_BUGS_H


/**
********************************************************************************
********************************************************************************
* @name                         Defines
* @{
********************************************************************************
*/


#define BUG_3192_FIX 1 ///< HISPI baudrate can be up to 1/4fcomm_clk
#define BUG_4422_FIX 1 ///< Spielrequirement
#define BUG_5473_FIX 1 ///< USI:radr_new_udr
#define BUG_5474_FIX 1 ///< USI SPI slave in nss_mode=1
#define BUG_5594_FIX 1 ///< Debug level is not working
#define BUG_5625_FIX 1 ///< DEBUG_TIMER in timer.c does not work
#define BUG_6788_FIX 1 ///< Diagnose call - mailbox protection
#define BUG_6829_FIX 1 ///< Double declaration of a function in pwmn.h file
#define BUG_6851_FIX 1 ///< SAR ADC idle mode
#define BUG_6852_FIX 1 ///< SAR ADC Voltage reference
#define BUG_6854_FIX 1 ///< BUG in parameter and data profile checking  (4DD-1 running)
#define BUG_6855_FIX 1 ///< Description of ADC Voltage Ref Selcetion is wrong
#define BUG_6856_FIX 1 ///< Aout.CFG0/1.aout_oe description is wrong
#define BUG_6857_FIX 1 ///< SARADC_CTRL:buffer_on  vs direct_mode
#define BUG_6859_FIX 1 ///< DAC:CFG.aout_oe misleading description
#define BUG_6863_FIX 1 ///< Documentation - SAR ADC vdd3v3 (scaled)
#define BUG_6871_FIX 1 ///< Documentation - Temperature sensor
#define BUG_6872_FIX 1 ///< Documentation - I2C interrupts
#define BUG_6873_FIX 1 ///< Documentation - FLL_SW_CTRL register
#define BUG_6875_FIX 1 ///< Bootloader Stage1 fkt_ptr() check
#define BUG_6877_FIX 1 ///< SEL_IN voltage limmiter
#define BUG_6878_FIX 1 ///< Bootloader_force_pin_value
#define BUG_6924_FIX 1 ///< SWD Stack: QOSC speed definition missing in application config.c
#define BUG_6963_FIX 1 ///< Device Reset in test setups:swd_slave_request_host_cpu_reset() not correctly implemented
#define BUG_6964_FIX 1 ///< Bootloader - Enable to load firmware with just CCPU inside ASIC

/**
* @}
********************************************************************************
********************************************************************************
*/


#endif /* HAVE_BUGS_H */
