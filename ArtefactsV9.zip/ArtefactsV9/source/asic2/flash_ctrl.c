/* FPGA Release: 10512 */
#include "flash_ctrl.h"

void flash_ctrl_set_area_min(flash_ctrl_num_t flash_ctrl, uint8_t start_page) {
  WRITE_REG_16(flash_ctrl + ADDR_FLASH_CTRL_AREA_MIN, 0xA500 + start_page);
}

void flash_ctrl_set_area_max(flash_ctrl_num_t flash_ctrl, uint8_t end_page) {
  WRITE_REG_16(flash_ctrl + ADDR_FLASH_CTRL_AREA_MAX, 0xA500 + end_page);
}

void flash_ctrl_use_half_clock_speed(bool half_rate) {
  // Timings always provided by FLASH_CTRL0
  WRITE_REG_16(AADDR_FLASH_CTRL0_TIMING_CONFIG, 0xA500 + (uint8_t)half_rate);
}

void flash_ctrl_set_timings(flash_timings_t t) {
  // Timings always provided by FLASH_CTRL0
  WRITE_REG_16(AADDR_FLASH_CTRL0_TNVS_TNVH, t.tnvs_tnvh);                       
  WRITE_REG_16(AADDR_FLASH_CTRL0_TNVH1    , t.tnvh1    );
  WRITE_REG_16(AADDR_FLASH_CTRL0_TPGS     , t.tpgs     );
  WRITE_REG_16(AADDR_FLASH_CTRL0_TRCV     , t.trcv     );
  WRITE_REG_16(AADDR_FLASH_CTRL0_TPROG    , t.tprog    );                     
  WRITE_REG_16(AADDR_FLASH_CTRL0_TERASE   , t.terase   );
  WRITE_REG_16(AADDR_FLASH_CTRL0_TME      , t.tme      );
}

uint8_t flash_ctrl_get_page(uint32_t flash_addr){
  flash_select_t flash_select;
  flash_ctrl_decode_addr(flash_addr, &flash_select);
  return flash_select.flash_page;
}
