#ifndef _APPLICATION_CONFIG_H_
#define _APPLICATION_CONFIG_H_

#ifdef SWD_COORDINATOR_STACK
  #include "swd_SlaveObjects.h" // SWD Coordinator
#endif

#ifdef SWD_SLAVE_STACK
  #include "slave/swd_slave_config.h" // SWD device
#endif

#include <stdint.h>
#include <stdbool.h>
#include "hiad_bf.h"
#include "clk_nres_bf.h"
#include "clk_nres.h"
#include "flash_ctrl.h"
#include "el_ctrl_bf.h"

#ifdef __GNUC__
#define _PACKED_ __attribute__ ((packed))
#endif

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(push)
#pragma pack(4)
#define _PACKED_
#endif

typedef struct{
  uint32_t clock_SWD_Hz;                              ///< Communication module clock speed
  uint32_t clock_SWSUBTIMER_1_Hz;                     ///< SoftwareTimer kernel/timer module clock speed
  uint32_t clock_WDOG_Hz;                             ///< WDOG0 module clock speed
  uint32_t clock_DEBUG_UART_Hz;                       ///< Debug UART clock speed 0 -> disable debug uart
  clk_nres_cfg_ana_osc_t clk_nres_cfg_ana_osc;        ///< content of CLK_NRES.CFG_ANA_OSC register
  clk_nres_cfg_ana_pll0_t clk_nres_cfg_ana_pll0;      ///< content of CLK_NRES.CFG_ANA_PLL0 register
  clk_nres_cfg_ana_pll1_t clk_nres_cfg_ana_pll1;      ///< content of CLK_NRES.CFG_ANA_PLL1 register
  clk_nres_cfg_t clk_nres_cfg_AS0_swd_tsu;            ///< content of CLK_NRES.CFG_AS0_SWD_TSU register
  clk_nres_cfg_t clk_nres_cfg_AS1_usi0;               ///< content of CLK_NRES.CFG_AS1_USI0 register
  clk_nres_cfg_t clk_nres_cfg_AS2_usi1;               ///< content of CLK_NRES.CFG_AS2_USI1 register
  clk_nres_cfg_t clk_nres_cfg_AS3_hipsi;              ///< content of CLK_NRES.CFG_AS3_HISPI register
  clk_nres_cfg_t clk_nres_cfg_M;                      ///< content of CLK_NRES.CFG_M register
  clk_nres_cfg_rate_t clk_nres_cfg_rate;              ///< content of CLK_NRES.CFG_RATE register
  clk_nres_cfg_rate_sel_0_t clk_nres_cfg_rate_sel_0;  ///< content of CLK_NRES.CFG_RATE_SEL_0 register
  clk_nres_cfg_rate_sel_1_t clk_nres_cfg_rate_sel_1;  ///< content of CLK_NRES.CFG_RATE_SEL_1 register
  clk_nres_cfg_rate_sel_2_t clk_nres_cfg_rate_sel_2;  ///< content of CLK_NRES.CFG_RATE_SEL_2 register
  bool use_flash_half_clock_speed;                    ///< contnet of FLASH_CTRL.TIMING_CONFIG.clk_ratio - flash clock ratio to system clock 
  flash_timings_t flash_timings;                      ///< flash timin parameters (depends on system clock) 
}_PACKED_ asic2_clock_t;

typedef enum{
  BOOTLOADER_MODE_DISABLED = 0,      ///< do not go to bootloader (it does not matter what is in flash memory)
  BOOTLOADER_MODE_CRC = 1,           ///< prefered bootloder more (if expected and calculated value does not match go to bootloader mode
  
  BOOTLOADER_MODE_COOKIE = 0xff,     ///< goto bootloader mode when expected value in flash contains all ones or all zeros
}_PACKED_ bootloader_mode_t;


typedef struct{
  uint32_t bootloader_flash0_crc16_start_addr;  ///< Where Flash0 starts - for bootloader mode crc checksum check
  uint32_t bootloader_flash0_crc16_length;      ///< Flash0 size - for bootloader mode crc checksum check
  uint32_t bootloader_flash1_crc16_start_addr;  ///< Where Flash1 starts - for bootloader mode crc checksum check - must be also in single core mode valid
  uint32_t bootloader_flash1_crc16_length;      ///< Flash1 size - for bootloader mode crc checksum check - must be also in single core mode valid
  uint8_t  bootloader_mode;                     ///< 1=cookie mode, see bootloader_mode_t
  uint16_t bootloader_force_pin_mask;           ///< bit pin mask for entry to bootloader mode
  uint8_t  bootloader_force_pin_group;          ///< bit pin group for entry to bootloader mode, off=0xFF
  uint8_t  bootloader_force_pin_value;          ///< The level on pad which tell to bootloader when to entry boortloader mode
  uint8_t  bootloader_dualcore;                 ///< It is dualcore application (true), DO NOT CHANGE
  uint8_t  bootloader_rez[3];                   ///< reserved
}_PACKED_ bootloader_cfg_t;

typedef enum{
  REPEATER_OFF = 0,
  REPEATER_RS485 = 1,
  REPEATER_LWL_UP = 2,   // Koordinator side
  REPEATER_LWL_DOWN = 3, // Bus side
  REPEATER_HV_PHY = 4,   // uses HV-addon board
}_PACKED_ repeater_type_t;

typedef struct{
  uint8_t   year_lb; ///< +226=>0xe2
  uint8_t   year_hb; ///< 1792=0x0700
  uint8_t   month;   ///< production month
  uint8_t   day;     ///< production day
  uint8_t   hour;    ///< production hour 24:
  uint8_t   minute;  ///< production minute
  uint8_t   line;       ///< production line 
  uint8_t   location;   ///< prodaction location
  uint8_t   sw_major;   ///< software application major number
  uint8_t   sw_minor;   ///< software application minor number
  uint8_t   aCfg[4];    // def. CFG, additional configuration for smart wire
  uint8_t   vpfi_low;   // Power Fail indicator - low limit - PFI reset 
  uint8_t   vpfi_high;  // Ppwer Fail indicator - high limit - min V for startup
} _PACKED_ production_data_t; // SWD_prog product progr. (*.ini)

typedef struct{
  uint16_t          struct_version_tag; ///< version of mailbox
  uint8_t           product_name[32];   ///< Produkt name, ascii
  uint8_t           vendor_id;          ///< VendorID: Moeller-RMQ = 0x81 (verlorene Parameter=0x01)
  uint8_t           device_id;          ///< DeviceID:     0xFD =  FFFF____KK_LL
  uint8_t           sw_ver;             ///< Software version of application 
  uint8_t           hw_ver;             ///< Hardware version of application
  bootloader_cfg_t  bootloader_cfg;     ///< Bootloader configuration see bootloader_cfg_t
  repeater_type_t   repeater_type;      ///< SWD repeater configuration
  uint8_t           jtag_dio;           ///< JTAG or Serial Wire Debug is used
  
  asic2_clock_t     asic2_clock;        ///< clock system configuration
 
  uint8_t           device_options;     ///< SWD device oprionts
  
  uint8_t           disable_watchdog_for_development_only; ///< Disable watchdog WDOG0 functionality (only for debug)
  uint8_t           use_GPO_SWD_LED_and_not_EL;  ///< status LED is connected only to GPO or to electronic label function
  
  uint8_t           reserved1[139];
  
  production_data_t production_data;    ///< Production data see production_data_t
    
  uint8_t           product_custom_paramter[84]; 
  
  uint8_t           reserved2[140];
  
  uint16_t          crc16; ///< absolute
  
} _PACKED_ application_config_t; //512 - 4Bytes bootloader CRC of the flash


#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(pop)
#endif 

#endif
