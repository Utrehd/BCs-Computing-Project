/* FPGA Release: 10512 */
#include "saradc_ctrl_list_helper.h"
#include "pwmn.h"
#include "stdio.h"

//helper functions

void print_list_command(sarc_command_type_t *cmd, bool verbose){
  int i;
  for(i=0; i<3; i++){
    printf("L%d = {0x%4x}\n", i, *(((uint16_t*)cmd)+i));  
  }
  if (verbose){
   printf("target_adr = 0x%x" , (*cmd).list_entry.target_adr); 
   printf("no_sample = 0x%x" , (*cmd).list_entry.no_sample); 
   printf("no_sum = 0x%x" , (*cmd).list_entry.no_sum); 
   printf("ch_no = 0x%x" , (*cmd).list_entry.ch_no); 
   printf("trigger_type = 0x%x" , (*cmd).list_entry.trigger_type); 
   printf("trigger = 0x%x" , (*cmd).list_entry.trigger); 
  }
}

void new_SARC_COMMAND_MPWM(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t pwm_phase){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_MPWM(target_adr, TADR_mode, no_sample,no_sum,ch_no,pwm_phase)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_MBP(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t base_phase){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_MBP(target_adr, TADR_mode, no_sample,no_sum,ch_no,base_phase)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_MDTE(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t wait_time, uint16_t dte_mask){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_MDTE(target_adr, TADR_mode, no_sample,no_sum,ch_no, wait_time, dte_mask)};
  *cmd = cmd_temp;
}

void start_list(uint16_t * list_adr, bool list_skip){
  saradc_ctrl_sadr_new_t sadr_new = {(uint16_t)(uint32_t)list_adr | (list_skip ? 1 : 0)};
  saradc_ctrl_set_sadr_new(sadr_new);
}

void new_SARC_COMMAND_MIMM_SE(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t sampling_extension){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_MIMM_SE(target_adr, TADR_mode, no_sample,no_sum,ch_no, sampling_extension)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_MIMM(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_MIMM(target_adr, TADR_mode, no_sample,no_sum,ch_no)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_SMUX(sarc_command_type_t *cmd, uint16_t ch_no, uint16_t trigger_type, uint16_t trigger){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_SMUX(ch_no, trigger_type, trigger)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_SMUX_SET_TADR(sarc_command_type_t *cmd, uint16_t target_adr, uint16_t ch_no, uint16_t trigger_type, uint16_t trigger){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_SMUX_SET_TADR(target_adr, ch_no, trigger_type, trigger)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_SMUXIMM(sarc_command_type_t *cmd, uint16_t ch_no){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_SMUX(ch_no, 2, SARC_TRIGGER_SMUXIMM)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_SMUXIMM_SET_TADR(sarc_command_type_t *cmd, uint16_t target_adr, uint16_t ch_no){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_SMUX_SET_TADR(target_adr, ch_no, 2, SARC_TRIGGER_SMUXIMM)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_ANOOR_N(sarc_command_type_t *cmd, uint16_t N, uint16_t u_bound, uint16_t l_bound){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_ANOOR_N(N,u_bound,l_bound)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_AOOR_N(sarc_command_type_t *cmd, uint16_t N, uint16_t u_bound, uint16_t l_bound){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_AOOR_N(N,u_bound,l_bound)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_BUS_WRITE(sarc_command_type_t *cmd, uint16_t data, uint16_t adr){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_BUS_WRITE(data, adr)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_WAIT(sarc_command_type_t *cmd, uint16_t wait_cycles){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_WAIT(wait_cycles)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_WRITE_CFG(sarc_command_type_t *cmd, uint16_t cfg){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_WRITE_CFG(cfg)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_LOOP_TADR(sarc_command_type_t *cmd, uint16_t u_bound, uint16_t l_bound){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_LOOP_TADR(u_bound, l_bound)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_LOOP_NTADR(sarc_command_type_t *cmd, uint16_t u_bound, uint16_t l_bound){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_LOOP_NTADR(u_bound, l_bound)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_LOOP_BP(sarc_command_type_t *cmd, uint16_t u_bound, uint16_t l_bound){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_LOOP_BP(u_bound, l_bound)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_LOOP_NBP(sarc_command_type_t *cmd, uint16_t u_bound, uint16_t l_bound){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_LOOP_NBP(u_bound, l_bound)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_GOTO_SUMLEQ(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t compare_val){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_GOTO_SUMLEQ(target_adr, compare_val)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_GOTO_SUMNLEQ(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t compare_val){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_GOTO_SUMNLEQ(target_adr, compare_val)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_GOTO_BPLEQ(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t compare_val){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_GOTO_BPLEQ(target_adr, compare_val)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_GOTO_BPNLEQ(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t compare_val){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_GOTO_BPNLEQ(target_adr, compare_val)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_GOTO(sarc_command_type_t *cmd, uint16_t *target_adr){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_GOTO(target_adr)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_END(sarc_command_type_t *cmd){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_END()};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_SYNC_EVT(sarc_command_type_t *cmd){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_SYNC_EVT()};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_ST_BP(sarc_command_type_t *cmd, uint16_t * target_adr, uint16_t TADR_mode){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_ST_BP(target_adr, TADR_mode)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_ST_TADR(sarc_command_type_t *cmd, uint16_t * target_adr, uint16_t TADR_mode){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_ST_TADR(target_adr, TADR_mode)};
  *cmd = cmd_temp;
}

void new_SARC_COMMAND_MIMM_HIST(sarc_command_type_t *cmd, uint16_t *target_adr, uint16_t TADR_mode, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no){
  sarc_command_type_t cmd_temp = {__SARC_COMMAND_MIMM_HIST(target_adr, TADR_mode, no_sample,no_sum,ch_no)};
  *cmd = cmd_temp;
}


void wait_for_list_done(){
  while (!(saradc_ctrl_get_irq_status().val & (1<<SARADC_CTRL_IRQ_SADR_DONE_NEMPTY)));
  saradc_ctrl_get_sadr_done();
}

void saradc_ctrl_stop_pwmn(){
  
  pwmn_set_cnt_max_reload((pwmn_cnt_max_reload_t)2047);

  pwmn_cmd_t cmd_pwmn;
  cmd_pwmn.val = 0;
  cmd_pwmn.bf.run = 0;
  cmd_pwmn.bf.restart = 1;
  pwmn_set_cmd(cmd_pwmn);

  //pwmn_pwm_cfg_t pwm_cfg_pwmn;
  //pwm_cfg_pwmn.val = 0;
  //pwm_cfg_pwmn.bf.c_src = 1;
  //pwmn_set_pwm_cfg(pwm_cfg_pwmn,(uint8_t)0);
  //pwmn_set_pwm_cfg(pwm_cfg_pwmn,(uint8_t)1);
  //pwmn_set_pwm_cfg(pwm_cfg_pwmn,(uint8_t)2);

  pwmn_pwm_on_t pwm_on;
  pwm_on.val = 0;
  pwm_on.bf.hs = 1;
  pwm_on.bf.ls = 1;
  pwmn_set_pwm_on(pwm_on,(uint8_t)0);
  pwmn_set_pwm_on(pwm_on,(uint8_t)1);
  pwmn_set_pwm_on(pwm_on,(uint8_t)2);

  pwmn_set_dead_time_reload((pwmn_dead_time_reload_t)5);
  
}
        
void saradc_ctrl_start_pwmn(){
  
	pwmn_set_cnt_max_reload_u16(4);
  pwmn_set_cnt_max_reload((pwmn_cnt_max_reload_t)255);
  pwmn_set_prescaler_u16((uint16_t)1);
  pwmn_set_prescaler_reload((uint16_t)1);

  pwmn_cmd_t cmd_pwmn;
  cmd_pwmn.val = 0;
  cmd_pwmn.bf.run = 1;
  pwmn_set_cmd(cmd_pwmn);                                  

  //pwmn_pwm_cfg_t pwm_cfg_pwmn;
  //pwm_cfg_pwmn.val = 0;
  //pwm_cfg_pwmn.bf.c_src = 1;
  //pwmn_set_pwm_cfg(pwm_cfg_pwmn,(uint8_t)0);
  //pwmn_set_pwm_cfg(pwm_cfg_pwmn,(uint8_t)1);
  //pwmn_set_pwm_cfg(pwm_cfg_pwmn,(uint8_t)2);

  pwmn_pwm_on_t pwm_on;
  pwm_on.val = 0;
  pwm_on.bf.hs = 1;
  pwm_on.bf.ls = 1;
  pwmn_set_pwm_on(pwm_on,(uint8_t)0);
  pwmn_set_pwm_on(pwm_on,(uint8_t)1);
  pwmn_set_pwm_on(pwm_on,(uint8_t)2);

  pwmn_set_dead_time_reload((pwmn_dead_time_reload_t)5);
  
}


//example applications

// single shot or continuous background conversion of multiple ADC channels.
// Creates the following list:
// 1. The ADC is powered up. Waits until ADC has powered up.
// 2. For each ADC channel no_sum conversions performed and summed up. The sum is written to the array *target_adr.
// 3. The ADC is powered down.
// Parameters
//   target_adr: array of uint16_t values for the sums. Must have no_ones(ch_mask) length.
//   ch_mask: bitN=1 <=> channel no bitN is converted
//   no_sum: 1..16 number of samples to sum up per channel 
//void sarc_app_create_simple_list(uint16_t *target_adr, uint16_t ch_mask, uint16_t no_sum)


