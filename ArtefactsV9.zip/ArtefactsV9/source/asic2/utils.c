#include "utils.h"
#include "hardware.h"

#ifdef SWD_SLAVE_STACK 
  #include "swd_device_db_file.h"
#endif


#include <hardware.h>
#include "clk_nres_api.h"
#include "bugs.h"       // for BUG_6963_FIX!

#ifdef SWD_SLAVE_STACK 
  #include "swd_device_db_file.h"
#endif

const uint16_t onehot16[16] = {
	0x0001,
	0x0002,
	0x0004,
	0x0008,
	0x0010,
	0x0020,
	0x0040,
	0x0080,
	0x0100,
	0x0200,
	0x0400,
	0x0800,
	0x1000,
	0x2000,
	0x4000,
	0x8000
};

bool div_u16(uint16_t x, uint16_t y, uint16_t * div, uint16_t * mod){
  uint32_t q,z,foo;
  switch(y){
  case 0:
    return false;
  case 16:
    *div = x >> 4;
    *mod = x & 15;
    return true;
  default:
    q = 0;
    while( 1 == 1 ){
      z   = 1;
      foo = y;
      while( foo <= x ){
        foo <<= 1;
        z <<= 1;
      };
      if ( z == 1 ){
        *mod = x;
        *div = q;
        return true;
      };
      x -= foo >> 1;
      q += z >> 1;
    };
  }
}

void wait_cpu_cycles(uint32_t time){
  volatile uint32_t delay = time;
  while(delay){
    delay--;
  }
}


#if defined (SEGGER_RTT_UART)
#include <yfuns.h>
#include "SEGGER_RTT.h"
#warning "Segger RTT Uart"
size_t __write(int handle, const unsigned char * buffer, size_t size);

size_t __write(int handle, const unsigned char * buffer, size_t size) {
  (void) handle;  /* Not used, avoid warning */
  SEGGER_RTT_Write(0, (const char*)buffer, size);
  return size;
}

size_t __write_buffered(int handle, const unsigned char * buffer, size_t size) {
  (void) handle;  /* Not used, avoid warning */
  SEGGER_RTT_Write(0, (const char*)buffer, size);
  return size;
}

void uart_init_baudrate ( uint32_t baudrate ){
    SEGGER_RTT_ConfigUpBuffer(0, NULL, NULL, 0, SEGGER_RTT_MODE_BLOCK_IF_FIFO_FULL);
}

#elif defined (PHYSICAL_UART)
#warning "physical Uart"
static uart_num_t uart_debug = UART;

size_t __write (int fd, const unsigned char *buffer, size_t len);

int putchar (int ch){
    uart_send_byte (uart_debug, ch);
    if (ch == '\n') {
        uart_send_byte (uart_debug, '\r');
    }
    return ch;
}


int getchar (void){
    uint8_t data;
    if (uart_recv_byte (uart_debug, &data)) {
        return data;
    } else {
        return EOF;
    }
}

size_t __write (int fd, const unsigned char *buffer, size_t len){
    int nChars = 0;
    for ( /*Empty */ ; len > 0; --len) {
        putchar (*buffer++);
        nChars++;
    }
    return nChars;
}


void uart_init_baudrate ( uint32_t baudrate )
{
        uint32_t clk;
	uint16_t divider;
	uint16_t fractional;

        //clk = application_config.asic2_clock.clock_DEBUG_UART_Hz;
        
        if(clk_nres_api_get_module_clock(CLKPNO_UART, &clk)!=eError_none) {
          // No correct clock freq. value get for UART */
          while(1);
        }
        
	divider = ( clk / baudrate ) - 1;
	fractional = ( ( ( clk * 4 ) / baudrate ) ) & 0x3;
    wdog_unlock_guard(GUARD0);
    io_ctrl_guard_unlock();
    
#ifdef UTILS_UART_IOMUX_PAD_RX
    io_ctrl_config_sel(UTILS_UART_IOMUX_PAD_RX, IO_UART_OE_RX);
    io_ctrl_config_sel(UTILS_UART_IOMUX_PAD_TX, IO_UART_TX);
#else    
    #ifdef FPGA_BOARD
      //usecase 0, 2, 4,5,6,7,8, 
      io_ctrl_config_sel(IOMUX_PAD29, IO_UART_OE_RX);
      io_ctrl_config_sel(IOMUX_PAD28, IO_UART_TX);
    #else
      //Evaluation Board
      io_ctrl_config_sel(IOMUX_PAD16, IO_UART_OE_RX);
      io_ctrl_config_sel(IOMUX_PAD10, IO_UART_TX);
    #endif
#endif      
    io_ctrl_guard_lock();
    wdog_disable(GUARD0);
    uart_init(uart_debug, divider, fractional, UART_DATA_LEN_8, UART_PARITY_NONE, UART_ONE_STOP);
}

#else
/* ########################################################################## */    
/* ########################################################################## */    
/* ########################################################################## */    
#warning "no debug output"

/* ########################################################################## */    
int putchar (int ch) {
  return ch;
}

/* ########################################################################## */    
int getchar (void) {
  return EOF;
}

/* ########################################################################## */    
size_t __write (int fd, const unsigned char *buffer, size_t len){
    int nChars = 0;
    for ( /*Empty */ ; len > 0; --len) {
        putchar (*buffer++);
        nChars++;
    }
    return nChars;
}

/* ########################################################################## */    
void uart_init_baudrate ( uint32_t baudrate ) {
}
#endif // (SEGGER_RTT_UART)








/* ########################################################################## */    
#ifdef SWD_SLAVE_STACK 
  void utils_print_project_name(void) {
#ifdef SWD_DEVICE_DB_DEVICE
  printf("==================================================\n");
  printf("Project: %s project\n", SWD_DEVICE_DB_DEVICE);
  printf("==================================================\n");
#endif
}
#endif

/* ########################################################################## */    
void utils_reset_all_blocks(void) {
  wdog_unlock_guard(GUARD0);
  clk_nres_guard_enable(CLK_NRES_0);

  for(clkpno_t i_clk_part=CLKPNO_CRC0;i_clk_part<=CLKPNO_COUNT;i_clk_part++) {
    
    if (i_clk_part == CLKPNO_GUARD0 ) {
      continue;
    }
    if ( i_clk_part == CLKPNO_GUARD1 ) {
      continue;
    }
    /*
    if ( i_clk_part == CLKPNO_IO_CTRL ) {
      continue;
    }
    if ( i_clk_part == CLKPNO_UART ) {
      continue;
    }
    */
   
    clk_nres_set_nreset(i_clk_part, false);  
    /*clk_nres_set_nreset(i_clk_part, true);*/
  }
  clk_nres_set_as_nreset(AS_SWD_TSU,false);
  clk_nres_set_as_nreset(AS_USI0,false);
  clk_nres_set_as_nreset(AS_USI1,false);
  clk_nres_set_as_nreset(AS_HISPI,false);
  
  clk_nres_guard_disable(CLK_NRES_0);
  wdog_disable (GUARD0); // GUARD disable
  while (wdog_is_running (GUARD0))  ;     
}

// #############################################################################
bool utils_cmp_in_range(uint32_t par_low, uint32_t par_value, uint32_t par_high) {
  if ((par_low <= par_value) && (par_value <= par_high)) {
    return(true);
  }
  else {
    return(false);
  }
}


// #############################################################################
bool g_utils_ResetRequest=false;

// #############################################################################
void utils_reset_register(void) {
  g_utils_ResetRequest=true;
}

// #############################################################################
/*
 * solution for the reset properties of the SWD Device is for our tests to get the right system behavior for: 
 * renew (setnew), baudrate change, cycle dat/mailbox.. timeout, command reset ..).
 * That�s not possible, if you don�t return directly from �swd_slave_request_host_cpu_reset()� in ACPU, 
 * because you get the slow time_out WD which generate trouble during setnew, baudrate change, cyclic data timeout in SWD system!
 *
 * Due to this fact we have to reset ACPU on ResetRequest
 */

void utils_reset_exec(void) {
  if( g_utils_ResetRequest )
  {
#ifdef DEBUG
    NVIC_SystemReset();
#else
    /* make an ASIC hardware reset by cookie failure in WDOG1*/
    
    /* enable GUARD1 to enable access to WDOG1 */
    wdog_unlock_guard(GUARD1);
    
    wdog_unlock_guard(WDOG1);
    
    /* send wrong cookie - generate reset by WDOG1 */
    wdog_set_magic_cookie(WDOG1, 0x00);
#endif
  }
}