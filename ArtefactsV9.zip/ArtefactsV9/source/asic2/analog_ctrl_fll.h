/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         analog_ctrl_fll.h
*
* @brief        Analog Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __ANALOG_CTRL_FLL_H__
#define __ANALOG_CTRL_FLL_H__

#include "device.h"

#include "utils.h"
#include "analog_ctrl_bf.h"

/* ############################################################################ */
/**
 * \brief   Function to set the configuration of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \param config FLL configuration
 *
 * \note analog_ctrl_fll_config_t: <br>
 *              bits 4:0 - eval_rate: Clk divider of lf-osc "1 << eval_rate" clock-cycles of lf clock are measured <br>
 *              bit 15 - freeze: do not change trim_val <br>
 */
void analog_ctrl_fll_set_config(analog_ctrl_fll_config_t config);

/* ############################################################################ */
/**
 * \brief   Function to read FLL configuration
 *
 * \ingroup analog_ctrl
 * 
 * \return Current FLL configuration
 */
analog_ctrl_fll_config_t analog_ctrl_fll_get_config(void);

/* ############################################################################ */
/**
 * \brief   Function to set the evaluation rate of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \param eval_rate Clk divider of lf-osc "1 << eval_rate" clock-cycles of lf clock are measured
 *
 */
void analog_ctrl_fll_set_eval_rate(uint8_t eval_rate);

/* ############################################################################ */
/**
 * \brief   Function to lock the trim_val value
 *
 * \ingroup analog_ctrl
 * 
 * \param freeze do not change trim_val
 *
 */
void analog_ctrl_fll_set_freeze(bool freeze);

/* ############################################################################ */
/**
 * \brief   Function to read FLL evaluation value (eval_val)
 *
 * \ingroup analog_ctrl
 * 
 * \return Measured number of HF clock-cycles during divided LF clock-cycles
 */
uint16_t analog_ctrl_fll_get_eval_val(void);

/* ############################################################################ */
/**
 * \brief   Function to set value of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \param val target number of HF clock-cycles during divided LF clock-cycles
 *
 */
void analog_ctrl_fll_set_val(uint16_t val);

/* ############################################################################ */
/**
 * \brief   Function to read value of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \return Measured number of HF clock-cycles during divided LF clock-cycles
 */
uint16_t analog_ctrl_fll_get_val(void);

/* ############################################################################ */
/**
 * \brief   Function to set range of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \param val allowed range for target
 *
 */
void analog_ctrl_fll_set_range(uint16_t val);

/* ############################################################################ */
/**
 * \brief   Function to read range of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \return allowed range for target
 */
uint16_t analog_ctrl_fll_get_range(void);

/* ############################################################################ */
/**
 * \brief   Function to set software control value of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \param trim_val when use_sw = 1
 *
 */
void analog_ctrl_fll_set_sw_ctrl(analog_ctrl_fll_sw_ctrl_t sw_ctrl);

/* ############################################################################ */
/**
 * \brief   Function to read software control value of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \return trim_val when use_sw = 1
 */
analog_ctrl_fll_sw_ctrl_t analog_ctrl_fll_get_sw_ctrl(void);

/* ############################################################################ */
/**
 * \brief   Function to activate software control of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \param use_sw 1: enable software control trim_val = sw_val
 *
 */
void analog_ctrl_fll_set_use_sw(bool use_sw);

/* ############################################################################ */
/**
 * \brief   Function to read trimmer value of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \return Current value applied to osc
 */
uint8_t analog_ctrl_fll_get_trim_val(void);

/* ############################################################################ */
/**
 * \brief   Function to read status of FLL
 *
 * \ingroup analog_ctrl
 * 
 * \return Current status of FLL 
 *
 * \note analog_ctrl_fll_status_t: <br>
 *              bit 0 - eval_gt: Osc is too fast <br>
 *              bit 1 - eval_lw: Osc is too slow <br>
 */
analog_ctrl_fll_status_t analog_ctrl_fll_get_status(void);

/* ############################################################################ */
/**
 * \brief   Function to read if the FLL is locked
 *
 * \ingroup analog_ctrl
 * 
 * \return 1: FLL is locked. 0: FLL is not locked
 */
bool analog_ctrl_fll_is_locked(void);

/**@} */
#endif /* __ANALOG_CTRL_FLL_H__ */
