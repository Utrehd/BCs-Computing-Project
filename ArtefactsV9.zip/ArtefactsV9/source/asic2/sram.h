/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         sram.h
*
* @brief        SRAM Parameters
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __SRAM_H__
#define __SRAM_H__

/**
 * \defgroup sram ASIC2 SRAM HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Address, size SRAM definition
 */
/**@{*/ 

#define SRAM_SIZEE        0x2000 ///< SRAME size [B]
#define SRAM_SIZE0        0x2000 ///< SRAM0 size [B]
#define SRAM_SIZE1        0x2000 ///< SRAM1 size [B]

#define BASE_ADDR_SRAM    0x20000000                     ///< Base address for SRAMs
#define BASE_ADDR_SRAME   BASE_ADDR_SRAM                 ///< Base address for SRAME
#define BASE_ADDR_SRAM0   (BASE_ADDR_SRAME + SRAM_SIZEE) ///< Base address for SRAM0
#define BASE_ADDR_SRAM1   (BASE_ADDR_SRAM0 + SRAM_SIZE0) ///< Base address for SRAM1

#define SRAM_SIZE         (SRAM_SIZEE + SRAM_SIZE0 + SRAM_SIZE1)  ///< SRAMs size [B]

/**@} */

#endif /* __SRAM_H__ */
