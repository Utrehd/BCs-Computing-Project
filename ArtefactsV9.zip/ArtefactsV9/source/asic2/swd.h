/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swd.h
*
* @brief        SWD_PM HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SWD_H
#define HAVE_SWD_H

/**
 * \defgroup swd_pm ASIC2 SWD_PM HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control SWD_PM
 */
/**@{*/ 

#include <device.h>


#include <swd_bf.h>
#include <swd_irq.h>

#include <swd_types.h>

#include <swd_comm.h>
#include <swd_dma.h>
#include <swd_pe.h>
#include <swd_sap.h>
#include <swd_irq.h>

/**@} */
#endif /* HAVE_SWD_H */
