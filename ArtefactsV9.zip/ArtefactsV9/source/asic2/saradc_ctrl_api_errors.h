/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         circular_buffer_api_errors.h
*
* @brief        Error handler for SARADC Ctrl API functions
*
* @author       Dedourek Pavel, Cid Mateo
*
********************************************************************************
*
********************************************************************************
********************************************************************************
*/

/**
 * \ingroup error_api
 */
#ifndef __SARADC_CTRL_API_ERRORS__
#define __SARADC_CTRL_API_ERRORS__

#define SARADC_CTRL_API_ERRORS_CODES                                           \
  /**                                                                          \
   * SARADC did not return measured sample in specific time                    \
   */                                                                          \
  eError_saradc_ctrl_api_get_sample_timeout                                                                                 
    
#endif
 
