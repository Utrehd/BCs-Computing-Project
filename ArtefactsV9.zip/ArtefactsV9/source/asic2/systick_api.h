/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         systick_api.h
*
* @brief        Systick API functions
*
* @author       Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __SYSTICK_API__
#define __SYSTICK_API__

#include "stdint.h"
#include "errors_api.h"

/**
 * \defgroup systick_api ASIC2 systick API functions
 *
 * \ingroup  asic2_api
 *
 * \brief    API function to control GPIO
 *
 */

/* ############################################################################ */
/**
 * \brief  Initializes systick
 *         The function initializes systick with the load_cycles value.
 *         The systick works as a countdown from load_cycles to zero, every time
 *         reaches zero it calls the callback function.
 *         
 *         The countdown speed is the system clock frequency. Example:
 *         To have a coundown of 10 ms
 *
 * \ingroup systick_api 
 *
 *              systick_init(  );
 *
 * \param load_cycles Value to load in systick
 *
 * \return error code
 */
errors_api_code_e systick_api_init( uint32_t load_cycles );

/* ############################################################################ */
/**
 * \brief  Set the callback function for systick
 *         The function written as a parameter will be call when systick value
 *         reaches zero. Example
 *
 *              systick_callback( function_example );
 *
 * \ingroup systick_api 
 *
 * \param ptr_callback_irq Function to be call
 */
void systick_api_callback( void (*ptr_callback_irq)(void) );

/* ############################################################################ */
/**
 * \brief It gets the time from last reset of internal Systick variable in [load_cycles]
 *
 * \ingroup systick_api 
 *
 * \return the time from last reset of internal Systick variable in [load_cycles]
 */
uint32_t systick_api_get_value(void);

/* ############################################################################ */
void systick_api_clr(void);


/* ############################################################################ */
/**
 * \brief This function waits specific time defined by parameter in load_cycles units
 *
 * \ingroup systick_api 
 *
 * \param i_wait_for_load_cyces wait this number of load cycles
 */
void systick_api_delay(uint32_t i_wait_for_load_cyces);

#endif