/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         flash_ctrl.h
*
* @brief        FLASH Controller API functions
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_FLASH_CTRL_API_H
#define HAVE_FLASH_CTRL_API_H

#include "errors_api.h"

/**
 * \defgroup flash_ctrl_api ASIC2 FLASH Controller API functions
 * 
 * \ingroup  flash_ctrl   asic2_api
 *
 * \brief    API Functions to control FLASH Controller
 */
/**@{*/ 

#include "device.h"


/* ############################################################################ */
/**
 * \brief Set flash timming according to system frequency
 *
 * \ingroup flash_ctrl_api
 *
 * \return  clk_nres_api status
 */ 
errors_api_code_e flash_ctrl_api_set_timings(void);

/* ############################################################################ */
/**
 * \brief Set flash timming according to system frequency
 *
 * \ingroup flash_ctrl_api
 *
 * \return  success
 */ 
bool flash_ctrl_api_page_erase(uint32_t page_base_addr);


/**@} */
#endif /* HAVE_FLASH_CTRL_API_H */

