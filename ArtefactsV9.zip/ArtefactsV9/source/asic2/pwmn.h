/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         pwmn.h
*
* @brief        PWMN HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __PWMN_H__
#define __PWMN_H__

/**
 * \example example_pwmn.c
 * This is an example of how to use PWMN module
 */

/**
 * \defgroup pwmn ASIC2 PWMN HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control PWMN
 *
 * \details See code example: @include example_pwmn.c
 */
/**@{*/ 

#include "device.h"

#include "pwmn_bf.h"
#include "pwmn_irq.h"





/* ======================================================================= */
/* MODULE HANDLING                                                         */
/* ======================================================================= */

//SETTER

/* ############################################################################ */
/**
 * \brief Function to set PWMN configuration
 *
 * \ingroup pwmn 
 * 
 * \param cfg                  Desired configuration for PWMN
 *                             \see pwmn_cfg_t
 */ 
void pwmn_set_cfg(pwmn_cfg_t cfg);

/* ############################################################################ */
/**
 * \brief Function to set PWMN command
 *
 * \ingroup pwmn 
 * 
 * \param cmd                  Desired command for PWMN
 *                             \see pwmn_cmd_t
 */ 
void pwmn_set_cmd(pwmn_cmd_t cmd);

/* ############################################################################ */
/**
 * \brief Function to set PWMN counter
 *
 * \ingroup pwmn 
 * 
 * \param cnt                  Desired counter value
 */ 
void pwmn_set_cnt(pwmn_cnt_t cnt);

/* ############################################################################ */
/**
 * \brief Function to set PWMN prescaler
 *
 * \ingroup pwmn 
 * 
 * \param prescaler            Desired prescaler value
 */ 
void pwmn_set_prescaler(pwmn_prescaler_t prescaler);

/* ############################################################################ */
/**
 * \brief Function to set PWMN maximum counter value
 *
 * \ingroup pwmn 
 * 
 * \param cnt_max              Desired maximum counter value
 *                             \note Permitted range: <br>
 *                                   for CFG.mode=*sawtooth: 0..2^16-1 <br>
 *                                   for CFG.mode=*triangle: 0..2^15-1
 */ 
void pwmn_set_cnt_max(pwmn_cnt_max_t cnt_max);

/* ############################################################################ */
/**
 * \brief Function to set PWMN NTH start value
 *
 * \ingroup pwmn 
 * 
 * \param nth_start            Decremented at the start of every period. The start_evt and the associated reload actions are only performed when NTH_START=0
 */ 
void pwmn_set_nth_start(pwmn_nth_start_t nth_start);

/* ############################################################################ */
/**
 * \brief Function to set PWMN dead time
 *
 * \ingroup pwmn 
 * 
 * \param dead_time            0..MAX <br>
 *                             0: dead time is disabled, hs and ls outputs change simultaneously
 */ 
void pwmn_set_dead_time(pwmn_dead_time_t dead_time);

/* ############################################################################ */
/**
 * \brief Function to set PWMN prescaler reload
 *
 * \ingroup pwmn 
 * 
 * \param prescaler_reload     Transferred to PRESCALER after it reached 0
 */ 
void pwmn_set_prescaler_reload(pwmn_prescaler_reload_t prescaler_reload);

/* ############################################################################ */
/**
 * \brief Function to set PWMN maximum counter reload
 *
 * \ingroup pwmn 
 * 
 * \param cnt_max_reload       Desired maximum counter reload value
 *                             \note Permitted range: <br>
 *                                   for CFG.mode=*sawtooth: 0..2^16-1 <br>
 *                                   for CFG.mode=*triangle: 0..2^15-1
 */ 
void pwmn_set_cnt_max_reload(pwmn_cnt_max_reload_t cnt_max_reload);

/* ############################################################################ */
/**
 * \brief Function to set PWMN NTH start reload
 *
 * \ingroup pwmn 
 * 
 * \param nth_start_reload     Transferred to NTH_START after it reached 0
 */ 
void pwmn_set_nth_start_reload(pwmn_nth_start_reload_t nth_start_reload);

/* ############################################################################ */
/**
 * \brief Function to set PWMN dead time reload
 *
 * \ingroup pwmn 
 * 
 * \param dead_time_reload     0..MAX <br>
 *                             0: dead time is disabled, hs and ls outputs change simultaneously
 */ 
void pwmn_set_dead_time_reload(pwmn_dead_time_reload_t dead_time_reload);

/* ############################################################################ */
/**
 * \brief Function to set individual PWMN configuration
 *
 * \ingroup pwmn 
 * 
 * \param cfg                  00: ps[?]=1 when pwm?_C0 > CNT otherwise ps[?]=0 <br>
 *                             01: ps[?]=0 when pwm?_C0 > CNT otherwise ps[?]=1 <br>
 *                             10: ps[?]=0 when start_evt <br>
 *                                 ps[?]=1 when pwm?_C0=CNT (has priority over start_evt) <br>
 *                                 ps[?]=0 when pwm?_C1=CNT (has priority over pwm?_C0)
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_cfg(pwmn_pwm_cfg_t cfg, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set current PWMN values (C0)
 *
 * \ingroup pwmn 
 * 
 * \param c0                   Current value of the PWMN
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_c0(pwmn_pwm_c_t c0, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set current PWMN values (C1)
 *
 * \ingroup pwmn 
 * 
 * \param c1                   Current value of the PWMN
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_c1(pwmn_pwm_c_t c1, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set PWMN ON values <br>
 *
 *                             PWM?_ON hs and ls sets each output individually to 0. PWM?_ON_RELOAD is transferred to
 *                             PWM?_ON synchronous to the effect of the other RELOAD values
 *
 * \ingroup pwmn 
 * 
 * \param on                   Value of ON
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_on(pwmn_pwm_on_t on, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set current PWMN reload values (C0)
 *
 * \ingroup pwmn 
 * 
 * \param c0_reload            Current reload value of the PWMN
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_c0_reload(pwmn_pwm_c_reload_t c0_reload, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set current PWMN reload values (C1)
 *
 * \ingroup pwmn 
 * 
 * \param c1_reload            Current reload value of the PWMN
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_c1_reload(pwmn_pwm_c_reload_t c1_reload, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set PWMN ON reload values <br>
 *
 *                             PWM?_ON hs and ls sets each output individually to 0. PWM?_ON_RELOAD is transferred to
 *                             PWM?_ON synchronous to the effect of the other RELOAD values
 *
 *
 * \ingroup pwmn 
 * 
 * \param on_reload            Value of ON reload
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_on_reload(pwmn_pwm_on_reload_t on_reload, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set PWMN Interrupt status
 *
 * \ingroup pwmn 
 * 
 * \param irq_status           Desired interrupt status
 *                             \see pwmn_irq_status_t
 */ 
void pwmn_set_irq_status_reg(pwmn_irq_status_t irq_status);

/* ############################################################################ */
/**
 * \brief Function to set PWMN Interrupt mask
 *
 * \ingroup pwmn 
 * 
 * \param irq_mask             Enable irq source: <br>
 *                             1: enabled <br>
 *                             0: disabled
 */ 
void pwmn_set_irq_mask(pwmn_irq_mask_t irq_mask);

/* ############################################################################ */
/**
 * \brief Function to enable PWMN Interrupt
 *
 * \ingroup pwmn 
 * 
 * \param irq_venable          Vector number of interrupt to enable
 */ 
void pwmn_set_irq_venable(pwmn_irq_venable_t irq_venable);

/* ############################################################################ */
/**
 * \brief Function to disable PWMN Interrupt
 *
 * \ingroup pwmn 
 * 
 * \param irq_disable          Vector number of interrupt to disable
 */ 
void pwmn_set_irq_vdisable(pwmn_irq_venable_t irq_disable);

/* ############################################################################ */
/**
 * \brief Function to set PWMN nesting priority
 *
 * \ingroup pwmn 
 * 
 * \param irq_vmax             Needed for nested interrupt support <br>
 *                             Software writes current vector number to this register, so only interrupts with higher priority (lower vector number) can nest
 */ 
void pwmn_set_irq_vmax(pwmn_irq_vmax_t irq_vmax);

/* ############################################################################ */
/**
 * \brief Function to enable PWM vector number 
 *
 * \ingroup pwmn 
 * 
 * \param irq_vno              Vector number of interrupt
 *                             \note vector number of enabled pending interrupt with highest priority (smallest vector number). when no irq is pending the first unused irq number is returned.
 */ 
void pwmn_set_irq_vno(pwmn_irq_vno_t irq_vno);


/* ############################################################################ */
/**
 * \brief Function to set PWMN configuration
 *
 * \ingroup pwmn 
 * 
 * \param cfg                  Desired configuration in 16 bits format
 */ 
void pwmn_set_cfg_u16(uint16_t cfg);

/* ############################################################################ */
/**
 * \brief Function to set PWMN command
 *
 * \ingroup pwmn 
 * 
 * \param cmd                  Desired command in 16 bits format
 */ 
void pwmn_set_cmd_u16(uint16_t cmd);

/* ############################################################################ */
/**
 * \brief Function to set PWMN counter
 *
 * \ingroup pwmn 
 * 
 * \param cnt                  Desired counter in 16 bits format
 */ 
void pwmn_set_cnt_u16(uint16_t cnt);

/* ############################################################################ */
/**
 * \brief Function to set PWMN prescaler
 *
 * \ingroup pwmn 
 * 
 * \param prescaler            Desired prescaler in 16 bits format
 */ 
void pwmn_set_prescaler_u16(uint16_t prescaler);

/* ############################################################################ */
/**
 * \brief Function to set PWMN maximum counter value
 *
 * \ingroup pwmn 
 * 
 * \param cnt_max              Desired maximum counter value in 16 bits format
 *                             \note Permitted range: <br>
 *                                   for CFG.mode=*sawtooth: 0..2^16-1 <br>
 *                                   for CFG.mode=*triangle: 0..2^15-1
 */ 
void pwmn_set_cnt_max_u16(uint16_t cnt_max);

/* ############################################################################ */
/**
 * \brief Function to set PWMN NTH start value
 *
 * \ingroup pwmn 
 * 
 * \param nth_start            Decremented at the start of every period. The start_evt and the associated reload actions are only performed when NTH_START=0
 */ 
void pwmn_set_nth_start_u16(uint16_t nth_start);

/* ############################################################################ */
/**
 * \brief Function to set PWMN dead time value
 *
 * \ingroup pwmn 
 * 
 * \param dead_time            0..MAX <br>
 *                             0: dead time is disabled, hs and ls outputs change simultaneously
 */ 
void pwmn_set_dead_time_u16(uint16_t dead_time);

/* ############################################################################ */
/**
 * \brief Function to set PWMN prescaler reload value
 *
 * \ingroup pwmn 
 * 
 * \param prescaler_reload     Transferred to NTH_START after it reached 0
 */ 
void pwmn_set_prescaler_reload_u16(uint16_t prescaler_reload);

/* ############################################################################ */
/**
 * \brief Function to set PWMN maximum counter reload
 *
 * \ingroup pwmn 
 * 
 * \param cnt_max_reload       Desired maximum counter reload value
 *                             \note Permitted range: <br>
 *                                   for CFG.mode=*sawtooth: 0..2^16-1 <br>
 *                                   for CFG.mode=*triangle: 0..2^15-1
 */ 
void pwmn_set_cnt_max_reload_u16(uint16_t cnt_max_reload);

/* ############################################################################ */
/**
 * \brief Function to set PWMN NTH start reload
 *
 * \ingroup pwmn 
 * 
 * \param nth_start_reload     Transferred to NTH_START after it reached 0
 */ 

/* ############################################################################ */
/**
 * \brief Function to set PWMN dead time reload
 *
 * \ingroup pwmn 
 * 
 * \param dead_time_reload     0..MAX <br>
 *                             0: dead time is disabled, hs and ls outputs change simultaneously
 */ 

/* ############################################################################ */
/**
 * \brief Function to set individual PWMN configuration
 *
 * \ingroup pwmn 
 * 
 * \param cfg                  00: ps[?]=1 when pwm?_C0 > CNT otherwise ps[?]=0 <br>
 *                             01: ps[?]=0 when pwm?_C0 > CNT otherwise ps[?]=1 <br>
 *                             10: ps[?]=0 when start_evt <br>
 *                                 ps[?]=1 when pwm?_C0=CNT (has priority over start_evt) <br>
 *                                 ps[?]=0 when pwm?_C1=CNT (has priority over pwm?_C0)
 * 
 * \param nr                   Number of PWMN to configure
 */ 
void pwmn_set_pwm_cfg_u16(uint16_t cfg, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set current PWMN values (C0)
 *
 * \ingroup pwmn 
 * 
 * \param c0                   Current value of the PWMN
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_c0_u16(uint16_t c0, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set current PWMN values (C1)
 *
 * \ingroup pwmn 
 * 
 * \param c1                   Current value of the PWMN
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_c1_u16(uint16_t c1, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set PWMN ON values <br>
 *
 *                             PWM?_ON hs and ls sets each output individually to 0. PWM?_ON_RELOAD is transferred to
 *                             PWM?_ON synchronous to the effect of the other RELOAD values
 *
 * \ingroup pwmn 
 * 
 * \param on                   Value of ON
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_on_u16(uint16_t on, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set current PWMN reload values (C0)
 *
 * \ingroup pwmn 
 * 
 * \param c0_reload            Current reload value of the PWMN
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_c0_reload_u16(uint16_t c0_reload, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set current PWMN reload values (C1)
 *
 * \ingroup pwmn 
 * 
 * \param c1_reload            Current reload value of the PWMN
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_c1_reload_u16(uint16_t c1_reload, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set PWMN ON reload values <br>
 *
 *                             PWM?_ON hs and ls sets each output individually to 0. PWM?_ON_RELOAD is transferred to
 *                             PWM?_ON synchronous to the effect of the other RELOAD values
 *
 *
 * \ingroup pwmn 
 * 
 * \param on_reload            Value of ON reload
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_set_pwm_on_reload_u16(uint16_t on_reload, uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set PWMN Interrupt status
 *
 * \ingroup pwmn 
 * 
 * \param irq_status           Desired interrupt status
 */ 
void pwmn_set_irq_status_u16_reg(uint16_t irq_status);

/* ############################################################################ */
/**
 * \brief Function to set PWMN Interrupt mask
 *
 * \ingroup pwmn 
 * 
 * \param irq_mask             Enable irq source: <br>
 *                             1: enabled <br>
 *                             0: disabled
 */ 
void pwmn_set_irq_mask_u16(uint16_t irq_mask);

/* ############################################################################ */
/**
 * \brief Function to enable PWMN Interrupt
 *
 * \ingroup pwmn 
 * 
 * \param irq_venable          Vector number of interrupt to enable
 */ 
void pwmn_set_irq_venable_u16(uint16_t irq_venable);

/* ############################################################################ */
/**
 * \brief Function to disable PWMN Interrupt
 *
 * \ingroup pwmn 
 * 
 * \param irq_disable          Vector number of interrupt to disable
 */ 
void pwmn_set_irq_vdisable_u16(uint16_t irq_disable);

/* ############################################################################ */
/**
 * \brief Function to set PWMN nesting priority
 *
 * \ingroup pwmn 
 * 
 * \param irq_vmax             Needed for nested interrupt support <br>
 *                             Software writes current vector number to this register, so only interrupts with higher priority (lower vector number) can nest
 */ 
void pwmn_set_irq_vmax_u16(uint16_t irq_vmax);
 
/* ############################################################################ */
/**
 * \brief Function to enable PWM vector number
 *
 * \ingroup pwmn 
 * 
 * \param irq_vno              Vector number of interrupt
 *                             \note vector number of enabled pending interrupt with highest priority (smallest vector number). when no irq is pending the first unused irq number is returned.
 */ 
void pwmn_set_irq_vno_u16(uint16_t irq_vno);

// GETTER

/* ############################################################################ */
/**
 * \brief Function to get PWMN configuration
 *
 * \ingroup pwmn 
 * 
 * \return                     Current configuration for PWMN
 *                             \see pwmn_cfg_t
 */ 
pwmn_cfg_t pwmn_get_cfg(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN state
 *
 * \ingroup pwmn 
 * 
 * \return                     Current state of PWMN
 *                             \see pwmn_state_t             
 */ 
pwmn_state_t pwmn_get_state(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN counter restart
 *
 * \ingroup pwmn 
 * 
 * \return                     Value of PWM_PHASE at the last time a restart event occurred
 */ 
pwmn_cnt_restart_t pwmn_get_cnt_restart(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN counter value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current counter value
 */ 
pwmn_cnt_t pwmn_get_cnt(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN phase
 *
 * \ingroup pwmn 
 * 
 * \return                     Value of module output pwm_phase: <br>
 *                             for CFG.mode=*sawtooth: 15:0 is the counter value <br>
 *                             for CFG.mode=*triangle: 14:0 is the counter value and bit 15 is 0 for the first and 1 for the second half of the period.
 */ 
pwmn_pwm_phase_t pwmn_get_pwm_phase(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN prescaler
 *
 * \ingroup pwmn 
 * 
 * \return                     Current prescaler value
 */ 
pwmn_prescaler_t pwmn_get_prescaler(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN maximum counter value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current maximum counter value
 */ 
pwmn_cnt_max_t pwmn_get_cnt_max(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN NTH start value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current NTH start value
 */ 
pwmn_nth_start_t pwmn_get_nth_start(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN dead time value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current dead time value
 */ 
pwmn_dead_time_t pwmn_get_dead_time(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN prescaler reload value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current prescaler reload value
 */ 
pwmn_prescaler_reload_t pwmn_get_prescaler_reload(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN maximum counter reload value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current maximum counter reload value
 */ 
pwmn_cnt_max_reload_t pwmn_get_cnt_max_reload(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN NTH start reload value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current NTH start reload value
 */ 
pwmn_nth_start_reload_t pwmn_get_nth_start_reload(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN dead time reload value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current dead time reload value
 */ 
pwmn_dead_time_reload_t pwmn_get_dead_time_reload(void);

/* ############################################################################ */
/**
 * \brief Function to get individual PWMN configuration
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     00: ps[?]=1 when pwm?_C0 > CNT otherwise ps[?]=0 <br>
 *                             01: ps[?]=0 when pwm?_C0 > CNT otherwise ps[?]=1 <br>
 *                             10: ps[?]=0 when start_evt <br>
 *                                 ps[?]=1 when pwm?_C0=CNT (has priority over start_evt) <br>
 *                                 ps[?]=0 when pwm?_C1=CNT (has priority over pwm?_C0)
 * 
 */ 
pwmn_pwm_cfg_t pwmn_get_pwm_cfg(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get current PWMN values (C0)
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Current value of the PWMN
 */ 
pwmn_pwm_c_t pwmn_get_pwm_c0(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get current PWMN values (C1)
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Current value of the PWMN
 */ 
pwmn_pwm_c_t pwmn_get_pwm_c1(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get PWMN ON values <br>
 *
 *                             PWM?_ON hs and ls sets each output individually to 0. PWM?_ON_RELOAD is transferred to
 *                             PWM?_ON synchronous to the effect of the other RELOAD values
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Value of ON
 */ 
pwmn_pwm_on_t pwmn_get_pwm_on(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get current PWMN reload values (C0)
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Current reload value of the PWMN
 */ 
pwmn_pwm_c_reload_t pwmn_get_pwm_c0_reload(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get current PWMN reload values (C1)
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Current reload value of the PWMN
 */ 
pwmn_pwm_c_reload_t pwmn_get_pwm_c1_reload(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set PWMN ON reload values <br>
 *
 *                             PWM?_ON hs and ls sets each output individually to 0. PWM?_ON_RELOAD is transferred to
 *                             PWM?_ON synchronous to the effect of the other RELOAD values
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Value of ON reload
 */ 
pwmn_pwm_on_reload_t pwmn_get_pwm_on_reload(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get PWMN Interrupt status
 *
 * \ingroup pwmn 
 * 
 * \return                     Current interrupt status
 *                             \see pwmn_irq_status_t
 */ 
pwmn_irq_status_t pwmn_get_irq_status_reg(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN Interrupt mask
 *
 * \ingroup pwmn 
 * 
 * \return                     Interrupt source: <br>
 *                             1: enabled <br>
 *                             0: disabled
 */ 
pwmn_irq_mask_t pwmn_get_irq_mask(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN nesting priority
 *
 * \ingroup pwmn 
 * 
 * \return                     Needed for nested interrupt support <br>
 *                             Software writes current vector number to this register, so only interrupts with higher priority (lower vector number) can nest
 */ 
pwmn_irq_vmax_t pwmn_get_irq_vmax(void);

/* ############################################################################ */
/**
 * \brief Function to get PWM enabled vector number
 *
 * \ingroup pwmn 
 * 
 * \return                     Vector number of interrupt
 *                             \note vector number of enabled pending interrupt with highest priority (smallest vector number). when no irq is pending the first unused irq number is returned.
 */ 
pwmn_irq_vno_t pwmn_get_irq_vno(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN configuration
 *
 * \ingroup pwmn 
 * 
 * \return Current             Configuration for PWMN
 */ 
uint16_t pwmn_get_cfg_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN state
 *
 * \ingroup pwmn 
 * 
 * \return                     Current state of PWMN
 */ 
uint16_t pwmn_get_state_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN counter restart
 *
 * \ingroup pwmn 
 * 
 * \return                     Value of PWM_PHASE at the last time a restart event occurred
 */ 
uint16_t pwmn_get_cnt_restart_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN counter value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current counter value
 */ 
uint16_t pwmn_get_cnt_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN phase
 *
 * \ingroup pwmn 
 * 
 * \return                     Value of module output pwm_phase: <br>
 *                             for CFG.mode=*sawtooth: 15:0 is the counter value <br>
 *                             for CFG.mode=*triangle: 14:0 is the counter value and bit 15 is 0 for the first and 1 for the second half of the period.
 */ 
uint16_t pwmn_get_pwm_phase_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN prescaler
 *
 * \ingroup pwmn 
 * 
 * \return                     Current prescaler value
 */ 
uint16_t pwmn_get_prescaler_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN maximum counter value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current maximum counter value
 */ 
uint16_t pwmn_get_cnt_max_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN NTH start value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current NTH start value
 */ 
uint16_t pwmn_get_nth_start_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN dead time value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current dead time value
 */ 
uint16_t pwmn_get_dead_time_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN prescaler reload value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current prescaler reload value
 */ 
uint16_t pwmn_get_prescaler_reload_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN maximum counter reload value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current maximum counter reload value
 */ 
uint16_t pwmn_get_cnt_max_reload_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN NTH start reload value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current NTH start reload value
 */ 
uint16_t pwmn_get_nth_start_reload_u16(void);
 
/* ############################################################################ */
/**
 * \brief Function to get PWMN dead time reload value
 *
 * \ingroup pwmn 
 * 
 * \return                     Current dead time reload value
 */ 
uint16_t pwmn_get_dead_time_reload_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get individual PWMN configuration
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     00: ps[?]=1 when pwm?_C0 > CNT otherwise ps[?]=0 <br>
 *                             01: ps[?]=0 when pwm?_C0 > CNT otherwise ps[?]=1 <br>
 *                             10: ps[?]=0 when start_evt <br>
 *                                 ps[?]=1 when pwm?_C0=CNT (has priority over start_evt) <br>
 *                                 ps[?]=0 when pwm?_C1=CNT (has priority over pwm?_C0)
 * 
 */ 
uint16_t pwmn_get_pwm_cfg_u16(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get current PWMN values (C0)
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Current value of the PWMN
 */ 
uint16_t pwmn_get_pwm_c0_u16(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get current PWMN values (C1)
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Current value of the PWMN
 */ 
uint16_t pwmn_get_pwm_c1_u16(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get PWMN ON values <br>
 *
 *                             PWM?_ON hs and ls sets each output individually to 0. PWM?_ON_RELOAD is transferred to
 *                             PWM?_ON synchronous to the effect of the other RELOAD values
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Value of ON
 */ 
uint16_t pwmn_get_pwm_on_u16(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get current PWMN reload values (C0)
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Current reload value of the PWMN
 */ 
uint16_t pwmn_get_pwm_c0_reload_u16(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get current PWMN reload values (C1)
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Current reload value of the PWMN
 */ 
uint16_t pwmn_get_pwm_c1_reload_u16(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to set PWMN ON reload values <br>
 *
 *                             PWM?_ON hs and ls sets each output individually to 0. PWM?_ON_RELOAD is transferred to
 *                             PWM?_ON synchronous to the effect of the other RELOAD values
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 * 
 * \return                     Value of ON reload
 */ 
uint16_t pwmn_get_pwm_on_reload_u16(uint8_t nr);

/* ############################################################################ */
/**
 * \brief Function to get PWMN Interrupt status
 *
 * \ingroup pwmn 
 * 
 * \return                     Current interrupt status
 */ 
uint16_t pwmn_get_irq_status_u16_reg(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN Interrupt mask
 *
 * \ingroup pwmn 
 * 
 * \return                     Interrupt source: <br>
 *                             1: enabled <br>
 *                             0: disabled
 */ 
uint16_t pwmn_get_irq_mask_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN nesting priority
 *
 * \ingroup pwmn 
 * 
 * \return                     Needed for nested interrupt support <br>
 *                             Software writes current vector number to this register, so only interrupts with higher priority (lower vector number) can nest
 */ 
uint16_t pwmn_get_irq_vmax_u16(void);

/* ############################################################################ */
/**
 * \brief Function to get PWM enabled vector number
 *
 * \ingroup pwmn 
 * 
 * \return                     Vector number of interrupt
 *                             \note vector number of enabled pending interrupt with highest priority (smallest vector number). when no irq is pending the first unused irq number is returned.
 */ 
uint16_t pwmn_get_irq_vno_u16(void);


/* ############################################################################ */
/**
 * \brief Function to restore all PWMN registers
 *
 * \ingroup pwmn 
 */ 
void pwmn_reset_to_default(void);

/* ############################################################################ */
/**
 * \brief Function to restore PWMN interrupt registers
 *
 * \ingroup pwmn 
 */ 
void pwmn_reset_to_default_irq_regs(void);


/* ############################################################################ */
/**
 * \brief Function to start PWMN
 *
 * \ingroup pwmn 
 */ 
void pwmn_start();

/* ############################################################################ */
/**
 * \brief Function to stop PWMN
 *
 * \ingroup pwmn 
 */ 
void pwmn_stop();

/* ############################################################################ */
/**
 * \brief Function to set PWMN restart
 *
 * \ingroup pwmn 
 */ 
void pwmn_restart(void);

/* ############################################################################ */
/**
 * \brief Function to stop restart in PWMN
 *
 * \ingroup pwmn 
 */ 
void pwmn_restart_stop(void);

/* ############################################################################ */
/**
 * \brief Function to clear PWMN STATE.oc
 *
 * \ingroup pwmn 
 */ 
void pwmn_clear_oc(void);

//------------------------
//used by pre_pwm

/* ############################################################################ */
/**
 * \brief Function to enable PWMN
 *
 * \ingroup pwmn 
 * 
 * \param nr                   Number of the PWMN
 */ 
void pwmn_enable(uint8_t nr);

/* ======================================================================= */
/* INTERRUPT HANDLING                                                      */
/* ======================================================================= */


/* ############################################################################ */
/**
 * \brief Function to enable PWMN Interrupts
 *
 * \ingroup pwmn 
 * 
 * \param irq                  Vector number of interrupt to enable
 *                             \see pwmn_irq_t
 * 
 * \param enable               1: Enable
 */ 
void pwmn_enable_irq(pwmn_irq_t irq, bool enable);

/* ############################################################################ */
/**
 * \brief Function to clear PWMN all interrupt events
 *
 * \ingroup pwmn 
 */ 
void pwmn_clear_all_irq_events(void);

/* ############################################################################ */
/**
 * \brief Function to get PWMN pending interrupt
 *
 * \ingroup pwmn 
 * 
 * \return                     Vector number of enabled pending interrupt with highest priority (smallest vector number) <br>
 *                             When no irq is pending the first unused irq number is returned
 *                             \see pwmn_irq_t
 */ 
pwmn_irq_t pwmn_get_pending_irq(void);

/**@{*/ 
#endif /* __PWMN_H__ */

