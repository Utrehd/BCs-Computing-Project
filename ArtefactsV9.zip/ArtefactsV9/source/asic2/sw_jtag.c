/* FPGA Release: 10512 */
#include <hardware_api.h>

#warning "only for FPGA Board - not for production"
//seperate HV-Die does not exist. only inside a asic2 and then with a hv_control

#define JTAG_PIN_TDI  GPIO_BIT_1  // SYS_PMOD0_2 (HV_JTAG_TDI)
#define JTAG_PIN_TMS  GPIO_BIT_2  // SYS_PMOD0_4 (HV_JTAG_TMS)
#define JTAG_PIN_TCK  GPIO_BIT_3  // SYS_PMOD0_6 (HV_JTAG_TCK)
#define JTAG_PIN_TDO  GPIO_BIT_4  // SYS_PMOD0_8 (HV_JTAG_NRES)
#define JTAG_PIN_NRES GPIO_BIT_5  // SYS_PMOD0_2 (HV_JTAG_TDI)

#define JTAG_STATE_HIGH 0xffff
#define JTAG_STATE_LOW 0

static bool selout_enable;

static hv_ir_pwr_config_t hv_ir_pwr_config;

void sw_jtag_init(void){
  gpio_set_oe(GPIO_GROUP_0, JTAG_PIN_TDI , true); gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TDI , JTAG_STATE_LOW);
  gpio_set_oe(GPIO_GROUP_0, JTAG_PIN_TMS , true); gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS , JTAG_STATE_LOW);
  gpio_set_oe(GPIO_GROUP_0, JTAG_PIN_TCK , true); gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK , JTAG_STATE_LOW);
  gpio_set_oe(GPIO_GROUP_0, JTAG_PIN_NRES, true); gpio_set_out(GPIO_GROUP_0, JTAG_PIN_NRES, JTAG_STATE_LOW);
  gpio_set_ie(GPIO_GROUP_0, JTAG_PIN_TDO , true);
}

void sw_jtag_set_nres(bool value){
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_NRES, value ? JTAG_STATE_HIGH : JTAG_STATE_LOW);
  if (value){
    selout_enable = false;
  } else {
    hv_ir_pwr_config.val  = 0;
  }
}

void sw_jtag_tap_reset(void){
  uint8_t i;
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_HIGH);
  for (i = 11; i > 0; i--){
    if (i == 1){
      gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_LOW);
    }
    gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
    gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);
  }
  // go to idle state
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
}

static uint16_t sw_jtag_dr_shift(uint16_t dr){
  unsigned long tdo = 0;
  unsigned char i;
  unsigned char tclk = 0;
  unsigned char no_bits = 16;

  // idle -> select DR
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_HIGH);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);

  // select DR -> shift DR
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);

  for (i = 0; i < no_bits; i++){
    // set JTAG_PIN_TDI msb first
    if (dr & (1 << (no_bits -i -1))){
      gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TDI, JTAG_STATE_HIGH);
    } else {
      gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TDI, JTAG_STATE_LOW);
    }
    // set JTAG_PIN_TMS with last bit
    if (i == (no_bits -1)){
      // shift DR -> exit1 DR
      gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_HIGH);
    }
    gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
    gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);
    // read JTAG_PIN_TDO msb first
    tdo = tdo << 1;
    tdo |= ((gpio_get_in (GPIO_GROUP_0, JTAG_PIN_TDO)>>1)&1);

  }
  // exit1 DR -> update DR
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);

  // update DR -> idle
  // set TCLK
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TDI, tclk);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);

  return tdo;
}

static uint16_t sw_jtag_ir_shift(uint8_t ir, bool read){
  unsigned long tdo = 0;
  unsigned char i;
  unsigned char tclk = 0;
  unsigned char no_bits = 8;

  // idle -> select IR
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_HIGH);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);

  // select IR -> shift IR
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);


  for (i = 0; i < no_bits; i++){
    // set JTAG_PIN_TDI lsb first
    if (ir & (1 << i)){
      gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TDI, JTAG_STATE_HIGH);
    } else {
      gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TDI, JTAG_STATE_LOW);
    }
    // set JTAG_PIN_TMS with last bit
    if (i == (no_bits -1)){
      // shift IR -> exit1 IR
      gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_HIGH);
    }
    gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
    gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);
  }
  // exit1 IR -> update IR
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);

  // update IR -> idle
  // set TCLK
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TMS, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TDI, tclk);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_HIGH);
  gpio_set_out(GPIO_GROUP_0, JTAG_PIN_TCK, JTAG_STATE_LOW);

  if (read) {
    tdo = sw_jtag_dr_shift(0);
  }

  return tdo;
}

void sw_jtag_pwr_config(  bool              vreg_vdd5tx_npd,
                          bool              pw_vdd5tx_npd,
                          vreg_vdd3v3_max_t vreg_vdd3v3_max,
                          pw_vpow_range_t   pw_vpow_range,
                          uint8_t                pw_vpow_hyst){
  hv_ir_pwr_config.bf.vreg_vdd5tx_npd = vreg_vdd5tx_npd;
  hv_ir_pwr_config.bf.pw_vdd5tx_npd   = pw_vdd5tx_npd;
  hv_ir_pwr_config.bf.vreg_vdd3v3_max = vreg_vdd3v3_max;
  hv_ir_pwr_config.bf.pw_vpow_hyst    = pw_vpow_hyst;
  hv_ir_pwr_config.bf.pw_vpow_range   = pw_vpow_range;
  sw_jtag_ir_shift(ADDR_HV_IR_IR_PWR_CONFIG, false);
  sw_jtag_dr_shift(hv_ir_pwr_config.val);
}

void sw_jtag_cfg_phy( bool                      hrx485_npd,
                      bool                      htx485_npd,
                      bool htx485_slew_enable,
                      htx485_bbm_fast_t         htx485_bbm_fast,
                      htx485_auto_shutdown_t htx485_auto_shutdown,
                      htx485_tempsens_enable_t htx485_tempsens_enable,
                      htx485_tempsens_mask_t htx485_tempsens_mask){
  uint16_t temp = 0;
  temp |= hrx485_npd              << SFT_HV_IR_RS485_CONFIG_HRX485_NPD;
  temp |= htx485_npd              << SFT_HV_IR_RS485_CONFIG_HTX485_NPD;
  temp |= htx485_slew_enable      << SFT_HV_IR_RS485_CONFIG_HTX485_SLEW_ENABLE;
  temp |= htx485_bbm_fast         << SFT_HV_IR_RS485_CONFIG_HTX485_BBM_FAST;
  temp |= htx485_auto_shutdown    << SFT_HV_IR_RS485_CONFIG_HTX485_AUTO_SHUTDOWN;
  temp |= htx485_tempsens_enable  << SFT_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_ENABLE;
  temp |= htx485_tempsens_mask    << SFT_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_MASK;

  sw_jtag_ir_shift(ADDR_HV_IR_IR_RS485_CONFIG, false);
  sw_jtag_dr_shift(temp);
}

void sw_jtag_set_selout(bool selout){
  uint16_t temp = 0;
  temp |= selout_enable << SFT_HV_IR_SELOUT_HSELOUT_NPD;
  temp |= selout        << SFT_HV_IR_SELOUT_HSELOUT_TX;
  sw_jtag_ir_shift(ADDR_HV_IR_IR_SELOUT, false);
  sw_jtag_dr_shift(temp);
  //printf("- set selout %d\r\n", selout);
}


void sw_jtag_set_selout_enable(bool enable){
  selout_enable = enable;
  if (!enable){
    sw_jtag_set_selout(false);
  }
}

void sw_jtag_set_gpo(bool en, bool val){
  uint16_t temp = 0;
  temp |= en    << SFT_HV_IR_GPO5V_HGPO_EN;
  temp |= val   << SFT_HV_IR_GPO5V_HGPO_OUT;
  sw_jtag_ir_shift(ADDR_HV_IR_IR_GPO5V, false);
  sw_jtag_dr_shift(temp);
}
