#include "hardware.h"
#include "clk_nres_api.h"


#if defined(CLK_NRES_CFG_LOW_RATE_0) && defined(CLK_NRES_CFG_LOW_RATE_0) && defined(CLK_NRES_CFG_HIGH_RATE)
#include <application_config_user_calc.h>
#endif

#ifdef SWD_SLAVE_STACK
  // on dual core implementation (different protocols, CLK_NRES is accessible by mailbox commands only 
  #include <slave/swd_mailbox_acpu.h>
#endif

/* ############################################################################ */

errors_api_code_e clk_nres_api_set_clock_partition(clkpno_t clkpno, bool enable){
  
  errors_api_code_e error_code = eError_none;

#ifdef SWD_SLAVE_STACK
      swd_enable_hw_module(clkpno, enable);
#else
  wdog_unlock_guard(GUARD0);
  clk_nres_guard_enable(CLK_NRES_0);      
      
  switch (clkpno) {
    case CLKPNO_SWTIMER1:
    case CLKPNO_HIAD:
    case CLKPNO_UART:
    case CLKPNO_CRC0:
    case CLKPNO_CRC1:
    case CLKPNO_GPIO:
    case CLKPNO_SARADC_CTRL:
    case CLKPNO_PWMN:
    case CLKPNO_GUARD1:
    case CLKPNO_WDOG1:
    case CLKPNO_CCTIMER0:
    case CLKPNO_CCTIMER1:
    case CLKPNO_AOUT_CTRL:
    case CLKPNO_I2C:
      clk_nres_enable_clock_partition(CLK_NRES_0, clkpno, enable);
      clk_nres_set_nreset(clkpno, enable);
      break;
      
    case CLKPNO_HISPI:
      clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_HISPI, enable);
      clk_nres_set_nreset(CLKPNO_HISPI, enable);
      
      clk_nres_enable_as_clock_domain(CLK_NRES_0, AS_HISPI, true);
      clk_nres_set_as_nreset(AS_HISPI, enable);
      break;
  
    case CLKPNO_USI0:
      clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_USI0, enable);
      clk_nres_set_nreset(CLKPNO_USI0, enable);
      
      clk_nres_enable_as_clock_domain(CLK_NRES_0, AS_USI0, true);
      clk_nres_set_as_nreset(AS_USI0, enable);
      break;
      
    case CLKPNO_USI1:
      // normal clock
      clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_USI1, enable);
      clk_nres_set_nreset(CLKPNO_USI1, enable);
      
      // AS clock
      clk_nres_enable_as_clock_domain(CLK_NRES_0, AS_USI1, true);
      clk_nres_set_as_nreset(AS_USI1, enable);
      break;

    default:
      error_code = eError_clk_nres_api_incorrect_clock_partition;
    }
  clk_nres_guard_disable(CLK_NRES_0);
  wdog_disable (GUARD0); // GUARD disable
  //while (wdog_is_running (GUARD0))  ;   
  
#endif 
  return error_code;  
}

/* ############################################################################ */
errors_api_code_e clk_nres_api_get_as_clock(clk_domain_t domain, uint32_t * as_clock_freq) {
  errors_api_code_e error_code = eError_none;  

#if defined(CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC) && \
    defined(CLK_NRES_CFG_AS1_USI0_CLK_SRC) && \
    defined(CLK_NRES_CFG_AS2_USI1_CLK_SRC) && \
    defined(CLK_NRES_CFG_AS3_HISPI_CLK_SRC) && \
    defined(CLK_NRES_CFG_M_CLK_SRC)
      
#include <application_config_user_calc.h>

  switch(domain){
  case AS_SWD_TSU:  
    *as_clock_freq = CLK_NRES_AS0_SWD_TSU_FREQ_HZ;
    break;
  case AS_USI0:
    *as_clock_freq = CLK_NRES_AS1_USI0_FREQ_HZ;
    break;
  case AS_USI1:
    *as_clock_freq = CLK_NRES_AS2_USI1_FREQ_HZ;
    break;
  case AS_HISPI:
    *as_clock_freq = CLK_NRES_AS3_HISPI_FREQ_HZ;
    break;
  case MAIN:
    *as_clock_freq = CLK_NRES_CLK_MAIN_FREQ_HZ;
    break;
  default:
    return eError_clk_nres_api_incorrect_as_clk; ///< Incorrect configuration of AS clock
    break;
  }

#else  
  uint32_t clock_freq;
  uint32_t clock_freq_divided;
  uint32_t pll_output_freq;
    
  clk_nres_cfg_t clk_nres_cfg;
  
  /* Read the clock data configuration from the registers */
  switch(domain){
  case AS_SWD_TSU:  
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS0_SWD_TSU);
    break;
  case AS_USI0:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS1_USI0);
    break;
  case AS_USI1:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS2_USI1);
    break;
  case AS_HISPI:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS3_HISPI);
    break;
  case MAIN:
    clk_nres_cfg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_M);
    break;
  default:
    return eError_clk_nres_api_incorrect_as_clk; ///< Incorrect configuration of AS clock
    break;
  }
  
  /* Select main clock */
  switch(clk_nres_cfg.bf.clk_src){
    
    case CLOCK_SOURCE_RCOSC_HF:
      clock_freq = CLOCK_FREQ_RCOSC_HF;
    break;
    
    case CLOCK_SOURCE_RCOSC_LF:
      clock_freq = CLOCK_FREQ_RCOSC_LF;
    break;
    
    case CLOCK_SOURCE_PLL:
      error_code = clk_nres_api_get_pll_freq(&pll_output_freq);
      clock_freq = pll_output_freq;
      
    break;
    
    case CLOCK_SOURCE_QOSC:
      clock_freq = CLOCK_FREQ_QOSC;
    break;
    
    default:  
      return eError_clk_nres_api_incorrect_as_clk; ///< Incorrect configuration of AS clock
  }
  
  if (clock_freq==0) {
    return eError_clk_nres_api_incorrect_as_clk; ///< Incorrect configuration of AS clock
  }
  
  /* AS clock divided */
  clock_freq_divided = clock_freq/clk_nres_cfg.bf.clk_div;
  
  *as_clock_freq = clock_freq_divided;
  
#endif  
  return error_code;
}

/* ############################################################################ */
errors_api_code_e clk_nres_api_get_system_clock(uint32_t * system_clock) {
  return(clk_nres_api_get_as_clock(MAIN, system_clock));
}


/* ############################################################################ */

clk_rate_t clk_nres_api_get_rate_sel(clkpno_t clkpno) {
  uint32_t rel_adr = 0;
  clk_rate_t cfg_rate_sel;
  
  if (clkpno < CLKPNO_MASTERS) return ((clk_rate_t)0);
  else clkpno -= CLKPNO_MASTERS;
  
  while (clkpno >= 8) {
    clkpno -= 8;
    rel_adr += 2;
  }
  
  cfg_rate_sel = (clk_rate_t)READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE_SEL_0 + rel_adr);
  
  cfg_rate_sel = (clk_rate_t)( cfg_rate_sel >> 2*clkpno );
  cfg_rate_sel &=  0x03;
  
  return cfg_rate_sel;
}

/* ############################################################################ */

errors_api_code_e clk_nres_api_get_module_clock(clkpno_t module, uint32_t * module_clock) {
  
  
#if defined(CLK_NRES_CFG_LOW_RATE_0) && defined(CLK_NRES_CFG_LOW_RATE_0) && defined(CLK_NRES_CFG_HIGH_RATE)
#include <application_config_user_calc.h>
  
  *module_clock = 0;
  
  switch(module) {
    
  case CLKPNO_CCPU0 :
    *module_clock = CLK_NRES_CFG_RATE_SEL_CCPU0_FREQ_HZ;
    break;
 
  case CLKPNO_ACPU1:
    *module_clock = CLK_NRES_CFG_RATE_SEL_ACPU1_FREQ_HZ;
    break;
 
  case CLKPNO_CRC0:
    *module_clock = CLK_NRES_CFG_RATE_SEL_CRC0_FREQ_HZ;
    break;
 
  case CLKPNO_CRC1:
    *module_clock = CLK_NRES_CFG_RATE_SEL_CRC1_FREQ_HZ;
    break;
 
  case CLKPNO_HIAD:
    *module_clock = CLK_NRES_CFG_RATE_SEL_HIAD_FREQ_HZ;
    break;

  case CLKPNO_HISPI:
    *module_clock = CLK_NRES_CFG_RATE_SEL_HISPI_FREQ_HZ;
    break;
 
  case CLKPNO_SWD:
    *module_clock = CLK_NRES_CFG_RATE_SEL_SWD_FREQ_HZ;
    break;
 
  case CLKPNO_SARADC_CTRL:
    *module_clock = CLK_NRES_CFG_RATE_SEL_SARADC_CTRL_FREQ_HZ;
    break;
 
  case CLKPNO_USI0:
    *module_clock = CLK_NRES_CFG_RATE_SEL_USI0_FREQ_HZ;
    break;
 
  case CLKPNO_USI1:
    *module_clock = CLK_NRES_CFG_RATE_SEL_USI1_FREQ_HZ;
    break;
    
  case CLKPNO_TSU:
    *module_clock = CLK_NRES_CFG_RATE_SEL_TSU_FREQ_HZ;
    break;
    
  case CLKPNO_GPIO:
    *module_clock = CLK_NRES_CFG_RATE_SEL_GPIO_FREQ_HZ;
    break;
  
  case CLKPNO_GUARD0:
    *module_clock = CLK_NRES_CFG_RATE_SEL_GUARD0_FREQ_HZ;
    break;
  
  case CLKPNO_GUARD1:
    *module_clock = CLK_NRES_CFG_RATE_SEL_GUARD1_FREQ_HZ;
    break;
  
  case CLKPNO_SWTIMER0:
    *module_clock = CLK_NRES_CFG_RATE_SEL_SWTIMER0_FREQ_HZ;
    break;
  
  case CLKPNO_SWTIMER1:
    *module_clock = CLK_NRES_CFG_RATE_SEL_SWTIMER1_FREQ_HZ;
    break;
  
  case CLKPNO_PWMN:
    *module_clock = CLK_NRES_CFG_RATE_SEL_PWMN_FREQ_HZ;
    break;
  
  case CLKPNO_VIC_EXT:
    *module_clock = CLK_NRES_CFG_RATE_SEL_VIC_EXT_FREQ_HZ;
    break;
  
  case CLKPNO_WDOG0:
    *module_clock = CLK_NRES_CFG_RATE_SEL_WDOG0_FREQ_HZ;
    break;
  
  case CLKPNO_WDOG1:
    *module_clock = CLK_NRES_CFG_RATE_SEL_WDOG1_FREQ_HZ;
    break;
  
  case CLKPNO_CPU_N_CPU:
    *module_clock = CLK_NRES_CFG_RATE_SEL_CPU_N_CPU_FREQ_HZ;
    break;
  
  case CLKPNO_CCTIMER0:
    *module_clock = CLK_NRES_CFG_RATE_SEL_CCTIMER0_FREQ_HZ;
    break;
  
  case CLKPNO_CCTIMER1:
    *module_clock = CLK_NRES_CFG_RATE_SEL_CCTIMER1_FREQ_HZ;
    break;
  
  case CLKPNO_IO_CTRL:
    *module_clock = CLK_NRES_CFG_RATE_SEL_IO_CTRL_FREQ_HZ;
    break;
  
  case CLKPNO_ANALOG_CTRL:
    *module_clock = CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL_FREQ_HZ;
    break;
  
  case CLKPNO_ACCESS_CONTROL:
    *module_clock = CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL_FREQ_HZ;
    break;
  
  case CLKPNO_HV_CTRL:
    *module_clock = CLK_NRES_CFG_RATE_SEL_HV_CTRL_FREQ_HZ;
    break;
  
  case CLKPNO_UART:
    *module_clock = CLK_NRES_CFG_RATE_SEL_UART_FREQ_HZ;
    break;
  
  case CLKPNO_AOUT_CTRL:
    *module_clock = CLK_NRES_CFG_RATE_SEL_AOUT_CTRL_FREQ_HZ;
    break;
  
  case CLKPNO_I2C:
    *module_clock = CLK_NRES_CFG_RATE_SEL_I2C_FREQ_HZ;
    break;
  
  case CLKPNO_EL_CTRL:
    *module_clock = CLK_NRES_CFG_RATE_SEL_EL_CTRL_FREQ_HZ;
    break;
     
  default:  
    *module_clock = 0;
    return eError_clk_nres_api_incorrect_module;
    break;
  }
  
  return eError_none;

#else
  
#if defined(APPLICATION_CONFIG)
  
#include <info.h>
  
   *module_clock = 0;
  
  switch(module) {
    
  
  case CLKPNO_WDOG0:
    *module_clock = application_config.asic2_clock.clock_WDOG_Hz;
    return eError_none;
    break;
  
  case CLKPNO_UART:
    *module_clock = (application_config.asic2_clock.clock_DEBUG_UART_Hz & 0xFFFFff00);
    return eError_none;
    break;

  case CLKPNO_SWTIMER0:
    *module_clock = application_config.asic2_clock.clock_SWSUBTIMER_1_Hz;
    return eError_none;
    break;
    
     
  default:  
    break;
  }
  
#endif
  

  uint32_t system_clk;
  uint32_t module_clk;
  clk_rate_t module_rate;
  errors_api_code_e error_code = eError_none;
  
  clk_nres_cfg_rate_t cfg_reg;

  error_code = clk_nres_api_get_system_clock(&system_clk);
  
  cfg_reg.val = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE);
  
  module_rate = clk_nres_api_get_rate_sel(module);
    
  switch( module_rate ){
    
  case full_rate:
    module_clk = system_clk;
  break;
    
  case high_rate:
    module_clk = system_clk/cfg_reg.bf.cfg_high_rate;
  break;
    
  case low_rate_0:
    module_clk = system_clk/cfg_reg.bf.cfg_low_rate_0;
  break;
  
  case low_rate_1:
    module_clk = system_clk/cfg_reg.bf.cfg_low_rate_1;
  break;
    
  default:  
    return eError_clk_nres_api_incorrect_rate;
    
  }
  
  *module_clock = module_clk;
  return error_code;
#endif  
}

/* ############################################################################ */

errors_api_code_e clk_nres_api_get_pll_freq(uint32_t * pll_freq) {
  
  uint32_t freq_in, freq_out;
  uint8_t NR;
  uint8_t NF;
  uint8_t OD;
  uint16_t cfg_pll1, cfg_pll0;
  
  /* Read all the configuration */
  cfg_pll0 = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL0);
  cfg_pll1 = READ_REG_U16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL1);
  
  /* Check is the PLL is enalbe */
  if( (cfg_pll0 & BIT_CLK_NRES_CFG_ANA_PLL0_PLL_PD_N) == 0 )
  {
    return eError_clk_nres_api_pll_not_enabled; ///< PLL is not enabled (power down mode)
  }
  if( (cfg_pll0 & BIT_CLK_NRES_CFG_ANA_PLL0_PLL_OE) == 0 )
  {
    return eError_clk_nres_api_pll_not_enabled; ///< PLL is not enabled (fout forced to zero)
  }
  
  /* Check frequency input source */
  if( (cfg_pll0 & BIT_CLK_NRES_CFG_ANA_PLL0_PLL_FIN_SRC) > 0) {
    freq_in = CLOCK_FREQ_QOSC;
    
    if (freq_in==0) {
      return eError_clk_nres_api_incorrect_master_clk; ///< Incorrect configuration of master clock
    }

  } else {
    freq_in = CLOCK_FREQ_RCOSC_HF;
  }
    
  /* Apply the formula */
  OD =  (cfg_pll1 >> SFT_CLK_NRES_CFG_ANA_PLL1_PLL_OD) & MSK_CLK_NRES_CFG_ANA_PLL1_PLL_OD;
  NR =  (cfg_pll1 >> SFT_CLK_NRES_CFG_ANA_PLL1_PLL_NR) & MSK_CLK_NRES_CFG_ANA_PLL1_PLL_NR;
  NF =  (cfg_pll1 >> SFT_CLK_NRES_CFG_ANA_PLL1_PLL_NF) & MSK_CLK_NRES_CFG_ANA_PLL1_PLL_NF;
    
  freq_out = freq_in * (NF+1) ;
  freq_out = freq_out / (NR+1) ;
  freq_out = freq_out >> OD ;
  
  *pll_freq = freq_out;
  
  return eError_none;
}


/* ############################################################################ */
void clk_nres_api_reset_all_blocks(void) {
  wdog_unlock_guard(GUARD0);
  clk_nres_guard_enable(CLK_NRES_0);

  for(clkpno_t i_clk_part=CLKPNO_CRC0;i_clk_part<=CLKPNO_COUNT;i_clk_part++) {
    
    if (i_clk_part == CLKPNO_GUARD0 ) {
      continue;
    }
    if ( i_clk_part == CLKPNO_GUARD1 ) {
      continue;
    }
    
    /* sample test - FIX */
    /* The device loose debug mode when HV_CTRL is reset */
    if ( i_clk_part == CLKPNO_HV_CTRL ) {
      continue;
    }
    
    
    /*
    if ( i_clk_part == CLKPNO_IO_CTRL ) {
      continue;
    }
    if ( i_clk_part == CLKPNO_UART ) {
      continue;
    }
    */
   
    clk_nres_set_nreset(i_clk_part, false);  
    /*clk_nres_set_nreset(i_clk_part, true);*/
  }
  clk_nres_set_as_nreset(AS_SWD_TSU,false);
  clk_nres_set_as_nreset(AS_USI0,false);
  clk_nres_set_as_nreset(AS_USI1,false);
  clk_nres_set_as_nreset(AS_HISPI,false);
  
  clk_nres_guard_disable(CLK_NRES_0);
  wdog_disable (GUARD0); // GUARD disable
  while (wdog_is_running (GUARD0))  ;     
}
