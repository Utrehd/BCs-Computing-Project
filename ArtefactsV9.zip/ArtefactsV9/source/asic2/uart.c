/* FPGA Release: 10512 */
#include "uart.h"
#include "uart_bf.h"

void uart_init (uart_num_t uart_no,
           uint16_t divider, uint8_t frac, uart_data_len_t data_bits,
           uart_parity_t parity, uart_stop_bit_t stop_bits) {
    uart_config_t uart_config;
    uart_config.val = READ_REG_U16(uart_no + ADDR_UART_CONFIG);
    uart_config.bf.data_bits = data_bits;
    uart_config.bf.par_type = parity;
    uart_config.bf.stop_bits = stop_bits;
    uart_config.bf.rx_enable = 1;
    WRITE_REG_16(uart_no + ADDR_UART_CONFIG, uart_config.val);
    uart_setdivider(uart_no, divider, frac);
}


void uart_set_rx_enable(uart_num_t uart_no, bool enable){
    uart_config_t uart_config;
    uart_config.val = READ_REG_U16(uart_no + ADDR_UART_CONFIG);
    uart_config.bf.rx_enable = enable ? 1 : 0;
    WRITE_REG_16(uart_no + ADDR_UART_CONFIG, uart_config.val);
}


void uart_loopback_enable(uart_num_t uart_no, bool enable){
    uart_config_t uart_config;
    uart_config.val = READ_REG_U16(uart_no + ADDR_UART_CONFIG);
    uart_config.bf.loopback_en = enable ? 1 : 0;
    WRITE_REG_16(uart_no + ADDR_UART_CONFIG, uart_config.val);
}


void uart_setdivider (uart_num_t uart_no, uint16_t divider, uint8_t frac) {
    uart_baudrate_lw_t uart_baudrate_lw;
    uart_baudrate_lw.val = 0;
    uart_baudrate_lw.bf.divider = divider;
    uart_baudrate_lw.bf.frac = frac;
    WRITE_REG_16(uart_no + ADDR_UART_BAUDRATE_LW, uart_baudrate_lw.val);
    WRITE_REG_16(uart_no + ADDR_UART_BAUDRATE_HW, divider >> 14);
}


void uart_send_byte (uart_num_t uart_no, uint8_t data) {
    uart_irq_status_t uart_status;
    do{
      uart_status.val = READ_REG_U16(uart_no + ADDR_UART_IRQ_STATUS);
    } while (uart_status.bf.tx_fifo_nfull == 0);

    WRITE_REG_16(uart_no + ADDR_UART_TX_DATA, (uint16_t) data);
}


bool uart_recv_byte (uart_num_t uart_no, uint8_t * data) {
    uart_rx_data_t  rx_data;
    rx_data.val = READ_REG_U16(uart_no + ADDR_UART_RX_DATA);
    if (rx_data.bf.valid == 1) {
      *data = rx_data.bf.rx_data;
      return true;
    } else
      return false;
}


uint8_t uart_get_rxdata (uart_num_t uart_no) {
    uart_rx_data_t  rx_data;
    rx_data.val = READ_REG_U16(uart_no + ADDR_UART_RX_DATA);
    return rx_data.bf.rx_data;
}

bool uart_transmitting(uart_num_t uart_no){
  uart_irq_status_t uart_status;
  uart_status.val = READ_REG_U16(uart_no + ADDR_UART_IRQ_STATUS);
  if (uart_status.bf.tx_transmitting == 1)
    return true;
  return false;
}

void uart_enable_irq (uart_num_t uart_no, uart_irq_t irq, bool enable) {
  uint16_t irq_mask = READ_REG_U16(uart_no + ADDR_UART_IRQ_MASK);
  irq_mask &= ~((uint16_t) 1 << irq);
  irq_mask |=  ((uint16_t) (enable ? 1 : 0) << irq);
  WRITE_REG_16(uart_no + ADDR_UART_IRQ_MASK, irq_mask);
}


uart_irq_t uart_get_next_pending_irq (uart_num_t uart_no) {
  return (uart_irq_t) READ_REG_U16(uart_no + ADDR_UART_IRQ_VNO);
}

uart_irq_status_t uart_get_irq_status (uart_num_t uart_no) {
  uart_irq_status_t uart_irq_status;
  uart_irq_status.val = READ_REG_U16(uart_no + ADDR_UART_IRQ_STATUS);
  return uart_irq_status;
}

uart_irq_mask_t uart_get_irq_mask (uart_num_t uart_no) {
  return (uart_irq_mask_t) READ_REG_U16(uart_no + ADDR_UART_IRQ_MASK);
}

void uart_clear_irq (uart_num_t uart_no, uart_irq_t irq) {
    WRITE_REG_16(uart_no + ADDR_UART_IRQ_STATUS, (uint16_t) (0x01 << irq));
}

uint32_t uart_get_min_bit_length(uart_num_t uart_no){
  uint32_t tmp = 0;
  tmp |= ((uint32_t)(READ_REG_U16(uart_no + ADDR_UART_MIN_BIT_LENGTH_HW)) << 16); 
  tmp |=  (uint32_t) READ_REG_U16(uart_no + ADDR_UART_MIN_BIT_LENGTH_LW);
  return tmp;
}

void uart_fifo_clear(uart_num_t uart_no, bool rx_clear, bool tx_clear){
  uart_fifo_clear_cmd_t uart_fifo_clear_cmd;
  uart_fifo_clear_cmd.val = READ_REG_U16(uart_no + ADDR_UART_FIFO_CLEAR_CMD);
  uart_fifo_clear_cmd.bf.rx_fifo_clear = rx_clear ? 1 : 0;
  uart_fifo_clear_cmd.bf.tx_fifo_clear = tx_clear ? 1 : 0;
  WRITE_REG_16(uart_no + ADDR_UART_FIFO_CLEAR_CMD, uart_fifo_clear_cmd.val);
}

uint16_t uart_get_rx_fifo_level(uart_num_t uart_no){
  uart_fifo_levels_t  rx_level;
  rx_level.val = READ_REG_U16(uart_no + ADDR_UART_FIFO_LEVELS);
  return rx_level.bf.rx_fifo_level;
}

uint16_t uart_get_tx_fifo_level(uart_num_t uart_no){
  uart_fifo_levels_t  tx_level;
  tx_level.val = READ_REG_U16(uart_no + ADDR_UART_FIFO_LEVELS);
  return tx_level.bf.tx_fifo_level;
}

uint16_t uart_get_rx_fifo_timeout(uart_num_t uart_no){
  return READ_REG_U16(uart_no + ADDR_UART_RX_FIFO_TIMEOUT);
}

void uart_set_rx_fifo_timeout(uart_num_t uart_no, uint16_t value){
  WRITE_REG_16(uart_no + ADDR_UART_RX_FIFO_TIMEOUT, value);
}

void uart_set_rx_high_water(uart_num_t uart_no, uint8_t value){
  uart_config_t uart_config;
  uart_config.val = READ_REG_U16(uart_no + ADDR_UART_CONFIG);
  uart_config.bf.rx_fifo_high_water = value;
  WRITE_REG_16(uart_no + ADDR_UART_CONFIG, uart_config.val);  
}

void uart_set_tx_low_water(uart_num_t uart_no, uint8_t value){
  uart_config_t uart_config;
  uart_config.val = READ_REG_U16(uart_no + ADDR_UART_CONFIG);
  uart_config.bf.tx_fifo_low_water = value;
  WRITE_REG_16(uart_no + ADDR_UART_CONFIG, uart_config.val);
}

