/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         usi_irq.h
*
* @brief        USI HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __USI_IRQ_H__
#define __USI_IRQ_H__

#include <usi_bf.h>

#define USI_NUM_IRQS 14

/**
 * \brief This enumeration describes USI IRQ
 *
 * \ingroup usi
 *
 */
typedef enum{
  USI_IRQ_REVENTS_0 =                   0, ///< receive event 0 - usi_dma_rxcfg_t::revents
  USI_IRQ_REVENTS_1 =                   1, ///< receive event 1 - usi_dma_rxcfg_t::revents
  USI_IRQ_REVENTS_2 =                   2, ///< receive event 2 - usi_dma_rxcfg_t::revents
  USI_IRQ_REVENTS_3 =                   3, ///< receive event 3 - usi_dma_rxcfg_t::revents
  USI_IRQ_REVENTS_4 =                   4, ///< receive event 4 - usi_dma_rxcfg_t::revents
  
  /**
   * receive data has been lost as no data structure is available <br>
   * interrupt type: event
   */
  USI_IRQ_RADR_NEW_UDR =                5,
  
  /**
   * bit rate extraction result register has been updated<br>
   * interrupt type: event
   */
  USI_IRQ_BRE_UPDATED =                 6,
  
  /**
   * SDI had CFG.sdi_irq_pol polarity while nss was not asserted<br>
   * interrupt type: event
   */
  USI_IRQ_EVT_SDI =                     7,
  
  /**
   * 1: TADR_NEW can accept a new pointer.<br>
   * interrupt type: status
   */
  USI_IRQ_TADR_NEW_NFULL =              8,
  
  /**
   * 1: TADR_DONE contains a newly completed pointer.<br>
   * interrupt type: status
   */
  USI_IRQ_TADR_DONE_NEMPTY =            9,
  
  /**
   * 1: RADR_NEW can accept a new pointer.<br>
   * interrupt type: status
   */
  USI_IRQ_RADR_NEW_NFULL =              10,
  
  /**
   * 1: RADR_DONE contains a newly completed pointer.<br>
   * interrupt type: status
   */
  USI_IRQ_RADR_DONE_NEMPTY =            11,
  
  /**
   * transmit transfer in progress<br>
   * interrupt type: status
   */
  USI_IRQ_TRANSMITTING =                12,
  
  /**
   * receive transfer in progress<br>
   * interrupt type: status
   */
  USI_IRQ_RECEIVING =                   13
} usi_irq_t;





/* ############################################################################ */
/**
 * \brief  USI interrupt call SPI or UART subroutines
 *         \see usi_spi_dma_init() 
 *         \see usi_uart_dma_init()
 *
 * \ingroup usi
 *
 * \param  usi_no   USI instance
 *
 * \param spi_Nuart true - SPI <br>
 *                  false - UART <br>
 */
void usi_irq_set_spi_Nuart(usi_num_t usi_no, bool spi_Nuart);

#endif
