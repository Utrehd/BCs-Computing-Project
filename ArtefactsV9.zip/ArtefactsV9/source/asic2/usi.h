/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         usi.h
*
* @brief        USI HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __USI_H__
#define __USI_H__

/**
 * \defgroup usi ASIC2 USI HAL functions
 *  
 * \ingroup  asic2_hal
 *
 * \brief    Functions to control USI (can be used as UART or SPI)
 *
 * How to calculate bitrate:
 * acc = (acc + br_inc) % br_mod generates ticks
 * \see usi_cfg_br_inc(), usi_cfg_br_mod()
 *
 */
/**@{*/ 

#include "device.h"

#include "usi_irq.h"
#include "usi_bf.h"

//=======================================================================

// Please include either
// - usi_uart.h
// or
// - usi_spi.h

//=======================================================================
// config (set at any time)
//=======================================================================
#define USI_DMA_MODE_LENGTH     0
#define USI_DMA_MODE_TRANSFER   1

/* ############################################################################ */
/**
 * \brief   USI General Enable
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \param   enable    Enable USI instance <br>
 *                    Disabling the module will stop all transfers and DMA operations 
 *                    in progress and clear all data and pointer FIFOs.
 *
 */
void usi_enable(usi_num_t usi_no, bool enable);

/* ############################################################################ */
/**
 * \brief   set USI bitrate generation increment
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \param   br_inc    bit rate generation: increment
 *                    The increment can be updated by software at any time,
 *                    immediately affecting the length of all bits. [comm_clk]
 *
 */
void usi_cfg_br_inc(usi_num_t usi_no, uint16_t br_inc);

/* ############################################################################ */
/**
 * \brief   enable transmit function for USI
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \param   enable    enable transmit function
 *
 */
void usi_tx_enable(usi_num_t usi_no, bool enable);

/* ############################################################################ */
/**
 * \brief   enable receive function for USI
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \param   enable    enable receive function
 *
 */
void usi_rx_enable(usi_num_t usi_no, bool enable);

/* ############################################################################ */
/**
 * \brief   set DMA mode when transfer ends for USI
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \param   mode      0: DMA transfer ends when tdlen is reached <br>
 *                    1: like "0" but also when SPI slave transfer ends
 *
 */
void usi_spi_cfg_tx_dma_mode(usi_num_t usi_no, bool mode);

/* ############################################################################ */
/**
 * \brief   set DMA mode when transfer ends for USI
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \param   mode      0: DMA transfer ends when maxlen is reached <br>
 *                    1: like "0" but also when SPI slave transfer ends
 *
 */
void usi_spi_cfg_rx_dma_mode(usi_num_t usi_no, bool mode);

/* ############################################################################ */
/**
 * \brief   get USI bitrate generation increment
 *          \see usi_cfg_br_inc()
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \return  current bitrate increment value
 *
 */
uint16_t usi_get_cfg_br_inc(usi_num_t usi_no);

/* ############################################################################ */
/** 
 * \brief Bit Rate Extraction mode
 *
 * \ingroup usi
 */
typedef enum{
  /**
   * Bit rate extraction is disabled
   */
  USI_BRE_OFF         =   0,
  
  /**
   * After a valid break measure the distance between 5 falling edges (i.e. 8 bit times) of sdi. 
   * This measurement requires a break to be sent followed by 0x55.
   */
  USI_BRE_BREAK       =   1,
  
  /**
   * Starting with a detected start bit measure the distance between 5 falling edges (i.e. 8 bit times) of sdi. 
   * This measurement requires the knowledge when a 0x55 is sent and/or large pauses between 0x55 bytes. 
   * Does not work with Break.
   * Can also be used in SPI mode.
   */
  USI_BRE_PAUSE       =   2,
  
  /**
   * Same as USI_BRE_PAUSE but U_BRE_RES is only updated only when 0x55 has been received successfully. 
   * This mode can be used for updating the bit rate. 
   * Does not work with Break.
   */
  USI_BRE_CHECK       =   3,
  
  /**
   * Minimum search. Continuously updates the shortest '0' period detected. 
   * The minimum is cleared (set to MAX) when U_BRE_RES is read.
   * Can also be used in SPI mode.
   */
  USI_BRE_MIN         =   4
} usi_bre_mode_t;

/* ############################################################################ */
/**
 * The bit rate of an incoming uart words can be extracted. All measurements are performed in c omm_clk clock
 * cycles and the result is written to U_BRE_RES.
 * The incoming sdi signal is filtered by an integration filter with the configurable threshold CFG_INTF to
 * remove glitches. The filtered sdi signal is processed by one the following algorithms:
 *
 * \brief   Set bit rate mode extaction
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \param   mode      0: bit rate extraction disabled <br>
 *                    1-4: see functional description <br>
 *                         in Uart Mode BRE uses the filtered sdi_i <br>
 *                         in SPI mode the filtered sck_i signal. <br>
 *                         \see usi_bre_mode_t
 *
 */
void usi_set_bre_mode(usi_num_t usi_no, usi_bre_mode_t mode);

/* ############################################################################ */
/**
 * \brief   Get result of bit rate extraction
 *
 * \see usi_set_bre_mode()
 *
 * \ingroup usi
 *
 * \return  result of bit rate extraction
 */
uint32_t  usi_get_bre_res(usi_num_t usi_no);

//=======================================================================
// config (locked by enable)
//=======================================================================
#define USI_MODE_UART false
#define USI_MODE_SPI  true

/* ############################################################################ */
/**
 * \brief   Set USI mode. Can be changed only when CFG.en=0 - usi_enable()
 *
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \param   mode      false : UART (macro USI_MODE_UART) <br>
 *                    true  : SPI  (USI_MODE_SPI)
 *
 */
void usi_cfg_mode(usi_num_t usi_no, bool mode);

/* ############################################################################ */
/**
 * \brief   Swap sdi and sdo
 *
 * \ingroup usi
 * 
 * \param   usi_no        USI instance
 *
 * \param   sdi_sdo_swap  true  : swap sdi and sdo assignment at module interface
 *
 */
void usi_cfg_sdi_sdo_swap(usi_num_t usi_no, bool sdi_sdo_swap);

/* ############################################################################ */
/**
 * \brief   Connect sdi and sdo
 *
 * \ingroup usi
 * 
 * \param   usi_no            USI instance
 *
 * \param   sdi_sdo_loopback  true  : connect sdo to sdi internally
 *
 */
void usi_cfg_sdi_sdo_loopback(usi_num_t usi_no, bool sdi_sdo_loopback);

/* ############################################################################ */
/**
 * \brief   Half duplex 
 *
 * \ingroup usi
 * 
 * \param   usi_no          USI instance
 *
 * \param   sdi_uses_sdo_i  true  : sdi connected to sdo_i for half duplex communication without
 *                                  external phy
 *
 */
void usi_cfg_sdi_uses_sdo_i(usi_num_t usi_no, bool sdi_uses_sdo_i);

/* ############################################################################ */
/**
 * \brief   Invert sdo_o and sdo_i
 *
 * \ingroup usi
 * 
 * \param   usi_no          USI instance
 *
 * \param   sdo_inv  true  : Invert sdo_o and sdo_i
 *
 */
void usi_cfg_sdo_inv(usi_num_t usi_no, bool sdo_inv);

/* ############################################################################ */
/**
 * \brief   Invert sdi_i
 *
 * \ingroup usi
 * 
 * \param   usi_no          USI instance
 *
 * \param   sdi_inv  true  : Invert sdi_i
 *
 */
void usi_cfg_sdi_inv(usi_num_t usi_no, bool sdi_inv);

/* ############################################################################ */
/**
 * \brief   Invert nss_o and nss_i
 *
 * \ingroup usi
 * 
 * \param   usi_no          USI instance
 *
 * \param   sdi_inv  true  : Invert nss_o and nss_i
 *
 */
void usi_cfg_nss_inv(usi_num_t usi_no, bool nss_inv);

/* ############################################################################ */
/**
 * \brief   Bit rate generation: modulus [comm_clk]
 *          Can be changed only when CFG.en=0 - usi_enable()
 *
 * \ingroup usi
 * 
 * \param   usi_no  USI instance
 *
 * \param   br_mod  bit rate generation: modulus
 *
 */
void usi_cfg_br_mod(usi_num_t usi_no, uint16_t br_mod);

/* ############################################################################ */
/**
 * \brief   Set bilt length [ticks]
 *          Can be changed only when CFG.en=0 - usi_enable()
 *
 * \ingroup usi
 * 
 * \param   usi_no           USI instance
 *
 * \param   tick_bit_length  UART: bit length in ticks <br>
 *                           SPI: half bit length in ticks <br> 
 *
 */
void usi_cfg_tick_bit_length(usi_num_t usi_no, uint16_t tick_bit_length);

/* ############################################################################ */
/**
 * \brief   Set threshold of integration filters for sdi_i, nss_i and sck_i.
 *          The filtered signals are used for Uart bit rate extraction, all SPI
 *          operations and sdi irq signaling. <br>
 *          The uart start bit detection and sampling of data/parity/stop bits
 *          circumvent these filters.
 *          Can be changed only when CFG.en=0 - usi_enable()
 *
 * \ingroup usi
 * 
 * \param   usi_no   USI instance
 *
 * \param   intf     threshold of integration filters
 *
 */
void usi_cfg_intf(usi_num_t usi_no, uint16_t intf);  

//=======================================================================
// DMA TX
//=======================================================================
#define BIT_USI_DMA_TCFG_UART_SEND_BREAK 1
#define BIT_USI_DMA_TCFG_SPI_KEEP_NSS    1
#define BIT_USI_DMA_TCFG_SPI_SDO_OE_CTRL 2

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(push)
#pragma pack(2)
#endif

/* ############################################################################ */
/** 
 * \brief Data structure for transmit data
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * start address of the buffer containing the transmit transfer elements.
   * The buffer contains the data of one transmit frame.
   */
  volatile unsigned short tdadr;
  
  /**
   *  transmit options:
   *  <table>
   *   <caption id="multi_row"></caption>
   *   <tr><th> bits          </th> <th> value </th> <th> UART mode            </th> <th> SPI mode                                           </th></tr>
   *   <tr><td rowspan="2"> 0 </td> <td> 0 </td> <td> do not send break        </td> <td> deassert nss at end of frame                       </td></tr> 
   *   <tr>                         <td> 1 </td> <td> send break before buffer </td> <td> keep nss asserted after end of frame (master only) </td></tr> 
   *   <tr><td rowspan="2"> 1 </td> <td> 0 </td> <td> </td> <td> do not change sdo_oe during frame                                           </td></tr>  
   *   <tr>                         <td> 1 </td> <td> </td> <td>  sdo_oe=1 from start of frame to end of transmission (tdlen reached).    
                                                                                        Output also depends on CFG_SPI_BL.sdo_high_z.   </td></tr>    
   * </table>
   */
  volatile unsigned short tcfg;
  
  /**
   * length of the transmit transfer elements
   */
  volatile unsigned short tdlen;
} _PACKED_ usi_dma_txcfg_t;

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(pop)
#endif

/* ############################################################################ */
/**
 * \brief   Set new data structure for transmit data \see usi_dma_txcfg_t.
 *
 * \ingroup usi
 * 
 * \param   usi_no    USI instance
 *
 * \param   tadr_new  word aligned address pointer to the next data structure (input of pointer fifo)
 *
 */
void usi_dma_set_tadr_new(usi_num_t usi_no, uint16_t tadr_new);

/* ############################################################################ */
/**
 * \brief   Get pointer of data structure currently in use
 * \see     usi_dma_txcfg_t
 *
 * \ingroup usi
 * 
 * \return address of current structure (transmit)
 */
uint32_t usi_dma_get_tadr_current(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Get number of words remaining to be sent
 * \see     usi_dma_txcfg_t
 *
 * \ingroup usi
 * 
 * \return  number of words remaining to be sent
 */
uint16_t usi_dma_get_tdlen_current(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Get pointer to the done data transmit structure (output of pointer fifo)
 * \see     usi_dma_txcfg_t
 *
 * \ingroup usi
 * 
 * \return  pointer to the done data structure (output of pointer fifo)
 */
uint32_t usi_dma_get_tadr_done(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   clear the FIFO TADR_NEW
 * \see     usi_dma_txcfg_t
 *
 * \ingroup usi
 */
void usi_dma_clear_tadr_new(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   terminate (skip) current transmit data structure TADR_CURRENT and continue with the next
 * \see     usi_dma_txcfg_t
 *
 * \ingroup usi
 */
void usi_dma_skip_tadr_current(usi_num_t usi_no);

//=======================================================================
// DMA RX
//=======================================================================
#define USI_DMA_REVENTS_RECEIVE_TIMEOUT       0
#define BIT_USI_DMA_REVENTS_RECEIVE_TIMEOUT   (1 << USI_DMA_REVENTS_RECEIVE_TIMEOUT)

#define USI_DMA_REVENTS_UART_START_ERR        1
#define BIT_USI_DMA_REVENTS_UART_START_ERR    (1 << USI_DMA_REVENTS_UART_START_ERR)

#define USI_DMA_REVENTS_UART_PAR_ERR          2
#define BIT_USI_DMA_REVENTS_UART_PAR_ERR      (1 << USI_DMA_REVENTS_UART_PAR_ERR)

#define USI_DMA_REVENTS_UART_STOP_ERR         3
#define BIT_USI_DMA_REVENTS_UART_STOP_ERR     (1 << USI_DMA_REVENTS_UART_STOP_ERR)

#define USI_DMA_REVENTS_UART_BREAK            4
#define BIT_USI_DMA_REVENTS_UART_BREAK        (1 << USI_DMA_REVENTS_UART_BREAK)

#define USI_DMA_REVENTS_SPI_WORD_LEN_ERR      1
#define BIT_USI_DMA_REVENTS_SPI_WORD_LEN_ERR  (1 << USI_DMA_REVENTS_SPI_WORD_LEN_ERR)

#define USI_DMA_REVENTS_SCK_TIMEOUT           2
#define BIT_USI_DMA_REVENTS_SCK_TIMEOUT       (1 << USI_DMA_REVENTS_SCK_TIMEOUT)

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(push)
#pragma pack(2)
#endif

/* ############################################################################ */
/** 
 * \brief Data structure for receive data
 *
 * \ingroup usi
 */
typedef struct {
  /**
   * start address of the buffer for the downstream data. The buffer contains
   * the data of one receive frame.
    */
  volatile unsigned short rdadr;
  
  /**
   * maximum length of the receive buffer in words
   */
  volatile unsigned short maxlen;
  
  /**
   * receive events occured during current frame . This field is n ot
   * continuously updated. Only written when switching to the next buffer.
   * Clearing the event in the IRQ_STATUS register will not affect revent s .
   * Will be initialized to 0 by hardware.
   *
   *  <table>
   *   <caption id="multi_row"></caption>
   *   <tr><th> bits          </th> <th> UART mode                       </th> <th> SPI mode                                             </th></tr>
   *   <tr><td> 0             </td> <td> 1: receive timeout ended frame  </td> <td> 1: receive timeout ended frame                       </td></tr> 
   *   <tr><td> 1             </td> <td> 1: start bit error              </td> <td> 1: word length error (last word of frame incomplete) </td></tr> 
   *   <tr><td> 2             </td> <td> 1: parity error                 </td> <td> 1: receive timeout ended frame                       </td></tr>    
   *   <tr><td> 3             </td> <td> 1: stop bit error               </td> <td> 1: sck timeout occurred                              </td></tr> 
   *   <tr><td> 4             </td> <td> 1: break occurred               </td> <td>                                                      </td></tr> 
   *   <tr><td> 5             </td> <td> 0                               </td> <td> 0                                                    </td></tr>    
   * </table>
   */
  volatile unsigned short revents;
  
  /**
   * length of the received  transfer elements . This field is not continuously
   * updated. Only written when switching to the next buffer.
   */
  volatile unsigned short rdlen;
} _PACKED_ usi_dma_rxcfg_t;

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(pop)
#endif

/* ############################################################################ */
/**
 * \brief   Set DMA rx timeout.
 *
 * \ingroup usi
 * 
 * \param   usi_no     USI instance
 *
 * \param   rx_timeout 0 = disabled <br>
 *                     >0: number of system clock cycles until timeout event.<br>
 *                         Timeout is reset with every newly received transfer element.<br>
 *
 */
void usi_dma_cfg_rx_timeout(usi_num_t usi_no, uint32_t rx_timeout);

/* ############################################################################ */
/**
 * \brief   Set new data structure for receive data \see usi_dma_rxcfg_t.
 *
 * \ingroup usi
 * 
 * \param   usi_no     USI instance
 *
 * \param   radr_new   word aligned address pointer to the next data structure (input of pointer fifo) use POINTER_TO_ADDRESS()
 *
 */
void usi_dma_set_radr_new(usi_num_t usi_no, uint16_t radr_new);

/* ############################################################################ */
/**
 * \brief   Get pointer of data structure currently in use
 * \see     usi_dma_rxcfg_t
 *
 * \ingroup usi
 * 
 * \return address of current structure (receive)
 */
uint32_t usi_dma_get_radr_current(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Get number of received words
 * \see     usi_dma_rxcfg_t 
 *
 * \ingroup usi
 * 
 * \return  number of receive words
 */
uint16_t usi_dma_get_rdlen_current(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Get pointer to the done data receive structure (output of pointer fifo)
 * \see     usi_dma_rxcfg_t
 *
 * \ingroup usi
 * 
 * \return  pointer to the done data structure (output of pointer fifo)
 */
uint32_t usi_dma_get_radr_done(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Clear the FIFO RADR_NEW
 * \see     usi_dma_rxcfg_t
 *
 * \ingroup usi
 * 
 */
void usi_dma_clear_radr_new(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Write rdlen and then terminate (skip) current receive data structure
 *          RADR_CURRENT and continue with the next
 * \see     usi_dma_rxcfg_t
 *
 * \ingroup usi
 * 
 */
void usi_dma_skip_radr_current(usi_num_t usi_no);

//=======================================================================
// DMA sync
//=======================================================================


/* ############################################################################ */
/**
 * \brief   Write rdlen and then terminate (skip) current receive data structure
 *          RADR_CURRENT and continue with the next
 *
 * \param   usi_no     USI instance
 *
 * \param   sync_en    1: Uart transmit and SPI master frame wait for sync strobe to start
 *
 * \param   sync_delay number of clock cycles after sync pulse occurred to start
 *                     of transmission. This gives the DMA machines time to
 *                     fetch the DMA structures. ( recommended > 23  )
 *
 * \ingroup usi
 * 
 */
void usi_dma_cfg_sync(usi_num_t usi_no, bool sync_en, uint8_t sync_delay);

/* ############################################################################ */
/**
 * \brief   Prepare data to transmit when synchronization occured
 *
 * \see     usi_dma_cfg_sync(), usi_dma_txcfg_t
 *
 * \param   usi_no      USI instance
 *
 * \param   tadr_new_ws Copied to TADR_NEW when sync strobe occurs and has been written
 *                      to since the last write sync and CFG_SYNC.en = 1 .
 *
 * \ingroup usi
 * 
 */
void usi_dma_set_tadr_new_ws(usi_num_t usi_no, uint16_t tadr_new_ws);

/* ############################################################################ */
/**
 * \brief   Prepare data to receive when synchronization occured
 *
 * \see     usi_dma_cfg_sync(), usi_dma_rxcfg_t
 *
 * \param   usi_no      USI instance
 *
 * \param   radr_new_ws Copied to RADR_NEW when sync strobe occurs and has been
 *                      written to since the last write sync and CFG_SYNC.en = 1 .
 *
 * \ingroup usi
 * 
 */
void usi_dma_set_radr_new_ws(usi_num_t usi_no, uint16_t radr_new_ws);

//=======================================================================
// helper wrapper
//=======================================================================

/* ############################################################################ */
/**
 * \brief   Return number of USI instance
 *
 * \param   usi_no      USI instance
 *
 * \return  Number of USI instance
 *
 * \ingroup usi
 * 
 */
int usi_no_to_index(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Enable RX, TX, and general enable
 *
 * \see usi_tx_enable(), usi_rx_enable(), usi_enable()
 *
 * \param   usi_no      USI instance
 *
 * \param   enable      enable USI
 *
 * \ingroup usi
 * 
 */
void usi_full_enable(usi_num_t usi_no, bool enable);

/* ############################################################################ */
/**
 * \brief   Get Interrupt flag tadr_new_nfull
 *
 * \param   usi_no  USI instance
 *
 * \return  true: TADR_NEW can accept a new pointer.
 *
 * \ingroup usi
 * 
 */
bool usi_tadr_new_is_nfull(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Get Interrupt flag tadr_done_nempty
 *
 * \param   usi_no  USI instance
 *
 * \return  true: TADR_DONE contains a newly completed pointer.
 *
 * \ingroup usi
 * 
 */
bool usi_tadr_done_is_nempty(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Get Interrupt flag radr_new_nfull
 *
 * \param   usi_no  USI instance
 *
 * \return  true: RADR_NEW can accept a new pointer.
 *
 * \ingroup usi
 * 
 */
bool usi_radr_new_is_nfull(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Get Interrupt flag radr_done_nempty
 *
 * \param   usi_no  USI instance
 *
 * \return  true: RADR_DONE contains a newly completed pointer.
 *
 * \ingroup usi
 * 
 */
bool usi_radr_done_is_nempty(usi_num_t usi_no);

//=======================================================================
// DMA helpers
//=======================================================================

/* ############################################################################ */
/**
 * \brief Fill in usi_dma_txcfg_t structure
 *
 * \param len           length of the transmit transfer elements 
 *
 * \param data          pointer to data buffer to be sent
 *
 * \param tcfg          transmit options, usi_dma_txcfg_t::tcfg
 *
 * \param usi_dma_txcfg pointer to usi_dma_txcfg_t structure which will be given to<br> 
 *                      usi_dma_send_frame() or directly to usi_dma_set_tadr_new()
 *
 * \ingroup usi
 * 
 */
void usi_dma_prepare_txcfg(uint16_t len, void * data, uint16_t tcfg, usi_dma_txcfg_t *usi_dma_txcfg);

/* ############################################################################ */
/**
 * \brief Prepare transmit structure to DMA
 *
 * \see usi_dma_cfg_sync(), usi_dma_txcfg_t
 *
 * \param  usi_no        USI instance
 *
 * \param  sync          Uart transmit and SPI master frame wait for sync strobe to start enable
 *
 * \param  usi_dma_txcfg pointer to usi_dma_txcfg_t structure
 *
 * \ingroup usi
 * 
 */
void usi_dma_send_frame(usi_num_t usi_no, bool sync, volatile usi_dma_txcfg_t *usi_dma_txcfg);

/* ############################################################################ */
/**
 * \brief Fill in usi_dma_txcfg_t structure
 *
 * \param maxlen        maximum length of the receive buffer in words 
 *
 * \param data          pointer to data buffer to be received
 *
 * \param usi_dma_rxcfg pointer to usi_dma_rxcfg_t structure which will be given to<br> 
 *                      usi_dma_provide_rxcfg() or directly to usi_dma_set_radr_new()
 *
 * \ingroup usi
 * 
 */
void usi_dma_prepare_rxcfg(uint16_t maxlen, void * data, usi_dma_rxcfg_t *usi_dma_rxcfg);

/* ############################################################################ */
/**
 * \brief Prepare receive structure to DMA
 *
 * \see usi_dma_cfg_sync(), usi_dma_rxcfg_t
 *
 * \param  usi_no        USI instance
 *
 * \param  usi_dma_rxcfg pointer to usi_dma_rxcfg_t structure
 *
 * \param  sync          Uart receive and SPI master frame wait for sync strobe to start enable
 *
 * \ingroup usi
 * 
 */
bool usi_dma_provide_rxcfg(usi_num_t usi_no, volatile usi_dma_rxcfg_t *usi_dma_rxcfg, bool sync);

/* ############################################################################ */
/**
 * \brief Get data from receive structure. Save receive events to local structure - usi_get_revents().
 *
 * \param   usi_no    USI instance
 *
 * \param   data      returns pointer to data buffer where data were received
 *
 * \param   rdlen     pointer to number received words
 *
 * \return  true when receive structure contains new data   
 *
 * \ingroup usi
 * 
 */
bool usi_dma_get_rx_data(usi_num_t usi_no, void ** data, uint16_t *rdlen);

/* ############################################################################ */
/**
 * \brief Gets receive events (save during last usi_dma_get_rx_data() execution)
 * 
 * \param   usi_no    USI instance 
 *
 * \return  receive events - usi_dma_rxcfg_t::revents
 *
 * \ingroup usi
 * 
 */
uint8_t usi_get_revents(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief   Clear local structure with receive events 
 *
 * \param   usi_no    USI instance 
 *
 * \ingroup usi
 * 
 */
void usi_clear_revents(usi_num_t usi_no);

//=======================================================================
// IRQ
//=======================================================================

/* ############################################################################ */
/**
 * \brief   Set IRQ mask for USI
 *
 * \param   usi_no    USI instance 
 *
 * \param   irq       interrupt source
 *
 * \param   enable    enable irq source
 *
 * \ingroup usi
 * 
 */
void usi_enable_irq(usi_num_t usi_no, usi_irq_t irq, bool enable);

/* ############################################################################ */
/**
 * \brief Get pending USI interrupt
 *
 * \param   usi_no    USI instance 
 *
 * \ingroup usi
 *
 * \return vector number of enabled pending interrupt with highest priority
 *         (smallest vector number). when no irq is pending the first unused irq
 *         number is returned.
 *
 */
usi_irq_t usi_get_next_pending_irq(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief Get IRQ status of USI
 *
 * \param   usi_no    USI instance  
 *
 * \return IRQ status of USI 
 *
 * \note unmasked status of all pending irqs<br>
 *             1: pending <br>
 *             0: no request <br>
 *
 * \note write: clear event flags <br>
 *              1: clear related flag <br>
 *              0: do not change flag <br>
 *
 * \ingroup usi
 */ 
usi_irq_status_t usi_get_irq_status(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief Clear interrupt flag of USI
 *
 * \param   usi_no    USI instance  
 *
 * \param   irq       specify irq bit which should be cleared
 *
 * \ingroup usi
 */
void usi_clear_irq(usi_num_t usi_no, usi_irq_t irq);

/* ############################################################################ */
/**
 * \brief Clear all interrupt flags of USI
 *
 * \param   usi_no    USI instance  
 *
 * \ingroup usi
 */
void usi_clear_all_irq(usi_num_t usi_no);

/**@{*/ 
#endif /* HAVE_USI_H */
