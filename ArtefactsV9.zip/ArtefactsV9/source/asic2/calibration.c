/* FPGA Release: 10512 */
#include "device.h"
#include "sram.h"
#include "analog_ctrl_bf.h"
#include "hv_ctrl.h"
#include "flash_ctrl.h"

        
#define CALIBRATION_CAL_ANA_VREF        0x30000
#define CALIBRATION_CAL_ANA_IREF        0x30002
#define CALIBRATION_CAL_ANA_HFOSC       0x30004
#define CALIBRATION_CAL_ANA_PLL         0x30006
#define CALIBRATION_CAL_SARADC_CORR09   0x30008
#define CALIBRATION_CAL_SARADC_CORR10   0x3000A
#define CALIBRATION_CAL_SARADC_CORR11   0x3000C

#define CALIBRATION_HV_CAL0             0x30010
#define CALIBRATION_HV_CAL1             0x30012
#define CALIBRATION_HV_CAL2             0x30014

#define CALIBRATION_RCOSC_LF_FREQ_LW    0x30030
#define CALIBRATION_RCOSC_LF_FREQ_HW    0x30032

#define CALIBRATION_AOUT0_OFFSET        0x30034
#define CALIBRATION_AOUT1_OFFSET        0x30036
#define CALIBRATION_AOUT0_GAIN          0x30038
#define CALIBRATION_AOUT1_GAIN          0x3003A

#define CALIBRATION_VERSION             0x30048

#define CALIBRATION_SERIAL_LW           0x3004A
#define CALIBRATION_SERIAL_HW           0x3004C

void calibrate_lv(void){
  WRITE_REG_16(AADDR_ANALOG_CTRL_CAL_ANA_VREF,      READ_REG_U16(CALIBRATION_CAL_ANA_VREF     ));
  WRITE_REG_16(AADDR_ANALOG_CTRL_CAL_ANA_IREF,      READ_REG_U16(CALIBRATION_CAL_ANA_IREF     ));
  WRITE_REG_16(AADDR_ANALOG_CTRL_CAL_ANA_HFOSC,     READ_REG_U16(CALIBRATION_CAL_ANA_HFOSC    ));
  WRITE_REG_16(AADDR_ANALOG_CTRL_CAL_ANA_PLL,       READ_REG_U16(CALIBRATION_CAL_ANA_PLL      ));
  WRITE_REG_16(ADDR_ANALOG_CTRL_CAL_SARADC_CORR09,   READ_REG_U16(CALIBRATION_CAL_SARADC_CORR09));
  WRITE_REG_16(ADDR_ANALOG_CTRL_CAL_SARADC_CORR10,   READ_REG_U16(CALIBRATION_CAL_SARADC_CORR10));
  WRITE_REG_16(ADDR_ANALOG_CTRL_CAL_SARADC_CORR11,   READ_REG_U16(CALIBRATION_CAL_SARADC_CORR11));
}

inline static void wait_hv_request(void){
  while(READ_REG_U16(AADDR_HV_CTRL_IRQ_STATUS) & BIT_HV_CTRL_IRQ_STATUS_CPU_REQUEST);
}

inline static void write_hv_reg(uint8_t ir, uint16_t dr){
  WRITE_REG_16(AADDR_HV_CTRL_JTAG_IR_CMD, ir);
  WRITE_REG_16(AADDR_HV_CTRL_JTAG_DR_CMD, dr);
  wait_hv_request();
}

inline static void hv_tap_reset(void){
  WRITE_REG_16(AADDR_HV_CTRL_JTAG_IR_CMD, BIT_HV_CTRL_JTAG_IR_CMD_TAP_RESET);
  wait_hv_request();
}

void calibrate_hv(void){
  WRITE_REG_16(AADDR_HV_CTRL_JTAG_RESET,        1);
  hv_tap_reset();
  write_hv_reg(ADDR_HV_IR_IR_CLEAR_RESET_FLAG,  1);
  write_hv_reg(ADDR_HV_IR_IR_CAL0,              READ_REG_U16(CALIBRATION_HV_CAL0));
  write_hv_reg(ADDR_HV_IR_IR_CAL1,              READ_REG_U16(CALIBRATION_HV_CAL1));
  write_hv_reg(ADDR_HV_IR_IR_CAL2,              READ_REG_U16(CALIBRATION_HV_CAL2));
}

uint32_t calibration_get_rcosc_lf_freq(void){
  return READ_REG_U32(CALIBRATION_RCOSC_LF_FREQ_LW);
}

uint16_t calibration_get_aout_offset(uint8_t i_aout) {
  switch(i_aout) {
  case 0:  
    return READ_REG_U16(CALIBRATION_AOUT0_OFFSET);
    break;
    
  case 1:  
    return READ_REG_U16(CALIBRATION_AOUT1_OFFSET);
    break;
    
  default:
    while(1);
    break;
  }
}

uint16_t calibration_get_aout_gain(uint8_t i_aout) {
  switch(i_aout) {
  case 0:  
    return READ_REG_U16(CALIBRATION_AOUT0_GAIN);
    break;
    
  case 1:  
    return READ_REG_U16(CALIBRATION_AOUT1_GAIN);
    break;
    
  default:
    while(1);
    break;
  }
}

uint32_t calibration_get_serial(void){
  uint32_t sn = READ_REG_U16(CALIBRATION_SERIAL_HW);
  sn <<= 16;
  sn += READ_REG_U16(CALIBRATION_SERIAL_LW);
  return sn;
}

uint16_t calibration_get_version(void){
  return READ_REG_U16(CALIBRATION_VERSION);
}
