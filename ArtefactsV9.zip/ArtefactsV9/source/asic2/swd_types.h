/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swd_types.h
*
* @brief        SWD_PM HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __SWD_TYPES_H__
#define __SWD_TYPES_H__

#ifndef HAVE_SWD_H
#error "Please include swd.h instead of this file."
#endif

// ------------------------------------------------------------
// these structures need to be packed
// ------------------------------------------------------------
#ifdef __GNUC__
#define _PACKED_ __attribute__ ((packed))
#endif

#ifdef __IAR_SYSTEMS_ICC__

#pragma pack(push)
#pragma pack(1)
#define _PACKED_
#endif

// SIZES LIST ENTRY

/* ############################################################################ */
/**
 * \brief Not found in specification
 *
 * \ingroup swd_pm 
 */ 
typedef struct {
    uint8_t write_length            : 6;       /* [5 ... 0] */
    uint8_t big_entry               : 1;       /* [6] */
    uint8_t replace                 : 1;       /* [7] */
} _PACKED_ swd_sizes_entry_bf;


/* ############################################################################ */
/**
 * \brief Not found in specification
 *
 * \ingroup swd_pm 
 */ 
typedef union {
    unsigned char              val;  ///< bit field representation
    swd_sizes_entry_bf      bf;  ///< word representation
} _PACKED_ swd_sizes_entry_t;

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(pop)
#endif

// ------------------------------------------------------------
// no packing needed here
// ------------------------------------------------------------

#define CYCLIC_STATUS_SIZE 3


/* ############################################################################ */
/**
 * \brief  Start Delimiter and Hamming Distances
 *
 *         The start delimiters were chosen in a way that there is a hamming distance of at least four in one group and
 *         a hamming distance of at least three between all start delimiters.
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * SDw open acyclic write connection to a node
   */ 
    SWD_SDW                          = 0x68,
  /**
   * SDb opens broadcast connection to multiple nodes
   */ 
    SWD_SDB                          = 0xDC,
} swd_start_delimiter_t;

// IRQ STATUS

/* ############################################################################ */
/**
 * \brief Structure to describe IRQ status
 *
 * \ingroup swd_pm 
 */ 
typedef struct {
  /**
   * IRQ status from Protocol Engine group
   */ 
    swd_irq_status_pe_t     pe;
  /**
   * IRQ status from DMA group
   */ 
    swd_irq_status_dma_t    dma;
  /**
   * 
   * IRQ status from COMM group
   */ 
    swd_irq_status_comm_t   comm;
  /**
   * 
   */ 
    unsigned short                      reserved;
} swd_irq_status_all;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of IRQ status
 *
 * \ingroup swd_pm 
 */ 
typedef union {
    uint64_t                        val;  ///< bit field representation
    swd_irq_status_all      all;  ///< word representation
} swd_irq_status_t;

// IRQ MASK

/* ############################################################################ */
/**
 * \brief  Structure to describe IRQ mask
 *
 * \ingroup swd_pm 
 */ 
typedef struct {
  /**
   * IRQ mask from Protocol Engine group
   */ 
    swd_irq_mask_pe_t       pe;
  /**
   * IRQ mask from DMA group
   */ 
    swd_irq_mask_dma_t      dma;
  /**
   * IRQ mask from COMM group
   */ 
    swd_irq_mask_comm_t     comm;
  /**
   * 
   */ 
    unsigned short                      reserved;
} swd_irq_mask_all;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of IRQ mask
 *
 * \ingroup swd_pm 
 */ 
typedef union {
    uint64_t                        val;  ///< bit field representation
    swd_irq_mask_all        all;  ///< word representation
} swd_irq_mask_t;

// PE CONFIG

/* ############################################################################ */
/**
 * \brief PE Configuration
 *
 * \ingroup swd_pm 
 */ 
typedef struct {
  /**
   *  PE Configuration Low Word
   */ 
    swd_pe_config_lw_t       lw;
  /**
   *  PE Configuration High Word
   */ 
    swd_pe_config_hw_t       hw;
} swd_pe_config_all;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of PE Configuration
 *
 * \ingroup swd_pm 
 */ 
typedef union {
    uint32_t                        val;  ///< bit field representation
    swd_pe_config_all       all;  ///< word representation
} swd_pe_config_t;



/* ############################################################################ */
/**
 * \brief Definition of SWD baudrates
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * 10 Mbps
   */ 
    SWD_BAUDRATE_10M                 = 10000000,
} swd_baudrate_t;

///* ############################################################################ */
///**
// * \brief Not used
// *
// * \ingroup swd_pm 
// */ 
//typedef struct {
//    swd_busstat_threshold0_t         threshold0;
//    swd_busstat_threshold1_t         threshold1;
//    swd_busstat_threshold2_t         threshold2;
//    swd_busstat_threshold2_t         threshold3;
//    swd_busstat_threshold2_t         threshold4;
//} swd_busstat_thresholds_t;
//
//
///* ############################################################################ */
///**
// * \brief 
// *
// * \ingroup swd_pm 
// */ 
//typedef struct {
//    swd_busstat_count0_t             count0;
//    swd_busstat_count1_t             count1;
//    swd_busstat_count2_t             count2;
//
//    swd_busstat_count3_t             count3;
//} swd_busstat_counts_t;


/* ############################################################################ */
/**
 * \brief PE_COMMAND
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
    /**
     * start cyclic transfer
     */
    SWD_COMMAND_CYC                  = 1,
    
    /**
     * start grant for start acyclic transfer
     */
    SWD_COMMAND_GNT                  = 2,
} swd_command_t;


/* ############################################################################ */
/**
 * \brief 
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * SUCCESS (transfer successful)
   */ 
    SWD_RESULT_SUCCESS               = 1,
  /**
   * START_ERR (start-bit error)
   */ 
    SWD_RESULT_START_ERR             = 2,
  /**
   * STOP_ERR (stop-bit error)
   */ 
    SWD_RESULT_STOP_ERR              = 3,
  /**
   * READBACK_DATA_ERR (data readback error)
   */ 
    SWD_RESULT_READBACK_DATA_ERR     = 4,
  /**
   * RX_TIMEOUT (receive timeout)
   */ 
    SWD_RESULT_RX_TIMEOUT            = 5,
  /**
   * CRC8_ERR (CRC8 header error)
   */ 
    SWD_RESULT_CRC8_ERR              = 6,
  /**
   * CRC32_ERR (CRC32 frame error)
   */ 
    SWD_RESULT_CRC32_ERR             = 7,
  /**
   * DMA_ERR (DMA error (see DMA_ERRORS)
   */ 
    SWD_RESULT_DMA_ERR               = 8,
  /**
   * DISACK (DisAck detected, but no error detected)
   */ 
    SWD_RESULT_DISACK                = 9,
  /**
   * GRANT_ERR (Grant error, only with transfer_type = 10)
   */ 
    SWD_RESULT_GRANT_ERR             = 10,
  /**
   * SDN_ERR (SDN error, with transfer type = 00 or 11))
   */ 
    SWD_RESULT_SDN_ERR               = 11,
  /**
   * TAKEOVER_ERR (Takeover error)
   */ 
    SWD_RESULT_TAKEOVER_ERR          = 12,
  /**
   * SPEED_ERR (resync speed error)
   */ 
    SWD_RESULT_SPEED_ERR             = 13,
  /**
   * READBACK_DISACK_ERR (disack readback error)
   */ 
    SWD_RESULT_READBACK_DISACK_ERR   = 14,
  /**
   * NOT_IDLE (not idle error)
   */ 
    SWD_RESULT_NOT_IDLE_ERR          = 15,
  /**
   * DISACK2 (DisAck2 detected, but no error detected)
   */ 
    SWD_RESULT_DISACK2               = 16,
  /**
   * READBACK_REPEAT_ERR (repeat readback error)
   */ 
    SWD_RESULT_READBACK_REPEAT_ERR   = 17,
  /**
   * READBACK_NO_RX_ERR (readback error because of no rx data)
   */ 
    SWD_RESULT_READBACK_NO_RX_ERR    = 18,
} swd_result_t;


/* ############################################################################ */
/**
 * \brief ???
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * 
   */ 
    SWD_TRANSFER_CYCLIC              = 1,
  /**
   * 
   */ 
    SWD_TRANSFER_GRANT               = 2,
  /**
   * 
   */ 
    SWD_TRANSFER_ACYCLIC             = 3,
} swd_transfer_t;


/* ############################################################################ */
/**
 * \brief ???Specify SAP source???
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * SAP source 0
   */ 
    SWD_SAP_SOURCE0                  = 0,
  /**
   * SAP source 1
   */ 
    SWD_SAP_SOURCE1                  = 1,
  /**
   * SAP source 2
   */ 
    SWD_SAP_SOURCE2                  = 2,
  /**
   * SAP source 3
   */ 
    SWD_SAP_SOURCE3                  = 3,
} swd_sap_src_t;


/* ############################################################################ */
/**
 * \brief SAP source FSM states
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * NONE (no address recognized)
   */ 
    SWD_SAP_SRC_STATE_NONE           = 0,
  /**
   * ALL (all addresses recognized)
   */ 
    SWD_SAP_SRC_STATE_ALL            = 1,
  /**
   * FIXED (fixed address used)
   */ 
    SWD_SAP_SRC_STATE_FIXED          = 2,
  /**
   * LEARN (all addresses recognized, learning active)
   */ 
    SWD_SAP_SRC_STATE_LEARN          = 3,
  /**
   * LEARNED (learned address used)
   */ 
    SWD_SAP_SRC_STATE_LEARNED        = 7,
} swd_sap_src_state_t;


/* ############################################################################ */
/**
 * \brief SOURCE FSM COMMAND
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * FORCE_NONE (no address recognized)
   */ 
    SWD_SAP_SRC_FORCE_NONE           = 0,
  /**
   * FORCE_ALL (all addresses recognized)
   */ 
    SWD_SAP_SRC_FORCE_ALL            = 1,
  /**
   * FORCE_FIXED (fixed address used)
   */ 
    SWD_SAP_SRC_FORCE_FIXED          = 2,
  /**
   * FORCE_LEARN (all addresses recognized, learning active)
   */ 
    SWD_SAP_SRC_FORCE_LEARN          = 3,
  /**
   *  CONDITIONAL_NONE (safe transition to NONE, may not be executed)
   */ 
    SWD_SAP_SRC_CONDITIONAL_NONE     = 4,
  /**
   * CONDITIONAL_FIXED (safe transition to FIXED, may not be executed)
   */ 
    SWD_SAP_SRC_CONDITIONAL_FIXED    = 6,
} swd_sap_src_command_t;


/* ############################################################################ */
/**
 * \brief 
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * Virtual DMA channel for write positions and replacement of nodes.
   */ 
  SWD_DMA_VCHANNEL_SIZES           = 0,

  /**
   * Virtual DMA channel for cyclic send data.
   */ 
  SWD_DMA_VCHANNEL_CYC_TX          = 1,

  /**
   * Virtual DMA channel for cyclic reception data.
   */ 
  SWD_DMA_VCHANNEL_CYC_RX          = 2,

  /**
   * Virtual DMA channel for acyclic send data.
   */ 
  SWD_DMA_VCHANNEL_ACY_TX          = 3,
  
  /**
   * Virtual DMA channel for acyclic reception data  (SAP A).
   */
  SWD_DMA_VCHANNEL_ACY_RX_SAPA     = 4,
  
  /**
   * Virtual DMA channel for acyclic reception data  (SAP B).
   */
  SWD_DMA_VCHANNEL_ACY_RX_SAPB     = 5,

  /**
   * Virtual DMA channel for acyclic reception data  (SAP C).
   */
  SWD_DMA_VCHANNEL_ACY_RX_SAPC     = 6,
} swd_dma_vchannel_t;


/* ############################################################################ */
/**
 * \brief Status0, Status1, Status2 Modules
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * Status0 Module
   */ 
    SWD_STATUS0                      = 0,
  /**
   * Status1 Module
   */ 
    SWD_STATUS1                      = 1,
  /**
   * Status2 Module
   */ 
    SWD_STATUS2                      = 2,
} swd_stat_t;


/* ############################################################################ */
/**
 * \brief RX_CUT instancies
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * RX_CUT0
   */ 
    SWD_CYC_RX_CUT0                  = 0,
  /**
   * RX_CUT1
   */ 
    SWD_CYC_RX_CUT1                  = 1,
  /**
   * RX_CUT2
   */ 
    SWD_CYC_RX_CUT2                  = 2,
} swd_cyc_rx_cut_t;


/* ############################################################################ */
/**
 * \brief start address and length of cyclic rx data cut out in bytes
 *
 * \ingroup swd_pm 
 */ 
typedef struct {
  /**
   * start0 address of cyclic rx data cut out in bytes
   */ 
    swd_pe_cyc_rx_cut_start_t   start0;
  /**
   * length0 of cyclic rx data cut out in bytes
   */ 
    swd_pe_cyc_rx_cut_length_t  length0;
  /**
   * start1 address of cyclic rx data cut out in bytes
   */ 
    swd_pe_cyc_rx_cut_start_t   start1;
  /**
   * length1 of cyclic rx data cut out in bytes
   */ 
    swd_pe_cyc_rx_cut_length_t  length1;
  /**
   * start2 address of cyclic rx data cut out in bytes
   */ 
    swd_pe_cyc_rx_cut_start_t   start2;
  /**
   * length2 of cyclic rx data cut out in bytes
   */ 
    swd_pe_cyc_rx_cut_length_t  length2;
} swd_cyc_rx_cuts_t;

//typedef swd_sap_source0_status_t     swd_sap_source_status_t;
//typedef swd_status0_mask_offset_t    swd_status_mask_offset_t;
typedef swd_dpll_last_frac_period_t  swd_dpll_frac_period_t;
typedef swd_irq_status_dma_t         swd_dma_channel_status_t;



/* ############################################################################ */
/**
 * \brief SWD Sync Input
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * TSU
   */ 
  SWD_SYNC_TSU                 = 0,
  /**
   * SWTIMER0
   */ 
  SWD_SYNC_SWTIMER0            = 1,
} swd_sync_source_t;



/* ############################################################################ */
/**
 * \brief SWD BUS selection
 *
 * \ingroup swd_pm 
 */ 
typedef enum {
  /**
   * BUS0
   */ 
  SWD_BUS0                     = 0,
  /**
   * BUS1
   */ 
  SWD_BUS1                     = 1,
} swd_bus_t;


#endif
