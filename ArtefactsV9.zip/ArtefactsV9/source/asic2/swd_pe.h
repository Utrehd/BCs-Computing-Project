/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swd_pe.h
*
* @brief        SWD_PM HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SWD_PE_H
#define HAVE_SWD_PE_H

#ifndef HAVE_SWD_H
#error "Please include swd.h instead of this file."
#endif


/* ############################################################################ */
/**
 * \brief Get Protocol Engine (PE) Configuration
 *
 * \ingroup swd_pm 
 * 
 * \param config pointer to current configuration settings
 */ 
void swd_get_pe_config (swd_pe_config_t * config);


/* ############################################################################ */
/**
 * \brief Set Protocol Engine (PE) Configuration
 *
 * \ingroup swd_pm 
 * 
 * \param config pointer to current configuration settings to be set
 */ 
void swd_set_pe_config (swd_pe_config_t * config);


/* ############################################################################ */
/**
 * \brief Enable decoding of frames and events, disabled is reset
 *
 * \ingroup swd_pm 
 * 
 * \param en Enable decoding of frames and events
 */ 
void swd_set_pe_enable(bool en);


/* ############################################################################ */
/**
 * \brief enable incoming cyclic transfer (crc32 DisAck and DMA channel open) <br>
 *        PE_CYC_WRITE_OFFSET and PE_CYC_WRITE_LENGTH have to be valid
 *
 * \ingroup swd_pm 
 * 
 * \param en enable incoming cyclic transfer
 */ 
void swd_set_sdz_enable(bool en);


/* ############################################################################ */
/**
 * \brief enable reaction to incoming grants <br>
 *        PE_GNT_SELF has to be valid
 *
 * \ingroup swd_pm 
 * 
 * \param en enable reaction to incoming grants
 */ 
void swd_set_sdg_enable(bool en);


/* ############################################################################ */
/**
 * \brief enable incoming acyclic transfers (crc32 DisAck and DMA channel open)
 *
 * \ingroup swd_pm 
 * 
 * \param en enable incoming acyclic transfers
 */ 
void swd_set_sdw_enable(bool en);


/* ############################################################################ */
/**
 * \brief enable incoming broadcasts (crc32 DisAck and DMA channel open)
 *
 * \ingroup swd_pm 
 * 
 * \param en enable incoming broadcasts
 */ 
void swd_set_sdb_enable(bool en);


/* ############################################################################ */
/**
 * \brief Enables the swd protocol machine.
 *
 * \ingroup swd_pm 
 * 
 * \param pe_enable enable decoding of frames and events
 * 
 * \param sdz_enable enable incoming cyclic transfer
 * 
 * \param sdg_enable enable reaction to incoming grants
 * 
 * \param sdw_enable enable incoming acyclic transfers
 * 
 * \param sdb_enable enable incoming broadcasts
 */ 
void swd_enable_engine (
  bool pe_enable,
  bool sdz_enable,
  bool sdg_enable,
  bool sdw_enable,
  bool sdb_enable);


/* ############################################################################ */
/**
 * \brief Configures the SWD protocol machine.
 *
 * \ingroup swd_pm 
 * 
 * \param sdz_no_disack     send no disack when crc32 error detected in cyclic frame
 * 
 * \param sdw_no_disack     send no disack when crc32 error detected in acyclic write
 * 
 * \param sdw_ignore_disack ignore disack
 * 
 * \param sdw_no_crc32      do not send crc32 even if node is destination of unicast
 * 
 * \param sdb_no_disack     send no disack when crc32 error detected in acyclic broadcast
 * 
 * \param sdb_ignore_disack ignore disack
 * 
 * \param cyc_tx_update     always close CYC TX DMA channel, even when error
 * 
 * \param cyc_succ_no_res   generate no result event on successful receiving cyclic transfer
 */ 
void swd_config_engine (bool sdz_no_disack,
                           bool sdw_no_disack,
                           bool sdw_ignore_disack,
                           bool sdw_no_crc32,
                           bool sdb_no_disack,
                           bool sdb_ignore_disack,
                           bool cyc_tx_update,
                           bool cyc_succ_no_res);


/* ############################################################################ */
/**
 * \brief   Who is going to send DisAck (acyclic)
 *
 * \ingroup swd_pm 
 * 
 * \param v true: all nodes will send DisAck <br>
 *          false: only nodes that take part in the transfer will send DisAck <br>
 */ 
void swd_config_sdw_all_disack(bool v);


/* ############################################################################ */
/**
 * \brief   Who is going to send DisAck (broadcast)
 *
 * \ingroup swd_pm 
 * 
 * \param v true: all nodes will send DisAck <br>
 *          false: only nodes that take part in the transfer will send DisAck <br>
 */ 
void swd_config_sdb_all_disack(bool v);


/* ############################################################################ */
/**
 * \brief Set node ID used to react on Grant and start acyclic transfer
 *
 * \ingroup swd_pm 
 * 
 * \param module_id node ID
 */ 
void swd_set_module_id (uint8_t module_id);


/* ############################################################################ */
/**
 * \brief Generate no result event on successful receiving cyclic transfer
 *
 * \ingroup swd_pm 
 * 
 * \param v enable 
 */ 
void swd_config_cyc_succ_no_res(bool v);


/* ############################################################################ */
/**
 * \brief Sets offset and length of cyclic transfers.
 *
 * \ingroup swd_pm 
 * 
 * \param offset   write offset for cyclic transfer in bytes <br>
 *                 Offset in bytes, starting from the calling module data into a cyclic frame. <br>
 * 
 * \param length   write length for cyclic transfer in bytes <br>
 *                 Number of bytes that the calling module in can write a cyclic frame. <br>
 */ 
void swd_config_cycl (uint16_t offset, uint16_t length);


/* ############################################################################ */
/**
 * \brief           Starts a cyclic transfer. This function is allowed only by the Coordinator.
 *
 * \ingroup swd_pm 
 * 
 * \param len       length of data in cyclic transfer <br>
 *                  used when starting cyclic frame with command = 01 as coordinator <br>
 *                  used when cyclic frame is started with sync input and sync mode enabled <br>
 * 
 * \param tag       user command tag. will be visible in results register when finished
 *
 * \remarks         PE_COMMAND will be reset by hardware.
 */ 
void swd_start_cycl (uint16_t len, uint8_t tag);


/* ############################################################################ */
/**
 * \brief           Starts an acyclic transfer (GRANT). This function may only be used by Coordinator.
 *
 * \ingroup swd_pm 
 * 
 * \param module_id Module address of the module, which is the next one may start acyclic data transmission.
 * 
 * \param tag       user command tag. will be visible in results register when finished
 */ 
void swd_start_acycl (uint8_t module_id, uint8_t tag);


/* ############################################################################ */
/**
 * \brief          enable sync mode
 *
 * \ingroup swd_pm 
 * 
 * \param enable   enable sync mode (cyclic frames started by HW sync input e.g. TSU)
 * 
 * \param len      length of data in cyclic transfer <br>
 *                 used when starting cyclic frame with command = 01 as coordinator <br>
 *                 used when cyclic frame is started with sync input and sync mode enabled <br>
 */ 
void swd_enable_sync_mode (bool enable, uint16_t len);

/**
 * Gibt das Ergebnis der letzten Operation zurueck.
 *
 * @param pe_result             Zeiger auf eine Variable, in der das
 *                              Ergebnis der letzten Operation der
 *                              Perotokollmaschine gespeichert werden soll.
 * @return                      Lag ein gueltiges Ergebnis vor, wird TRUE
 *                              zurueckgegeben.
 */

/* ############################################################################ */
/**
 * \brief           Returns the result of the last operation.
 *
 * \ingroup swd_pm 
 * 
 * \param pe_result Pointer to a variable in which the
 *                  Result of the last operation of the
 *                  Protocol machine should be stored.
 * 
 * \return          true when a valid result is found. (Result FIFO is not empty)
 */ 
bool swd_get_pe_result (swd_pe_result_t * pe_result);



/* ############################################################################ */
/**
 * \brief         Configure status mask offset
 *
 * \ingroup swd_pm 
 * 
 * \param status  which MASK_OFFSET should be written (0/1/2)
 * 
 * \param mask    bit mask for status field, 1: sensitive to corresponding '1' bit in status byte
 * 
 * \param offset  count offset (see description of status byte filtering)
 */ 
void swd_config_status_filter (swd_stat_t status, uint8_t mask, uint16_t offset);


/* ############################################################################ */
/**
 * \brief start capturing nodes with given Status 1 configuration <br>
 *        capturing starts on next cyclic frame status evaluation <br>
 *        capturing stays enabled until at least one node was captured <br>
 *
 * \ingroup swd_pm 
 * 
 * \param status 1/2
 *
 * \remarks STATUSx_COMMAND will be reset by hardware
 */ 
void swd_start_status_capture (swd_stat_t status);


/* ############################################################################ */
/**
 * \brief           ???Get next status ID???
 *
 * \ingroup swd_pm 
 * 
 * \param status 
 * 
 * \param module_id Node ID of Node with status byte set matching to given mask (e.g. acyclic request)
 * 
 * \return          Node ID is valid
 *
 * \remarks         The STATUSx_NODES values are provided by a FIFO which is filled by the hardware when the STATUSx_COMMAND
 *                  was started at least once and at least one cyclic frame was evaluated. <br>
 *                  When the STATUSx_NODES is read, the FIFO entry is removed. <br>
 */ 
bool swd_get_next_status_node (swd_stat_t status, uint8_t * module_id);



/* ############################################################################ */
/**
 * \brief                Get write length ID of last received node
 *
 * \ingroup swd_pm 
 * 
 * \param sizes_entry_id when timeout during cyclic transfer, register contains write length ID of last received node
 * 
 * \return               Value becomes valid after a timeout during cyclic transfer and stays valid until reading this register
 */ 
bool swd_get_timeout_id (uint8_t * sizes_entry_id);



/* ############################################################################ */
/**
 * \brief  Get write length ID of first not replaced node, that was expected to be replaced
 *
 * \ingroup swd_pm 
 * 
 * \param sizes_entry_id  when nodes should be replaced during cyclic transfer:
 *                        register contains write length ID of first not replaced node, that was
 *                        expected to be replaced
 * 
 * \return                Value becomes valid with first not replaced node during cyclic
 *                        transfer and stays valid until reading this register
 */ 
bool swd_get_not_replaced_id (uint8_t * sizes_entry_id);



/* ############################################################################ */
/**
 * \brief           Sets counter
 *
 * \ingroup swd_pm 
 * 
 * \param value     counter value
 *
 * \remarks         This counter (in combination with �cyc_succ_no_res� bit of PE_CONFIG) is used to reduce IRQ load for cyclic
 *                  success events. Writing a value to this register will start a counter, counting down with each successfully received cyclic
 *                  frame. An IRQ can be enabled when the counter is zero.
 */ 
void swd_set_cyc_succ_res_cnt (uint8_t value);


/* ############################################################################ */
/**
 * \brief           get actual counter value
 *
 * \ingroup swd_pm 
 * 
 * \return          actual counter value
 *
 * \remarks         This counter (in combination with �cyc_succ_no_res� bit of PE_CONFIG) is used to reduce IRQ load for cyclic
 *                  success events. Writing a value to this register will start a counter, counting down with each successfully received cyclic
 *                  frame. An IRQ can be enabled when the counter is zero.
 */ 
uint8_t swd_get_cyc_succ_res_cnt (void);



/* ############################################################################ */
/**
 * \brief          Set start address and length of cyclic rx data cut out
 *
 * \ingroup swd_pm 
 * 
 * \param no       (0/1/2)
 * 
 * \param offset   start address of cyclic rx data cut out in bytes start 0 < start 1 < start2 <br>
 *                 (byte no = cyc_rx_cut_start +1)
 * 
 * \param length   length of cyclic rx data cut out in bytes <br>
 *                 (cyc_rx_cut_length = 0 means no bytes in this window)
 */ 
void swd_set_cyc_rx_cut (swd_cyc_rx_cut_t no, uint16_t offset, uint16_t length);


#endif /* HAVE_SWD_PE_H */
