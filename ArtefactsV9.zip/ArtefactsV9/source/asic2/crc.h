/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         crc.h
*
* @brief        Cyclic redundancy check HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_CRC_H
#define HAVE_CRC_H

#include "device.h"


#include "crc_bf.h"
#include "crc_irq.h"

/**
 * \example example_crc.c
 * This is an example of how to use CRC block.
 */
 
/**
 * \defgroup crc ASIC2 Cyclic redundancy check HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control Cyclic redundancy check (CRC)
 *
 * How to use it:
 * -# Configure CRC: crc_set_cfg(), crc_set_polynom(), crc_set_start_value()
 * -# Set data which are used for CRC computation:  crc_set_len(),  crc_set_start_addr()
 * -# wait until CRC is finished crc_is_finished()
 * -# clear CRC done status crc_get_done_start_addr()
 * -# get CRC value crc_get_crc()
 *
 *
   \dot
    digraph crc_fsm {
    rankdir=LR;
    node [fontname="Times bold", fontcolor=white, shape = circle, style=filled, fillcolor="#0B59BB"];
    edge [fontname=Times] //All the lines look like this
    
    NEW -> CURRENT [label=" start new computation"];
    CURRENT -> CURRENT [label=" in progress"]
    CURRENT -> DONE  [label=" computation has completed"];
    }
  \enddot
 * \details See code example: @include example_crc.c
 */
 
 
 

/**@{*/ 






/* ############################################################################ */
/**
 * \brief   Function to configurate CRC Cyclic redundancy check.
 *          Configuration of polynom length, address direction, bit direction for CRC
 *
 * \ingroup crc
 * 
 * \param CRC CRC instance
 * 
 * \param cfg CRC configuration
 *
 */
void crc_set_cfg(crc_num_t CRC, crc_cfg_t cfg);

/* ############################################################################ */
/**
 * \brief   Function to readout CRC configuration. (polynom length, address direction, bit direction)
 *
 * \ingroup crc
 * 
 * \param CRC CRC instance
 * 
 * \return Current CRC configuration
 */
crc_cfg_t crc_get_cfg(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief   Function to set CRC polynom. 
 *
 * \ingroup crc
 * 
 * \param CRC CRC instance
 * 
 * \param coef coefficients of the polynomial. <br>
 *             COEF[x] <=> x^(n) <br>
 *             The highest coeficent is determined to be 1 all the time. <br>            
 */
void crc_set_polynom(crc_num_t CRC, uint32_t coef);

/* ############################################################################ */
/**
 * \brief   Function to set start value for CRC. 
 *
 * \ingroup crc
 * 
 * \param CRC CRC instance
 * 
 * \param val value of the crc at the start of the computation
 *
 */
void crc_set_start_value(crc_num_t CRC, uint32_t val);

/* ############################################################################ */
/**
 * \brief Function to set wait cycles for CRC. 
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 * 
 * \param val number of clock cycles to wait before the next word is read in addition to the cycles required by the CRC computation itself.
 *
 */
void crc_set_wait(crc_num_t CRC, uint8_t val);

/* ############################################################################ */
/**
 * \brief Abort current CRC computation
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 */
void crc_abort(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Function to start CRC computation
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \param addr start address of the data block for the next CRC computation. 
 *             Writing to the SADR_NEW_HW address will start a new computation 
 *             when the current one has finished or is aborted. <br>
 *             Up to 2 addresses can be provided.
 *
 */
void crc_set_start_addr(crc_num_t CRC, uint32_t addr);

/* ############################################################################ */
/**
 * \brief Function to set length of data block for CRC computation
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \param len length of the data block for the next CRC computation in bytes .
 *
 */
void crc_set_len(crc_num_t CRC, uint32_t len);

/* ############################################################################ */
/**
 * \brief Function to readout SADR_NEW_LW & SADR_NEW_HW
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \return new start address
 *
 */
uint32_t crc_get_start_addr(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Function to readout LEN_HW & LEN_LW
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \return length of the data block for current CRC computation in bytes .
 *
 */
uint32_t crc_get_len(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Function to readout SADR_CURRENT_LW & SADR_CURRENT_HW 
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \return sadr of the crc currently in progress
 *
 */
uint32_t crc_get_current_start_addr(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Function to readout SADR_DONE_LW & SADR_DONE_HW 
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \return SADR of the result. <br>
 *         This register will only be updated after the entire CRC computation has completed. <br>
 *         Reading the SADR_DONE_HW address will clear an asserted IRQ_STATUS.sadr_done_nempty 
 *         and set all *_DONE registers to 0x00.
 *
 */
uint32_t crc_get_done_start_addr(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Function to readout ADR_CURRENT_LW & ADR_CURRENT_LW 
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \return address last read
 *
 */
uint32_t crc_get_current_addr(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Function to readout CRC_LW & CRC_HW 
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \return CRC of the address range defined by SADR_DONE to LEN_DONE. <br>
 *         Unused bits contain START_VALUE. <br>
 *         Reading the CRC_LW register causes the output-Fifo to get the next value.
 *
 */
uint32_t crc_get_crc(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Find out that CRC computaion is completed. 
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \return true - *_DONE contains a completed unread CRC computation <br>
 *         false - CRC computation in progress 
 *
 */
bool crc_is_finished(crc_num_t crc);

//======================= IRQ ===========================================

/* ############################################################################ */
/**
 * \brief Set IRQ mask for CRC
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \param irq interrupt source
 *
 * \param enable enable irq source
 *
 */
void crc_set_irq_mask(crc_num_t CRC, crc_irq_t irq, bool enable);

/* ############################################################################ */
/**
 * \brief Set IRQ mask for CRC (atomic access)
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \param irq interrupt source
 *
 * \param enable enable irq source
 *
 */  
void crc_enable_irq(crc_num_t CRC, crc_irq_t irq, bool enable);

/* ############################################################################ */
/**
 * \brief Get IRQ status of CRC
 *
 * \ingroup crc
 *
 * \param CRC CRC instance
 *
 * \return IRQ status of CRC 
 *
 * \note read: unmasked status of all pending irqs <br>
 *             1: pending <br>
 *             0: no request <br>
 *
 * \note write: clear event flags <br>
 *              1: clear related flag <br>
 *              0: do not change flag <br>
 *
 */ 
crc_irq_status_t crc_get_irq_status(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Clear all IRQ flags in CRC
 *
 * \ingroup crc
 *
 */
void crc_clear_all_irq_events(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Get pending CRC interrupt
 *
 * \ingroup crc
 *
 * \return vector number of enabled pending interrupt with highest priority
 *         (smallest vector number). when no irq is pending the first unused irq
 *         number is returned.
 *
 */
crc_irq_t crc_get_pending_irq(crc_num_t CRC);

/* ############################################################################ */
/**
 * \brief Get pending CRC interrupt
 *
 * \ingroup crc
 *
 * \param   vno vector number of interrupt event to clear
 *
 */
void crc_set_vno_irq(crc_num_t CRC, crc_irq_t vno);

/**@} */
#endif /* HAVE_CRC_H */


