/* FPGA Release: 10512 */

#include "crc.h"
#include "utils.h"


void crc_set_cfg(crc_num_t CRC, crc_cfg_t cfg){
  WRITE_REG_16(CRC + ADDR_CRC_CFG, cfg.val);
}

crc_cfg_t crc_get_cfg(crc_num_t CRC){
  crc_cfg_t cfg;  
  cfg.val = READ_REG_U16(CRC + ADDR_CRC_CFG);
  return cfg;
}

void crc_set_polynom(crc_num_t CRC, uint32_t coef){
  WRITE_REG_16(CRC + ADDR_CRC_COEF_LW, (uint16_t) coef);
  WRITE_REG_16(CRC + ADDR_CRC_COEF_HW, (uint16_t) (coef >> 16));
}

void crc_set_start_value(crc_num_t CRC, uint32_t val){
  WRITE_REG_16(CRC + ADDR_CRC_START_VALUE_LW, (uint16_t) val);
  WRITE_REG_16(CRC + ADDR_CRC_START_VALUE_HW, (uint16_t) (val >> 16));
}

void crc_set_wait(crc_num_t CRC, uint8_t val){
  WRITE_REG_16(CRC + ADDR_CRC_WAIT, val);  
}

void crc_abort(crc_num_t CRC){
  WRITE_REG_16(CRC + ADDR_CRC_CMD, 1);  
}

void crc_set_start_addr(crc_num_t CRC, uint32_t addr){
  WRITE_REG_16(CRC + ADDR_CRC_SADR_NEW_LW, (uint16_t) addr);
  WRITE_REG_16(CRC + ADDR_CRC_SADR_NEW_HW, (uint16_t) (addr >> 16));
}

void crc_set_len(crc_num_t CRC, uint32_t len){
  WRITE_REG_16(CRC + ADDR_CRC_LEN_LW, (uint16_t) len);  
  WRITE_REG_16(CRC + ADDR_CRC_LEN_HW, (uint16_t) (len >> 16));  
}


uint32_t crc_get_start_addr(crc_num_t CRC){
  uint32_t temp = READ_REG_U16(CRC + ADDR_CRC_SADR_NEW_LW);
  return (temp | (READ_REG_U16(CRC + ADDR_CRC_SADR_NEW_HW) << 16));
}

uint32_t crc_get_len(crc_num_t CRC){
  uint32_t temp = READ_REG_U16(CRC + ADDR_CRC_LEN_LW);
  return (temp | (READ_REG_U16(CRC + ADDR_CRC_LEN_HW) << 16));
}

uint32_t crc_get_current_start_addr(crc_num_t CRC){
  uint32_t temp = READ_REG_U16(CRC + ADDR_CRC_SADR_CURRENT_LW);
  return (temp | (READ_REG_U16(CRC + ADDR_CRC_SADR_CURRENT_HW) << 16));
}

uint32_t crc_get_done_start_addr(crc_num_t CRC){
  uint32_t temp = READ_REG_U16(CRC + ADDR_CRC_SADR_DONE_LW);
  return (temp | (READ_REG_U16(CRC + ADDR_CRC_SADR_DONE_HW) << 16));
}

uint32_t crc_get_current_addr(crc_num_t CRC){
  uint32_t temp = READ_REG_U16(CRC + ADDR_CRC_ADR_CURRENT_LW);
  return (temp | (READ_REG_U16(CRC + ADDR_CRC_ADR_CURRENT_HW) << 16));
}

uint32_t crc_get_crc(crc_num_t CRC){
  uint32_t ret = 0;
  ret = READ_REG_U16(CRC + ADDR_CRC_CRC_HW);
  ret = ret << 16;
  ret |= READ_REG_U16(CRC + ADDR_CRC_CRC_LW);
  return ret;  
}

bool crc_is_finished(crc_num_t crc){
  crc_irq_status_t status = crc_get_irq_status(crc);
  return (status.bf.sadr_done_nempty == 1) ? true : false;    
}

//======================= IRQ ===========================================

void crc_set_irq_mask(crc_num_t CRC, crc_irq_t irq, bool enable){  
  uint32_t irqs;
  irqs = READ_REG_U16(CRC + ADDR_CRC_IRQ_MASK);
  if (enable) {
      irqs |= onehot16[(uint16_t) irq];
  }
  else {
      irqs &= ~onehot16[(uint16_t) irq];
  }  
  WRITE_REG_16(CRC + ADDR_CRC_IRQ_MASK, irqs);
}

void crc_enable_irq(crc_num_t CRC, crc_irq_t irq, bool enable){  
  if (enable) WRITE_REG_16(CRC + ADDR_CRC_IRQ_VENABLE, irq);
  else WRITE_REG_16(CRC + ADDR_CRC_IRQ_VDISABLE, irq);
}

crc_irq_status_t crc_get_irq_status(crc_num_t CRC){
  crc_irq_status_t status;
  status.val = READ_REG_U16(CRC + ADDR_CRC_IRQ_STATUS);
  return status;
}

void crc_clear_all_irq_events(crc_num_t CRC){
  WRITE_REG_16(CRC + ADDR_CRC_IRQ_STATUS,0xFFFF);
}

crc_irq_t crc_get_pending_irq(crc_num_t CRC){
  return (crc_irq_t) READ_REG_U16(CRC + ADDR_CRC_IRQ_VNO);
}

void crc_set_vno_irq(crc_num_t CRC, crc_irq_t vno){
  WRITE_REG_16(CRC + ADDR_CRC_IRQ_VNO, vno);
}

