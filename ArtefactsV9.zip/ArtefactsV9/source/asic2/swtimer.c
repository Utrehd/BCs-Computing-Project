/* FPGA Release: 10512 */
#include "swtimer.h"
#include "utils.h"
#include "core_cm0plus.h"

/* ======================================================================= */
/* MODULE HANDLING                                                         */
/* ======================================================================= */
static swtimer_callback_t callback0;
static swtimer_callback_t callback1;

static swtimer_callback_t callbacks0[SWTIMER_NUM_IRQS];
static swtimer_callback_t callbacks1[SWTIMER_NUM_IRQS];

_INTERRUPT_ IRQ_SWTIMER0_Handler(void) {
  if (callback0 != NULL){
    callback0();
  } else {
    swtimer_irq_t irq = swtimer_get_next_pending_irq(SWTIMER0);
    swtimer_clear_irq(SWTIMER0, irq);
    if(callbacks0[irq] != NULL) {
        callbacks0[irq]();
    }
  }
}

_INTERRUPT_ IRQ_SWTIMER1_Handler(void) {
  if (callback1 != NULL){
    callback1();
  } else {
    swtimer_irq_t irq = swtimer_get_next_pending_irq(SWTIMER1);
    swtimer_clear_irq(SWTIMER1, irq);
    if(callbacks1[irq] != NULL) {
        callbacks1[irq]();
    }
  }
}

void swtimer_init(swtimer_num_t nr) {
  int i;
  if(nr == SWTIMER0){
    callback0 = NULL;
    for(i = 0; i < SWTIMER_NUM_IRQS; i++) {
        callbacks0[i] = NULL;
    } 
    NVIC_SetPriority(IRQ_SWTIMER0, 1);
    NVIC_EnableIRQ(IRQ_SWTIMER0);
  } else {
    callback1 = NULL;
    for(i = 0; i < SWTIMER_NUM_IRQS; i++) {
        callbacks1[i] = NULL;
    }      
    NVIC_SetPriority(IRQ_SWTIMER1, 6);
    NVIC_EnableIRQ(IRQ_SWTIMER1);
  }
}

void swtimer_use_ext_irq_handler(swtimer_num_t nr, swtimer_callback_t callback) {
  if(nr == SWTIMER0) callback0 = callback;
  else               callback1 = callback;
}

void swtimer_register(swtimer_num_t nr, swtimer_irq_t dev, swtimer_callback_t callback) {
  if(nr == SWTIMER0) callbacks0[dev] = callback;
  else               callbacks1[dev] = callback;
}

void swtimer_set_command(swtimer_num_t nr, swtimer_cmd_t command) {
  WRITE_REG_16(nr + ADDR_SWTIMER_COMMAND, command);
}

void swtimer_enable(swtimer_num_t nr,swtimer_sub_t swtimer_dev, bool enable) {
	if((uint16_t)swtimer_dev >(2 * SUBTIMERS - 1)) return;
	if(enable) {
		BIS_REG_16(nr + ADDR_SWTIMER_CONFIG, onehot16[swtimer_dev]);
	} else {
		BIC_REG_16(nr + ADDR_SWTIMER_CONFIG, onehot16[swtimer_dev]);
  }
    
}

void swtimer_autoreload_enable(swtimer_num_t nr,swtimer_sub_t swtimer_dev, bool enable) {
	swtimer_dev =(swtimer_sub_t)((int)swtimer_dev + SUBTIMERS);
	if((uint16_t)swtimer_dev >(2 * SUBTIMERS - 1)) return;
	if(enable) {
		BIS_REG_16(nr + ADDR_SWTIMER_CONFIG, onehot16[swtimer_dev]);
	} else {
		BIC_REG_16(nr + ADDR_SWTIMER_CONFIG, onehot16[swtimer_dev]);
	}
}

void swtimer_cascade_enable(swtimer_num_t nr,swtimer_cascade_t cascade, bool enable) {
	if((cascade != SWTIMER_CASCADE_SUB0_SUB1) &&(cascade != SWTIMER_CASCADE_SUB2_SUB3)) 
	  return;
	if(enable) {
		BIS_REG_16(nr + ADDR_SWTIMER_CONFIG, onehot16[cascade]);
	} else {
		BIC_REG_16(nr + ADDR_SWTIMER_CONFIG, onehot16[cascade]);
	}
}

void swtimer_set_counter_reload(swtimer_num_t nr,swtimer_sub_t swtimer_dev, uint16_t val) {
  WRITE_REG_16(nr + ADDR_SWTIMER_CNT0_RELOAD +(swtimer_dev * 2), val);
}

void swtimer_set_prescaler_reload(swtimer_num_t nr,swtimer_sub_t swtimer_dev, uint16_t val) {
  WRITE_REG_16(nr + ADDR_SWTIMER_DIV0_RELOAD +(swtimer_dev * 2), val);
}

uint16_t swtimer_get_counter_value(swtimer_num_t nr,swtimer_sub_t swtimer_dev) {
  return READ_REG_U16(nr + ADDR_SWTIMER_CNT0_VALUE +(swtimer_dev * 2));
}

uint16_t swtimer_get_reload_value(swtimer_num_t nr,swtimer_sub_t swtimer_dev){
  return READ_REG_U16(nr + ADDR_SWTIMER_CNT0_RELOAD +(swtimer_dev * 2));
}

void swtimer_set_nmi_enable(swtimer_num_t nr, bool enable){
  swtimer_config_t swtimer_config;
  swtimer_config.val = READ_REG_U16(nr + ADDR_SWTIMER_CONFIG);
  swtimer_config.bf.cnt0_zero_nmi = enable;
  WRITE_REG_16(nr + ADDR_SWTIMER_CONFIG, swtimer_config.val);
}

void swtimer0_set_set_swd_sync_enable(bool enable){
  swtimer_config_t swtimer_config;
  swtimer_config.val = READ_REG_U16(AADDR_SWTIMER0_CONFIG);
  swtimer_config.bf.cnt1_zero_swd_sync = enable;
  WRITE_REG_16(AADDR_SWTIMER0_CONFIG, swtimer_config.val);
}

/* ======================================================================= */
/* INTERRUPT HANDLING                                                      */
/* ======================================================================= */
uint16_t swtimer_get_irq_mask(swtimer_num_t nr){
  return READ_REG_U16(nr + ADDR_SWTIMER_IRQ_MASK);
}

void swtimer_enable_irq(swtimer_num_t nr, swtimer_irq_t irq, bool enable){  
  if(enable)  WRITE_REG_16(nr + ADDR_SWTIMER_IRQ_VENABLE,   irq);
  else        WRITE_REG_16(nr + ADDR_SWTIMER_IRQ_VDISABLE,  irq);
}

void swtimer_clear_irq(swtimer_num_t nr, swtimer_irq_t irq){
  WRITE_REG_16(nr + ADDR_SWTIMER_IRQ_STATUS,(1 << irq));
}

swtimer_irq_status_t swtimer_get_irq_status(swtimer_num_t nr){
  swtimer_irq_status_t status;
  status.val = READ_REG_U16(nr + ADDR_SWTIMER_IRQ_STATUS);
  return status;
}

void swtimer_clear_all_irq_events(swtimer_num_t nr){
  WRITE_REG_16(nr + ADDR_SWTIMER_IRQ_STATUS,0xFFFF);
}

swtimer_irq_t swtimer_get_next_pending_irq(swtimer_num_t nr){
  return(swtimer_irq_t) READ_REG_U16(nr + ADDR_SWTIMER_IRQ_VNO);
}

void swtimer_set_irq_vno(swtimer_num_t nr, swtimer_irq_t vno){
  WRITE_REG_16(nr + ADDR_SWTIMER_IRQ_VNO, vno);
}
