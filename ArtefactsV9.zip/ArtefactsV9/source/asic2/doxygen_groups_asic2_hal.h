/**
 *  \defgroup asic2_hal HAL functions
 *
 *
 *  \brief    ASIC2 HAL functions
 *
 * @{
 *
 * @}
 */
