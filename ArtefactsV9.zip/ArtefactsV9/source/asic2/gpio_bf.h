/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         gpio_bf.h
*
* @brief        General Purpose Input/Output HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __GPIO_BF_H__
#define __GPIO_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_GPIO
#define BASE_ADDR_GPIO 0x40006B00U
#endif

#define NUMBER_GPIO 1


/* ############################################################################ */
/**
 * \brief This is an enum class for GPIO instance
 *
 * \ingroup gpio 
 */ 
typedef enum {
  /**
   * This is instance EL_CTRL
   */ 
  GPIO                           = (int)BASE_ADDR_GPIO
} gpio_num_t;

// Register bit field definitions

/* GPIO_CONFIG */

#define MSK_GPIO_CONFIG_EN0                                 (0x1)     /* [0] */
#define RES_GPIO_CONFIG_EN0                                 (0x0)
#define SFT_GPIO_CONFIG_EN0                                 (0)
#define LSB_GPIO_CONFIG_EN0                                 (0)
#define MSB_GPIO_CONFIG_EN0                                 (0)
#define BIT_GPIO_CONFIG_EN0                                 (0x1)     /* [0] */
#define MSK_GPIO_CONFIG_EN1                                 (0x1)     /* [1] */
#define RES_GPIO_CONFIG_EN1                                 (0x0)
#define SFT_GPIO_CONFIG_EN1                                 (1)
#define LSB_GPIO_CONFIG_EN1                                 (1)
#define MSB_GPIO_CONFIG_EN1                                 (1)
#define BIT_GPIO_CONFIG_EN1                                 (0x2)     /* [1] */
#define MSK_GPIO_CONFIG_EN2                                 (0x1)     /* [2] */
#define RES_GPIO_CONFIG_EN2                                 (0x0)
#define SFT_GPIO_CONFIG_EN2                                 (2)
#define LSB_GPIO_CONFIG_EN2                                 (2)
#define MSB_GPIO_CONFIG_EN2                                 (2)
#define BIT_GPIO_CONFIG_EN2                                 (0x4)     /* [2] */
#define MSK_GPIO_CONFIG_EN3                                 (0x1)     /* [3] */
#define RES_GPIO_CONFIG_EN3                                 (0x0)
#define SFT_GPIO_CONFIG_EN3                                 (3)
#define LSB_GPIO_CONFIG_EN3                                 (3)
#define MSB_GPIO_CONFIG_EN3                                 (3)
#define BIT_GPIO_CONFIG_EN3                                 (0x8)     /* [3] */
#define MSK_GPIO_CONFIG_SYNC_EN                             (0x1)     /* [4] */
#define RES_GPIO_CONFIG_SYNC_EN                             (0x0)
#define SFT_GPIO_CONFIG_SYNC_EN                             (4)
#define LSB_GPIO_CONFIG_SYNC_EN                             (4)
#define MSB_GPIO_CONFIG_SYNC_EN                             (4)
#define BIT_GPIO_CONFIG_SYNC_EN                             (0x10)    /* [4] */
#define MSK_GPIO_CONFIG_IRQ_SEL0                            (0x3)     /* [ 6:5] */
#define RES_GPIO_CONFIG_IRQ_SEL0                            (0x0)
#define SFT_GPIO_CONFIG_IRQ_SEL0                            (5)
#define LSB_GPIO_CONFIG_IRQ_SEL0                            (5)
#define MSB_GPIO_CONFIG_IRQ_SEL0                            (6)
#define MSK_GPIO_CONFIG_IRQ_SEL1                            (0x3)     /* [ 8:7] */
#define RES_GPIO_CONFIG_IRQ_SEL1                            (0x0)
#define SFT_GPIO_CONFIG_IRQ_SEL1                            (7)
#define LSB_GPIO_CONFIG_IRQ_SEL1                            (7)
#define MSB_GPIO_CONFIG_IRQ_SEL1                            (8)
#define MSK_GPIO_CONFIG_IRQ_SEL2                            (0x3)     /* [10:9] */
#define RES_GPIO_CONFIG_IRQ_SEL2                            (0x0)
#define SFT_GPIO_CONFIG_IRQ_SEL2                            (9)
#define LSB_GPIO_CONFIG_IRQ_SEL2                            (9)
#define MSB_GPIO_CONFIG_IRQ_SEL2                            (10)
#define MSK_GPIO_CONFIG_IRQ_SEL3                            (0x3)     /* [12:11] */
#define RES_GPIO_CONFIG_IRQ_SEL3                            (0x0)
#define SFT_GPIO_CONFIG_IRQ_SEL3                            (11)
#define LSB_GPIO_CONFIG_IRQ_SEL3                            (11)
#define MSB_GPIO_CONFIG_IRQ_SEL3                            (12)


/* ############################################################################ */
/**
 * \brief This structure describes GPIO configuration
 *
 * \ingroup gpio 
 */ 
typedef struct {
  /**
   * enable the input filters f0 and f1 of gpio group0, when disabled filters will be reset
   */ 
  unsigned short en0                           :    1;       /* [0] */
  /**
   * enable the input filters f0 and f1 of gpio group1, when disabled filters will be reset
   */ 
  unsigned short en1                           :    1;       /* [1] */
  /**
   * enable the input filters f0 and f1 of gpio group2, when disabled filters will be reset
   */ 
  unsigned short en2                           :    1;       /* [2] */
  /**
   * enable the input filters f0 and f1 of gpio group3, when disabled filters will be reset
   */ 
  unsigned short en3                           :    1;       /* [3] */
  /**
   * enable hardware sync
   */ 
  unsigned short sync_en                       :    1;       /* [4] */
  /**
   * Select the filter for the interrupts from gpio group0: <br>
   *   "00" : resyn_pp <br>
   *   "01" : f0 <br>
   *   "10" : f1
   */ 
  unsigned short irq_sel0                      :    2;       /* [ 6:5] */
  /**
   * see above, gpio group1
   */ 
  unsigned short irq_sel1                      :    2;       /* [ 8:7] */
  /**
   * see above, gpio group2
   */ 
  unsigned short irq_sel2                      :    2;       /* [10:9] */
  /**
   * see above, gpio group3
   */ 
  unsigned short irq_sel3                      :    2;       /* [12:11] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    3;
} gpio_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of GPIO configuration
 *
 * \ingroup gpio 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  gpio_config_bf bf;  ///< bit field representation
} gpio_config_t;


/* GPIO_COMMAND */

#define MSK_GPIO_COMMAND                                    (0x1)     /* [0] */

typedef unsigned short gpio_command_t;                                /* [0] */


/* GPIO_F0_CFG */

#define MSK_GPIO_F0_CFG                                     (0xff)    /* [ 7:0] */

typedef unsigned short gpio_f0_cfg_t;                                 /* [ 7:0] */


/* GPIO_F1_CFG */

#define MSK_GPIO_F1_CFG                                     (0xffff)  /* [15:0] */

typedef unsigned short gpio_f1_cfg_t;                                 /* [15:0] */


/* GPIO_OE_G */

#define MSK_GPIO_OE_G                                       (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_oe_g_t;                                   /* [ 8:0] */


/* GPIO_IE_G */

#define MSK_GPIO_IE_G                                       (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_ie_g_t;                                   /* [ 8:0] */


/* GPIO_OUT */

#define MSK_GPIO_OUT                                        (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_out_t;                                    /* [ 8:0] */


/* GPIO_OUT_SET */

#define MSK_GPIO_OUT_SET                                    (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_out_set_t;                                /* [ 8:0] */


/* GPIO_OUT_CLR */

#define MSK_GPIO_OUT_CLR                                    (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_out_clr_t;                                /* [ 8:0] */


/* GPIO_OUT_TOGGLE */

#define MSK_GPIO_OUT_TOGGLE                                 (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_out_toggle_t;                             /* [ 8:0] */


/* GPIO_RESYN */

#define MSK_GPIO_RESYN                                      (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_resyn_t;                                  /* [ 8:0] */


/* GPIO_F0 */

#define MSK_GPIO_F0                                         (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_f0_t;                                     /* [ 8:0] */


/* GPIO_F1 */

#define MSK_GPIO_F1                                         (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_f1_t;                                     /* [ 8:0] */


/* GPIO_SYNC_SEL */

#define MSK_GPIO_SYNC_SEL                                   (0x3)     /* [ 1:0] */

typedef unsigned short gpio_sync_sel_t;                               /* [ 1:0] */


/* GPIO_G0_SYNC */

#define MSK_GPIO_G0_SYNC                                    (0x1ff)   /* [ 8:0] */

typedef unsigned short gpio_g0_sync_t;                                /* [ 8:0] */


/* GPIO_IRQ_CFG0 */

#define MSK_GPIO_IRQ_CFG0_G0_IRQ0                           (0x7)     /* [ 2:0] */
#define RES_GPIO_IRQ_CFG0_G0_IRQ0                           (0x0)
#define SFT_GPIO_IRQ_CFG0_G0_IRQ0                           (0)
#define LSB_GPIO_IRQ_CFG0_G0_IRQ0                           (0)
#define MSB_GPIO_IRQ_CFG0_G0_IRQ0                           (2)
#define MSK_GPIO_IRQ_CFG0_G0_IRQ1                           (0x7)     /* [ 5:3] */
#define RES_GPIO_IRQ_CFG0_G0_IRQ1                           (0x0)
#define SFT_GPIO_IRQ_CFG0_G0_IRQ1                           (3)
#define LSB_GPIO_IRQ_CFG0_G0_IRQ1                           (3)
#define MSB_GPIO_IRQ_CFG0_G0_IRQ1                           (5)
#define MSK_GPIO_IRQ_CFG0_G0_IRQ2                           (0x7)     /* [ 8:6] */
#define RES_GPIO_IRQ_CFG0_G0_IRQ2                           (0x0)
#define SFT_GPIO_IRQ_CFG0_G0_IRQ2                           (6)
#define LSB_GPIO_IRQ_CFG0_G0_IRQ2                           (6)
#define MSB_GPIO_IRQ_CFG0_G0_IRQ2                           (8)
#define MSK_GPIO_IRQ_CFG0_G0_IRQ3                           (0x7)     /* [11:9] */
#define RES_GPIO_IRQ_CFG0_G0_IRQ3                           (0x0)
#define SFT_GPIO_IRQ_CFG0_G0_IRQ3                           (9)
#define LSB_GPIO_IRQ_CFG0_G0_IRQ3                           (9)
#define MSB_GPIO_IRQ_CFG0_G0_IRQ3                           (11)


/* ############################################################################ */
/**
 * \brief This structure describes GPIO Interrupt group 0 subsystem
 *
 * \ingroup gpio 
 */ 
typedef struct {
  /**
   * Configuration for irq 0 (from gpio group 0, pin 1): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g0_irq0                       :    3;       /* [ 2:0] */
  /**
   * Configuration for irq 0 (from gpio group 0, pin 2): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g0_irq1                       :    3;       /* [ 5:3] */
  /**
   * Configuration for irq 0 (from gpio group 0, pin 3): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g0_irq2                       :    3;       /* [ 8:6] */
  /**
   * Configuration for irq 0 (from gpio group 0, pin 4): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g0_irq3                       :    3;       /* [11:9] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    4;
} gpio_irq_cfg0_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of GPIO Interrupt group 0 subsystem
 *
 * \ingroup gpio 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  gpio_irq_cfg0_bf bf;  ///< bit field representation
} gpio_irq_cfg0_t;


/* GPIO_IRQ_CFG1 */

#define MSK_GPIO_IRQ_CFG1_G1_IRQ0                           (0x7)     /* [ 2:0] */
#define RES_GPIO_IRQ_CFG1_G1_IRQ0                           (0x0)
#define SFT_GPIO_IRQ_CFG1_G1_IRQ0                           (0)
#define LSB_GPIO_IRQ_CFG1_G1_IRQ0                           (0)
#define MSB_GPIO_IRQ_CFG1_G1_IRQ0                           (2)
#define MSK_GPIO_IRQ_CFG1_G1_IRQ1                           (0x7)     /* [ 5:3] */
#define RES_GPIO_IRQ_CFG1_G1_IRQ1                           (0x0)
#define SFT_GPIO_IRQ_CFG1_G1_IRQ1                           (3)
#define LSB_GPIO_IRQ_CFG1_G1_IRQ1                           (3)
#define MSB_GPIO_IRQ_CFG1_G1_IRQ1                           (5)
#define MSK_GPIO_IRQ_CFG1_G1_IRQ2                           (0x7)     /* [ 8:6] */
#define RES_GPIO_IRQ_CFG1_G1_IRQ2                           (0x0)
#define SFT_GPIO_IRQ_CFG1_G1_IRQ2                           (6)
#define LSB_GPIO_IRQ_CFG1_G1_IRQ2                           (6)
#define MSB_GPIO_IRQ_CFG1_G1_IRQ2                           (8)
#define MSK_GPIO_IRQ_CFG1_G1_IRQ3                           (0x7)     /* [11:9] */
#define RES_GPIO_IRQ_CFG1_G1_IRQ3                           (0x0)
#define SFT_GPIO_IRQ_CFG1_G1_IRQ3                           (9)
#define LSB_GPIO_IRQ_CFG1_G1_IRQ3                           (9)
#define MSB_GPIO_IRQ_CFG1_G1_IRQ3                           (11)


/* ############################################################################ */
/**
 * \brief This structure describes GPIO Interrupt group 1 subsystem
 *
 * \ingroup gpio 
 */ 
typedef struct {
  /**
   * Configuration for irq 0 (from gpio group 1, pin 1): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g1_irq0                       :    3;       /* [ 2:0] */
  /**
   * Configuration for irq 0 (from gpio group 1, pin 6): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g1_irq1                       :    3;       /* [ 5:3] */
  /**
   * Configuration for irq 0 (from gpio group 1, pin 7): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g1_irq2                       :    3;       /* [ 8:6] */
  /**
   * Configuration for irq 0 (from gpio group 1, pin 8): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g1_irq3                       :    3;       /* [11:9] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    4;
} gpio_irq_cfg1_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of GPIO Interrupt group 1 subsystem
 *
 * \ingroup gpio 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  gpio_irq_cfg1_bf bf;  ///< bit field representation
} gpio_irq_cfg1_t;


/* GPIO_IRQ_CFG2 */

#define MSK_GPIO_IRQ_CFG2_G2_IRQ0                           (0x7)     /* [ 2:0] */
#define RES_GPIO_IRQ_CFG2_G2_IRQ0                           (0x0)
#define SFT_GPIO_IRQ_CFG2_G2_IRQ0                           (0)
#define LSB_GPIO_IRQ_CFG2_G2_IRQ0                           (0)
#define MSB_GPIO_IRQ_CFG2_G2_IRQ0                           (2)
#define MSK_GPIO_IRQ_CFG2_G2_IRQ1                           (0x7)     /* [ 5:3] */
#define RES_GPIO_IRQ_CFG2_G2_IRQ1                           (0x0)
#define SFT_GPIO_IRQ_CFG2_G2_IRQ1                           (3)
#define LSB_GPIO_IRQ_CFG2_G2_IRQ1                           (3)
#define MSB_GPIO_IRQ_CFG2_G2_IRQ1                           (5)
#define MSK_GPIO_IRQ_CFG2_G2_IRQ2                           (0x7)     /* [ 8:6] */
#define RES_GPIO_IRQ_CFG2_G2_IRQ2                           (0x0)
#define SFT_GPIO_IRQ_CFG2_G2_IRQ2                           (6)
#define LSB_GPIO_IRQ_CFG2_G2_IRQ2                           (6)
#define MSB_GPIO_IRQ_CFG2_G2_IRQ2                           (8)
#define MSK_GPIO_IRQ_CFG2_G2_IRQ3                           (0x7)     /* [11:9] */
#define RES_GPIO_IRQ_CFG2_G2_IRQ3                           (0x0)
#define SFT_GPIO_IRQ_CFG2_G2_IRQ3                           (9)
#define LSB_GPIO_IRQ_CFG2_G2_IRQ3                           (9)
#define MSB_GPIO_IRQ_CFG2_G2_IRQ3                           (11)


/* ############################################################################ */
/**
 * \brief This structure describes GPIO Interrupt group 2 subsystem
 *
 * \ingroup gpio 
 */ 
typedef struct {
  /**
   * Configuration for irq 0 (from gpio group 2, pin 2): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g2_irq0                       :    3;       /* [ 2:0] */
  /**
   * Configuration for irq 0 (from gpio group 2, pin 3): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g2_irq1                       :    3;       /* [ 5:3] */
  /**
   * Configuration for irq 0 (from gpio group 2, pin 7): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g2_irq2                       :    3;       /* [ 8:6] */
  /**
   * Configuration for irq 0 (from gpio group 2, pin 8): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g2_irq3                       :    3;       /* [11:9] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    4;
} gpio_irq_cfg2_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of GPIO Interrupt group 2 subsystem
 *
 * \ingroup gpio 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  gpio_irq_cfg2_bf bf;  ///< bit field representation
} gpio_irq_cfg2_t;


/* GPIO_IRQ_CFG3 */

#define MSK_GPIO_IRQ_CFG3_G3_IRQ0                           (0x7)     /* [ 2:0] */
#define RES_GPIO_IRQ_CFG3_G3_IRQ0                           (0x0)
#define SFT_GPIO_IRQ_CFG3_G3_IRQ0                           (0)
#define LSB_GPIO_IRQ_CFG3_G3_IRQ0                           (0)
#define MSB_GPIO_IRQ_CFG3_G3_IRQ0                           (2)
#define MSK_GPIO_IRQ_CFG3_G3_IRQ1                           (0x7)     /* [ 5:3] */
#define RES_GPIO_IRQ_CFG3_G3_IRQ1                           (0x0)
#define SFT_GPIO_IRQ_CFG3_G3_IRQ1                           (3)
#define LSB_GPIO_IRQ_CFG3_G3_IRQ1                           (3)
#define MSB_GPIO_IRQ_CFG3_G3_IRQ1                           (5)
#define MSK_GPIO_IRQ_CFG3_G3_IRQ2                           (0x7)     /* [ 8:6] */
#define RES_GPIO_IRQ_CFG3_G3_IRQ2                           (0x0)
#define SFT_GPIO_IRQ_CFG3_G3_IRQ2                           (6)
#define LSB_GPIO_IRQ_CFG3_G3_IRQ2                           (6)
#define MSB_GPIO_IRQ_CFG3_G3_IRQ2                           (8)
#define MSK_GPIO_IRQ_CFG3_G3_IRQ3                           (0x7)     /* [11:9] */
#define RES_GPIO_IRQ_CFG3_G3_IRQ3                           (0x0)
#define SFT_GPIO_IRQ_CFG3_G3_IRQ3                           (9)
#define LSB_GPIO_IRQ_CFG3_G3_IRQ3                           (9)
#define MSB_GPIO_IRQ_CFG3_G3_IRQ3                           (11)


/* ############################################################################ */
/**
 * \brief This structure describes GPIO Interrupt group 3 subsystem
 *
 * \ingroup gpio 
 */ 
typedef struct {
  /**
   * Configuration for irq 0 (from gpio group 3, pin 3): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g3_irq0                       :    3;       /* [ 2:0] */
  /**
   * Configuration for irq 0 (from gpio group 3, pin 4): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g3_irq1                       :    3;       /* [ 5:3] */
  /**
   * Configuration for irq 0 (from gpio group 3, pin 5): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g3_irq2                       :    3;       /* [ 8:6] */
  /**
   * Configuration for irq 0 (from gpio group 3, pin 6): <br>
   *   000 : no interrupt event generation <br>
   *   001 : level irq = 0 <br>
   *   010 : level irq = 1 <br>
   *   011 : rising edge <br>
   *   100 : falling edge <br>
   *   101 : both edges <br>
   * all cases result in interrupt events
   */ 
  unsigned short g3_irq3                       :    3;       /* [11:9] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    4;
} gpio_irq_cfg3_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of GPIO Interrupt group 3 subsystem
 *
 * \ingroup gpio 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  gpio_irq_cfg3_bf bf;  ///< bit field representation
} gpio_irq_cfg3_t;


/* GPIO_IRQ_STATUS */

#define MSK_GPIO_IRQ_STATUS_EVT_G0_PIN1                     (0x1)     /* [0] */
#define RES_GPIO_IRQ_STATUS_EVT_G0_PIN1                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G0_PIN1                     (0)
#define LSB_GPIO_IRQ_STATUS_EVT_G0_PIN1                     (0)
#define MSB_GPIO_IRQ_STATUS_EVT_G0_PIN1                     (0)
#define BIT_GPIO_IRQ_STATUS_EVT_G0_PIN1                     (0x1)     /* [0] */
#define MSK_GPIO_IRQ_STATUS_EVT_G0_PIN2                     (0x1)     /* [1] */
#define RES_GPIO_IRQ_STATUS_EVT_G0_PIN2                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G0_PIN2                     (1)
#define LSB_GPIO_IRQ_STATUS_EVT_G0_PIN2                     (1)
#define MSB_GPIO_IRQ_STATUS_EVT_G0_PIN2                     (1)
#define BIT_GPIO_IRQ_STATUS_EVT_G0_PIN2                     (0x2)     /* [1] */
#define MSK_GPIO_IRQ_STATUS_EVT_G0_PIN3                     (0x1)     /* [2] */
#define RES_GPIO_IRQ_STATUS_EVT_G0_PIN3                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G0_PIN3                     (2)
#define LSB_GPIO_IRQ_STATUS_EVT_G0_PIN3                     (2)
#define MSB_GPIO_IRQ_STATUS_EVT_G0_PIN3                     (2)
#define BIT_GPIO_IRQ_STATUS_EVT_G0_PIN3                     (0x4)     /* [2] */
#define MSK_GPIO_IRQ_STATUS_EVT_G0_PIN4                     (0x1)     /* [3] */
#define RES_GPIO_IRQ_STATUS_EVT_G0_PIN4                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G0_PIN4                     (3)
#define LSB_GPIO_IRQ_STATUS_EVT_G0_PIN4                     (3)
#define MSB_GPIO_IRQ_STATUS_EVT_G0_PIN4                     (3)
#define BIT_GPIO_IRQ_STATUS_EVT_G0_PIN4                     (0x8)     /* [3] */
#define MSK_GPIO_IRQ_STATUS_EVT_G1_PIN1                     (0x1)     /* [4] */
#define RES_GPIO_IRQ_STATUS_EVT_G1_PIN1                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G1_PIN1                     (4)
#define LSB_GPIO_IRQ_STATUS_EVT_G1_PIN1                     (4)
#define MSB_GPIO_IRQ_STATUS_EVT_G1_PIN1                     (4)
#define BIT_GPIO_IRQ_STATUS_EVT_G1_PIN1                     (0x10)    /* [4] */
#define MSK_GPIO_IRQ_STATUS_EVT_G1_PIN6                     (0x1)     /* [5] */
#define RES_GPIO_IRQ_STATUS_EVT_G1_PIN6                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G1_PIN6                     (5)
#define LSB_GPIO_IRQ_STATUS_EVT_G1_PIN6                     (5)
#define MSB_GPIO_IRQ_STATUS_EVT_G1_PIN6                     (5)
#define BIT_GPIO_IRQ_STATUS_EVT_G1_PIN6                     (0x20)    /* [5] */
#define MSK_GPIO_IRQ_STATUS_EVT_G1_PIN7                     (0x1)     /* [6] */
#define RES_GPIO_IRQ_STATUS_EVT_G1_PIN7                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G1_PIN7                     (6)
#define LSB_GPIO_IRQ_STATUS_EVT_G1_PIN7                     (6)
#define MSB_GPIO_IRQ_STATUS_EVT_G1_PIN7                     (6)
#define BIT_GPIO_IRQ_STATUS_EVT_G1_PIN7                     (0x40)    /* [6] */
#define MSK_GPIO_IRQ_STATUS_EVT_G1_PIN8                     (0x1)     /* [7] */
#define RES_GPIO_IRQ_STATUS_EVT_G1_PIN8                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G1_PIN8                     (7)
#define LSB_GPIO_IRQ_STATUS_EVT_G1_PIN8                     (7)
#define MSB_GPIO_IRQ_STATUS_EVT_G1_PIN8                     (7)
#define BIT_GPIO_IRQ_STATUS_EVT_G1_PIN8                     (0x80)    /* [7] */
#define MSK_GPIO_IRQ_STATUS_EVT_G2_PIN2                     (0x1)     /* [8] */
#define RES_GPIO_IRQ_STATUS_EVT_G2_PIN2                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G2_PIN2                     (8)
#define LSB_GPIO_IRQ_STATUS_EVT_G2_PIN2                     (8)
#define MSB_GPIO_IRQ_STATUS_EVT_G2_PIN2                     (8)
#define BIT_GPIO_IRQ_STATUS_EVT_G2_PIN2                     (0x100)   /* [8] */
#define MSK_GPIO_IRQ_STATUS_EVT_G2_PIN3                     (0x1)     /* [9] */
#define RES_GPIO_IRQ_STATUS_EVT_G2_PIN3                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G2_PIN3                     (9)
#define LSB_GPIO_IRQ_STATUS_EVT_G2_PIN3                     (9)
#define MSB_GPIO_IRQ_STATUS_EVT_G2_PIN3                     (9)
#define BIT_GPIO_IRQ_STATUS_EVT_G2_PIN3                     (0x200)   /* [9] */
#define MSK_GPIO_IRQ_STATUS_EVT_G2_PIN7                     (0x1)     /* [10] */
#define RES_GPIO_IRQ_STATUS_EVT_G2_PIN7                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G2_PIN7                     (10)
#define LSB_GPIO_IRQ_STATUS_EVT_G2_PIN7                     (10)
#define MSB_GPIO_IRQ_STATUS_EVT_G2_PIN7                     (10)
#define BIT_GPIO_IRQ_STATUS_EVT_G2_PIN7                     (0x400)   /* [10] */
#define MSK_GPIO_IRQ_STATUS_EVT_G2_PIN8                     (0x1)     /* [11] */
#define RES_GPIO_IRQ_STATUS_EVT_G2_PIN8                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G2_PIN8                     (11)
#define LSB_GPIO_IRQ_STATUS_EVT_G2_PIN8                     (11)
#define MSB_GPIO_IRQ_STATUS_EVT_G2_PIN8                     (11)
#define BIT_GPIO_IRQ_STATUS_EVT_G2_PIN8                     (0x800)   /* [11] */
#define MSK_GPIO_IRQ_STATUS_EVT_G3_PIN3                     (0x1)     /* [12] */
#define RES_GPIO_IRQ_STATUS_EVT_G3_PIN3                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G3_PIN3                     (12)
#define LSB_GPIO_IRQ_STATUS_EVT_G3_PIN3                     (12)
#define MSB_GPIO_IRQ_STATUS_EVT_G3_PIN3                     (12)
#define BIT_GPIO_IRQ_STATUS_EVT_G3_PIN3                     (0x1000)  /* [12] */
#define MSK_GPIO_IRQ_STATUS_EVT_G3_PIN4                     (0x1)     /* [13] */
#define RES_GPIO_IRQ_STATUS_EVT_G3_PIN4                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G3_PIN4                     (13)
#define LSB_GPIO_IRQ_STATUS_EVT_G3_PIN4                     (13)
#define MSB_GPIO_IRQ_STATUS_EVT_G3_PIN4                     (13)
#define BIT_GPIO_IRQ_STATUS_EVT_G3_PIN4                     (0x2000)  /* [13] */
#define MSK_GPIO_IRQ_STATUS_EVT_G3_PIN5                     (0x1)     /* [14] */
#define RES_GPIO_IRQ_STATUS_EVT_G3_PIN5                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G3_PIN5                     (14)
#define LSB_GPIO_IRQ_STATUS_EVT_G3_PIN5                     (14)
#define MSB_GPIO_IRQ_STATUS_EVT_G3_PIN5                     (14)
#define BIT_GPIO_IRQ_STATUS_EVT_G3_PIN5                     (0x4000)  /* [14] */
#define MSK_GPIO_IRQ_STATUS_EVT_G3_PIN6                     (0x1)     /* [15] */
#define RES_GPIO_IRQ_STATUS_EVT_G3_PIN6                     (0x0)
#define SFT_GPIO_IRQ_STATUS_EVT_G3_PIN6                     (15)
#define LSB_GPIO_IRQ_STATUS_EVT_G3_PIN6                     (15)
#define MSB_GPIO_IRQ_STATUS_EVT_G3_PIN6                     (15)
#define BIT_GPIO_IRQ_STATUS_EVT_G3_PIN6                     (0x8000)  /* [15] */


/* ############################################################################ */
/**
 * \brief This structure describes GPIO Interrupt event
 *
 * \ingroup gpio 
 */ 
typedef struct {
  /**
   * interrupt event occurred in group 0 pin 1
   */ 
  unsigned short evt_g0_pin1                   :    1;       /* [0] */
  /**
   * interrupt event occurred in group 0 pin 2
   */ 
  unsigned short evt_g0_pin2                   :    1;       /* [1] */
  /**
   * interrupt event occurred in group 0 pin 3
   */ 
  unsigned short evt_g0_pin3                   :    1;       /* [2] */
  /**
   * interrupt event occurred in group 0 pin 4
   */ 
  unsigned short evt_g0_pin4                   :    1;       /* [3] */
  /**
   * interrupt event occurred in group 1 pin 1
   */ 
  unsigned short evt_g1_pin1                   :    1;       /* [4] */
  /**
   * interrupt event occurred in group 1 pin 6
   */ 
  unsigned short evt_g1_pin6                   :    1;       /* [5] */
  /**
   * interrupt event occurred in group 1 pin 7
   */ 
  unsigned short evt_g1_pin7                   :    1;       /* [6] */
  /**
   * interrupt event occurred in group 1 pin 8
   */ 
  unsigned short evt_g1_pin8                   :    1;       /* [7] */
  /**
   * interrupt event occurred in group 2 pin 2
   */ 
  unsigned short evt_g2_pin2                   :    1;       /* [8] */
  /**
   * interrupt event occurred in group 2 pin 3
   */ 
  unsigned short evt_g2_pin3                   :    1;       /* [9] */
  /**
   * interrupt event occurred in group 2 pin 7
   */ 
  unsigned short evt_g2_pin7                   :    1;       /* [10] */
  /**
   * interrupt event occurred in group 2 pin 8
   */ 
  unsigned short evt_g2_pin8                   :    1;       /* [11] */
  /**
   * interrupt event occurred in group 3 pin 3
   */ 
  unsigned short evt_g3_pin3                   :    1;       /* [12] */
  /**
   * interrupt event occurred in group 3 pin 4
   */ 
  unsigned short evt_g3_pin4                   :    1;       /* [13] */
  /**
   * interrupt event occurred in group 3 pin 5
   */ 
  unsigned short evt_g3_pin5                   :    1;       /* [14] */
  /**
   * interrupt event occurred in group 3 pin 6
   */ 
  unsigned short evt_g3_pin6                   :    1;       /* [15] */
} gpio_irq_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of GPIO Interrupt event
 *
 * \ingroup gpio 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  gpio_irq_status_bf bf;  ///< bit field representation
} gpio_irq_status_t;


/* GPIO_IRQ_MASK */

#define MSK_GPIO_IRQ_MASK                                   (0xffff)  /* [15:0] */

typedef unsigned short gpio_irq_mask_t;                               /* [15:0] */


/* GPIO_IRQ_VENABLE */

#define MSK_GPIO_IRQ_VENABLE                                (0xf)     /* [ 3:0] */

typedef unsigned short gpio_irq_venable_t;                            /* [ 3:0] */


/* GPIO_IRQ_VDISABLE */

#define MSK_GPIO_IRQ_VDISABLE                               (0xf)     /* [ 3:0] */

typedef unsigned short gpio_irq_vdisable_t;                           /* [ 3:0] */


/* GPIO_IRQ_VMAX */

#define MSK_GPIO_IRQ_VMAX                                   (0x1f)    /* [ 4:0] */

typedef unsigned short gpio_irq_vmax_t;                               /* [ 4:0] */


/* GPIO_IRQ_VNO */

#define MSK_GPIO_IRQ_VNO                                    (0x1f)    /* [ 4:0] */

typedef unsigned short gpio_irq_vno_t;                                /* [ 4:0] */


/* GPIO_CONFIG_NMI */

#define MSK_GPIO_CONFIG_NMI_NMI_GROUP                       (0x3)     /* [ 1:0] */
#define RES_GPIO_CONFIG_NMI_NMI_GROUP                       (0x0)
#define SFT_GPIO_CONFIG_NMI_NMI_GROUP                       (0)
#define LSB_GPIO_CONFIG_NMI_NMI_GROUP                       (0)
#define MSB_GPIO_CONFIG_NMI_NMI_GROUP                       (1)
#define MSK_GPIO_CONFIG_NMI_NMI_PIN                         (0xf)     /* [ 5:2] */
#define RES_GPIO_CONFIG_NMI_NMI_PIN                         (0x0)
#define SFT_GPIO_CONFIG_NMI_NMI_PIN                         (2)
#define LSB_GPIO_CONFIG_NMI_NMI_PIN                         (2)
#define MSB_GPIO_CONFIG_NMI_NMI_PIN                         (5)
#define MSK_GPIO_CONFIG_NMI_CCPU0_NMI_ENABLE                (0x1)     /* [6] */
#define RES_GPIO_CONFIG_NMI_CCPU0_NMI_ENABLE                (0x0)
#define SFT_GPIO_CONFIG_NMI_CCPU0_NMI_ENABLE                (6)
#define LSB_GPIO_CONFIG_NMI_CCPU0_NMI_ENABLE                (6)
#define MSB_GPIO_CONFIG_NMI_CCPU0_NMI_ENABLE                (6)
#define BIT_GPIO_CONFIG_NMI_CCPU0_NMI_ENABLE                (0x40)    /* [6] */
#define MSK_GPIO_CONFIG_NMI_ACPU1_NMI_ENABLE                (0x1)     /* [7] */
#define RES_GPIO_CONFIG_NMI_ACPU1_NMI_ENABLE                (0x0)
#define SFT_GPIO_CONFIG_NMI_ACPU1_NMI_ENABLE                (7)
#define LSB_GPIO_CONFIG_NMI_ACPU1_NMI_ENABLE                (7)
#define MSB_GPIO_CONFIG_NMI_ACPU1_NMI_ENABLE                (7)
#define BIT_GPIO_CONFIG_NMI_ACPU1_NMI_ENABLE                (0x80)    /* [7] */


/* ############################################################################ */
/**
 * \brief This structure describes GPIO Non Maskable Interrupt (NMI) configuration
 *
 * \ingroup gpio 
 */ 
typedef struct {
  /**
   * select GPIO group to use as NMI input
   */ 
  unsigned short nmi_group                     :    2;       /* [ 1:0] */
  /**
   * select GPIO group pin to use as NMI input
   */ 
  unsigned short nmi_pin                       :    4;       /* [ 5:2] */
  /**
   * 1: enable NMI for CCPU0
   */ 
  unsigned short ccpu0_nmi_enable              :    1;       /* [6] */
  /**
   * 1: enable NMI for ACPU1
   */ 
  unsigned short acpu1_nmi_enable              :    1;       /* [7] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    8;
} gpio_config_nmi_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of GPIO Non Maskable Interrupt (NMI) configuration
 *
 * \ingroup gpio 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  gpio_config_nmi_bf bf;  ///< bit field representation
} gpio_config_nmi_t;



// Register definitions for module
// Instance base address BASE_ADDR_GPIO 0x40006B00U ... 

#define ADDR_GPIO_CONFIG                                     (0x00U)
#define A_GPIO_CONFIG(ba)                                    ((ba) + ADDR_GPIO_CONFIG)
#define R_GPIO_CONFIG(ba)                                    (*(volatile unsigned short *)((unsigned int)A_GPIO_CONFIG(ba)))
#define RES_GPIO_CONFIG                                      (0x0U)
#define MSB_GPIO_CONFIG                                      12
#define LSB_GPIO_CONFIG                                      0
#define AADDR_GPIO_CONFIG                                    (BASE_ADDR_GPIO + ADDR_GPIO_CONFIG)
#define REG_GPIO_CONFIG                                      (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_CONFIG))

#define ADDR_GPIO_COMMAND                                    (0x02U)
#define A_GPIO_COMMAND(ba)                                   ((ba) + ADDR_GPIO_COMMAND)
#define R_GPIO_COMMAND(ba)                                   (*(volatile unsigned short *)((unsigned int)A_GPIO_COMMAND(ba)))
#define RES_GPIO_COMMAND                                     (0x0U)
#define MSB_GPIO_COMMAND                                     0
#define LSB_GPIO_COMMAND                                     0
#define AADDR_GPIO_COMMAND                                   (BASE_ADDR_GPIO + ADDR_GPIO_COMMAND)
#define REG_GPIO_COMMAND                                     (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_COMMAND))

#define ADDR_GPIO_G0_F0_CFG                                  (0x04U)
#define A_GPIO_G0_F0_CFG(ba)                                 ((ba) + ADDR_GPIO_G0_F0_CFG)
#define R_GPIO_G0_F0_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_F0_CFG(ba)))
#define RES_GPIO_G0_F0_CFG                                   (0x1U)
#define MSB_GPIO_G0_F0_CFG                                   7
#define LSB_GPIO_G0_F0_CFG                                   0
#define AADDR_GPIO_G0_F0_CFG                                 (BASE_ADDR_GPIO + ADDR_GPIO_G0_F0_CFG)
#define REG_GPIO_G0_F0_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_F0_CFG))

#define ADDR_GPIO_G1_F0_CFG                                  (0x06U)
#define A_GPIO_G1_F0_CFG(ba)                                 ((ba) + ADDR_GPIO_G1_F0_CFG)
#define R_GPIO_G1_F0_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_F0_CFG(ba)))
#define RES_GPIO_G1_F0_CFG                                   (0x1U)
#define MSB_GPIO_G1_F0_CFG                                   7
#define LSB_GPIO_G1_F0_CFG                                   0
#define AADDR_GPIO_G1_F0_CFG                                 (BASE_ADDR_GPIO + ADDR_GPIO_G1_F0_CFG)
#define REG_GPIO_G1_F0_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_F0_CFG))

#define ADDR_GPIO_G2_F0_CFG                                  (0x08U)
#define A_GPIO_G2_F0_CFG(ba)                                 ((ba) + ADDR_GPIO_G2_F0_CFG)
#define R_GPIO_G2_F0_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_F0_CFG(ba)))
#define RES_GPIO_G2_F0_CFG                                   (0x1U)
#define MSB_GPIO_G2_F0_CFG                                   7
#define LSB_GPIO_G2_F0_CFG                                   0
#define AADDR_GPIO_G2_F0_CFG                                 (BASE_ADDR_GPIO + ADDR_GPIO_G2_F0_CFG)
#define REG_GPIO_G2_F0_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_F0_CFG))

#define ADDR_GPIO_G3_F0_CFG                                  (0x0AU)
#define A_GPIO_G3_F0_CFG(ba)                                 ((ba) + ADDR_GPIO_G3_F0_CFG)
#define R_GPIO_G3_F0_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_F0_CFG(ba)))
#define RES_GPIO_G3_F0_CFG                                   (0x1U)
#define MSB_GPIO_G3_F0_CFG                                   7
#define LSB_GPIO_G3_F0_CFG                                   0
#define AADDR_GPIO_G3_F0_CFG                                 (BASE_ADDR_GPIO + ADDR_GPIO_G3_F0_CFG)
#define REG_GPIO_G3_F0_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_F0_CFG))

#define ADDR_GPIO_G0_F1_CFG                                  (0x0CU)
#define A_GPIO_G0_F1_CFG(ba)                                 ((ba) + ADDR_GPIO_G0_F1_CFG)
#define R_GPIO_G0_F1_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_F1_CFG(ba)))
#define RES_GPIO_G0_F1_CFG                                   (0x1U)
#define MSB_GPIO_G0_F1_CFG                                   15
#define LSB_GPIO_G0_F1_CFG                                   0
#define AADDR_GPIO_G0_F1_CFG                                 (BASE_ADDR_GPIO + ADDR_GPIO_G0_F1_CFG)
#define REG_GPIO_G0_F1_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_F1_CFG))

#define ADDR_GPIO_G1_F1_CFG                                  (0x0EU)
#define A_GPIO_G1_F1_CFG(ba)                                 ((ba) + ADDR_GPIO_G1_F1_CFG)
#define R_GPIO_G1_F1_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_F1_CFG(ba)))
#define RES_GPIO_G1_F1_CFG                                   (0x1U)
#define MSB_GPIO_G1_F1_CFG                                   15
#define LSB_GPIO_G1_F1_CFG                                   0
#define AADDR_GPIO_G1_F1_CFG                                 (BASE_ADDR_GPIO + ADDR_GPIO_G1_F1_CFG)
#define REG_GPIO_G1_F1_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_F1_CFG))

#define ADDR_GPIO_G2_F1_CFG                                  (0x10U)
#define A_GPIO_G2_F1_CFG(ba)                                 ((ba) + ADDR_GPIO_G2_F1_CFG)
#define R_GPIO_G2_F1_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_F1_CFG(ba)))
#define RES_GPIO_G2_F1_CFG                                   (0x1U)
#define MSB_GPIO_G2_F1_CFG                                   15
#define LSB_GPIO_G2_F1_CFG                                   0
#define AADDR_GPIO_G2_F1_CFG                                 (BASE_ADDR_GPIO + ADDR_GPIO_G2_F1_CFG)
#define REG_GPIO_G2_F1_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_F1_CFG))

#define ADDR_GPIO_G3_F1_CFG                                  (0x12U)
#define A_GPIO_G3_F1_CFG(ba)                                 ((ba) + ADDR_GPIO_G3_F1_CFG)
#define R_GPIO_G3_F1_CFG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_F1_CFG(ba)))
#define RES_GPIO_G3_F1_CFG                                   (0x1U)
#define MSB_GPIO_G3_F1_CFG                                   15
#define LSB_GPIO_G3_F1_CFG                                   0
#define AADDR_GPIO_G3_F1_CFG                                 (BASE_ADDR_GPIO + ADDR_GPIO_G3_F1_CFG)
#define REG_GPIO_G3_F1_CFG                                   (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_F1_CFG))

#define ADDR_GPIO_G0_OE                                      (0x14U)
#define A_GPIO_G0_OE(ba)                                     ((ba) + ADDR_GPIO_G0_OE)
#define R_GPIO_G0_OE(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_OE(ba)))
#define RES_GPIO_G0_OE                                       (0x0U)
#define MSB_GPIO_G0_OE                                       8
#define LSB_GPIO_G0_OE                                       0
#define AADDR_GPIO_G0_OE                                     (BASE_ADDR_GPIO + ADDR_GPIO_G0_OE)
#define REG_GPIO_G0_OE                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_OE))

#define ADDR_GPIO_G1_OE                                      (0x16U)
#define A_GPIO_G1_OE(ba)                                     ((ba) + ADDR_GPIO_G1_OE)
#define R_GPIO_G1_OE(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_OE(ba)))
#define RES_GPIO_G1_OE                                       (0x0U)
#define MSB_GPIO_G1_OE                                       8
#define LSB_GPIO_G1_OE                                       0
#define AADDR_GPIO_G1_OE                                     (BASE_ADDR_GPIO + ADDR_GPIO_G1_OE)
#define REG_GPIO_G1_OE                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_OE))

#define ADDR_GPIO_G2_OE                                      (0x18U)
#define A_GPIO_G2_OE(ba)                                     ((ba) + ADDR_GPIO_G2_OE)
#define R_GPIO_G2_OE(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_OE(ba)))
#define RES_GPIO_G2_OE                                       (0x0U)
#define MSB_GPIO_G2_OE                                       8
#define LSB_GPIO_G2_OE                                       0
#define AADDR_GPIO_G2_OE                                     (BASE_ADDR_GPIO + ADDR_GPIO_G2_OE)
#define REG_GPIO_G2_OE                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_OE))

#define ADDR_GPIO_G3_OE                                      (0x1AU)
#define A_GPIO_G3_OE(ba)                                     ((ba) + ADDR_GPIO_G3_OE)
#define R_GPIO_G3_OE(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_OE(ba)))
#define RES_GPIO_G3_OE                                       (0x0U)
#define MSB_GPIO_G3_OE                                       8
#define LSB_GPIO_G3_OE                                       0
#define AADDR_GPIO_G3_OE                                     (BASE_ADDR_GPIO + ADDR_GPIO_G3_OE)
#define REG_GPIO_G3_OE                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_OE))

#define ADDR_GPIO_G0_IE                                      (0x1CU)
#define A_GPIO_G0_IE(ba)                                     ((ba) + ADDR_GPIO_G0_IE)
#define R_GPIO_G0_IE(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_IE(ba)))
#define RES_GPIO_G0_IE                                       (0x0U)
#define MSB_GPIO_G0_IE                                       8
#define LSB_GPIO_G0_IE                                       0
#define AADDR_GPIO_G0_IE                                     (BASE_ADDR_GPIO + ADDR_GPIO_G0_IE)
#define REG_GPIO_G0_IE                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_IE))

#define ADDR_GPIO_G1_IE                                      (0x1EU)
#define A_GPIO_G1_IE(ba)                                     ((ba) + ADDR_GPIO_G1_IE)
#define R_GPIO_G1_IE(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_IE(ba)))
#define RES_GPIO_G1_IE                                       (0x0U)
#define MSB_GPIO_G1_IE                                       8
#define LSB_GPIO_G1_IE                                       0
#define AADDR_GPIO_G1_IE                                     (BASE_ADDR_GPIO + ADDR_GPIO_G1_IE)
#define REG_GPIO_G1_IE                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_IE))

#define ADDR_GPIO_G2_IE                                      (0x20U)
#define A_GPIO_G2_IE(ba)                                     ((ba) + ADDR_GPIO_G2_IE)
#define R_GPIO_G2_IE(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_IE(ba)))
#define RES_GPIO_G2_IE                                       (0x0U)
#define MSB_GPIO_G2_IE                                       8
#define LSB_GPIO_G2_IE                                       0
#define AADDR_GPIO_G2_IE                                     (BASE_ADDR_GPIO + ADDR_GPIO_G2_IE)
#define REG_GPIO_G2_IE                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_IE))

#define ADDR_GPIO_G3_IE                                      (0x22U)
#define A_GPIO_G3_IE(ba)                                     ((ba) + ADDR_GPIO_G3_IE)
#define R_GPIO_G3_IE(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_IE(ba)))
#define RES_GPIO_G3_IE                                       (0x0U)
#define MSB_GPIO_G3_IE                                       8
#define LSB_GPIO_G3_IE                                       0
#define AADDR_GPIO_G3_IE                                     (BASE_ADDR_GPIO + ADDR_GPIO_G3_IE)
#define REG_GPIO_G3_IE                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_IE))

#define ADDR_GPIO_G0_OUT                                     (0x24U)
#define A_GPIO_G0_OUT(ba)                                    ((ba) + ADDR_GPIO_G0_OUT)
#define R_GPIO_G0_OUT(ba)                                    (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_OUT(ba)))
#define RES_GPIO_G0_OUT                                      (0x0U)
#define MSB_GPIO_G0_OUT                                      8
#define LSB_GPIO_G0_OUT                                      0
#define AADDR_GPIO_G0_OUT                                    (BASE_ADDR_GPIO + ADDR_GPIO_G0_OUT)
#define REG_GPIO_G0_OUT                                      (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_OUT))

#define ADDR_GPIO_G1_OUT                                     (0x26U)
#define A_GPIO_G1_OUT(ba)                                    ((ba) + ADDR_GPIO_G1_OUT)
#define R_GPIO_G1_OUT(ba)                                    (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_OUT(ba)))
#define RES_GPIO_G1_OUT                                      (0x0U)
#define MSB_GPIO_G1_OUT                                      8
#define LSB_GPIO_G1_OUT                                      0
#define AADDR_GPIO_G1_OUT                                    (BASE_ADDR_GPIO + ADDR_GPIO_G1_OUT)
#define REG_GPIO_G1_OUT                                      (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_OUT))

#define ADDR_GPIO_G2_OUT                                     (0x28U)
#define A_GPIO_G2_OUT(ba)                                    ((ba) + ADDR_GPIO_G2_OUT)
#define R_GPIO_G2_OUT(ba)                                    (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_OUT(ba)))
#define RES_GPIO_G2_OUT                                      (0x0U)
#define MSB_GPIO_G2_OUT                                      8
#define LSB_GPIO_G2_OUT                                      0
#define AADDR_GPIO_G2_OUT                                    (BASE_ADDR_GPIO + ADDR_GPIO_G2_OUT)
#define REG_GPIO_G2_OUT                                      (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_OUT))

#define ADDR_GPIO_G3_OUT                                     (0x2AU)
#define A_GPIO_G3_OUT(ba)                                    ((ba) + ADDR_GPIO_G3_OUT)
#define R_GPIO_G3_OUT(ba)                                    (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_OUT(ba)))
#define RES_GPIO_G3_OUT                                      (0x0U)
#define MSB_GPIO_G3_OUT                                      8
#define LSB_GPIO_G3_OUT                                      0
#define AADDR_GPIO_G3_OUT                                    (BASE_ADDR_GPIO + ADDR_GPIO_G3_OUT)
#define REG_GPIO_G3_OUT                                      (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_OUT))

#define ADDR_GPIO_G0_OUT_SET                                 (0x2CU)
#define A_GPIO_G0_OUT_SET(ba)                                ((ba) + ADDR_GPIO_G0_OUT_SET)
#define R_GPIO_G0_OUT_SET(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_OUT_SET(ba)))
#define RES_GPIO_G0_OUT_SET                                  (0x0U)
#define MSB_GPIO_G0_OUT_SET                                  8
#define LSB_GPIO_G0_OUT_SET                                  0
#define AADDR_GPIO_G0_OUT_SET                                (BASE_ADDR_GPIO + ADDR_GPIO_G0_OUT_SET)
#define REG_GPIO_G0_OUT_SET                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_OUT_SET))

#define ADDR_GPIO_G1_OUT_SET                                 (0x2EU)
#define A_GPIO_G1_OUT_SET(ba)                                ((ba) + ADDR_GPIO_G1_OUT_SET)
#define R_GPIO_G1_OUT_SET(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_OUT_SET(ba)))
#define RES_GPIO_G1_OUT_SET                                  (0x0U)
#define MSB_GPIO_G1_OUT_SET                                  8
#define LSB_GPIO_G1_OUT_SET                                  0
#define AADDR_GPIO_G1_OUT_SET                                (BASE_ADDR_GPIO + ADDR_GPIO_G1_OUT_SET)
#define REG_GPIO_G1_OUT_SET                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_OUT_SET))

#define ADDR_GPIO_G2_OUT_SET                                 (0x30U)
#define A_GPIO_G2_OUT_SET(ba)                                ((ba) + ADDR_GPIO_G2_OUT_SET)
#define R_GPIO_G2_OUT_SET(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_OUT_SET(ba)))
#define RES_GPIO_G2_OUT_SET                                  (0x0U)
#define MSB_GPIO_G2_OUT_SET                                  8
#define LSB_GPIO_G2_OUT_SET                                  0
#define AADDR_GPIO_G2_OUT_SET                                (BASE_ADDR_GPIO + ADDR_GPIO_G2_OUT_SET)
#define REG_GPIO_G2_OUT_SET                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_OUT_SET))

#define ADDR_GPIO_G3_OUT_SET                                 (0x32U)
#define A_GPIO_G3_OUT_SET(ba)                                ((ba) + ADDR_GPIO_G3_OUT_SET)
#define R_GPIO_G3_OUT_SET(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_OUT_SET(ba)))
#define RES_GPIO_G3_OUT_SET                                  (0x0U)
#define MSB_GPIO_G3_OUT_SET                                  8
#define LSB_GPIO_G3_OUT_SET                                  0
#define AADDR_GPIO_G3_OUT_SET                                (BASE_ADDR_GPIO + ADDR_GPIO_G3_OUT_SET)
#define REG_GPIO_G3_OUT_SET                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_OUT_SET))

#define ADDR_GPIO_G0_OUT_CLR                                 (0x34U)
#define A_GPIO_G0_OUT_CLR(ba)                                ((ba) + ADDR_GPIO_G0_OUT_CLR)
#define R_GPIO_G0_OUT_CLR(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_OUT_CLR(ba)))
#define RES_GPIO_G0_OUT_CLR                                  (0x0U)
#define MSB_GPIO_G0_OUT_CLR                                  8
#define LSB_GPIO_G0_OUT_CLR                                  0
#define AADDR_GPIO_G0_OUT_CLR                                (BASE_ADDR_GPIO + ADDR_GPIO_G0_OUT_CLR)
#define REG_GPIO_G0_OUT_CLR                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_OUT_CLR))

#define ADDR_GPIO_G1_OUT_CLR                                 (0x36U)
#define A_GPIO_G1_OUT_CLR(ba)                                ((ba) + ADDR_GPIO_G1_OUT_CLR)
#define R_GPIO_G1_OUT_CLR(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_OUT_CLR(ba)))
#define RES_GPIO_G1_OUT_CLR                                  (0x0U)
#define MSB_GPIO_G1_OUT_CLR                                  8
#define LSB_GPIO_G1_OUT_CLR                                  0
#define AADDR_GPIO_G1_OUT_CLR                                (BASE_ADDR_GPIO + ADDR_GPIO_G1_OUT_CLR)
#define REG_GPIO_G1_OUT_CLR                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_OUT_CLR))

#define ADDR_GPIO_G2_OUT_CLR                                 (0x38U)
#define A_GPIO_G2_OUT_CLR(ba)                                ((ba) + ADDR_GPIO_G2_OUT_CLR)
#define R_GPIO_G2_OUT_CLR(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_OUT_CLR(ba)))
#define RES_GPIO_G2_OUT_CLR                                  (0x0U)
#define MSB_GPIO_G2_OUT_CLR                                  8
#define LSB_GPIO_G2_OUT_CLR                                  0
#define AADDR_GPIO_G2_OUT_CLR                                (BASE_ADDR_GPIO + ADDR_GPIO_G2_OUT_CLR)
#define REG_GPIO_G2_OUT_CLR                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_OUT_CLR))

#define ADDR_GPIO_G3_OUT_CLR                                 (0x3AU)
#define A_GPIO_G3_OUT_CLR(ba)                                ((ba) + ADDR_GPIO_G3_OUT_CLR)
#define R_GPIO_G3_OUT_CLR(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_OUT_CLR(ba)))
#define RES_GPIO_G3_OUT_CLR                                  (0x0U)
#define MSB_GPIO_G3_OUT_CLR                                  8
#define LSB_GPIO_G3_OUT_CLR                                  0
#define AADDR_GPIO_G3_OUT_CLR                                (BASE_ADDR_GPIO + ADDR_GPIO_G3_OUT_CLR)
#define REG_GPIO_G3_OUT_CLR                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_OUT_CLR))

#define ADDR_GPIO_G0_OUT_TOGGLE                              (0x3CU)
#define A_GPIO_G0_OUT_TOGGLE(ba)                             ((ba) + ADDR_GPIO_G0_OUT_TOGGLE)
#define R_GPIO_G0_OUT_TOGGLE(ba)                             (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_OUT_TOGGLE(ba)))
#define RES_GPIO_G0_OUT_TOGGLE                               (0x0U)
#define MSB_GPIO_G0_OUT_TOGGLE                               8
#define LSB_GPIO_G0_OUT_TOGGLE                               0
#define AADDR_GPIO_G0_OUT_TOGGLE                             (BASE_ADDR_GPIO + ADDR_GPIO_G0_OUT_TOGGLE)
#define REG_GPIO_G0_OUT_TOGGLE                               (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_OUT_TOGGLE))

#define ADDR_GPIO_G1_OUT_TOGGLE                              (0x3EU)
#define A_GPIO_G1_OUT_TOGGLE(ba)                             ((ba) + ADDR_GPIO_G1_OUT_TOGGLE)
#define R_GPIO_G1_OUT_TOGGLE(ba)                             (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_OUT_TOGGLE(ba)))
#define RES_GPIO_G1_OUT_TOGGLE                               (0x0U)
#define MSB_GPIO_G1_OUT_TOGGLE                               8
#define LSB_GPIO_G1_OUT_TOGGLE                               0
#define AADDR_GPIO_G1_OUT_TOGGLE                             (BASE_ADDR_GPIO + ADDR_GPIO_G1_OUT_TOGGLE)
#define REG_GPIO_G1_OUT_TOGGLE                               (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_OUT_TOGGLE))

#define ADDR_GPIO_G2_OUT_TOGGLE                              (0x40U)
#define A_GPIO_G2_OUT_TOGGLE(ba)                             ((ba) + ADDR_GPIO_G2_OUT_TOGGLE)
#define R_GPIO_G2_OUT_TOGGLE(ba)                             (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_OUT_TOGGLE(ba)))
#define RES_GPIO_G2_OUT_TOGGLE                               (0x0U)
#define MSB_GPIO_G2_OUT_TOGGLE                               8
#define LSB_GPIO_G2_OUT_TOGGLE                               0
#define AADDR_GPIO_G2_OUT_TOGGLE                             (BASE_ADDR_GPIO + ADDR_GPIO_G2_OUT_TOGGLE)
#define REG_GPIO_G2_OUT_TOGGLE                               (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_OUT_TOGGLE))

#define ADDR_GPIO_G3_OUT_TOGGLE                              (0x42U)
#define A_GPIO_G3_OUT_TOGGLE(ba)                             ((ba) + ADDR_GPIO_G3_OUT_TOGGLE)
#define R_GPIO_G3_OUT_TOGGLE(ba)                             (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_OUT_TOGGLE(ba)))
#define RES_GPIO_G3_OUT_TOGGLE                               (0x0U)
#define MSB_GPIO_G3_OUT_TOGGLE                               8
#define LSB_GPIO_G3_OUT_TOGGLE                               0
#define AADDR_GPIO_G3_OUT_TOGGLE                             (BASE_ADDR_GPIO + ADDR_GPIO_G3_OUT_TOGGLE)
#define REG_GPIO_G3_OUT_TOGGLE                               (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_OUT_TOGGLE))

#define ADDR_GPIO_G0_RESYN                                   (0x44U)
#define A_GPIO_G0_RESYN(ba)                                  ((ba) + ADDR_GPIO_G0_RESYN)
#define R_GPIO_G0_RESYN(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_RESYN(ba)))
#define RES_GPIO_G0_RESYN                                    (0x0U)
#define MSB_GPIO_G0_RESYN                                    8
#define LSB_GPIO_G0_RESYN                                    0
#define AADDR_GPIO_G0_RESYN                                  (BASE_ADDR_GPIO + ADDR_GPIO_G0_RESYN)
#define REG_GPIO_G0_RESYN                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_RESYN))

#define ADDR_GPIO_G1_RESYN                                   (0x46U)
#define A_GPIO_G1_RESYN(ba)                                  ((ba) + ADDR_GPIO_G1_RESYN)
#define R_GPIO_G1_RESYN(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_RESYN(ba)))
#define RES_GPIO_G1_RESYN                                    (0x0U)
#define MSB_GPIO_G1_RESYN                                    8
#define LSB_GPIO_G1_RESYN                                    0
#define AADDR_GPIO_G1_RESYN                                  (BASE_ADDR_GPIO + ADDR_GPIO_G1_RESYN)
#define REG_GPIO_G1_RESYN                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_RESYN))

#define ADDR_GPIO_G2_RESYN                                   (0x48U)
#define A_GPIO_G2_RESYN(ba)                                  ((ba) + ADDR_GPIO_G2_RESYN)
#define R_GPIO_G2_RESYN(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_RESYN(ba)))
#define RES_GPIO_G2_RESYN                                    (0x0U)
#define MSB_GPIO_G2_RESYN                                    8
#define LSB_GPIO_G2_RESYN                                    0
#define AADDR_GPIO_G2_RESYN                                  (BASE_ADDR_GPIO + ADDR_GPIO_G2_RESYN)
#define REG_GPIO_G2_RESYN                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_RESYN))

#define ADDR_GPIO_G3_RESYN                                   (0x4AU)
#define A_GPIO_G3_RESYN(ba)                                  ((ba) + ADDR_GPIO_G3_RESYN)
#define R_GPIO_G3_RESYN(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_RESYN(ba)))
#define RES_GPIO_G3_RESYN                                    (0x0U)
#define MSB_GPIO_G3_RESYN                                    8
#define LSB_GPIO_G3_RESYN                                    0
#define AADDR_GPIO_G3_RESYN                                  (BASE_ADDR_GPIO + ADDR_GPIO_G3_RESYN)
#define REG_GPIO_G3_RESYN                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_RESYN))

#define ADDR_GPIO_G0_F0                                      (0x4CU)
#define A_GPIO_G0_F0(ba)                                     ((ba) + ADDR_GPIO_G0_F0)
#define R_GPIO_G0_F0(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_F0(ba)))
#define RES_GPIO_G0_F0                                       (0x0U)
#define MSB_GPIO_G0_F0                                       8
#define LSB_GPIO_G0_F0                                       0
#define AADDR_GPIO_G0_F0                                     (BASE_ADDR_GPIO + ADDR_GPIO_G0_F0)
#define REG_GPIO_G0_F0                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_F0))

#define ADDR_GPIO_G1_F0                                      (0x4EU)
#define A_GPIO_G1_F0(ba)                                     ((ba) + ADDR_GPIO_G1_F0)
#define R_GPIO_G1_F0(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_F0(ba)))
#define RES_GPIO_G1_F0                                       (0x0U)
#define MSB_GPIO_G1_F0                                       8
#define LSB_GPIO_G1_F0                                       0
#define AADDR_GPIO_G1_F0                                     (BASE_ADDR_GPIO + ADDR_GPIO_G1_F0)
#define REG_GPIO_G1_F0                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_F0))

#define ADDR_GPIO_G2_F0                                      (0x50U)
#define A_GPIO_G2_F0(ba)                                     ((ba) + ADDR_GPIO_G2_F0)
#define R_GPIO_G2_F0(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_F0(ba)))
#define RES_GPIO_G2_F0                                       (0x0U)
#define MSB_GPIO_G2_F0                                       8
#define LSB_GPIO_G2_F0                                       0
#define AADDR_GPIO_G2_F0                                     (BASE_ADDR_GPIO + ADDR_GPIO_G2_F0)
#define REG_GPIO_G2_F0                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_F0))

#define ADDR_GPIO_G3_F0                                      (0x52U)
#define A_GPIO_G3_F0(ba)                                     ((ba) + ADDR_GPIO_G3_F0)
#define R_GPIO_G3_F0(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_F0(ba)))
#define RES_GPIO_G3_F0                                       (0x0U)
#define MSB_GPIO_G3_F0                                       8
#define LSB_GPIO_G3_F0                                       0
#define AADDR_GPIO_G3_F0                                     (BASE_ADDR_GPIO + ADDR_GPIO_G3_F0)
#define REG_GPIO_G3_F0                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_F0))

#define ADDR_GPIO_G0_F1                                      (0x54U)
#define A_GPIO_G0_F1(ba)                                     ((ba) + ADDR_GPIO_G0_F1)
#define R_GPIO_G0_F1(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_F1(ba)))
#define RES_GPIO_G0_F1                                       (0x0U)
#define MSB_GPIO_G0_F1                                       8
#define LSB_GPIO_G0_F1                                       0
#define AADDR_GPIO_G0_F1                                     (BASE_ADDR_GPIO + ADDR_GPIO_G0_F1)
#define REG_GPIO_G0_F1                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_F1))

#define ADDR_GPIO_G1_F1                                      (0x56U)
#define A_GPIO_G1_F1(ba)                                     ((ba) + ADDR_GPIO_G1_F1)
#define R_GPIO_G1_F1(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_F1(ba)))
#define RES_GPIO_G1_F1                                       (0x0U)
#define MSB_GPIO_G1_F1                                       8
#define LSB_GPIO_G1_F1                                       0
#define AADDR_GPIO_G1_F1                                     (BASE_ADDR_GPIO + ADDR_GPIO_G1_F1)
#define REG_GPIO_G1_F1                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_F1))

#define ADDR_GPIO_G2_F1                                      (0x58U)
#define A_GPIO_G2_F1(ba)                                     ((ba) + ADDR_GPIO_G2_F1)
#define R_GPIO_G2_F1(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_F1(ba)))
#define RES_GPIO_G2_F1                                       (0x0U)
#define MSB_GPIO_G2_F1                                       8
#define LSB_GPIO_G2_F1                                       0
#define AADDR_GPIO_G2_F1                                     (BASE_ADDR_GPIO + ADDR_GPIO_G2_F1)
#define REG_GPIO_G2_F1                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_F1))

#define ADDR_GPIO_G3_F1                                      (0x5AU)
#define A_GPIO_G3_F1(ba)                                     ((ba) + ADDR_GPIO_G3_F1)
#define R_GPIO_G3_F1(ba)                                     (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_F1(ba)))
#define RES_GPIO_G3_F1                                       (0x0U)
#define MSB_GPIO_G3_F1                                       8
#define LSB_GPIO_G3_F1                                       0
#define AADDR_GPIO_G3_F1                                     (BASE_ADDR_GPIO + ADDR_GPIO_G3_F1)
#define REG_GPIO_G3_F1                                       (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_F1))

#define ADDR_GPIO_G0_SYNC_SEL                                (0x5CU)
#define A_GPIO_G0_SYNC_SEL(ba)                               ((ba) + ADDR_GPIO_G0_SYNC_SEL)
#define R_GPIO_G0_SYNC_SEL(ba)                               (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_SYNC_SEL(ba)))
#define RES_GPIO_G0_SYNC_SEL                                 (0x0U)
#define MSB_GPIO_G0_SYNC_SEL                                 1
#define LSB_GPIO_G0_SYNC_SEL                                 0
#define AADDR_GPIO_G0_SYNC_SEL                               (BASE_ADDR_GPIO + ADDR_GPIO_G0_SYNC_SEL)
#define REG_GPIO_G0_SYNC_SEL                                 (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_SYNC_SEL))

#define ADDR_GPIO_G1_SYNC_SEL                                (0x5EU)
#define A_GPIO_G1_SYNC_SEL(ba)                               ((ba) + ADDR_GPIO_G1_SYNC_SEL)
#define R_GPIO_G1_SYNC_SEL(ba)                               (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_SYNC_SEL(ba)))
#define RES_GPIO_G1_SYNC_SEL                                 (0x0U)
#define MSB_GPIO_G1_SYNC_SEL                                 1
#define LSB_GPIO_G1_SYNC_SEL                                 0
#define AADDR_GPIO_G1_SYNC_SEL                               (BASE_ADDR_GPIO + ADDR_GPIO_G1_SYNC_SEL)
#define REG_GPIO_G1_SYNC_SEL                                 (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_SYNC_SEL))

#define ADDR_GPIO_G2_SYNC_SEL                                (0x60U)
#define A_GPIO_G2_SYNC_SEL(ba)                               ((ba) + ADDR_GPIO_G2_SYNC_SEL)
#define R_GPIO_G2_SYNC_SEL(ba)                               (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_SYNC_SEL(ba)))
#define RES_GPIO_G2_SYNC_SEL                                 (0x0U)
#define MSB_GPIO_G2_SYNC_SEL                                 1
#define LSB_GPIO_G2_SYNC_SEL                                 0
#define AADDR_GPIO_G2_SYNC_SEL                               (BASE_ADDR_GPIO + ADDR_GPIO_G2_SYNC_SEL)
#define REG_GPIO_G2_SYNC_SEL                                 (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_SYNC_SEL))

#define ADDR_GPIO_G3_SYNC_SEL                                (0x62U)
#define A_GPIO_G3_SYNC_SEL(ba)                               ((ba) + ADDR_GPIO_G3_SYNC_SEL)
#define R_GPIO_G3_SYNC_SEL(ba)                               (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_SYNC_SEL(ba)))
#define RES_GPIO_G3_SYNC_SEL                                 (0x0U)
#define MSB_GPIO_G3_SYNC_SEL                                 1
#define LSB_GPIO_G3_SYNC_SEL                                 0
#define AADDR_GPIO_G3_SYNC_SEL                               (BASE_ADDR_GPIO + ADDR_GPIO_G3_SYNC_SEL)
#define REG_GPIO_G3_SYNC_SEL                                 (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_SYNC_SEL))

#define ADDR_GPIO_G0_SYNC                                    (0x64U)
#define A_GPIO_G0_SYNC(ba)                                   ((ba) + ADDR_GPIO_G0_SYNC)
#define R_GPIO_G0_SYNC(ba)                                   (*(volatile unsigned short *)((unsigned int)A_GPIO_G0_SYNC(ba)))
#define RES_GPIO_G0_SYNC                                     (0x0U)
#define MSB_GPIO_G0_SYNC                                     8
#define LSB_GPIO_G0_SYNC                                     0
#define AADDR_GPIO_G0_SYNC                                   (BASE_ADDR_GPIO + ADDR_GPIO_G0_SYNC)
#define REG_GPIO_G0_SYNC                                     (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G0_SYNC))

#define ADDR_GPIO_G1_SYNC                                    (0x66U)
#define A_GPIO_G1_SYNC(ba)                                   ((ba) + ADDR_GPIO_G1_SYNC)
#define R_GPIO_G1_SYNC(ba)                                   (*(volatile unsigned short *)((unsigned int)A_GPIO_G1_SYNC(ba)))
#define RES_GPIO_G1_SYNC                                     (0x0U)
#define MSB_GPIO_G1_SYNC                                     8
#define LSB_GPIO_G1_SYNC                                     0
#define AADDR_GPIO_G1_SYNC                                   (BASE_ADDR_GPIO + ADDR_GPIO_G1_SYNC)
#define REG_GPIO_G1_SYNC                                     (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G1_SYNC))

#define ADDR_GPIO_G2_SYNC                                    (0x68U)
#define A_GPIO_G2_SYNC(ba)                                   ((ba) + ADDR_GPIO_G2_SYNC)
#define R_GPIO_G2_SYNC(ba)                                   (*(volatile unsigned short *)((unsigned int)A_GPIO_G2_SYNC(ba)))
#define RES_GPIO_G2_SYNC                                     (0x0U)
#define MSB_GPIO_G2_SYNC                                     8
#define LSB_GPIO_G2_SYNC                                     0
#define AADDR_GPIO_G2_SYNC                                   (BASE_ADDR_GPIO + ADDR_GPIO_G2_SYNC)
#define REG_GPIO_G2_SYNC                                     (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G2_SYNC))

#define ADDR_GPIO_G3_SYNC                                    (0x6AU)
#define A_GPIO_G3_SYNC(ba)                                   ((ba) + ADDR_GPIO_G3_SYNC)
#define R_GPIO_G3_SYNC(ba)                                   (*(volatile unsigned short *)((unsigned int)A_GPIO_G3_SYNC(ba)))
#define RES_GPIO_G3_SYNC                                     (0x0U)
#define MSB_GPIO_G3_SYNC                                     8
#define LSB_GPIO_G3_SYNC                                     0
#define AADDR_GPIO_G3_SYNC                                   (BASE_ADDR_GPIO + ADDR_GPIO_G3_SYNC)
#define REG_GPIO_G3_SYNC                                     (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_G3_SYNC))

#define ADDR_GPIO_IRQ_CFG0                                   (0x6CU)
#define A_GPIO_IRQ_CFG0(ba)                                  ((ba) + ADDR_GPIO_IRQ_CFG0)
#define R_GPIO_IRQ_CFG0(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_CFG0(ba)))
#define RES_GPIO_IRQ_CFG0                                    (0x0U)
#define MSB_GPIO_IRQ_CFG0                                    11
#define LSB_GPIO_IRQ_CFG0                                    0
#define AADDR_GPIO_IRQ_CFG0                                  (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_CFG0)
#define REG_GPIO_IRQ_CFG0                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_CFG0))

#define ADDR_GPIO_IRQ_CFG1                                   (0x6EU)
#define A_GPIO_IRQ_CFG1(ba)                                  ((ba) + ADDR_GPIO_IRQ_CFG1)
#define R_GPIO_IRQ_CFG1(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_CFG1(ba)))
#define RES_GPIO_IRQ_CFG1                                    (0x0U)
#define MSB_GPIO_IRQ_CFG1                                    11
#define LSB_GPIO_IRQ_CFG1                                    0
#define AADDR_GPIO_IRQ_CFG1                                  (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_CFG1)
#define REG_GPIO_IRQ_CFG1                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_CFG1))

#define ADDR_GPIO_IRQ_CFG2                                   (0x70U)
#define A_GPIO_IRQ_CFG2(ba)                                  ((ba) + ADDR_GPIO_IRQ_CFG2)
#define R_GPIO_IRQ_CFG2(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_CFG2(ba)))
#define RES_GPIO_IRQ_CFG2                                    (0x0U)
#define MSB_GPIO_IRQ_CFG2                                    11
#define LSB_GPIO_IRQ_CFG2                                    0
#define AADDR_GPIO_IRQ_CFG2                                  (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_CFG2)
#define REG_GPIO_IRQ_CFG2                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_CFG2))

#define ADDR_GPIO_IRQ_CFG3                                   (0x72U)
#define A_GPIO_IRQ_CFG3(ba)                                  ((ba) + ADDR_GPIO_IRQ_CFG3)
#define R_GPIO_IRQ_CFG3(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_CFG3(ba)))
#define RES_GPIO_IRQ_CFG3                                    (0x0U)
#define MSB_GPIO_IRQ_CFG3                                    11
#define LSB_GPIO_IRQ_CFG3                                    0
#define AADDR_GPIO_IRQ_CFG3                                  (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_CFG3)
#define REG_GPIO_IRQ_CFG3                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_CFG3))

#define ADDR_GPIO_IRQ_STATUS                                 (0x74U)
#define A_GPIO_IRQ_STATUS(ba)                                ((ba) + ADDR_GPIO_IRQ_STATUS)
#define R_GPIO_IRQ_STATUS(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_STATUS(ba)))
#define RES_GPIO_IRQ_STATUS                                  (0x0U)
#define MSB_GPIO_IRQ_STATUS                                  15
#define LSB_GPIO_IRQ_STATUS                                  0
#define AADDR_GPIO_IRQ_STATUS                                (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_STATUS)
#define REG_GPIO_IRQ_STATUS                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_STATUS))

#define ADDR_GPIO_IRQ_MASK                                   (0x78U)
#define A_GPIO_IRQ_MASK(ba)                                  ((ba) + ADDR_GPIO_IRQ_MASK)
#define R_GPIO_IRQ_MASK(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_MASK(ba)))
#define RES_GPIO_IRQ_MASK                                    (0x0U)
#define MSB_GPIO_IRQ_MASK                                    15
#define LSB_GPIO_IRQ_MASK                                    0
#define AADDR_GPIO_IRQ_MASK                                  (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_MASK)
#define REG_GPIO_IRQ_MASK                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_MASK))

#define ADDR_GPIO_IRQ_VENABLE                                (0x7CU)
#define A_GPIO_IRQ_VENABLE(ba)                               ((ba) + ADDR_GPIO_IRQ_VENABLE)
#define R_GPIO_IRQ_VENABLE(ba)                               (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_VENABLE(ba)))
#define RES_GPIO_IRQ_VENABLE                                 (0x0U)
#define MSB_GPIO_IRQ_VENABLE                                 3
#define LSB_GPIO_IRQ_VENABLE                                 0
#define AADDR_GPIO_IRQ_VENABLE                               (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_VENABLE)
#define REG_GPIO_IRQ_VENABLE                                 (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_VENABLE))

#define ADDR_GPIO_IRQ_VDISABLE                               (0x7EU)
#define A_GPIO_IRQ_VDISABLE(ba)                              ((ba) + ADDR_GPIO_IRQ_VDISABLE)
#define R_GPIO_IRQ_VDISABLE(ba)                              (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_VDISABLE(ba)))
#define RES_GPIO_IRQ_VDISABLE                                (0x0U)
#define MSB_GPIO_IRQ_VDISABLE                                3
#define LSB_GPIO_IRQ_VDISABLE                                0
#define AADDR_GPIO_IRQ_VDISABLE                              (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_VDISABLE)
#define REG_GPIO_IRQ_VDISABLE                                (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_VDISABLE))

#define ADDR_GPIO_IRQ_VMAX                                   (0x80U)
#define A_GPIO_IRQ_VMAX(ba)                                  ((ba) + ADDR_GPIO_IRQ_VMAX)
#define R_GPIO_IRQ_VMAX(ba)                                  (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_VMAX(ba)))
#define RES_GPIO_IRQ_VMAX                                    (0x10U)
#define MSB_GPIO_IRQ_VMAX                                    4
#define LSB_GPIO_IRQ_VMAX                                    0
#define AADDR_GPIO_IRQ_VMAX                                  (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_VMAX)
#define REG_GPIO_IRQ_VMAX                                    (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_VMAX))

#define ADDR_GPIO_IRQ_VNO                                    (0x82U)
#define A_GPIO_IRQ_VNO(ba)                                   ((ba) + ADDR_GPIO_IRQ_VNO)
#define R_GPIO_IRQ_VNO(ba)                                   (*(volatile unsigned short *)((unsigned int)A_GPIO_IRQ_VNO(ba)))
#define RES_GPIO_IRQ_VNO                                     (0x10U)
#define MSB_GPIO_IRQ_VNO                                     4
#define LSB_GPIO_IRQ_VNO                                     0
#define AADDR_GPIO_IRQ_VNO                                   (BASE_ADDR_GPIO + ADDR_GPIO_IRQ_VNO)
#define REG_GPIO_IRQ_VNO                                     (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_IRQ_VNO))

#define ADDR_GPIO_CONFIG_NMI                                 (0x84U)
#define A_GPIO_CONFIG_NMI(ba)                                ((ba) + ADDR_GPIO_CONFIG_NMI)
#define R_GPIO_CONFIG_NMI(ba)                                (*(volatile unsigned short *)((unsigned int)A_GPIO_CONFIG_NMI(ba)))
#define RES_GPIO_CONFIG_NMI                                  (0x0U)
#define MSB_GPIO_CONFIG_NMI                                  7
#define LSB_GPIO_CONFIG_NMI                                  0
#define AADDR_GPIO_CONFIG_NMI                                (BASE_ADDR_GPIO + ADDR_GPIO_CONFIG_NMI)
#define REG_GPIO_CONFIG_NMI                                  (*(volatile unsigned short *)((unsigned int)AADDR_GPIO_CONFIG_NMI))




#endif
