#include "stdint.h"
#include "hardware_api.h"
#include "circular_buffer_api.h"


uint16_t circular_buffer_api_cpu_n_cpu_atomic_block_start(void) {
  uint16_t tsf0 = cpu_n_cpu_test_set_flag(CPU_N_CPU_1, TS_FLAG_CB_SEMAPHORE);
  return(tsf0);
}

// #############################################################################

void circular_buffer_api_cpu_n_cpu_atomic_block_end(void) {
  cpu_n_cpu_clr_ts_flag(CPU_N_CPU_1, TS_FLAG_CB_SEMAPHORE);
}

// #############################################################################

static uint16_t circular_buffer_api_length_data(volatile s_circular_buffer *cb) {
  return((cb->size + cb->write - cb->read) & ( cb->size - 1));
}

// #############################################################################

errors_api_code_e circular_buffer_api_write(volatile s_circular_buffer *cb, s_mbox_queue_param * data) {
  errors_api_code_e i_error;  

  if(circular_buffer_api_cpu_n_cpu_atomic_block_start()){
    return(eError_circular_buffer_api_wait);
  }
  
  if ( circular_buffer_api_length_data(cb) == (cb->size-1)) {
    i_error = eError_circular_buffer_api_full;
  }
  else {
    cb->buf[cb->write] = *data;
    cb->write = (cb->write + 1) & ( cb->size - 1); 
    i_error = eError_none;
  }
  
  circular_buffer_api_cpu_n_cpu_atomic_block_end();
  return(i_error);
}

// #############################################################################

errors_api_code_e circular_buffer_api_read(volatile s_circular_buffer *cb, s_mbox_queue_param * data) {
  errors_api_code_e i_error;
  
  if(circular_buffer_api_cpu_n_cpu_atomic_block_start()){
    return(eError_circular_buffer_api_wait);
  }
  
  if ( circular_buffer_api_length_data(cb) == 0) {
    i_error = eError_circular_buffer_api_empty;
  }
  else {
    *data = cb->buf[cb->read];
    cb->read = (cb->read + 1) & ( cb->size - 1);
    i_error = eError_none;
  }


  circular_buffer_api_cpu_n_cpu_atomic_block_end();
  return(i_error);
}

// #############################################################################

errors_api_code_e circular_buffer_api_number_elements(volatile s_circular_buffer *cb, uint16_t * number_elements) {
  errors_api_code_e i_error;
  
  if(circular_buffer_api_cpu_n_cpu_atomic_block_start()){
    return(eError_circular_buffer_api_wait);
  }
  
  *number_elements = circular_buffer_api_length_data(cb);
  
  if ( *number_elements == (cb->size-1)) {
    i_error = eError_circular_buffer_api_full;
  }else if ( circular_buffer_api_length_data(cb) == 0) {
    i_error = eError_circular_buffer_api_empty;
  }
  else {
    i_error = eError_none;
  }

  circular_buffer_api_cpu_n_cpu_atomic_block_end();
  return(i_error);
}

