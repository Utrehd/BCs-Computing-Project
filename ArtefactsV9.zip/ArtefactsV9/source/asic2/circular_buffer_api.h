/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         circular_buffer_api.h
*
* @brief        Circular Buffer API functions
*
* @author       Dedourek Pavel, Cid Mateo
*
********************************************************************************
*
********************************************************************************
********************************************************************************
*/

#ifndef __CB_H__
#define __CB_H__

#include "stdint.h"
#include "slave/swd_mailbox_generic.h"
#include "errors_api.h"

#define TS_FLAG_CB_SEMAPHORE 1 ///< Define semaphore flag to use in CPU_N_CPU

/**
 * \defgroup circular_buffer_api ASIC2 Circular Buffer API functions
 * 
 * \ingroup  circular_buffer_api   asic2_api
 *
 * \brief    API function to control Circullar Buffer
 *
 */
/**@{*/

// #############################################################################
/** 
 * \brief This structure describes Circular Buffer parameters
 *
 * \ingroup circular_buffer_api
 */
typedef struct {
  mbox_cmd_e swd_command;
  diag_t tDiag;
  bool failsave;
} s_mbox_queue_param;

// #############################################################################
/** 
 * \brief This structure describes Circular Buffer status
 *
 * \ingroup circular_buffer_api
 */
typedef struct {
  s_mbox_queue_param *buf;  ///< block of memory
  uint16_t size;   ///< must be a power of two
  uint16_t read;   ///< holds current read position: 0 to (size-1)
  uint16_t write;  ///< holds current write position: 0 to (size-1) 
} s_circular_buffer ;

/* ############################################################################ */
/**
 * \brief Function to lock the mechanism
 *
 * \ingroup circular_buffer_api
 * 
 * \return True when the semaphore is locked
 */
uint16_t circular_buffer_api_cpu_n_cpu_atomic_block_start(void);

/* ############################################################################ */
/**
 * \brief Function to unlock the mechanism
 *
 * \ingroup circular_buffer_api
 */
void circular_buffer_api_cpu_n_cpu_atomic_block_end(void);

/* ############################################################################ */
/**
 * \brief Internal function to get number of elements in circular buffer
 *
 * \ingroup circular_buffer_api
 * 
 * \param cb Pointer to circular buffer
 *
 * \return Number of items in circular buffer
 */
static uint16_t circular_buffer_api_length_data(volatile s_circular_buffer *cb);

// #############################################################################
/**
 * \brief Function to write data into circular buffer
 *
 * \ingroup circular_buffer_api
 *
 * \param cb Pointer to circular buffer
 * 
 * \param data Data to be written into circular buffer
 *
 * \return Error code
 */
errors_api_code_e circular_buffer_api_write(volatile s_circular_buffer *cb, s_mbox_queue_param * data);

// #############################################################################
/**
 * \brief Function to read data from circular buffer
 *
 * \ingroup circular_buffer_api
 *
 * \param cb Pointer to circular buffer
 * 
 * \param data Pointer to the read data from the circular buffer
 *
 * \return Error code
 */
errors_api_code_e circular_buffer_api_read(volatile s_circular_buffer *cb,s_mbox_queue_param * data);

// #############################################################################
/**
 * \brief Function to read the number of current elements inside the circular buffer
 *
 * \ingroup circular_buffer_api
 *
 * \param cb Pointer to circular buffer
 * 
 * \param number_elements Pointer to the number of current elements inside the circular buffer
 *
 * \return Error code
 */
errors_api_code_e circular_buffer_api_number_elements(volatile s_circular_buffer *cb, uint16_t * number_elements);

#endif

