/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         irq_no.h
*
* @brief        Numbers of Interrupt Request (IRQ)
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __IRQ_NO_H__
#define __IRQ_NO_H__

/* ############################################################################ */
/**
 * \brief This is an enum class for Numbers of Interrupt Request to specify numbers to different IRQs
 */ 

typedef enum {
  IRQ_CLK_NRES_0                                  = 0,
  IRQ_SWTIMER0                                    = 1,
  IRQ_TSU                                         = 2,
  IRQ_SWD                                         = 3,
  IRQ_HV_CTRL                                     = 4,
  IRQ_CPU_N_CPU_0                                 = 5,
  IRQ_EL_CTRL                                     = 6,
  IRQ_SWTIMER1                                    = 7,
  IRQ_HISPI                                       = 8,
  IRQ_UART                                        = 9,
  IRQ_CRC0                                        = 10,
  IRQ_CRC1                                        = 11,
  IRQ_GPIO                                        = 12,
  IRQ_SARADC_CTRL                                 = 13,
  IRQ_CPU_N_CPU_1                                 = 14,
  IRQ_PWMN                                        = 15,
  IRQ_CCTIMER0                                    = 16,
  IRQ_CCTIMER1                                    = 17,
  IRQ_USI0                                        = 18,
  IRQ_USI1                                        = 19,
  IRQ_I2C                                         = 20,
  IRQ_CPU_N_CPU_EXT                               = 21,
  IRQ_COUNT                                       = 22,
} irq_number_t;

/**@} */
#endif /* __IRQ_NO_H__ */
