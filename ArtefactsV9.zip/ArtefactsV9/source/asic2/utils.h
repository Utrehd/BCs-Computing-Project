/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         utils.h
*
* @brief        Utils HAL functions
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

// #ifndef  __UTILS_H__
// #define  __UTILS_H__
// 
// #include "device.h"
// 
// #include "uart_api.h"
// #include <stdarg.h>
// 
// extern uart_num_t utils_printf_uart;
// extern void       (*utils_printf_func)(uint16_t);
// 
// bool div_u16(uint16_t x, uint16_t y, uint16_t * div, uint16_t * mod);
// 
// uint16_t printf(const char *format, ...);
// 
// char* strcpy(char* dst, const char* src);
// 
// void* memcpy(void* dst, const void* src, unsigned int len);
// 
// unsigned int strlen(const char* str);
// 
// void set_debug_uart(uart_num_t uart);
// void set_debug_func(void (*func)(uint16_t));
// 
// #endif

#ifndef  __UTILS_H__
#define  __UTILS_H__

/**
 * \defgroup api_utils ASIC2 Utils HAL functions
 * 
 * \brief    Functions to control Utils
 */
/**@{*/ 

#include "device.h"


#define UNSIGNED_SAT(val, bits) (((val) > ((1 << (bits)) - 1)) ? ((1 << (bits)) - 1) : (val))

#define NON_ZERO_TO_ONE(value) (((value) == 0) ? 0 : 1)

#define MIN(a,b) (((a)<(b))?(a):(b))

#define MAX(a,b) (((a)>(b))?(a):(b))

#define ABS(x) ((x)<0 ? -(x) : (x))

/**
  * \brief This structure describes 8 bits data
  *
  * \ingroup api_utils
  */
typedef struct
{
    uint8_t  bit0:1;
    uint8_t  bit1:1;
    uint8_t  bit2:1;
    uint8_t  bit3:1;
    uint8_t  bit4:1;
    uint8_t  bit5:1;
    uint8_t  bit6:1;
    uint8_t  bit7:1;
} data_bf;

/**
  * \brief Conversion type between byte and bit representation of data
  *
  * \ingroup api_utils
  */ 
typedef union
{
  uint8_t data;
  data_bf bf;
} data_t;

extern const uint16_t onehot16[16];

bool div_u16(uint16_t x, uint16_t y, uint16_t * div, uint16_t * mod);

void wait_cpu_cycles(uint32_t time);

/* ############################################################################ */
/**
* Function to read FPGA build number from FLASH memory.
*
* \return FPGA build number
*/
uint16_t get_fpga_build( void );

/* ############################################################################ */
/**
* Function to read ASIC2 build number from FLASH memory.
*
* \return ASIC2 build number
*/
uint32_t get_asic2_serial( void );

/* ########################################################################## */    
/**
 * @brief sets the desired baud rate on the serial interface that was selected
 * 
 * This method sets the desired baud rate on the currently set serial port. For 
 * this purpose, the actual frequency of the clock network is needed to be set
 * in application_config.c -> clock_DEBUG_UART_Hz. 
 * The function provides a fixed 8n1 as word format.
 *
 * @param baudrate baudrate in Hz
 */
void uart_init_baudrate ( uint32_t baudrate );

/* ########################################################################## */    
/**
 * Function used for resetting all blocks (except GUARD0/GUARD1)
 */
void utils_print_project_name(void);


/* ########################################################################## */    
/**
 * Function to reset all peripherals - except GUARDs 
 */
void utils_reset_all_blocks(void);

/* ########################################################################## */    
/**
 * Function to printout application config for SWD Prog2 tool to fill in .ini file
 */
void test_utils_print_values_for_swd_prog_ini(void);


/* ########################################################################## */    
/**
* Function to check if par_value is inside of interval <par_low,par_high>
*
* \param par_low low limit for comparison
*
* \param par_value value for comparison
*
* \param par_high high limit for comparison
*
* \return result of comarison (true when value is in limits)
*/
bool utils_cmp_in_range(uint32_t par_low, uint32_t par_value, uint32_t par_high);

/* ########################################################################## */    
/**
* Function to check if m_dwActual is close to expected value m_dwExpected defined by m_cPercentage
*
* \param m_dwActual actal value
*
* \param m_dwExpected expected value
*
* \param m_cPercentage the percantage band
*
* \return result of comarison (true when value is in percantage band)
*/
bool utils_cmp_in_percentage(uint32_t m_dwActual, uint32_t m_dwExpected, uint8_t m_cPercentage);

/* ########################################################################## */    
/**
* Register that core reset is needed
*
* \see BUG_6963_FIX
*/
void utils_reset_register(void);


/* ########################################################################## */    
/**
* Function to cexec reset when it is needed (when utils_reset_register() was called)
*
* \see BUG_6963_FIX
*/
void utils_reset_exec(void);



/**@} */
#endif /* __UTILS_H__ */

