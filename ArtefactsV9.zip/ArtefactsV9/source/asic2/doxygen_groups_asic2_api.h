/**
 *  \defgroup asic2_api API functions
 *
 *
 *  \brief    ASIC2 API functions
 *
 * @{
 *
 * @}
 */
