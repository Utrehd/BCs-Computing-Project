#include "application_config.h"
#include "application_config_user_calc.h"

#if defined(SWD_SLAVE_STACK) 
  /* SWD device database */
  #include "swd_device_db_file.h"
#endif


//
// DO NOT MODIFY FOLLOWING CODE
//
// You have to go to "device_settings.h" to change device setting.
//
//     device_settings.h (definition of setting)
//
//     ---> application_config_user_calc.h (calculation)
//       
//          ---> application_config.c (store data into structure)
//

#pragma location = "APPLICATION_CONFIG"

#ifdef __IAR_SYSTEMS_ICC__
__root  
#endif
const application_config_t application_config = {
  .struct_version_tag = 2,
  
#if defined(SWD_SLAVE_STACK)   
  // SWD DEVICE STACK
  .product_name = SWD_DEVICE_DB_DEVICE,
  .vendor_id = SWD_DEVICE_DB_VENDOR_ID,
  .device_id= SWD_DEVICE_DB_DEVICE_ID,
  .device_options = SWD_DEVICE_DB_DEVICE_OPTIONS,
#else
  // Other products
  .product_name = APPLICATION_CONFIG_PRODUCT_NAME,
  .vendor_id = APPLICATION_CONFIG_VENDOR_ID,
  .device_id = APPLICATION_CONFIG_DEVICE_ID,
  .device_options = APPLICATION_CONFIG_DEVICE_OPTIONS,
#endif  
  
  .disable_watchdog_for_development_only = APPLICATION_CONFIG_DISABLE_WATCHDOG_FOR_DEVELOPMENT_ONLY,
  
  .use_GPO_SWD_LED_and_not_EL            = APPLICATION_CONFIG_USE_GPO_SWD_LED_AND_NOT_EL,
    
  .sw_ver = APPLICATION_CONFIG_SW_VER,
  .hw_ver = APPLICATION_CONFIG_HW_VER,
  .jtag_dio = APPLICATION_CONFIG_JTAG_DIO, 
  .repeater_type = APPLICATION_CONFIG_REPEATER_TYPE,
                                                          
  
  .bootloader_cfg.bootloader_flash0_crc16_start_addr = APPLICATION_CONFIG_BOOTLOADER_FLASH0_CRC16_START_ADDR,
  .bootloader_cfg.bootloader_flash0_crc16_length = APPLICATION_CONFIG_BOOTLOADER_FLASH0_CRC16_LENGTH,
  
  .bootloader_cfg.bootloader_flash1_crc16_start_addr = APPLICATION_CONFIG_BOOTLOADER_FLASH1_CRC16_START_ADDR,
  .bootloader_cfg.bootloader_flash1_crc16_length = APPLICATION_CONFIG_BOOTLOADER_FLASH1_CRC16_LENGTH,

#if defined(DEBUG)   
  // In debug mode FLASH memory is not correctly filled (the last address)
  .bootloader_cfg.bootloader_mode = BOOTLOADER_MODE_DISABLED,
#else  
  .bootloader_cfg.bootloader_mode = APPLICATION_CONFIG_BOOTLOADER_MODE,
#endif
  
  .bootloader_cfg.bootloader_force_pin_mask = APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_PIN_MASK,
  .bootloader_cfg.bootloader_force_pin_group = APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_GROUP,
  .bootloader_cfg.bootloader_force_pin_value = APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_VALUE,
  
  .bootloader_cfg.bootloader_dualcore  = APPLICATION_CONFIG_BOOTLOADER_DUALCORE,

#if defined(SWD_SLAVE_STACK) 
  .asic2_clock.clock_SWD_Hz = CLK_NRES_AS0_SWD_TSU_FREQ_HZ,
#elif defined(MODBUS_DEVICE_STACK)
  .asic2_clock.clock_SWD_Hz = CLK_NRES_AS1_USI0_FREQ_HZ,
#else  
  #warning "clock_SWD_Hz is not defined"
  .asic2_clock.clock_SWD_Hz = 0,
#endif
  
  .asic2_clock.clock_SWSUBTIMER_1_Hz = CLK_NRES_CFG_RATE_SEL_SWTIMER0_FREQ_HZ,

#if defined(APPLICATION_CONFIG_BOOTLOADER_UART_DEBUG_PIN)   
  .asic2_clock.clock_DEBUG_UART_Hz = (CLK_NRES_CFG_RATE_SEL_UART_FREQ_HZ & 0xFFFFff00) | APPLICATION_CONFIG_BOOTLOADER_UART_DEBUG_PIN,
#else
  // UART DEBUG PIN - PAD10 on eval board
  .asic2_clock.clock_DEBUG_UART_Hz = (CLK_NRES_CFG_RATE_SEL_UART_FREQ_HZ & 0xFFFFff00) | (10),
#endif
  
  .asic2_clock.clock_WDOG_Hz = CLK_NRES_CFG_RATE_SEL_WDOG0_FREQ_HZ,  

  .asic2_clock.clk_nres_cfg_ana_osc.bf.rcosc_hf_pd_n = CLK_NRES_RCOSC_HF_PD_N,

  .asic2_clock.clk_nres_cfg_ana_osc.bf.qosc_pd_n     = CLK_NRES_QOSC_PD_N,

  .asic2_clock.clk_nres_cfg_ana_osc.bf.qosc_strength = CLK_NRES_RCOSC_QOSC_STRENGTH,
  
  .asic2_clock.clk_nres_cfg_ana_osc.bf.qosc_clk_bypass = CLK_NRES_ANA_OSC_QOSC_CLK_BYPASS,

  .asic2_clock.clk_nres_cfg_ana_pll0.bf.pll_fin_src = CLK_NRES_RCOSC_SOURCE_FOR_PLL,
  
  .asic2_clock.clk_nres_cfg_ana_pll0.bf.pll_oe = CLK_NRES_PLL_PLL_OE,    

  .asic2_clock.clk_nres_cfg_ana_pll0.bf.pll_pd_n = CLK_NRES_PLL_PLL_PD_N,

  .asic2_clock.clk_nres_cfg_ana_pll1.bf.pll_od = CLK_NRES_PLL_OD,
  .asic2_clock.clk_nres_cfg_ana_pll1.bf.pll_nr = CLK_NRES_PLL_NR,
  .asic2_clock.clk_nres_cfg_ana_pll1.bf.pll_nf = CLK_NRES_PLL_NF,

  .asic2_clock.clk_nres_cfg_AS0_swd_tsu.bf.clk_src = CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC,
  .asic2_clock.clk_nres_cfg_AS0_swd_tsu.bf.clk_div = CLK_NRES_CFG_AS0_SWD_TSU_CLK_DIV,
  
  .asic2_clock.clk_nres_cfg_AS1_usi0.bf.clk_src    = CLK_NRES_CFG_AS1_USI0_CLK_SRC,
  .asic2_clock.clk_nres_cfg_AS1_usi0.bf.clk_div    = CLK_NRES_CFG_AS1_USI0_CLK_DIV,
  
  .asic2_clock.clk_nres_cfg_AS2_usi1.bf.clk_src    = CLK_NRES_CFG_AS2_USI1_CLK_SRC,
  .asic2_clock.clk_nres_cfg_AS2_usi1.bf.clk_div    = CLK_NRES_CFG_AS2_USI1_CLK_DIV,
  
  .asic2_clock.clk_nres_cfg_AS3_hipsi.bf.clk_src   = CLK_NRES_CFG_AS3_HISPI_CLK_SRC,
  .asic2_clock.clk_nres_cfg_AS3_hipsi.bf.clk_div   = CLK_NRES_CFG_AS3_HISPI_CLK_DIV,
  
  .asic2_clock.clk_nres_cfg_M.bf.clk_src           = CLK_NRES_CFG_M_CLK_SRC,
  .asic2_clock.clk_nres_cfg_M.bf.clk_div           = CLK_NRES_CFG_M_CLK_DIV,
  
  .asic2_clock.clk_nres_cfg_rate.bf.cfg_low_rate_0 = CLK_NRES_CFG_LOW_RATE_0,
  .asic2_clock.clk_nres_cfg_rate.bf.cfg_low_rate_1 = CLK_NRES_CFG_LOW_RATE_1,
  .asic2_clock.clk_nres_cfg_rate.bf.cfg_high_rate  = CLK_NRES_CFG_HIGH_RATE,
  
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_tsu         = CLK_NRES_CFG_RATE_SEL_TSU,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_gpio        = CLK_NRES_CFG_RATE_SEL_GPIO,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_guard0      = CLK_NRES_CFG_RATE_SEL_GUARD0,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_guard1      = CLK_NRES_CFG_RATE_SEL_GUARD1,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_swtimer0    = CLK_NRES_CFG_RATE_SEL_SWTIMER0,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_swtimer1    = CLK_NRES_CFG_RATE_SEL_SWTIMER1,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_pwmn        = CLK_NRES_CFG_RATE_SEL_PWMN,
  .asic2_clock.clk_nres_cfg_rate_sel_0.bf.cfg_rate_sel_vic_ext     = CLK_NRES_CFG_RATE_SEL_VIC_EXT,

  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_wdog0       = CLK_NRES_CFG_RATE_SEL_WDOG0,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_wdog1       = CLK_NRES_CFG_RATE_SEL_WDOG1,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_cpu_n_cpu   = CLK_NRES_CFG_RATE_SEL_CPU_N_CPU,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_cctimer0    = CLK_NRES_CFG_RATE_SEL_CCTIMER0,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_cctimer1    = CLK_NRES_CFG_RATE_SEL_CCTIMER1,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_io_ctrl     = CLK_NRES_CFG_RATE_SEL_IO_CTRL,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_analog_ctrl = CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL,
  .asic2_clock.clk_nres_cfg_rate_sel_1.bf.cfg_rate_sel_access_ctrl = CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL,

  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_hv_ctrl     = CLK_NRES_CFG_RATE_SEL_HV_CTRL,
  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_uart        = CLK_NRES_CFG_RATE_SEL_UART,
  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_aout_ctrl   = CLK_NRES_CFG_RATE_SEL_AOUT_CTRL,
  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_i2c         = CLK_NRES_CFG_RATE_SEL_I2C,
  .asic2_clock.clk_nres_cfg_rate_sel_2.bf.cfg_rate_sel_el_ctrl     = CLK_NRES_CFG_RATE_SEL_EL_CTRL,
  

  .asic2_clock.use_flash_half_clock_speed = APPLICATION_CONFIG_FLASH_CTRL_USE_FLASH_HALF_CLOCK_SPEED,
  .asic2_clock.flash_timings.tnvs_tnvh    = APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH,
  .asic2_clock.flash_timings.tnvh1        = APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVH1,
  .asic2_clock.flash_timings.tpgs         = APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPGS,
  .asic2_clock.flash_timings.trcv         = APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TRCV,
  .asic2_clock.flash_timings.tprog        = APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPROG,
  .asic2_clock.flash_timings.terase       = APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TERASE,
  .asic2_clock.flash_timings.tme          = APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TME,
  
  // For the LCF Interpreter
  .reserved2 = 
  // %QX0.0 := %IX0.2 AND %IX0.4 OR %IX0.3;
  // %QX0.1 := NOT %IX0.2;
  {
    0x22, 
    0x06,
    
    0x01, 0x01,
    0x01, 0x00, 
    0x05,
    0x02, 0x00, 

    0x01, 0x03, 
    0x01, 0x02, 
    0x04,
    0x02, 0x01, 

    0x01, 0x00, 
    0x00, 0x01, 
    0x06, 
    0x02, 0x02,

    0x01, 0x03,
    0x01, 0x02,
    0x05, 
    0x01, 0x01,
    0x05, 
    0x01, 0x00,
    0x05, 
    0x02, 0x03
  }
};


