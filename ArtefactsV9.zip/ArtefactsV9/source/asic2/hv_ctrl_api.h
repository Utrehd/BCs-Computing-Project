/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hv_ctrl_api.h
*
* @brief        HV_CTRL API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

/**
* \file 
*
* \brief  HV_CTRL API functions
*
* \author Eaton European Innovation Center 
*
* \version FPGA Release: 10512 / ASIC2 Specification (Revision 2.9.3)
*/

#ifndef __HV_CTRL_API__
#define __HV_CTRL_API__

/**
 * \defgroup hv_ctrl_api ASIC2 HV Modules and HV_CTRL API functions
 * 
 * \ingroup  hv_ctrl   asic2_api
 *
 * \brief    API function to control HV Modules and HV_CTRL
 *
 */

#include "errors_api.h"
#include "hv_ctrl.h" // include HAL
//#include "hv_ctrl_bf.h"
//#include "hv_ir_bf.h"

/* ############################################################################ */
/**
 * \brief Enumeration which describes the different registers in HV CTRL
 *
 * \ingroup hv_ctrl_api 
 */
typedef enum{
  IR_PWR_CONFIG = ADDR_HV_IR_IR_PWR_CONFIG,
  IR_GPO5V = ADDR_HV_IR_IR_GPO5V,
  IR_HVHKMUX = ADDR_HV_IR_IR_HVHKMUX,
  IR_ISINK0 = ADDR_HV_IR_IR_ISINK0,
  IR_ISINK1 = ADDR_HV_IR_IR_ISINK1,
  IR_ISINK2 = ADDR_HV_IR_IR_ISINK2,
  IR_RS485_CONFIG = ADDR_HV_IR_IR_RS485_CONFIG,
  IR_SELOUT = ADDR_HV_IR_IR_SELOUT,
  IR_SELIN_CONFIG = ADDR_HV_IR_IR_SELIN_CONFIG,
  IR_SELIO_STATUS = ADDR_HV_IR_IR_SELIO_STATUS,
  IR_STATUS = ADDR_HV_IR_IR_STATUS,
  IR_MASK = ADDR_HV_IR_IR_MASK,
  IR_CLEAR_RESET_FLAG = ADDR_HV_IR_IR_CLEAR_RESET_FLAG,
  IR_VERSION = ADDR_HV_IR_IR_VERSION,
  IR_CAL0 = ADDR_HV_IR_IR_CAL0,
  IR_CAL1 = ADDR_HV_IR_IR_CAL1,
  IR_CAL2 = ADDR_HV_IR_IR_CAL2,
  IR_CAL0_CLR = ADDR_HV_IR_IR_CAL0_CLR,
  IR_CAL1_CLR = ADDR_HV_IR_IR_CAL1_CLR,
  IR_CAL2_CLR = ADDR_HV_IR_IR_CAL2_CLR,
  IR_CAL0_SET = ADDR_HV_IR_IR_CAL0_SET,
  IR_CAL1_SET = ADDR_HV_IR_IR_CAL1_SET,
  IR_CAL2_SET = ADDR_HV_IR_IR_CAL2_SET,
  IR_PASS = ADDR_HV_IR_IR_PASS,
  IR_TMR0 = ADDR_HV_IR_IR_TMR0,
  IR_TMR1 = ADDR_HV_IR_IR_TMR1,
  IR_TMR_ONE_GPO = ADDR_HV_IR_IR_TMR_ONE_GPO,
  IR_TMR_ONE_RX = ADDR_HV_IR_IR_TMR_ONE_RX
} hv_ctrl_api_register_e;

/* ############################################################################ */
/**
 * \brief  Get the hv ctrl register value
 *         This function returns the value of the selected hv control register
 *
 * \ingroup hv_ctrl_api 
 *
 * \param hv_ctrl_api_register_e Select the register
 * \return Value of the corresponding register
 */
uint16_t hv_ctrl_api_get_register(hv_ctrl_api_register_e hv_register);

/* ############################################################################ */
/**
 * \brief  Set the hv ctrl register value
 *         This function writes the desired value into the selected hv control register
 *
 * \ingroup hv_ctrl_api 
 *
 * \param hv_ctrl_api_register_e Select the register
 * \param data Value to write in the corresponding register
 */
void hv_ctrl_api_set_register(hv_ctrl_api_register_e hv_register, uint16_t data);

/* ############################################################################ */
/**
 * \brief  Initializes communication with HV die registers
 *
 * \ingroup hv_ctrl_api
 */
void hv_ctrl_api_init();

/* ############################################################################ */
/**
 * \brief Set current to specific channel (set only changes)
 *
 * \ingroup hv_ctrl_api
 */
bool hv_ctrl_api_set_isink(uint8_t no, uint8_t val);

/* ############################################################################ */
/**
 * \brief  Enable RS-485 
 *
 * \ingroup hv_ctrl_api
 *
 * \param bSlewEnable Slewrate is in active
 */
void hv_ctrl_api_rs485_enable(bool bSlewEnable);


#endif