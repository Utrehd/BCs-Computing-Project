#include "aout_ctrl.h"
#include "aout_ctrl_api.h"
#include "calibration.h"
#include "./../bugs.h"

static uint16_t aout_ctrl_api_offset[2];
static uint16_t aout_ctrl_api_gain[2];


void aout_ctrl_api_init(aout_ctrl_dac_sel_t par_dac_sel, aout_ctrl_cfg_t par_cfg) {

  set_aout_ctrl_cfg(par_dac_sel, par_cfg);

  aout_ctrl_api_offset[par_dac_sel] = calibration_get_aout_offset(par_dac_sel);
  aout_ctrl_api_gain[par_dac_sel]   = calibration_get_aout_gain(par_dac_sel);  
  
}

void aout_ctrl_api_set_value(aout_ctrl_dac_sel_t dac_sel, uint16_t par_value_in_0p1mV) {
  
  /*
   * the formula below converts a desired voltage into the register
   * value for each aout register:
   * x[LSB] = u[mV/10] * gain_flash[LSB/(mV/10)] / (1<<13) + offset_flash[LSB] / (1<<1)
  */
  
  uint32_t i_reg_value;
  i_reg_value = (par_value_in_0p1mV * aout_ctrl_api_gain[dac_sel]);
  i_reg_value = i_reg_value / (1<<13);
  i_reg_value = i_reg_value + aout_ctrl_api_offset[dac_sel]/(1<<1);
  set_aout_ctrl_dac(dac_sel, i_reg_value);
}

void set_aout_api_ctrl_dac_sync(aout_ctrl_dac_sel_t dac_sel, uint16_t par_value_in_0p1mV) {
  
  /*
   * the formula below converts a desired voltage into the register
   * value for each aout register:
   * x[LSB] = u[mV/10] * gain_flash[LSB/(mV/10)] / (1<<13) + offset_flash[LSB] / (1<<1)
  */
  
  uint32_t i_reg_value;
  i_reg_value = (par_value_in_0p1mV * aout_ctrl_api_gain[dac_sel]);
  i_reg_value = i_reg_value / (1<<13);
  i_reg_value = i_reg_value + aout_ctrl_api_offset[dac_sel]/(1<<1);
  set_aout_ctrl_dac_sync(dac_sel, i_reg_value);
}