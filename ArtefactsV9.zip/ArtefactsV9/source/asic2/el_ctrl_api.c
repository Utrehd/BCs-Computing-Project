#include "hardware.h"
#include "el_ctrl_api.h"
#include "hv_ctrl.h"
#include "clk_nres_api.h"
#include "io_ctrl_api.h"

/* ############################################################################ */

void el_ctrl_api_config_hv(void){
  hv_ctrl_cfg_timing(3);
  hv_ctrl_set_nres(true);
  hv_ctrl_pwr_config(
    true,                         //bool                      vreg_vdd5tx_npd
    true,                         //bool                      pw_vdd5tx_npd
    VREG_VDD3V3_3V3,              //vreg_vdd3v3_max_t         vreg_vdd3v3_max
    PW_VPOW_RANGE_4_16,           //pw_vpow_range_t           pw_vpow_range
    5);                           //uint8_t                   pw_vpow_hyst
  hv_ctrl_cfg_phy(
    true,                         //bool                      hrx485_npd
    true,                         //bool                      htx485_npd
    false,                        //bool                      htx485_slew_enable
    HTX485_BREAK_BEFORE_MAKE,     //htx485_bbm_fast_t         htx485_bbm_fast
    HTX485_IGNORE_TEMP_ERROR,     //htx485_auto_shutdown_t    htx485_auto_shutdown
    HTX485_TEMPSENSE_OFF,         //htx485_tempsens_enable_t  htx485_tempsens_enable
    HTX485_TEMPSENSE_NO_ERRORS);  //htx485_tempsens_mask_t    htx485_tempsens_mask
}

/* ############################################################################ */
    
void el_ctrl_api_config_node(uint32_t baudrate){
  
  uint32_t system_clock;
  if(clk_nres_api_get_system_clock(&system_clock)!=eError_none) {
    while(1); /* Error */
  }

  uint32_t  full_bit_length = system_clock / baudrate;
  uint32_t  half_bit_length    = full_bit_length / 2;
  uint8_t   tx_preamble_len    = 8;
  uint16_t  meas_intf_rise     = 600;
  uint8_t   rx_intf_threshold  = 2;

  printf("-config EL (Node)\n");
  // HV
  hv_ctrl_set_gpo_el_req_enable(true);
  // MEAS
  el_ctrl_meas_enable(true);
  el_ctrl_set_meas_intf_rise_fall(meas_intf_rise, meas_intf_rise >> 3);  // rise : fall = 1 : 8
  el_ctrl_set_meas_zero_level(false);
  // RX
  el_ctrl_set_rx_intf_threshold(rx_intf_threshold);
  el_ctrl_set_rx_bit_length(full_bit_length);
  el_ctrl_set_rx_min_preamble_length(tx_preamble_len-3);
  el_ctrl_set_rx_zero_level(false);
  el_ctrl_rx_enable(true);
  // TX
  el_ctrl_set_tx_half_bit_length(half_bit_length);
  el_ctrl_set_tx_preamble_length(tx_preamble_len);
  el_ctrl_set_tx_always_pre(false);
  // CYC
  el_ctrl_cyc_enable(true);
  el_ctrl_set_cyc_len(0x64);
  el_ctrl_set_cyc_tx_start(el_ctrl_get_cyc_len() >> 3); //>>3
  el_ctrl_set_cyc_tx_start(0x1A);
}
   
/* ############################################################################ */
    
void el_ctrl_api_pinout(void){
  
  wdog_enable(GUARD0);
  wdog_unlock_guard(GUARD0);
  io_ctrl_guard_unlock();

    /* Dedicated pin (ELRX) */
    io_ctrl_config_el_ctrl_tia(true);           /* External TIA is used */
    io_ctrl_config_el_rx_ds(true);              /* Drive Strength needed for external LED */

  io_ctrl_guard_lock();
  wdog_disable (GUARD0); // GUARD disable
  while (wdog_is_running (GUARD0)) ;

}

/* ############################################################################ */

void el_ctrl_api_setting_node_hcs_comm(uint8_t tx_max_bytes){
  el_ctrl_tia_config(true, 0x2);                                     // Enable hysteresis. See electrical parameters.
  el_ctrl_set_tx_max_bytes(tx_max_bytes);                             // Maximum length of tx phase in bytes
  el_ctrl_set_tx_led_on_pattern(0xFE);                                // During the �LED on� phase led_on is transmitted. Each bit is transmitted for the duration of half a bit period. Has to be different than 0xFF or 0.
  el_ctrl_tx_pat_enable(true);                                        // Send led_on pattern during tx pat until end of cycle
  el_ctrl_set_tx_always_pre(true);                                    // Always send tx pre and tx pst
  el_ctrl_set_tx_trigger(EL_CTRL_TRIGGER_CYC_TX_START);               // When CYC_TX_START occurs
  el_ctrl_set_tx_gpo_ignore(false);                                   // tx2rx and rx2tx states switch GPO and wait until gpo_now is equal to gpo_val
  el_ctrl_cyc_enable(true);                                           // CYC counter enabled
  el_ctrl_set_rx_intf_threshold(0x3F);                                // Threshold of integration filter
}

/* ############################################################################ */

void el_ctrl_api_setting_node_fcs_comm(uint8_t  tx_max_bytes){
  el_ctrl_tia_config(true, 0x2);                                     // Enable hysteresis. See electrical parameters.
  el_ctrl_set_tx_max_bytes(0);                                        // Sent data until TX FIFO is empty
  el_ctrl_set_tx_led_on_pattern(0xAA);                                // During the �LED on� phase led_on is transmitted. Each bit is transmitted for the duration of half a bit period. Has to be different than 0xFF or 0.
  el_ctrl_tx_pat_enable(false);                                       // tx pat disabled (will directly go to tx2rx phase)
  el_ctrl_set_tx_always_pre(false);                                   // Go from rx2tx to tx pat when tx_empty
  el_ctrl_set_tx_trigger(EL_CTRL_TRIGGER_IMMEDIATELY);                // Immediately
  el_ctrl_set_tx_gpo_ignore(false);                                   // tx2rx and rx2tx states switch GPO and wait until gpo_now is equal to gpo_val
  el_ctrl_cyc_enable(false);                                          // CYC counter stopped and cleared
  el_ctrl_set_rx_intf_threshold(0x3F);                                // Threshold of integration filter
}

/* ############################################################################ */

errors_api_code_e el_ctrl_api_recv_byte(uint8_t *recv_byte){
  
  uint16_t cycle_cnt = 0;
  bool timeout = false;
  
  /* Wait for the received data (with timeout) */
  while(el_ctrl_rx_fifo_empty() && !timeout){ 
    if (cycle_cnt == 3000){
      timeout = true;
      return eError_el_ctrl_api_no_recv_byte;
    }
  cycle_cnt++;
  }

  *recv_byte = el_ctrl_recv_byte(); /* received data */
  
  return eError_none;
}

/* ############################################################################ */

void el_ctrl_api_send_byte(uint8_t send_byte){
  el_ctrl_send_byte(send_byte);
}