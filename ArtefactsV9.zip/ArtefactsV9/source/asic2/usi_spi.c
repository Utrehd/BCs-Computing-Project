/* FPGA Release: 10512 */
#include "usi_spi.h"
#include "sram.h"
#include "stdio.h"

#define USI_SPI_MAX_DMA_WORDS 10

typedef struct {
  volatile usi_dma_rxcfg_t rx_config;
  volatile usi_dma_txcfg_t tx_config;
  volatile uint16_t rx_buffer[USI_SPI_MAX_DMA_WORDS];
  volatile uint16_t tx_buffer[USI_SPI_MAX_DMA_WORDS];
  uint16_t rx_ptr;
  uint16_t rx_len;
  uint8_t cfg_slave_nmaster;
  uint8_t cfg_word_mode;
  uint8_t tx_byte_sel;
  uint8_t rx_byte_sel;
} usi_spi_struct_t;

static usi_spi_struct_t usi_spi_struct[NUMBER_USI];


void usi_spi_init(usi_num_t usi_no, bool slave_nmaster){
  uint8_t index = usi_no_to_index(usi_no);
  usi_clear_revents(usi_no);
  usi_spi_struct[index].tx_config.tcfg = 0;
  usi_spi_struct[index].tx_config.tdlen = 0;
  usi_spi_struct[index].rx_config.maxlen = USI_SPI_MAX_DMA_WORDS;
  usi_spi_struct[index].tx_byte_sel = 0;
  usi_spi_struct[index].rx_ptr = 0;
  usi_spi_struct[index].rx_len = 0;
 
  usi_spi_struct[index].rx_config.rdadr = (uint16_t)((uint32_t)&(usi_spi_struct[index].rx_buffer[0]));
  //printf("\r\nrx data:@0x%X conf:@0x%X ccpu\r\n",  usi_spi_struct[index].rx_config.rdadr, (uint16_t) &(usi_spi_struct[index].rx_config));
  usi_spi_struct[index].tx_config.tdadr = (uint16_t)((uint32_t)&(usi_spi_struct[index].tx_buffer[0]));
  //printf("tx data:@0x%X conf:@0x%X ccpu\r\n", usi_spi_struct[index].tx_config.tdadr, (uint16_t) &(usi_spi_struct[index].tx_config));
  if (slave_nmaster){
    usi_spi_cfg_tx_dma_mode(usi_no, (bool)USI_DMA_MODE_TRANSFER);
    usi_spi_cfg_rx_dma_mode(usi_no, (bool)USI_DMA_MODE_TRANSFER); 
  } else {
    usi_spi_cfg_tx_dma_mode(usi_no, (bool)USI_DMA_MODE_LENGTH);
    usi_spi_cfg_rx_dma_mode(usi_no, (bool)USI_DMA_MODE_LENGTH);
    usi_spi_set_cfg_early_sdo(usi_no, 0); 
  }
}

//=======================================================================
// config
//=======================================================================
void usi_spi_cfg_phase(usi_num_t usi_no, bool phase){
  usi_cfg_spi_bl_t usi_cfg_spi_bl;
  usi_cfg_spi_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_BL);
  usi_cfg_spi_bl.bf.phase = phase;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_BL, usi_cfg_spi_bl.val);
}

void usi_spi_cfg_polarity(usi_num_t usi_no, bool polarity){
  usi_cfg_spi_bl_t usi_cfg_spi_bl;
  usi_cfg_spi_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_BL);
  usi_cfg_spi_bl.bf.polarity = polarity;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_BL, usi_cfg_spi_bl.val);
}

void usi_spi_cfg_msb_first(usi_num_t usi_no, bool msb_first){
  usi_cfg_spi_bl_t usi_cfg_spi_bl;
  usi_cfg_spi_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_BL);
  usi_cfg_spi_bl.bf.msb_first = msb_first;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_BL, usi_cfg_spi_bl.val);
}

void usi_spi_cfg_data_bits(usi_num_t usi_no, usi_spi_data_len_t data_bits){
  uint8_t index = usi_no_to_index(usi_no);
  usi_spi_struct[index].cfg_word_mode = (data_bits > USI_SPI_DATA_LEN_8) ? 1 : 0;
  usi_cfg_spi_bl_t usi_cfg_spi_bl;
  usi_cfg_spi_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_BL);
  usi_cfg_spi_bl.bf.data_bits = data_bits;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_BL, usi_cfg_spi_bl.val);
}

void usi_spi_cfg_slave_nmaster(usi_num_t usi_no, bool slave_nmaster){
  uint8_t index = usi_no_to_index(usi_no);
  usi_spi_struct[index].cfg_slave_nmaster = slave_nmaster;
  usi_cfg_spi_bl_t usi_cfg_spi_bl;
  usi_cfg_spi_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_BL);
  usi_cfg_spi_bl.bf.slave = slave_nmaster;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_BL, usi_cfg_spi_bl.val);
}

void usi_spi_cfg_nss_mode(usi_num_t usi_no, usi_spi_nss_mode_t nss_mode){
  usi_cfg_spi_bl_t usi_cfg_spi_bl;
  usi_cfg_spi_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_BL);
  usi_cfg_spi_bl.bf.nss_mode = nss_mode;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_BL, usi_cfg_spi_bl.val);
}

void usi_spi_cfg_sdo_high_z(usi_num_t usi_no, bool sdo_high_z){
  usi_cfg_spi_bl_t usi_cfg_spi_bl;
  usi_cfg_spi_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_BL);
  usi_cfg_spi_bl.bf.sdo_high_z = sdo_high_z;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_BL, usi_cfg_spi_bl.val);
}

void usi_spi_cfg_sdi_irq_pol(usi_num_t usi_no, bool sdi_irq_pol){
  usi_cfg_spi_bl_t usi_cfg_spi_bl;
  usi_cfg_spi_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_BL);
  usi_cfg_spi_bl.bf.sdi_irq_pol = sdi_irq_pol;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_BL, usi_cfg_spi_bl.val);
}

void usi_spi_cfg_sck_timeout(usi_num_t usi_no, uint8_t sck_timeout){
  usi_cfg_spi_sck_timeout_t usi_cfg_spi_sck_timeout;
  usi_cfg_spi_sck_timeout.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_SCK_TIMEOUT);
  usi_cfg_spi_sck_timeout.bf.sck_timeout = sck_timeout;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_SCK_TIMEOUT, usi_cfg_spi_sck_timeout.val);
}

void usi_spi_cfg_sck_timeout_bitlength_sel(usi_num_t usi_no, usi_spi_sck_timeout_sel_t bitlength_sel){
  usi_cfg_spi_sck_timeout_t usi_cfg_spi_sck_timeout;
  usi_cfg_spi_sck_timeout.val = READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_SCK_TIMEOUT);
  usi_cfg_spi_sck_timeout.bf.bitlength_sel = bitlength_sel;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_SCK_TIMEOUT, usi_cfg_spi_sck_timeout.val);
}

void usi_spi_set_cfg_early_sdo(usi_num_t usi_no, uint8_t phase){
  WRITE_REG_16(usi_no + ADDR_USI_CFG_SPI_EARLY_SDO, phase);
}

uint8_t usi_spi_get_cfg_early_sdo(usi_num_t usi_no){
  return READ_REG_U16(usi_no + ADDR_USI_CFG_SPI_EARLY_SDO);
}

//=======================================================================
// status
//=======================================================================
bool usi_spi_is_word_mode(usi_num_t usi_no){
  uint8_t index = usi_no_to_index(usi_no);
  return usi_spi_struct[index].cfg_word_mode ? true : false;
}

//=======================================================================
// simple usage DMA wrapper
//=======================================================================
void usi_spi_prepare_recv_dma(usi_num_t usi_no){
  uint8_t index = usi_no_to_index(usi_no);
  while (usi_dma_provide_rxcfg(usi_no, &(usi_spi_struct[index].rx_config), false) && usi_spi_struct[index].cfg_slave_nmaster);
}

void usi_spi_immediate_transfer(usi_num_t usi_no){
  uint8_t index = usi_no_to_index(usi_no);
  //usi_dma_prepare_txcfg(usi_no, usi_spi_struct[index].tx_ptr, (void*)&(usi_spi_struct[index].tx_buffer), 0);
  usi_spi_struct[index].tx_config.tdadr = POINTER_TO_ADDRESS(usi_spi_struct[index].tx_buffer);
  if (!usi_spi_struct[index].cfg_slave_nmaster){
    //usi_dma_prepare_rxcfg(usi_no, usi_spi_struct[index].tx_ptr, (void*)&(usi_spi_struct[index].rx_buffer), false);
    usi_spi_struct[index].rx_config.maxlen = usi_spi_struct[index].tx_config.tdlen;
    //printf("usi_spi_immediate_transfer rx_len %d\r\n", usi_spi_struct[index].rx_config.maxlen);
    usi_spi_prepare_recv_dma(usi_no);
  }
  //printf("usi_dma_send_frame tx_len=%d data=0x%04x 0x%04x 0x%04x\r\n", usi_spi_struct[index].tx_config.tdlen, usi_spi_struct[index].tx_buffer[0], usi_spi_struct[index].tx_buffer[1], usi_spi_struct[index].tx_buffer[2]);
  usi_dma_send_frame(usi_no, false, &(usi_spi_struct[index].tx_config));
}

void usi_spi_transmit_data(usi_num_t usi_no, uint16_t data, bool keep_nss) {
  uint8_t index = usi_no_to_index(usi_no);
  uint8_t bytepos = usi_spi_struct[index].tx_config.tdlen;
  //printf("TX 0x%04x\r\n", data);
  if (usi_spi_is_word_mode(usi_no)) {
    usi_spi_struct[index].tx_buffer[bytepos] = data;
  } else {
    bytepos >>= 1;
    if (usi_spi_struct[index].tx_byte_sel) {
      usi_spi_struct[index].tx_buffer[bytepos] |= ((uint16_t) data) << 8;
      usi_spi_struct[index].tx_byte_sel = 0;
    } else {
      usi_spi_struct[index].tx_buffer[bytepos] = data;
      usi_spi_struct[index].tx_byte_sel = 1;
    }
  }
  usi_spi_struct[index].tx_config.tdlen++;
  
  if (!keep_nss || (usi_spi_struct[index].tx_config.tdlen == (USI_SPI_MAX_DMA_WORDS-1))){
    usi_spi_immediate_transfer(usi_no);
    usi_spi_struct[index].tx_config.tdlen = 0;
    usi_spi_struct[index].tx_byte_sel = 0;
  }
}

bool usi_spi_receive_data(usi_num_t usi_no, uint16_t *data) {
  uint8_t index = usi_no_to_index(usi_no);
  uint16_t * data_ptr;
  
  //printf("PRE  rx_ptr=%d rx_len=%d\r\n", usi_spi_struct[index].rx_ptr, usi_spi_struct[index].rx_len);
  if (usi_spi_struct[index].rx_ptr == usi_spi_struct[index].rx_len){
    if (!usi_dma_get_rx_data(usi_no, (void*)&data_ptr, &usi_spi_struct[index].rx_len)){
      return false;
    }
    //printf("<- RX len=%d data_ptr=0x%04x @0x%X\r\n", usi_spi_struct[index].rx_len, *data_ptr, data_ptr);
    usi_spi_struct[index].rx_ptr = 0;
    usi_spi_struct[index].rx_byte_sel = 0;
    if (usi_spi_struct[index].cfg_slave_nmaster){
      usi_spi_prepare_recv_dma(usi_no);
    }
  }
  if (usi_spi_struct[index].rx_ptr < usi_spi_struct[index].rx_len){
    uint16_t temp = 0;
    if (usi_spi_is_word_mode(usi_no)) {
      temp = usi_spi_struct[index].rx_buffer[usi_spi_struct[index].rx_ptr];
    } else if (usi_spi_struct[index].rx_byte_sel) {
      temp = (usi_spi_struct[index].rx_buffer[usi_spi_struct[index].rx_ptr >> 1] >> 8) & 0xFF;
    } else {
      temp = (usi_spi_struct[index].rx_buffer[usi_spi_struct[index].rx_ptr >> 1]) & 0xFF;
    }
    *data = temp;
    usi_spi_struct[index].rx_byte_sel = usi_spi_struct[index].rx_byte_sel ? 0 : 1;
    usi_spi_struct[index].rx_ptr++;   
    //printf("rx_ptr=%d rx_len=%d\r\n", usi_spi_struct[index].rx_ptr, usi_spi_struct[index].rx_len);
    return true;
  }
  //printf("POST rx_ptr=%d rx_len=%d\r\n", usi_spi_struct[index].rx_ptr, usi_spi_struct[index].rx_len);
  return false;
}

uint16_t usi_spi_transceive_frame(usi_num_t usi_no, void * tdata, void * rdata, uint16_t rx_maxlen, uint16_t tx_len, bool keep_nss, bool sdo_oe_ctrl) {
  usi_dma_rxcfg_t usi_dma_rxcfg;
  usi_dma_prepare_rxcfg(rx_maxlen, rdata, &usi_dma_rxcfg);

  usi_dma_txcfg_t usi_dma_txcfg;
  uint8_t tcfg = 0;
  tcfg += keep_nss     ? BIT_USI_DMA_TCFG_SPI_KEEP_NSS    : 0;
  tcfg += sdo_oe_ctrl  ? BIT_USI_DMA_TCFG_SPI_SDO_OE_CTRL : 0;
  usi_dma_prepare_txcfg(tx_len, tdata, tcfg, &usi_dma_txcfg);
  
  while(!usi_dma_provide_rxcfg(usi_no, &usi_dma_rxcfg, false));
  usi_dma_send_frame(usi_no, false, &usi_dma_txcfg);
  
  void *ptr;
  uint16_t rdlen;
        
  while(!usi_dma_get_rx_data(usi_no, &ptr, &rdlen));
  usi_dma_get_tadr_done(usi_no);  // dummy get
  return rdlen;
}
