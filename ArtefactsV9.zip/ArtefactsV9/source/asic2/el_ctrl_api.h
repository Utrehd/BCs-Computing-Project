/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2018 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         el_ctrl_api.h
*
* @brief        EL_CTRL API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __EL_CTRL_API__
#define __EL_CTRL_API__

/**
 * \defgroup el_ctrl_api ASIC2 Electronic label API functions
 * 
 * \ingroup  el_ctrl   asic2_api
 *
 * \brief    API function to control CLK_NRES
 *
 */
 
#include "errors_api.h"

/* ############################################################################ */
/**
 * \brief Function  to set the correct HV configuration for Electronic Label
 *
 * \ingroup el_ctrl_api 
 */
void el_ctrl_api_config_hv(void);

/* ############################################################################ */
/**
 * \brief Function to set the correct Electronic Label configuration with a desired baudrate
 *
 * \ingroup el_ctrl_api 
 * 
 * \param baudrate   Desired baudrate
 */
void el_ctrl_api_config_node(uint32_t baudrate);

/* ############################################################################ */
/**
 * \brief Function to set the specific pinout (ELRX) for Electronic Label
 *
 * \ingroup el_ctrl_api 
 */
void el_ctrl_api_pinout(void);

/* ############################################################################ */
/**
 * \brief Function to set the Electronic Label as a node with Hiddem Communication Schedule
 *
 * \ingroup el_ctrl_api 
 * 
 * \param tx_max_bytes   Maximum transmission bytes
 */
void el_ctrl_api_setting_node_hcs_comm(uint8_t tx_max_bytes);

/* ############################################################################ */
/**
 * \brief Function to set the Electronic Label as a node with Full Communication Schedule
 *
 * \ingroup el_ctrl_api 
 * 
 * \param tx_max_bytes   Maximum transmission bytes
 */
void el_ctrl_api_setting_node_fcs_comm(uint8_t tx_max_bytes);

/* ############################################################################ */
/**
 * \brief Function to receive byte in Electronic Label
 *
 * \ingroup el_ctrl_api 
 * 
 * \param recv_byte   Byte received
 *
 * \return Error code
 */
errors_api_code_e el_ctrl_api_recv_byte(uint8_t *recv_byte);

/* ############################################################################ */
/**
 * \brief Function to send byte in Electronic Label
 *
 * \ingroup el_ctrl_api 
 * 
 * \param send_byte   Byte to send
 */
void el_ctrl_api_send_byte(uint8_t send_byte);

#endif