

#include <application_config.h>
#include <string.h>
#include <hardware.h>

extern const application_config_t application_config;



const application_config_t * system_config_application_config_get(void) {
  return(&application_config);
}

void system_config_init( void )
{
  asic2_clock_t asic2_clock_empty;
  volatile uint16_t delay = 5000;       // 1300 loops = ~1ms at 32MHz
   
  memset(&asic2_clock_empty, 0xff , sizeof(asic2_clock_t));
  if ((memcmp(&asic2_clock_empty, &application_config.asic2_clock,  sizeof(asic2_clock_t)) == 0) || (application_config.struct_version_tag != 2)){
    clk_nres_wake_cpu1();
    while (1){
      asm("nop");
    }
  }

  //GuardEnable();
  wdog_enable(GUARD0);
  wdog_unlock_guard(GUARD0);
  clk_nres_unlock();
  
  // clk_nres_cfg_ana_osc.rcosc_hf_pd_n must be always enabled!!!!!!!
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC,        application_config.asic2_clock.clk_nres_cfg_ana_osc.val | 0x0001);
  if( !application_config.asic2_clock.clk_nres_cfg_ana_osc.bf.qosc_clk_bypass )
  {
    // quarz for internal oscillator Startup delay
    while(delay)
    { 
      delay--; 
    }
  }
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL0,       application_config.asic2_clock.clk_nres_cfg_ana_pll0.val);
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL1,       application_config.asic2_clock.clk_nres_cfg_ana_pll1.val);
  // PLL Startup delay > 1ms
  delay = 2000; // min 1.5ms at 32MHz
  while(delay)
  { 
    delay--; 
  }
  

  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS0_SWD_TSU,    application_config.asic2_clock.clk_nres_cfg_AS0_swd_tsu.val);
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS1_USI0,       application_config.asic2_clock.clk_nres_cfg_AS1_usi0.val);
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS2_USI1,       application_config.asic2_clock.clk_nres_cfg_AS2_usi1.val);
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS3_HISPI,      application_config.asic2_clock.clk_nres_cfg_AS3_hipsi.val);
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_M,              application_config.asic2_clock.clk_nres_cfg_M.val);

  
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE,           application_config.asic2_clock.clk_nres_cfg_rate.val);
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE_SEL_0,     application_config.asic2_clock.clk_nres_cfg_rate_sel_0.val);
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE_SEL_1,     application_config.asic2_clock.clk_nres_cfg_rate_sel_1.val);
  WRITE_REG_16(CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE_SEL_2,     application_config.asic2_clock.clk_nres_cfg_rate_sel_2.val);
  
  
  
  
  
  flash_ctrl_use_half_clock_speed(application_config.asic2_clock.use_flash_half_clock_speed);
  flash_ctrl_set_timings(application_config.asic2_clock.flash_timings);
  
  // domain config
  clk_nres_set_nreset(CLKPNO_SWD, false);
  clk_nres_set_nreset(CLKPNO_TSU, false);
  clk_nres_set_as_nreset(AS_SWD_TSU, false);
  clk_nres_enable_as_clock_domain(CLK_NRES_0, AS_SWD_TSU, true);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_SWD, true);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_TSU, true);
  clk_nres_set_nreset(CLKPNO_SWD, true);
  clk_nres_set_nreset(CLKPNO_TSU, true);
  clk_nres_set_as_nreset(AS_SWD_TSU, true);
  
  //also used by acpu
  //clk_nres_set_nreset(CLKPNO_GPIO, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_GPIO, true);
  clk_nres_set_nreset(CLKPNO_GPIO, true);
  
  clk_nres_set_nreset(CLKPNO_IO_CTRL, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_IO_CTRL, true);
  clk_nres_set_nreset(CLKPNO_IO_CTRL, true);

  clk_nres_set_nreset(CLKPNO_HV_CTRL, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_HV_CTRL, true);
  clk_nres_set_nreset(CLKPNO_HV_CTRL, true);

  clk_nres_set_nreset(CLKPNO_SWTIMER0, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_SWTIMER0, true);
  clk_nres_set_nreset(CLKPNO_SWTIMER0, true);

  clk_nres_set_nreset(CLKPNO_ACCESS_CONTROL, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_ACCESS_CONTROL, true);
  clk_nres_set_nreset(CLKPNO_ACCESS_CONTROL, true);

  clk_nres_set_nreset(CLKPNO_EL_CTRL, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_EL_CTRL, true);
  clk_nres_set_nreset(CLKPNO_EL_CTRL, true);

  //also used by acpu
  //clk_nres_set_nreset(CLKPNO_UART, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_UART, true);
  clk_nres_set_nreset(CLKPNO_UART, true);

  clk_nres_set_nreset(CLKPNO_CPU_N_CPU, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_CPU_N_CPU, true);
  clk_nres_set_nreset(CLKPNO_CPU_N_CPU, true);

  //peri 1 acpu
/*
  clk_nres_set_nreset(CLKPNO_SWTIMER1, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_SWTIMER1, true);
  clk_nres_set_nreset(CLKPNO_SWTIMER1, true);

  clk_nres_set_nreset(CLKPNO_USI0, false);
  clk_nres_set_as_nreset(AS_USI0, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_USI0, true);
  clk_nres_set_nreset(CLKPNO_USI0, true);

  clk_nres_set_nreset(CLKPNO_USI1, false);
  clk_nres_set_as_nreset(AS_USI1, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_USI1, true);
  clk_nres_set_nreset(CLKPNO_USI1, true);

  clk_nres_set_nreset(CLKPNO_HIAD, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_HIAD, true);
  clk_nres_set_nreset(CLKPNO_HIAD, true);

  clk_nres_set_nreset(CLKPNO_I2C, false);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_I2C, true);
  clk_nres_set_nreset(CLKPNO_I2C, true);


  clk_nres_set_nreset(CLKPNO_VIC_EXT, true);
  clk_nres_enable_clock_partition(CLK_NRES_0, CLKPNO_VIC_EXT, true);
  clk_nres_set_nreset(CLKPNO_VIC_EXT, true);
  */
  
  /* 
   * WDOG1 can reset ACPU 
   * see utils_reset_exec() in utils.c
   */
  clk_nres_enable_wdog1_global_reset(true);
  
  wdog_disable(GUARD0);
  
  
  
  
  wdog_unlock_guard(GUARD0);
  io_ctrl_guard_unlock();
    
  io_ctrl_config_jtag_dio(application_config.jtag_dio);
  
  io_ctrl_guard_lock();
  wdog_disable(GUARD0);
  
  
  
  
  
}