/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hv_ctrl_api.h
*
* @brief        HV_CTRL API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

/**
* \file 
*
* \brief  RS485 API functions (RS485 HV die to USI.UART)
*
* \author Eaton European Innovation Center 
*
* \version ASIC2 Specification (Revision 2.9.3)
*/




/** 
 *  \defgroup rs_485_api API to control RS485 driver (internal/external) by USI.UART
 *
 *  \ingroup  usi_uart_dma   asic2_api
 *
 *  \brief    API to control RS485
 *
 */
/**@{*/    

/**

\verbatim
  HOW TO USE IT:

  errors_api_code_e error_code = eError_none;
  
  // Interconnection between USI.UART and RS485 (internal)
  error_code |= rs485_api_int_phy_init_pad(USI0, HV_TXEN,USI0_TXEN, HV_TX,USI0_TX, HV_RX,USI0_RX);  
  
  // baudrate = 16MHz / 139 = 115384 bps = ~115200
  error_code |= rs485_api_usi_uart_clock_and_baudrate(CLOCK_SOURCE_RCOSC_HF,0, 1, 1, 139);
    
   
  rs485_api_usi_uart_set_parity(USI_UART_PARITY_EVEN);
  rs485_api_usi_uart_set_stopbit(USI_UART_ONE_STOP);
  rs485_api_usi_uart_init();

  // where to save received data 
  rs485_api_data_recv(1,  (uint8_t *)g_data_rx);

  // call back functions
  rs485_api_reg_callback(7, uart_rx_done, uart_error);

  // send data
  rs485_api_data_send(5, (uint8_t *)g_data)

\endverbatim
  *
  */

#ifndef __RS485_API__
#define __RS485_API__

#include "ASIC2_pinout.h"
#include "errors_api.h"
#include "usi.h"
#include "usi_uart.h"
#include "clk_nres.h"

/* ############################################################################ */
/**
 * \brief  Init RS-485 
 *         To define USI.UART interface to connect to external RS-485 phy
 *
 * \ingroup rs_485_api
 *
 * \param USI UART instance
 * 
 * \param pinout_usi_txen UART pin (LV die)
 *
 * \param pinout_usi_tx UART pin (LV die)
 *
 * \param pinout_usi_rx UART pin (LV die)
 *
    +--------------------------------------------------+
    |                                                  |
    |                           +--------------------+ |
    |       +-------------------> pinout_usi_txen    +---->
    |       |                   +--------------------+ |
    |       |                                          |
    |     +-+------+            +--------------------+ |
    |     |USI UART+------------> pinout_usi_tx      +-----
    |     +-+------+            +--------------------+ |
    |       |                                          |
    |       |                   +--------------------+ |
    |       +-------------------> pinout_usi_rx      <-----
    |                           +--------------------+ |
    |                                                  |
    +--------------------------------------------------+
\endverbatim
 */
errors_api_code_e rs485_api_ext_phy_init_pad(
                    const usi_num_t usi_no,
                    device_pinout pinout_usi_txen,
                    device_pinout pinout_usi_tx,
                    device_pinout pinout_usi_rx);
                      
/* ############################################################################ */
/**
 * \brief  Init RS-485 
 *         To define interconnection between internal ASIC2 phy and internal USI.UART
 *
 * \ingroup rs_485_api
 *
 * \param USI UART instance
 * 
 * \param pinout_hv_rs485_txen RS485 PHY pin (HV die)
 *
 * \param pinout_usi_txen UART pin (LV die)
 *
 * \param pinout_hv_rs485_tx RS485 PHY pin (HV die)
 *
 * \param pinout_usi_tx UART pin (LV die)
 *
 * \param pinout_hv_rs485_rx RS485 PHY pin (HV die)
 *
 * \param pinout_usi_rx UART pin (LV die)
 *
\verbatim
    +--------------------------------------------------+
    |                                                  |
    +--------------+            +--------------------+ |
    | PhyA||       <------------+pinout_hv_rs485_txen<-----+
    +------+       |            +--------------------+ |   |
    |      | RS485 <------+                            |   |
    +------+       |      |     +--------------------+ |   |
    | PhyB||       <---+  +-----+ pinout_hv_rs485_tx <-------+
    +--------------+   |        +--------------------+ |   | |
    |                  |                               |   | |
    |                  |        +--------------------+ |   | |
    |                  +--------+ pinout_hv_rs485_rx +---------+
    |                           +--------------------+ |   | | |
    |                                                  |   | | |
    |                           +--------------------+ |   | | |
    |       +-------------------> pinout_usi_txen    +-----+ | |
    |       |                   +--------------------+ |     | |
    |       |                                          |     | |
    |     +-+------+            +--------------------+ |     | |
    |     |USI UART+------------> pinout_usi_tx      +-------+ |
    |     +-+------+            +--------------------+ |       |
    |       |                                          |       |
    |       |                   +--------------------+ |       |
    |       +-------------------> pinout_usi_rx      <---------+
    |                           +--------------------+ |
    |                                                  |
    +--------------------------------------------------+
\endverbatim
 */
errors_api_code_e rs485_api_int_phy_init_pad(
                    const usi_num_t usi_no,
                    device_pinout pinout_hv_rs485_txen, device_pinout pinout_usi_txen,
                    device_pinout pinout_hv_rs485_tx,   device_pinout pinout_usi_tx,
                    device_pinout pinout_hv_rs485_rx,   device_pinout pinout_usi_rx);

                    
                    
                    
                    

/* ########################################################################## */  
/**
 * Function to preset data order for USI UART to control RS485
 *
 * \ingroup rs_485_api
 *
 * \param par_msb_first   TRUE - MSB goes first <br>
 *                        FALSE - LSB goes first 
 *
 */
void rs485_api_usi_uart_set_msb_first(usi_uart_bit_order_t par_msb_first);


/* ########################################################################## */  
/**
 * Function to preset data size for USI UART to control RS485
 *
 * \ingroup rs_485_api
 *
 * 
 * \param par_data_bits   number of data bits <br>
 *                        0: 8 data bits <br>
 *                        1: 7 data bits <br>
 *
 */
void rs485_api_usi_uart_set_data_bits(usi_uart_data_len_t par_data_bits);

/* ########################################################################## */  
/**
 * Function to preset parity type for USI UART to control RS485
 *
 * \ingroup rs_485_api
 *
 * \param par_par_type    type of parity bit <br>
 *                        0: no parity bit
 *                        1: odd parity bit
 *                        2: even parity bit
 *
 */
void rs485_api_usi_uart_set_parity(usi_uart_parity_t par_par_type);

/* ########################################################################## */  
/**
 * Function to preset parity type for USI UART to control RS485
 *
 * \ingroup rs_485_api
 *
 * \param par_stop_bits   number of stop bits for transmit <br>
 *                        0: one stop bit
 *                        1: two stop bits 
 *
 */
void rs485_api_usi_uart_set_stopbit(usi_uart_stop_bit_t par_stop_bits);



/* ########################################################################## */  
/**
 * Function to preset rx_timeout for USI UART to control RS485
 *
 * \ingroup rs_485_api
 *
 * \param par_rx_timeout  
 *
 */
void rs485_api_usi_uart_set_rx_timeout(uint32_t par_rx_timeout);



/* ########################################################################## */  
/**
 * Function to preset baudrate for USI UART to control RS485
 *
 * \ingroup rs_485_api
 *
 * \param par_clock_source
 *
 * \param par_as_clk_div
 *
 * \param par_br_mod
 *
 * \param par_br_inc
 *
 * \param par_bit_length
 *
 */
errors_api_code_e rs485_api_usi_uart_clock_and_baudrate(clock_source_t par_clock_source, uint8_t par_as_clk_div, uint16_t par_br_mod, uint16_t par_br_inc, uint16_t par_bit_length);

/* ########################################################################## */  
/**
 * Function to turn on automatic baudrate detection
 *
 * \ingroup rs_485_api
 *
 * \param eMode bit rate extraction mode
 *
 * \see usi_set_bre_mode()
 */
void rs485_api_usi_uart_autobaudrate_set(usi_bre_mode_t eMode);

/* ########################################################################## */  
/**
 * Get detected baudrate
 *
 * \ingroup rs_485_api
 *
 * \param p_baudrate pointer to measured baudrate
 *
 * \return new baudrate was detected
 */
bool rs485_api_usi_uart_autobaudrate_get(uint32_t *p_baudrate);

  
/* ########################################################################## */  
/**
 * Function to setup USI UART to control RS485
 *
 * \ingroup rs_485_api
 *
 */
void rs485_api_usi_uart_init(void);


/* ########################################################################## */  
/**
 * Prepare data to be sent
 *
 * \ingroup rs_485_api
 *
 * \param par_number_of_data 1..255
 *
 * \param par_p_snd_data pointer to send data
 */
errors_api_code_e rs485_api_data_send(uint8_t par_number_of_data, void * par_p_snd_data);



/* ########################################################################## */  
/**
 * Prepare data for USI/UART to be received
 *
 * \ingroup rs_485_api
 *
 * \param par_number_of_data 1..255
 *
 * \param par_p_rcv_data pointer to receive data
 */
errors_api_code_e rs485_api_data_recv(uint8_t par_number_of_data, void * par_p_rcv_data);



/* ########################################################################## */  
/**
 * Register callback functions
 *
 * \ingroup rs_485_api
 *
 * \param par_usi_nvic_priority set NVIC priority for this USI
 *
 * \param p_fce_callback_rx_done pointer to function which will be called when buffer (def. by usi_uart_dma_rx) contains received data
 *
 * \param p_fce_callback_error pointer to function which will be called when ERROR occurs
 *
 * \param p_fce_callback_tadr_new pointer to function which will be called when TADR_NEW can accept a new pointer
 *
 */
void rs485_api_reg_callback(uint8_t par_usi_nvic_priority, void (*p_fce_callback_rx_done)(void), void (*p_fce_callback_error)(void), void (*p_fce_callback_tadr_new)(void));


/* ########################################################################## */  
/**
 * Interrupt subroutine is run when RADR_DONE contains a newly completed pointer.
 *
 * \brief Enable receive interrupt
 *
 * \ingroup rs_485_api
 *
 * \param par_enable enable 
 */
void rs485_api_irq_data_recv_done(bool par_enable);



/* ########################################################################## */  
/**
 * Interrupt subroutine is run when TADR_NEW can accept a new pointer.
 *
 * \brief Enable ready to transmit interrupt
 *
 * \ingroup rs_485_api
 *
 * \param par_enable enable 
 */
void rs485_api_irq_data_send_ready(bool par_enable);

/* ########################################################################## */  
/**
 * Get number of received bytes
 *
 * \ingroup rs_485_api
 *
 * \return number of received bytes
 *
 */
uint16_t rs485_api_usi_data_rdlen_get(void);


/* ########################################################################## */  
/**
 * Set baudrates limits
 *
 * \ingroup rs_485_api
 *
 * \param m_dwLowLimit Low baudrate limit
 *
 * \param m_dwHighLimit High baudrate limit
 *
 */
void rs485_api_usi_uart_dma_autobaudrate_limits_set(uint32_t m_dwLowLimit, uint32_t m_dwHighLimit);

#endif