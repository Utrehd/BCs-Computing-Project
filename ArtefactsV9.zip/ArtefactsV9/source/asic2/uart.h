/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         uart.h
*
* @brief        UART HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_UART_H
#define HAVE_UART_H

#include "device.h"


#include "uart_irq.h"
#include "uart_bf.h"

/**
 * \example example_uart.c
 * This is an example of how to use UART block.
 */
 
/**
 * \defgroup uart ASIC2 UART HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control UART
 *
 * How to use it:
 * -# Enable clocks for UART in CLK_NRES
 * -# Configure UART
 *
 * \details See code example: @include example_uart.c
 */
/**@{*/ 



/* ############################################################################ */
/** 
 * \brief This enumeration describes UART data length
 *
 * \ingroup uart
 */
typedef enum {
    UART_DATA_LEN_8             = 0, ///< 8bit data length
    UART_DATA_LEN_7             = 1  ///< 7bit data length
} uart_data_len_t;

/* ############################################################################ */
/** 
 * \brief This enumeration describes UART parity type
 *
 * \ingroup uart
 */
typedef enum {
    UART_PARITY_NONE            = 0, ///< no parity
    UART_PARITY_ODD             = 1, ///< odd parity
    UART_PARITY_EVEN            = 2  ///< even parity
} uart_parity_t;

/* ############################################################################ */
/** 
 * \brief This enumeration describes UART data length
 *
 * \ingroup uart
 */
typedef enum {
    UART_ONE_STOP               = 0, ///< one stop bit
    UART_TWO_STOP               = 1  ///< two stop bits
} uart_stop_bit_t;

/* ############################################################################ */
/**
 * \brief Init UART 
 *
 * \param  uart_no  UART instance
 *
 * \param  divider   divider of interface, divider value = (system frequency / baudrate) - 1
 *
 * \param  frac      fractional value = frac(1)/2 + frac(0)/4
 *
 * \param  data_bits number of data bits (see uart_data_len_t)
 *
 * \param  parity    type of parity bit (see uart_parity_t)
 *
 * \param  stop_bits number of stop bits for transmit (see uart_stop_bit_t)
 *
 * \ingroup uart
 * 
 */
void uart_init(uart_num_t uart_no,
                uint16_t divider, uint8_t frac,
                uart_data_len_t data_bits, 
                uart_parity_t parity,
                uart_stop_bit_t stop_bits);

/* ############################################################################ */
/**
 * \brief  enable receive function
 *
 * \param  uart_no  UART instance
 *
 * \param  enable   enable receive function
 *
 * \ingroup uart
 * 
 */
void uart_set_rx_enable(uart_num_t uart_no, bool enable);

/* ############################################################################ */
/**
 * \brief  enable internal loopback
 *
 * \param  uart_no  UART instance
 *
 * \param  enable   enable internal loopback
 *
 * \ingroup uart
 * 
 */
void uart_loopback_enable(uart_num_t uart_no, bool enable);

/* ############################################################################ */
/**
 * \brief  Set UART divider to get specific baudrate 
 *
 * \param  uart_no  UART instance
 *
 * \param  divider   divider of interface, divider value = (system frequency / baudrate) - 1
 *
 * \param  frac      fractional value = frac(1)/2 + frac(0)/4
 *
 * \ingroup uart
 * 
 */
void uart_setdivider(uart_num_t uart_no, uint16_t divider, uint8_t frac);

/* ############################################################################ */
/**
 * \brief  Send UART data
 *
 * \param  uart_no   UART instance
 *
 * \param  data      data to be send
 *
 * \ingroup uart
 * 
 */
void uart_send_byte(uart_num_t uart_no, uint8_t data);

/* ############################################################################ */
/**
 * \brief  Get received UART data
 *
 * \param  uart_no   UART instance
 *
 * \param  data      received data 
 *
 * \return at least one element in receive fifo
 *
 * \ingroup uart
 * 
 */
bool uart_recv_byte(uart_num_t uart_no, uint8_t *data);

/* ############################################################################ */
/**
 * \brief  Get received UART data
 *
 * \param  uart_no   UART instance
 *
 * \return received data
 *
 * \ingroup uart
 * 
 */
uint8_t uart_get_rxdata(uart_num_t uart_no);

/* ############################################################################ */
/**
 * \brief  Get UART status about transmitting
 *
 * \param  uart_no   UART instance
 *
 * \return UART is transmitting (TX FIFO not empty or currently sending a byte)
 *
 * \ingroup uart
 * 
 */
bool uart_transmitting(uart_num_t uart_no);

/* ############################################################################ */
/**
 * \brief  Get UART minimum length 
 *
 * Remark: The min_bit_length high word and low word are reset to maximum value when reading the
 *         min_bit_length low word register. The first value after reset is invalid.
 *
 * \param  uart_no   UART instance
 *
 * \return minimum bit length (number of clock cycles between two edges)
 *
 * \ingroup uart
 * 
 */
uint32_t uart_get_min_bit_length(uart_num_t uart_no);

/* ############################################################################ */
/**
 * \brief  Clear UART FIFO 
 *
 * \param  uart_no   UART instance
 *
 * \param  rx_clear  clear receive fifo
 *
 * \param  tx_clear  clear transmit fifo
 *
 * \ingroup uart
 * 
 */
void uart_fifo_clear(uart_num_t uart_no, bool rx_clear, bool tx_clear);

/* ############################################################################ */
/**
 * \brief  Get number of elements in RX FIFO
 *
 * \param  uart_no   UART instance
 *
 * \return number of elements in rx fifo (from 0 to FIFO_SIZE)
 *
 * \ingroup uart
 * 
 */
uint16_t uart_get_rx_fifo_level(uart_num_t uart_no);

/* ############################################################################ */
/**
 * \brief  Get number of elements in TX FIFO
 *
 * \param  uart_no   UART instance
 *
 * \return number of elements in tx fifo (from 0 to FIFO_SIZE)
 *
 * \ingroup uart
 * 
 */
uint16_t uart_get_tx_fifo_level(uart_num_t uart_no);

/* ############################################################################ */
/**
 * \brief  Get UART RX FIFO timeout
 *
 * time in bits until receive timeout event
 * timeout will be restarted when new incoming data byte
 * timeout will be set when counted to zero and RX_FIFO.state = non empty
 *
 * \param  uart_no   UART instance
 *
 * \return time in bits until receive timeout event
 *
 * \ingroup uart
 * 
 */
uint16_t uart_get_rx_fifo_timeout(uart_num_t uart_no);

/* ############################################################################ */
/**
 * \brief  Set UART RX FIFO timeout
 *
 * time in bits until receive timeout event
 * timeout will be restarted when new incoming data byte
 * timeout will be set when counted to zero and RX_FIFO.state = non empty
 *
 * \param  uart_no  UART instance
 *
 * \param  value    time in bits until receive timeout event
 *
 * \ingroup uart
 * 
 */
void uart_set_rx_fifo_timeout(uart_num_t uart_no, uint16_t value);

/* ############################################################################ */
/**
 * \brief  Set UART FIFO high water level
 *
 * \param  uart_no  UART instance
 *
 * \param  value    receive FIFO high water level from 0...FIFOS_SIZE-1
 *
 * \ingroup uart
 * 
 */
void uart_set_rx_high_water(uart_num_t uart_no, uint8_t value);

/* ############################################################################ */
/**
 * \brief  Set UART FIFO low water level
 *
 * \param  uart_no  UART instance
 *
 * \param  value    send FIFO low water level from 0...FIFOS_SIZE-1
 *
 * \ingroup uart
 * 
 */
void uart_set_tx_low_water(uart_num_t uart_no, uint8_t value);


//======================= IRQ ===========================================

/* ############################################################################ */
/** 
 * \brief write UART_IRQ_MASK irq_mask register
 *
 * \param  uart_no  UART instance
 *
 * \param irq  specify interrupt
 *
 * \param enable enable interrupt
 *
 * \note should be implemented by IRQ_VENABLE/IRQ_VDISABLE
 */
void uart_enable_irq(uart_num_t uart_no, uart_irq_t irq, bool enable);

/* ############################################################################ */
/** 
 * \brief get UART pending interrupt
 *
 * \param  uart_no  UART instance
 *
 * \return  vector number of enabled pending interrupt with highest
 *          priority (smallest vector number).  when no irq is pending the
 *          first unused irq number is returned.
 */
uart_irq_t uart_get_next_pending_irq(uart_num_t uart_no);

/* ############################################################################ */
/** 
 * \brief get UART irq status register value 
 *
 * \param  uart_no  UART instance
 *
 * \return  contains UART_IRQ_STATUS 
 */
uart_irq_status_t uart_get_irq_status(uart_num_t uart_no);

/* ############################################################################ */
/** 
 * \brief get UART irq_mask register
 *
 * \return read irq_mask value 
 */
uart_irq_mask_t uart_get_irq_mask(uart_num_t uart_no);

/* ############################################################################ */
/** 
 * \brief Clear all interrups flags
 */
void uart_clear_irq (uart_num_t uart_no, uart_irq_t irq);

/**@{*/ 
#endif /* HAVE_UART_H */
