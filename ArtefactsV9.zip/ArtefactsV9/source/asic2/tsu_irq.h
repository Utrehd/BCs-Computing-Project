/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         tsu_irq.h
*
* @brief        TSU Module HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __TSU_IRQ_H__
#define __TSU_IRQ_H__

#define TSU_NUM_IRQS 14


/* ############################################################################ */
/**
 * \brief This enumeration describes TSU IRQ
 *
 * \ingroup tsu
 */ 
typedef enum{
  /**
   * timebase overflow
   */ 
  TSU_IRQ_EVT_TIMEBASE_OF =             0,
  /**
   * configured sync_in_ext event
   */ 
  TSU_IRQ_EVT_SYNC_IN_EXT =             1,
  /**
   * sync_out[0] event
   */ 
  TSU_IRQ_SYNC_OUT_0 =                  2,
  /**
   * sync_out[1] event
   */ 
  TSU_IRQ_SYNC_OUT_1 =                  3,
  /**
   * sync_out[2] event
   */ 
  TSU_IRQ_SYNC_OUT_2 =                  4,
  /**
   * sync_out[3] event
   */ 
  TSU_IRQ_SYNC_OUT_3 =                  5,
  /**
   * sync_out[4] event
   */ 
  TSU_IRQ_SYNC_OUT_4 =                  6,
  /**
   * sync_out[5] event
   */ 
  TSU_IRQ_SYNC_OUT_5 =                  7,
  /**
   * sync_out[6] event
   */ 
  TSU_IRQ_SYNC_OUT_6 =                  8,
  /**
   * sync_out[7] event
   */ 
  TSU_IRQ_SYNC_OUT_7 =                  9,
  /**
   * sync_out[8] event
   */ 
  TSU_IRQ_SYNC_OUT_8 =                  10,
  /**
   * sync_out[3] event
   */ 
  TSU_IRQ_SYNC_OUT_9 =                  11,
  /**
   * start of sync_out_ext[0] event
   */ 
  TSU_IRQ_SYNC_OUT_EXT_0 =              12,
  /**
   * start of sync_out_ext[1] event
   */ 
  TSU_IRQ_SYNC_OUT_EXT_1 =              13
} tsu_irq_t;

#endif
