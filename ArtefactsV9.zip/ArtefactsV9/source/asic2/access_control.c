/* FPGA Release: 10512 */
#include "access_control.h"

void access_control_unlock(void){
  WRITE_REG_16(AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI, 0xFFFF);
  WRITE_REG_16(AADDR_ACCESS_CONTROL_M2_SWD,           0xFFFF);
  WRITE_REG_16(AADDR_ACCESS_CONTROL_M3_CCPU0,         0xFFFF);
  WRITE_REG_16(AADDR_ACCESS_CONTROL_M4_SARC,          0xFFFF);
  WRITE_REG_16(AADDR_ACCESS_CONTROL_M5_USI0,          0xFFFF);
  WRITE_REG_16(AADDR_ACCESS_CONTROL_M6_USI1,          0xFFFF);
  WRITE_REG_16(AADDR_ACCESS_CONTROL_M7_ACPU1,         0xFFFF);
}

void access_control_set_peri_access(access_control_master_t master, access_control_peri_t peri_bus, access_control_access_t access){
  uint16_t reg;
  switch(master){
  case ACCESS_CONTROL_MASTER_HIAD:
  case ACCESS_CONTROL_MASTER_HISPI:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI);
    reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD + 2 * peri_bus));
    reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD + 2 * peri_bus);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI, reg);
    break;
  case ACCESS_CONTROL_MASTER_CCPU0:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M3_CCPU0);
    reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD + 2 * peri_bus));
    reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD + 2 * peri_bus);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M3_CCPU0, reg);
    break;
  case ACCESS_CONTROL_MASTER_ACPU1:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M7_ACPU1);
    reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD + 2 * peri_bus));
    reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_PERI0_RD + 2 * peri_bus);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M7_ACPU1, reg);
    break;
  default: break;
  }
}

void access_control_set_ram_access(access_control_master_t master, access_control_ram_t ram, access_control_access_t access){
  uint16_t reg;
  switch(master){
  case ACCESS_CONTROL_MASTER_HIAD:
  case ACCESS_CONTROL_MASTER_HISPI:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI);
    reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD + 2 * ram));
    reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD + 2 * ram);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI, reg);
    break;
  case ACCESS_CONTROL_MASTER_CCPU0:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M3_CCPU0);
    if (ram == ACCESS_CONTROL_RAM0){
      reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD));
      reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM0_RD);
    }
    if (ram == ACCESS_CONTROL_RAM1){
      reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD));
      reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD);
    }
    if (ram == ACCESS_CONTROL_RAME){
      reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD));
      reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD);
    }
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M3_CCPU0, reg);
    break;
  case ACCESS_CONTROL_MASTER_SWD:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M2_SWD);
    reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD + 2 * ram));
    reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD + 2 * ram);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M2_SWD, reg);
    break;
  case ACCESS_CONTROL_MASTER_SARC:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M4_SARC);
    reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD + 2 * ram));
    reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD + 2 * ram);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M4_SARC, reg);
    break;
  case ACCESS_CONTROL_MASTER_USI0:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M5_USI0);
    reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD + 2 * ram));
    reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD + 2 * ram);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M5_USI0, reg);
    break;
  case ACCESS_CONTROL_MASTER_USI1:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M6_USI1);
    reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD + 2 * ram));
    reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M2_M4_M5_M6_RAM0_RD + 2 * ram);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M6_USI1, reg);
    break;
  case ACCESS_CONTROL_MASTER_ACPU1:
    reg = READ_REG_U16(AADDR_ACCESS_CONTROL_M7_ACPU1);
    if (ram == ACCESS_CONTROL_RAM1){
      reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD));
      reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAM1_RD);
    }
    if (ram == ACCESS_CONTROL_RAME){
      reg &= ~(0x3           << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD));
      reg |=  (access & 0x3) << (SFT_ACCESS_CONTROL_M0_M1_M3_M7_RAME_RD);
    }
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M7_ACPU1, reg);
    break;
  default: break;
  }
}

void access_control_set_wbbus_access(access_control_master_t master, wbbus_module_t module, access_control_access_t access){
  uint32_t addr = 0xFFFFFFFFUL;
  uint16_t reg;
  switch(master){
  case ACCESS_CONTROL_MASTER_HIAD:
  case ACCESS_CONTROL_MASTER_HISPI:
    addr = AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_WBUS0;
    break;
  case ACCESS_CONTROL_MASTER_CCPU0:
    addr = AADDR_ACCESS_CONTROL_M3_CCPU0_WBUS0;
    break;
  case ACCESS_CONTROL_MASTER_ACPU1:
    addr = AADDR_ACCESS_CONTROL_M7_ACPU1_WBUS0;
    break;
  default: break;
  }
  if (addr < 0xFFFFFFFFUL){
    while(module > 7){
      addr += 6;
      module -= 8;
    }
    reg = READ_REG_U16(addr);
    reg &= ~(0x3           << (2 * module));
    reg |=  (access & 0x3) << (2 * module);
    WRITE_REG_16(addr, reg);
  }
}

void access_control_set_master_range(access_control_master_t master, access_control_range_t range, access_control_access_t access, uint16_t low_addr, uint16_t high_addr){
  uint16_t reg_low;
  uint16_t reg_high;

  reg_low  = (low_addr & 0xFFC0);
  reg_low |= (0x3 & access);
  reg_high = (high_addr & 0xFFC0);

  switch(master){
  case ACCESS_CONTROL_MASTER_HIAD:
  case ACCESS_CONTROL_MASTER_HISPI:
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_LOW,  reg_low);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M0_M1_HIAD_HISPI_R0_HIGH, reg_high);
    break;
  case ACCESS_CONTROL_MASTER_SWD:
    if (range) {
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M2_SWD_R1_LOW,  reg_low);
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M2_SWD_R1_HIGH, reg_high);
    } else {
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M2_SWD_R0_LOW,  reg_low);
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M2_SWD_R0_HIGH, reg_high);
    }
    break;
  case ACCESS_CONTROL_MASTER_CCPU0:
    if (range) {
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M3_CCPU0_R1_LOW,  reg_low);
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M3_CCPU0_R1_HIGH, reg_high);
    } else {
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M3_CCPU0_R0_LOW,  reg_low);
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M3_CCPU0_R0_HIGH, reg_high);
    }
    break;
  case ACCESS_CONTROL_MASTER_SARC:
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M4_SARC_R0_LOW,  reg_low);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M4_SARC_R0_HIGH, reg_high);
    break;
  case ACCESS_CONTROL_MASTER_USI0:
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M5_USI0_R0_LOW,  reg_low);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M5_USI0_R0_HIGH, reg_high);
    break;
  case ACCESS_CONTROL_MASTER_USI1:
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M6_USI1_R0_LOW,  reg_low);
    WRITE_REG_16(AADDR_ACCESS_CONTROL_M6_USI1_R0_HIGH, reg_high);
    break;
  case ACCESS_CONTROL_MASTER_ACPU1:
    if (range) {
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M7_ACPU1_R1_LOW,  reg_low);
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M7_ACPU1_R1_HIGH, reg_high);
    } else {
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M7_ACPU1_R0_LOW,  reg_low);
      WRITE_REG_16(AADDR_ACCESS_CONTROL_M7_ACPU1_R0_HIGH, reg_high);
    }
    break;
  default: break;
  }
}

