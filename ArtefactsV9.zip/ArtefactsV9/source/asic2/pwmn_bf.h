/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         pwmn_bf.h
*
* @brief        PWMN HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __PWMN_BF_H__
#define __PWMN_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_PWMN
#define BASE_ADDR_PWMN 0x40006D00U
#endif

#define NUMBER_PWMN 1


/* ############################################################################ */
/**
 * \brief This is an enum class for PWMN instance
 *
 * \ingroup pwmn 
 */ 
typedef enum {
  /**
   * This is instance PWMN
   */ 
  PWMN                           = (int)BASE_ADDR_PWMN
} pwmn_num_t;

// Register bit field definitions

/* PWMN_CFG */

#define MSK_PWMN_CFG_CNT_MODE                               (0x3)     /* [ 1:0] */
#define RES_PWMN_CFG_CNT_MODE                               (0x0)
#define SFT_PWMN_CFG_CNT_MODE                               (0)
#define LSB_PWMN_CFG_CNT_MODE                               (0)
#define MSB_PWMN_CFG_CNT_MODE                               (1)
#define MSK_PWMN_CFG_MIDDLE_RL                              (0x1)     /* [2] */
#define RES_PWMN_CFG_MIDDLE_RL                              (0x0)
#define SFT_PWMN_CFG_MIDDLE_RL                              (2)
#define LSB_PWMN_CFG_MIDDLE_RL                              (2)
#define MSB_PWMN_CFG_MIDDLE_RL                              (2)
#define BIT_PWMN_CFG_MIDDLE_RL                              (0x4)     /* [2] */
#define MSK_PWMN_CFG_DEAD_TIME_MODE                         (0x1)     /* [3] */
#define RES_PWMN_CFG_DEAD_TIME_MODE                         (0x0)
#define SFT_PWMN_CFG_DEAD_TIME_MODE                         (3)
#define LSB_PWMN_CFG_DEAD_TIME_MODE                         (3)
#define MSB_PWMN_CFG_DEAD_TIME_MODE                         (3)
#define BIT_PWMN_CFG_DEAD_TIME_MODE                         (0x8)     /* [3] */
#define MSK_PWMN_CFG_OC_ASYN_EN                             (0x1)     /* [4] */
#define RES_PWMN_CFG_OC_ASYN_EN                             (0x0)
#define SFT_PWMN_CFG_OC_ASYN_EN                             (4)
#define LSB_PWMN_CFG_OC_ASYN_EN                             (4)
#define MSB_PWMN_CFG_OC_ASYN_EN                             (4)
#define BIT_PWMN_CFG_OC_ASYN_EN                             (0x10)    /* [4] */
#define MSK_PWMN_CFG_OC_SYN_EN                              (0x1)     /* [5] */
#define RES_PWMN_CFG_OC_SYN_EN                              (0x0)
#define SFT_PWMN_CFG_OC_SYN_EN                              (5)
#define LSB_PWMN_CFG_OC_SYN_EN                              (5)
#define MSB_PWMN_CFG_OC_SYN_EN                              (5)
#define BIT_PWMN_CFG_OC_SYN_EN                              (0x20)    /* [5] */
#define MSK_PWMN_CFG_OC_INTF                                (0x7f)    /* [12:6] */
#define RES_PWMN_CFG_OC_INTF                                (0x00)
#define SFT_PWMN_CFG_OC_INTF                                (6)
#define LSB_PWMN_CFG_OC_INTF                                (6)
#define MSB_PWMN_CFG_OC_INTF                                (12)
#define MSK_PWMN_CFG_RESTART_EN                             (0x1)     /* [13] */
#define RES_PWMN_CFG_RESTART_EN                             (0x0)
#define SFT_PWMN_CFG_RESTART_EN                             (13)
#define LSB_PWMN_CFG_RESTART_EN                             (13)
#define MSB_PWMN_CFG_RESTART_EN                             (13)
#define BIT_PWMN_CFG_RESTART_EN                             (0x2000)  /* [13] */
#define MSK_PWMN_CFG_RESTART_CAP_EN                         (0x1)     /* [14] */
#define RES_PWMN_CFG_RESTART_CAP_EN                         (0x0)
#define SFT_PWMN_CFG_RESTART_CAP_EN                         (14)
#define LSB_PWMN_CFG_RESTART_CAP_EN                         (14)
#define MSB_PWMN_CFG_RESTART_CAP_EN                         (14)
#define BIT_PWMN_CFG_RESTART_CAP_EN                         (0x4000)  /* [14] */
#define MSK_PWMN_CFG_DT_EVT_CONTINUE                        (0x1)     /* [15] */
#define RES_PWMN_CFG_DT_EVT_CONTINUE                        (0x0)
#define SFT_PWMN_CFG_DT_EVT_CONTINUE                        (15)
#define LSB_PWMN_CFG_DT_EVT_CONTINUE                        (15)
#define MSB_PWMN_CFG_DT_EVT_CONTINUE                        (15)
#define BIT_PWMN_CFG_DT_EVT_CONTINUE                        (0x8000)  /* [15] */


/* ############################################################################ */
/**
 * \brief This structure describes PWMN configuration
 *
 * \ingroup pwmn 
 */ 
typedef struct {
  /**
   * 00: sawtooth: CNT=0..CNT_MAX <br>
   * 01: inverted sawtooth CNT=CNT_MAX..0 <br>
   * 10: triangle: CNT=0..CNT_MAX CNT_MAX..0 <br>
   * 11: inverted triangle: CNT=CNT_MAX..0 0..CNT_MAX
   */ 
  unsigned short cnt_mode                      :    2;       /* [ 1:0] */
  /**
   * This bit is only evaluated for cnt_mode=*triangle <br>
   * 0: reload event only at start_evt of pwm period <br>
   * 1: reload event at start_evt and middle_evt of period
   */ 
  unsigned short middle_rl                     :    1;       /* [2] */
  /**
   * 0: only rising edge of pwm is delayed by DEAD_TIME cycles <br>
   * 1: rising and falling edges of ps are delayed by DEAD_TIME cycles
   */ 
  unsigned short dead_time_mode                :    1;       /* [3] */
  /**
   * 1: nalloff sets '0' all outputs asynchronously. STATE.oc is not influenced
   */ 
  unsigned short oc_asyn_en                    :    1;       /* [4] */
  /**
   * 1: the filtered nalloff sets '0' all outputs and STATE.oc 
   */ 
  unsigned short oc_syn_en                     :    1;       /* [5] */
  /**
   * Threshold of the integration filter for the nalloff signal
   */ 
  unsigned short oc_intf                       :    7;       /* [12:6] */
  /**
   * 1: Restart input restarts CNT and PRESCALER
   */ 
  unsigned short restart_en                    :    1;       /* [13] */
  /**
   * 1: Restart input stores CNT in CNT_RESTART
   */ 
  unsigned short restart_cap_en                :    1;       /* [14] */
  /**
   * 1: Dead time events are continued on full and zero period for saradc_ctrl
   */ 
  unsigned short dt_evt_continue               :    1;       /* [15] */
} pwmn_cfg_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of PWMN configuration
 *
 * \ingroup pwmn 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  pwmn_cfg_bf bf;  ///< bit field representation
} pwmn_cfg_t;


/* PWMN_CMD */

#define MSK_PWMN_CMD_RUN                                    (0x1)     /* [0] */
#define RES_PWMN_CMD_RUN                                    (0x0)
#define SFT_PWMN_CMD_RUN                                    (0)
#define LSB_PWMN_CMD_RUN                                    (0)
#define MSB_PWMN_CMD_RUN                                    (0)
#define BIT_PWMN_CMD_RUN                                    (0x1)     /* [0] */
#define MSK_PWMN_CMD_OC                                     (0x1)     /* [1] */
#define RES_PWMN_CMD_OC                                     (0x0)
#define SFT_PWMN_CMD_OC                                     (1)
#define LSB_PWMN_CMD_OC                                     (1)
#define MSB_PWMN_CMD_OC                                     (1)
#define BIT_PWMN_CMD_OC                                     (0x2)     /* [1] */
#define MSK_PWMN_CMD_RESTART                                (0x1)     /* [2] */
#define RES_PWMN_CMD_RESTART                                (0x0)
#define SFT_PWMN_CMD_RESTART                                (2)
#define LSB_PWMN_CMD_RESTART                                (2)
#define MSB_PWMN_CMD_RESTART                                (2)
#define BIT_PWMN_CMD_RESTART                                (0x4)     /* [2] */


/* ############################################################################ */
/**
 * \brief This structure describes PWMN command
 *
 * \ingroup pwmn 
 */ 
typedef struct {
  /**
   * 0: stop (stops PRESCALER, CNT, ps and dead time FSM) <br>
   * 1: run (restarts PRESCALER, CNT and ps at start of period)
   */ 
  unsigned short run                           :    1;       /* [0] */
  /**
   * 1: clears STATE.oc
   */ 
  unsigned short oc                            :    1;       /* [1] */
  /**
   * 1: store CNT in CNT_RESTART, restart CNT and PRESCALER
   */ 
  unsigned short restart                       :    1;       /* [2] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   13;
} pwmn_cmd_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of PWMN command
 *
 * \ingroup pwmn 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  pwmn_cmd_bf bf;  ///< bit field representation
} pwmn_cmd_t;


/* PWMN_STATE */

#define MSK_PWMN_STATE_RUN                                  (0x1)     /* [0] */
#define RES_PWMN_STATE_RUN                                  (0x0)
#define SFT_PWMN_STATE_RUN                                  (0)
#define LSB_PWMN_STATE_RUN                                  (0)
#define MSB_PWMN_STATE_RUN                                  (0)
#define BIT_PWMN_STATE_RUN                                  (0x1)     /* [0] */
#define MSK_PWMN_STATE_OC                                   (0x1)     /* [1] */
#define RES_PWMN_STATE_OC                                   (0x0)
#define SFT_PWMN_STATE_OC                                   (1)
#define LSB_PWMN_STATE_OC                                   (1)
#define MSB_PWMN_STATE_OC                                   (1)
#define BIT_PWMN_STATE_OC                                   (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes PWMN state
 *
 * \ingroup pwmn 
 */ 
typedef struct {
  /**
   * 0: stopped <br>
   * 1: running
   */ 
  unsigned short run                           :    1;       /* [0] */
  /**
   * 1: over current detected, all outputs turned off same value as IRQ_STATUS.oc
   */ 
  unsigned short oc                            :    1;       /* [1] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   14;
} pwmn_state_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of PWMN state
 *
 * \ingroup pwmn 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  pwmn_state_bf bf;  ///< bit field representation
} pwmn_state_t;


/* PWMN_CNT */

#define MSK_PWMN_CNT                                        (0xffff)  /* [15:0] */

typedef unsigned short pwmn_cnt_t;                                    /* [15:0] */


/* PWMN_PWM_PHASE */

#define MSK_PWMN_PWM_PHASE                                  (0xffff)  /* [15:0] */

typedef unsigned short pwmn_pwm_phase_t;                              /* [15:0] */


/* PWMN_PRESCALER */

#define MSK_PWMN_PRESCALER                                  (0xf)     /* [ 3:0] */

typedef unsigned short pwmn_prescaler_t;                              /* [ 3:0] */


/* PWMN_CNT_MAX */

#define MSK_PWMN_CNT_MAX                                    (0xffff)  /* [15:0] */

typedef unsigned short pwmn_cnt_max_t;                                /* [15:0] */


/* PWMN_DEAD_TIME */

#define MSK_PWMN_DEAD_TIME                                  (0xff)    /* [ 7:0] */

typedef unsigned short pwmn_dead_time_t;                              /* [ 7:0] */


/* PWMN_PRESCALER_RELOAD */

#define MSK_PWMN_PRESCALER_RELOAD                           (0xf)     /* [ 3:0] */

typedef unsigned short pwmn_prescaler_reload_t;                       /* [ 3:0] */


/* PWMN_CNT_MAX_RELOAD */

#define MSK_PWMN_CNT_MAX_RELOAD                             (0xffff)  /* [15:0] */

typedef unsigned short pwmn_cnt_max_reload_t;                         /* [15:0] */


/* PWMN_DEAD_TIME_RELOAD */

#define MSK_PWMN_DEAD_TIME_RELOAD                           (0xff)    /* [ 7:0] */

typedef unsigned short pwmn_dead_time_reload_t;                       /* [ 7:0] */


/* PWMN_CNT_RESTART */

#define MSK_PWMN_CNT_RESTART                                (0xffff)  /* [15:0] */

typedef unsigned short pwmn_cnt_restart_t;                            /* [15:0] */


/* PWMN_NTH_START */

#define MSK_PWMN_NTH_START                                  (0xf)     /* [ 3:0] */

typedef unsigned short pwmn_nth_start_t;                              /* [ 3:0] */


/* PWMN_NTH_START_RELOAD */

#define MSK_PWMN_NTH_START_RELOAD                           (0xf)     /* [ 3:0] */

typedef unsigned short pwmn_nth_start_reload_t;                       /* [ 3:0] */


/* PWMN_PWM_CFG */

#define MSK_PWMN_PWM_CFG                                    (0x3)     /* [ 1:0] */

typedef unsigned short pwmn_pwm_cfg_t;                                /* [ 1:0] */


/* PWMN_PWM_C */

#define MSK_PWMN_PWM_C                                      (0xffff)  /* [15:0] */

typedef unsigned short pwmn_pwm_c_t;                                  /* [15:0] */


/* PWMN_PWM_ON */

#define MSK_PWMN_PWM_ON_LS                                  (0x1)     /* [0] */
#define RES_PWMN_PWM_ON_LS                                  (0x0)
#define SFT_PWMN_PWM_ON_LS                                  (0)
#define LSB_PWMN_PWM_ON_LS                                  (0)
#define MSB_PWMN_PWM_ON_LS                                  (0)
#define BIT_PWMN_PWM_ON_LS                                  (0x1)     /* [0] */
#define MSK_PWMN_PWM_ON_HS                                  (0x1)     /* [1] */
#define RES_PWMN_PWM_ON_HS                                  (0x0)
#define SFT_PWMN_PWM_ON_HS                                  (1)
#define LSB_PWMN_PWM_ON_HS                                  (1)
#define MSB_PWMN_PWM_ON_HS                                  (1)
#define BIT_PWMN_PWM_ON_HS                                  (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes PWMN on
 *
 * \ingroup pwmn 
 */ 
typedef struct {
  /**
   * 0: ls[?]=0
   */ 
  unsigned short ls                            :    1;       /* [0] */
  /**
   * 0: hs[?]=0
   */ 
  unsigned short hs                            :    1;       /* [1] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   14;
} pwmn_pwm_on_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of PWMN on
 *
 * \ingroup pwmn 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  pwmn_pwm_on_bf bf;  ///< bit field representation
} pwmn_pwm_on_t;


/* PWMN_PWM_C_RELOAD */

#define MSK_PWMN_PWM_C_RELOAD                               (0xffff)  /* [15:0] */

typedef unsigned short pwmn_pwm_c_reload_t;                           /* [15:0] */


/* PWMN_PWM_ON_RELOAD */

#define MSK_PWMN_PWM_ON_RELOAD_LS                           (0x1)     /* [0] */
#define RES_PWMN_PWM_ON_RELOAD_LS                           (0x0)
#define SFT_PWMN_PWM_ON_RELOAD_LS                           (0)
#define LSB_PWMN_PWM_ON_RELOAD_LS                           (0)
#define MSB_PWMN_PWM_ON_RELOAD_LS                           (0)
#define BIT_PWMN_PWM_ON_RELOAD_LS                           (0x1)     /* [0] */
#define MSK_PWMN_PWM_ON_RELOAD_HS                           (0x1)     /* [1] */
#define RES_PWMN_PWM_ON_RELOAD_HS                           (0x0)
#define SFT_PWMN_PWM_ON_RELOAD_HS                           (1)
#define LSB_PWMN_PWM_ON_RELOAD_HS                           (1)
#define MSB_PWMN_PWM_ON_RELOAD_HS                           (1)
#define BIT_PWMN_PWM_ON_RELOAD_HS                           (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes PWMN on reload
 *
 * \ingroup pwmn 
 */ 
typedef struct {
  /**
   * 
   */ 
  unsigned short ls                            :    1;       /* [0] */
  /**
   * 
   */ 
  unsigned short hs                            :    1;       /* [1] */
  /**
   * 
   */ 
  unsigned short reserved                      :   14;
} pwmn_pwm_on_reload_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of WMN on reload
 *
 * \ingroup pwmn 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  pwmn_pwm_on_reload_bf bf;  ///< bit field representation
} pwmn_pwm_on_reload_t;


/* PWMN_IRQ_STATUS */

#define MSK_PWMN_IRQ_STATUS_OC                              (0x1)     /* [0] */
#define RES_PWMN_IRQ_STATUS_OC                              (0x0)
#define SFT_PWMN_IRQ_STATUS_OC                              (0)
#define LSB_PWMN_IRQ_STATUS_OC                              (0)
#define MSB_PWMN_IRQ_STATUS_OC                              (0)
#define BIT_PWMN_IRQ_STATUS_OC                              (0x1)     /* [0] */
#define MSK_PWMN_IRQ_STATUS_START_EVT                       (0x1)     /* [1] */
#define RES_PWMN_IRQ_STATUS_START_EVT                       (0x0)
#define SFT_PWMN_IRQ_STATUS_START_EVT                       (1)
#define LSB_PWMN_IRQ_STATUS_START_EVT                       (1)
#define MSB_PWMN_IRQ_STATUS_START_EVT                       (1)
#define BIT_PWMN_IRQ_STATUS_START_EVT                       (0x2)     /* [1] */
#define MSK_PWMN_IRQ_STATUS_MIDDLE_EVT                      (0x1)     /* [2] */
#define RES_PWMN_IRQ_STATUS_MIDDLE_EVT                      (0x0)
#define SFT_PWMN_IRQ_STATUS_MIDDLE_EVT                      (2)
#define LSB_PWMN_IRQ_STATUS_MIDDLE_EVT                      (2)
#define MSB_PWMN_IRQ_STATUS_MIDDLE_EVT                      (2)
#define BIT_PWMN_IRQ_STATUS_MIDDLE_EVT                      (0x4)     /* [2] */
#define MSK_PWMN_IRQ_STATUS_DEAD_TIME_EVT_0                 (0x1)     /* [3] */
#define RES_PWMN_IRQ_STATUS_DEAD_TIME_EVT_0                 (0x0)
#define SFT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_0                 (3)
#define LSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_0                 (3)
#define MSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_0                 (3)
#define BIT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_0                 (0x8)     /* [3] */
#define MSK_PWMN_IRQ_STATUS_DEAD_TIME_EVT_1                 (0x1)     /* [4] */
#define RES_PWMN_IRQ_STATUS_DEAD_TIME_EVT_1                 (0x0)
#define SFT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_1                 (4)
#define LSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_1                 (4)
#define MSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_1                 (4)
#define BIT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_1                 (0x10)    /* [4] */
#define MSK_PWMN_IRQ_STATUS_DEAD_TIME_EVT_2                 (0x1)     /* [5] */
#define RES_PWMN_IRQ_STATUS_DEAD_TIME_EVT_2                 (0x0)
#define SFT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_2                 (5)
#define LSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_2                 (5)
#define MSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_2                 (5)
#define BIT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_2                 (0x20)    /* [5] */
#define MSK_PWMN_IRQ_STATUS_DEAD_TIME_EVT_3                 (0x1)     /* [6] */
#define RES_PWMN_IRQ_STATUS_DEAD_TIME_EVT_3                 (0x0)
#define SFT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_3                 (6)
#define LSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_3                 (6)
#define MSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_3                 (6)
#define BIT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_3                 (0x40)    /* [6] */
#define MSK_PWMN_IRQ_STATUS_DEAD_TIME_EVT_4                 (0x1)     /* [7] */
#define RES_PWMN_IRQ_STATUS_DEAD_TIME_EVT_4                 (0x0)
#define SFT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_4                 (7)
#define LSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_4                 (7)
#define MSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_4                 (7)
#define BIT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_4                 (0x80)    /* [7] */
#define MSK_PWMN_IRQ_STATUS_DEAD_TIME_EVT_5                 (0x1)     /* [8] */
#define RES_PWMN_IRQ_STATUS_DEAD_TIME_EVT_5                 (0x0)
#define SFT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_5                 (8)
#define LSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_5                 (8)
#define MSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_5                 (8)
#define BIT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_5                 (0x100)   /* [8] */
#define MSK_PWMN_IRQ_STATUS_DEAD_TIME_EVT_6                 (0x1)     /* [9] */
#define RES_PWMN_IRQ_STATUS_DEAD_TIME_EVT_6                 (0x0)
#define SFT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_6                 (9)
#define LSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_6                 (9)
#define MSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_6                 (9)
#define BIT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_6                 (0x200)   /* [9] */
#define MSK_PWMN_IRQ_STATUS_DEAD_TIME_EVT_7                 (0x1)     /* [10] */
#define RES_PWMN_IRQ_STATUS_DEAD_TIME_EVT_7                 (0x0)
#define SFT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_7                 (10)
#define LSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_7                 (10)
#define MSB_PWMN_IRQ_STATUS_DEAD_TIME_EVT_7                 (10)
#define BIT_PWMN_IRQ_STATUS_DEAD_TIME_EVT_7                 (0x400)   /* [10] */


/* ############################################################################ */
/**
 * \brief This structure describes PWMN Interrupt status
 *
 * \ingroup pwmn 
 */ 
typedef struct {
  /**
   * Over current
   */ 
  unsigned short oc                            :    1;       /* [0] */
  /**
   * Start of NTH_START pwm period and associated reload event occurred
   */ 
  unsigned short start_evt                     :    1;       /* [1] */
  /**
   * Middle of pwm period occurred
   */ 
  unsigned short middle_evt                    :    1;       /* [2] */
  /**
   * Dead time event 0 occurred (channel 0, pos)
   */ 
  unsigned short dead_time_evt_0               :    1;       /* [3] */
  /**
   * Dead time event 1 occurred (channel 0, neg)
   */ 
  unsigned short dead_time_evt_1               :    1;       /* [4] */
  /**
   * Dead time event 2 occurred (channel 1, pos)
   */ 
  unsigned short dead_time_evt_2               :    1;       /* [5] */
  /**
   * Dead time event 3 occurred (channel 1, neg)
   */ 
  unsigned short dead_time_evt_3               :    1;       /* [6] */
  /**
   * Dead time event 4 occurred (channel 2, pos)
   */ 
  unsigned short dead_time_evt_4               :    1;       /* [7] */
  /**
   * Dead time event 5 occurred (channel 2, neg)
   */ 
  unsigned short dead_time_evt_5               :    1;       /* [8] */
  /**
   * Dead time event 6 occurred (channel 3, pos)
   */ 
  unsigned short dead_time_evt_6               :    1;       /* [9] */
  /**
   * Dead time event 7 occurred (channel 3, neg)
   */ 
  unsigned short dead_time_evt_7               :    1;       /* [10] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    5;
} pwmn_irq_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of PWMN Interrupt status
 *
 * \ingroup pwmn 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  pwmn_irq_status_bf bf;  ///< bit field representation
} pwmn_irq_status_t;


/* PWMN_IRQ_MASK */

#define MSK_PWMN_IRQ_MASK                                   (0x7ff)   /* [10:0] */

typedef unsigned short pwmn_irq_mask_t;                               /* [10:0] */


/* PWMN_IRQ_VENABLE */

#define MSK_PWMN_IRQ_VENABLE                                (0xf)     /* [ 3:0] */

typedef unsigned short pwmn_irq_venable_t;                            /* [ 3:0] */


/* PWMN_IRQ_VDISABLE */

#define MSK_PWMN_IRQ_VDISABLE                               (0xf)     /* [ 3:0] */

typedef unsigned short pwmn_irq_vdisable_t;                           /* [ 3:0] */


/* PWMN_IRQ_VMAX */

#define MSK_PWMN_IRQ_VMAX                                   (0xf)     /* [ 3:0] */

typedef unsigned short pwmn_irq_vmax_t;                               /* [ 3:0] */


/* PWMN_IRQ_VNO */

#define MSK_PWMN_IRQ_VNO                                    (0xf)     /* [ 3:0] */

typedef unsigned short pwmn_irq_vno_t;                                /* [ 3:0] */



// Register definitions for module
// Instance base address BASE_ADDR_PWMN 0x40006D00U ... 

#define ADDR_PWMN_CFG                                        (0x00U)
#define A_PWMN_CFG(ba)                                       ((ba) + ADDR_PWMN_CFG)
#define R_PWMN_CFG(ba)                                       (*(volatile unsigned short *)((unsigned int)A_PWMN_CFG(ba)))
#define RES_PWMN_CFG                                         (0x0U)
#define MSB_PWMN_CFG                                         15
#define LSB_PWMN_CFG                                         0
#define AADDR_PWMN_CFG                                       (BASE_ADDR_PWMN + ADDR_PWMN_CFG)
#define REG_PWMN_CFG                                         (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_CFG))

#define ADDR_PWMN_CMD                                        (0x02U)
#define A_PWMN_CMD(ba)                                       ((ba) + ADDR_PWMN_CMD)
#define R_PWMN_CMD(ba)                                       (*(volatile unsigned short *)((unsigned int)A_PWMN_CMD(ba)))
#define RES_PWMN_CMD                                         (0x0U)
#define MSB_PWMN_CMD                                         2
#define LSB_PWMN_CMD                                         0
#define AADDR_PWMN_CMD                                       (BASE_ADDR_PWMN + ADDR_PWMN_CMD)
#define REG_PWMN_CMD                                         (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_CMD))

#define ADDR_PWMN_STATE                                      (0x04U)
#define A_PWMN_STATE(ba)                                     ((ba) + ADDR_PWMN_STATE)
#define R_PWMN_STATE(ba)                                     (*(volatile unsigned short *)((unsigned int)A_PWMN_STATE(ba)))
#define RES_PWMN_STATE                                       (0x0U)
#define MSB_PWMN_STATE                                       1
#define LSB_PWMN_STATE                                       0
#define AADDR_PWMN_STATE                                     (BASE_ADDR_PWMN + ADDR_PWMN_STATE)
#define REG_PWMN_STATE                                       (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_STATE))

#define ADDR_PWMN_CNT                                        (0x06U)
#define A_PWMN_CNT(ba)                                       ((ba) + ADDR_PWMN_CNT)
#define R_PWMN_CNT(ba)                                       (*(volatile unsigned short *)((unsigned int)A_PWMN_CNT(ba)))
#define RES_PWMN_CNT                                         (0x0U)
#define MSB_PWMN_CNT                                         15
#define LSB_PWMN_CNT                                         0
#define AADDR_PWMN_CNT                                       (BASE_ADDR_PWMN + ADDR_PWMN_CNT)
#define REG_PWMN_CNT                                         (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_CNT))

#define ADDR_PWMN_PWM_PHASE                                  (0x08U)
#define A_PWMN_PWM_PHASE(ba)                                 ((ba) + ADDR_PWMN_PWM_PHASE)
#define R_PWMN_PWM_PHASE(ba)                                 (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM_PHASE(ba)))
#define RES_PWMN_PWM_PHASE                                   (0x0U)
#define MSB_PWMN_PWM_PHASE                                   15
#define LSB_PWMN_PWM_PHASE                                   0
#define AADDR_PWMN_PWM_PHASE                                 (BASE_ADDR_PWMN + ADDR_PWMN_PWM_PHASE)
#define REG_PWMN_PWM_PHASE                                   (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM_PHASE))

#define ADDR_PWMN_PRESCALER                                  (0x0AU)
#define A_PWMN_PRESCALER(ba)                                 ((ba) + ADDR_PWMN_PRESCALER)
#define R_PWMN_PRESCALER(ba)                                 (*(volatile unsigned short *)((unsigned int)A_PWMN_PRESCALER(ba)))
#define RES_PWMN_PRESCALER                                   (0x0U)
#define MSB_PWMN_PRESCALER                                   3
#define LSB_PWMN_PRESCALER                                   0
#define AADDR_PWMN_PRESCALER                                 (BASE_ADDR_PWMN + ADDR_PWMN_PRESCALER)
#define REG_PWMN_PRESCALER                                   (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PRESCALER))

#define ADDR_PWMN_CNT_MAX                                    (0x0CU)
#define A_PWMN_CNT_MAX(ba)                                   ((ba) + ADDR_PWMN_CNT_MAX)
#define R_PWMN_CNT_MAX(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_CNT_MAX(ba)))
#define RES_PWMN_CNT_MAX                                     (0x0U)
#define MSB_PWMN_CNT_MAX                                     15
#define LSB_PWMN_CNT_MAX                                     0
#define AADDR_PWMN_CNT_MAX                                   (BASE_ADDR_PWMN + ADDR_PWMN_CNT_MAX)
#define REG_PWMN_CNT_MAX                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_CNT_MAX))

#define ADDR_PWMN_DEAD_TIME                                  (0x0EU)
#define A_PWMN_DEAD_TIME(ba)                                 ((ba) + ADDR_PWMN_DEAD_TIME)
#define R_PWMN_DEAD_TIME(ba)                                 (*(volatile unsigned short *)((unsigned int)A_PWMN_DEAD_TIME(ba)))
#define RES_PWMN_DEAD_TIME                                   (0x0U)
#define MSB_PWMN_DEAD_TIME                                   7
#define LSB_PWMN_DEAD_TIME                                   0
#define AADDR_PWMN_DEAD_TIME                                 (BASE_ADDR_PWMN + ADDR_PWMN_DEAD_TIME)
#define REG_PWMN_DEAD_TIME                                   (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_DEAD_TIME))

#define ADDR_PWMN_PRESCALER_RELOAD                           (0x10U)
#define A_PWMN_PRESCALER_RELOAD(ba)                          ((ba) + ADDR_PWMN_PRESCALER_RELOAD)
#define R_PWMN_PRESCALER_RELOAD(ba)                          (*(volatile unsigned short *)((unsigned int)A_PWMN_PRESCALER_RELOAD(ba)))
#define RES_PWMN_PRESCALER_RELOAD                            (0x0U)
#define MSB_PWMN_PRESCALER_RELOAD                            3
#define LSB_PWMN_PRESCALER_RELOAD                            0
#define AADDR_PWMN_PRESCALER_RELOAD                          (BASE_ADDR_PWMN + ADDR_PWMN_PRESCALER_RELOAD)
#define REG_PWMN_PRESCALER_RELOAD                            (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PRESCALER_RELOAD))

#define ADDR_PWMN_CNT_MAX_RELOAD                             (0x12U)
#define A_PWMN_CNT_MAX_RELOAD(ba)                            ((ba) + ADDR_PWMN_CNT_MAX_RELOAD)
#define R_PWMN_CNT_MAX_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_CNT_MAX_RELOAD(ba)))
#define RES_PWMN_CNT_MAX_RELOAD                              (0x0U)
#define MSB_PWMN_CNT_MAX_RELOAD                              15
#define LSB_PWMN_CNT_MAX_RELOAD                              0
#define AADDR_PWMN_CNT_MAX_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_CNT_MAX_RELOAD)
#define REG_PWMN_CNT_MAX_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_CNT_MAX_RELOAD))

#define ADDR_PWMN_DEAD_TIME_RELOAD                           (0x14U)
#define A_PWMN_DEAD_TIME_RELOAD(ba)                          ((ba) + ADDR_PWMN_DEAD_TIME_RELOAD)
#define R_PWMN_DEAD_TIME_RELOAD(ba)                          (*(volatile unsigned short *)((unsigned int)A_PWMN_DEAD_TIME_RELOAD(ba)))
#define RES_PWMN_DEAD_TIME_RELOAD                            (0x0U)
#define MSB_PWMN_DEAD_TIME_RELOAD                            7
#define LSB_PWMN_DEAD_TIME_RELOAD                            0
#define AADDR_PWMN_DEAD_TIME_RELOAD                          (BASE_ADDR_PWMN + ADDR_PWMN_DEAD_TIME_RELOAD)
#define REG_PWMN_DEAD_TIME_RELOAD                            (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_DEAD_TIME_RELOAD))

#define ADDR_PWMN_CNT_RESTART                                (0x16U)
#define A_PWMN_CNT_RESTART(ba)                               ((ba) + ADDR_PWMN_CNT_RESTART)
#define R_PWMN_CNT_RESTART(ba)                               (*(volatile unsigned short *)((unsigned int)A_PWMN_CNT_RESTART(ba)))
#define RES_PWMN_CNT_RESTART                                 (0x0U)
#define MSB_PWMN_CNT_RESTART                                 15
#define LSB_PWMN_CNT_RESTART                                 0
#define AADDR_PWMN_CNT_RESTART                               (BASE_ADDR_PWMN + ADDR_PWMN_CNT_RESTART)
#define REG_PWMN_CNT_RESTART                                 (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_CNT_RESTART))

#define ADDR_PWMN_NTH_START                                  (0x18U)
#define A_PWMN_NTH_START(ba)                                 ((ba) + ADDR_PWMN_NTH_START)
#define R_PWMN_NTH_START(ba)                                 (*(volatile unsigned short *)((unsigned int)A_PWMN_NTH_START(ba)))
#define RES_PWMN_NTH_START                                   (0x0U)
#define MSB_PWMN_NTH_START                                   3
#define LSB_PWMN_NTH_START                                   0
#define AADDR_PWMN_NTH_START                                 (BASE_ADDR_PWMN + ADDR_PWMN_NTH_START)
#define REG_PWMN_NTH_START                                   (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_NTH_START))

#define ADDR_PWMN_NTH_START_RELOAD                           (0x1AU)
#define A_PWMN_NTH_START_RELOAD(ba)                          ((ba) + ADDR_PWMN_NTH_START_RELOAD)
#define R_PWMN_NTH_START_RELOAD(ba)                          (*(volatile unsigned short *)((unsigned int)A_PWMN_NTH_START_RELOAD(ba)))
#define RES_PWMN_NTH_START_RELOAD                            (0x0U)
#define MSB_PWMN_NTH_START_RELOAD                            3
#define LSB_PWMN_NTH_START_RELOAD                            0
#define AADDR_PWMN_NTH_START_RELOAD                          (BASE_ADDR_PWMN + ADDR_PWMN_NTH_START_RELOAD)
#define REG_PWMN_NTH_START_RELOAD                            (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_NTH_START_RELOAD))

#define ADDR_PWMN_PWM0_CFG                                   (0x20U)
#define A_PWMN_PWM0_CFG(ba)                                  ((ba) + ADDR_PWMN_PWM0_CFG)
#define R_PWMN_PWM0_CFG(ba)                                  (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM0_CFG(ba)))
#define RES_PWMN_PWM0_CFG                                    (0x0U)
#define MSB_PWMN_PWM0_CFG                                    1
#define LSB_PWMN_PWM0_CFG                                    0
#define AADDR_PWMN_PWM0_CFG                                  (BASE_ADDR_PWMN + ADDR_PWMN_PWM0_CFG)
#define REG_PWMN_PWM0_CFG                                    (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM0_CFG))

#define ADDR_PWMN_PWM0_C0                                    (0x22U)
#define A_PWMN_PWM0_C0(ba)                                   ((ba) + ADDR_PWMN_PWM0_C0)
#define R_PWMN_PWM0_C0(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM0_C0(ba)))
#define RES_PWMN_PWM0_C0                                     (0x0U)
#define MSB_PWMN_PWM0_C0                                     15
#define LSB_PWMN_PWM0_C0                                     0
#define AADDR_PWMN_PWM0_C0                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM0_C0)
#define REG_PWMN_PWM0_C0                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM0_C0))

#define ADDR_PWMN_PWM0_C1                                    (0x24U)
#define A_PWMN_PWM0_C1(ba)                                   ((ba) + ADDR_PWMN_PWM0_C1)
#define R_PWMN_PWM0_C1(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM0_C1(ba)))
#define RES_PWMN_PWM0_C1                                     (0x0U)
#define MSB_PWMN_PWM0_C1                                     15
#define LSB_PWMN_PWM0_C1                                     0
#define AADDR_PWMN_PWM0_C1                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM0_C1)
#define REG_PWMN_PWM0_C1                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM0_C1))

#define ADDR_PWMN_PWM0_ON                                    (0x26U)
#define A_PWMN_PWM0_ON(ba)                                   ((ba) + ADDR_PWMN_PWM0_ON)
#define R_PWMN_PWM0_ON(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM0_ON(ba)))
#define RES_PWMN_PWM0_ON                                     (0x0U)
#define MSB_PWMN_PWM0_ON                                     1
#define LSB_PWMN_PWM0_ON                                     0
#define AADDR_PWMN_PWM0_ON                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM0_ON)
#define REG_PWMN_PWM0_ON                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM0_ON))

#define ADDR_PWMN_PWM0_C0_RELOAD                             (0x28U)
#define A_PWMN_PWM0_C0_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM0_C0_RELOAD)
#define R_PWMN_PWM0_C0_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM0_C0_RELOAD(ba)))
#define RES_PWMN_PWM0_C0_RELOAD                              (0x0U)
#define MSB_PWMN_PWM0_C0_RELOAD                              15
#define LSB_PWMN_PWM0_C0_RELOAD                              0
#define AADDR_PWMN_PWM0_C0_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM0_C0_RELOAD)
#define REG_PWMN_PWM0_C0_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM0_C0_RELOAD))

#define ADDR_PWMN_PWM0_C1_RELOAD                             (0x2AU)
#define A_PWMN_PWM0_C1_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM0_C1_RELOAD)
#define R_PWMN_PWM0_C1_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM0_C1_RELOAD(ba)))
#define RES_PWMN_PWM0_C1_RELOAD                              (0x0U)
#define MSB_PWMN_PWM0_C1_RELOAD                              15
#define LSB_PWMN_PWM0_C1_RELOAD                              0
#define AADDR_PWMN_PWM0_C1_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM0_C1_RELOAD)
#define REG_PWMN_PWM0_C1_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM0_C1_RELOAD))

#define ADDR_PWMN_PWM0_ON_RELOAD                             (0x2CU)
#define A_PWMN_PWM0_ON_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM0_ON_RELOAD)
#define R_PWMN_PWM0_ON_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM0_ON_RELOAD(ba)))
#define RES_PWMN_PWM0_ON_RELOAD                              (0x0U)
#define MSB_PWMN_PWM0_ON_RELOAD                              1
#define LSB_PWMN_PWM0_ON_RELOAD                              0
#define AADDR_PWMN_PWM0_ON_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM0_ON_RELOAD)
#define REG_PWMN_PWM0_ON_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM0_ON_RELOAD))

#define ADDR_PWMN_PWM1_CFG                                   (0x30U)
#define A_PWMN_PWM1_CFG(ba)                                  ((ba) + ADDR_PWMN_PWM1_CFG)
#define R_PWMN_PWM1_CFG(ba)                                  (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM1_CFG(ba)))
#define RES_PWMN_PWM1_CFG                                    (0x0U)
#define MSB_PWMN_PWM1_CFG                                    1
#define LSB_PWMN_PWM1_CFG                                    0
#define AADDR_PWMN_PWM1_CFG                                  (BASE_ADDR_PWMN + ADDR_PWMN_PWM1_CFG)
#define REG_PWMN_PWM1_CFG                                    (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM1_CFG))

#define ADDR_PWMN_PWM1_C0                                    (0x32U)
#define A_PWMN_PWM1_C0(ba)                                   ((ba) + ADDR_PWMN_PWM1_C0)
#define R_PWMN_PWM1_C0(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM1_C0(ba)))
#define RES_PWMN_PWM1_C0                                     (0x0U)
#define MSB_PWMN_PWM1_C0                                     15
#define LSB_PWMN_PWM1_C0                                     0
#define AADDR_PWMN_PWM1_C0                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM1_C0)
#define REG_PWMN_PWM1_C0                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM1_C0))

#define ADDR_PWMN_PWM1_C1                                    (0x34U)
#define A_PWMN_PWM1_C1(ba)                                   ((ba) + ADDR_PWMN_PWM1_C1)
#define R_PWMN_PWM1_C1(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM1_C1(ba)))
#define RES_PWMN_PWM1_C1                                     (0x0U)
#define MSB_PWMN_PWM1_C1                                     15
#define LSB_PWMN_PWM1_C1                                     0
#define AADDR_PWMN_PWM1_C1                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM1_C1)
#define REG_PWMN_PWM1_C1                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM1_C1))

#define ADDR_PWMN_PWM1_ON                                    (0x36U)
#define A_PWMN_PWM1_ON(ba)                                   ((ba) + ADDR_PWMN_PWM1_ON)
#define R_PWMN_PWM1_ON(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM1_ON(ba)))
#define RES_PWMN_PWM1_ON                                     (0x0U)
#define MSB_PWMN_PWM1_ON                                     1
#define LSB_PWMN_PWM1_ON                                     0
#define AADDR_PWMN_PWM1_ON                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM1_ON)
#define REG_PWMN_PWM1_ON                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM1_ON))

#define ADDR_PWMN_PWM1_C0_RELOAD                             (0x38U)
#define A_PWMN_PWM1_C0_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM1_C0_RELOAD)
#define R_PWMN_PWM1_C0_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM1_C0_RELOAD(ba)))
#define RES_PWMN_PWM1_C0_RELOAD                              (0x0U)
#define MSB_PWMN_PWM1_C0_RELOAD                              15
#define LSB_PWMN_PWM1_C0_RELOAD                              0
#define AADDR_PWMN_PWM1_C0_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM1_C0_RELOAD)
#define REG_PWMN_PWM1_C0_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM1_C0_RELOAD))

#define ADDR_PWMN_PWM1_C1_RELOAD                             (0x3AU)
#define A_PWMN_PWM1_C1_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM1_C1_RELOAD)
#define R_PWMN_PWM1_C1_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM1_C1_RELOAD(ba)))
#define RES_PWMN_PWM1_C1_RELOAD                              (0x0U)
#define MSB_PWMN_PWM1_C1_RELOAD                              15
#define LSB_PWMN_PWM1_C1_RELOAD                              0
#define AADDR_PWMN_PWM1_C1_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM1_C1_RELOAD)
#define REG_PWMN_PWM1_C1_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM1_C1_RELOAD))

#define ADDR_PWMN_PWM1_ON_RELOAD                             (0x3CU)
#define A_PWMN_PWM1_ON_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM1_ON_RELOAD)
#define R_PWMN_PWM1_ON_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM1_ON_RELOAD(ba)))
#define RES_PWMN_PWM1_ON_RELOAD                              (0x0U)
#define MSB_PWMN_PWM1_ON_RELOAD                              1
#define LSB_PWMN_PWM1_ON_RELOAD                              0
#define AADDR_PWMN_PWM1_ON_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM1_ON_RELOAD)
#define REG_PWMN_PWM1_ON_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM1_ON_RELOAD))

#define ADDR_PWMN_PWM2_CFG                                   (0x40U)
#define A_PWMN_PWM2_CFG(ba)                                  ((ba) + ADDR_PWMN_PWM2_CFG)
#define R_PWMN_PWM2_CFG(ba)                                  (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM2_CFG(ba)))
#define RES_PWMN_PWM2_CFG                                    (0x0U)
#define MSB_PWMN_PWM2_CFG                                    1
#define LSB_PWMN_PWM2_CFG                                    0
#define AADDR_PWMN_PWM2_CFG                                  (BASE_ADDR_PWMN + ADDR_PWMN_PWM2_CFG)
#define REG_PWMN_PWM2_CFG                                    (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM2_CFG))

#define ADDR_PWMN_PWM2_C0                                    (0x42U)
#define A_PWMN_PWM2_C0(ba)                                   ((ba) + ADDR_PWMN_PWM2_C0)
#define R_PWMN_PWM2_C0(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM2_C0(ba)))
#define RES_PWMN_PWM2_C0                                     (0x0U)
#define MSB_PWMN_PWM2_C0                                     15
#define LSB_PWMN_PWM2_C0                                     0
#define AADDR_PWMN_PWM2_C0                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM2_C0)
#define REG_PWMN_PWM2_C0                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM2_C0))

#define ADDR_PWMN_PWM2_C1                                    (0x44U)
#define A_PWMN_PWM2_C1(ba)                                   ((ba) + ADDR_PWMN_PWM2_C1)
#define R_PWMN_PWM2_C1(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM2_C1(ba)))
#define RES_PWMN_PWM2_C1                                     (0x0U)
#define MSB_PWMN_PWM2_C1                                     15
#define LSB_PWMN_PWM2_C1                                     0
#define AADDR_PWMN_PWM2_C1                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM2_C1)
#define REG_PWMN_PWM2_C1                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM2_C1))

#define ADDR_PWMN_PWM2_ON                                    (0x46U)
#define A_PWMN_PWM2_ON(ba)                                   ((ba) + ADDR_PWMN_PWM2_ON)
#define R_PWMN_PWM2_ON(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM2_ON(ba)))
#define RES_PWMN_PWM2_ON                                     (0x0U)
#define MSB_PWMN_PWM2_ON                                     1
#define LSB_PWMN_PWM2_ON                                     0
#define AADDR_PWMN_PWM2_ON                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM2_ON)
#define REG_PWMN_PWM2_ON                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM2_ON))

#define ADDR_PWMN_PWM2_C0_RELOAD                             (0x48U)
#define A_PWMN_PWM2_C0_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM2_C0_RELOAD)
#define R_PWMN_PWM2_C0_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM2_C0_RELOAD(ba)))
#define RES_PWMN_PWM2_C0_RELOAD                              (0x0U)
#define MSB_PWMN_PWM2_C0_RELOAD                              15
#define LSB_PWMN_PWM2_C0_RELOAD                              0
#define AADDR_PWMN_PWM2_C0_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM2_C0_RELOAD)
#define REG_PWMN_PWM2_C0_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM2_C0_RELOAD))

#define ADDR_PWMN_PWM2_C1_RELOAD                             (0x4AU)
#define A_PWMN_PWM2_C1_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM2_C1_RELOAD)
#define R_PWMN_PWM2_C1_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM2_C1_RELOAD(ba)))
#define RES_PWMN_PWM2_C1_RELOAD                              (0x0U)
#define MSB_PWMN_PWM2_C1_RELOAD                              15
#define LSB_PWMN_PWM2_C1_RELOAD                              0
#define AADDR_PWMN_PWM2_C1_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM2_C1_RELOAD)
#define REG_PWMN_PWM2_C1_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM2_C1_RELOAD))

#define ADDR_PWMN_PWM2_ON_RELOAD                             (0x4CU)
#define A_PWMN_PWM2_ON_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM2_ON_RELOAD)
#define R_PWMN_PWM2_ON_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM2_ON_RELOAD(ba)))
#define RES_PWMN_PWM2_ON_RELOAD                              (0x0U)
#define MSB_PWMN_PWM2_ON_RELOAD                              1
#define LSB_PWMN_PWM2_ON_RELOAD                              0
#define AADDR_PWMN_PWM2_ON_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM2_ON_RELOAD)
#define REG_PWMN_PWM2_ON_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM2_ON_RELOAD))

#define ADDR_PWMN_PWM3_CFG                                   (0x50U)
#define A_PWMN_PWM3_CFG(ba)                                  ((ba) + ADDR_PWMN_PWM3_CFG)
#define R_PWMN_PWM3_CFG(ba)                                  (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM3_CFG(ba)))
#define RES_PWMN_PWM3_CFG                                    (0x0U)
#define MSB_PWMN_PWM3_CFG                                    1
#define LSB_PWMN_PWM3_CFG                                    0
#define AADDR_PWMN_PWM3_CFG                                  (BASE_ADDR_PWMN + ADDR_PWMN_PWM3_CFG)
#define REG_PWMN_PWM3_CFG                                    (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM3_CFG))

#define ADDR_PWMN_PWM3_C0                                    (0x52U)
#define A_PWMN_PWM3_C0(ba)                                   ((ba) + ADDR_PWMN_PWM3_C0)
#define R_PWMN_PWM3_C0(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM3_C0(ba)))
#define RES_PWMN_PWM3_C0                                     (0x0U)
#define MSB_PWMN_PWM3_C0                                     15
#define LSB_PWMN_PWM3_C0                                     0
#define AADDR_PWMN_PWM3_C0                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM3_C0)
#define REG_PWMN_PWM3_C0                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM3_C0))

#define ADDR_PWMN_PWM3_C1                                    (0x54U)
#define A_PWMN_PWM3_C1(ba)                                   ((ba) + ADDR_PWMN_PWM3_C1)
#define R_PWMN_PWM3_C1(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM3_C1(ba)))
#define RES_PWMN_PWM3_C1                                     (0x0U)
#define MSB_PWMN_PWM3_C1                                     15
#define LSB_PWMN_PWM3_C1                                     0
#define AADDR_PWMN_PWM3_C1                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM3_C1)
#define REG_PWMN_PWM3_C1                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM3_C1))

#define ADDR_PWMN_PWM3_ON                                    (0x56U)
#define A_PWMN_PWM3_ON(ba)                                   ((ba) + ADDR_PWMN_PWM3_ON)
#define R_PWMN_PWM3_ON(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM3_ON(ba)))
#define RES_PWMN_PWM3_ON                                     (0x0U)
#define MSB_PWMN_PWM3_ON                                     1
#define LSB_PWMN_PWM3_ON                                     0
#define AADDR_PWMN_PWM3_ON                                   (BASE_ADDR_PWMN + ADDR_PWMN_PWM3_ON)
#define REG_PWMN_PWM3_ON                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM3_ON))

#define ADDR_PWMN_PWM3_C0_RELOAD                             (0x58U)
#define A_PWMN_PWM3_C0_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM3_C0_RELOAD)
#define R_PWMN_PWM3_C0_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM3_C0_RELOAD(ba)))
#define RES_PWMN_PWM3_C0_RELOAD                              (0x0U)
#define MSB_PWMN_PWM3_C0_RELOAD                              15
#define LSB_PWMN_PWM3_C0_RELOAD                              0
#define AADDR_PWMN_PWM3_C0_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM3_C0_RELOAD)
#define REG_PWMN_PWM3_C0_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM3_C0_RELOAD))

#define ADDR_PWMN_PWM3_C1_RELOAD                             (0x5AU)
#define A_PWMN_PWM3_C1_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM3_C1_RELOAD)
#define R_PWMN_PWM3_C1_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM3_C1_RELOAD(ba)))
#define RES_PWMN_PWM3_C1_RELOAD                              (0x0U)
#define MSB_PWMN_PWM3_C1_RELOAD                              15
#define LSB_PWMN_PWM3_C1_RELOAD                              0
#define AADDR_PWMN_PWM3_C1_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM3_C1_RELOAD)
#define REG_PWMN_PWM3_C1_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM3_C1_RELOAD))

#define ADDR_PWMN_PWM3_ON_RELOAD                             (0x5CU)
#define A_PWMN_PWM3_ON_RELOAD(ba)                            ((ba) + ADDR_PWMN_PWM3_ON_RELOAD)
#define R_PWMN_PWM3_ON_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_PWMN_PWM3_ON_RELOAD(ba)))
#define RES_PWMN_PWM3_ON_RELOAD                              (0x0U)
#define MSB_PWMN_PWM3_ON_RELOAD                              1
#define LSB_PWMN_PWM3_ON_RELOAD                              0
#define AADDR_PWMN_PWM3_ON_RELOAD                            (BASE_ADDR_PWMN + ADDR_PWMN_PWM3_ON_RELOAD)
#define REG_PWMN_PWM3_ON_RELOAD                              (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_PWM3_ON_RELOAD))

#define ADDR_PWMN_IRQ_STATUS                                 (0x70U)
#define A_PWMN_IRQ_STATUS(ba)                                ((ba) + ADDR_PWMN_IRQ_STATUS)
#define R_PWMN_IRQ_STATUS(ba)                                (*(volatile unsigned short *)((unsigned int)A_PWMN_IRQ_STATUS(ba)))
#define RES_PWMN_IRQ_STATUS                                  (0x0U)
#define MSB_PWMN_IRQ_STATUS                                  10
#define LSB_PWMN_IRQ_STATUS                                  0
#define AADDR_PWMN_IRQ_STATUS                                (BASE_ADDR_PWMN + ADDR_PWMN_IRQ_STATUS)
#define REG_PWMN_IRQ_STATUS                                  (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_IRQ_STATUS))

#define ADDR_PWMN_IRQ_MASK                                   (0x74U)
#define A_PWMN_IRQ_MASK(ba)                                  ((ba) + ADDR_PWMN_IRQ_MASK)
#define R_PWMN_IRQ_MASK(ba)                                  (*(volatile unsigned short *)((unsigned int)A_PWMN_IRQ_MASK(ba)))
#define RES_PWMN_IRQ_MASK                                    (0x0U)
#define MSB_PWMN_IRQ_MASK                                    10
#define LSB_PWMN_IRQ_MASK                                    0
#define AADDR_PWMN_IRQ_MASK                                  (BASE_ADDR_PWMN + ADDR_PWMN_IRQ_MASK)
#define REG_PWMN_IRQ_MASK                                    (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_IRQ_MASK))

#define ADDR_PWMN_IRQ_VENABLE                                (0x78U)
#define A_PWMN_IRQ_VENABLE(ba)                               ((ba) + ADDR_PWMN_IRQ_VENABLE)
#define R_PWMN_IRQ_VENABLE(ba)                               (*(volatile unsigned short *)((unsigned int)A_PWMN_IRQ_VENABLE(ba)))
#define RES_PWMN_IRQ_VENABLE                                 (0x0U)
#define MSB_PWMN_IRQ_VENABLE                                 3
#define LSB_PWMN_IRQ_VENABLE                                 0
#define AADDR_PWMN_IRQ_VENABLE                               (BASE_ADDR_PWMN + ADDR_PWMN_IRQ_VENABLE)
#define REG_PWMN_IRQ_VENABLE                                 (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_IRQ_VENABLE))

#define ADDR_PWMN_IRQ_VDISABLE                               (0x7AU)
#define A_PWMN_IRQ_VDISABLE(ba)                              ((ba) + ADDR_PWMN_IRQ_VDISABLE)
#define R_PWMN_IRQ_VDISABLE(ba)                              (*(volatile unsigned short *)((unsigned int)A_PWMN_IRQ_VDISABLE(ba)))
#define RES_PWMN_IRQ_VDISABLE                                (0x0U)
#define MSB_PWMN_IRQ_VDISABLE                                3
#define LSB_PWMN_IRQ_VDISABLE                                0
#define AADDR_PWMN_IRQ_VDISABLE                              (BASE_ADDR_PWMN + ADDR_PWMN_IRQ_VDISABLE)
#define REG_PWMN_IRQ_VDISABLE                                (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_IRQ_VDISABLE))

#define ADDR_PWMN_IRQ_VMAX                                   (0x7CU)
#define A_PWMN_IRQ_VMAX(ba)                                  ((ba) + ADDR_PWMN_IRQ_VMAX)
#define R_PWMN_IRQ_VMAX(ba)                                  (*(volatile unsigned short *)((unsigned int)A_PWMN_IRQ_VMAX(ba)))
#define RES_PWMN_IRQ_VMAX                                    (0xbU)
#define MSB_PWMN_IRQ_VMAX                                    3
#define LSB_PWMN_IRQ_VMAX                                    0
#define AADDR_PWMN_IRQ_VMAX                                  (BASE_ADDR_PWMN + ADDR_PWMN_IRQ_VMAX)
#define REG_PWMN_IRQ_VMAX                                    (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_IRQ_VMAX))

#define ADDR_PWMN_IRQ_VNO                                    (0x7EU)
#define A_PWMN_IRQ_VNO(ba)                                   ((ba) + ADDR_PWMN_IRQ_VNO)
#define R_PWMN_IRQ_VNO(ba)                                   (*(volatile unsigned short *)((unsigned int)A_PWMN_IRQ_VNO(ba)))
#define RES_PWMN_IRQ_VNO                                     (0xbU)
#define MSB_PWMN_IRQ_VNO                                     3
#define LSB_PWMN_IRQ_VNO                                     0
#define AADDR_PWMN_IRQ_VNO                                   (BASE_ADDR_PWMN + ADDR_PWMN_IRQ_VNO)
#define REG_PWMN_IRQ_VNO                                     (*(volatile unsigned short *)((unsigned int)AADDR_PWMN_IRQ_VNO))




#endif
