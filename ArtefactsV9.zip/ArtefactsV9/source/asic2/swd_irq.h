/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swd_irq.h
*
* @brief        SWD_PM HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __SWD_IRQ_H__
#define __SWD_IRQ_H__

#include "swd_bf.h"
#include "swd_types.h"

#define SWD_NUM_IRQS 36


/* ############################################################################ */
/**
 * \brief 
 *
 * \ingroup swd_pm 
 */ 
typedef enum{
  /**
   * PE was restarted by DPLL lock
   */ 
  SWD_IRQ_EVT_RESTART =               0,
  /**
   * PE start of cyclic frame (after successful CRC8)
   */ 
  SWD_IRQ_EVT_CYC_STARTED =           1,
  /**
   * PE start of acyclic frame with grant (after successful CRC8)
   */ 
  SWD_IRQ_EVT_GNT_STARTED =           2,
  /**
   * PE result FIFO not empty
   */ 
  SWD_IRQ_RESULT_NEMPTY =             3,
  /**
   * PE Status1 Module captured at least one request, e.g. acyclic transfer request
   */ 
  SWD_IRQ_STATUS1_REQ =               4,
  /**
   * PE Cyclic Successful Result Counter is zero
   */ 
  SWD_IRQ_CYC_RES_CNT_ZERO =          5,
  /**
   * PE Not replaced node ID available
   */ 
  SWD_IRQ_NOT_REPLACED_NEMPTY =       6,
  /**
   * DMA VCHANNEL_SIZES next Pointer FIFO not full
   */ 
  SWD_IRQ_SIZES_NEXT_NFULL =         16,
  /**
   * DMA VCHANNEL_SIZES last Pointer FIFO not empty
   */ 
  SWD_IRQ_SIZES_LAST_NEMPTY =        17,
  /**
   * DMA VCHANNEL_CYC_TX next Pointer FIFO not full
   */ 
  SWD_IRQ_CYC_TX_NEXT_NFULL =        18,
  /**
   * DMA VCHANNEL_CYC_TX next Pointer FIFO not full
   */ 
  SWD_IRQ_CYC_TX_LAST_NEMPTY =       19,
  /**
   * DMA VCHANNEL_CYC_RX next Pointer FIFO not full
   */ 
  SWD_IRQ_CYC_RX_NEXT_NFULL =        20,
  /**
   * DMA VCHANNEL_CYC_RX last Pointer FIFO not empty
   */ 
  SWD_IRQ_CYC_RX_LAST_NEMPTY =       21,
  /**
   * DMA VCHANNEL_AZY_TX next Pointer FIFO not full
   */ 
  SWD_IRQ_AZY_TX_NEXT_NFULL =        22,
  /**
   * DMA VCHANNEL_AZY_TX last Pointer FIFO not empty
   */ 
  SWD_IRQ_AZY_TX_LAST_NEMPTY =       23,
  /**
   * DMA VCHANNEL_AZY_RX_SAPA next Pointer FIFO not full
   */ 
  SWD_IRQ_AZY_RX_SAPA_NEXT_NFULL =   24,
  /**
   * DMA VCHANNEL_AZY_RX_SAPA last Pointer FIFO not empty
   */ 
  SWD_IRQ_AZY_RX_SAPA_LAST_NEMPTY =  25,
  /**
   * DMA VCHANNEL_AZY_RX_SAPB next Pointer FIFO not full
   */ 
  SWD_IRQ_AZY_RX_SAPB_NEXT_NFULL =   26,
  /**
   * DMA VCHANNEL_AZY_RX_SAPB last Pointer FIFO not empty
   */ 
  SWD_IRQ_AZY_RX_SAPB_LAST_NEMPTY =  27,
  /**
   * DMA VCHANNEL_AZY_RX_SAPC next Pointer FIFO not full
   */ 
  SWD_IRQ_AZY_RX_SAPC_NEXT_NFULL =   28,
  /**
   * DMA VCHANNEL_AZY_RX_SAPC last Pointer FIFO not empty
   */ 
  SWD_IRQ_AZY_RX_SAPC_LAST_NEMPTY =  29,
  /**
   * COMM bus0: became idle
   */ 
  SWD_IRQ_EVT_DPLL_IDLE_0 =          32,
  /**
   * COMM bus1: became idle
   */ 
  SWD_IRQ_EVT_DPLL_IDLE_1 =          33,
  /**
   * COMM bus0: DLL has locked (equal to restart)
   */ 
  SWD_IRQ_EVT_DPLL_LOCKED_0 =        34,
  /**
   * COMM bus1: DLL has locked (equal to restart)
   */ 
  SWD_IRQ_EVT_DPLL_LOCKED_1 =        35,
} swd_irq_t;


/* ############################################################################ */
/** 
 * \brief write UART_IRQ_MASK irq_mask register
 *
 * \param  uart_no  UART instance
 *
 * \param irq  specify interrupt
 *
 * \param enable enable interrupt
 */
void swd_enable_irq (swd_irq_t irq, bool enable);


/* ############################################################################ */
/**
 * \brief Clear SWD EVENTS
 *
 * \ingroup swd_pm 
 * 
 * \param irq 
 */ 
void swd_clear_irq (swd_irq_t irq);


/* ############################################################################ */
/**
 * \brief Next pending IRQ
 *
 * \ingroup swd_pm 
 * 
 * \return number of highest priority non masked interrupt <br>
 *         highest priority no = 0 <br>
 *         first unused number: no irq pending <br>
 *          <br>
 *         IRQ_NO ASSIGNMENT: <br>
 *          0 ... 15 IRQ_MASK_PE <br>
 *         16 ... 31 IRQ_MASK_DMA <br>
 *         32 ... 47 IRQ_MASK_COMM <br>
 */ 
swd_irq_t swd_get_next_pending_irq (void);


/* ############################################################################ */
/** 
 * \brief Get SWD IRQ status
 *
 * \ingroup swd_pm 
 * 
 * \param irq_status IRQ status
 */ 
void swd_get_irq_status (swd_irq_status_t * irq_status);

#endif
