/* FPGA Release: 10512 */
#include "cctimer32.h"

void cctimer32_set_prescaler(cctimer32_num_t timer, cctimer32_prescaler_sel_t sel, uint8_t prescaler, uint8_t reload) {
  uint32_t adr;
  uint16_t val = reload;
  val = (val << 8) | prescaler;
  
  if (timer == CCTIMER0) 
    adr = (sel == CCTIMER32_AB)? AADDR_CCTIMER0_PS_AB : AADDR_CCTIMER0_PS_CD;
  else
    adr = (sel == CCTIMER32_AB)? AADDR_CCTIMER1_PS_AB : AADDR_CCTIMER1_PS_CD;
  
  WRITE_REG_16(adr, val);
}

uint16_t cctimer32_get_ps_ab(cctimer32_num_t timer, cctimer32_prescaler_sel_t sel) {
  uint32_t adr;
  
  if (timer == CCTIMER0) 
    adr = (sel == CCTIMER32_AB)? AADDR_CCTIMER0_PS_AB : AADDR_CCTIMER0_PS_CD;
  else
    adr = (sel == CCTIMER32_AB)? AADDR_CCTIMER1_PS_AB : AADDR_CCTIMER1_PS_CD;
  
  return READ_REG_U16(adr);
}

void cctimer32_set_pre_reload(cctimer32_num_t timer, cctimer32_prescaler_sel_t sel, uint8_t reload) {
  uint32_t adr;
  
  if (timer == CCTIMER0) 
    adr = (sel == CCTIMER32_AB)? AADDR_CCTIMER0_PSR_AB : AADDR_CCTIMER0_PSR_CD;
  else
    adr = (sel == CCTIMER32_AB)? AADDR_CCTIMER1_PSR_AB : AADDR_CCTIMER1_PSR_CD;
  
  WRITE_REG_16(adr, reload);
}

void cctimer32_set_control(cctimer32_num_t timer,
  bool enable_a, bool enable_b, bool enable_c, bool enable_d,
  bool restart_a, bool restart_b, bool restart_c, bool restart_d, bool restart_ps_ab, bool restart_ps_cd,
  bool read_sync_c, bool read_sync_d, bool write_sync_c, bool write_sync_d) {

  uint16_t val = 0;
  
  if (enable_a)      val |= 1 <<  0;
  if (enable_b)      val |= 1 <<  1;
  if (enable_c)      val |= 1 <<  2;
  if (enable_d)      val |= 1 <<  3;
  if (restart_a)     val |= 1 <<  4;
  if (restart_b)     val |= 1 <<  5;
  if (restart_c)     val |= 1 <<  6;
  if (restart_d)     val |= 1 <<  7;
  if (restart_ps_ab) val |= 1 <<  8;
  if (restart_ps_cd) val |= 1 <<  9;
  if (read_sync_c)   val |= 1 << 10;
  if (read_sync_d)   val |= 1 << 11;
  if (write_sync_c)  val |= 1 << 12;
  if (write_sync_d)  val |= 1 << 13;
  
  //uint32_t adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONTROL : AADDR_CCTIMER1_CONTROL;
  WRITE_REG_16(timer + ADDR_CCTIMER32_CONTROL, val);
}

void cctimer32_set_config_global(cctimer32_num_t timer,
  bool ab_16_32, bool cd_16_32, bool sync_en_c, bool sync_en_d,
  cctimer32_pwm_mode_t pwm_ab, cctimer32_pwm_mode_t pwm_cd,
  bool ps_disable_ab) {

  uint16_t val = 0;
  
  if (ab_16_32)      val |= 1 <<  0;
  if (cd_16_32)      val |= 1 <<  2;
  if (sync_en_c)     val |= 1 <<  1;
  if (sync_en_d)     val |= 1 <<  3;
  if (ps_disable_ab) val |= 1 <<  8;
  val |= pwm_ab << 4;
  val |= pwm_cd << 6;
  
  //uint32_t adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG : AADDR_CCTIMER1_CONFIG;
  WRITE_REG_16(timer + ADDR_CCTIMER32_CONFIG, val);
}

void cctimer32_set_config_ed(cctimer32_num_t timer,
  bool inv_a, bool inv_b, bool inv_zm, bool inv_gate,
  bool swap_ab, cctimer32_ed_format_t format, cctimer32_ed_gate_t gate) {

  uint16_t val = 0;
  
  if (inv_a)    val |= 1 <<  0;
  if (inv_b)    val |= 1 <<  1;
  if (inv_zm)   val |= 1 <<  2;
  if (inv_gate) val |= 1 <<  3;
  if (swap_ab)  val |= 1 <<  4;
  val |= format << 5;
  val |=   gate << 8;
  
  //uint32_t adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_ED : AADDR_CCTIMER1_CONFIG_ED;
  WRITE_REG_16(timer + ADDR_CCTIMER32_CONFIG_ED, val);
}

void cctimer32_set_config(cctimer32_num_t timer, cctimer32_timer_sel_t sel, 
  cctimer32_conf_counter_sel_t counter_sel, cctimer32_conf_counter_act_t counter_act,
  cctimer32_conf_restart_sel_t restart_sel, cctimer32_conf_restart_act_t restart_act,
  cctimer32_conf_cc_sel_t cc_sel, cctimer32_conf_cc_act_t cc_act,
  cctimer32_conf_mode_t mode) {
  
  uint32_t adr = 0;
  uint16_t val = 0;
  
  switch (sel) {
    case CCTIMER32_A :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_A : AADDR_CCTIMER1_CONFIG_A; break;
    case CCTIMER32_B :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_B : AADDR_CCTIMER1_CONFIG_B; break;
    case CCTIMER32_C :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_C : AADDR_CCTIMER1_CONFIG_C; break;
    case CCTIMER32_D :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_D : AADDR_CCTIMER1_CONFIG_D; break;
  }
  
  val |= counter_sel <<  0;
  val |= counter_act <<  3;
  val |= restart_sel <<  4;
  val |= restart_act <<  8;
  val |=      cc_sel <<  9;
  val |=      cc_act << 13;
  val |=        mode << 14;
  
  WRITE_REG_16(adr, val);
}

cctimer32_compr_conf_t cctimer32_convert_compr_config(cctimer32_num_t timer, cctimer32_timer_sel_t sel, 
  cctimer32_conf_counter_sel_t counter_sel, cctimer32_conf_counter_act_t counter_act,
  cctimer32_conf_restart_sel_t restart_sel, cctimer32_conf_restart_act_t restart_act,
  cctimer32_conf_cc_sel_t cc_sel, cctimer32_conf_cc_act_t cc_act,
  cctimer32_conf_mode_t mode) {
  
  uint32_t adr = 0;
  uint16_t val = 0;
  
  switch (sel) {
    case CCTIMER32_A :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_A : AADDR_CCTIMER1_CONFIG_A; break;
    case CCTIMER32_B :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_B : AADDR_CCTIMER1_CONFIG_B; break;
    case CCTIMER32_C :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_C : AADDR_CCTIMER1_CONFIG_C; break;
    case CCTIMER32_D :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_D : AADDR_CCTIMER1_CONFIG_D; break;
  }
  
  val |= counter_sel <<  0;
  val |= counter_act <<  3;
  val |= restart_sel <<  4;
  val |= restart_act <<  8;
  val |=      cc_sel <<  9;
  val |=      cc_act << 13;
  val |=        mode << 14;
  
  cctimer32_compr_conf_t temp;
  temp.addr   = adr;
  temp.value  = val;
  
  return temp;
}

void cctimer_set_compr_config(cctimer32_compr_conf_t compr_config) {
  WRITE_REG_16(compr_config.addr, compr_config.value);
}

void cctimer_set_intf_thresholds(cctimer32_num_t timer, uint8_t intf_ab, uint8_t intf_zm_gate, uint16_t intf_clk_div) {
  uint16_t temp = intf_zm_gate;
  WRITE_REG_16(timer + ADDR_CCTIMER32_CFG_INTF, (temp << SFT_CCTIMER32_CFG_INTF_ZM_GATE) | intf_ab);
  WRITE_REG_16(timer + ADDR_CCTIMER32_CFG_INTF_PRE, intf_clk_div);
}

cctimer32_compr_conf_t cctimer_get_compr_config(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  uint32_t adr = 0;
  
  switch (sel) {
    case CCTIMER32_A :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_A : AADDR_CCTIMER1_CONFIG_A; break;
    case CCTIMER32_B :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_B : AADDR_CCTIMER1_CONFIG_B; break;
    case CCTIMER32_C :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_C : AADDR_CCTIMER1_CONFIG_C; break;
    case CCTIMER32_D :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CONFIG_D : AADDR_CCTIMER1_CONFIG_D; break;
  }

  cctimer32_compr_conf_t temp;
  temp.addr   = adr;
  temp.value  = READ_REG_U16(adr);
  
  return temp;
}

void cctimer32_set_capcmp(cctimer32_num_t timer, cctimer32_timer_sel_t sel, uint16_t val) {
  uint32_t adr = 0;
  
  switch (sel) {
    case CCTIMER32_A :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CAPCMP_A : AADDR_CCTIMER1_CAPCMP_A; break;
    case CCTIMER32_B :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CAPCMP_B : AADDR_CCTIMER1_CAPCMP_B; break;
    case CCTIMER32_C :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CAPCMP_C : AADDR_CCTIMER1_CAPCMP_C; break;
    case CCTIMER32_D :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CAPCMP_D : AADDR_CCTIMER1_CAPCMP_D; break;
  }
  
  WRITE_REG_16(adr, val);
}

uint16_t cctimer32_get_capcmp(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  uint32_t adr = 0;
  
  switch (sel) {
    case CCTIMER32_A :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CAPCMP_A : AADDR_CCTIMER1_CAPCMP_A; break;
    case CCTIMER32_B :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CAPCMP_B : AADDR_CCTIMER1_CAPCMP_B; break;
    case CCTIMER32_C :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CAPCMP_C : AADDR_CCTIMER1_CAPCMP_C; break;
    case CCTIMER32_D :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_CAPCMP_D : AADDR_CCTIMER1_CAPCMP_D; break;
  }
  
  return READ_REG_U16(adr);
}

uint16_t cctimer32_get_counter(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  uint32_t adr = 0;
  
  switch (sel) {
    case CCTIMER32_A :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_COUNTER_A : AADDR_CCTIMER1_COUNTER_A; break;
    case CCTIMER32_B :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_COUNTER_B : AADDR_CCTIMER1_COUNTER_B; break;
    case CCTIMER32_C :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_COUNTER_C : AADDR_CCTIMER1_COUNTER_C; break;
    case CCTIMER32_D :
      adr = (timer == CCTIMER0)? AADDR_CCTIMER0_COUNTER_D : AADDR_CCTIMER1_COUNTER_D; break;
  }
  
  return READ_REG_U16(adr);
}

bool cctimer32_is_irq_pos(cctimer32_num_t timer, uint8_t pos) {
  //uint32_t adr;
  uint16_t val;
  //adr = (timer == CCTIMER0)? AADDR_CCTIMER0_IRQ_STATUS : AADDR_CCTIMER1_IRQ_STATUS;
  val = READ_REG_U16(timer + ADDR_CCTIMER32_IRQ_STATUS);
  return ((val & (1 << pos)) != 0) ? true : false;
}

uint16_t cctimer32_get_irqs(cctimer32_num_t timer) {
  //uint32_t adr = (timer == CCTIMER0)? AADDR_CCTIMER0_IRQ_STATUS : AADDR_CCTIMER1_IRQ_STATUS;
  return READ_REG_U16(timer + ADDR_CCTIMER32_IRQ_STATUS);
}

bool cctimer32_is_overflow(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  return cctimer32_is_irq_pos(timer,sel);
}

bool cctimer32_is_restart(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  return cctimer32_is_irq_pos(timer,sel + 4);
}

bool cctimer32_is_capture(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  return cctimer32_is_irq_pos(timer,sel + 8);
}

bool cctimer32_is_zm(cctimer32_num_t timer) {
  return cctimer32_is_irq_pos(timer,12);
}

bool cctimer32_is_dir_change(cctimer32_num_t timer) {
  return cctimer32_is_irq_pos(timer,13);
}

bool cctimer32_is_pos_change(cctimer32_num_t timer) {
  return cctimer32_is_irq_pos(timer,14);
}

bool cctimer32_is_ab_error(cctimer32_num_t timer) {
  return cctimer32_is_irq_pos(timer,15);
}

void cctimer32_clear_irq_pos(cctimer32_num_t timer, uint8_t pos) {
  //uint32_t adr = (timer == CCTIMER0)? AADDR_CCTIMER0_IRQ_STATUS : AADDR_CCTIMER1_IRQ_STATUS;
  WRITE_REG_16(timer + ADDR_CCTIMER32_IRQ_STATUS, 1 << pos);
}

void cctimer32_clear_all_irqs(cctimer32_num_t timer) {
  //uint32_t adr = (timer == CCTIMER0)? AADDR_CCTIMER0_IRQ_STATUS : AADDR_CCTIMER1_IRQ_STATUS;
  WRITE_REG_16(timer + ADDR_CCTIMER32_IRQ_STATUS, 0xFFFF);
}

void cctimer32_clear_overflow(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  cctimer32_clear_irq_pos(timer, sel);
}

void cctimer32_clear_restart(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  cctimer32_clear_irq_pos(timer, sel + 4);
}

void cctimer32_clear_capture(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  cctimer32_clear_irq_pos(timer, sel + 8);
}

void cctimer32_clear_zm(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  cctimer32_clear_irq_pos(timer, 12);
}

void cctimer32_clear_dir_change(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  cctimer32_clear_irq_pos(timer, 13);
}

void cctimer32_clear_pos_change(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  cctimer32_clear_irq_pos(timer, 14);
}

void cctimer32_clear_ab_error(cctimer32_num_t timer, cctimer32_timer_sel_t sel) {
  cctimer32_clear_irq_pos(timer, 15);
}

void cctimer32_set_irq_mask(cctimer32_num_t timer, uint16_t mask) {
  //uint32_t adr = (timer == CCTIMER0)? AADDR_CCTIMER0_IRQ_MASK : AADDR_CCTIMER1_IRQ_MASK;
  WRITE_REG_16(timer + ADDR_CCTIMER32_IRQ_MASK, mask);
}

uint16_t cctimer32_get_irq_mask(cctimer32_num_t timer) {
  //uint32_t adr = (timer == CCTIMER0)? AADDR_CCTIMER0_IRQ_MASK : AADDR_CCTIMER1_IRQ_MASK;
  return READ_REG_U16(timer + ADDR_CCTIMER32_IRQ_MASK);
}

cctimer32_irq_status_t cctimer32_get_irq_status(cctimer32_num_t timer){
  cctimer32_irq_status_t cctimer32_irq_status;
  cctimer32_irq_status.val = READ_REG_U16(timer + ADDR_CCTIMER32_IRQ_STATUS);
  return cctimer32_irq_status;
}
