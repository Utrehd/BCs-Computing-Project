/* FPGA Release: 10512 */
#include "usi_uart.h"
#include "sram.h"
#include "stdio.h"

#define BUFFER_RX_COUNT 2
#define BUFFER_RX_BYTES 1

#define BUFFER_TX_COUNT 2
#define BUFFER_TX_BYTES 1

typedef struct {
  volatile usi_dma_rxcfg_t rx_config[BUFFER_RX_COUNT];
  volatile usi_dma_txcfg_t tx_config[BUFFER_TX_COUNT];
  volatile uint8_t rx_buffer[BUFFER_RX_COUNT];
  volatile uint8_t tx_buffer[BUFFER_TX_COUNT];
  uint8_t rx_sel;
  uint8_t tx_sel;
} usi_uart_struct_t;


static usi_uart_struct_t usi_uart_struct[NUMBER_USI];

void usi_uart_prepare_dma(usi_num_t usi_no);

void usi_uart_init(usi_num_t usi_no){
  uint8_t usi = usi_no_to_index(usi_no);
  uint8_t i;
  usi_clear_revents(usi_no);
  usi_uart_struct[usi].rx_sel=0;
  usi_uart_struct[usi].tx_sel=0;
//printf("\r\n");
  for (i=0; i<BUFFER_RX_COUNT; i++){
    usi_uart_struct[usi].rx_config[i].maxlen = BUFFER_RX_BYTES;
    usi_uart_struct[usi].rx_config[i].rdadr = (uint16_t)((uint32_t)&(usi_uart_struct[usi].rx_buffer[i]));
//printf("rx %d data:@0x%X conf:@0x%X ccpu\r\n", i, usi_uart_struct[usi].rx_config[i].rdadr, (uint16_t) &(usi_uart_struct[usi].rx_config[i]));
  }
  for (i=0; i<BUFFER_TX_COUNT; i++){
    usi_uart_struct[usi].tx_config[i].tdadr = (uint16_t)((uint32_t)&(usi_uart_struct[usi].tx_buffer[i]));
//printf("tx %d data:@0x%X conf:@0x%X ccpu\r\n", i, usi_uart_struct[usi].tx_config[i].tdadr, (uint16_t) &(usi_uart_struct[usi].tx_config[i]));
  }
}

//=======================================================================
// config
//=======================================================================
void usi_uart_cfg_half_duplex(usi_num_t usi_no, usi_cfg_u_half_duplex_t cfg){
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_HALF_DUPLEX, cfg.val);
}

void usi_uart_cfg_msb_first(usi_num_t usi_no, usi_uart_bit_order_t i_usi_bit_order){
  usi_cfg_u_bl_t usi_cfg_u_bl;
  usi_cfg_u_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_U_BL);
  usi_cfg_u_bl.bf.msb_first = i_usi_bit_order;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_BL, usi_cfg_u_bl.val);
}

void usi_uart_cfg_data_bits(usi_num_t usi_no, usi_uart_data_len_t data_bits){
  usi_cfg_u_bl_t usi_cfg_u_bl;
  usi_cfg_u_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_U_BL);
  usi_cfg_u_bl.bf.data_bits = data_bits;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_BL, usi_cfg_u_bl.val);
}

void usi_uart_cfg_stop_bits(usi_num_t usi_no, usi_uart_stop_bit_t stop_bits){
  usi_cfg_u_bl_t usi_cfg_u_bl;
  usi_cfg_u_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_U_BL);
  usi_cfg_u_bl.bf.stop_bits = stop_bits;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_BL, usi_cfg_u_bl.val);
}

void usi_uart_cfg_parity(usi_num_t usi_no, usi_uart_parity_t parity){
  usi_cfg_u_bl_t usi_cfg_u_bl;
  usi_cfg_u_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_U_BL);
  usi_cfg_u_bl.bf.par_type = parity;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_BL, usi_cfg_u_bl.val);
}

void usi_uart_cfg_start_threshold(usi_num_t usi_no, uint16_t start_threshold){
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_START_THRESHOLD, start_threshold);
}

void usi_uart_cfg_data_sampling(usi_num_t usi_no, uint16_t data_start, uint16_t data_length){
  usi_cfg_u_tick_t usi_cfg_u_tick;
  usi_cfg_u_tick.val = READ_REG_U16(usi_no + ADDR_USI_CFG_U_TICK);
  usi_cfg_u_tick.bf.rx_start = data_start;
  usi_cfg_u_tick.bf.rx_len = data_length;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_TICK, usi_cfg_u_tick.val);
}

void usi_uart_cfg_break_tx_len(usi_num_t usi_no, uint8_t len){
  usi_cfg_u_bl_t usi_cfg_u_bl;
  usi_cfg_u_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_U_BL);
  usi_cfg_u_bl.bf.break_tx_len = len;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_BL, usi_cfg_u_bl.val);
}

void usi_uart_cfg_break_rx_thr(usi_num_t usi_no, uint8_t thr){
  usi_cfg_u_bl_t usi_cfg_u_bl;
  usi_cfg_u_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_U_BL);
  usi_cfg_u_bl.bf.break_rx_thr = thr;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_BL, usi_cfg_u_bl.val);
}

void usi_uart_cfg_break_conc(usi_num_t usi_no, bool conc){
  usi_cfg_u_bl_t usi_cfg_u_bl;
  usi_cfg_u_bl.val = READ_REG_U16(usi_no + ADDR_USI_CFG_U_BL);
  usi_cfg_u_bl.bf.break_conc = conc;
  WRITE_REG_16(usi_no + ADDR_USI_CFG_U_BL, usi_cfg_u_bl.val);
}

//=======================================================================
// helper wrapper
//=======================================================================
void usi_uart_cfg_bit_length(usi_num_t usi_no, uint16_t bit_length){
  usi_cfg_tick_bit_length(usi_no, bit_length);
  usi_uart_cfg_data_sampling(usi_no, bit_length >> 2, bit_length >> 1);
}

//=======================================================================
// simple usage DMA wrapper
//=======================================================================
void usi_uart_send_byte_tcfg (usi_num_t usi_no, uint8_t data, uint8_t tcfg, uint8_t len) {
  uint8_t usi = usi_no_to_index(usi_no);
  uint8_t tx_sel = usi_uart_struct[usi].tx_sel;
  usi_uart_struct[usi].tx_buffer[tx_sel] = data;  
  usi_uart_struct[usi].tx_config[tx_sel].tcfg  = tcfg;
  usi_uart_struct[usi].tx_config[tx_sel].tdlen = len;
  usi_uart_prepare_recv_dma(usi_no);
  usi_dma_send_frame(usi_no, false, (usi_dma_txcfg_t*) &(usi_uart_struct[usi].tx_config[tx_sel]) );
  usi_uart_struct[usi].tx_sel++;
  usi_uart_struct[usi].tx_sel %= BUFFER_TX_COUNT;
}

void usi_uart_send_byte (usi_num_t usi_no, uint8_t data) {
  usi_uart_send_byte_tcfg(usi_no, data, 0, 1);
}

void usi_uart_prepare_recv_dma(usi_num_t usi_no){
  uint8_t usi = usi_no_to_index(usi_no);
  while (usi_dma_provide_rxcfg(usi_no, &(usi_uart_struct[usi].rx_config[ usi_uart_struct[usi].rx_sel ]), false)) {
      usi_uart_struct[usi].rx_sel++;
      usi_uart_struct[usi].rx_sel %= BUFFER_RX_COUNT;
  }
}

bool usi_uart_recv_byte (usi_num_t usi_no, uint8_t *data){
  uint8_t * data_ptr;
  usi_uart_prepare_recv_dma(usi_no);
  uint16_t len;
  if (usi_dma_get_rx_data(usi_no, (void*) &data_ptr, &len) && len){
    *data = data_ptr[0];
    return true;
  }
  return false;
}
