/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         vic_ext.h
*
* @brief        External Processor Interrupt Controller (VIC_EXT) HAL functions
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_VIC_EXT_H
#define HAVE_VIC_EXT_H

/**
 * \example example_vic_ext.c
 * This is an example of how to use CRC block.
 */

/**
 * \defgroup vic_ext ASIC2 External Processor Interrupt Controller (VIC_EXT)
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control External Processor Interrupt Controller (VIC_EXT)
 *
 * \details See code example: @include example_vic_ext.c
 */
/**@{*/ 


#include "device.h"
#include "vic_ext_bf.h"
#include "vic_ext_irq.h"

/* ############################################################################ */
/**
 * \brief Enables main interrupt in VIC_EXT
 *
 * \ingroup vic_ext
 * 
 * \param main_enable main interrupt enable / disable
 * 
 */
void vic_ext_main_enable(bool main_enable);

/* ############################################################################ */
/**
 * \brief Set the polarity of interrupt request signal
 *
 * \ingroup vic_ext
 * 
 * \param polarity 0: high indicates interrupt request <br>
 *                 1: low indicates interrupt request <br>s
 * 
 */
void vic_ext_set_polarity(uint8_t polarity);

/* ############################################################################ */
/**
 * \brief Enables irq source
 *
 * \ingroup vic_ext
 * 
 * \param irq_number number of interrupt which should be enabled
 *
 */
void vic_ext_irq_enable(vic_ext_irq_t irq_number);

/* ############################################################################ */
/**
 * \brief Disables irq source
 *
 *
 * \ingroup vic_ext
 * 
 * \param irq_number number of interrupt which should be disabled
 *
 */
void vic_ext_irq_disable(vic_ext_irq_t irq_number);


/**@} */
#endif /* HAVE_VIC_H */


