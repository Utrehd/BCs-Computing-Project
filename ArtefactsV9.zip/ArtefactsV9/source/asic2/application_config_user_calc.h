/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         application_config_clock_calc.h
*
* @brief        Macros definition and checks for application_config.c (clock part)
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#include "flash_ctrl.h" // there is definition of FLASH_CTRL_ACCESS_TIME_* macros which are used here in application_config_clock_calc.h

//#include <device_settings.h> (it should be include in project settings)

//
// DO NOT MODIFY THIS CODE IN APPLICATION
//
#ifndef _APPLICATION_CONFIG_CLOCK_CALC_H_
#define _APPLICATION_CONFIG_CLOCK_CALC_H_

/* General defines */
#define DISPLAY_VALUE2(x) #x
#define DISPLAY_VALUE(x) DISPLAY_VALUE2(x)

// BOOTLOADER


#ifdef APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P

  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "======================================================")
    #pragma message( "PIN " DISPLAY_VALUE(APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P) " IS USED TO ENTRY BOOTLOADER MODE")
  #endif

  #if   ((APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P >=  0) && (APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P <=  8))
    #define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_GROUP 0x00
  #elif ((APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P >=  9) && (APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P <= 17))
    #define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_GROUP 0x01
  #elif ((APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P >= 18) && (APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P <= 26))
    #define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_GROUP 0x02    
  #elif ((APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P >= 27) && (APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P <= 35))
    #define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_GROUP 0x03
  #endif
  
  #define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_PIN_MASK (1<<((APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P)%(9)))

  #ifdef __IAR_SYSTEMS_ICC__
  //  #pragma message( "GRP " DISPLAY_VALUE(APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_GROUP))
  //  #pragma message( "MASK " DISPLAY_VALUE(APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_PIN_MASK))
    #pragma message( "======================================================")  
  #endif

#else
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "======================================================")
    #pragma message( "NO PIN TO ENTRY BOOTLOADER MODE")
    #pragma message( "======================================================")  
  #endif  
  
  #define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_PIN_MASK   0x00
  #define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_GROUP      0xFF
  #define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_VALUE         0
#endif


// power of CLK_NRES_PLL_OD 
#if CLK_NRES_PLL_OD == 0
  #define CLK_NRES_POWER_OD_DIV 1
#elif  CLK_NRES_PLL_OD == 1
  #define CLK_NRES_POWER_OD_DIV 2
#elif  CLK_NRES_PLL_OD == 2
  #define CLK_NRES_POWER_OD_DIV 4
#elif  CLK_NRES_PLL_OD == 3
  #define CLK_NRES_POWER_OD_DIV 8
#endif


/* clock frequencies defines */
#define CLK_NRES_RCOSC_HF_CLK_FREQ_HZ  16000000UL // [Hz]
#define CLK_NRES_RCOSC_LF_CLK            810000UL // [Hz]



/* clock source defines */
#define M_CLOCK_SOURCE_RCOSC_HF   0
#define M_CLOCK_SOURCE_RCOSC_LF   1
#define M_CLOCK_SOURCE_QOSC       2
#define M_CLOCK_SOURCE_PLL        3

/* peripherals defines */
#define FULL_RATE  0
#define HIGH_RATE  1
#define LOW_RATE_0 2
#define LOW_RATE_1 3


//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// PLL
//


//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//#define CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC
#if  CLK_NRES_PLL_FIN_CLK_SRC  == CLK_NRES_RCOSC_SOURCE_FOR_PLL
  #define APPL_CFG_CLK_NRES_RCOSC_HF_IS_USED
  #define CLK_NRES_PLL_FIN_FREQ_HZ    CLK_NRES_RCOSC_HF_CLK_FREQ_HZ

#elif CLK_NRES_PLL_FIN_CLK_SRC == CLK_NRES_QOSC_SOURCE_FOR_PLL
  #define APPL_CFG_CLK_NRES_QOSC_IS_USED
  #define CLK_NRES_PLL_FIN_FREQ_HZ    CLK_NRES_QOSC_CLK_FREQ_HZ
#else
  #error "CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC:wrong settings"
#endif 

// NR-DIV - INPUT DIVIDER - Comparison Frequency
#define CLK_NRES_PLL_FCMP_FREQ_HZ     ((CLK_NRES_PLL_FIN_FREQ_HZ)/(CLK_NRES_PLL_NR+1))

// VCO output
#define CLK_NRES_PLL_VCO_FREQ_HZ      ((CLK_NRES_PLL_FCMP_FREQ_HZ)*(CLK_NRES_PLL_NF+1))

// OD-DIV - OUTPUT DIVIDER
#define CLK_NRES_PLL_FOUT_FREQ_HZ     ((CLK_NRES_PLL_VCO_FREQ_HZ)/(CLK_NRES_POWER_OD_DIV))



#define MIN_CLK_NRES_PLL_FIN_FREQ_HZ      4000000 // [Hz]
#define MAX_CLK_NRES_PLL_FIN_FREQ_HZ     50000000 // [Hz]


#define MIN_CLK_NRES_PLL_FCMP_FREQ_HZ     4000000 // [Hz]
#define MAX_CLK_NRES_PLL_FCMP_FREQ_HZ    25000000 // [Hz]


#define MIN_CLK_NRES_PLL_VCO_FREQ_HZ     50000000 // [Hz]
#define MAX_CLK_NRES_PLL_VCO_FREQ_HZ    100000000 // [Hz]


#if ((CLK_NRES_PLL_NF < 0) || (CLK_NRES_PLL_NF > 31))
  #error "feedback bit divider for PLL is out of limits (CLK_NRES_PLL_NF)! Please, change it in application_config_clock.h"
#endif

#if ((CLK_NRES_PLL_NR < 0) || (CLK_NRES_PLL_NR > 7))
  #error "input divider for PLL is out of limits (CLK_NRES_PLL_NR)! Please, change it in application_config_clock.h"
#endif

#if ((CLK_NRES_PLL_OD < 0) || (CLK_NRES_PLL_OD > 3))
  #error "output divider for PLL is out of limits (CLK_NRES_PLL_OD)! Please, change it in application_config_clock.h"
#endif

//------------------------------------------------------------------------------
//-- PLL FIN CHECK -------------------------------------------------------------
//------------------------------------------------------------------------------
#if CLK_NRES_PLL_FIN_FREQ_HZ < MIN_CLK_NRES_PLL_FIN_FREQ_HZ
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    #pragma message( "Fin = " DISPLAY_VALUE(CLK_NRES_PLL_FIN_FREQ_HZ) " Hz < " DISPLAY_VALUE(MIN_CLK_NRES_PLL_FIN_FREQ_HZ) " Hz")
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  #endif
  #error "Input frequency for PLL (CLK_NRES_PLL_FIN_FREQ_HZ) is out of LOW limit!" 
#endif

#if CLK_NRES_PLL_FIN_FREQ_HZ > MAX_CLK_NRES_PLL_FIN_FREQ_HZ
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    #pragma message( "Fin = " DISPLAY_VALUE(CLK_NRES_PLL_FIN_FREQ_HZ) " Hz > " DISPLAY_VALUE(MAX_CLK_NRES_PLL_FIN_FREQ_HZ) " Hz")
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  #endif
  #error "Input frequency for PLL (CLK_NRES_PLL_FIN_FREQ_HZ) is out of HIGH limit!" 
#endif

//------------------------------------------------------------------------------
//-- PLL_FCMP CHECK -------------------------------------------------------------
//------------------------------------------------------------------------------
#if CLK_NRES_PLL_FCMP_FREQ_HZ < MIN_CLK_NRES_PLL_FCMP_FREQ_HZ
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    #pragma message( "Fin = " DISPLAY_VALUE(CLK_NRES_PLL_FCMP_FREQ_HZ) " Hz < " DISPLAY_VALUE(MIN_CLK_NRES_PLL_FCMP_FREQ_HZ) " Hz")
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  #endif
  #error "Input frequency for PLL (CLK_NRES_PLL_FCMP_FREQ_HZ) is out of LOW limit!" 
#endif

#if CLK_NRES_PLL_FCMP_FREQ_HZ > MAX_CLK_NRES_PLL_FCMP_FREQ_HZ
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    #pragma message( "Fin = " DISPLAY_VALUE(CLK_NRES_PLL_FCMP_FREQ_HZ) " Hz > " DISPLAY_VALUE(MAX_CLK_NRES_PLL_FCMP_FREQ_HZ) " Hz")
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  #endif
  #error "Input frequency for PLL (CLK_NRES_PLL_FCMP_FREQ_HZ) is out of HIGH limit!" 
#endif

//------------------------------------------------------------------------------
//-- PLL_VCO CHECK -------------------------------------------------------------
//------------------------------------------------------------------------------
#if CLK_NRES_PLL_VCO_FREQ_HZ < MIN_CLK_NRES_PLL_VCO_FREQ_HZ
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    #pragma message( "Fin = " DISPLAY_VALUE(CLK_NRES_PLL_VCO_FREQ_HZ) " Hz < " DISPLAY_VALUE(MIN_CLK_NRES_PLL_VCO_FREQ_HZ) " Hz")
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  #endif
  #error "Input frequency for PLL (CLK_NRES_PLL_VCO_FREQ_HZ) is out of LOW limit!" 
#endif

#if CLK_NRES_PLL_VCO_FREQ_HZ > MAX_CLK_NRES_PLL_VCO_FREQ_HZ
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    #pragma message( "Fin = " DISPLAY_VALUE(CLK_NRES_PLL_VCO_FREQ_HZ) " Hz > " DISPLAY_VALUE(MAX_CLK_NRES_PLL_VCO_FREQ_HZ) " Hz")
    #pragma message( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  #endif
  #error "Input frequency for PLL (CLK_NRES_PLL_VCO_FREQ_HZ) is out of HIGH limit!" 
#endif







//
//------------------------------------------------------------------------------
//
//#define CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC
#if  CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC  == M_CLOCK_SOURCE_RCOSC_HF
  #define APPL_CFG_CLK_NRES_RCOSC_HF_IS_USED
  #define CLK_NRES_CFG_AS0_SWD_TSU_FREQ_HZ_TMP    CLK_NRES_RCOSC_HF_CLK_FREQ_HZ

#elif CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC == M_CLOCK_SOURCE_QOSC
  #define APPL_CFG_CLK_NRES_QOSC_IS_USED
  #define CLK_NRES_CFG_AS0_SWD_TSU_FREQ_HZ_TMP    CLK_NRES_QOSC_CLK_FREQ_HZ

#elif CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC == M_CLOCK_SOURCE_PLL
  #define CLK_NRES_CFG_AS0_SWD_TSU_FREQ_HZ_TMP    CLK_NRES_PLL_FOUT_FREQ_HZ
  #define APPL_CFG_CLK_NRES_PLL_ENABLE

#elif CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC == M_CLOCK_SOURCE_RCOSC_LF
  #define CLK_NRES_CFG_AS0_SWD_TSU_FREQ_HZ_TMP    CLK_NRES_RCOSC_LF_CLK
#else
  #error "CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC:wrong settings"
#endif 
// AS1 divider
#define CLK_NRES_AS0_SWD_TSU_FREQ_HZ   ((CLK_NRES_CFG_AS0_SWD_TSU_FREQ_HZ_TMP)/(CLK_NRES_CFG_AS0_SWD_TSU_CLK_DIV))
//
//------------------------------------------------------------------------------
//
//#define CLK_NRES_CFG_AS1_USI0_CLK_SRC
#if  CLK_NRES_CFG_AS1_USI0_CLK_SRC  == M_CLOCK_SOURCE_RCOSC_HF
  #define APPL_CFG_CLK_NRES_RCOSC_HF_IS_USED
  #define CLK_NRES_AS1_USI0_FREQ_HZ_TMP    CLK_NRES_RCOSC_HF_CLK_FREQ_HZ

#elif CLK_NRES_CFG_AS1_USI0_CLK_SRC == M_CLOCK_SOURCE_QOSC
  #define APPL_CFG_CLK_NRES_QOSC_IS_USED
  #define CLK_NRES_AS1_USI0_FREQ_HZ_TMP    CLK_NRES_QOSC_CLK_FREQ_HZ

#elif CLK_NRES_CFG_AS1_USI0_CLK_SRC == M_CLOCK_SOURCE_PLL
  #define CLK_NRES_AS1_USI0_FREQ_HZ_TMP    CLK_NRES_PLL_FOUT_FREQ_HZ
  #define APPL_CFG_CLK_NRES_PLL_ENABLE

#elif CLK_NRES_CFG_AS1_USI0_CLK_SRC == M_CLOCK_SOURCE_RCOSC_LF
  #define CLK_NRES_AS1_USI0_FREQ_HZ_TMP    CLK_NRES_RCOSC_LF_CLK
#else
  #error "CLK_NRES_CFG_AS1_USI0_CLK_SRC:wrong settings"
#endif 
// AS1 divider
#define CLK_NRES_AS1_USI0_FREQ_HZ   ((CLK_NRES_AS1_USI0_FREQ_HZ_TMP)/(CLK_NRES_CFG_AS1_USI0_CLK_DIV))
//
//------------------------------------------------------------------------------
//
//#define CLK_NRES_CFG_AS2_USI1_CLK_SRC
#if  CLK_NRES_CFG_AS2_USI1_CLK_SRC  == M_CLOCK_SOURCE_RCOSC_HF
  #define APPL_CFG_CLK_NRES_RCOSC_HF_IS_USED
  #define CLK_NRES_AS2_USI1_FREQ_HZ_TMP    CLK_NRES_RCOSC_HF_CLK_FREQ_HZ

#elif CLK_NRES_CFG_AS2_USI1_CLK_SRC == M_CLOCK_SOURCE_QOSC
  #define APPL_CFG_CLK_NRES_QOSC_IS_USED
  #define CLK_NRES_AS2_USI1_FREQ_HZ_TMP    CLK_NRES_QOSC_CLK_FREQ_HZ

#elif CLK_NRES_CFG_AS2_USI1_CLK_SRC == M_CLOCK_SOURCE_PLL
  #define CLK_NRES_AS2_USI1_FREQ_HZ_TMP    CLK_NRES_PLL_FOUT_FREQ_HZ
  #define APPL_CFG_CLK_NRES_PLL_ENABLE

#elif CLK_NRES_CFG_AS2_USI1_CLK_SRC == M_CLOCK_SOURCE_RCOSC_LF
  #define CLK_NRES_AS2_USI1_FREQ_HZ_TMP    CLK_NRES_RCOSC_LF_CLK
#else
  #error "CLK_NRES_CFG_AS2_USI1_CLK_SRC:wrong settings"
#endif 
// AS2 divider
#define CLK_NRES_AS2_USI1_FREQ_HZ   ((CLK_NRES_AS2_USI1_FREQ_HZ_TMP)/(CLK_NRES_CFG_AS2_USI1_CLK_DIV))
//
//------------------------------------------------------------------------------
//
//#define CLK_NRES_CFG_AS3_HISPI_CLK_SRC    CLOCK_SOURCE_RCOSC_LF
#if  CLK_NRES_CFG_AS3_HISPI_CLK_SRC  == M_CLOCK_SOURCE_RCOSC_HF
  #define APPL_CFG_CLK_NRES_RCOSC_HF_IS_USED
  #define CLK_NRES_AS3_HISPI_FREQ_HZ_TMP    CLK_NRES_RCOSC_HF_CLK_FREQ_HZ

#elif CLK_NRES_CFG_AS3_HISPI_CLK_SRC == M_CLOCK_SOURCE_QOSC
  #define APPL_CFG_CLK_NRES_QOSC_IS_USED
  #define CLK_NRES_AS3_HISPI_FREQ_HZ_TMP    CLK_NRES_QOSC_CLK_FREQ_HZ

#elif CLK_NRES_CFG_AS3_HISPI_CLK_SRC == M_CLOCK_SOURCE_PLL
  #define CLK_NRES_AS3_HISPI_FREQ_HZ_TMP    CLK_NRES_PLL_FOUT_FREQ_HZ
  #define APPL_CFG_CLK_NRES_PLL_ENABLE

#elif CLK_NRES_CFG_AS3_HISPI_CLK_SRC == M_CLOCK_SOURCE_RCOSC_LF
  #define CLK_NRES_AS3_HISPI_FREQ_HZ_TMP    CLK_NRES_RCOSC_LF_CLK
#else
  #error "CLK_NRES_CFG_AS3_HISPI_CLK_SRC:wrong settings"
#endif 
// AS3 divider
#define CLK_NRES_AS3_HISPI_FREQ_HZ   ((CLK_NRES_AS3_HISPI_FREQ_HZ_TMP)/(CLK_NRES_CFG_AS3_HISPI_CLK_DIV))
//
//------------------------------------------------------------------------------
// MAIN CLOCK
//#define CLK_NRES_CLK_M_CLK_SRC
#if  CLK_NRES_CFG_M_CLK_SRC  == M_CLOCK_SOURCE_RCOSC_HF
  #define APPL_CFG_CLK_NRES_RCOSC_HF_IS_USED
  #define CLK_NRES_CLK_MAIN_FREQ_HZ_TMP    CLK_NRES_RCOSC_HF_CLK_FREQ_HZ

#elif CLK_NRES_CFG_M_CLK_SRC == M_CLOCK_SOURCE_QOSC
  #define APPL_CFG_CLK_NRES_QOSC_IS_USED
  #define CLK_NRES_CLK_MAIN_FREQ_HZ_TMP    CLK_NRES_QOSC_CLK_FREQ_HZ

#elif CLK_NRES_CFG_M_CLK_SRC == M_CLOCK_SOURCE_PLL
  #define CLK_NRES_CLK_MAIN_FREQ_HZ_TMP    CLK_NRES_PLL_FOUT_FREQ_HZ
  #define APPL_CFG_CLK_NRES_PLL_ENABLE

#elif CLK_NRES_CFG_M_CLK_SRC == M_CLOCK_SOURCE_RCOSC_LF
  #define CLK_NRES_CLK_MAIN_FREQ_HZ_TMP    CLK_NRES_RCOSC_LF_CLK
#else
  #error "CLK_NRES_CFG_M_CLK_SRC:wrong settings"
#endif 
// MAIN divider
#define CLK_NRES_CLK_MAIN_FREQ_HZ   ((CLK_NRES_CLK_MAIN_FREQ_HZ_TMP)/(CLK_NRES_CFG_M_CLK_DIV))
//
//------------------------------------------------------------------------------
//




// INPUTs check
#ifdef APPL_CFG_CLK_NRES_QOSC_IS_USED
  #ifndef CLK_NRES_QOSC_CLK_FREQ_HZ
    #error "CLK_NRES_QOSC_CLK_FREQ_HZ is not defined!!! Please, define it in device_settings.h"
  #endif
  
  #define CLK_NRES_QOSC_PD_N   1
#else
  #define CLK_NRES_QOSC_PD_N   0

#endif


#ifdef APPL_CFG_CLK_NRES_RCOSC_HF_IS_USED
  #define CLK_NRES_RCOSC_HF_PD_N   1
#else
  #define CLK_NRES_RCOSC_HF_PD_N   0
#endif

// PLL enable/disable
#ifdef APPL_CFG_CLK_NRES_PLL_ENABLE
  // PLL ENABLE
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "======================================================")
    #pragma message( "PLL_FCMP = FIN / (NR+1) = " DISPLAY_VALUE(CLK_NRES_PLL_FCMP_FREQ_HZ) " Hz")
    #pragma message( "VCO = (FIN / (NR+1)) * (NF+1) = " DISPLAY_VALUE(CLK_NRES_PLL_VCO_FREQ_HZ) " Hz")
    #pragma message( "FOUT = (FIN / (NR+1)) * (NF+1) / (1/2**OD) = " DISPLAY_VALUE(CLK_NRES_PLL_FOUT_FREQ_HZ) " Hz")
    #pragma message( "======================================================")
  #endif
  
  #define CLK_NRES_PLL_PLL_OE         CLK_NRES_PLL_OUTPUT_ENABLED
  #define CLK_NRES_PLL_PLL_PD_N       CLK_NRES_PLL_ENABLE
#else
  // PLL DISABLE
  #define CLK_NRES_PLL_PLL_OE         CLK_NRES_PLL_OUTPUT_DISABLE
  #define CLK_NRES_PLL_PLL_PD_N       CLK_NRES_PLL_DISABLE
#endif




// Checks
#if ((CLK_NRES_CLK_MAIN_FREQ_HZ) > 33000000U)
  #error "Main Clock Domain frequency is higher than 33MHz"
#endif

#if ((CLK_NRES_AS0_SWD_TSU_FREQ_HZ) > 66000000U)
  #error "AS0 Clock Domain (SWD, TSU Frontends) frequency is higher than 66MHz"
#elif ((CLK_NRES_AS0_SWD_TSU_FREQ_HZ) < CLK_NRES_CLK_MAIN_FREQ_HZ)
  #error "AS0 Clock Domain (SWD, TSU Frontends) frequency is lower than MAIN clock"
#endif


#if ((CLK_NRES_AS1_USI0_FREQ_HZ_TMP) > 66000000U)
  #error "AS1 Clock Domain (USI0 Frontend) frequency is higher than 66MHz"
#elif ((CLK_NRES_AS1_USI0_FREQ_HZ_TMP) < CLK_NRES_CLK_MAIN_FREQ_HZ)
  #error "AS1 Clock Domain (USI0 Frontend) frequency is lower than MAIN clock"
#endif


#if ((CLK_NRES_AS2_USI1_FREQ_HZ_TMP) > 66000000U)
  #error "AS2 Clock Domain (USI1 Frontend) frequency is higher than 66MHz"
#elif ((CLK_NRES_AS2_USI1_FREQ_HZ_TMP) < CLK_NRES_CLK_MAIN_FREQ_HZ)
  #error "AS2 Clock Domain (USI1 Frontend) frequency is lower than MAIN clock"
#endif


#if ((CLK_NRES_AS3_HISPI_FREQ_HZ_TMP) > 66000000U)
  #error "AS3 Clock Domain (HISPI Frontend) frequency is higher than 66MHz"
#elif ((CLK_NRES_AS3_HISPI_FREQ_HZ_TMP) < CLK_NRES_CLK_MAIN_FREQ_HZ)
  #error "AS3 Clock Domain (HISPI Frontend) frequency is lower than MAIN clock"
#endif

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// 
// PERIPHERALS
//
//  - defined?
//
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

// MASTERS
#define CLK_NRES_CFG_RATE_SEL_CCPU0_FREQ_HZ          CLK_NRES_FULL_RATE_FREQ_HZ
#define CLK_NRES_CFG_RATE_SEL_ACPU1_FREQ_HZ          CLK_NRES_FULL_RATE_FREQ_HZ
#define CLK_NRES_CFG_RATE_SEL_CRC0_FREQ_HZ           CLK_NRES_FULL_RATE_FREQ_HZ
#define CLK_NRES_CFG_RATE_SEL_CRC1_FREQ_HZ           CLK_NRES_FULL_RATE_FREQ_HZ
#define CLK_NRES_CFG_RATE_SEL_HIAD_FREQ_HZ           CLK_NRES_FULL_RATE_FREQ_HZ
#define CLK_NRES_CFG_RATE_SEL_HISPI_FREQ_HZ          CLK_NRES_FULL_RATE_FREQ_HZ
#define CLK_NRES_CFG_RATE_SEL_SWD_FREQ_HZ            CLK_NRES_FULL_RATE_FREQ_HZ
#define CLK_NRES_CFG_RATE_SEL_SARADC_CTRL_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ
#define CLK_NRES_CFG_RATE_SEL_USI0_FREQ_HZ           CLK_NRES_FULL_RATE_FREQ_HZ
#define CLK_NRES_CFG_RATE_SEL_USI1_FREQ_HZ           CLK_NRES_FULL_RATE_FREQ_HZ


//#define CLK_NRES_CFG_RATE_SEL_TSU
#if   CLK_NRES_CFG_RATE_SEL_TSU  == FULL_RATE
  #define CLK_NRES_CFG_RATE_SEL_TSU_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ

#elif CLK_NRES_CFG_RATE_SEL_TSU == HIGH_RATE
  #define CLK_NRES_CFG_RATE_SEL_TSU_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ

#elif CLK_NRES_CFG_RATE_SEL_TSU == LOW_RATE_0
  #define CLK_NRES_CFG_RATE_SEL_TSU_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ

#elif CLK_NRES_CFG_RATE_SEL_TSU == LOW_RATE_1
  #define CLK_NRES_CFG_RATE_SEL_TSU_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ
#else
  #error "CLK_NRES_CFG_RATE_SEL_TSU:wrong settings"
#endif 
             

//#define CLK_NRES_CFG_RATE_SEL_GPIO
#if   CLK_NRES_CFG_RATE_SEL_GPIO  == FULL_RATE
  #define CLK_NRES_CFG_RATE_SEL_GPIO_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ

#elif CLK_NRES_CFG_RATE_SEL_GPIO == HIGH_RATE
  #define CLK_NRES_CFG_RATE_SEL_GPIO_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ

#elif CLK_NRES_CFG_RATE_SEL_GPIO == LOW_RATE_0
  #define CLK_NRES_CFG_RATE_SEL_GPIO_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ

#elif CLK_NRES_CFG_RATE_SEL_GPIO == LOW_RATE_1
  #define CLK_NRES_CFG_RATE_SEL_GPIO_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ
#else
  #error "CLK_NRES_CFG_RATE_SEL_GPIO:wrong settings"
#endif                

//#define CLK_NRES_CFG_RATE_SEL_GUARD0
#if   CLK_NRES_CFG_RATE_SEL_GUARD0  == FULL_RATE
  #define CLK_NRES_CFG_RATE_SEL_GUARD0_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ

#elif CLK_NRES_CFG_RATE_SEL_GUARD0 == HIGH_RATE
  #define CLK_NRES_CFG_RATE_SEL_GUARD0_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ

#elif CLK_NRES_CFG_RATE_SEL_GUARD0 == LOW_RATE_0
  #define CLK_NRES_CFG_RATE_SEL_GUARD0_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ

#elif CLK_NRES_CFG_RATE_SEL_GUARD0 == LOW_RATE_1
  #define CLK_NRES_CFG_RATE_SEL_GUARD0_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ
#else
  #error "CLK_NRES_CFG_RATE_SEL_GUARD0:wrong settings"
#endif   

//#define CLK_NRES_CFG_RATE_SEL_GUARD1
#if   CLK_NRES_CFG_RATE_SEL_GUARD1  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_GUARD1_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_GUARD1 == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_GUARD1_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_GUARD1 == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_GUARD1_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_GUARD1 == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_GUARD1_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_GUARD1:wrong settings" 
#endif  

//#define CLK_NRES_CFG_RATE_SEL_SWTIMER0
#if   CLK_NRES_CFG_RATE_SEL_SWTIMER0  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_SWTIMER0_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_SWTIMER0 == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_SWTIMER0_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_SWTIMER0 == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_SWTIMER0_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_SWTIMER0 == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_SWTIMER0_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
#error "CLK_NRES_CFG_RATE_SEL_SWTIMER0:wrong settings" 
#endif 

//#define CLK_NRES_CFG_RATE_SEL_SWTIMER1
#if   CLK_NRES_CFG_RATE_SEL_SWTIMER1  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_SWTIMER1_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_SWTIMER1 == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_SWTIMER1_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_SWTIMER1 == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_SWTIMER1_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_SWTIMER1 == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_SWTIMER1_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_SWTIMER1:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_PWMN
#if   CLK_NRES_CFG_RATE_SEL_PWMN  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_PWMN_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_PWMN == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_PWMN_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_PWMN == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_PWMN_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_PWMN == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_PWMN_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_PWMN:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_VIC_EXT
#if   CLK_NRES_CFG_RATE_SEL_VIC_EXT  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_VIC_EXT_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_VIC_EXT == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_VIC_EXT_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_VIC_EXT == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_VIC_EXT_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_VIC_EXT == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_VIC_EXT_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_VIC_EXT:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_WDOG0
#if   CLK_NRES_CFG_RATE_SEL_WDOG0  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_WDOG0_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_WDOG0 == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_WDOG0_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_WDOG0 == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_WDOG0_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_WDOG0 == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_WDOG0_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_WDOG0:wrong settings"
#endif

//#define CLK_NRES_CFG_RATE_SEL_WDOG1
#if   CLK_NRES_CFG_RATE_SEL_WDOG1  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_WDOG1_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_WDOG1 == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_WDOG1_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_WDOG1 == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_WDOG1_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_WDOG1 == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_WDOG1_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_WDOG1:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_CPU_N_CPU
#if   CLK_NRES_CFG_RATE_SEL_CPU_N_CPU  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_CPU_N_CPU_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_CPU_N_CPU == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_CPU_N_CPU_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_CPU_N_CPU == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_CPU_N_CPU_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_CPU_N_CPU == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_CPU_N_CPU_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_CPU_N_CPU:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_CCTIMER0
#if   CLK_NRES_CFG_RATE_SEL_CCTIMER0  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_CCTIMER0_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_CCTIMER0 == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_CCTIMER0_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_CCTIMER0 == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_CCTIMER0_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_CCTIMER0 == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_CCTIMER0_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_CCTIMER0:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_CCTIMER1
#if   CLK_NRES_CFG_RATE_SEL_CCTIMER1  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_CCTIMER1_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_CCTIMER1 == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_CCTIMER1_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_CCTIMER1 == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_CCTIMER1_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_CCTIMER1 == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_CCTIMER1_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_CCTIMER1:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_IO_CTRL
#if   CLK_NRES_CFG_RATE_SEL_IO_CTRL  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_IO_CTRL_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_IO_CTRL == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_IO_CTRL_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_IO_CTRL == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_IO_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_IO_CTRL == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_IO_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_IO_CTRL:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL
#if   CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL
#if   CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_HV_CTRL
#if   CLK_NRES_CFG_RATE_SEL_HV_CTRL  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_HV_CTRL_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_HV_CTRL == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_HV_CTRL_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_HV_CTRL == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_HV_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_HV_CTRL == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_HV_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_HV_CTRL:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_UART
#if   CLK_NRES_CFG_RATE_SEL_UART  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_UART_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_UART == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_UART_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_UART == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_UART_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_UART == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_UART_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_UART:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_AOUT_CTRL
#if   CLK_NRES_CFG_RATE_SEL_AOUT_CTRL  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_AOUT_CTRL_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_AOUT_CTRL == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_AOUT_CTRL_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_AOUT_CTRL == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_AOUT_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_AOUT_CTRL == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_AOUT_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_AOUT_CTRL:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_I2C
#if   CLK_NRES_CFG_RATE_SEL_I2C  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_I2C_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_I2C == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_I2C_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_I2C == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_I2C_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_I2C == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_I2C_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_I2C:wrong settings" 
#endif

//#define CLK_NRES_CFG_RATE_SEL_EL_CTRL
#if   CLK_NRES_CFG_RATE_SEL_EL_CTRL  == FULL_RATE 
  #define CLK_NRES_CFG_RATE_SEL_EL_CTRL_FREQ_HZ    CLK_NRES_FULL_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_EL_CTRL == HIGH_RATE 
  #define CLK_NRES_CFG_RATE_SEL_EL_CTRL_FREQ_HZ    CLK_NRES_HIGH_RATE_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_EL_CTRL == LOW_RATE_0 
  #define CLK_NRES_CFG_RATE_SEL_EL_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_0_FREQ_HZ 
#elif CLK_NRES_CFG_RATE_SEL_EL_CTRL == LOW_RATE_1 
  #define CLK_NRES_CFG_RATE_SEL_EL_CTRL_FREQ_HZ    CLK_NRES_LOW_RATE_1_FREQ_HZ 
#else 
  #error "CLK_NRES_CFG_RATE_SEL_EL_CTRL:wrong settings" 
#endif

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// 
// CLOCK CHECKS
//
//  - defined?
//
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------


#ifndef CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC
#error "CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC not defined"
#endif 

#ifndef CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC
#error "CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC not defined"
#endif 

#ifndef CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC
#error "CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC not defined"
#endif 

#ifndef CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC
#error "CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC not defined"
#endif 



//------------------------------------------------------------------------------

#ifndef CLK_NRES_CFG_RATE_SEL_TSU
#error "CLK_NRES_CFG_RATE_SEL_TSU not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_GPIO
#error "CLK_NRES_CFG_RATE_SEL_GPIO not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_GUARD0
#error "CLK_NRES_CFG_RATE_SEL_GUARD0 not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_GUARD1
#error "CLK_NRES_CFG_RATE_SEL_GUARD1 not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_SWTIMER0
#error "CLK_NRES_CFG_RATE_SEL_SWTIMER0 not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_SWTIMER1
#error "CLK_NRES_CFG_RATE_SEL_SWTIMER1 not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_PWMN  
#error "CLK_NRES_CFG_RATE_SEL_PWMN not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_VIC_EXT
#error "CLK_NRES_CFG_RATE_SEL_VIC_EXT not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_WDOG0
#error "CLK_NRES_CFG_RATE_SEL_WDOG0 not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_WDOG1  
#error "CLK_NRES_CFG_RATE_SEL_WDOG1 not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_CPU_N_CPU
#error "CLK_NRES_CFG_RATE_SEL_CPU_N_CPU not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_CCTIMER0
#error "CLK_NRES_CFG_RATE_SEL_CCTIMER0 not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_CCTIMER1
#error "CLK_NRES_CFG_RATE_SEL_CCTIMER1 not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_IO_CTRL 
#error "CLK_NRES_CFG_RATE_SEL_IO_CTRL not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL
#error "CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL
#error "CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_HV_CTRL
#error "CLK_NRES_CFG_RATE_SEL_HV_CTRL not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_UART
#error "CLK_NRES_CFG_RATE_SEL_UART not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_AOUT_CTRL
#error "CLK_NRES_CFG_RATE_SEL_AOUT_CTRL not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_I2C
#error "CLK_NRES_CFG_RATE_SEL_I2C not defined"
#endif 

#ifndef CLK_NRES_CFG_RATE_SEL_EL_CTRL
#error "CLK_NRES_CFG_RATE_SEL_EL_CTRL not defined"
#endif 

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// 
// CLOCK Calculation
//
//
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------









/* EQUATIONs */


#define CLK_NRES_FULL_RATE_FREQ_HZ   (CLK_NRES_CLK_MAIN_FREQ_HZ)
#define CLK_NRES_HIGH_RATE_FREQ_HZ   ((CLK_NRES_CLK_MAIN_FREQ_HZ)/(CLK_NRES_CFG_HIGH_RATE))
#define CLK_NRES_LOW_RATE_0_FREQ_HZ  ((CLK_NRES_CLK_MAIN_FREQ_HZ)/(CLK_NRES_CFG_LOW_RATE_0))
#define CLK_NRES_LOW_RATE_1_FREQ_HZ  ((CLK_NRES_CLK_MAIN_FREQ_HZ)/(CLK_NRES_CFG_LOW_RATE_1))


//
// Print out frequecies 
//
#ifdef __IAR_SYSTEMS_ICC__
  #pragma message( "======================================================")
  #pragma message( "AS0 SWD TSU Freq  = " DISPLAY_VALUE(CLK_NRES_AS0_SWD_TSU_FREQ_HZ) " Hz")
  #pragma message( "AS1 USI0 Freq  = " DISPLAY_VALUE(CLK_NRES_AS1_USI0_FREQ_HZ) " Hz")
  #pragma message( "AS2 USI1 Freq  = " DISPLAY_VALUE(CLK_NRES_AS2_USI1_FREQ_HZ) " Hz")
  #pragma message( "AS3 HISPI Freq  = " DISPLAY_VALUE(CLK_NRES_AS3_HISPI_FREQ_HZ) " Hz")
  #pragma message( "======================================================")
  #pragma message( "Main clock Freq  = " DISPLAY_VALUE(CLK_NRES_CLK_MAIN_FREQ_HZ) " Hz")
  #pragma message( "======================================================")
  #pragma message( "Full rate Freq  = " DISPLAY_VALUE(CLK_NRES_FULL_RATE_FREQ_HZ) " Hz")
  #pragma message( "High rate Freq  = " DISPLAY_VALUE(CLK_NRES_HIGH_RATE_FREQ_HZ) " Hz")
  #pragma message( "Low rate 0 Freq  = " DISPLAY_VALUE(CLK_NRES_LOW_RATE_0_FREQ_HZ) " Hz")
  #pragma message( "Low rate 1 Freq  = " DISPLAY_VALUE(CLK_NRES_LOW_RATE_1_FREQ_HZ) " Hz")
  #pragma message( "======================================================")
  //#pragma message( "TSU freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_TSU_FREQ_HZ) " Hz")
  //#pragma message( "GPIO freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_GPIO_FREQ_HZ) " Hz")
  //#pragma message( "GUARD0 freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_GUARD0_FREQ_HZ) " Hz")
  //#pragma message( "GUARD1 freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_GUARD1_FREQ_HZ) " Hz")
  //#pragma message( "SWTIMER0 freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_SWTIMER0_FREQ_HZ) " Hz")
  //#pragma message( "SWTIMER1 freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_SWTIMER1_FREQ_HZ) " Hz")
  //#pragma message( "PWM freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_PWMN_FREQ_HZ) " Hz")
  //#pragma message( "VIC_EXT freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_VIC_EXT_FREQ_HZ) " Hz")
  //#pragma message( "WDOG0 freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_WDOG0_FREQ_HZ) " Hz")
  //#pragma message( "WDOG1 freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_WDOG1_FREQ_HZ) " Hz")
  //#pragma message( "CPU_N_CPU freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_CPU_N_CPU_FREQ_HZ) " Hz")
  //#pragma message( "CCTIMER0 freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_CCTIMER0_FREQ_HZ) " Hz")
  //#pragma message( "CCTIMER1 freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_CCTIMER1_FREQ_HZ) " Hz")
  //#pragma message( "IO_CTRL freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_IO_CTRL_FREQ_HZ) " Hz")
  //#pragma message( "ANALOG_CTRL freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL_FREQ_HZ) " Hz")
  //#pragma message( "ACCESS_CTRL freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL_FREQ_HZ) " Hz")
  //#pragma message( "HV_CTRL freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_HV_CTRL_FREQ_HZ) " Hz")
  //#pragma message( "UART freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_UART_FREQ_HZ) " Hz")
  //#pragma message( "AOUT_CTRL freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_AOUT_CTRL_FREQ_HZ) " Hz")
  //#pragma message( "I2C freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_I2C_FREQ_HZ) " Hz")
  //#pragma message( "EL_CTRL freq = " DISPLAY_VALUE(CLK_NRES_CFG_RATE_SEL_EL_CTRL_FREQ_HZ) " Hz")
  //#pragma message( "======================================================")
#endif

// FLASH


// MACRO VERIFICATION:BEGIN
//    #include <stdio.h>
//
//    #define TNVS_TNVH  ( ( ( 49U * ( (((16000000UL)/(2))) / (1000U) ) ) / ( ((8000000UL)/(1000U)) ) ) + 1 ) 
//    #define TNVH1      ( ( ( 881U * ( (((16000000UL)/(2))) / (1000U) ) ) / ( ((8000000UL)/(1000U)) ) ) + 1 ) 
//    #define TPGS       ( ( ( 89U * ( (((16000000UL)/(2))) / (1000U) ) ) / ( ((8000000UL)/(1000U)) ) ) + 1 ) 
//    #define TRCV       ( ( ( 9U * ( (((16000000UL)/(2))) / (1000U) ) ) / ( ((8000000UL)/(1000U)) ) ) + 1 ) 
//    #define TPROG      ( ( ( 177U * ( (((16000000UL)/(2))) / (1000U) ) ) / ( ((8000000UL)/(1000U)) ) ) + 1 ) 
//    #define TERASE     ( ( ( 672U * ( (((16000000UL)/(2))) / (1000U) ) ) / ( ((8000000UL)/(1000U)) ) ) + 1 ) 
//    #define TME        ( ( ( 672U * ( (((16000000UL)/(2))) / (1000U) ) ) / ( ((8000000UL)/(1000U)) ) ) + 1 ) 
//
//    //typedef unsigned char uint8_t;
//    //typedef unsigned int 	uint16_t;
//
//    void main(void) {
//      uint8_t tnvs_tnvh = TNVS_TNVH;
//      uint16_t tnvh1 = TNVH1;
//      uint16_t tpgs = TPGS;
//      uint8_t trcv = TRCV;
//      uint16_t tprog = TPROG;
//      uint16_t terase = TERASE;
//      uint16_t tme = TME;
//
//      printf("tnvs_tnvh: %u\n",tnvs_tnvh);
//      printf("tnvh1: %u\n",tnvh1);
//      printf("tpgs: %u\n",tpgs);
//      printf("trcv: %u\n",trcv);
//      printf("tprog: %u\n",tprog);
//      printf("terase: %u\n",terase);
//      printf("tme: %u\n",tme);
//    }
// MACRO VERIFICATION:OUTPUT


// MACRO VERIFICATION:END
//    16M / 2
//
//    $ ./a.exe
//    tnvs_tnvh: 50
//    tnvh1: 882
//    tpgs: 90
//    trcv: 10
//    tprog: 178
//    terase: 673
//    tme: 673
//
// --------------------
//    1M / 1
//
//    $ ./a.exe
//    tnvs_tnvh: 7
//    tnvh1: 111
//    tpgs: 12
//    trcv: 2
//    tprog: 23
//    terase: 85
//    tme: 85
//
// --------------------
//    32M / 1
//
//    tnvs_tnvh: 197
//    tnvh1: 3525
//    tpgs: 357
//    trcv: 37
//    tprog: 709
//    terase: 2689
//    tme: 2689







#if CLK_NRES_CLK_MAIN_FREQ_HZ > 16500000U
  #define APPLICATION_CONFIG_FLASH_CTRL_USE_FLASH_HALF_CLOCK_SPEED  1
#else 
  #define APPLICATION_CONFIG_FLASH_CTRL_USE_FLASH_HALF_CLOCK_SPEED  0
#endif

#include <flash_ctrl.h>

#define APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH   FLASH_CTRL_ACCESS_TIME_TNVS_TNVH(CLK_NRES_CLK_MAIN_FREQ_HZ)
#define APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVH1       FLASH_CTRL_ACCESS_TIME_TNVH1(CLK_NRES_CLK_MAIN_FREQ_HZ)
#define APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPGS        FLASH_CTRL_ACCESS_TIME_TPGS(CLK_NRES_CLK_MAIN_FREQ_HZ)
#define APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TRCV        FLASH_CTRL_ACCESS_TIME_TRCV(CLK_NRES_CLK_MAIN_FREQ_HZ)
#define APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPROG       FLASH_CTRL_ACCESS_TIME_TPROG(CLK_NRES_CLK_MAIN_FREQ_HZ)
#define APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TERASE      FLASH_CTRL_ACCESS_TIME_TERASE(CLK_NRES_CLK_MAIN_FREQ_HZ)
#define APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TME         FLASH_CTRL_ACCESS_TIME_TME(CLK_NRES_CLK_MAIN_FREQ_HZ)

#ifdef __IAR_SYSTEMS_ICC__
  #pragma message( " ")
  #pragma message( "======================================================")
  #pragma message( "===  FLASH PARAM  ====================================")
  #pragma message( "======================================================")
  #pragma message( "TNVS_TNVH = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH))
  #pragma message( "TNVH1 = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVH1))
  #pragma message( "TPGS = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPGS))
  #pragma message( "TRCV = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TRCV))
  #pragma message( "TPROG = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPROG))
  #pragma message( "TERASE = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TERASE))
  #pragma message( "TME = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TME))
  #pragma message( "======================================================")
#endif

#define APPLICATION_CONFIG_MHZ 1000000U
#define APPLICATION_CONFIG_KHZ 1000U

// 6.18.5 Flash Access Times
// limits are calculated in register value units [cycle time]
#define APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH ((  5U*CLK_NRES_CLK_MAIN_FREQ_HZ)/APPLICATION_CONFIG_MHZ) ///< [us]
#define APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TNVH1     ((100U*CLK_NRES_CLK_MAIN_FREQ_HZ)/APPLICATION_CONFIG_MHZ) ///< [us]
#define APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TPGS      (( 10U*CLK_NRES_CLK_MAIN_FREQ_HZ)/APPLICATION_CONFIG_MHZ) ///< [us]
#define APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TRCV      ((  1U*CLK_NRES_CLK_MAIN_FREQ_HZ)/APPLICATION_CONFIG_MHZ) ///< [us]

#define APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TPROG     (( 20U*CLK_NRES_CLK_MAIN_FREQ_HZ)/APPLICATION_CONFIG_MHZ) ///< [us]
#define APPLICATION_CONFIG_MAX_FLASH_CTRL_ACCESS_TIME_TPROG     (( 40U*CLK_NRES_CLK_MAIN_FREQ_HZ)/APPLICATION_CONFIG_MHZ) ///< [us]

#define APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TERASE    (( (20U*CLK_NRES_CLK_MAIN_FREQ_HZ)/256U)/APPLICATION_CONFIG_KHZ) ///< [ms]
#define APPLICATION_CONFIG_MAX_FLASH_CTRL_ACCESS_TIME_TERASE    (( (40U*CLK_NRES_CLK_MAIN_FREQ_HZ)/256U)/APPLICATION_CONFIG_KHZ) ///< [ms]

#define APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TME       (( (20U*CLK_NRES_CLK_MAIN_FREQ_HZ)/256U)/APPLICATION_CONFIG_KHZ) ///< [ms]
#define APPLICATION_CONFIG_MAX_FLASH_CTRL_ACCESS_TIME_TME       (( (40U*CLK_NRES_CLK_MAIN_FREQ_HZ)/256U)/APPLICATION_CONFIG_KHZ) ///< [ms]

#if ((APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH) < (APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH)) 
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "TNVS_TNVH = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH) " cycles")
    #pragma message( DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH) " < " DISPLAY_VALUE(APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH))
  #endif
  #error "APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVS_TNVH is out of limits"
#endif

#if (APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVH1 < APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TNVH1) 
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "TNVH1 = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVH1) " cycles")
  #endif
  #error "APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TNVH1 is out of limits"
#endif

#if (APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPGS < APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TPGS) 
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "TPGS = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPGS) " cycles")
  #endif
  #error "APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPGS is out of limits"
#endif

#if (APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TRCV < APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TRCV) 
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "TRCV = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TRCV) " cycles")
  #endif
  #error "APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TRCV is out of limits"
#endif

#if ((APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPROG < APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TPROG) || \
     (APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPROG > APPLICATION_CONFIG_MAX_FLASH_CTRL_ACCESS_TIME_TPROG))
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "TPROG = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPROG) " cycles")
  #endif
  #error "APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TPROG is out of limits"
#endif

#if ((APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TERASE < APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TERASE) || \
     (APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TERASE > APPLICATION_CONFIG_MAX_FLASH_CTRL_ACCESS_TIME_TERASE))
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "TERASE = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TERASE) " cycles")
  #endif
  #error "APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TERASE is out of limits"
#endif

#if ((APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TME < APPLICATION_CONFIG_MIN_FLASH_CTRL_ACCESS_TIME_TME) || \
     (APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TME > APPLICATION_CONFIG_MAX_FLASH_CTRL_ACCESS_TIME_TME))
  #ifdef __IAR_SYSTEMS_ICC__
    #pragma message( "TME = " DISPLAY_VALUE(APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TME) " cycles")
  #endif
  #error "APPLICATION_CONFIG_FLASH_CTRL_ACCESS_TIME_TME is out of limits"
#endif


#endif