/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         aout_ctrl_bf.h
*
* @brief        Aout and Aout Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __AOUT_CTRL_BF_H__
#define __AOUT_CTRL_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_AOUT_CTRL
#define BASE_ADDR_AOUT_CTRL 0x40007100U
#endif

#define NUMBER_AOUT_CTRL 1

/**
  * \brief This is an enum class for AOUT Control instance
  *
  * \ingroup aout_ctrl
  */ 
typedef enum {
  AOUT_CTRL                      = (int)BASE_ADDR_AOUT_CTRL ///< this is instance AOUT Control
} aout_ctrl_num_t;

// Register bit field definitions

/* AOUT_CTRL_CFG */

#define MSK_AOUT_CTRL_CFG_EN                                (0x1)     /* [0] */
#define RES_AOUT_CTRL_CFG_EN                                (0x0)
#define SFT_AOUT_CTRL_CFG_EN                                (0)
#define LSB_AOUT_CTRL_CFG_EN                                (0)
#define MSB_AOUT_CTRL_CFG_EN                                (0)
#define BIT_AOUT_CTRL_CFG_EN                                (0x1)     /* [0] */
#define MSK_AOUT_CTRL_CFG_DIV                               (0x3f)    /* [ 6:1] */
#define RES_AOUT_CTRL_CFG_DIV                               (0x00)
#define SFT_AOUT_CTRL_CFG_DIV                               (1)
#define LSB_AOUT_CTRL_CFG_DIV                               (1)
#define MSB_AOUT_CTRL_CFG_DIV                               (6)
#define MSK_AOUT_CTRL_CFG_C1                                (0xf)     /* [10:7] */
#define RES_AOUT_CTRL_CFG_C1                                (0x8)
#define SFT_AOUT_CTRL_CFG_C1                                (7)
#define LSB_AOUT_CTRL_CFG_C1                                (7)
#define MSB_AOUT_CTRL_CFG_C1                                (10)
#define MSK_AOUT_CTRL_CFG_SYNC_EN                           (0x1)     /* [11] */
#define RES_AOUT_CTRL_CFG_SYNC_EN                           (0x0)
#define SFT_AOUT_CTRL_CFG_SYNC_EN                           (11)
#define LSB_AOUT_CTRL_CFG_SYNC_EN                           (11)
#define MSB_AOUT_CTRL_CFG_SYNC_EN                           (11)
#define BIT_AOUT_CTRL_CFG_SYNC_EN                           (0x800)   /* [11] */
#define MSK_AOUT_CTRL_CFG_AOUT_NPD                          (0x1)     /* [12] */
#define RES_AOUT_CTRL_CFG_AOUT_NPD                          (0x0)
#define SFT_AOUT_CTRL_CFG_AOUT_NPD                          (12)
#define LSB_AOUT_CTRL_CFG_AOUT_NPD                          (12)
#define MSB_AOUT_CTRL_CFG_AOUT_NPD                          (12)
#define BIT_AOUT_CTRL_CFG_AOUT_NPD                          (0x1000)  /* [12] */
#define MSK_AOUT_CTRL_CFG_AOUT_OE                           (0x1)     /* [13] */
#define RES_AOUT_CTRL_CFG_AOUT_OE                           (0x0)
#define SFT_AOUT_CTRL_CFG_AOUT_OE                           (13)
#define LSB_AOUT_CTRL_CFG_AOUT_OE                           (13)
#define MSB_AOUT_CTRL_CFG_AOUT_OE                           (13)
#define BIT_AOUT_CTRL_CFG_AOUT_OE                           (0x2000)  /* [13] */
#define MSK_AOUT_CTRL_CFG_EXT_FEEDBACK_ENABLE               (0x1)     /* [14] */
#define RES_AOUT_CTRL_CFG_EXT_FEEDBACK_ENABLE               (0x0)
#define SFT_AOUT_CTRL_CFG_EXT_FEEDBACK_ENABLE               (14)
#define LSB_AOUT_CTRL_CFG_EXT_FEEDBACK_ENABLE               (14)
#define MSB_AOUT_CTRL_CFG_EXT_FEEDBACK_ENABLE               (14)
#define BIT_AOUT_CTRL_CFG_EXT_FEEDBACK_ENABLE               (0x4000)  /* [14] */

/** 
 * \brief This structure describes AOUT Control configuration 
 *
 * \ingroup aout_ctrl
 */
typedef struct {
  unsigned short en                            :    1; ///< <B>bit 0</B> <br> 0: sigma delta modulator for channel 0 /1 stopped and its integrators cleared<br> 1: sigma delta modulator for channel 0/1 running
  unsigned short div                           :    6; ///< <B>bits 6:1</B> <br> update period of the modulator in clock cycles (div +1) Note: For best performance, set a value that the DAC is clocked with 2 MHz
  unsigned short c1                            :    4; ///< <B>bits 10:7</B> <br> coef1 = c1/16
  unsigned short sync_en                       :    1; ///< <B>bit 11</B> <br> 1: DAC*_SYNC is transferred to DAC* when sync is asserted
  unsigned short aout_npd                      :    1; ///< <B>bit 12</B> <br> 1: power on the analog aout
  unsigned short aout_oe                       :    1; ///< <B>bit 13</B> <br> 1: Output enable for the lowpass filter
  unsigned short ext_feedback_enable           :    1; ///< <B>bit 14</B> <br> 1: use pad node as filter feedback (small external load currents can be compensated)<br>0: use internal node as filter feedback (better stability with high external cap)
  unsigned short reserved                      :    1; ///< <B>bit 15</B> <br> reserved
} aout_ctrl_cfg_bf;

/**
 * \brief Conversion type between word and bit representation of AOUT Control configuration
 *
 * \ingroup aout_ctrl
 */
typedef union {
  unsigned short val;
  aout_ctrl_cfg_bf bf;
} aout_ctrl_cfg_t;


/* AOUT_CTRL_DAC */

#define MSK_AOUT_CTRL_DAC                                   (0xffff)  /* [15:0] */

typedef unsigned short aout_ctrl_dac_t;                               /* [15:0] */


/* AOUT_CTRL_DAC_SYNC */

#define MSK_AOUT_CTRL_DAC_SYNC                              (0xffff)  /* [15:0] */

typedef unsigned short aout_ctrl_dac_sync_t;                          /* [15:0] */


/* AOUT_CTRL_DAC0_MOD_TEST */

#define MSK_AOUT_CTRL_DAC0_MOD_TEST_VAL                     (0xf)     /* [ 3:0] */
#define RES_AOUT_CTRL_DAC0_MOD_TEST_VAL                     (0x0)
#define SFT_AOUT_CTRL_DAC0_MOD_TEST_VAL                     (0)
#define LSB_AOUT_CTRL_DAC0_MOD_TEST_VAL                     (0)
#define MSB_AOUT_CTRL_DAC0_MOD_TEST_VAL                     (3)
#define MSK_AOUT_CTRL_DAC0_MOD_TEST_FORCE_ENABLE            (0x1)     /* [4] */
#define RES_AOUT_CTRL_DAC0_MOD_TEST_FORCE_ENABLE            (0x0)
#define SFT_AOUT_CTRL_DAC0_MOD_TEST_FORCE_ENABLE            (4)
#define LSB_AOUT_CTRL_DAC0_MOD_TEST_FORCE_ENABLE            (4)
#define MSB_AOUT_CTRL_DAC0_MOD_TEST_FORCE_ENABLE            (4)
#define BIT_AOUT_CTRL_DAC0_MOD_TEST_FORCE_ENABLE            (0x10)    /* [4] */
#define MSK_AOUT_CTRL_DAC0_MOD_TEST_BYPASS_SCRAMBLER        (0x1)     /* [5] */
#define RES_AOUT_CTRL_DAC0_MOD_TEST_BYPASS_SCRAMBLER        (0x0)
#define SFT_AOUT_CTRL_DAC0_MOD_TEST_BYPASS_SCRAMBLER        (5)
#define LSB_AOUT_CTRL_DAC0_MOD_TEST_BYPASS_SCRAMBLER        (5)
#define MSB_AOUT_CTRL_DAC0_MOD_TEST_BYPASS_SCRAMBLER        (5)
#define BIT_AOUT_CTRL_DAC0_MOD_TEST_BYPASS_SCRAMBLER        (0x20)    /* [5] */

/** 
 * \brief This structure describes AOUT Control module test 
 *
 * \ingroup aout_ctrl
 */
typedef struct {
  unsigned short val                           :    4;       ///< <B>bits 3:0</B> <br> value to be forced on DAC signed, range: -4 ... 4
  unsigned short force_enable                  :    1;       ///< <B>bit 4</B> <br> enable force (bypass digital sigma-delta modulator)
  unsigned short bypass_scrambler              :    1;       ///< <B>bit 5</B> <br> static output (bypass scrambler) <br> <EM>Note: this config bit can also be used in normal operation (no forcedoutput)</EM>
  unsigned short reserved                      :   10;       ///< <B>bits 15:6</B> <br> reserved
} aout_ctrl_dac0_mod_test_bf;

/**
 * \brief Conversion type between word and bit representation of AOUT Control module test
 *
 * \ingroup aout_ctrl
 */
typedef union {
  unsigned short val;
  aout_ctrl_dac0_mod_test_bf bf;
} aout_ctrl_dac0_mod_test_t;



// Register definitions for module
// Instance base address BASE_ADDR_AOUT_CTRL 0x40007100U ... 

#define ADDR_AOUT_CTRL_CFG0                                  (0x00U)
#define A_AOUT_CTRL_CFG0(ba)                                 ((ba) + ADDR_AOUT_CTRL_CFG0)
#define R_AOUT_CTRL_CFG0(ba)                                 (*(volatile unsigned short *)((unsigned int)A_AOUT_CTRL_CFG0(ba)))
#define RES_AOUT_CTRL_CFG0                                   (0x400U)
#define MSB_AOUT_CTRL_CFG0                                   14
#define LSB_AOUT_CTRL_CFG0                                   0
#define AADDR_AOUT_CTRL_CFG0                                 (BASE_ADDR_AOUT_CTRL + ADDR_AOUT_CTRL_CFG0)
#define REG_AOUT_CTRL_CFG0                                   (*(volatile unsigned short *)((unsigned int)AADDR_AOUT_CTRL_CFG0))

#define ADDR_AOUT_CTRL_CFG1                                  (0x02U)
#define A_AOUT_CTRL_CFG1(ba)                                 ((ba) + ADDR_AOUT_CTRL_CFG1)
#define R_AOUT_CTRL_CFG1(ba)                                 (*(volatile unsigned short *)((unsigned int)A_AOUT_CTRL_CFG1(ba)))
#define RES_AOUT_CTRL_CFG1                                   (0x400U)
#define MSB_AOUT_CTRL_CFG1                                   14
#define LSB_AOUT_CTRL_CFG1                                   0
#define AADDR_AOUT_CTRL_CFG1                                 (BASE_ADDR_AOUT_CTRL + ADDR_AOUT_CTRL_CFG1)
#define REG_AOUT_CTRL_CFG1                                   (*(volatile unsigned short *)((unsigned int)AADDR_AOUT_CTRL_CFG1))

#define ADDR_AOUT_CTRL_DAC0                                  (0x04U)
#define A_AOUT_CTRL_DAC0(ba)                                 ((ba) + ADDR_AOUT_CTRL_DAC0)
#define R_AOUT_CTRL_DAC0(ba)                                 (*(volatile unsigned short *)((unsigned int)A_AOUT_CTRL_DAC0(ba)))
#define RES_AOUT_CTRL_DAC0                                   (0x0U)
#define MSB_AOUT_CTRL_DAC0                                   15
#define LSB_AOUT_CTRL_DAC0                                   0
#define AADDR_AOUT_CTRL_DAC0                                 (BASE_ADDR_AOUT_CTRL + ADDR_AOUT_CTRL_DAC0)
#define REG_AOUT_CTRL_DAC0                                   (*(volatile unsigned short *)((unsigned int)AADDR_AOUT_CTRL_DAC0))

#define ADDR_AOUT_CTRL_DAC1                                  (0x06U)
#define A_AOUT_CTRL_DAC1(ba)                                 ((ba) + ADDR_AOUT_CTRL_DAC1)
#define R_AOUT_CTRL_DAC1(ba)                                 (*(volatile unsigned short *)((unsigned int)A_AOUT_CTRL_DAC1(ba)))
#define RES_AOUT_CTRL_DAC1                                   (0x0U)
#define MSB_AOUT_CTRL_DAC1                                   15
#define LSB_AOUT_CTRL_DAC1                                   0
#define AADDR_AOUT_CTRL_DAC1                                 (BASE_ADDR_AOUT_CTRL + ADDR_AOUT_CTRL_DAC1)
#define REG_AOUT_CTRL_DAC1                                   (*(volatile unsigned short *)((unsigned int)AADDR_AOUT_CTRL_DAC1))

#define ADDR_AOUT_CTRL_DAC0_SYNC                             (0x08U)
#define A_AOUT_CTRL_DAC0_SYNC(ba)                            ((ba) + ADDR_AOUT_CTRL_DAC0_SYNC)
#define R_AOUT_CTRL_DAC0_SYNC(ba)                            (*(volatile unsigned short *)((unsigned int)A_AOUT_CTRL_DAC0_SYNC(ba)))
#define RES_AOUT_CTRL_DAC0_SYNC                              (0x0U)
#define MSB_AOUT_CTRL_DAC0_SYNC                              15
#define LSB_AOUT_CTRL_DAC0_SYNC                              0
#define AADDR_AOUT_CTRL_DAC0_SYNC                            (BASE_ADDR_AOUT_CTRL + ADDR_AOUT_CTRL_DAC0_SYNC)
#define REG_AOUT_CTRL_DAC0_SYNC                              (*(volatile unsigned short *)((unsigned int)AADDR_AOUT_CTRL_DAC0_SYNC))

#define ADDR_AOUT_CTRL_DAC1_SYNC                             (0x0AU)
#define A_AOUT_CTRL_DAC1_SYNC(ba)                            ((ba) + ADDR_AOUT_CTRL_DAC1_SYNC)
#define R_AOUT_CTRL_DAC1_SYNC(ba)                            (*(volatile unsigned short *)((unsigned int)A_AOUT_CTRL_DAC1_SYNC(ba)))
#define RES_AOUT_CTRL_DAC1_SYNC                              (0x0U)
#define MSB_AOUT_CTRL_DAC1_SYNC                              15
#define LSB_AOUT_CTRL_DAC1_SYNC                              0
#define AADDR_AOUT_CTRL_DAC1_SYNC                            (BASE_ADDR_AOUT_CTRL + ADDR_AOUT_CTRL_DAC1_SYNC)
#define REG_AOUT_CTRL_DAC1_SYNC                              (*(volatile unsigned short *)((unsigned int)AADDR_AOUT_CTRL_DAC1_SYNC))

#define ADDR_AOUT_CTRL_DAC0_MOD_TEST                         (0x0CU)
#define A_AOUT_CTRL_DAC0_MOD_TEST(ba)                        ((ba) + ADDR_AOUT_CTRL_DAC0_MOD_TEST)
#define R_AOUT_CTRL_DAC0_MOD_TEST(ba)                        (*(volatile unsigned short *)((unsigned int)A_AOUT_CTRL_DAC0_MOD_TEST(ba)))
#define RES_AOUT_CTRL_DAC0_MOD_TEST                          (0x0U)
#define MSB_AOUT_CTRL_DAC0_MOD_TEST                          5
#define LSB_AOUT_CTRL_DAC0_MOD_TEST                          0
#define AADDR_AOUT_CTRL_DAC0_MOD_TEST                        (BASE_ADDR_AOUT_CTRL + ADDR_AOUT_CTRL_DAC0_MOD_TEST)
#define REG_AOUT_CTRL_DAC0_MOD_TEST                          (*(volatile unsigned short *)((unsigned int)AADDR_AOUT_CTRL_DAC0_MOD_TEST))

#define ADDR_AOUT_CTRL_DAC1_MOD_TEST                         (0x0EU)
#define A_AOUT_CTRL_DAC1_MOD_TEST(ba)                        ((ba) + ADDR_AOUT_CTRL_DAC1_MOD_TEST)
#define R_AOUT_CTRL_DAC1_MOD_TEST(ba)                        (*(volatile unsigned short *)((unsigned int)A_AOUT_CTRL_DAC1_MOD_TEST(ba)))
#define RES_AOUT_CTRL_DAC1_MOD_TEST                          (0x0U)
#define MSB_AOUT_CTRL_DAC1_MOD_TEST                          5
#define LSB_AOUT_CTRL_DAC1_MOD_TEST                          0
#define AADDR_AOUT_CTRL_DAC1_MOD_TEST                        (BASE_ADDR_AOUT_CTRL + ADDR_AOUT_CTRL_DAC1_MOD_TEST)
#define REG_AOUT_CTRL_DAC1_MOD_TEST                          (*(volatile unsigned short *)((unsigned int)AADDR_AOUT_CTRL_DAC1_MOD_TEST))




#endif
