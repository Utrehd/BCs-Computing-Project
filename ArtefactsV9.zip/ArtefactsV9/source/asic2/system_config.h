#ifndef _SYSTEM_CONFIG_H_
#define _SYSTEM_CONFIG_H_

#include <application_config.h>

const application_config_t * system_config_application_config_get(void);
  
void system_config_init( void );

#endif