/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hv_ir_bf.h
*
* @brief        HV Die Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HV_IR_BF_H__
#define __HV_IR_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_HV_IR
#define BASE_ADDR_HV_IR 0x0U
#endif

#define NUMBER_HV_IR 1


/* ############################################################################ */
/**
 * \brief This is an enum class for HV IR instance
 *
 * \ingroup hv_ctrl 
 */ 
typedef enum {
  /**
   * This is instance HV_IR
   */ 
  HV_IR                          = (int)BASE_ADDR_HV_IR
} hv_ir_num_t;

// Register bit field definitions

/* HV_IR_PWR_CONFIG */

#define MSK_HV_IR_PWR_CONFIG_VREG_VDD3V3_MAX                (0x1)     /* [0] */
#define SFT_HV_IR_PWR_CONFIG_VREG_VDD3V3_MAX                (0)
#define LSB_HV_IR_PWR_CONFIG_VREG_VDD3V3_MAX                (0)
#define MSB_HV_IR_PWR_CONFIG_VREG_VDD3V3_MAX                (0)
#define BIT_HV_IR_PWR_CONFIG_VREG_VDD3V3_MAX                (0x1)     /* [0] */
#define MSK_HV_IR_PWR_CONFIG_VREG_VDD5TX_NPD                (0x1)     /* [1] */
#define SFT_HV_IR_PWR_CONFIG_VREG_VDD5TX_NPD                (1)
#define LSB_HV_IR_PWR_CONFIG_VREG_VDD5TX_NPD                (1)
#define MSB_HV_IR_PWR_CONFIG_VREG_VDD5TX_NPD                (1)
#define BIT_HV_IR_PWR_CONFIG_VREG_VDD5TX_NPD                (0x2)     /* [1] */
#define MSK_HV_IR_PWR_CONFIG_PW_VPOW_VTH                    (0xff)    /* [ 9:2] */
#define SFT_HV_IR_PWR_CONFIG_PW_VPOW_VTH                    (2)
#define LSB_HV_IR_PWR_CONFIG_PW_VPOW_VTH                    (2)
#define MSB_HV_IR_PWR_CONFIG_PW_VPOW_VTH                    (9)
#define MSK_HV_IR_PWR_CONFIG_PW_VPOW_HYST                   (0xf)     /* [13:10] */
#define SFT_HV_IR_PWR_CONFIG_PW_VPOW_HYST                   (10)
#define LSB_HV_IR_PWR_CONFIG_PW_VPOW_HYST                   (10)
#define MSB_HV_IR_PWR_CONFIG_PW_VPOW_HYST                   (13)
#define MSK_HV_IR_PWR_CONFIG_PW_VPOW_RANGE                  (0x1)     /* [14] */
#define SFT_HV_IR_PWR_CONFIG_PW_VPOW_RANGE                  (14)
#define LSB_HV_IR_PWR_CONFIG_PW_VPOW_RANGE                  (14)
#define MSB_HV_IR_PWR_CONFIG_PW_VPOW_RANGE                  (14)
#define BIT_HV_IR_PWR_CONFIG_PW_VPOW_RANGE                  (0x4000)  /* [14] */
#define MSK_HV_IR_PWR_CONFIG_PW_VDD5TX_NPD                  (0x1)     /* [15] */
#define SFT_HV_IR_PWR_CONFIG_PW_VDD5TX_NPD                  (15)
#define LSB_HV_IR_PWR_CONFIG_PW_VDD5TX_NPD                  (15)
#define MSB_HV_IR_PWR_CONFIG_PW_VDD5TX_NPD                  (15)
#define BIT_HV_IR_PWR_CONFIG_PW_VDD5TX_NPD                  (0x8000)  /* [15] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR JTAG power configuration
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * 0: reduced output voltage vdd3v3 (for external supply) <br>
   * 1: standart output voltage vdd3v3
   */ 
  unsigned short vreg_vdd3v3_max               :    1;       /* [0] */
  /**
   * 0:regulator is off <br>
   * 1: reglator is on
   */ 
  unsigned short vreg_vdd5tx_npd               :    1;       /* [1] */
  /**
   * Threshold of Vpow powerwatch for falling suppy (0x0 = powerwatch is off)
   */ 
  unsigned short pw_vpow_vth                   :    8;       /* [ 9:2] */
  /**
   * Hysteresis adder for rising supply
   */ 
  unsigned short pw_vpow_hyst                  :    4;       /* [13:10] */
  /**
   * 0: 4 … 16V nominal range <br>
   * 1: 8 … 32V nominal range
   */ 
  unsigned short pw_vpow_range                 :    1;       /* [14] */
  /**
   * 1: powerwatch vdd5tx is on
   */ 
  unsigned short pw_vdd5tx_npd                 :    1;       /* [15] */
} hv_ir_pwr_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR JTAG power configuration
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_pwr_config_bf bf;  ///< bit field representation
} hv_ir_pwr_config_t;


/* HV_IR_GPO5V */

#define MSK_HV_IR_GPO5V_HGPO_OUT                            (0x1)     /* [0] */
#define SFT_HV_IR_GPO5V_HGPO_OUT                            (0)
#define LSB_HV_IR_GPO5V_HGPO_OUT                            (0)
#define MSB_HV_IR_GPO5V_HGPO_OUT                            (0)
#define BIT_HV_IR_GPO5V_HGPO_OUT                            (0x1)     /* [0] */
#define MSK_HV_IR_GPO5V_HGPO_EN                             (0x1)     /* [1] */
#define SFT_HV_IR_GPO5V_HGPO_EN                             (1)
#define LSB_HV_IR_GPO5V_HGPO_EN                             (1)
#define MSB_HV_IR_GPO5V_HGPO_EN                             (1)
#define BIT_HV_IR_GPO5V_HGPO_EN                             (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR JTAG GPO 5V
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Output Data
   */ 
  unsigned short hgpo_out                      :    1;       /* [0] */
  /**
   * -> Output enable: <br>
   * 0: High-Z <br>
   * 1: Output is driven by hgpo_out
   */ 
  unsigned short hgpo_en                       :    1;       /* [1] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   14;
} hv_ir_gpo5v_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR JTAG GPO 5V
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_gpo5v_bf bf;  ///< bit field representation
} hv_ir_gpo5v_t;


/* HV_IR_HVHKMUX */

#define MSK_HV_IR_HVHKMUX_HHKMUX_SEL                        (0xf)     /* [ 3:0] */
#define SFT_HV_IR_HVHKMUX_HHKMUX_SEL                        (0)
#define LSB_HV_IR_HVHKMUX_HHKMUX_SEL                        (0)
#define MSB_HV_IR_HVHKMUX_HHKMUX_SEL                        (3)
#define MSK_HV_IR_HVHKMUX_HHKMUX_BYPASS_BUFFER              (0x1)     /* [4] */
#define SFT_HV_IR_HVHKMUX_HHKMUX_BYPASS_BUFFER              (4)
#define LSB_HV_IR_HVHKMUX_HHKMUX_BYPASS_BUFFER              (4)
#define MSB_HV_IR_HVHKMUX_HHKMUX_BYPASS_BUFFER              (4)
#define BIT_HV_IR_HVHKMUX_HHKMUX_BYPASS_BUFFER              (0x10)    /* [4] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR JTAG Housekeeping Multiplexer
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * 0: gnd (mux and buffers are disabled) <br>
   * 1: Vpow 1:18 <br>
   * 2: vdd5tx 1:3 <br>
   * 3: Isink0 1:18 <br>
   * 4: Isink1 1:18 <br>
   * 5: Isink2 1:18 <br>
   * 6: Temperature of HV temperature diode <br>
   * 7..10: not available <br>
   * 11: Isink0 1:3 <br>
   * 12: Isink1 1:3 <br>
   * 13: Isink2 1:3 <br>
   * 14..15: not available
   */ 
  unsigned short hhkmux_sel                    :    4;       /* [ 3:0] */
  /**
   * 0: signal is buffered <br>
   * 1: buffer is by-passed
   */ 
  unsigned short hhkmux_bypass_buffer          :    1;       /* [4] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   11;
} hv_ir_hvhkmux_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR JTAG Housekeeping Multiplexer
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_hvhkmux_bf bf;  ///< bit field representation
} hv_ir_hvhkmux_t;


/* HV_IR_ISINK0 */

#define MSK_HV_IR_ISINK0                                    (0xff)    /* [ 7:0] */

typedef unsigned short hv_ir_isink0_t;                                /* [ 7:0] */


/* HV_IR_ISINK1 */

#define MSK_HV_IR_ISINK1                                    (0xff)    /* [ 7:0] */

typedef unsigned short hv_ir_isink1_t;                                /* [ 7:0] */


/* HV_IR_ISINK2 */

#define MSK_HV_IR_ISINK2                                    (0xff)    /* [ 7:0] */

typedef unsigned short hv_ir_isink2_t;                                /* [ 7:0] */


/* HV_IR_RS485_CONFIG */

#define MSK_HV_IR_RS485_CONFIG_HRX485_NPD                   (0x1)     /* [0] */
#define SFT_HV_IR_RS485_CONFIG_HRX485_NPD                   (0)
#define LSB_HV_IR_RS485_CONFIG_HRX485_NPD                   (0)
#define MSB_HV_IR_RS485_CONFIG_HRX485_NPD                   (0)
#define BIT_HV_IR_RS485_CONFIG_HRX485_NPD                   (0x1)     /* [0] */
#define MSK_HV_IR_RS485_CONFIG_HTX485_NPD                   (0x1)     /* [1] */
#define SFT_HV_IR_RS485_CONFIG_HTX485_NPD                   (1)
#define LSB_HV_IR_RS485_CONFIG_HTX485_NPD                   (1)
#define MSB_HV_IR_RS485_CONFIG_HTX485_NPD                   (1)
#define BIT_HV_IR_RS485_CONFIG_HTX485_NPD                   (0x2)     /* [1] */
#define MSK_HV_IR_RS485_CONFIG_HTX485_SLEW_ENABLE           (0x1)     /* [2] */
#define SFT_HV_IR_RS485_CONFIG_HTX485_SLEW_ENABLE           (2)
#define LSB_HV_IR_RS485_CONFIG_HTX485_SLEW_ENABLE           (2)
#define MSB_HV_IR_RS485_CONFIG_HTX485_SLEW_ENABLE           (2)
#define BIT_HV_IR_RS485_CONFIG_HTX485_SLEW_ENABLE           (0x4)     /* [2] */
#define MSK_HV_IR_RS485_CONFIG_HTX485_BBM_FAST              (0x1)     /* [3] */
#define SFT_HV_IR_RS485_CONFIG_HTX485_BBM_FAST              (3)
#define LSB_HV_IR_RS485_CONFIG_HTX485_BBM_FAST              (3)
#define MSB_HV_IR_RS485_CONFIG_HTX485_BBM_FAST              (3)
#define BIT_HV_IR_RS485_CONFIG_HTX485_BBM_FAST              (0x8)     /* [3] */
#define MSK_HV_IR_RS485_CONFIG_HTX485_AUTO_SHUTDOWN         (0x3)     /* [ 5:4] */
#define SFT_HV_IR_RS485_CONFIG_HTX485_AUTO_SHUTDOWN         (4)
#define LSB_HV_IR_RS485_CONFIG_HTX485_AUTO_SHUTDOWN         (4)
#define MSB_HV_IR_RS485_CONFIG_HTX485_AUTO_SHUTDOWN         (5)
#define MSK_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_ENABLE       (0x3)     /* [ 7:6] */
#define SFT_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_ENABLE       (6)
#define LSB_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_ENABLE       (6)
#define MSB_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_ENABLE       (7)
#define MSK_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_MASK         (0x3)     /* [ 9:8] */
#define SFT_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_MASK         (8)
#define LSB_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_MASK         (8)
#define MSB_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_MASK         (9)


/* ############################################################################ */
/**
 * \brief This structure describes HV IR JTAG 485 Receiver
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * 1: Receiver is in functional mode <br>
   * 0: Receiver is in power down
   */ 
  unsigned short hrx485_npd                    :    1;       /* [0] */
  /**
   * 1: Transmitter is in functional mode <br>
   * 0: Transmitter is in power down (outputs disabled)
   */ 
  unsigned short htx485_npd                    :    1;       /* [1] */
  /**
   * 1: Slewrate is in active
   */ 
  unsigned short htx485_slew_enable            :    1;       /* [2] */
  /**
   * This bit controls transitions when slew rate is off <br>
   * '1': break-before-make (with transient tri-state) <br>
   * '0': between driven '0' and '1' is done with overlapping of P and N drivers for a short time. In this mode the bus is always driven
   */ 
  unsigned short htx485_bbm_fast               :    1;       /* [3] */
  /**
   * 00: temperature error ignored <br>
   * 10: synchronous shut down: <br>
   * - tx_enable@phy will be asserted when tx_enable@pad is asserted and temperature is ok <br>
   * - tx_enable@phy will be released only when tx_enable@pad is released (stays on, even if temperature errors occurs, to ensures that the transmission is finished) <br>
   * 11: asychronous shut down: <br>
   * - tx_enable@phy is off, when temperature error is active
   */ 
  unsigned short htx485_auto_shutdown          :    2;       /* [ 5:4] */
  /**
   * 00: temperature sensor is always off <br>
   * 10: temperature sensor is enabled / disabled with tx_enable@pad, but stays on, when a temperature orror occurs <br>
   * 11: temperature sense is always on
   */ 
  unsigned short htx485_tempsens_enable        :    2;       /* [ 7:6] */
  /**
   * Masks temperature errors (affects htx485_auto_shutdown and htx485_tempsens_enable) <br>
   * 00: no temperature errors <br>
   * 01: htx485_temperror <br>
   * 10: vdd5tx_temperror <br>
   * 11: both temperature errors
   */ 
  unsigned short htx485_tempsens_mask          :    2;       /* [ 9:8] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    6;
} hv_ir_rs485_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR JTAG 485 Receiver
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_rs485_config_bf bf;  ///< bit field representation
} hv_ir_rs485_config_t;


/* HV_IR_SELOUT */

#define MSK_HV_IR_SELOUT_HSELOUT_TX                         (0x1)     /* [0] */
#define SFT_HV_IR_SELOUT_HSELOUT_TX                         (0)
#define LSB_HV_IR_SELOUT_HSELOUT_TX                         (0)
#define MSB_HV_IR_SELOUT_HSELOUT_TX                         (0)
#define BIT_HV_IR_SELOUT_HSELOUT_TX                         (0x1)     /* [0] */
#define MSK_HV_IR_SELOUT_HSELOUT_NPD                        (0x1)     /* [1] */
#define SFT_HV_IR_SELOUT_HSELOUT_NPD                        (1)
#define LSB_HV_IR_SELOUT_HSELOUT_NPD                        (1)
#define MSB_HV_IR_SELOUT_HSELOUT_NPD                        (1)
#define BIT_HV_IR_SELOUT_HSELOUT_NPD                        (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR JTAG SelOut
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Digital selout data: <br>
   * '0': selout open <br>
   * '1': selout pulls to GND
   */ 
  unsigned short hselout_tx                    :    1;       /* [0] */
  /**
   * 1: Selout powered up
   */ 
  unsigned short hselout_npd                   :    1;       /* [1] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   14;
} hv_ir_selout_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR JTAG SelOut
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_selout_bf bf;  ///< bit field representation
} hv_ir_selout_t;


/* HV_IR_SELIN_CONFIG */

#define MSK_HV_IR_SELIN_CONFIG_HSELIN_NPD                   (0x1)     /* [0] */
#define SFT_HV_IR_SELIN_CONFIG_HSELIN_NPD                   (0)
#define LSB_HV_IR_SELIN_CONFIG_HSELIN_NPD                   (0)
#define MSB_HV_IR_SELIN_CONFIG_HSELIN_NPD                   (0)
#define BIT_HV_IR_SELIN_CONFIG_HSELIN_NPD                   (0x1)     /* [0] */
#define MSK_HV_IR_SELIN_CONFIG_HSELIN_VLIM                  (0x1)     /* [1] */
#define SFT_HV_IR_SELIN_CONFIG_HSELIN_VLIM                  (1)
#define LSB_HV_IR_SELIN_CONFIG_HSELIN_VLIM                  (1)
#define MSB_HV_IR_SELIN_CONFIG_HSELIN_VLIM                  (1)
#define BIT_HV_IR_SELIN_CONFIG_HSELIN_VLIM                  (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR JTAG SelIn
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * 1: Selin powered up
   */ 
  unsigned short hselin_npd                    :    1;       /* [0] */
  /**
   * 0: voltage-limiter off <br>
   * 1: voltage-limiter on
   */ 
  unsigned short hselin_vlim                   :    1;       /* [1] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   14;
} hv_ir_selin_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR JTAG SelIn
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_selin_config_bf bf;  ///< bit field representation
} hv_ir_selin_config_t;


/* HV_IR_SELIN_STATUS */

#define MSK_HV_IR_SELIN_STATUS_HSELIN_RX                    (0x1)     /* [0] */
#define SFT_HV_IR_SELIN_STATUS_HSELIN_RX                    (0)
#define LSB_HV_IR_SELIN_STATUS_HSELIN_RX                    (0)
#define MSB_HV_IR_SELIN_STATUS_HSELIN_RX                    (0)
#define BIT_HV_IR_SELIN_STATUS_HSELIN_RX                    (0x1)     /* [0] */
#define MSK_HV_IR_SELIN_STATUS_HSELOUT_ACK                  (0x1)     /* [1] */
#define SFT_HV_IR_SELIN_STATUS_HSELOUT_ACK                  (1)
#define LSB_HV_IR_SELIN_STATUS_HSELOUT_ACK                  (1)
#define MSB_HV_IR_SELIN_STATUS_HSELOUT_ACK                  (1)
#define BIT_HV_IR_SELIN_STATUS_HSELOUT_ACK                  (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR JTAG SelIO status
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Digital selin data: <br>
   * '0': current smaller than threshold <br>
   * '1': current higher than threshold
   */ 
  unsigned short hselin_rx                     :    1;       /* [0] */
  /**
   * Digital selout data: <br>
   * '0': current smaller than threshold <br>
   * '1': current higher than threshold
   */ 
  unsigned short hselout_ack                   :    1;       /* [1] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   14;
} hv_ir_selin_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR JTAG SelIO status
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_selin_status_bf bf;  ///< bit field representation
} hv_ir_selin_status_t;


/* HV_IR_STATUS */

#define MSK_HV_IR_STATUS_HSELIN_RX                          (0x1)     /* [0] */
#define SFT_HV_IR_STATUS_HSELIN_RX                          (0)
#define LSB_HV_IR_STATUS_HSELIN_RX                          (0)
#define MSB_HV_IR_STATUS_HSELIN_RX                          (0)
#define BIT_HV_IR_STATUS_HSELIN_RX                          (0x1)     /* [0] */
#define MSK_HV_IR_STATUS_HSELIN_RX_N                        (0x1)     /* [1] */
#define SFT_HV_IR_STATUS_HSELIN_RX_N                        (1)
#define LSB_HV_IR_STATUS_HSELIN_RX_N                        (1)
#define MSB_HV_IR_STATUS_HSELIN_RX_N                        (1)
#define BIT_HV_IR_STATUS_HSELIN_RX_N                        (0x2)     /* [1] */
#define MSK_HV_IR_STATUS_PW_VDD5TX_FAIL                     (0x1)     /* [2] */
#define SFT_HV_IR_STATUS_PW_VDD5TX_FAIL                     (2)
#define LSB_HV_IR_STATUS_PW_VDD5TX_FAIL                     (2)
#define MSB_HV_IR_STATUS_PW_VDD5TX_FAIL                     (2)
#define BIT_HV_IR_STATUS_PW_VDD5TX_FAIL                     (0x4)     /* [2] */
#define MSK_HV_IR_STATUS_PW_VPOW_FAIL                       (0x1)     /* [3] */
#define SFT_HV_IR_STATUS_PW_VPOW_FAIL                       (3)
#define LSB_HV_IR_STATUS_PW_VPOW_FAIL                       (3)
#define MSB_HV_IR_STATUS_PW_VPOW_FAIL                       (3)
#define BIT_HV_IR_STATUS_PW_VPOW_FAIL                       (0x8)     /* [3] */
#define MSK_HV_IR_STATUS_VDD5TX_TEMPERROR                   (0x1)     /* [4] */
#define SFT_HV_IR_STATUS_VDD5TX_TEMPERROR                   (4)
#define LSB_HV_IR_STATUS_VDD5TX_TEMPERROR                   (4)
#define MSB_HV_IR_STATUS_VDD5TX_TEMPERROR                   (4)
#define BIT_HV_IR_STATUS_VDD5TX_TEMPERROR                   (0x10)    /* [4] */
#define MSK_HV_IR_STATUS_HTX485_TEMPERROR                   (0x1)     /* [5] */
#define SFT_HV_IR_STATUS_HTX485_TEMPERROR                   (5)
#define LSB_HV_IR_STATUS_HTX485_TEMPERROR                   (5)
#define MSB_HV_IR_STATUS_HTX485_TEMPERROR                   (5)
#define BIT_HV_IR_STATUS_HTX485_TEMPERROR                   (0x20)    /* [5] */
#define MSK_HV_IR_STATUS_RESET_FLAG                         (0x1)     /* [6] */
#define SFT_HV_IR_STATUS_RESET_FLAG                         (6)
#define LSB_HV_IR_STATUS_RESET_FLAG                         (6)
#define MSB_HV_IR_STATUS_RESET_FLAG                         (6)
#define BIT_HV_IR_STATUS_RESET_FLAG                         (0x40)    /* [6] */
#define MSK_HV_IR_STATUS_HSELOUT_ACK                        (0x1)     /* [7] */
#define SFT_HV_IR_STATUS_HSELOUT_ACK                        (7)
#define LSB_HV_IR_STATUS_HSELOUT_ACK                        (7)
#define MSB_HV_IR_STATUS_HSELOUT_ACK                        (7)
#define BIT_HV_IR_STATUS_HSELOUT_ACK                        (0x80)    /* [7] */
#define MSK_HV_IR_STATUS_HSELOUT_ACK_N                      (0x1)     /* [8] */
#define SFT_HV_IR_STATUS_HSELOUT_ACK_N                      (8)
#define LSB_HV_IR_STATUS_HSELOUT_ACK_N                      (8)
#define MSB_HV_IR_STATUS_HSELOUT_ACK_N                      (8)
#define BIT_HV_IR_STATUS_HSELOUT_ACK_N                      (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR status
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Same as IR_SELIO_STATUS.hselin_rx
   */ 
  unsigned short hselin_rx                     :    1;       /* [0] */
  /**
   * Inverted hselin_rx
   */ 
  unsigned short hselin_rx_n                   :    1;       /* [1] */
  /**
   * 1: powerwatch for vdd5tx detected undervoltage
   */ 
  unsigned short pw_vdd5tx_fail                :    1;       /* [2] */
  /**
   * 1: powerwatch for vpow detected undervoltage
   */ 
  unsigned short pw_vpow_fail                  :    1;       /* [3] */
  /**
   * 1: temperature sensor of vdd5tx regulator detected overtemperature
   */ 
  unsigned short vdd5tx_temperror              :    1;       /* [4] */
  /**
   * 1: any of the temperature sensors of htx485 transmitter detected overtemperature
   */ 
  unsigned short htx485_temperror              :    1;       /* [5] */
  /**
   * A reset was done by hv_nres
   */ 
  unsigned short reset_flag                    :    1;       /* [6] */
  /**
   * Same as IR_SELIO_STATUS.hselout_ack
   */ 
  unsigned short hselout_ack                   :    1;       /* [7] */
  /**
   * Inverted hselout_ack
   */ 
  unsigned short hselout_ack_n                 :    1;       /* [8] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    7;
} hv_ir_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR status
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_status_bf bf;  ///< bit field representation
} hv_ir_status_t;


/* HV_IR_MASK */

#define MSK_HV_IR_MASK                                      (0x1ff)   /* [ 8:0] */

typedef unsigned short hv_ir_mask_t;                                  /* [ 8:0] */


/* HV_IR_CLEAR_RESET_FLAG */

#define MSK_HV_IR_CLEAR_RESET_FLAG                          (0x1)     /* [0] */

typedef unsigned short hv_ir_clear_reset_flag_t;                      /* [0] */


/* HV_IR_VERSION */

#define MSK_HV_IR_VERSION_METAL_VERSION                     (0x1f)    /* [ 4:0] */
#define SFT_HV_IR_VERSION_METAL_VERSION                     (0)
#define LSB_HV_IR_VERSION_METAL_VERSION                     (0)
#define MSB_HV_IR_VERSION_METAL_VERSION                     (4)
#define MSK_HV_IR_VERSION_RELEASE                           (0x7ff)   /* [15:5] */
#define SFT_HV_IR_VERSION_RELEASE                           (5)
#define LSB_HV_IR_VERSION_RELEASE                           (5)
#define MSB_HV_IR_VERSION_RELEASE                           (15)


/* ############################################################################ */
/**
 * \brief This structure describes HV IR version
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Version of metal fix: <br>
   * if .release == 1 <br>
   *   1: T70313A <br>
   *   2: T70313B <br>
   *   3: T70313C <br>
   *   4: T70313D <br>
   *   5: T70313E <br>
   *   6: T70313F <br>
   *   7: T70313G <br>
   *   8: T70313H <br>
   *   9: T70313I <br>
   *   10: T70313K <br>
   *   11: T70313L <br>
   *   16: E70313A <br>
   * if .release == 0 <br>
   *   fixed to 0
   */ 
  unsigned short metal_version                 :    5;       /* [ 4:0] */
  /**
   * Fixed to 1 <br>
   * 0: M70313A <br>
   * 1: T70313A .. F, E70313A
   */ 
  unsigned short release                       :   11;       /* [15:5] */
} hv_ir_version_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR version
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_version_bf bf;  ///< bit field representation
} hv_ir_version_t;


/* HV_IR_CAL0 */

#define MSK_HV_IR_CAL0_CAL_REF_BG                           (0xf)     /* [ 3:0] */
#define SFT_HV_IR_CAL0_CAL_REF_BG                           (0)
#define LSB_HV_IR_CAL0_CAL_REF_BG                           (0)
#define MSB_HV_IR_CAL0_CAL_REF_BG                           (3)
#define MSK_HV_IR_CAL0_CAL_REF_ICONST                       (0xf)     /* [ 7:4] */
#define SFT_HV_IR_CAL0_CAL_REF_ICONST                       (4)
#define LSB_HV_IR_CAL0_CAL_REF_ICONST                       (4)
#define MSB_HV_IR_CAL0_CAL_REF_ICONST                       (7)
#define MSK_HV_IR_CAL0_CAL_REF_TDIOL                        (0xf)     /* [11:8] */
#define SFT_HV_IR_CAL0_CAL_REF_TDIOL                        (8)
#define LSB_HV_IR_CAL0_CAL_REF_TDIOL                        (8)
#define MSB_HV_IR_CAL0_CAL_REF_TDIOL                        (11)
#define MSK_HV_IR_CAL0_CAL_REF_TDIOH                        (0xf)     /* [15:12] */
#define SFT_HV_IR_CAL0_CAL_REF_TDIOH                        (12)
#define LSB_HV_IR_CAL0_CAL_REF_TDIOH                        (12)
#define MSB_HV_IR_CAL0_CAL_REF_TDIOH                        (15)


/* ############################################################################ */
/**
 * \brief This structure describes HV IR calibration data 0
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Calibration data for reference bandgap
   */ 
  unsigned short cal_ref_bg                    :    4;       /* [ 3:0] */
  /**
   * Calibration data for reference current increasing
   */ 
  unsigned short cal_ref_iconst                :    4;       /* [ 7:4] */
  /**
   * Calibration data for temperature low voltage (=high T) threshold increasing
   */ 
  unsigned short cal_ref_tdiol                 :    4;       /* [11:8] */
  /**
   * Calibration data for temperature high voltage (=low T) threshold increasing
   */ 
  unsigned short cal_ref_tdioh                 :    4;       /* [15:12] */
} hv_ir_cal0_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR calibration data 0
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_cal0_bf bf;  ///< bit field representation
} hv_ir_cal0_t;


/* HV_IR_CAL1 */

#define MSK_HV_IR_CAL1_CAL_VREG_VDD3V3                      (0x3)     /* [ 1:0] */
#define SFT_HV_IR_CAL1_CAL_VREG_VDD3V3                      (0)
#define LSB_HV_IR_CAL1_CAL_VREG_VDD3V3                      (0)
#define MSB_HV_IR_CAL1_CAL_VREG_VDD3V3                      (1)
#define MSK_HV_IR_CAL1_CAL_VREG_VDD3V3A                     (0x3)     /* [ 3:2] */
#define SFT_HV_IR_CAL1_CAL_VREG_VDD3V3A                     (2)
#define LSB_HV_IR_CAL1_CAL_VREG_VDD3V3A                     (2)
#define MSB_HV_IR_CAL1_CAL_VREG_VDD3V3A                     (3)
#define MSK_HV_IR_CAL1_CAL_VREG_VDD5TX                      (0x3)     /* [ 5:4] */
#define SFT_HV_IR_CAL1_CAL_VREG_VDD5TX                      (4)
#define LSB_HV_IR_CAL1_CAL_VREG_VDD5TX                      (4)
#define MSB_HV_IR_CAL1_CAL_VREG_VDD5TX                      (5)
#define MSK_HV_IR_CAL1_CAL_HPW_VDD5TX                       (0x3)     /* [ 9:8] */
#define SFT_HV_IR_CAL1_CAL_HPW_VDD5TX                       (8)
#define LSB_HV_IR_CAL1_CAL_HPW_VDD5TX                       (8)
#define MSB_HV_IR_CAL1_CAL_HPW_VDD5TX                       (9)
#define MSK_HV_IR_CAL1_CAL_PAD_SELDRV                       (0x1)     /* [10] */
#define SFT_HV_IR_CAL1_CAL_PAD_SELDRV                       (10)
#define LSB_HV_IR_CAL1_CAL_PAD_SELDRV                       (10)
#define MSB_HV_IR_CAL1_CAL_PAD_SELDRV                       (10)
#define BIT_HV_IR_CAL1_CAL_PAD_SELDRV                       (0x400)   /* [10] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR calibration data 1
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Calibration data for vreg3v3: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: debug, do not use
   */ 
  unsigned short cal_vreg_vdd3v3               :    2;       /* [ 1:0] */
  /**
   * Calibration data for vreg3v3a: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: debug, do not use
   */ 
  unsigned short cal_vreg_vdd3v3a              :    2;       /* [ 3:2] */
  /**
   * Calibration data for vreg5tx: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: debug, do not use
   */ 
  unsigned short cal_vreg_vdd5tx               :    2;       /* [ 5:4] */
  /**
   * Reserved
   */ 
  unsigned short reserved7                     :    2;       /* [ 7:6] */
  /**
   * Calibration data for powerwatch vdd5tx: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: +6%
   */ 
  unsigned short cal_hpw_vdd5tx                :    2;       /* [ 9:8] */
  /**
   * 0: low driver strength for digital output pads <br>
   * 1: high driver strength for digital output pads
   */ 
  unsigned short cal_pad_seldrv                :    1;       /* [10] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    5;
} hv_ir_cal1_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR calibration data 1
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_cal1_bf bf;  ///< bit field representation
} hv_ir_cal1_t;


/* HV_IR_CAL2 */

#define MSK_HV_IR_CAL2_CAL_HTX485_A_OCN                     (0x7)     /* [ 2:0] */
#define SFT_HV_IR_CAL2_CAL_HTX485_A_OCN                     (0)
#define LSB_HV_IR_CAL2_CAL_HTX485_A_OCN                     (0)
#define MSB_HV_IR_CAL2_CAL_HTX485_A_OCN                     (2)
#define MSK_HV_IR_CAL2_CAL_HTX485_A_OCP                     (0x7)     /* [ 5:3] */
#define SFT_HV_IR_CAL2_CAL_HTX485_A_OCP                     (3)
#define LSB_HV_IR_CAL2_CAL_HTX485_A_OCP                     (3)
#define MSB_HV_IR_CAL2_CAL_HTX485_A_OCP                     (5)
#define MSK_HV_IR_CAL2_CAL_HTX485_B_OCN                     (0x7)     /* [ 8:6] */
#define SFT_HV_IR_CAL2_CAL_HTX485_B_OCN                     (6)
#define LSB_HV_IR_CAL2_CAL_HTX485_B_OCN                     (6)
#define MSB_HV_IR_CAL2_CAL_HTX485_B_OCN                     (8)
#define MSK_HV_IR_CAL2_CAL_HTX485_B_OCP                     (0x7)     /* [11:9] */
#define SFT_HV_IR_CAL2_CAL_HTX485_B_OCP                     (9)
#define LSB_HV_IR_CAL2_CAL_HTX485_B_OCP                     (9)
#define MSB_HV_IR_CAL2_CAL_HTX485_B_OCP                     (11)
#define MSK_HV_IR_CAL2_CAL_HTX485_SLEW                      (0x1)     /* [12] */
#define SFT_HV_IR_CAL2_CAL_HTX485_SLEW                      (12)
#define LSB_HV_IR_CAL2_CAL_HTX485_SLEW                      (12)
#define MSB_HV_IR_CAL2_CAL_HTX485_SLEW                      (12)
#define BIT_HV_IR_CAL2_CAL_HTX485_SLEW                      (0x1000)  /* [12] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR calibration data 2
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Calibration data for htx485 line A high-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_a_ocn              :    3;       /* [ 2:0] */
  /**
   * Calibration data for htx485 line A low-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_a_ocp              :    3;       /* [ 5:3] */
  /**
   * Calibration data for htx485 line B high-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_b_ocn              :    3;       /* [ 8:6] */
  /**
   * Calibration data for htx485 line B low-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_b_ocp              :    3;       /* [11:9] */
  /**
   * This bit controls the slew rate speed when slew rate is enabled: <br>
   * 0: slew rate is normal <br>
   * 1: slew rate is slower
   */ 
  unsigned short cal_htx485_slew               :    1;       /* [12] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    3;
} hv_ir_cal2_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR calibration data 2
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_cal2_bf bf;  ///< bit field representation
} hv_ir_cal2_t;


/* HV_IR_CAL0_CLR */

#define MSK_HV_IR_CAL0_CLR_CAL_REF_BG                       (0xf)     /* [ 3:0] */
#define SFT_HV_IR_CAL0_CLR_CAL_REF_BG                       (0)
#define LSB_HV_IR_CAL0_CLR_CAL_REF_BG                       (0)
#define MSB_HV_IR_CAL0_CLR_CAL_REF_BG                       (3)
#define MSK_HV_IR_CAL0_CLR_CAL_REF_ICONST                   (0xf)     /* [ 7:4] */
#define SFT_HV_IR_CAL0_CLR_CAL_REF_ICONST                   (4)
#define LSB_HV_IR_CAL0_CLR_CAL_REF_ICONST                   (4)
#define MSB_HV_IR_CAL0_CLR_CAL_REF_ICONST                   (7)
#define MSK_HV_IR_CAL0_CLR_CAL_REF_TDIOL                    (0xf)     /* [11:8] */
#define SFT_HV_IR_CAL0_CLR_CAL_REF_TDIOL                    (8)
#define LSB_HV_IR_CAL0_CLR_CAL_REF_TDIOL                    (8)
#define MSB_HV_IR_CAL0_CLR_CAL_REF_TDIOL                    (11)
#define MSK_HV_IR_CAL0_CLR_CAL_REF_TDIOH                    (0xf)     /* [15:12] */
#define SFT_HV_IR_CAL0_CLR_CAL_REF_TDIOH                    (12)
#define LSB_HV_IR_CAL0_CLR_CAL_REF_TDIOH                    (12)
#define MSB_HV_IR_CAL0_CLR_CAL_REF_TDIOH                    (15)


/* ############################################################################ */
/**
 * \brief This structure describes HV IR calibration data 0 clear
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Calibration data for reference bandgap
   */ 
  unsigned short cal_ref_bg                    :    4;       /* [ 3:0] */
  /**
   * Calibration data for reference current increasing
   */ 
  unsigned short cal_ref_iconst                :    4;       /* [ 7:4] */
  /**
   * Calibration data for temperature low voltage (=high T) threshold increasing
   */ 
  unsigned short cal_ref_tdiol                 :    4;       /* [11:8] */
  /**
   * Calibration data for temperature high voltage (=low T) threshold increasing
   */ 
  unsigned short cal_ref_tdioh                 :    4;       /* [15:12] */
} hv_ir_cal0_clr_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR calibration data 0 clear
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_cal0_clr_bf bf;  ///< bit field representation
} hv_ir_cal0_clr_t;


/* HV_IR_CAL1_CLR */

#define MSK_HV_IR_CAL1_CLR_CAL_VREG_VDD3V3                  (0x3)     /* [ 1:0] */
#define SFT_HV_IR_CAL1_CLR_CAL_VREG_VDD3V3                  (0)
#define LSB_HV_IR_CAL1_CLR_CAL_VREG_VDD3V3                  (0)
#define MSB_HV_IR_CAL1_CLR_CAL_VREG_VDD3V3                  (1)
#define MSK_HV_IR_CAL1_CLR_CAL_VREG_VDD3V3A                 (0x3)     /* [ 3:2] */
#define SFT_HV_IR_CAL1_CLR_CAL_VREG_VDD3V3A                 (2)
#define LSB_HV_IR_CAL1_CLR_CAL_VREG_VDD3V3A                 (2)
#define MSB_HV_IR_CAL1_CLR_CAL_VREG_VDD3V3A                 (3)
#define MSK_HV_IR_CAL1_CLR_CAL_VREG_VDD5TX                  (0x3)     /* [ 5:4] */
#define SFT_HV_IR_CAL1_CLR_CAL_VREG_VDD5TX                  (4)
#define LSB_HV_IR_CAL1_CLR_CAL_VREG_VDD5TX                  (4)
#define MSB_HV_IR_CAL1_CLR_CAL_VREG_VDD5TX                  (5)
#define MSK_HV_IR_CAL1_CLR_CAL_SELIN                        (0x3)     /* [ 7:6] */
#define SFT_HV_IR_CAL1_CLR_CAL_SELIN                        (6)
#define LSB_HV_IR_CAL1_CLR_CAL_SELIN                        (6)
#define MSB_HV_IR_CAL1_CLR_CAL_SELIN                        (7)
#define MSK_HV_IR_CAL1_CLR_CAL_HPW_VDD5TX                   (0x3)     /* [ 9:8] */
#define SFT_HV_IR_CAL1_CLR_CAL_HPW_VDD5TX                   (8)
#define LSB_HV_IR_CAL1_CLR_CAL_HPW_VDD5TX                   (8)
#define MSB_HV_IR_CAL1_CLR_CAL_HPW_VDD5TX                   (9)
#define MSK_HV_IR_CAL1_CLR_CAL_PAD_SELDRV                   (0x1)     /* [10] */
#define SFT_HV_IR_CAL1_CLR_CAL_PAD_SELDRV                   (10)
#define LSB_HV_IR_CAL1_CLR_CAL_PAD_SELDRV                   (10)
#define MSB_HV_IR_CAL1_CLR_CAL_PAD_SELDRV                   (10)
#define BIT_HV_IR_CAL1_CLR_CAL_PAD_SELDRV                   (0x400)   /* [10] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR calibration data 1 clear
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Calibration data for vreg3v3: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: debug, do not use
   */ 
  unsigned short cal_vreg_vdd3v3               :    2;       /* [ 1:0] */
  /**
   * Calibration data for vreg3v3a: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: debug, do not use
   */ 
  unsigned short cal_vreg_vdd3v3a              :    2;       /* [ 3:2] */
  /**
   * Calibration data for vreg5tx: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: debug, do not use
   */ 
  unsigned short cal_vreg_vdd5tx               :    2;       /* [ 5:4] */
  /**
   * 
   */ 
  unsigned short cal_selin                     :    2;       /* [ 7:6] */
  /**
   * Calibration data for powerwatch vdd5tx: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: +6%
   */ 
  unsigned short cal_hpw_vdd5tx                :    2;       /* [ 9:8] */
  /**
   * 0: low driver strength for digital output pads <br>
   * 1: high driver strength for digital output pads
   */ 
  unsigned short cal_pad_seldrv                :    1;       /* [10] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    5;
} hv_ir_cal1_clr_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR calibration data 1 clear
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_cal1_clr_bf bf;  ///< bit field representation
} hv_ir_cal1_clr_t;


/* HV_IR_CAL2_CLR */

#define MSK_HV_IR_CAL2_CLR_CAL_HTX485_A_OCN                 (0x7)     /* [ 2:0] */
#define SFT_HV_IR_CAL2_CLR_CAL_HTX485_A_OCN                 (0)
#define LSB_HV_IR_CAL2_CLR_CAL_HTX485_A_OCN                 (0)
#define MSB_HV_IR_CAL2_CLR_CAL_HTX485_A_OCN                 (2)
#define MSK_HV_IR_CAL2_CLR_CAL_HTX485_A_OCP                 (0x7)     /* [ 5:3] */
#define SFT_HV_IR_CAL2_CLR_CAL_HTX485_A_OCP                 (3)
#define LSB_HV_IR_CAL2_CLR_CAL_HTX485_A_OCP                 (3)
#define MSB_HV_IR_CAL2_CLR_CAL_HTX485_A_OCP                 (5)
#define MSK_HV_IR_CAL2_CLR_CAL_HTX485_B_OCN                 (0x7)     /* [ 8:6] */
#define SFT_HV_IR_CAL2_CLR_CAL_HTX485_B_OCN                 (6)
#define LSB_HV_IR_CAL2_CLR_CAL_HTX485_B_OCN                 (6)
#define MSB_HV_IR_CAL2_CLR_CAL_HTX485_B_OCN                 (8)
#define MSK_HV_IR_CAL2_CLR_CAL_HTX485_B_OCP                 (0x7)     /* [11:9] */
#define SFT_HV_IR_CAL2_CLR_CAL_HTX485_B_OCP                 (9)
#define LSB_HV_IR_CAL2_CLR_CAL_HTX485_B_OCP                 (9)
#define MSB_HV_IR_CAL2_CLR_CAL_HTX485_B_OCP                 (11)
#define MSK_HV_IR_CAL2_CLR_CAL_HTX485_SLEW                  (0x1)     /* [12] */
#define SFT_HV_IR_CAL2_CLR_CAL_HTX485_SLEW                  (12)
#define LSB_HV_IR_CAL2_CLR_CAL_HTX485_SLEW                  (12)
#define MSB_HV_IR_CAL2_CLR_CAL_HTX485_SLEW                  (12)
#define BIT_HV_IR_CAL2_CLR_CAL_HTX485_SLEW                  (0x1000)  /* [12] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR calibration data 2 clear
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Calibration data for htx485 line A high-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_a_ocn              :    3;       /* [ 2:0] */
  /**
   * Calibration data for htx485 line A low-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_a_ocp              :    3;       /* [ 5:3] */
  /**
   * Calibration data for htx485 line B high-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_b_ocn              :    3;       /* [ 8:6] */
  /**
   * Calibration data for htx485 line B low-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_b_ocp              :    3;       /* [11:9] */
  /**
   * This bit controls the slew rate speed when slew rate is enabled <br>
   * 0: slew rate is normal <br>
   * 1: slew rate is slower
   */ 
  unsigned short cal_htx485_slew               :    1;       /* [12] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    3;
} hv_ir_cal2_clr_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR calibration data 2 clear
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_cal2_clr_bf bf;  ///< bit field representation
} hv_ir_cal2_clr_t;


/* HV_IR_CAL0_SET */

#define MSK_HV_IR_CAL0_SET_CAL_REF_BG                       (0xf)     /* [ 3:0] */
#define SFT_HV_IR_CAL0_SET_CAL_REF_BG                       (0)
#define LSB_HV_IR_CAL0_SET_CAL_REF_BG                       (0)
#define MSB_HV_IR_CAL0_SET_CAL_REF_BG                       (3)
#define MSK_HV_IR_CAL0_SET_CAL_REF_ICONST                   (0xf)     /* [ 7:4] */
#define SFT_HV_IR_CAL0_SET_CAL_REF_ICONST                   (4)
#define LSB_HV_IR_CAL0_SET_CAL_REF_ICONST                   (4)
#define MSB_HV_IR_CAL0_SET_CAL_REF_ICONST                   (7)
#define MSK_HV_IR_CAL0_SET_CAL_REF_TDIOL                    (0xf)     /* [11:8] */
#define SFT_HV_IR_CAL0_SET_CAL_REF_TDIOL                    (8)
#define LSB_HV_IR_CAL0_SET_CAL_REF_TDIOL                    (8)
#define MSB_HV_IR_CAL0_SET_CAL_REF_TDIOL                    (11)
#define MSK_HV_IR_CAL0_SET_CAL_REF_TDIOH                    (0xf)     /* [15:12] */
#define SFT_HV_IR_CAL0_SET_CAL_REF_TDIOH                    (12)
#define LSB_HV_IR_CAL0_SET_CAL_REF_TDIOH                    (12)
#define MSB_HV_IR_CAL0_SET_CAL_REF_TDIOH                    (15)


/* ############################################################################ */
/**
 * \brief This structure describes HV IR calibration data 0 set
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Calibration data for reference bandgap
   */ 
  unsigned short cal_ref_bg                    :    4;       /* [ 3:0] */
  /**
   * Calibration data for reference current increasing
   */ 
  unsigned short cal_ref_iconst                :    4;       /* [ 7:4] */
  /**
   * Calibration data for temperature low voltage (=high T) threshold increasing
   */ 
  unsigned short cal_ref_tdiol                 :    4;       /* [11:8] */
  /**
   * Calibration data for temperature high voltage (=low T) threshold increasing
   */ 
  unsigned short cal_ref_tdioh                 :    4;       /* [15:12] */
} hv_ir_cal0_set_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR calibration data 0 set
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_cal0_set_bf bf;  ///< bit field representation
} hv_ir_cal0_set_t;


/* HV_IR_CAL1_SET */

#define MSK_HV_IR_CAL1_SET_CAL_VREG_VDD3V3                  (0x3)     /* [ 1:0] */
#define SFT_HV_IR_CAL1_SET_CAL_VREG_VDD3V3                  (0)
#define LSB_HV_IR_CAL1_SET_CAL_VREG_VDD3V3                  (0)
#define MSB_HV_IR_CAL1_SET_CAL_VREG_VDD3V3                  (1)
#define MSK_HV_IR_CAL1_SET_CAL_VREG_VDD3V3A                 (0x3)     /* [ 3:2] */
#define SFT_HV_IR_CAL1_SET_CAL_VREG_VDD3V3A                 (2)
#define LSB_HV_IR_CAL1_SET_CAL_VREG_VDD3V3A                 (2)
#define MSB_HV_IR_CAL1_SET_CAL_VREG_VDD3V3A                 (3)
#define MSK_HV_IR_CAL1_SET_CAL_VREG_VDD5TX                  (0x3)     /* [ 5:4] */
#define SFT_HV_IR_CAL1_SET_CAL_VREG_VDD5TX                  (4)
#define LSB_HV_IR_CAL1_SET_CAL_VREG_VDD5TX                  (4)
#define MSB_HV_IR_CAL1_SET_CAL_VREG_VDD5TX                  (5)
#define MSK_HV_IR_CAL1_SET_CAL_SELIN                        (0x3)     /* [ 7:6] */
#define SFT_HV_IR_CAL1_SET_CAL_SELIN                        (6)
#define LSB_HV_IR_CAL1_SET_CAL_SELIN                        (6)
#define MSB_HV_IR_CAL1_SET_CAL_SELIN                        (7)
#define MSK_HV_IR_CAL1_SET_CAL_HPW_VDD5TX                   (0x3)     /* [ 9:8] */
#define SFT_HV_IR_CAL1_SET_CAL_HPW_VDD5TX                   (8)
#define LSB_HV_IR_CAL1_SET_CAL_HPW_VDD5TX                   (8)
#define MSB_HV_IR_CAL1_SET_CAL_HPW_VDD5TX                   (9)
#define MSK_HV_IR_CAL1_SET_CAL_PAD_SELDRV                   (0x1)     /* [10] */
#define SFT_HV_IR_CAL1_SET_CAL_PAD_SELDRV                   (10)
#define LSB_HV_IR_CAL1_SET_CAL_PAD_SELDRV                   (10)
#define MSB_HV_IR_CAL1_SET_CAL_PAD_SELDRV                   (10)
#define BIT_HV_IR_CAL1_SET_CAL_PAD_SELDRV                   (0x400)   /* [10] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR calibration data 1 set
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Calibration data for vreg3v3: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: debug, do not use
   */ 
  unsigned short cal_vreg_vdd3v3               :    2;       /* [ 1:0] */
  /**
   * Calibration data for vreg3v3a: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: debug, do not use
   */ 
  unsigned short cal_vreg_vdd3v3a              :    2;       /* [ 3:2] */
  /**
   * Calibration data for vreg5tx: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: debug, do not use
   */ 
  unsigned short cal_vreg_vdd5tx               :    2;       /* [ 5:4] */
  /**
   * 
   */ 
  unsigned short cal_selin                     :    2;       /* [ 7:6] */
  /**
   * Calibration data for powerwatch vdd5tx: <br>
   * 0: normal <br>
   * 1: +2% <br>
   * 2: -2% <br>
   * 3: +6%
   */ 
  unsigned short cal_hpw_vdd5tx                :    2;       /* [ 9:8] */
  /**
   * 0: low driver strength for digital output pads <br>
   * 1: high driver strength for digital output pads
   */ 
  unsigned short cal_pad_seldrv                :    1;       /* [10] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    5;
} hv_ir_cal1_set_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR calibration data 1 set
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_cal1_set_bf bf;  ///< bit field representation
} hv_ir_cal1_set_t;


/* HV_IR_CAL2_SET */

#define MSK_HV_IR_CAL2_SET_CAL_HTX485_A_OCN                 (0x7)     /* [ 2:0] */
#define SFT_HV_IR_CAL2_SET_CAL_HTX485_A_OCN                 (0)
#define LSB_HV_IR_CAL2_SET_CAL_HTX485_A_OCN                 (0)
#define MSB_HV_IR_CAL2_SET_CAL_HTX485_A_OCN                 (2)
#define MSK_HV_IR_CAL2_SET_CAL_HTX485_A_OCP                 (0x7)     /* [ 5:3] */
#define SFT_HV_IR_CAL2_SET_CAL_HTX485_A_OCP                 (3)
#define LSB_HV_IR_CAL2_SET_CAL_HTX485_A_OCP                 (3)
#define MSB_HV_IR_CAL2_SET_CAL_HTX485_A_OCP                 (5)
#define MSK_HV_IR_CAL2_SET_CAL_HTX485_B_OCN                 (0x7)     /* [ 8:6] */
#define SFT_HV_IR_CAL2_SET_CAL_HTX485_B_OCN                 (6)
#define LSB_HV_IR_CAL2_SET_CAL_HTX485_B_OCN                 (6)
#define MSB_HV_IR_CAL2_SET_CAL_HTX485_B_OCN                 (8)
#define MSK_HV_IR_CAL2_SET_CAL_HTX485_B_OCP                 (0x7)     /* [11:9] */
#define SFT_HV_IR_CAL2_SET_CAL_HTX485_B_OCP                 (9)
#define LSB_HV_IR_CAL2_SET_CAL_HTX485_B_OCP                 (9)
#define MSB_HV_IR_CAL2_SET_CAL_HTX485_B_OCP                 (11)
#define MSK_HV_IR_CAL2_SET_CAL_HTX485_SLEW                  (0x1)     /* [12] */
#define SFT_HV_IR_CAL2_SET_CAL_HTX485_SLEW                  (12)
#define LSB_HV_IR_CAL2_SET_CAL_HTX485_SLEW                  (12)
#define MSB_HV_IR_CAL2_SET_CAL_HTX485_SLEW                  (12)
#define BIT_HV_IR_CAL2_SET_CAL_HTX485_SLEW                  (0x1000)  /* [12] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR calibration data 2 set
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Calibration data for htx485 line A high-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_a_ocn              :    3;       /* [ 2:0] */
  /**
   * Calibration data for htx485 line A low-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_a_ocp              :    3;       /* [ 5:3] */
  /**
   * Calibration data for htx485 line B high-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_b_ocn              :    3;       /* [ 8:6] */
  /**
   * Calibration data for htx485 line B low-side current limitation. Increasing
   */ 
  unsigned short cal_htx485_b_ocp              :    3;       /* [11:9] */
  /**
   * This bit controls the slew rate speed when slew rate is enabled <br>
   * 0: slew rate is normal <br>
   * 1: slew rate is slower
   */ 
  unsigned short cal_htx485_slew               :    1;       /* [12] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    3;
} hv_ir_cal2_set_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR calibration data 2 set
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_cal2_set_bf bf;  ///< bit field representation
} hv_ir_cal2_set_t;


/* HV_IR_PASS */

#define MSK_HV_IR_PASS                                      (0xffff)  /* [15:0] */

typedef unsigned short hv_ir_pass_t;                                  /* [15:0] */


/* HV_IR_TMR0 */

#define MSK_HV_IR_TMR0_HV_TMR_ATBUS_EN                      (0x1)     /* [0] */
#define SFT_HV_IR_TMR0_HV_TMR_ATBUS_EN                      (0)
#define LSB_HV_IR_TMR0_HV_TMR_ATBUS_EN                      (0)
#define MSB_HV_IR_TMR0_HV_TMR_ATBUS_EN                      (0)
#define BIT_HV_IR_TMR0_HV_TMR_ATBUS_EN                      (0x1)     /* [0] */
#define MSK_HV_IR_TMR0_HV_TMR_ATBUS_GPO                     (0x1)     /* [1] */
#define SFT_HV_IR_TMR0_HV_TMR_ATBUS_GPO                     (1)
#define LSB_HV_IR_TMR0_HV_TMR_ATBUS_GPO                     (1)
#define MSB_HV_IR_TMR0_HV_TMR_ATBUS_GPO                     (1)
#define BIT_HV_IR_TMR0_HV_TMR_ATBUS_GPO                     (0x2)     /* [1] */
#define MSK_HV_IR_TMR0_HV_TMR_ATBUS_HHK                     (0x1)     /* [2] */
#define SFT_HV_IR_TMR0_HV_TMR_ATBUS_HHK                     (2)
#define LSB_HV_IR_TMR0_HV_TMR_ATBUS_HHK                     (2)
#define MSB_HV_IR_TMR0_HV_TMR_ATBUS_HHK                     (2)
#define BIT_HV_IR_TMR0_HV_TMR_ATBUS_HHK                     (0x4)     /* [2] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR testmode registers 0
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Testbus enable
   */ 
  unsigned short hv_tmr_atbus_en               :    1;       /* [0] */
  /**
   * Map testbus to GPO
   */ 
  unsigned short hv_tmr_atbus_gpo              :    1;       /* [1] */
  /**
   * Map testbus to housekeeping output
   */ 
  unsigned short hv_tmr_atbus_hhk              :    1;       /* [2] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :   13;
} hv_ir_tmr0_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR testmode registers 0
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_tmr0_bf bf;  ///< bit field representation
} hv_ir_tmr0_t;


/* HV_IR_TMR1 */

#define MSK_HV_IR_TMR1_HREF_SW_IBP_TEST_ICONST              (0x1)     /* [0] */
#define SFT_HV_IR_TMR1_HREF_SW_IBP_TEST_ICONST              (0)
#define LSB_HV_IR_TMR1_HREF_SW_IBP_TEST_ICONST              (0)
#define MSB_HV_IR_TMR1_HREF_SW_IBP_TEST_ICONST              (0)
#define BIT_HV_IR_TMR1_HREF_SW_IBP_TEST_ICONST              (0x1)     /* [0] */
#define MSK_HV_IR_TMR1_HREF_SW_VREF_TDIOL                   (0x1)     /* [1] */
#define SFT_HV_IR_TMR1_HREF_SW_VREF_TDIOL                   (1)
#define LSB_HV_IR_TMR1_HREF_SW_VREF_TDIOL                   (1)
#define MSB_HV_IR_TMR1_HREF_SW_VREF_TDIOL                   (1)
#define BIT_HV_IR_TMR1_HREF_SW_VREF_TDIOL                   (0x2)     /* [1] */
#define MSK_HV_IR_TMR1_HREF_SW_VREF_TDIOH                   (0x1)     /* [2] */
#define SFT_HV_IR_TMR1_HREF_SW_VREF_TDIOH                   (2)
#define LSB_HV_IR_TMR1_HREF_SW_VREF_TDIOH                   (2)
#define MSB_HV_IR_TMR1_HREF_SW_VREF_TDIOH                   (2)
#define BIT_HV_IR_TMR1_HREF_SW_VREF_TDIOH                   (0x4)     /* [2] */
#define MSK_HV_IR_TMR1_HREF_SW_VBG_BUF                      (0x1)     /* [3] */
#define SFT_HV_IR_TMR1_HREF_SW_VBG_BUF                      (3)
#define LSB_HV_IR_TMR1_HREF_SW_VBG_BUF                      (3)
#define MSB_HV_IR_TMR1_HREF_SW_VBG_BUF                      (3)
#define BIT_HV_IR_TMR1_HREF_SW_VBG_BUF                      (0x8)     /* [3] */
#define MSK_HV_IR_TMR1_HREF_SW_VBG                          (0x1)     /* [4] */
#define SFT_HV_IR_TMR1_HREF_SW_VBG                          (4)
#define LSB_HV_IR_TMR1_HREF_SW_VBG                          (4)
#define MSB_HV_IR_TMR1_HREF_SW_VBG                          (4)
#define BIT_HV_IR_TMR1_HREF_SW_VBG                          (0x10)    /* [4] */
#define MSK_HV_IR_TMR1_HRES_SW_VDDPRE                       (0x1)     /* [5] */
#define SFT_HV_IR_TMR1_HRES_SW_VDDPRE                       (5)
#define LSB_HV_IR_TMR1_HRES_SW_VDDPRE                       (5)
#define MSB_HV_IR_TMR1_HRES_SW_VDDPRE                       (5)
#define BIT_HV_IR_TMR1_HRES_SW_VDDPRE                       (0x20)    /* [5] */
#define MSK_HV_IR_TMR1_HTX_SW_DIO_PHYB_HI                   (0x1)     /* [6] */
#define SFT_HV_IR_TMR1_HTX_SW_DIO_PHYB_HI                   (6)
#define LSB_HV_IR_TMR1_HTX_SW_DIO_PHYB_HI                   (6)
#define MSB_HV_IR_TMR1_HTX_SW_DIO_PHYB_HI                   (6)
#define BIT_HV_IR_TMR1_HTX_SW_DIO_PHYB_HI                   (0x40)    /* [6] */
#define MSK_HV_IR_TMR1_HTX_SW_DIO_PHYB_LO                   (0x1)     /* [7] */
#define SFT_HV_IR_TMR1_HTX_SW_DIO_PHYB_LO                   (7)
#define LSB_HV_IR_TMR1_HTX_SW_DIO_PHYB_LO                   (7)
#define MSB_HV_IR_TMR1_HTX_SW_DIO_PHYB_LO                   (7)
#define BIT_HV_IR_TMR1_HTX_SW_DIO_PHYB_LO                   (0x80)    /* [7] */
#define MSK_HV_IR_TMR1_HTX_SW_DIO_PHYA_HI                   (0x1)     /* [8] */
#define SFT_HV_IR_TMR1_HTX_SW_DIO_PHYA_HI                   (8)
#define LSB_HV_IR_TMR1_HTX_SW_DIO_PHYA_HI                   (8)
#define MSB_HV_IR_TMR1_HTX_SW_DIO_PHYA_HI                   (8)
#define BIT_HV_IR_TMR1_HTX_SW_DIO_PHYA_HI                   (0x100)   /* [8] */
#define MSK_HV_IR_TMR1_HTX_SW_DIO_PHYA_LO                   (0x1)     /* [9] */
#define SFT_HV_IR_TMR1_HTX_SW_DIO_PHYA_LO                   (9)
#define LSB_HV_IR_TMR1_HTX_SW_DIO_PHYA_LO                   (9)
#define MSB_HV_IR_TMR1_HTX_SW_DIO_PHYA_LO                   (9)
#define BIT_HV_IR_TMR1_HTX_SW_DIO_PHYA_LO                   (0x200)   /* [9] */
#define MSK_HV_IR_TMR1_VREG5TX_SW_DIO                       (0x1)     /* [10] */
#define SFT_HV_IR_TMR1_VREG5TX_SW_DIO                       (10)
#define LSB_HV_IR_TMR1_VREG5TX_SW_DIO                       (10)
#define MSB_HV_IR_TMR1_VREG5TX_SW_DIO                       (10)
#define BIT_HV_IR_TMR1_VREG5TX_SW_DIO                       (0x400)   /* [10] */
#define MSK_HV_IR_TMR1_HPW_VPOW_DAC                         (0x1)     /* [11] */
#define SFT_HV_IR_TMR1_HPW_VPOW_DAC                         (11)
#define LSB_HV_IR_TMR1_HPW_VPOW_DAC                         (11)
#define MSB_HV_IR_TMR1_HPW_VPOW_DAC                         (11)
#define BIT_HV_IR_TMR1_HPW_VPOW_DAC                         (0x800)   /* [11] */
#define MSK_HV_IR_TMR1_HPW_VPOW_RTAP                        (0x1)     /* [12] */
#define SFT_HV_IR_TMR1_HPW_VPOW_RTAP                        (12)
#define LSB_HV_IR_TMR1_HPW_VPOW_RTAP                        (12)
#define MSB_HV_IR_TMR1_HPW_VPOW_RTAP                        (12)
#define BIT_HV_IR_TMR1_HPW_VPOW_RTAP                        (0x1000)  /* [12] */
#define MSK_HV_IR_TMR1_HPW_VPOW_RTAP_Z                      (0x1)     /* [13] */
#define SFT_HV_IR_TMR1_HPW_VPOW_RTAP_Z                      (13)
#define LSB_HV_IR_TMR1_HPW_VPOW_RTAP_Z                      (13)
#define MSB_HV_IR_TMR1_HPW_VPOW_RTAP_Z                      (13)
#define BIT_HV_IR_TMR1_HPW_VPOW_RTAP_Z                      (0x2000)  /* [13] */


/* ############################################################################ */
/**
 * \brief This structure describes HV IR testmode registers 1
 *
 * \ingroup hv_ctrl 
 */ 
typedef struct {
  /**
   * Connect ref_current to testbus
   */ 
  unsigned short href_sw_ibp_test_iconst       :    1;       /* [0] */
  /**
   * Connect vth_low of temp_comp to testbus
   */ 
  unsigned short href_sw_vref_tdiol            :    1;       /* [1] */
  /**
   * Connect vth_high of temp_comp to testbus
   */ 
  unsigned short href_sw_vref_tdioh            :    1;       /* [2] */
  /**
   * Connect buffered Bandgap to testbus
   */ 
  unsigned short href_sw_vbg_buf               :    1;       /* [3] */
  /**
   * Connect unbuffered Bandgap to testbus
   */ 
  unsigned short href_sw_vbg                   :    1;       /* [4] */
  /**
   * Connect vdd_pre to testbus
   */ 
  unsigned short hres_sw_vddpre                :    1;       /* [5] */
  /**
   * Connect temp_diode to testbus
   */ 
  unsigned short htx_sw_dio_phyb_hi            :    1;       /* [6] */
  /**
   * Connect temp_diode to testbus
   */ 
  unsigned short htx_sw_dio_phyb_lo            :    1;       /* [7] */
  /**
   * Connect temp_diode to testbus
   */ 
  unsigned short htx_sw_dio_phya_hi            :    1;       /* [8] */
  /**
   * Connect temp_diode to testbus
   */ 
  unsigned short htx_sw_dio_phya_lo            :    1;       /* [9] */
  /**
   * Connect temp_diode to testbus
   */ 
  unsigned short vreg5tx_sw_dio                :    1;       /* [10] */
  /**
   * Connect DAC comparator input to testbus
   */ 
  unsigned short hpw_vpow_dac                  :    1;       /* [11] */
  /**
   * Connect rchain-tap comparator input to testbus
   */ 
  unsigned short hpw_vpow_rtap                 :    1;       /* [12] */
  /**
   * Disconnect rchain from rchain-tap comparator input
   */ 
  unsigned short hpw_vpow_rtap_z               :    1;       /* [13] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    2;
} hv_ir_tmr1_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HV IR testmode registers 1
 *
 * \ingroup hv_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hv_ir_tmr1_bf bf;  ///< bit field representation
} hv_ir_tmr1_t;


/* HV_IR_TMR_ONE_GPO */

#define MSK_HV_IR_TMR_ONE_GPO                               (0x7)     /* [ 2:0] */

typedef unsigned short hv_ir_tmr_one_gpo_t;                           /* [ 2:0] */


/* HV_IR_TMR_ONE_RX */

#define MSK_HV_IR_TMR_ONE_RX                                (0x7)     /* [ 2:0] */

typedef unsigned short hv_ir_tmr_one_rx_t;                            /* [ 2:0] */



// Register definitions for module
// Instance base address BASE_ADDR_HV_IR 0x0U ... undefined

#define ADDR_HV_IR_IR_PWR_CONFIG                             (0x00U)
#define A_HV_IR_IR_PWR_CONFIG(ba)                            ((ba) + ADDR_HV_IR_IR_PWR_CONFIG)
#define R_HV_IR_IR_PWR_CONFIG(ba)                            (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_PWR_CONFIG(ba)))
#define RES_HV_IR_IR_PWR_CONFIG                              (0x1400U)
#define MSB_HV_IR_IR_PWR_CONFIG                              15
#define LSB_HV_IR_IR_PWR_CONFIG                              0
#define AADDR_HV_IR_IR_PWR_CONFIG                            (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_PWR_CONFIG)
#define REG_HV_IR_IR_PWR_CONFIG                              (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_PWR_CONFIG))

#define ADDR_HV_IR_IR_GPO5V                                  (0x01U)
#define A_HV_IR_IR_GPO5V(ba)                                 ((ba) + ADDR_HV_IR_IR_GPO5V)
#define R_HV_IR_IR_GPO5V(ba)                                 (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_GPO5V(ba)))
#define RES_HV_IR_IR_GPO5V                                   (0x0U)
#define MSB_HV_IR_IR_GPO5V                                   1
#define LSB_HV_IR_IR_GPO5V                                   0
#define AADDR_HV_IR_IR_GPO5V                                 (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_GPO5V)
#define REG_HV_IR_IR_GPO5V                                   (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_GPO5V))

#define ADDR_HV_IR_IR_HVHKMUX                                (0x02U)
#define A_HV_IR_IR_HVHKMUX(ba)                               ((ba) + ADDR_HV_IR_IR_HVHKMUX)
#define R_HV_IR_IR_HVHKMUX(ba)                               (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_HVHKMUX(ba)))
#define RES_HV_IR_IR_HVHKMUX                                 (0x0U)
#define MSB_HV_IR_IR_HVHKMUX                                 4
#define LSB_HV_IR_IR_HVHKMUX                                 0
#define AADDR_HV_IR_IR_HVHKMUX                               (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_HVHKMUX)
#define REG_HV_IR_IR_HVHKMUX                                 (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_HVHKMUX))

#define ADDR_HV_IR_IR_ISINK0                                 (0x03U)
#define A_HV_IR_IR_ISINK0(ba)                                ((ba) + ADDR_HV_IR_IR_ISINK0)
#define R_HV_IR_IR_ISINK0(ba)                                (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_ISINK0(ba)))
#define RES_HV_IR_IR_ISINK0                                  (0x0U)
#define MSB_HV_IR_IR_ISINK0                                  7
#define LSB_HV_IR_IR_ISINK0                                  0
#define AADDR_HV_IR_IR_ISINK0                                (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_ISINK0)
#define REG_HV_IR_IR_ISINK0                                  (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_ISINK0))

#define ADDR_HV_IR_IR_ISINK1                                 (0x04U)
#define A_HV_IR_IR_ISINK1(ba)                                ((ba) + ADDR_HV_IR_IR_ISINK1)
#define R_HV_IR_IR_ISINK1(ba)                                (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_ISINK1(ba)))
#define RES_HV_IR_IR_ISINK1                                  (0x0U)
#define MSB_HV_IR_IR_ISINK1                                  7
#define LSB_HV_IR_IR_ISINK1                                  0
#define AADDR_HV_IR_IR_ISINK1                                (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_ISINK1)
#define REG_HV_IR_IR_ISINK1                                  (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_ISINK1))

#define ADDR_HV_IR_IR_ISINK2                                 (0x05U)
#define A_HV_IR_IR_ISINK2(ba)                                ((ba) + ADDR_HV_IR_IR_ISINK2)
#define R_HV_IR_IR_ISINK2(ba)                                (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_ISINK2(ba)))
#define RES_HV_IR_IR_ISINK2                                  (0x0U)
#define MSB_HV_IR_IR_ISINK2                                  7
#define LSB_HV_IR_IR_ISINK2                                  0
#define AADDR_HV_IR_IR_ISINK2                                (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_ISINK2)
#define REG_HV_IR_IR_ISINK2                                  (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_ISINK2))

#define ADDR_HV_IR_IR_RS485_CONFIG                           (0x06U)
#define A_HV_IR_IR_RS485_CONFIG(ba)                          ((ba) + ADDR_HV_IR_IR_RS485_CONFIG)
#define R_HV_IR_IR_RS485_CONFIG(ba)                          (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_RS485_CONFIG(ba)))
#define RES_HV_IR_IR_RS485_CONFIG                            (0xa0U)
#define MSB_HV_IR_IR_RS485_CONFIG                            9
#define LSB_HV_IR_IR_RS485_CONFIG                            0
#define AADDR_HV_IR_IR_RS485_CONFIG                          (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_RS485_CONFIG)
#define REG_HV_IR_IR_RS485_CONFIG                            (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_RS485_CONFIG))

#define ADDR_HV_IR_IR_SELOUT                                 (0x07U)
#define A_HV_IR_IR_SELOUT(ba)                                ((ba) + ADDR_HV_IR_IR_SELOUT)
#define R_HV_IR_IR_SELOUT(ba)                                (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_SELOUT(ba)))
#define RES_HV_IR_IR_SELOUT                                  (0x0U)
#define MSB_HV_IR_IR_SELOUT                                  1
#define LSB_HV_IR_IR_SELOUT                                  0
#define AADDR_HV_IR_IR_SELOUT                                (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_SELOUT)
#define REG_HV_IR_IR_SELOUT                                  (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_SELOUT))

#define ADDR_HV_IR_IR_SELIN_CONFIG                           (0x08U)
#define A_HV_IR_IR_SELIN_CONFIG(ba)                          ((ba) + ADDR_HV_IR_IR_SELIN_CONFIG)
#define R_HV_IR_IR_SELIN_CONFIG(ba)                          (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_SELIN_CONFIG(ba)))
#define RES_HV_IR_IR_SELIN_CONFIG                            (0x0U)
#define MSB_HV_IR_IR_SELIN_CONFIG                            1
#define LSB_HV_IR_IR_SELIN_CONFIG                            0
#define AADDR_HV_IR_IR_SELIN_CONFIG                          (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_SELIN_CONFIG)
#define REG_HV_IR_IR_SELIN_CONFIG                            (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_SELIN_CONFIG))

#define ADDR_HV_IR_IR_SELIO_STATUS                           (0x09U)
#define A_HV_IR_IR_SELIO_STATUS(ba)                          ((ba) + ADDR_HV_IR_IR_SELIO_STATUS)
#define R_HV_IR_IR_SELIO_STATUS(ba)                          (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_SELIO_STATUS(ba)))
#define RES_HV_IR_IR_SELIO_STATUS                            (0x0U)
#define MSB_HV_IR_IR_SELIO_STATUS                            1
#define LSB_HV_IR_IR_SELIO_STATUS                            0
#define AADDR_HV_IR_IR_SELIO_STATUS                          (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_SELIO_STATUS)
#define REG_HV_IR_IR_SELIO_STATUS                            (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_SELIO_STATUS))

#define ADDR_HV_IR_IR_STATUS                                 (0x0AU)
#define A_HV_IR_IR_STATUS(ba)                                ((ba) + ADDR_HV_IR_IR_STATUS)
#define R_HV_IR_IR_STATUS(ba)                                (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_STATUS(ba)))
#define RES_HV_IR_IR_STATUS                                  (0x142U)
#define MSB_HV_IR_IR_STATUS                                  8
#define LSB_HV_IR_IR_STATUS                                  0
#define AADDR_HV_IR_IR_STATUS                                (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_STATUS)
#define REG_HV_IR_IR_STATUS                                  (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_STATUS))

#define ADDR_HV_IR_IR_MASK                                   (0x0BU)
#define A_HV_IR_IR_MASK(ba)                                  ((ba) + ADDR_HV_IR_IR_MASK)
#define R_HV_IR_IR_MASK(ba)                                  (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_MASK(ba)))
#define RES_HV_IR_IR_MASK                                    (0x40U)
#define MSB_HV_IR_IR_MASK                                    8
#define LSB_HV_IR_IR_MASK                                    0
#define AADDR_HV_IR_IR_MASK                                  (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_MASK)
#define REG_HV_IR_IR_MASK                                    (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_MASK))

#define ADDR_HV_IR_IR_CLEAR_RESET_FLAG                       (0x0CU)
#define A_HV_IR_IR_CLEAR_RESET_FLAG(ba)                      ((ba) + ADDR_HV_IR_IR_CLEAR_RESET_FLAG)
#define R_HV_IR_IR_CLEAR_RESET_FLAG(ba)                      (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CLEAR_RESET_FLAG(ba)))
#define RES_HV_IR_IR_CLEAR_RESET_FLAG                        (0x0U)
#define MSB_HV_IR_IR_CLEAR_RESET_FLAG                        0
#define LSB_HV_IR_IR_CLEAR_RESET_FLAG                        0
#define AADDR_HV_IR_IR_CLEAR_RESET_FLAG                      (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CLEAR_RESET_FLAG)
#define REG_HV_IR_IR_CLEAR_RESET_FLAG                        (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CLEAR_RESET_FLAG))

#define ADDR_HV_IR_IR_VERSION                                (0x0DU)
#define A_HV_IR_IR_VERSION(ba)                               ((ba) + ADDR_HV_IR_IR_VERSION)
#define R_HV_IR_IR_VERSION(ba)                               (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_VERSION(ba)))
#define RES_HV_IR_IR_VERSION                                 (0x20U)
#define MSB_HV_IR_IR_VERSION                                 15
#define LSB_HV_IR_IR_VERSION                                 0
#define AADDR_HV_IR_IR_VERSION                               (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_VERSION)
#define REG_HV_IR_IR_VERSION                                 (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_VERSION))

#define ADDR_HV_IR_IR_CAL0                                   (0x10U)
#define A_HV_IR_IR_CAL0(ba)                                  ((ba) + ADDR_HV_IR_IR_CAL0)
#define R_HV_IR_IR_CAL0(ba)                                  (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CAL0(ba)))
#define RES_HV_IR_IR_CAL0                                    (0x8690U)
#define MSB_HV_IR_IR_CAL0                                    15
#define LSB_HV_IR_IR_CAL0                                    0
#define AADDR_HV_IR_IR_CAL0                                  (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CAL0)
#define REG_HV_IR_IR_CAL0                                    (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CAL0))

#define ADDR_HV_IR_IR_CAL1                                   (0x11U)
#define A_HV_IR_IR_CAL1(ba)                                  ((ba) + ADDR_HV_IR_IR_CAL1)
#define R_HV_IR_IR_CAL1(ba)                                  (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CAL1(ba)))
#define RES_HV_IR_IR_CAL1                                    (0x0U)
#define MSB_HV_IR_IR_CAL1                                    10
#define LSB_HV_IR_IR_CAL1                                    0
#define AADDR_HV_IR_IR_CAL1                                  (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CAL1)
#define REG_HV_IR_IR_CAL1                                    (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CAL1))

#define ADDR_HV_IR_IR_CAL2                                   (0x12U)
#define A_HV_IR_IR_CAL2(ba)                                  ((ba) + ADDR_HV_IR_IR_CAL2)
#define R_HV_IR_IR_CAL2(ba)                                  (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CAL2(ba)))
#define RES_HV_IR_IR_CAL2                                    (0x6dbU)
#define MSB_HV_IR_IR_CAL2                                    12
#define LSB_HV_IR_IR_CAL2                                    0
#define AADDR_HV_IR_IR_CAL2                                  (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CAL2)
#define REG_HV_IR_IR_CAL2                                    (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CAL2))

#define ADDR_HV_IR_IR_CAL0_CLR                               (0x13U)
#define A_HV_IR_IR_CAL0_CLR(ba)                              ((ba) + ADDR_HV_IR_IR_CAL0_CLR)
#define R_HV_IR_IR_CAL0_CLR(ba)                              (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CAL0_CLR(ba)))
#define RES_HV_IR_IR_CAL0_CLR                                (0x8690U)
#define MSB_HV_IR_IR_CAL0_CLR                                15
#define LSB_HV_IR_IR_CAL0_CLR                                0
#define AADDR_HV_IR_IR_CAL0_CLR                              (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CAL0_CLR)
#define REG_HV_IR_IR_CAL0_CLR                                (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CAL0_CLR))

#define ADDR_HV_IR_IR_CAL1_CLR                               (0x14U)
#define A_HV_IR_IR_CAL1_CLR(ba)                              ((ba) + ADDR_HV_IR_IR_CAL1_CLR)
#define R_HV_IR_IR_CAL1_CLR(ba)                              (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CAL1_CLR(ba)))
#define RES_HV_IR_IR_CAL1_CLR                                (0x0U)
#define MSB_HV_IR_IR_CAL1_CLR                                10
#define LSB_HV_IR_IR_CAL1_CLR                                0
#define AADDR_HV_IR_IR_CAL1_CLR                              (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CAL1_CLR)
#define REG_HV_IR_IR_CAL1_CLR                                (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CAL1_CLR))

#define ADDR_HV_IR_IR_CAL2_CLR                               (0x15U)
#define A_HV_IR_IR_CAL2_CLR(ba)                              ((ba) + ADDR_HV_IR_IR_CAL2_CLR)
#define R_HV_IR_IR_CAL2_CLR(ba)                              (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CAL2_CLR(ba)))
#define RES_HV_IR_IR_CAL2_CLR                                (0x6dbU)
#define MSB_HV_IR_IR_CAL2_CLR                                12
#define LSB_HV_IR_IR_CAL2_CLR                                0
#define AADDR_HV_IR_IR_CAL2_CLR                              (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CAL2_CLR)
#define REG_HV_IR_IR_CAL2_CLR                                (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CAL2_CLR))

#define ADDR_HV_IR_IR_CAL0_SET                               (0x16U)
#define A_HV_IR_IR_CAL0_SET(ba)                              ((ba) + ADDR_HV_IR_IR_CAL0_SET)
#define R_HV_IR_IR_CAL0_SET(ba)                              (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CAL0_SET(ba)))
#define RES_HV_IR_IR_CAL0_SET                                (0x8690U)
#define MSB_HV_IR_IR_CAL0_SET                                15
#define LSB_HV_IR_IR_CAL0_SET                                0
#define AADDR_HV_IR_IR_CAL0_SET                              (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CAL0_SET)
#define REG_HV_IR_IR_CAL0_SET                                (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CAL0_SET))

#define ADDR_HV_IR_IR_CAL1_SET                               (0x17U)
#define A_HV_IR_IR_CAL1_SET(ba)                              ((ba) + ADDR_HV_IR_IR_CAL1_SET)
#define R_HV_IR_IR_CAL1_SET(ba)                              (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CAL1_SET(ba)))
#define RES_HV_IR_IR_CAL1_SET                                (0x0U)
#define MSB_HV_IR_IR_CAL1_SET                                10
#define LSB_HV_IR_IR_CAL1_SET                                0
#define AADDR_HV_IR_IR_CAL1_SET                              (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CAL1_SET)
#define REG_HV_IR_IR_CAL1_SET                                (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CAL1_SET))

#define ADDR_HV_IR_IR_CAL2_SET                               (0x18U)
#define A_HV_IR_IR_CAL2_SET(ba)                              ((ba) + ADDR_HV_IR_IR_CAL2_SET)
#define R_HV_IR_IR_CAL2_SET(ba)                              (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_CAL2_SET(ba)))
#define RES_HV_IR_IR_CAL2_SET                                (0x6dbU)
#define MSB_HV_IR_IR_CAL2_SET                                12
#define LSB_HV_IR_IR_CAL2_SET                                0
#define AADDR_HV_IR_IR_CAL2_SET                              (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_CAL2_SET)
#define REG_HV_IR_IR_CAL2_SET                                (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_CAL2_SET))

#define ADDR_HV_IR_IR_PASS                                   (0x20U)
#define A_HV_IR_IR_PASS(ba)                                  ((ba) + ADDR_HV_IR_IR_PASS)
#define R_HV_IR_IR_PASS(ba)                                  (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_PASS(ba)))
#define RES_HV_IR_IR_PASS                                    (0x0U)
#define MSB_HV_IR_IR_PASS                                    15
#define LSB_HV_IR_IR_PASS                                    0
#define AADDR_HV_IR_IR_PASS                                  (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_PASS)
#define REG_HV_IR_IR_PASS                                    (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_PASS))

#define ADDR_HV_IR_IR_TMR0                                   (0x21U)
#define A_HV_IR_IR_TMR0(ba)                                  ((ba) + ADDR_HV_IR_IR_TMR0)
#define R_HV_IR_IR_TMR0(ba)                                  (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_TMR0(ba)))
#define RES_HV_IR_IR_TMR0                                    (0x0U)
#define MSB_HV_IR_IR_TMR0                                    2
#define LSB_HV_IR_IR_TMR0                                    0
#define AADDR_HV_IR_IR_TMR0                                  (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_TMR0)
#define REG_HV_IR_IR_TMR0                                    (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_TMR0))

#define ADDR_HV_IR_IR_TMR1                                   (0x22U)
#define A_HV_IR_IR_TMR1(ba)                                  ((ba) + ADDR_HV_IR_IR_TMR1)
#define R_HV_IR_IR_TMR1(ba)                                  (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_TMR1(ba)))
#define RES_HV_IR_IR_TMR1                                    (0x0U)
#define MSB_HV_IR_IR_TMR1                                    13
#define LSB_HV_IR_IR_TMR1                                    0
#define AADDR_HV_IR_IR_TMR1                                  (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_TMR1)
#define REG_HV_IR_IR_TMR1                                    (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_TMR1))

#define ADDR_HV_IR_IR_TMR_ONE_GPO                            (0x23U)
#define A_HV_IR_IR_TMR_ONE_GPO(ba)                           ((ba) + ADDR_HV_IR_IR_TMR_ONE_GPO)
#define R_HV_IR_IR_TMR_ONE_GPO(ba)                           (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_TMR_ONE_GPO(ba)))
#define RES_HV_IR_IR_TMR_ONE_GPO                             (0x0U)
#define MSB_HV_IR_IR_TMR_ONE_GPO                             2
#define LSB_HV_IR_IR_TMR_ONE_GPO                             0
#define AADDR_HV_IR_IR_TMR_ONE_GPO                           (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_TMR_ONE_GPO)
#define REG_HV_IR_IR_TMR_ONE_GPO                             (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_TMR_ONE_GPO))

#define ADDR_HV_IR_IR_TMR_ONE_RX                             (0x24U)
#define A_HV_IR_IR_TMR_ONE_RX(ba)                            ((ba) + ADDR_HV_IR_IR_TMR_ONE_RX)
#define R_HV_IR_IR_TMR_ONE_RX(ba)                            (*(volatile unsigned short *)((unsigned int)A_HV_IR_IR_TMR_ONE_RX(ba)))
#define RES_HV_IR_IR_TMR_ONE_RX                              (0x0U)
#define MSB_HV_IR_IR_TMR_ONE_RX                              2
#define LSB_HV_IR_IR_TMR_ONE_RX                              0
#define AADDR_HV_IR_IR_TMR_ONE_RX                            (BASE_ADDR_HV_IR + ADDR_HV_IR_IR_TMR_ONE_RX)
#define REG_HV_IR_IR_TMR_ONE_RX                              (*(volatile unsigned short *)((unsigned int)AADDR_HV_IR_IR_TMR_ONE_RX))




#endif
