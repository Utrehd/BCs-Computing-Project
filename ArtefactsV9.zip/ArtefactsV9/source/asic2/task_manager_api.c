#include "hardware_api.h"
#include "task_manager_api.h"
#include "systick_api.h"

TASK_MANAGER_API_TASK_ITEM task_manager_api_task_list[TASK_MANAGER_API_TASK_LIST_MAX]; ///< Task list

uint8_t task_manager_api_num_of_tasks=0; // number of all running or blocked tasks
uint8_t task_manager_api_task_id_cnt=0;  // ID of last added task

/* ############################################################################ */
void task_manager_api_info(void) {
  //printf("%s:Number of item in task list:%u\n",task_manager_api_num_of_tasks);

  uint8_t i_local_task;
  for(i_local_task=0;i_local_task<task_manager_api_num_of_tasks;i_local_task++) {
    switch(task_manager_api_task_list[i_local_task].stat) {
      case TASK_MANAGER_API_NONE        : printf("No\n");break;
      case TASK_MANAGER_API_READY       : printf("Re\n");break;
      case TASK_MANAGER_API_RUNING      : printf("Ru\n");break;
      case TASK_MANAGER_API_BLOCKED     : printf("Bl\n");break;
      case TASK_MANAGER_API_TERMINATED  : printf("Te\n");break;
    }
    printf("[");
    printf("%i", task_manager_api_task_list[i_local_task].id);
    printf("] \n");
  }
}

/* ############################################################################ */
uint8_t task_manager_api_find(uint8_t i_task_ID) {
  uint8_t i_task_a;
  for(i_task_a=0;i_task_a<task_manager_api_num_of_tasks;i_task_a++) {
    if (task_manager_api_task_list[i_task_a].stat!=TASK_MANAGER_API_TERMINATED) {
      
      if (task_manager_api_task_list[i_task_a].id == i_task_ID) {
        return(i_task_a);
      }
    }
  }
  return(TASK_MANAGER_API_TASK_LIST_MAX);
}

/* ############################################################################ */
void task_manager_api_kill(uint8_t i_task_ID) {
  uint8_t i_index;
  
  i_index = task_manager_api_find(i_task_ID);
  if(i_index<TASK_MANAGER_API_TASK_LIST_MAX) {
    task_manager_api_task_list[i_index].stat=TASK_MANAGER_API_TERMINATED;
  }
}

/* ############################################################################ */
void task_manager_api_sleep(uint8_t i_task_ID) {
  uint8_t i_index;
  
  i_index = task_manager_api_find(i_task_ID);
  if(i_index<TASK_MANAGER_API_TASK_LIST_MAX) {
    task_manager_api_task_list[i_index].stat=TASK_MANAGER_API_BLOCKED;
  }
}

/* ############################################################################ */
void task_manager_api_wkup(uint8_t i_task_ID) {
  uint8_t i_index;
  
  i_index = task_manager_api_find(i_task_ID);
  if(i_index<TASK_MANAGER_API_TASK_LIST_MAX) {
    task_manager_api_task_list[i_index].stat=TASK_MANAGER_API_READY;
  }
}

/* ############################################################################ */
void task_manager_api_defrag(void) {
  uint8_t i_task_a;
  uint8_t i_task_b;
  
  //task_manager_api_info(); // DEBUG
  
  for(i_task_a=0;i_task_a<TASK_MANAGER_API_TASK_LIST_MAX;i_task_a++) {
    if (task_manager_api_task_list[i_task_a].stat==TASK_MANAGER_API_TERMINATED) {
      for(i_task_b=i_task_a+1;i_task_b<TASK_MANAGER_API_TASK_LIST_MAX;i_task_b++) {
        if (task_manager_api_task_list[i_task_b].stat!=TASK_MANAGER_API_TERMINATED) {

          task_manager_api_task_list[i_task_a].id=task_manager_api_task_list[i_task_b].id;
          task_manager_api_task_list[i_task_a].curr_time=task_manager_api_task_list[i_task_b].curr_time;
          task_manager_api_task_list[i_task_a].time_period=task_manager_api_task_list[i_task_b].time_period;
          task_manager_api_task_list[i_task_a].iteraction=task_manager_api_task_list[i_task_b].iteraction;
          task_manager_api_task_list[i_task_a].stat=task_manager_api_task_list[i_task_b].stat;
          task_manager_api_task_list[i_task_a].ptr_app=task_manager_api_task_list[i_task_b].ptr_app;
  
          task_manager_api_task_list[i_task_b].stat=TASK_MANAGER_API_TERMINATED;

          break; /* got to next loop iteraction */
        }
      }
    }
  }

  //task_manager_api_info(); // DEBUG

  task_manager_api_num_of_tasks=0;
  /* Counted how many task have not been terminated -> are active */ 
  for(i_task_a=0;i_task_a<TASK_MANAGER_API_TASK_LIST_MAX;i_task_a++) {
    switch(task_manager_api_task_list[i_task_a].stat) {
      case TASK_MANAGER_API_READY:   // task is ready to run
      case TASK_MANAGER_API_RUNING:  // task is currently running
      case TASK_MANAGER_API_BLOCKED: // task is blocked (sleep) can be woken-up
        task_manager_api_num_of_tasks++;
        break;
        
      default:
        break;
    }
  }

  //task_manager_api_info(); // DEBUG
}

/* ############################################################################ */
uint8_t task_manager_api_add(void (*i_ptr_app)(void), uint32_t i_per_time, uint8_t i_iteraction) {

  /* tasks cannot be defragmented here, because add function can be run from process itself */

  if ( task_manager_api_num_of_tasks >= TASK_MANAGER_API_TASK_LIST_MAX) {
    printf("task_manager_api_add:No enough space for new task!NEEDS TO BE SOLVED DURING COMPILATION!\n");
    while(1);
  }

  /*
  Serial.print("add_task");
  Serial.print(":");
  Serial.print(task_manager_api_task_id_cnt);
  Serial.print(":");
  Serial.print(i_per_time);
  Serial.print(":");
  Serial.println(i_iteraction);
  */
  
  task_manager_api_task_id_cnt++;
  task_manager_api_task_list[task_manager_api_num_of_tasks].id=task_manager_api_task_id_cnt;
  task_manager_api_task_list[task_manager_api_num_of_tasks].curr_time=0;
  task_manager_api_task_list[task_manager_api_num_of_tasks].time_period=i_per_time;
  task_manager_api_task_list[task_manager_api_num_of_tasks].iteraction=i_iteraction;
  task_manager_api_task_list[task_manager_api_num_of_tasks].stat=TASK_MANAGER_API_READY;
  task_manager_api_task_list[task_manager_api_num_of_tasks].ptr_app=i_ptr_app;
  task_manager_api_num_of_tasks++;
  
  return(task_manager_api_task_id_cnt);
}

/* ############################################################################ */
void task_manager_api_run() {

  void (*i_ptr_app)(void);
  uint32_t time_period;
  uint8_t i_local_task;

  //Serial.print("task_manager_api_run:task_manager_api_num_of_tasks:");
  //Serial.println(task_manager_api_num_of_tasks);
  
  if ( task_manager_api_num_of_tasks >= ((TASK_MANAGER_API_DEFRAG_LEVEL / 100.0) * TASK_MANAGER_API_TASK_LIST_MAX)) {
    printf("task_manager_api_add:task list is full:try to run defrag\n");
    task_manager_api_defrag();
  }


  
  for(i_local_task=0;i_local_task<task_manager_api_num_of_tasks;i_local_task++) {
    if (task_manager_api_task_list[i_local_task].stat==TASK_MANAGER_API_READY) {

      time_period = task_manager_api_task_list[i_local_task].time_period;
      task_manager_api_task_list[i_local_task].curr_time++;
    
      if (task_manager_api_task_list[i_local_task].curr_time >= time_period) {
        task_manager_api_task_list[i_local_task].curr_time=0;
        i_ptr_app = task_manager_api_task_list[i_local_task].ptr_app;

        task_manager_api_task_list[i_local_task].stat=TASK_MANAGER_API_RUNING;
        i_ptr_app(); // execute
        task_manager_api_task_list[i_local_task].stat=TASK_MANAGER_API_READY;


        if (task_manager_api_task_list[i_local_task].iteraction!=255) {
          task_manager_api_task_list[i_local_task].iteraction--;
        
          if (task_manager_api_task_list[i_local_task].iteraction==0) {
            task_manager_api_task_list[i_local_task].stat=TASK_MANAGER_API_TERMINATED;          
          }
        }
      }
    }
  }
}

/* ############################################################################ */
void task_manager_api_init(void) {
  
  /*
   *
   *            system clock                system clock
   * ----------------------------------- = ---------------- * TASK_MANAGER_API_TASK_PERIOD
   * (1000/TASK_MANAGER_API_TASK_PERIOD)        1000
   *
   * It is implemented like this to get constant from compiler (1000/TASK_MANAGER_API_TASK_PERIOD)
   * and use this number like divider for system clock
   * 
   * Example: TASK_MANAGER_API_TASK_PERIOD = 10, 30MHz
   *
   *       30e6        3e7                  30MHz
   *     --------   = ------- = 3e5  ===>   ----- = 100Hz ===> 10ms
   *     1000/10       100                   3e5
   */
  uint32_t system_clock;
  clk_nres_api_get_system_clock(&system_clock);
  systick_api_init( system_clock/(1000/TASK_MANAGER_API_TASK_PERIOD) );
  systick_api_callback( task_manager_api_run );
  
}