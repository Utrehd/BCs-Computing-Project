/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         usi_uart.h
*
* @brief        USI HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __USI_UART_H__
#define __USI_UART_H__


#include "device.h"

#include "usi.h"
#include "usi_irq.h"
#include "usi_bf.h"

/**
 * \example example_usi_uart.c
 * This is an example of how to use USI UART block.
 */
 
/**
 * \defgroup usi_uart
 *
 * \brief   functions to control UART by USI
 *
 * \ingroup usi
 *
 * \details How to use it - see code example: @include example_usi_uart.c
 */

/* ############################################################################ */
/** 
 * \brief This enumeration describes UART data bit order
 *
 * \ingroup usi_uart
 */
typedef enum {
  USI_UART_MSB_FIRST              = 1, ///< data bits transmitted MSB first
  USI_UART_LSB_FIRST              = 0  ///< data bits transmitted LSB first
} usi_uart_bit_order_t;


/* ############################################################################ */
/** 
 * \brief This enumeration describes UART data length
 *
 * \ingroup usi_uart
 */
typedef enum {
  USI_UART_DATA_LEN_8             = 0, ///< 8bit data length
  USI_UART_DATA_LEN_7             = 1  ///< 7bit data length
} usi_uart_data_len_t;

/* ############################################################################ */
/** 
 * \brief This enumeration describes UART parity type
 *
 * \ingroup usi_uart
 */
typedef enum {
  USI_UART_PARITY_NONE            = 0, ///< no parity
  USI_UART_PARITY_ODD             = 1, ///< odd parity
  USI_UART_PARITY_EVEN            = 2  ///< even parity
} usi_uart_parity_t;

/* ############################################################################ */
/** 
 * \brief This enumeration describes UART data length
 *
 * \ingroup usi_uart
 */
typedef enum {
  USI_UART_ONE_STOP               = 0, ///< one stop bit
  USI_UART_TWO_STOP               = 1  ///< two stop bits
} usi_uart_stop_bit_t;


//=======================================================================
// config
//=======================================================================


/* ############################################################################ */
/**
 * \brief Set UART halfduplex configuration
 *
 * \param  usi_no   USI instance
 *
 * \param  cfg      UART pads behavioral see usi_cfg_u_half_duplex_t for more information
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_half_duplex(usi_num_t usi_no, usi_cfg_u_half_duplex_t cfg);

/* ############################################################################ */
/**
 * \brief Set UART data order
 *
 * \param  usi_no   USI instance
 *
 * \param  msb_first  0: data bits transmitted LSB first<br>
 *                    1: data bits transmitted MSB first<br>
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_msb_first(usi_num_t usi_no, usi_uart_bit_order_t i_usi_bit_order);

/* ############################################################################ */
/**
 * \brief Set UART data order
 *
 * \param  usi_no   USI instance
 *
 * \param  data_bits  number of data bits (see usi_uart_data_len_t)<br>
 *                    0: 8 data bits<br>
 *                    1: 7 data bits<br>
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_data_bits(usi_num_t usi_no, usi_uart_data_len_t data_bits);

/* ############################################################################ */
/**
 * \brief Set UART number of stop bits
 *
 * \param  usi_no   USI instance
 *
 * \param  stop_bits  number of stop bits, see usi_uart_stop_bit_t
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_stop_bits(usi_num_t usi_no, usi_uart_stop_bit_t stop_bits);

/* ############################################################################ */
/**
 * \brief Set UART parity type
 *
 * \param  usi_no   USI instance
 *
 * \param  parity   set type of parity (see usi_uart_parity_t)
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_parity(usi_num_t usi_no, usi_uart_parity_t parity);

/* ############################################################################ */
/**
 * \brief Set UART start bit filter setting
 *
 * \param  usi_no   USI instance
 *
 * \param  start_threshold   leading edge of start bit detection threshold in comm_clk clock cycles
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_start_threshold(usi_num_t usi_no, uint16_t start_threshold);

/* ############################################################################ */
/**
 * \brief Set UART data sampling timing
 *
 * \param usi_no      USI instance
 *
 * \param data_start  start of sampling window in ticks from the start of the bit
 *
 * \param data_length duration of sampling window in ticks
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_data_sampling(usi_num_t usi_no, uint16_t data_start, uint16_t data_length);

/* ############################################################################ */
/**
 * \brief Set UART data sampling timing
 *
 * \param usi_no  USI instance
 *
 * \param len     number of transmitted break bits = 10 + break_tx_len
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_break_tx_len(usi_num_t usi_no, uint8_t len);

/* ############################################################################ */
/**
 * \brief Set UART data sampling timing
 *
 * \param usi_no  USI instance
 *
 * \param thr     threshold (inclusive) for detecting break word = 10 + break_rx_thr
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_break_rx_thr(usi_num_t usi_no, uint8_t thr);

/* ############################################################################ */
/**
 * \brief Set UART data sampling timing
 *
 * \param usi_no  USI instance
 *
 * \param conc    0: disable concurrent break detection. A break can only start at
 *                   the beginning of a Uart word.<br>
 *                1: enable concurrent break detection. A break can also start
 *                   within any position of a Uart word.
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_break_conc(usi_num_t usi_no, bool conc);

//=======================================================================
// status
//=======================================================================

//=======================================================================
// helper wrapper
//=======================================================================

/* ############################################################################ */
/**
 * \brief Set UART timing for read bit function (sampling window)
 * 
 * start of sampling window in ticks from the start of the bit = bit_length / 4 <br>
 * duration of sampling window in ticks = bit_length / 2 <br>
 *
 * It means is starts sampling window in 1/4 of bit and check it for 1/2.
 *
 * \param usi_no  USI instance
 *
 * \param bit_length     set bit length [ticks]
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_cfg_bit_length(usi_num_t usi_no, uint16_t bit_length);

//=======================================================================
// simple usage DMA wrapper
//=======================================================================

/* ############################################################################ */
/**
 * \brief Send UART data + set frame configuration
 *
 * \param usi_no  USI instance
 *
 * \param data    data to be sent
 *
 * \param tcfg    break configuration (see usi_dma_txcfg_t)
 *
 * \param len     how many words should be sent
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_send_byte_tcfg(usi_num_t usi_no, uint8_t data, uint8_t tcfg, uint8_t len);

/* ############################################################################ */
/**
 * \brief Prepare UART DMA to be able to receive data
 *
 * \param usi_no  USI instance
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_prepare_recv_dma(usi_num_t usi_no);

/* ############################################################################ */
/**
 * \brief Send UART data
 * 
 * \param usi_no  USI instance
 *
 * \param data    data to be sent
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_send_byte(usi_num_t usi_no, uint8_t data);

/* ############################################################################ */
/**
 * \brief Get received UART data
 * 
 * \param usi_no  USI instance
 *
 * \param data    pointer to data to be received
 *
 * \return true when receive structure contains new data 
 *
 * \ingroup usi_uart
 * 
 */
bool usi_uart_recv_byte(usi_num_t usi_no, uint8_t *data);

/* ############################################################################ */
/**
 * \brief init UART - init datastructures for DMA
 *
 * \param usi_no  USI instance
 *
 * \ingroup usi_uart
 * 
 */
void usi_uart_init(usi_num_t usi_no);

#endif
