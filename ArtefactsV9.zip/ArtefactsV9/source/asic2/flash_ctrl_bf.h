/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         flash_ctrl_bf.h
*
* @brief        FLASH Controller HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __FLASH_CTRL_BF_H__
#define __FLASH_CTRL_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_FLASH_CTRL0
#define BASE_ADDR_FLASH_CTRL0 0x40006500U
#endif
#ifndef BASE_ADDR_FLASH_CTRL1
#define BASE_ADDR_FLASH_CTRL1 0x40007280U
#endif

#define MULTIPLE_FLASH_CTRL
#define NUMBER_FLASH_CTRL 2


/* ############################################################################ */
/**
 * \brief This is an enum class for Flash Control instance
 *
 * \ingroup flash_ctrl 
 */ 
typedef enum {
  /**
   * his is instance FLASH_CTRL0
   */ 
  FLASH_CTRL0                    = (int)BASE_ADDR_FLASH_CTRL0,
  /**
   * This is instance FLASH_CTRL1
   */ 
  FLASH_CTRL1                    = (int)BASE_ADDR_FLASH_CTRL1
} flash_ctrl_num_t;

// Register bit field definitions

/* FLASH_CTRL_AREA_MIN */

#define MSK_FLASH_CTRL_AREA_MIN_AREA                        (0xff)    /* [ 7:0] */
#define RES_FLASH_CTRL_AREA_MIN_AREA                        (0x00)
#define SFT_FLASH_CTRL_AREA_MIN_AREA                        (0)
#define LSB_FLASH_CTRL_AREA_MIN_AREA                        (0)
#define MSB_FLASH_CTRL_AREA_MIN_AREA                        (7)
#define MSK_FLASH_CTRL_AREA_MIN_PASS                        (0xff)    /* [15:8] */
#define RES_FLASH_CTRL_AREA_MIN_PASS                        (0x96)
#define SFT_FLASH_CTRL_AREA_MIN_PASS                        (8)
#define LSB_FLASH_CTRL_AREA_MIN_PASS                        (8)
#define MSB_FLASH_CTRL_AREA_MIN_PASS                        (15)


/* ############################################################################ */
/**
 * \brief This is an enum class for Flash Control start page of writeable / eraseable area
 *
 * \ingroup flash_ctrl 
 */ 
typedef struct {
  /**
   * FLASH area write and erase protection <br>
   * Start page of writeable / eraseable area <br>
   * MAIN AREA: <br>
   * 0x00 - 0x50 (40kb) <br>
   * 0x00 - 0xB0 (88kb) <br>
   * INFO AREA (virtual) : 0xF0 – 0xF1 (2 pages) <br>
   * If AREA_MIN is greater than AREA_MAX no page is writeable
   */ 
  unsigned short area                          :    8;       /* [ 7:0] */
  /**
   * password must be written as 0xA5 will always be read as 0x96
   */ 
  unsigned short pass                          :    8;       /* [15:8] */
} flash_ctrl_area_min_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of Flash Control start page of writeable / eraseable area
 *
 * \ingroup flash_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  flash_ctrl_area_min_bf bf;  ///< bit field representation
} flash_ctrl_area_min_t;


/* FLASH_CTRL_AREA_MAX */

#define MSK_FLASH_CTRL_AREA_MAX_AREA                        (0xff)    /* [ 7:0] */
#define RES_FLASH_CTRL_AREA_MAX_AREA                        (0x00)
#define SFT_FLASH_CTRL_AREA_MAX_AREA                        (0)
#define LSB_FLASH_CTRL_AREA_MAX_AREA                        (0)
#define MSB_FLASH_CTRL_AREA_MAX_AREA                        (7)
#define MSK_FLASH_CTRL_AREA_MAX_PASS                        (0xff)    /* [15:8] */
#define RES_FLASH_CTRL_AREA_MAX_PASS                        (0x96)
#define SFT_FLASH_CTRL_AREA_MAX_PASS                        (8)
#define LSB_FLASH_CTRL_AREA_MAX_PASS                        (8)
#define MSB_FLASH_CTRL_AREA_MAX_PASS                        (15)


/* ############################################################################ */
/**
 * \brief This is an enum class for Flash Control end page of writeable / eraseable area
 *
 * \ingroup flash_ctrl 
 */ 
typedef struct {
  /**
   * end page of writeable / eraseable area
   */ 
  unsigned short area                          :    8;       /* [ 7:0] */
  /**
   * password must be written as 0xA5 will always be read as 0x96
   */ 
  unsigned short pass                          :    8;       /* [15:8] */
} flash_ctrl_area_max_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of Flash Control end page of writeable / eraseable area
 *
 * \ingroup flash_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  flash_ctrl_area_max_bf bf;  ///< bit field representation
} flash_ctrl_area_max_t;


/* FLASH_CTRL_MODE */

#define MSK_FLASH_CTRL_MODE_MODE                            (0xff)    /* [ 7:0] */
#define RES_FLASH_CTRL_MODE_MODE                            (0x01)
#define SFT_FLASH_CTRL_MODE_MODE                            (0)
#define LSB_FLASH_CTRL_MODE_MODE                            (0)
#define MSB_FLASH_CTRL_MODE_MODE                            (7)
#define MSK_FLASH_CTRL_MODE_PASS                            (0xff)    /* [15:8] */
#define RES_FLASH_CTRL_MODE_PASS                            (0x96)
#define SFT_FLASH_CTRL_MODE_PASS                            (8)
#define LSB_FLASH_CTRL_MODE_PASS                            (8)
#define MSB_FLASH_CTRL_MODE_PASS                            (15)


/* ############################################################################ */
/**
 * \brief This is an enum class for Flash Control mode
 *
 * \ingroup flash_ctrl 
 */ 
typedef struct {
  /**
   * 0x01: main and info block read (selected by address) <br>
   * 0x02: info block read (mapped to main address) <br>
   * 0x04: main block program <br>
   * 0x08: info block program <br>
   * 0x10: erase main page <br>
   * 0x20: erase info page <br>
   * 0x40: mass erase main block <br>
   * 0x80: mass erase main and info block (only in testmode) <br>
   * Any other written mode value results in FLASH read mode, program/erase modes: write access to appropriate flash address starts
   * program/erase cycle (see busy flag of status register, consider word config and row programming incomplete flag in program mode)
   */ 
  unsigned short mode                          :    8;       /* [ 7:0] */
  /**
   * password must be written as 0xA5 will always be read as 0x96
   */ 
  unsigned short pass                          :    8;       /* [15:8] */
} flash_ctrl_mode_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of Flash Control mode
 *
 * \ingroup flash_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  flash_ctrl_mode_bf bf;  ///< bit field representation
} flash_ctrl_mode_t;


/* FLASH_CTRL_STATUS */

#define MSK_FLASH_CTRL_STATUS_BUSY                          (0x1)     /* [0] */
#define RES_FLASH_CTRL_STATUS_BUSY                          (0x0)
#define SFT_FLASH_CTRL_STATUS_BUSY                          (0)
#define LSB_FLASH_CTRL_STATUS_BUSY                          (0)
#define MSB_FLASH_CTRL_STATUS_BUSY                          (0)
#define BIT_FLASH_CTRL_STATUS_BUSY                          (0x1)     /* [0] */
#define MSK_FLASH_CTRL_STATUS_WRITE_ERROR                   (0x1)     /* [1] */
#define RES_FLASH_CTRL_STATUS_WRITE_ERROR                   (0x0)
#define SFT_FLASH_CTRL_STATUS_WRITE_ERROR                   (1)
#define LSB_FLASH_CTRL_STATUS_WRITE_ERROR                   (1)
#define MSB_FLASH_CTRL_STATUS_WRITE_ERROR                   (1)
#define BIT_FLASH_CTRL_STATUS_WRITE_ERROR                   (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief This is an enum class for Flash Control status
 *
 * \ingroup flash_ctrl 
 */ 
typedef struct {
  /**
   * FLASH program/erase state: <br>
   * 0 : ready <br>
   * 1 : busy
   */ 
  unsigned short busy                          :    1;       /* [0] */
  /**
   * unexpected write to area protected memory occurred, will be cleared when STATUS is read
   */ 
  unsigned short write_error                   :    1;       /* [1] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :   14;
} flash_ctrl_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of Flash Control status
 *
 * \ingroup flash_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  flash_ctrl_status_bf bf;  ///< bit field representation
} flash_ctrl_status_t;


/* FLASH_CTRL_TIMING_CONFIG */

#define MSK_FLASH_CTRL_TIMING_CONFIG_CLK_RATIO              (0x1)     /* [0] */
#define RES_FLASH_CTRL_TIMING_CONFIG_CLK_RATIO              (0x1)
#define SFT_FLASH_CTRL_TIMING_CONFIG_CLK_RATIO              (0)
#define LSB_FLASH_CTRL_TIMING_CONFIG_CLK_RATIO              (0)
#define MSB_FLASH_CTRL_TIMING_CONFIG_CLK_RATIO              (0)
#define BIT_FLASH_CTRL_TIMING_CONFIG_CLK_RATIO              (0x1)     /* [0] */
#define MSK_FLASH_CTRL_TIMING_CONFIG_PASS                   (0xff)    /* [15:8] */
#define RES_FLASH_CTRL_TIMING_CONFIG_PASS                   (0x96)
#define SFT_FLASH_CTRL_TIMING_CONFIG_PASS                   (8)
#define LSB_FLASH_CTRL_TIMING_CONFIG_PASS                   (8)
#define MSB_FLASH_CTRL_TIMING_CONFIG_PASS                   (15)


/* ############################################################################ */
/**
 * \brief This is an enum class for Flash Control timing configuration
 *
 * \ingroup flash_ctrl 
 */ 
typedef struct {
  /**
   * 0: 1:1 flash clk = switch clk. <br>
   * 1: 2:1 flash clk = 0.5 system clk
   */ 
  unsigned short clk_ratio                     :    1;       /* [0] */
  /**
   * reserved
   */ 
  unsigned short reserved7                     :    7;       /* [ 7:1] */
  /**
   * password must be written as 0xA5 will always be read as 0x96
   */ 
  unsigned short pass                          :    8;       /* [15:8] */
} flash_ctrl_timing_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of Flash Control timing configuration
 *
 * \ingroup flash_ctrl 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  flash_ctrl_timing_config_bf bf;  ///< bit field representation
} flash_ctrl_timing_config_t;


/* FLASH_CTRL_TNVS_TNVH */

#define MSK_FLASH_CTRL_TNVS_TNVH                            (0xff)    /* [ 7:0] */

typedef unsigned short flash_ctrl_tnvs_tnvh_t;                        /* [ 7:0] */


/* FLASH_CTRL_TNVH1 */

#define MSK_FLASH_CTRL_TNVH1                                (0xffff)  /* [15:0] */

typedef unsigned short flash_ctrl_tnvh1_t;                            /* [15:0] */


/* FLASH_CTRL_TPGS */

#define MSK_FLASH_CTRL_TPGS                                 (0xffff)  /* [15:0] */

typedef unsigned short flash_ctrl_tpgs_t;                             /* [15:0] */


/* FLASH_CTRL_TRCV */

#define MSK_FLASH_CTRL_TRCV                                 (0xff)    /* [ 7:0] */

typedef unsigned short flash_ctrl_trcv_t;                             /* [ 7:0] */


/* FLASH_CTRL_TPROG */

#define MSK_FLASH_CTRL_TPROG                                (0xffff)  /* [15:0] */

typedef unsigned short flash_ctrl_tprog_t;                            /* [15:0] */


/* FLASH_CTRL_TERASE */

#define MSK_FLASH_CTRL_TERASE                               (0xffff)  /* [15:0] */

typedef unsigned short flash_ctrl_terase_t;                           /* [15:0] */


/* FLASH_CTRL_TME */

#define MSK_FLASH_CTRL_TME                                  (0xffff)  /* [15:0] */

typedef unsigned short flash_ctrl_tme_t;                              /* [15:0] */


/* FLASH_CTRL_INFO_ADDR */

#define MSK_FLASH_CTRL_INFO_ADDR                            (0x1ff)   /* [ 8:0] */

typedef unsigned short flash_ctrl_info_addr_t;                        /* [ 8:0] */


/* FLASH_CTRL_INFO_DATA */

#define MSK_FLASH_CTRL_INFO_DATA                            (0xffff)  /* [15:0] */

typedef unsigned short flash_ctrl_info_data_t;                        /* [15:0] */



// Register definitions for module
// Instance base address BASE_ADDR_FLASH_CTRL0 0x40006500U ... 
// Instance base address BASE_ADDR_FLASH_CTRL1 0x40007280U ... 

#define ADDR_FLASH_CTRL_AREA_MIN                             (0x00U)
#define A_FLASH_CTRL_AREA_MIN(ba)                            ((ba) + ADDR_FLASH_CTRL_AREA_MIN)
#define R_FLASH_CTRL_AREA_MIN(ba)                            (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_AREA_MIN(ba)))
#define RES_FLASH_CTRL_AREA_MIN                              (0x9600U)
#define MSB_FLASH_CTRL_AREA_MIN                              15
#define LSB_FLASH_CTRL_AREA_MIN                              0
#define AADDR_FLASH_CTRL0_AREA_MIN                           (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_AREA_MIN)
#define AADDR_FLASH_CTRL1_AREA_MIN                           (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_AREA_MIN)
#define REG_FLASH_CTRL0_AREA_MIN                             (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_AREA_MIN))
#define REG_FLASH_CTRL1_AREA_MIN                             (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_AREA_MIN))

#define ADDR_FLASH_CTRL_AREA_MAX                             (0x02U)
#define A_FLASH_CTRL_AREA_MAX(ba)                            ((ba) + ADDR_FLASH_CTRL_AREA_MAX)
#define R_FLASH_CTRL_AREA_MAX(ba)                            (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_AREA_MAX(ba)))
#define RES_FLASH_CTRL_AREA_MAX                              (0x9600U)
#define MSB_FLASH_CTRL_AREA_MAX                              15
#define LSB_FLASH_CTRL_AREA_MAX                              0
#define AADDR_FLASH_CTRL0_AREA_MAX                           (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_AREA_MAX)
#define AADDR_FLASH_CTRL1_AREA_MAX                           (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_AREA_MAX)
#define REG_FLASH_CTRL0_AREA_MAX                             (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_AREA_MAX))
#define REG_FLASH_CTRL1_AREA_MAX                             (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_AREA_MAX))

#define ADDR_FLASH_CTRL_MODE                                 (0x04U)
#define A_FLASH_CTRL_MODE(ba)                                ((ba) + ADDR_FLASH_CTRL_MODE)
#define R_FLASH_CTRL_MODE(ba)                                (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_MODE(ba)))
#define RES_FLASH_CTRL_MODE                                  (0x9601U)
#define MSB_FLASH_CTRL_MODE                                  15
#define LSB_FLASH_CTRL_MODE                                  0
#define AADDR_FLASH_CTRL0_MODE                               (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_MODE)
#define AADDR_FLASH_CTRL1_MODE                               (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_MODE)
#define REG_FLASH_CTRL0_MODE                                 (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_MODE))
#define REG_FLASH_CTRL1_MODE                                 (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_MODE))

#define ADDR_FLASH_CTRL_STATUS                               (0x06U)
#define A_FLASH_CTRL_STATUS(ba)                              ((ba) + ADDR_FLASH_CTRL_STATUS)
#define R_FLASH_CTRL_STATUS(ba)                              (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_STATUS(ba)))
#define RES_FLASH_CTRL_STATUS                                (0x0U)
#define MSB_FLASH_CTRL_STATUS                                1
#define LSB_FLASH_CTRL_STATUS                                0
#define AADDR_FLASH_CTRL0_STATUS                             (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_STATUS)
#define AADDR_FLASH_CTRL1_STATUS                             (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_STATUS)
#define REG_FLASH_CTRL0_STATUS                               (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_STATUS))
#define REG_FLASH_CTRL1_STATUS                               (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_STATUS))

#define ADDR_FLASH_CTRL_TIMING_CONFIG                        (0x0AU)
#define A_FLASH_CTRL_TIMING_CONFIG(ba)                       ((ba) + ADDR_FLASH_CTRL_TIMING_CONFIG)
#define R_FLASH_CTRL_TIMING_CONFIG(ba)                       (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_TIMING_CONFIG(ba)))
#define RES_FLASH_CTRL_TIMING_CONFIG                         (0x9601U)
#define MSB_FLASH_CTRL_TIMING_CONFIG                         15
#define LSB_FLASH_CTRL_TIMING_CONFIG                         0
#define AADDR_FLASH_CTRL0_TIMING_CONFIG                      (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_TIMING_CONFIG)
#define AADDR_FLASH_CTRL1_TIMING_CONFIG                      (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_TIMING_CONFIG)
#define REG_FLASH_CTRL0_TIMING_CONFIG                        (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_TIMING_CONFIG))
#define REG_FLASH_CTRL1_TIMING_CONFIG                        (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_TIMING_CONFIG))

#define ADDR_FLASH_CTRL_TNVS_TNVH                            (0x10U)
#define A_FLASH_CTRL_TNVS_TNVH(ba)                           ((ba) + ADDR_FLASH_CTRL_TNVS_TNVH)
#define R_FLASH_CTRL_TNVS_TNVH(ba)                           (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_TNVS_TNVH(ba)))
#define RES_FLASH_CTRL_TNVS_TNVH                             (0x31U)
#define MSB_FLASH_CTRL_TNVS_TNVH                             7
#define LSB_FLASH_CTRL_TNVS_TNVH                             0
#define AADDR_FLASH_CTRL0_TNVS_TNVH                          (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_TNVS_TNVH)
#define AADDR_FLASH_CTRL1_TNVS_TNVH                          (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_TNVS_TNVH)
#define REG_FLASH_CTRL0_TNVS_TNVH                            (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_TNVS_TNVH))
#define REG_FLASH_CTRL1_TNVS_TNVH                            (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_TNVS_TNVH))

#define ADDR_FLASH_CTRL_TNVH1                                (0x12U)
#define A_FLASH_CTRL_TNVH1(ba)                               ((ba) + ADDR_FLASH_CTRL_TNVH1)
#define R_FLASH_CTRL_TNVH1(ba)                               (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_TNVH1(ba)))
#define RES_FLASH_CTRL_TNVH1                                 (0x371U)
#define MSB_FLASH_CTRL_TNVH1                                 15
#define LSB_FLASH_CTRL_TNVH1                                 0
#define AADDR_FLASH_CTRL0_TNVH1                              (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_TNVH1)
#define AADDR_FLASH_CTRL1_TNVH1                              (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_TNVH1)
#define REG_FLASH_CTRL0_TNVH1                                (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_TNVH1))
#define REG_FLASH_CTRL1_TNVH1                                (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_TNVH1))

#define ADDR_FLASH_CTRL_TPGS                                 (0x14U)
#define A_FLASH_CTRL_TPGS(ba)                                ((ba) + ADDR_FLASH_CTRL_TPGS)
#define R_FLASH_CTRL_TPGS(ba)                                (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_TPGS(ba)))
#define RES_FLASH_CTRL_TPGS                                  (0x59U)
#define MSB_FLASH_CTRL_TPGS                                  15
#define LSB_FLASH_CTRL_TPGS                                  0
#define AADDR_FLASH_CTRL0_TPGS                               (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_TPGS)
#define AADDR_FLASH_CTRL1_TPGS                               (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_TPGS)
#define REG_FLASH_CTRL0_TPGS                                 (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_TPGS))
#define REG_FLASH_CTRL1_TPGS                                 (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_TPGS))

#define ADDR_FLASH_CTRL_TRCV                                 (0x16U)
#define A_FLASH_CTRL_TRCV(ba)                                ((ba) + ADDR_FLASH_CTRL_TRCV)
#define R_FLASH_CTRL_TRCV(ba)                                (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_TRCV(ba)))
#define RES_FLASH_CTRL_TRCV                                  (0x9U)
#define MSB_FLASH_CTRL_TRCV                                  7
#define LSB_FLASH_CTRL_TRCV                                  0
#define AADDR_FLASH_CTRL0_TRCV                               (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_TRCV)
#define AADDR_FLASH_CTRL1_TRCV                               (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_TRCV)
#define REG_FLASH_CTRL0_TRCV                                 (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_TRCV))
#define REG_FLASH_CTRL1_TRCV                                 (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_TRCV))

#define ADDR_FLASH_CTRL_TPROG                                (0x18U)
#define A_FLASH_CTRL_TPROG(ba)                               ((ba) + ADDR_FLASH_CTRL_TPROG)
#define R_FLASH_CTRL_TPROG(ba)                               (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_TPROG(ba)))
#define RES_FLASH_CTRL_TPROG                                 (0xb1U)
#define MSB_FLASH_CTRL_TPROG                                 15
#define LSB_FLASH_CTRL_TPROG                                 0
#define AADDR_FLASH_CTRL0_TPROG                              (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_TPROG)
#define AADDR_FLASH_CTRL1_TPROG                              (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_TPROG)
#define REG_FLASH_CTRL0_TPROG                                (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_TPROG))
#define REG_FLASH_CTRL1_TPROG                                (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_TPROG))

#define ADDR_FLASH_CTRL_TERASE                               (0x1AU)
#define A_FLASH_CTRL_TERASE(ba)                              ((ba) + ADDR_FLASH_CTRL_TERASE)
#define R_FLASH_CTRL_TERASE(ba)                              (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_TERASE(ba)))
#define RES_FLASH_CTRL_TERASE                                (0x2a0U)
#define MSB_FLASH_CTRL_TERASE                                15
#define LSB_FLASH_CTRL_TERASE                                0
#define AADDR_FLASH_CTRL0_TERASE                             (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_TERASE)
#define AADDR_FLASH_CTRL1_TERASE                             (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_TERASE)
#define REG_FLASH_CTRL0_TERASE                               (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_TERASE))
#define REG_FLASH_CTRL1_TERASE                               (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_TERASE))

#define ADDR_FLASH_CTRL_TME                                  (0x1CU)
#define A_FLASH_CTRL_TME(ba)                                 ((ba) + ADDR_FLASH_CTRL_TME)
#define R_FLASH_CTRL_TME(ba)                                 (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_TME(ba)))
#define RES_FLASH_CTRL_TME                                   (0x2a0U)
#define MSB_FLASH_CTRL_TME                                   15
#define LSB_FLASH_CTRL_TME                                   0
#define AADDR_FLASH_CTRL0_TME                                (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_TME)
#define AADDR_FLASH_CTRL1_TME                                (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_TME)
#define REG_FLASH_CTRL0_TME                                  (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_TME))
#define REG_FLASH_CTRL1_TME                                  (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_TME))

#define ADDR_FLASH_CTRL_INFO_ADDR                            (0x20U)
#define A_FLASH_CTRL_INFO_ADDR(ba)                           ((ba) + ADDR_FLASH_CTRL_INFO_ADDR)
#define R_FLASH_CTRL_INFO_ADDR(ba)                           (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_INFO_ADDR(ba)))
#define RES_FLASH_CTRL_INFO_ADDR                             (0x0U)
#define MSB_FLASH_CTRL_INFO_ADDR                             8
#define LSB_FLASH_CTRL_INFO_ADDR                             0
#define AADDR_FLASH_CTRL0_INFO_ADDR                          (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_INFO_ADDR)
#define AADDR_FLASH_CTRL1_INFO_ADDR                          (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_INFO_ADDR)
#define REG_FLASH_CTRL0_INFO_ADDR                            (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_INFO_ADDR))
#define REG_FLASH_CTRL1_INFO_ADDR                            (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_INFO_ADDR))

#define ADDR_FLASH_CTRL_INFO_DATA                            (0x22U)
#define A_FLASH_CTRL_INFO_DATA(ba)                           ((ba) + ADDR_FLASH_CTRL_INFO_DATA)
#define R_FLASH_CTRL_INFO_DATA(ba)                           (*(volatile unsigned short *)((unsigned int)A_FLASH_CTRL_INFO_DATA(ba)))
#define RES_FLASH_CTRL_INFO_DATA                             (0x0U)
#define MSB_FLASH_CTRL_INFO_DATA                             15
#define LSB_FLASH_CTRL_INFO_DATA                             0
#define AADDR_FLASH_CTRL0_INFO_DATA                          (BASE_ADDR_FLASH_CTRL0 + ADDR_FLASH_CTRL_INFO_DATA)
#define AADDR_FLASH_CTRL1_INFO_DATA                          (BASE_ADDR_FLASH_CTRL1 + ADDR_FLASH_CTRL_INFO_DATA)
#define REG_FLASH_CTRL0_INFO_DATA                            (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL0_INFO_DATA))
#define REG_FLASH_CTRL1_INFO_DATA                            (*(volatile unsigned short *)((unsigned int)AADDR_FLASH_CTRL1_INFO_DATA))




#endif
