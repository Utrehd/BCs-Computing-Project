/* FPGA Release: 10512 */
#include "device.h"
#include <core_cm0plus.h>
#include "flash_ctrl.h"

#ifdef __IAR_SYSTEMS_ICC__
  #pragma language=extended
  #pragma segment="CSTACK"
#endif

extern void __cmain( void );

#ifdef __IAR_SYSTEMS_ICC__
  extern _INTERRUPT_ __iar_program_start( void );
#else
  extern void __StackTop( void );
#endif

extern _INTERRUPT_  NMI_Handler( void );
extern _INTERRUPT_  HardFault_Handler( void );
extern _INTERRUPT_  SVCall_Handler( void );
extern _INTERRUPT_  PendSV_Handler( void );
extern _INTERRUPT_  SysTick_Handler( void );
extern _INTERRUPT_  IRQ_CLK_NRES_0_Handler( void );
extern _INTERRUPT_  IRQ_SWTIMER0_Handler( void );
extern _INTERRUPT_  IRQ_TSU_Handler( void );
extern _INTERRUPT_  IRQ_SWD_Handler( void );
extern _INTERRUPT_  IRQ_HV_CTRL_Handler( void );
extern _INTERRUPT_  IRQ_CPU_N_CPU_0_Handler( void );
extern _INTERRUPT_  IRQ_EL_CTRL_Handler( void );
extern _INTERRUPT_  IRQ_SWTIMER1_Handler( void );
extern _INTERRUPT_  IRQ_HISPI_Handler( void );
extern _INTERRUPT_  IRQ_UART_Handler( void );
extern _INTERRUPT_  IRQ_CRC0_Handler( void );
extern _INTERRUPT_  IRQ_CRC1_Handler( void );
extern _INTERRUPT_  IRQ_GPIO_Handler( void );
extern _INTERRUPT_  IRQ_SARADC_CTRL_Handler( void );
extern _INTERRUPT_  IRQ_CPU_N_CPU_1_Handler( void );
extern _INTERRUPT_  IRQ_PWMN_Handler( void );
extern _INTERRUPT_  IRQ_CCTIMER0_Handler( void );
extern _INTERRUPT_  IRQ_CCTIMER1_Handler( void );
extern _INTERRUPT_  IRQ_USI0_Handler( void );
extern _INTERRUPT_  IRQ_USI1_Handler( void );
extern _INTERRUPT_  IRQ_I2C_Handler( void );
extern _INTERRUPT_  IRQ_CPU_N_CPU_EXT_Handler( void );

typedef _INTERRUPT_( *intfunc )( void );
typedef union { intfunc __fun; void * __ptr; } intvec_elem;

// If vector table is not located at address 0, the user has to initialize
// the  NVIC vector table register (VTOR) before using interrupts.

#ifdef __IAR_SYSTEMS_ICC__
  #pragma location = ".intvec"
#else
  __attribute__((section (".vector_table")))
#endif
const intvec_elem __vector_table[] =
{
#ifdef __IAR_SYSTEMS_ICC__
  { .__ptr = __sfe( "CSTACK" ) },
  __iar_program_start,
#else
  __StackTop,
  __cmain,
#endif
  NMI_Handler,
  HardFault_Handler,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  SVCall_Handler,
  0,
  0,
  PendSV_Handler,
  SysTick_Handler,

  IRQ_CLK_NRES_0_Handler,
  IRQ_SWTIMER0_Handler,
  IRQ_TSU_Handler,
  IRQ_SWD_Handler,
  IRQ_HV_CTRL_Handler,
  IRQ_CPU_N_CPU_0_Handler,
  IRQ_EL_CTRL_Handler,
  IRQ_SWTIMER1_Handler,
  IRQ_HISPI_Handler,
  IRQ_UART_Handler,
  IRQ_CRC0_Handler,
  IRQ_CRC1_Handler,
  IRQ_GPIO_Handler,
  IRQ_SARADC_CTRL_Handler,
  IRQ_CPU_N_CPU_1_Handler,
  IRQ_PWMN_Handler,
  IRQ_CCTIMER0_Handler,
  IRQ_CCTIMER1_Handler,
  IRQ_USI0_Handler,
  IRQ_USI1_Handler,
  IRQ_I2C_Handler,
  IRQ_CPU_N_CPU_EXT_Handler 
};

// ISR Functions are defined weak and can be overridden by application
#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ NMI_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ HardFault_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ SVCall_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ PendSV_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ SysTick_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_CLK_NRES_0_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_SWTIMER0_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_TSU_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_SWD_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_HV_CTRL_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_CPU_N_CPU_0_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_EL_CTRL_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_SWTIMER1_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_HISPI_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_UART_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_CRC0_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_CRC1_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_GPIO_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_SARADC_CTRL_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_CPU_N_CPU_1_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_PWMN_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_CCTIMER0_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_CCTIMER1_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_USI0_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_USI1_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_I2C_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  #pragma call_graph_root = "interrupt"
  __ramfunc
  __weak
#else
  __attribute__((weak))
#endif
_INTERRUPT_ IRQ_CPU_N_CPU_EXT_Handler( void ) { while (1) {} }

#ifdef __IAR_SYSTEMS_ICC__
  __weak void __iar_init_core( void );
  __weak void __iar_init_vfp( void );
  
  #pragma required=__vector_table
  _INTERRUPT_ __iar_program_start( void )
  {
    __iar_init_core();
    __iar_init_vfp();
    int *cpuid = (int*)0x0000D000;
    __set_MSP((unsigned long)__section_end("CSTACK"));
    if (*cpuid == 0){
      SCB->VTOR = (uint32_t) BASE_ADDR_FLASH0;
    } else {
      SCB->VTOR = (uint32_t) BASE_ADDR_FLASH1;
    }
    __cmain();
  }
#endif
