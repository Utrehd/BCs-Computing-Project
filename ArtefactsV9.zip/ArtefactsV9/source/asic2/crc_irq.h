/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         crc_irq.h
*
* @brief        Cyclic redundancy check HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CRC_IRQ_H__
#define __CRC_IRQ_H__

#define CRC_NUM_IRQS 3

/** 
 * \brief List of CRC Interrupt sources 
 *
 * \ingroup crc
 *
 */
typedef enum{
  CRC_IRQ_SADR_DONE_NEMPTY =            0, ///< 1: *_DONE contains a completed unread CRC computation.
  CRC_IRQ_SADR_NEW_NFULL =              1, ///< 1: SADR_NEW can accept a new start address.
  CRC_IRQ_IDLE =                        2  ///< 0: CRC computation in progress
} crc_irq_t;

#endif
