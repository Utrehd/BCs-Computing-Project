#include "hardware.h"
#include "io_ctrl_api.h"

#ifdef ICP_DEVICE_STACK
  #pragma message( "io_ctrl_api:ICP_DEVICE_STACK is used" )
  #include <icp_mailbox_acpu.h>
#endif

#ifdef SWD_SLAVE_STACK
  #pragma message( "io_ctrl_api:SWD_SLAVE_STACK is used" )
  #include <slave/swd_mailbox_acpu.h>  
  #define ICP_DEVICE_STACK // We have to be compatible with SWD_SLAVE_STACK in this module
#endif

/* ############################################################################ */

errors_api_code_e io_ctrl_api_check_sel_func(device_pinout gpio_pinout, io_ctrl_api_func_e functionality, io_pin_func_t * module) {
  
  errors_api_code_e error_code;
  
  switch(functionality){
    
  case UART_OE:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_UART_OE_RX;
    break;
  
  case UART_RX:
    error_code = (gpio_pinout.function_group == func_b || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_UART_OE_RX;
    break;
    
  case UART_TX:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_b || gpio_pinout.function_group == func_c || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_UART_TX;
    break;
    
  case HISPI_CS:
    error_code = (gpio_pinout.function_group == func_a) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_HISPI;
    break;
    
  case HISPI_SCLK:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_HISPI;
    break;
    
  case HISPI_MOSI:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_HISPI;
    break;
    
  case HISPI_MISO:
    error_code = (gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_HISPI;
    break;
    
  case I2C_SCL:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_I2C;
    break;
    
  case I2C_SDA:
    error_code = (gpio_pinout.function_group == func_b || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_I2C;
    break;
    
  case VIC_EXT_IRQ:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_b || gpio_pinout.function_group == func_c || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_VIC_EXT;
    break;
    
  case HV_RS485_TXEN:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_HV_RS485;
    break;
    
  case HV_RS485_TX:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_HV_RS485;
    break;
    
  case HV_RS485_RX:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_HV_RS485;
    break;
    
  case SWD_TXEN_0:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_SWD_0;
    break;
    
  case SWD_TX_0:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_SWD_0;
    break;
    
  case SWD_RX_0:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_SWD_0;
    break;
    
  case SWD_TXEN_1:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_SWD_1;
    break;
    
  case SWD_TX_1:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_SWD_1;
    break;
    
  case SWD_RX_1:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_SWD_1;
    break;
    
  case USI0_NSS:
    error_code = (gpio_pinout.function_group == func_a) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_USI0;
    break;
    
  case USI0_SCK:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_USI0;
    break;
    
  case USI0_SDI_RX:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_USI0;
    break;
    
  case USI0_SDO_TX:
    error_code = (gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_USI0;
    break;
    
  case USI1_NSS:
    error_code = (gpio_pinout.function_group == func_a) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_USI1;
    break;
    
  case USI1_SCK:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_USI1;
    break;
    
  case USI1_SDI_RX:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_USI1;
    break;
    
  case USI1_SDO_TX:
    error_code = (gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_USI1;
    break;
    
  case TSU_SYNC_EXT_OUT_0:
    error_code = (gpio_pinout.function_group == func_a) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_TSU;
    break;
    
  case TSU_SYNC_EXT_IN:
    error_code = (gpio_pinout.function_group == func_b || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_TSU;
    break;
    
  case TSU_SYNC_EXT_OUT_1:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_TSU;
    break;
    
  case PWMN_HS_0:
    error_code = (gpio_pinout.function_group == func_a) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_PWMN_01;
    break;
    
  case PWMN_LS_0:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_PWMN_01;
    break;
    
  case PWMN_HS_1:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_PWMN_01;
    break;
    
  case PWMN_LS_1:
    error_code = (gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_PWMN_01;
    break;
    
  case PWMN_HS_2:
    error_code = (gpio_pinout.function_group == func_a) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_PWMN_23;
    break;
    
  case PWMN_LS_2:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_PWMN_23;
    break;
    
  case PWMN_HS_3:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_PWMN_23;
    break;
    
  case PWMN_LS_3:
    error_code = (gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_PWMN_23;
    break;
    
  case PWMN_NALLOFF:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_PWMN_NALLOFF;
    break;
    
  case HIAD_ALE:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_HIAD_ALE;
    break;
    
  case CCTIMER0_MEAS_0:
    error_code = (gpio_pinout.function_group == func_a) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER0_MEAS;
    break;
    
  case CCTIMER0_MEAS_1:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER0_MEAS;
    break;
    
  case CCTIMER0_MEAS_2:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER0_MEAS;
    break;
    
  case CCTIMER0_MEAS_3:
    error_code = (gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER0_MEAS;
    break;
    
  case CCTIMER0_PWM_0:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER0_PWM;
    break;
    
  case CCTIMER0_PWM_1:
    error_code = (gpio_pinout.function_group == func_b || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER0_PWM;
    break;
    
  case CCTIMER1_MEAS_0:
    error_code = (gpio_pinout.function_group == func_a) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER1_MEAS;
    break;
    
  case CCTIMER1_MEAS_1:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER1_MEAS;
    break;
    
  case CCTIMER1_MEAS_2:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER1_MEAS;
    break;
    
  case CCTIMER1_MEAS_3:
    error_code = (gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER1_MEAS;
    break;
    
  case CCTIMER1_PWM_0:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER1_PWM;
    break;
    
  case CCTIMER1_PWM_1:
    error_code = (gpio_pinout.function_group == func_b || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_CCTIMER1_PWM;
    break;
    
  case SARADC_SYNC_OUT:
    error_code = (gpio_pinout.function_group == func_a || gpio_pinout.function_group == func_b || gpio_pinout.function_group == func_c || gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_SARADC;
    break;

  case EL_CTRL_TX_EN:
    error_code = (gpio_pinout.function_group == func_a) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_EL_CTRL;
    break;
    
  case EL_CTRL_TX:
    error_code = (gpio_pinout.function_group == func_b) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_EL_CTRL;
    break;
    
  case EL_CTRL_TIA_INT:
    error_code = (gpio_pinout.function_group == func_c) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_EL_CTRL;
    break;
    
  case EL_CTRL_RX_EXT:
    error_code = (gpio_pinout.function_group == func_d) ? eError_none : eError_io_ctrl_api_incorrect_group;
    *module = IO_EL_CTRL;
    break;
    
  }
  return error_code;
}

/* ############################################################################ */
errors_api_code_e io_ctrl_api_sel(device_pinout gpio_pinout, io_pin_func_t module) {
  /* Link the pad with the module */

#ifdef ICP_DEVICE_STACK
  swd_io_ctrl_config_sel(gpio_pinout.iomux_pad, module);
#else
  wdog_enable(GUARD0);
  wdog_unlock_guard(GUARD0);
  io_ctrl_guard_unlock();
  
  io_ctrl_config_sel(gpio_pinout.iomux_pad, module);

  io_ctrl_guard_lock();
  wdog_disable (GUARD0); // GUARD disable
  while (wdog_is_running (GUARD0))  ;  
#endif
  
  return eError_none;
}

/* ############################################################################ */

errors_api_code_e io_ctrl_api_set_sel_func(device_pinout gpio_pinout, io_ctrl_api_func_e functionality) {
  
  errors_api_code_e error_code = eError_none;
  io_pin_func_t module;
  
  error_code = io_ctrl_api_check_sel_func(gpio_pinout, functionality, &module);
  
  if( error_code ==  eError_none ){
    io_ctrl_api_sel(gpio_pinout, module);
  }
  
  return error_code;
}

/* ############################################################################ */
 iomux_pad_t io_ctrl_api_num2iomux(int8_t par_pad_idx) {
    const iomux_pad_t i_enum_pad[]={\
    IOMUX_PAD0,IOMUX_PAD1,IOMUX_PAD2,IOMUX_PAD3,IOMUX_PAD4,IOMUX_PAD5,IOMUX_PAD6,IOMUX_PAD7,\
    IOMUX_PAD8,IOMUX_PAD9,IOMUX_PAD10,IOMUX_PAD11,IOMUX_PAD12,IOMUX_PAD13,IOMUX_PAD14,IOMUX_PAD15,\
    IOMUX_PAD16,IOMUX_PAD17,IOMUX_PAD18,IOMUX_PAD19,IOMUX_PAD20,IOMUX_PAD21,IOMUX_PAD22,IOMUX_PAD23,\
    IOMUX_PAD24,IOMUX_PAD25,IOMUX_PAD26,IOMUX_PAD27,IOMUX_PAD28,IOMUX_PAD29,IOMUX_PAD30,IOMUX_PAD31,\
    IOMUX_PAD32,IOMUX_PAD33,IOMUX_PAD34,IOMUX_PAD35\
  };
  return(i_enum_pad[par_pad_idx]);
}

/* ############################################################################ */
void io_ctrl_api_all_pin_pullup(void) {
#ifdef ICP_DEVICE_STACK
  //error("not possible to use this function when stack is used\n");
  while(1);  
#else
  // Pull-up enable for all pads
  uint8_t i_pad;
  
  wdog_unlock_guard(GUARD0);
  io_ctrl_guard_unlock();  
  for(i_pad=0;i_pad<36;i_pad++) {
    io_ctrl_config_pe(io_ctrl_api_num2iomux(i_pad), true);
  }
  io_ctrl_guard_lock();
  wdog_disable(GUARD0);
#endif
}

/* ############################################################################ */
void io_ctrl_api_pullup_enable(device_pinout gpio_pinout, uint8_t enable) {
#ifdef ICP_DEVICE_STACK
  //error("not possible to use this function when stack is used\n");
  while(1);  
#else
  wdog_unlock_guard(GUARD0);
  io_ctrl_guard_unlock();  
  
  if(enable == 0){
    io_ctrl_config_pe(gpio_pinout.iomux_pad, false);
  }else{
    io_ctrl_config_pe(gpio_pinout.iomux_pad, true);
  }
  
  io_ctrl_guard_lock();
  wdog_disable(GUARD0);
#endif  
}

/* ############################################################################ */
errors_api_code_e io_ctrl_api_rs485_hv_ctrl_pins(device_pinout pinout_hv_rs485_txen, device_pinout pinout_hv_rs485_tx, device_pinout pinout_hv_rs485_rx) {


  errors_api_code_e error_code = eError_none;
  error_code |= io_ctrl_api_set_sel_func(pinout_hv_rs485_txen, HV_RS485_TXEN);
  error_code |= io_ctrl_api_set_sel_func(pinout_hv_rs485_tx, HV_RS485_TX);
  error_code |= io_ctrl_api_set_sel_func(pinout_hv_rs485_rx, HV_RS485_RX);

#ifndef ICP_DEVICE_STACK  
  /* In case of modbus - this has to be set on CCPU0 */
  wdog_enable(GUARD0);
  wdog_unlock_guard(GUARD0);
  io_ctrl_guard_unlock();
  
    // SWD_HV
    io_ctrl_config_swd_hv_conn(IOMUX_HV_PADS_CONN);

  io_ctrl_guard_lock();
  wdog_disable (GUARD0); // GUARD disable
  while (wdog_is_running (GUARD0))  ;  
#endif  

  return(error_code);

}