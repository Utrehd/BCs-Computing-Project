/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         clk_nres_errors.h
*
* @brief        Error handler for CLK_NRES API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

/**
 * \ingroup error_api
 */

#ifndef __CLK_NRES_API_ERRORS__
#define __CLK_NRES_API_ERRORS__

#define CLK_NRES_API_ERRORS_CODES                                              \
  /**                                                                          \
   * PLL is not enabled                                                        \
   */                                                                          \
  eError_clk_nres_api_pll_not_enabled,                                         \
                                                                               \
  /**                                                                          \
   * Incorrect Clock partition selected.                                       \ 
   */                                                                          \
                                                                               \
  eError_clk_nres_api_incorrect_clock_partition,                               \
  /**                                                                          \
   * Incorrect Master Clock. It should be CLOCK_SOURCE_RCOSC_HF,               \
   * CLOCK_SOURCE_RCOSC_LF, CLOCK_SOURCE_PLL or CLOCK_SOURCE_QOSC              \ 
   */                                                                          \
  eError_clk_nres_api_incorrect_master_clk,                                    \
                                                                               \
  /**                                                                          \
   * Incorrect AS Clock. It should be CLOCK_SOURCE_RCOSC_HF,                   \
   * CLOCK_SOURCE_RCOSC_LF, CLOCK_SOURCE_PLL or CLOCK_SOURCE_QOSC              \ 
   */                                                                          \
  eError_clk_nres_api_incorrect_as_clk,                                        \
                                                                               \
  /**                                                                          \
   * Incorrect module rate. It should be full_rate, high_rate,                 \
   * low_rate_0 or low_rate_1                                                  \
   */                                                                          \
  eError_clk_nres_api_incorrect_rate,                                          \
                                                                               \
  /**                                                                          \
   * Incorrect module name                                                     \
   *                                                                           \
   */                                                                          \
  eError_clk_nres_api_incorrect_module                                               


#endif
 
