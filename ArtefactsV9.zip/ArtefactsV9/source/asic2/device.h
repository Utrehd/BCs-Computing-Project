/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         device.h
*
* @brief        Device configuration
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __DEVICE_H__
#define __DEVICE_H__

#ifdef __cplusplus
extern "C" {
#endif

  /*
   uint32 old_state = __get_PRIMASK();
  __disable_irq();
  .....
  __set_PRIMASK(old_state);
  */
#define CLI __disable_irq(); __ISB();
#define STI __enable_irq(); __ISB();
  
  
// ------------------------------------------------------------------------------------
// Machine Generated
// ------------------------------------------------------------------------------------
// irq_no start
typedef enum {
  /* -------------------  Cortex-M0 Processor Exceptions Numbers  ------------------- */
  Reset_IRQn                                      = -15,              /*!<   1  Reset Vector, invoked on Power up and warm reset                 */
  NonMaskableInt_IRQn                             = -14,              /*!<   2  Non maskable Interrupt, cannot be stopped or preempted           */
  HardFault_IRQn                                  = -13,              /*!<   3  Hard Fault, all classes of Fault                                 */
  SVCall_IRQn                                     =  -5,              /*!<  11  System Service Call via SVC instruction                          */
  PendSV_IRQn                                     =  -2,              /*!<  14  Pendable request for system service                              */
  SysTick_IRQn                                    =  -1,              /*!<  15  System Tick Timer                                                */
/* ---------------------  Specific Interrupt Numbers  --------------------- */
  IRQ_CLK_NRES_0                                  = 0,
  IRQ_SWTIMER0                                    = 1,
  IRQ_TSU                                         = 2,
  IRQ_SWD                                         = 3,
  IRQ_HV_CTRL                                     = 4,
  IRQ_CPU_N_CPU_0                                 = 5,
  IRQ_EL_CTRL                                     = 6,
  IRQ_SWTIMER1                                    = 7,
  IRQ_HISPI                                       = 8,
  IRQ_UART                                        = 9,
  IRQ_CRC0                                        = 10,
  IRQ_CRC1                                        = 11,
  IRQ_GPIO                                        = 12,
  IRQ_SARADC_CTRL                                 = 13,
  IRQ_CPU_N_CPU_1                                 = 14,
  IRQ_PWMN                                        = 15,
  IRQ_CCTIMER0                                    = 16,
  IRQ_CCTIMER1                                    = 17,
  IRQ_USI0                                        = 18,
  IRQ_USI1                                        = 19,
  IRQ_I2C                                         = 20,
  IRQ_CPU_N_CPU_EXT                               = 21,
  IRQ_COUNT                                       = 22,
} IRQn_Type;//irq_number_t;

/** @addtogroup Configuration_of_CMSIS
  * @{
  */


/* ================================================================================ */
/* ================      Processor and Core Peripheral Section     ================ */
/* ================================================================================ */

/* ----------------Configuration of the cm0 Processor and Core Peripherals---------------- */
#define __CM0_REV                 0x0000            /*!< Cortex-M0 Core Revision                                               */
#define __MPU_PRESENT                  0            /*!< MPU present or not                                                    */
#define __NVIC_PRIO_BITS               2            /*!< Number of Bits used for Priority Levels                               */
#define __Vendor_SysTickConfig         0            /*!< Set to 1 if different SysTick Config is used                          */
#define __VTOR_PRESENT                 1
/** @} */ /* End of group Configuration_of_CMSIS */

//#include <core_cm0.h>                               /*!< Cortex-M0 processor and core peripherals                              */
//#include "system_swd.h"                         /*!< SWD System                                                        */


/* ================================================================================ */
/* ================       Device Specific Peripheral Section       ================ */
/* ================================================================================ */
/* Macro to modify desired bitfields of a register */
#define WR_REG(reg, mask, pos, val) reg = (((uint32_t)val << pos) & mask) | \
                                          (reg & ((uint32_t)~((uint32_t)mask)))

/* Macro to modify desired bitfields of a register */
#define WR_REG_SIZE(reg, mask, pos, val, size) {  \
uint##size##_t VAL1 = (uint##size##_t)((uint##size##_t)val << pos); \
uint##size##_t VAL2 = (uint##size##_t) (VAL1 & (uint##size##_t)mask); \
uint##size##_t VAL3 = (uint##size##_t)~((uint##size##_t)mask); \
uint##size##_t VAL4 = (uint##size##_t) ((uint##size##_t)reg & VAL3); \
reg = (uint##size##_t) (VAL2 | VAL4);\
}

/** Macro to read bitfields from a register */
#define RD_REG(reg, mask, pos) (((uint32_t)reg & (uint32_t)mask) >> pos)

/** Macro to read bitfields from a register */
#define RD_REG_SIZE(reg, mask, pos,size) ((uint##size##_t)(((uint32_t)reg & \
                                                      (uint32_t)mask) >> pos) )

/** Macro to set a bit in register */
#define SET_BIT(reg, pos)     (reg |= ((uint32_t)1<<pos))

/** Macro to clear a bit in register */
#define CLR_BIT(reg, pos)     (reg = reg & (uint32_t)(~((uint32_t)1<<pos)) )


#include "stdint.h"

// ------------------------------------------------------------------------------------
// Compiler Wrapper Defines
// ------------------------------------------------------------------------------------
#ifdef __GNUC__
  #include <signal.h>
	#include <stdint.h>
  #define _INTERRUPT_     void __attribute__ ((interrupt("IRQ")))
  #define _IRQ_           
  #define _PACKED_        __attribute__ ((packed))
	#define _INLINE_        inline
#endif

#ifdef __IAR_SYSTEMS_ICC__
  #define _INTERRUPT_     __irq  void
  #define _IRQ_           __irq __arm
  #define _PACKED_
  #define _INLINE_
#endif

// ------------------------------------------------------------------------------------
// Additional Type Defines
// ------------------------------------------------------------------------------------
#ifdef __IAR_SYSTEMS_ICC__
#include <stdbool.h>
#else
#if defined(DPI) && defined(__cplusplus)
#else
typedef enum {
	false = 0,
	true  = 1
} bool;
#endif
#endif

#ifndef DPI
typedef int ssize_t;
#endif

#ifndef NULL
#define NULL ((void *)0)
#endif

// ------------------------------------------------------------------------------------
// Memory Access Macros
// ------------------------------------------------------------------------------------
#define POINTER_TO_ADDRESS(ptr)  ((uint32_t)(ptr))

#define WRITE_REG_8(addr,data)   (*(volatile uint8_t *)(addr) = (data))
#define READ_REG_U8(addr)        ((uint8_t)(*(volatile uint8_t *)(addr)))
#define READ_REG_S8(addr)        (( int8_t)(*(volatile  int8_t *)(addr)))
#define BIS_REG_8(addr,data)     (*(volatile uint8_t *)(addr) |=  (uint8_t)(data))
#define BIC_REG_8(addr,data)     (*(volatile uint8_t *)(addr) &= ~(uint8_t)(data))

#define WRITE_REG_16(addr,data)  (*(volatile uint16_t *)(addr) = (data))
#define READ_REG_U16(addr)       ((uint16_t)(*(volatile uint16_t *)(addr)))
#define READ_REG_S16(addr)       (( int16_t)(*(volatile  int16_t *)(addr)))
#define BIS_REG_16(addr,data)    (*(volatile uint16_t *)(addr) |=  (uint16_t)(data))
#define BIC_REG_16(addr,data)    (*(volatile uint16_t *)(addr) &= ~(uint16_t)(data))

#define WRITE_REG_32(addr,data)  (*(volatile uint32_t *)(addr) = (data))
#define READ_REG_U32(addr)       ((uint32_t)(*(volatile uint32_t *)(addr)))
#define READ_REG_S32(addr)       (( int32_t)(*(volatile  int32_t *)(addr)))
#define BIS_REG_32(addr,data)    (*(volatile uint32_t *)(addr) |=  (uint32_t)(data))
#define BIC_REG_32(addr,data)    (*(volatile uint32_t *)(addr) &= ~(uint32_t)(data))

#define WRITE_MEM_PTR(addr,ptr)  (*(volatile uintptr_t *)(addr) = (ptr))

/**@} */
#endif /* __DEVICE_H__ */

