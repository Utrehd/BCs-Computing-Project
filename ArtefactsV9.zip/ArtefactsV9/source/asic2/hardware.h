/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hardware.h
*
* @brief        System Hardware includes
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HARDWARE_H__
#define __HARDWARE_H__

  #include <device.h>

  #include <access_control.h>
  #include <analog_ctrl_tmr.h>
  #include <analog_ctrl_fll.h>
  #include <analog_ctrl.h>
  #include <aout_ctrl.h>
  #include <cctimer32_irq.h>
  #include <cctimer32.h>
  #include <clk_nres_irq.h>
  #include <clk_nres.h>
  #include <core_cm0plus.h>
  #include <core_cmFunc.h>
  #include <core_cmInstr.h>
  #include <cpu_n_cpu_irq.h>
  #include <cpu_n_cpu.h>
  #include <crc_irq.h>
  #include <crc.h>
  #include <el_ctrl_irq.h>
  #include <el_ctrl.h>
  #include <flash_ctrl.h>
  #include <gpio_irq.h>
  #include <gpio.h>
  #include <hiad.h>
  #include <hispi_irq.h>
  #include <hispi.h>
  #include <hv_ctrl_irq.h>
  #include <hv_ctrl.h>
  #include <i2c_irq.h>
  #include <i2c.h>
  #include <io_ctrl.h>
  #include <pwmn_irq.h>
  #include <pwmn.h>
  #include <saradc_ctrl_irq.h>
  #include <saradc_ctrl.h>
  #include <saradc_ctrl_list_helper.h>
  #include <sram.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>
  #include <swd.h>
  #include <sw_jtag.h>
  #include <swtimer_bf.h>
  #include <swtimer_irq.h>
  #include <swtimer.h>
  #include <tsu_irq.h>
  #include <tsu.h>
  #include <uart_irq.h>
  #include <uart.h>
  #include <usi_irq.h>
  #include <usi_spi.h>
  #include <usi_uart.h>
  #include <usi.h>
  #include <utils.h>
  #include <vic_ext_irq.h>
  #include <vic_ext.h>
  #include <wdog.h>
/**@} */
#endif /* __HARDWARE_H__ */
