/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         i2c_irq.h
*
* @brief        I2C Master Interface HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __I2C_IRQ_H__
#define __I2C_IRQ_H__

#define I2C_NUM_IRQS 13

/* ############################################################################ */
/**
 * \brief List of I2C Interrupt sources 
 *
 * \ingroup i2c 
 */ 
typedef enum{
  I2C_IRQ_EVT_REC_FIFO_OV_ERR =         0,  ///< software did not read incoming data fast enough
  I2C_IRQ_EVT_REC_FIFO_UR_ERR =         1,  ///< software has read from empty receive fifo
  I2C_IRQ_EVT_CMD_FIFO_OV_ERR =         2,  ///< software wrote data to full transmit fifo
  I2C_IRQ_EVT_CMD_FIFO_UR_ERR =         3,  ///< software has not written outgoing data fast enough
  I2C_IRQ_EVT_ACK_ERR =                 4,  ///< acknoledge error
  I2C_IRQ_EVT_BIT_ERR =                 5,  ///< bit error (looped back transmit bit mismatch)
  I2C_IRQ_REC_FIFO_NEMPTY =             6,  ///< receive fifo is not empty
  I2C_IRQ_REC_FIFO_HIGH_WATER =         7,  ///< receive fifo elements > high water level
  I2C_IRQ_REC_FIFO_FULL =               8,  ///< receive fifo is full
  I2C_IRQ_CMD_FIFO_EMPTY =              9,  ///< transmit fifo is empty
  I2C_IRQ_CMD_FIFO_LOW_WATER =          10, ///< transmit fifo elements <= low water level
  I2C_IRQ_CMD_FIFO_NFULL =              11, ///< transmit fifo is not full
  I2C_IRQ_SCL_STRETCH =                 12  ///< scl is stretched by slow slave
} i2c_irq_t;

#endif
