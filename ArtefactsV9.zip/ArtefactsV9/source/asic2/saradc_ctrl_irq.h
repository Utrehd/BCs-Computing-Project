/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         saradc_ctrl_irq.h
*
* @brief        SAR ADC Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __SARADC_CTRL_IRQ_H__
#define __SARADC_CTRL_IRQ_H__

#define SARADC_CTRL_NUM_IRQS 15

/** 
 * \brief This enumeration describes SAR ADC status interrupts
 *
 * \ingroup saradc_ctrl
 */
typedef enum{
  /**
   * a sum was not written to memory. The associated
   * address has been skipped.
   */
  SARADC_CTRL_IRQ_DMA_WRITE_ERR =       0,
  
  /**
   * sum written to memory
   */
  SARADC_CTRL_IRQ_SUM_WRITTEN_EVT =     1,
  
  /**
   * list completed
   */
  SARADC_CTRL_IRQ_LIST_DONE_EVT =       2,
  
  /**
   * SADR_DONE contains a new completed start address.
   */
  SARADC_CTRL_IRQ_SADR_DONE_NEMPTY =    3,
  
  /**
   * SADR_NEW can accept a new start address.
   */
  SARADC_CTRL_IRQ_SADR_NEW_NFULL =      4,
  
  /**
   * sum out of range
   */
  SARADC_CTRL_IRQ_OOR0 =                5,

  /**
   * sum out of range
   */
  SARADC_CTRL_IRQ_OOR1 =                6,
  
  /**
   * sum out of range
   */
  SARADC_CTRL_IRQ_OOR2 =                7,

  /**
   * sum out of range
   */
  SARADC_CTRL_IRQ_OOR3 =                8,

  /**
   * sum out of range
   */
  SARADC_CTRL_IRQ_OOR4 =                9,

  /**
   * sum out of range
   */
  SARADC_CTRL_IRQ_OOR5 =                10,

  /**
   * sum out of range
   */
  SARADC_CTRL_IRQ_OOR6 =                11,

  /**
   * sum out of range
   */
  SARADC_CTRL_IRQ_OOR7 =                12,

  /**
   * sum out of range
   */
  SARADC_CTRL_IRQ_OOR8 =                13,

  /**
   * the current trigger occurred after the previous trigger but
   * before it could be processed (e.h. because the ADC is still
   * converting)- 0xFFFFF is written to all no_sum sums.
   */
  SARADC_CTRL_IRQ_MISSED_TRIGGER =      14
} saradc_ctrl_irq_t;

#endif
