/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         access_control.h
*
* @brief        Access Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HAVE_ACCESS_CONTROL_H__
#define __HAVE_ACCESS_CONTROL_H__

/**
 * \example example_access_control.c
 * This is an example of how to use CRC block.
 */

/**
 * \defgroup access_control ASIC2 Access Control HAL functions
 *
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control Access Control
 *
 * \details See code example: @include example_access_control.c
 */
/**@{*/ 

#include "device.h"

#include "access_control_bf.h"

/**
  * \brief This is an enum class for Access Control to define the AHBL Masters
  *
  * \ingroup access_control
  */
typedef enum {
  ACCESS_CONTROL_MASTER_HIAD     = 0, ///< AHBL Master HIAD
  ACCESS_CONTROL_MASTER_HISPI    = 1, ///< AHBL Master HISPI
  ACCESS_CONTROL_MASTER_SWD      = 2, ///< AHBL Master SWD
  ACCESS_CONTROL_MASTER_CCPU0    = 3, ///< AHBL Master CCPU0
  ACCESS_CONTROL_MASTER_SARC     = 4, ///< AHBL Master SARC
  ACCESS_CONTROL_MASTER_USI0     = 5, ///< AHBL Master USI0
  ACCESS_CONTROL_MASTER_USI1     = 6, ///< AHBL Master USI1
  ACCESS_CONTROL_MASTER_ACPU1    = 7, ///< AHBL Master ACPU1
} access_control_master_t;

/**
  * \brief This is an enum class for Access Control to define the type of access
  *
  * \ingroup access_control
  */
typedef enum {
  ACCESS_CONTROL_ACCESS_NONE  = 0, ///< No access
  ACCESS_CONTROL_ACCESS_RO    = 1, ///< Read Only
  ACCESS_CONTROL_ACCESS_WO    = 2, ///< Write Only
  ACCESS_CONTROL_ACCESS_RW    = 3, ///< Read and Write
} access_control_access_t;

/**
  * \brief This is an enum class for Access Control to define SRAM memory
  *
  * \ingroup access_control
  */
typedef enum {
  ACCESS_CONTROL_RAM0     = 0, ///< SRAM Memory 0
  ACCESS_CONTROL_RAM1     = 1, ///< SRAM Memory 1
  ACCESS_CONTROL_RAME     = 2, ///< SRAM Memory external
} access_control_ram_t;

/**
  * \brief This is an enum class for Access Control to define peripheral busses
  *
  * \ingroup access_control
  */
typedef enum {
  ACCESS_CONTROL_PERI0    = 0, ///< Peripheral bus 0
  ACCESS_CONTROL_PERI1    = 1, ///< Peripheral bus 1
  ACCESS_CONTROL_PERIE    = 2, ///< Peripheral bus external
} access_control_peri_t;

/**
  * \brief This is an enum class for Access Control to define address range
  *
  * \ingroup access_control
  */ 
typedef enum {
  ACCESS_CONTROL_R0    = 0, ///< Address range 0
  ACCESS_CONTROL_R1    = 1, ///< Address range 1
} access_control_range_t;

/**
  * \brief This is an enum class for Access Control to define wbbus id numbers
  *
  * \ingroup access_control
  */ 
// wbbus_id start
typedef enum {
  WBBUS_MODULE_CLK_NRES_0                         = 0, ///< WBBUS ID for clk_nres_0 module
  WBBUS_MODULE_SWTIMER0                           = 1, ///< WBBUS ID for swtimer0 module
  WBBUS_MODULE_WDOG0                              = 2, ///< WBBUS ID for wdog0 module
  WBBUS_MODULE_TSU                                = 3, ///< WBBUS ID for tsu module
  WBBUS_MODULE_SWD                                = 4, ///< WBBUS ID for swd module
  WBBUS_MODULE_GUARD0                             = 5, ///< WBBUS ID for guard0 module
  WBBUS_MODULE_ACCESS_CONTROL                     = 6, ///< WBBUS ID for access_control module
  WBBUS_MODULE_HV_CTRL                            = 7, ///< WBBUS ID for hv_ctrl module
  WBBUS_MODULE_ANALOG_CTRL                        = 8, ///< WBBUS ID for analog_ctrl module
  WBBUS_MODULE_FLASH_CTRL0                        = 9, ///< WBBUS ID for flash_ctrl0 module
  WBBUS_MODULE_CPU_N_CPU_0                        = 10, ///< WBBUS ID for cpu_n_cpu_0 module
  WBBUS_MODULE_EL_CTRL                            = 11, ///< WBBUS ID for el_ctrl module
  WBBUS_MODULE_IO_CTRL                            = 12, ///< WBBUS ID for io_ctrl module
  WBBUS_MODULE_SWTIMER1                           = 13, ///< WBBUS ID for swtimer1 module
  WBBUS_MODULE_HISPI                              = 14, ///< WBBUS ID for hispi module
  WBBUS_MODULE_HIAD                               = 15, ///< WBBUS ID for hiad module
  WBBUS_MODULE_UART                               = 16, ///< WBBUS ID for uart module
  WBBUS_MODULE_CRC0                               = 17, ///< WBBUS ID for crc0 module
  WBBUS_MODULE_CRC1                               = 18, ///< WBBUS ID for crc1 module
  WBBUS_MODULE_GPIO                               = 19, ///< WBBUS ID for gpio module
  WBBUS_MODULE_SARADC_CTRL                        = 20, ///< WBBUS ID for saradc_ctrl module
  WBBUS_MODULE_CPU_N_CPU_1                        = 21, ///< WBBUS ID for cpu_n_cpu_1 module
  WBBUS_MODULE_PWMN                               = 22, ///< WBBUS ID for pwmn module
  WBBUS_MODULE_CLK_NRES_1                         = 23, ///< WBBUS ID for clk_nres_1 module
  WBBUS_MODULE_GUARD1                             = 24, ///< WBBUS ID for guard1 module
  WBBUS_MODULE_WDOG1                              = 25, ///< WBBUS ID for wdog1 module
  WBBUS_MODULE_CCTIMER0                           = 26, ///< WBBUS ID for cctimer0 module
  WBBUS_MODULE_CCTIMER1                           = 27, ///< WBBUS ID for cctimer1 module
  WBBUS_MODULE_USI0                               = 28, ///< WBBUS ID for usi0 module
  WBBUS_MODULE_USI1                               = 29, ///< WBBUS ID for usi1 module
  WBBUS_MODULE_AOUT_CTRL                          = 30, ///< WBBUS ID for aout_ctrl module
  WBBUS_MODULE_I2C                                = 31, ///< WBBUS ID for i2c module
  WBBUS_MODULE_FLASH_CTRL1                        = 32, ///< WBBUS ID for flash_ctrl1 module
  WBBUS_MODULE_CPU_N_CPU_EXT                      = 33, ///< WBBUS ID for cpu_n_cpu_ext module
  WBBUS_MODULE_VIC_EXT                            = 34, ///< WBBUS ID for vic_ext module
  WBBUS_MODULE_COUNT                              = 35, ///< WBBUS ID for count module
} wbbus_module_t;
// wbbus_id end

/* ############################################################################ */
/**
 * \brief   Function to set to the default value the Access Control configuration
 *          All modules are unlocked.
 *
 * \ingroup access_control
 * 
 */
void access_control_unlock(void);

/* ############################################################################ */
/**
 * \brief   Function to set the peripheral access
 *
 * \ingroup access_control
 * 
 * \param master Master ID
 * 
 * \param peri_bus Peripheral ID
 * 
 * \param access Type of access: None, Read-only, Write-only, Read-Write
 * 
 */
void access_control_set_peri_access(access_control_master_t master, access_control_peri_t peri_bus, access_control_access_t access);

/* ############################################################################ */
/**
 * \brief   Function to set the RAM access
 *
 * \ingroup access_control
 * 
 * \param master Master ID
 * 
 * \param ram RAM ID
 * 
 * \param access Type of access: None, Read-only, Write-only, Read-Write
 * 
 */
void access_control_set_ram_access(access_control_master_t master, access_control_ram_t ram, access_control_access_t access);

/* ############################################################################ */
/**
 * \brief   Function to set the Peripheral Buses access
 *
 * \ingroup access_control
 * 
 * \param master Master ID
 * 
 * \param ram RAM ID
 * 
 * \param access Type of access: None, Read-only, Write-only, Read-Write
 * 
 */
void access_control_set_wbbus_access(access_control_master_t master, wbbus_module_t module, access_control_access_t access);

/* ############################################################################ */
/**
 * \brief   Function to set the range of addresses the master can access
 *			The address window check is only active while the address of the requesting master is within the SRAM range 0x2000xxxx
 *			The Flash memory and peripheral modules are not protected with the address range checks
 *
 * \ingroup access_control
 * 
 * \param range Range
 * 
 * \param ram RAM ID
 * 
 * \param access Type of access: None, Read-only, Write-only, Read-Write
 * 
 * \param low_addr Lowest address to be accessed by master
 * 
 * \param high_addr Highest address to be accessed by master 
 * 
 */
void access_control_set_master_range(access_control_master_t master, access_control_range_t range, access_control_access_t access, uint16_t low_addr, uint16_t high_addr);

/**@} */
#endif /* __HAVE_ACCESS_CONTROL_H__ */
