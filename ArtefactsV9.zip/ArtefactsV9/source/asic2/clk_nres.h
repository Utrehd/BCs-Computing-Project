/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         clk_nres.h
*
* @brief        Clock and Reset Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CLK_NRES_H__
#define __CLK_NRES_H__

/**
 * \example example_clk_nres.c
 * This is an example of how to use clk_nres block.
 */


/**
 * \image html CLK-NRES.png
 * block schematic of Clock and Reset Control block
 */


/**
 * \defgroup clk_nres ASIC2 Clock and Reset Control API functions
 * 
 * \ingroup  asic2_hal
 *
 * \brief    Functions to control Clock and Reset Control
 *
 * \details See code example: @include example_clk_nres.c
 */
/**@{*/ 

#include "device.h"


#include "clk_nres_bf.h"
#include "clk_nres_irq.h"

/**
  * \brief This is an enum class for CLK_NRES to identify clock for each module
  *
  * \ingroup clk_nres
  */
typedef enum {
  CLKPNO_BUS_SYSTEM                               = 0,
  CLKPNO_CCPU0                                    = 1,
  CLKPNO_ACPU1                                    = 2,
  CLKPNO_CRC0                                     = 3,
  CLKPNO_CRC1                                     = 4,
  CLKPNO_HIAD                                     = 5,
  CLKPNO_HISPI                                    = 6,
  CLKPNO_SWD                                      = 7,
  CLKPNO_SARADC_CTRL                              = 8,
  CLKPNO_USI0                                     = 9,
  CLKPNO_USI1                                     = 10,
  CLKPNO_TSU                                      = 11,
  CLKPNO_GPIO                                     = 12,
  CLKPNO_GUARD0                                   = 13,
  CLKPNO_GUARD1                                   = 14,
  CLKPNO_SWTIMER0                                 = 15,
  CLKPNO_SWTIMER1                                 = 16,
  CLKPNO_PWMN                                     = 17,
  CLKPNO_VIC_EXT                                  = 18,
  CLKPNO_WDOG0                                    = 19,
  CLKPNO_WDOG1                                    = 20,
  CLKPNO_CPU_N_CPU                                = 21,
  CLKPNO_CCTIMER0                                 = 22,
  CLKPNO_CCTIMER1                                 = 23,
  CLKPNO_IO_CTRL                                  = 24,
  CLKPNO_ANALOG_CTRL                              = 25,
  CLKPNO_ACCESS_CONTROL                           = 26,
  CLKPNO_HV_CTRL                                  = 27,
  CLKPNO_UART                                     = 28,
  CLKPNO_AOUT_CTRL                                = 29,
  CLKPNO_I2C                                      = 30,
  CLKPNO_EL_CTRL                                  = 31,
  CLKPNO_COUNT                                    = 32,
} clkpno_t;
// clkpno end

#define CLKPNO_MASTERS CLKPNO_TSU

/**
  * \brief This is an enum class for CLK_NRES to identify clock source
  *
  * \ingroup clk_nres
  */
typedef enum {
  CLOCK_SOURCE_0              = 0,
  CLOCK_SOURCE_RCOSC_HF       = CLOCK_SOURCE_0,
  CLOCK_SOURCE_1              = 1,
  CLOCK_SOURCE_RCOSC_LF       = CLOCK_SOURCE_1,  
  CLOCK_SOURCE_2              = 2,
  CLOCK_SOURCE_QOSC           = CLOCK_SOURCE_2,
  CLOCK_SOURCE_3              = 3,
  CLOCK_SOURCE_PLL            = CLOCK_SOURCE_3,
  CLOCK_SOURCE_COUNT          = 4,
} clock_source_t;

/**
  * \brief This is an enum class for CLK_NRES to identify rate clock partition
  *
  * \ingroup clk_nres
  */
typedef enum {
  full_rate           = 0,
  high_rate           = 1,
  low_rate_0          = 2,
  low_rate_1          = 3,
} clk_rate_t;

/**
  * \brief This is an enum class for CLK_NRES to identify clock domain
  *
  * \ingroup clk_nres
  */
typedef enum {
  AS0               = 0,
  AS_SWD_TSU        = AS0,
  AS1               = 1,
  AS_USI0           = AS1,
  AS2               = 2,
  AS_USI1           = AS2,  
  AS3               = 3,
  AS_HISPI          = AS3,  
  AS_COUNT          = 4,
  MAIN              = 4,
  CLK_DOMAIN_COUNT  = 5,
} clk_domain_t;

/**
  * \brief This is an enum class for CLK_NRES to identify clock watches
  *
  * \ingroup clk_nres
  */
typedef enum {
  CW0          = 0,
  CW1          = 1,
} clk_cw_t;

/**
  * \brief This is an enum class for CLK_NRES to identify PLL source
  *
  * \ingroup clk_nres
  */
typedef enum {
  PLL_RCOSC_HF  = 0,
  PLL_QOSC      = 1,
} clk_pll_src_t;

//******************************************************************************
// CONFIG
//******************************************************************************

/* ############################################################################ */
/**
 * \brief   Function to unlock CLK_NRES
 *
 * \ingroup clk_nres
 *
 */
void clk_nres_unlock(void);

/* ############################################################################ */
/**
 * \brief   Function to enable GUARD
 *
 * \ingroup clk_nres
 * 
 * \param sel Select CLK_NRES instance
 *
 */
void clk_nres_guard_enable(clk_nres_num_t sel);

/* ############################################################################ */
/**
 * \brief   Function to disable GUARD
 *
 * \ingroup clk_nres
 * 
 * \param sel Select CLK_NRES instance
 *
 */
void clk_nres_guard_disable(clk_nres_num_t sel);

/* ############################################################################ */
/**
 * \brief   Function to get if CLK_NRES is enabled
 *
 * \ingroup clk_nres
 * 
 * \param sel Select CLK_NRES instance
 *
 * \return 1: enabled
 * 
 */
bool clk_nres_is_enabled(clk_nres_num_t sel);

/* ############################################################################ */
/**
 * \brief   Function to enable watchdog reset
 *
 * \ingroup clk_nres
 * 
 * \param val 1: enable reset
 *
 */
void clk_nres_enable_wdog1_global_reset(bool val);

/* ############################################################################ */
/**
 * \brief   Function to enable peripheral wbus 'peri0' reset when access to a disabled module
 *
 * \ingroup clk_nres
 * 
 * \param val 1: enable reset
 *
 */
void clk_nres_enable_nres_peri0_off_acc(bool val);

/* ############################################################################ */
/**
 * \brief   Function to enable peripheral wbus 'peri1' reset when access to a disabled module
 *
 * \ingroup clk_nres
 * 
 * \param val 1: enable reset
 *
 */
void clk_nres_enable_nres_peri1_off_acc(bool val);

/* ############################################################################ */
/**
 * \brief   Function to enable peripheral wbus 'perie' reset when access to a disabled module
 *
 * \ingroup clk_nres
 * 
 * \param val 1: enable reset
 *
 */
void clk_nres_enable_nres_perie_off_acc(bool val);

/* ############################################################################ */
/**
 * \brief   Function to enable reset when CCPU0 lockup
 *
 * \ingroup clk_nres
 * 
 * \param val 1: enable reset
 *
 */
void clk_nres_enable_nres_ccpu0_lockup(bool val);

/* ############################################################################ */
/**
 * \brief   Function to enable reset when ACPU1 lockup
 *
 * \ingroup clk_nres
 * 
 * \param val 1: enable reset
 *
 */
void clk_nres_enable_nres_acpu1_lockup(bool val);

/* ############################################################################ */
/**
 * \brief   Function to get if watchdog reset is enabled
 *
 * \ingroup clk_nres
 *
 * \return 1: enabled
 * 
 */
bool clk_nres_is_enable_wdog1_global_reset(void);

/* ############################################################################ */
/**
 * \brief   Function to enable reset by watchdog 1
 *
 * \ingroup clk_nres
 * 
 * \param nr Number clock partition
 * 
 * \param mask nres[*] of the corresponding clock partitions " " will be asserted when wdog1 expires
 *
 *             \note CLK_NRES, Bus Infrastructure, CCPU0, WDOG0, WDOG1 and ANALOG_CTRL cannot be reset by software
 *                   to avoid deadlocks. Special care should also be taken for resets of modules used by the other CPU.
 */
void clk_nres_set_cfg_wdog1_nres_en(uint8_t nr, uint16_t mask);

/* ############################################################################ */
/**
 * \brief   Function to configure reset by watchdog 1
 *
 * \ingroup clk_nres
 * 
 * \param mask       0: as_nres0_swd_tsu 0 rw 1 : as_nres0 will be asserted when wdog1 expires
 *                   1: as_nres1_usi0 0 rw 1: as_nres1 will be asserted when wdog1 expires
 *                   2: as_nres2_usi1 0 rw 1: as_nres2 will be asserted when wdog1 expires
 *                   3: as_nres3_hispi 0 rw 1: as_nres3 will be asserted when wdog1 expires
 *
 *             \note CLK_NRES, Bus Infrastructure, CCPU0, WDOG0, WDOG1 and ANALOG_CTRL cannot be reset by software
 *                   to avoid deadlocks. Special care should also be taken for resets of modules used by the other CPU.
 */
void clk_nres_set_cfg_wdog1_nres_en_as(uint8_t mask);

/* ############################################################################ */
/**
 * \brief   Function to set the clock root
 *
 * \ingroup clk_nres
 * 
 * \param domain Select clock domain
 *
 * \param clock_source Select clock source
 *
 */
void clk_nres_sel_clk_root(clk_domain_t domain, clock_source_t clock_source);

/* ############################################################################ */
/**
 * \brief   Function to set the clock rate
 *
 * \ingroup clk_nres
 * 
 * \param clk_rate Select clock rate
 *
 * \param rate Value of the rate
 *
 */
void clk_nres_set_clk_rate(clk_rate_t clk_rate, uint8_t rate);

/* ############################################################################ */
/**
 * \brief   Function to set a specific clock rate to a module
 *
 * \ingroup clk_nres
 *
 * \param clkpno Select the module
 * 
 * \param clk_rate Select clock rate
 *
 */
void clk_nres_set_rate_sel(clkpno_t clkpno, clk_rate_t clk_rate);

/* ############################################################################ */
/**
 * \brief   Function to set clock divider
 *
 * \ingroup clk_nres
 *
 * \param domain Select clock domain
 * 
 * \param div Divider value
 *
 */
void clk_nres_set_clk_divider(clk_domain_t domain, uint8_t div);

/* ############################################################################ */
/**
 * \brief   Function to enable clock on/off control
 *
 * \ingroup clk_nres
 *
 * \param sel Select CLK_NRES instance
 *
 * \param wbbus Select wbus[0] or wbus[1]
 *
 * \param nr Number of clock domain
 * 
 * \param mask 0: software control via bus interface wbus[*] access on registers CLK_SW_ON / OFF for clk[*] disabled
 *
 */
void clk_nres_set_cfg_sw_onoff_en(clk_nres_num_t sel, uint8_t wbbus, uint8_t nr, uint16_t mask);

/* ############################################################################ */
/**
 * \brief   Function to get clock on/off control
 *
 * \ingroup clk_nres
 *
 * \param sel Select CLK_NRES instance
 *
 * \param wbbus Select wbus[0] or wbus[1]
 *
 * \param nr Number of clock domain
 * 
 * \return 0: software control via bus interface wbus[*] access on registers CLK_SW_ON / OFF for clk[*] disabled
 *
 */
uint16_t  clk_nres_get_cfg_sw_onoff_en(clk_nres_num_t sel, uint8_t wbbus, uint8_t nr);

/* ############################################################################ */
/**
 * \brief   Function to enable clock on/off control for AS domain
 *
 * \ingroup clk_nres
 *
 * \param sel Select CLK_NRES instance
 *
 * \param wbbus Select wbus[0] or wbus[1]
 *
 * \param nr Number of clock domain
 * 
 * \param mask 0: software control via bus interface wbus[0] access on registers CLK_SW_ON / OFF_AS for as_clk[0] disabled
 *
 */
void clk_nres_set_cfg_as_onoff_en(clk_nres_num_t sel, uint8_t wbbus, uint8_t mask);

/* ############################################################################ */
/**
 * \brief   Function to get clock on/off control for AS domain
 *
 * \ingroup clk_nres
 *
 * \param sel Select CLK_NRES instance
 *
 * \param wbbus Select wbus[0] or wbus[1]
 *
 * \param nr Number of clock domain
 * 
 * \return 0: software control via bus interface wbus[0] access on registers CLK_SW_ON / OFF_AS for as_clk[0] disabled
 *
 */
uint8_t   clk_nres_get_cfg_as_onoff_en(clk_nres_num_t sel, uint8_t wbbus);

//******************************************************************************
// ANALOG
//******************************************************************************

/* ############################################################################ */
/**
 * \brief   Function to configure PLL
 *
 * \ingroup clk_nres
 *
 * \param src Select the PLL source
 * 
 * \param PD_N 1: PLL enabled
 * 
 * \param NR Select input divider value
 * 
 * \param NF Select feed back bit divider value
 * 
 * \param OD Select output divider value
 *
 */
void clk_nres_config_pll(clk_pll_src_t src, bool PD_N, uint8_t NR, uint8_t NF, uint8_t OD);

/* ############################################################################ */
/**
 * \brief   Function to enable PLL output
 *
 * \ingroup clk_nres
 *
 * \param OE Output enable
 *
 */
void clk_nres_set_pll_oe(bool OE);

/* ############################################################################ */
/**
 * \brief   Function to enable rcosc_hf clock
 *
 * \ingroup clk_nres
 *
 * \param rcosc_hf_enable 1: Enabled
 *
 */
void clk_nres_set_rcosc_hf_enable(bool rcosc_hf_enable);

/* ############################################################################ */
/**
 * \brief   Function to enable Quartz Oscillator (qosc) clock
 *
 * \ingroup clk_nres
 *
 * \param qosc_enable 1: Enabled
 *
 */
void clk_nres_set_qosc_enable(bool qosc_enable);

/* ############################################################################ */
/**
 * \brief   Function to select driving strength of Quartz Oscillator (qosc)
 *
 * \ingroup clk_nres
 *
 * \param qosc_strength Select qosc strength
 *
 */
void clk_nres_set_qosc_strength(uint8_t qosc_strength);

/* ############################################################################ */
/**
 * \brief   Function to select bypass Quartz Oscillator (qosc)
 *
 * \ingroup clk_nres
 *
 * \param qosc_clk_bypass 1: QOSC pad allows single ended clock
 *
 */
void clk_nres_set_qosc_clk_bypass(bool qosc_clk_bypass);

//******************************************************************************
// SW CONTROL
//******************************************************************************

/* ############################################################################ */
/**
 * \brief   Function to enable clock partition
 *
 * \ingroup clk_nres
 *
 * \param sel Select CLK_NRES instance
 *
 * \param clkpno Select the modules
 *
 * \param enable 1: Enable
 *
 */
void clk_nres_enable_clock_partition(clk_nres_num_t sel, clkpno_t clkpno, bool enable);

/* ############################################################################ */
/**
 * \brief   Function to enable software reset in clock partition
 *
 * \ingroup clk_nres
 *
 * \param clkpno Select the modules
 *
 * \param nreset 1: Enable
 *
 */
void clk_nres_set_nreset(clkpno_t clkpno, bool nreset);

/* ############################################################################ */
/**
 * \brief   Function to enable clock domain
 *
 * \ingroup clk_nres
 *
 * \param sel Select CLK_NRES instance
 *
 * \param AS Select clock domain
 *
 * \param enable 1: Enable
 *
 */
void clk_nres_enable_as_clock_domain(clk_nres_num_t sel, clk_domain_t AS, bool enable);

/* ############################################################################ */
/**
 * \brief   Function to enable software reset in clock domain
 *
 * \ingroup clk_nres
 *
 * \param AS Select clock domain
 *
 * \param nreset 1: Enable
 *
 */
void clk_nres_set_as_nreset(clk_domain_t AS, bool nreset);

/* ############################################################################ */
/**
 * \brief   Function to get reset sources
 *
 * \ingroup clk_nres
 *
 * \return Reset sources
 * 
 */
uint16_t  clk_nres_get_nres_sources(void);

/* ############################################################################ */
/**
 * \brief   Function to clear reset sources
 *
 * \ingroup clk_nres
 *
 * \param sources Reset sources to be cleared
 *
 */
void clk_nres_clear_nres_sources(uint16_t sources);

/* ############################################################################ */
/**
 * \brief   Function to wake up ACPU1
 *
 * \ingroup clk_nres
 *
 */
void clk_nres_wake_cpu1(void);

//******************************************************************************
// CW 
//******************************************************************************

/* ############################################################################ */
/**
 * \brief   Function to get clock watch configuration (into a pointer)
 *
 * \ingroup clk_nres
 *
 * \param cw Select clock watch
 *
 * \param cfg Pointer to the current configuration
 *
 */
void clk_nres_get_cw_cfg(clk_cw_t cw, clk_nres_cfg_cw_t * cfg);

/* ############################################################################ */
/**
 * \brief   Function to set clock watch configuration
 *
 * \ingroup clk_nres
 *
 * \param cw Select clock watch
 *
 * \param cfg Value of the configuration
 *
 */
void clk_nres_set_cw_cfg(clk_cw_t cw, clk_nres_cfg_cw_t cfg);

/* ############################################################################ */
/**
 * \brief   Function to set minimum of acceptable number of fast clock periods in clock watch
 *
 * \ingroup clk_nres
 *
 * \param cw Select clock watch
 *
 * \param min Value of number of fast clock periods
 *
 */
void clk_nres_set_cw_min(clk_cw_t cw, uint16_t min);

/* ############################################################################ */
/**
 * \brief   Function to set maximum of acceptable number of fast clock periods in clock watch
 *
 * \ingroup clk_nres
 *
 * \param cw Select clock watch
 *
 * \param max Value of number of fast clock periods
 *
 */
void clk_nres_set_cw_max(clk_cw_t cw, uint16_t max);

/* ############################################################################ */
/**
 * \brief   Function to get clock watch configuration
 *
 * \ingroup clk_nres
 *
 * \param cw Select clock watch
 *
 * \return Value of current configuration
 * 
 */
clk_nres_cfg_cw_t clk_nres_get_cfg_cw(clk_cw_t cw);

/* ############################################################################ */
/**
 * \brief   Function to get minimum of acceptable number of fast clock periods in clock watch
 *
 * \ingroup clk_nres
 *
 * \param cw Select clock watch
 *
 * \return Value of number of fast clock periods
 * 
 */
uint16_t clk_nres_get_cw_min(clk_cw_t cw);

/* ############################################################################ */
/**
 * \brief   Function to get maximum of acceptable number of fast clock periods in clock watch
 *
 * \ingroup clk_nres
 *
 * \param cw Select clock watch
 *
 * \return Value of number of fast clock periods
 * 
 */
uint16_t clk_nres_get_cw_max(clk_cw_t cw);

/* ############################################################################ */
/**
 * \brief   Function to get the measurement from the clock watch
 *
 * \ingroup clk_nres
 *
 * \param cw Select clock watch
 *
 * \return Value of current measurement
 * 
 */
uint16_t clk_nres_get_cw_measurement(clk_cw_t cw);

//******************************************************************************
// STATUS
//******************************************************************************

/* ############################################################################ */
/**
 * \brief   Function to get clock partition status
 *
 * \ingroup clk_nres
 *
 * \param sel Select CLK_NRES instance
 *
 * \param nr Number of the clock domain/partition
 *
 * \return      Status of clk partition <br>
 *              1: corresponding clock domain/partition is switched on
 */
uint16_t clk_nres_get_clk_status(clk_nres_num_t sel, uint8_t nr);

/* ############################################################################ */
/**
 * \brief   Function to get clock partition status
 *
 * \ingroup clk_nres
 *
 * \param sel Select CLK_NRES instance
 *
 * \return      Status of clk partition <br>
 *              1: corresponding clock domain/partition is switched on
 */
uint8_t  clk_nres_get_clk_status_as(clk_nres_num_t sel);

//******************************************************************************
// IRQ
//******************************************************************************

/* ############################################################################ */
/**
 * \brief   Function to set Interrupt Request (IRQ) mask
 *
 * \ingroup clk_nres
 *
 * \param irq Interrupt number
 *
 * \param enable 1: Enable
 *
 */
void clk_nres_set_irq_mask(clk_nres_irq_t irq, bool enable);
  
/* ############################################################################ */
/**
 * \brief   Function to enable Interrupt Request (IRQ)
 *
 * \ingroup clk_nres
 *
 * \param irq Interrupt number
 *
 * \param enable 1: Enable
 *
 */
void clk_nres_enable_irq(clk_nres_irq_t irq, bool enable);

/* ############################################################################ */
/**
 * \brief   Function to get Interrupt Request (IRQ) status
 *
 * \ingroup clk_nres
 *
 * \return Value of current IRQ status
 * 
 */
clk_nres_irq_status_t clk_nres_get_irq_status(void);

/* ############################################################################ */
/**
 * \brief   Function to clear all Interrupt Request (IRQ)
 *
 * \ingroup clk_nres
 *
 */
void clk_nres_clear_all_irq_events(void);

/* ############################################################################ */
/**
 * \brief   Function to get pending Interrupt Request (IRQ)
 *
 * \ingroup clk_nres
 *
 * \return Value of current pending interrupts
 * 
 */
clk_nres_irq_t clk_nres_get_pending_irq(void);

/* ############################################################################ */
/**
 * \brief   Function to set vector number of interrupt to enable
 *
 * \ingroup clk_nres
 *
 * \param vno Vector number of interrupt to enable
 *
 */
void clk_nres_set_irq_vno(clk_nres_irq_t vno);

/**@} */
#endif /* __CLK_NRES_H__ */



