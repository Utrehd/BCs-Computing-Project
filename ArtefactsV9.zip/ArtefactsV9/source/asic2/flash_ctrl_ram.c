/* FPGA Release: 10512 */
#include "device.h"
#include "hardware.h"
#include "flash_ctrl.h"
#include "flash_ctrl_bf.h"
#ifdef __IAR_SYSTEMS_ICC__
#include "string.h"
#endif

/* ############################################################################ */
__ramfunc static bool flash_ctrl_set_mode(flash_ctrl_num_t flash_ctrl, flash_mode_t mode) {
    uint16_t tmp;

    WRITE_REG_16(flash_ctrl + ADDR_FLASH_CTRL_MODE, 0xA500 | (mode & 0x00FF));
    tmp = READ_REG_U16(flash_ctrl + ADDR_FLASH_CTRL_MODE);
    if (tmp != (0x9600 | (mode & 0x00FF))) {
        return false;
    }
    return true;
}

/* ############################################################################ */
__ramfunc static bool flash_ctrl_is_busy(flash_ctrl_num_t flash_ctrl) {
  return (bool)((READ_REG_U16(flash_ctrl + ADDR_FLASH_CTRL_STATUS) & BIT_FLASH_CTRL_STATUS_BUSY) != 0);
}

/* ############################################################################ */
__ramfunc static bool flash_ctrl_is_write_error(flash_ctrl_num_t flash_ctrl) {
  return (bool)((READ_REG_U16(flash_ctrl + ADDR_FLASH_CTRL_STATUS) & BIT_FLASH_CTRL_STATUS_WRITE_ERROR) != 0);
}

/* ############################################################################ */
__ramfunc static bool flash_row_prog_private(uint32_t row_base_addr, uint32_t *row_data) {
  uint8_t dword_cnt;
  for (dword_cnt = 0; dword_cnt < 32; dword_cnt++) {
    if (!flash_dword_prog(row_base_addr, row_data[dword_cnt]))
      return false;
    row_base_addr += 4;
  }
  return true;
}

/* ############################################################################ */
__ramfunc static void flash_ctrl_decode_addr_private(uint32_t flash_addr, flash_select_t * flash_select){
  if (flash_addr >= BASE_ADDR_FLASH1_INFO){
    flash_select->flash_ctrl_num  = FLASH_CTRL1;
    flash_select->flash_block     = FLASH_INFO;
    flash_select->flash_base_addr = BASE_ADDR_FLASH1_INFO;
    flash_select->flash_page      = 0xF0 + ((flash_addr - flash_select->flash_base_addr) >> FLASH_CTRL_LSB_PAGES);
  } else if (flash_addr >= BASE_ADDR_FLASH0_INFO){
    flash_select->flash_ctrl_num  = FLASH_CTRL0;
    flash_select->flash_block     = FLASH_INFO;
    flash_select->flash_base_addr = BASE_ADDR_FLASH0_INFO;
    flash_select->flash_page      = 0xF0 + ((flash_addr - flash_select->flash_base_addr) >> FLASH_CTRL_LSB_PAGES);
  } else if (flash_addr >= BASE_ADDR_FLASH1){
    flash_select->flash_ctrl_num  = FLASH_CTRL1;
    flash_select->flash_block     = FLASH_MAIN;
    flash_select->flash_base_addr = BASE_ADDR_FLASH1;
    flash_select->flash_page      = (flash_addr - flash_select->flash_base_addr) >> FLASH_CTRL_LSB_PAGES;
  } else {// flash_addr BASE_ADDR_FLASH0
    flash_select->flash_ctrl_num  = FLASH_CTRL0;
    flash_select->flash_block     = FLASH_MAIN;
    flash_select->flash_base_addr = BASE_ADDR_FLASH0;
    flash_select->flash_page      = (flash_addr - flash_select->flash_base_addr) >> FLASH_CTRL_LSB_PAGES;
  }    
}

/* ############################################################################ */
__ramfunc static bool flash_dword_prog_private(uint32_t word_addr, uint32_t data) {
  flash_select_t flash_select;
  flash_ctrl_decode_addr(word_addr, &flash_select);
  flash_ctrl_is_write_error(flash_select.flash_ctrl_num); // clear write error with read access
  if (flash_select.flash_block == FLASH_MAIN) {
    if (!flash_ctrl_set_mode(flash_select.flash_ctrl_num, FLASH_MAIN_WRITE)) return false;
  } else if (flash_select.flash_block == FLASH_INFO) {
    if (!flash_ctrl_set_mode(flash_select.flash_ctrl_num, FLASH_INFO_WRITE)) return false;
  } else {
    return false;
  }
  word_addr &= 0xFFFFFFFCU;
  WRITE_REG_32(word_addr, data);
  if (flash_ctrl_is_write_error(flash_select.flash_ctrl_num)){                         // check error flag
    while(!flash_ctrl_set_mode(flash_select.flash_ctrl_num, FLASH_READ));  // hold if guard is dead 
    return false;
  }
  while (flash_ctrl_is_busy(flash_select.flash_ctrl_num));
  while(!flash_ctrl_set_mode(flash_select.flash_ctrl_num, FLASH_READ));  // hold if guard is dead 
  return true;
}

/* ############################################################################ */
__ramfunc static bool flash_page_erase_private(uint32_t page_base_addr) {
  flash_select_t flash_select;
  flash_ctrl_decode_addr(page_base_addr, &flash_select);
  flash_ctrl_is_write_error(flash_select.flash_ctrl_num); // clear write error with read access
  if (flash_select.flash_block == FLASH_MAIN) {
      if (!flash_ctrl_set_mode(flash_select.flash_ctrl_num, FLASH_MAIN_ERASE)) return false;
  } else if (flash_select.flash_block == FLASH_INFO) {
      if (!flash_ctrl_set_mode(flash_select.flash_ctrl_num, FLASH_INFO_ERASE)) return false;
  } else {
      return false;
  }
  page_base_addr &= 0xFFFFFE00U;
  volatile uint32_t* ptr = (volatile uint32_t*)(page_base_addr);
  *ptr = 0;
  do{
    if (flash_ctrl_is_write_error(flash_select.flash_ctrl_num)){
      while(!flash_ctrl_set_mode(flash_select.flash_ctrl_num, FLASH_READ));  // hold if guard is dead 
      return false;
    }
  } while (flash_ctrl_is_busy(flash_select.flash_ctrl_num));
  while(!flash_ctrl_set_mode(flash_select.flash_ctrl_num, FLASH_READ));  // hold if guard is dead 
  return true;
}

/* ############################################################################ */
__ramfunc static bool flash_mass_erase_private(flash_num_t flash, flash_block_t block) {
  flash_ctrl_num_t flash_ctrl;
  if (flash == FLASH0)  flash_ctrl = FLASH_CTRL0;
  else                  flash_ctrl = FLASH_CTRL1;
  flash_ctrl_is_write_error(flash_ctrl);
  if (block == FLASH_MAIN) {
    // perform mass erase of main area
    if (!flash_ctrl_set_mode(flash_ctrl, FLASH_MAIN_MASS_ERASE)) return false;
  } else {
    return false;
  }
  volatile uint32_t* ptr = (volatile uint32_t*)(flash);
  *ptr = 0;
  do{
    if (flash_ctrl_is_write_error(flash_ctrl)){
      while(!flash_ctrl_set_mode(flash_ctrl, FLASH_READ));  // hold if guard is dead 
      return false;
    }
  } while (flash_ctrl_is_busy(flash_ctrl));
  while(!flash_ctrl_set_mode(flash_ctrl, FLASH_READ));  // hold if guard is dead 
  
  return true;
}


/* ############################################################################ */
/* ############################################################################ */
/* ############################################################################ */
/* 
 * Following functions are wrappers for normal function
 * during running FLASH operation, no other access is allowed -> disable irq
 *
 */

/* ############################################################################ */
bool flash_row_prog(uint32_t row_base_addr, uint32_t *row_data)
{
  __disable_irq();
  return(flash_row_prog_private(row_base_addr, row_data));
  __enable_irq();
}

/* ############################################################################ */
void flash_ctrl_decode_addr(uint32_t flash_addr, flash_select_t * flash_select)
{
  __disable_irq();
  flash_ctrl_decode_addr_private(flash_addr, flash_select);
  __enable_irq();
}

/* ############################################################################ */
bool flash_dword_prog(uint32_t word_addr, uint32_t data)
{
  __disable_irq();
  return(flash_dword_prog_private(word_addr, data));
  __enable_irq();
}

/* ############################################################################ */
bool flash_page_erase(uint32_t page_base_addr) 
{
  __disable_irq();
  return(flash_page_erase_private(page_base_addr));
  __enable_irq();
}

/* ############################################################################ */
bool flash_mass_erase(flash_num_t flash, flash_block_t block) 
{
  __disable_irq();
  return(flash_mass_erase_private(flash, block));
  __enable_irq();
}