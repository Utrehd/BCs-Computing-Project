/* FPGA Release: 10512 */
#include "analog_ctrl_fll.h"

void analog_ctrl_fll_set_config(analog_ctrl_fll_config_t config){
  WRITE_REG_16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_CONFIG, config.val);
}

analog_ctrl_fll_config_t analog_ctrl_fll_get_config(void){
  analog_ctrl_fll_config_t ret;
  ret.val = READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_CONFIG);
  return ret;
}

void analog_ctrl_fll_set_eval_rate(uint8_t eval_rate){
  analog_ctrl_fll_config_t config;
  config.val = READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_CONFIG);
  config.bf.eval_rate = eval_rate;
  WRITE_REG_16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_CONFIG, config.val);
}

void analog_ctrl_fll_set_freeze(bool freeze){
  analog_ctrl_fll_config_t config;
  config.val = READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_CONFIG);
  config.bf.freeze = freeze;
  WRITE_REG_16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_CONFIG, config.val);
}

uint16_t analog_ctrl_fll_get_eval_val(void){
  return READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_EVAL_VAL);
}

void analog_ctrl_fll_set_val(uint16_t val){
  WRITE_REG_16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SET_VAL, val);
}

uint16_t analog_ctrl_fll_get_val(void){
  return READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SET_VAL);
}

void analog_ctrl_fll_set_range(uint16_t val){
  WRITE_REG_16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SET_RANGE, val);
}

uint16_t analog_ctrl_fll_get_range(void){
  return READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SET_RANGE);
}

void analog_ctrl_fll_set_sw_ctrl(analog_ctrl_fll_sw_ctrl_t sw_ctrl){
  WRITE_REG_16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SW_CTRL, sw_ctrl.val);
}

analog_ctrl_fll_sw_ctrl_t analog_ctrl_fll_get_sw_ctrl(void){
  analog_ctrl_fll_sw_ctrl_t ret;
  ret.val = READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SW_CTRL);
  return ret;  
}

void analog_ctrl_fll_set_use_sw(bool use_sw){
  analog_ctrl_fll_sw_ctrl_t sw_ctrl;
  sw_ctrl.val = READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SW_CTRL);
  sw_ctrl.bf.use_sw = use_sw;
  WRITE_REG_16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_SW_CTRL, sw_ctrl.val);
}

uint8_t analog_ctrl_fll_get_trim_val(void){
  return (uint8_t) READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_TRIM_VAL);
}

analog_ctrl_fll_status_t analog_ctrl_fll_get_status(void){
  analog_ctrl_fll_status_t ret;
  ret.val = READ_REG_U16(BASE_ADDR_ANALOG_CTRL + ADDR_ANALOG_CTRL_FLL_STATUS);
  return ret;  
}

bool analog_ctrl_fll_is_locked(void){
  analog_ctrl_fll_status_t analog_ctrl_fll_status = analog_ctrl_fll_get_status();
  if (!analog_ctrl_fll_status.val)
    return true;
  return false;
}

