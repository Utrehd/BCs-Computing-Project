/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         gpio_api_errors.h
*
* @brief        Error handler for GPIO API functions
*
* @author       Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

/**
 * \ingroup error_api
 */

#ifndef __GPIO_API_ERRORS__
#define __GPIO_API_ERRORS__

#define GPIO_API_ERRORS_CODES                                                  \
  /**                                                                          \
   * Incorrect level. It should be eLow or eHigh                               \
   */                                                                          \
  eError_gpio_api_incorrect_level,                                             \
                                                                               \
  /**                                                                          \
   * Incorrect configuration. It should be eInput or eOutput                   \ 
   */                                                                          \
  eError_gpio_api_incorrect_conf,                                              \
                                                                               \
  /**                                                                          \
   *Incorrect time. It should be eSeconds, eMili_seconds,                      \
   * eMicro_seconds, eNano_seconds or ePico_seconds                            \
   */                                                                          \
  eError_gpio_api_incorrect_time,                                              \
  /**                                                                          \
   *Incorrect configuration. The filter is not enabled                         \
   */                                                                          \
  eError_gpio_api_no_filter_enabled,                                           \
  /**                                                                          \
   *The selected pin does not have interrupt capability                        \
   */                                                                          \
  eError_gpio_api_pin_no_int,                                                  \
    /**                                                                        \
   *The filter cannot handle a defined period bigger than uint16               \
   */                                                                          \
  eError_gpio_api_filter_cfg_period_does_not_fit_uint,                         \
  /**                                                                          \
   *The GPIO cannot be 0                                                       \
   */                                                                          \
  eError_gpio_api_pin_cannot_write_zero                                        \
    
#endif
