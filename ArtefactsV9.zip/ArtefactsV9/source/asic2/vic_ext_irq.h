/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         vic_ext_irq.h
*
* @brief        External Processor Interrupt Controller (VIC_EXT) HAL functions
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/
#ifndef __VIC_EXT_IRQ_H__
#define __VIC_EXT_IRQ_H__

#define VIC_EXT_NUM_IRQS 22

/**
  * \brief This is an enum class for VIC_EXT describing IRQ events
  *
  * \ingroup vic_ext
  */ 
typedef enum{
  VIC_EXT_IRQ_IRQ_CLK_NRES_0 =          0, ///< CLK_NRES_0 interrupt source
  VIC_EXT_IRQ_IRQ_SWTIMER0 =            1, ///< SWTIMER0 interrupt source
  VIC_EXT_IRQ_IRQ_TSU =                 2, ///< TSU interrupt source
  VIC_EXT_IRQ_IRQ_SWD =                 3, ///< SWD interrupt source
  VIC_EXT_IRQ_IRQ_HV_CTRL =             4, ///< HV_CTRL interrupt source
  VIC_EXT_IRQ_IRQ_CPU_N_CPU_0 =         5, ///< CPU_N_CPU_0 interrupt source
  VIC_EXT_IRQ_IRQ_EL_CTRL =             6, ///< EL_CTRL interrupt source
  VIC_EXT_IRQ_IRQ_SWTIMER1 =            7, ///< SWTIMER1 interrupt source
  VIC_EXT_IRQ_IRQ_HISPI =               8, ///< HISPI interrupt source
  VIC_EXT_IRQ_IRQ_UART =                9, ///< UART interrupt source
  VIC_EXT_IRQ_IRQ_CRC0 =                10, ///< CRC0 interrupt source
  VIC_EXT_IRQ_IRQ_CRC1 =                11, ///< CRC1 interrupt source
  VIC_EXT_IRQ_IRQ_GPIO =                12, ///< GPIO interrupt source ///< CLK_NRES_0 interrupt source
  VIC_EXT_IRQ_IRQ_SARADC_CTRL =         13, ///< SARADC_CTRL interrupt source
  VIC_EXT_IRQ_IRQ_CPU_N_CPU_1 =         14, ///< CPU_N_CPU_1 interrupt source
  VIC_EXT_IRQ_IRQ_PWMN =                15, ///< PWMN interrupt source
  VIC_EXT_IRQ_IRQ_CCTIMER0 =            16, ///< CCTIMER0 interrupt source
  VIC_EXT_IRQ_IRQ_CCTIMER1 =            17, ///< CCTIMER1 interrupt source
  VIC_EXT_IRQ_IRQ_USI0 =                18, ///< USI0 interrupt source
  VIC_EXT_IRQ_IRQ_USI1 =                19, ///< USI1 interrupt source
  VIC_EXT_IRQ_IRQ_I2C =                 20, ///< I2C interrupt source
  VIC_EXT_IRQ_IRQ_CPU_N_CPU_EXT =       21 ///< CPU_N_CPU_EXT interrupt source
} vic_ext_irq_t;

#endif
