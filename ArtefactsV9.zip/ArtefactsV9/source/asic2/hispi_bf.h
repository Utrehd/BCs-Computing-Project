/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hispi_bf.h
*
* @brief        SPI Host interface HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HISPI_BF_H__
#define __HISPI_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_HISPI
#define BASE_ADDR_HISPI 0x40006880U
#endif

#define NUMBER_HISPI 1


/* ############################################################################ */
/**
 * \brief This is an enum class for HISPI instance
 *
 * \ingroup hispi 
 */ 
typedef enum {
  /**
   * This is instance HISPI
   */ 
  HISPI                          = (int)BASE_ADDR_HISPI
} hispi_num_t;

// Register bit field definitions

/* HISPI_CONFIG */

#define MSK_HISPI_CONFIG_ENABLE                             (0x1)     /* [0] */
#define RES_HISPI_CONFIG_ENABLE                             (0x0)
#define SFT_HISPI_CONFIG_ENABLE                             (0)
#define LSB_HISPI_CONFIG_ENABLE                             (0)
#define MSB_HISPI_CONFIG_ENABLE                             (0)
#define BIT_HISPI_CONFIG_ENABLE                             (0x1)     /* [0] */
#define MSK_HISPI_CONFIG_INV_NSS                            (0x1)     /* [1] */
#define RES_HISPI_CONFIG_INV_NSS                            (0x0)
#define SFT_HISPI_CONFIG_INV_NSS                            (1)
#define LSB_HISPI_CONFIG_INV_NSS                            (1)
#define MSB_HISPI_CONFIG_INV_NSS                            (1)
#define BIT_HISPI_CONFIG_INV_NSS                            (0x2)     /* [1] */
#define MSK_HISPI_CONFIG_CPOL                               (0x1)     /* [2] */
#define RES_HISPI_CONFIG_CPOL                               (0x0)
#define SFT_HISPI_CONFIG_CPOL                               (2)
#define LSB_HISPI_CONFIG_CPOL                               (2)
#define MSB_HISPI_CONFIG_CPOL                               (2)
#define BIT_HISPI_CONFIG_CPOL                               (0x4)     /* [2] */
#define MSK_HISPI_CONFIG_NCPHA                              (0x1)     /* [3] */
#define RES_HISPI_CONFIG_NCPHA                              (0x0)
#define SFT_HISPI_CONFIG_NCPHA                              (3)
#define LSB_HISPI_CONFIG_NCPHA                              (3)
#define MSB_HISPI_CONFIG_NCPHA                              (3)
#define BIT_HISPI_CONFIG_NCPHA                              (0x8)     /* [3] */
#define MSK_HISPI_CONFIG_MSB_NLSB_FIRST                     (0x1)     /* [4] */
#define RES_HISPI_CONFIG_MSB_NLSB_FIRST                     (0x0)
#define SFT_HISPI_CONFIG_MSB_NLSB_FIRST                     (4)
#define LSB_HISPI_CONFIG_MSB_NLSB_FIRST                     (4)
#define MSB_HISPI_CONFIG_MSB_NLSB_FIRST                     (4)
#define BIT_HISPI_CONFIG_MSB_NLSB_FIRST                     (0x10)    /* [4] */
#define MSK_HISPI_CONFIG_TIMEOUT                            (0x1)     /* [5] */
#define RES_HISPI_CONFIG_TIMEOUT                            (0x0)
#define SFT_HISPI_CONFIG_TIMEOUT                            (5)
#define LSB_HISPI_CONFIG_TIMEOUT                            (5)
#define MSB_HISPI_CONFIG_TIMEOUT                            (5)
#define BIT_HISPI_CONFIG_TIMEOUT                            (0x20)    /* [5] */
#define MSK_HISPI_CONFIG_MISO_HIZ                           (0x1)     /* [6] */
#define RES_HISPI_CONFIG_MISO_HIZ                           (0x0)
#define SFT_HISPI_CONFIG_MISO_HIZ                           (6)
#define LSB_HISPI_CONFIG_MISO_HIZ                           (6)
#define MSB_HISPI_CONFIG_MISO_HIZ                           (6)
#define BIT_HISPI_CONFIG_MISO_HIZ                           (0x40)    /* [6] */
#define MSK_HISPI_CONFIG_EARLY_MISO                         (0x1)     /* [7] */
#define RES_HISPI_CONFIG_EARLY_MISO                         (0x0)
#define SFT_HISPI_CONFIG_EARLY_MISO                         (7)
#define LSB_HISPI_CONFIG_EARLY_MISO                         (7)
#define MSB_HISPI_CONFIG_EARLY_MISO                         (7)
#define BIT_HISPI_CONFIG_EARLY_MISO                         (0x80)    /* [7] */
#define MSK_HISPI_CONFIG_EARLY_MISO_PHASE                   (0x3f)    /* [15:10] */
#define RES_HISPI_CONFIG_EARLY_MISO_PHASE                   (0x00)
#define SFT_HISPI_CONFIG_EARLY_MISO_PHASE                   (10)
#define LSB_HISPI_CONFIG_EARLY_MISO_PHASE                   (10)
#define MSB_HISPI_CONFIG_EARLY_MISO_PHASE                   (15)


/* ############################################################################ */
/**
 * \brief This structure describes HISPI configuration
 *
 * \ingroup hispi 
 */ 
typedef struct {
  /**
   * 1: enable SPI Hostinterface
   */ 
  unsigned short enable                        :    1;       /* [0] */
  /**
   * Invert nss (1: nss is high active, 0: nss is low active)
   */ 
  unsigned short inv_nss                       :    1;       /* [1] */
  /**
   * Clock polarity (see timing diagram)
   */ 
  unsigned short cpol                          :    1;       /* [2] */
  /**
   * Clock phase (see timing diagram)
   */ 
  unsigned short ncpha                         :    1;       /* [3] */
  /**
   * 1: MSB first <br>
   * 0: LSB first
   */ 
  unsigned short msb_nlsb_first                :    1;       /* [4] */
  /**
   * 1: timeout mode enabled <br>
   * 0: cs controlled
   */ 
  unsigned short timeout                       :    1;       /* [5] */
  /**
   * 1: miso will be only driven when cs is active and not using timeout <br>
   * 0: miso oe is only depending on mode
   */ 
  unsigned short miso_hiz                      :    1;       /* [6] */
  /**
   * 1: early miso output (after edge before) is enabled, this allows hispi to speed up to 1 / 4 of comm_clk, otherwise the speed of read transfer is limited to 1 / 8 of comm_clk
   */ 
  unsigned short early_miso                    :    1;       /* [7] */
  /**
   * reserved
   */ 
  unsigned short reserved9                     :    2;       /* [ 9:8] */
  /**
   * Phase offset for miso data in number of comm clock cycles valid only when early miso is enabled
   */ 
  unsigned short early_miso_phase              :    6;       /* [15:10] */
} hispi_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HISPI configuration
 *
 * \ingroup hispi 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hispi_config_bf bf;  ///< bit field representation
} hispi_config_t;


/* HISPI_TIMEOUT */

#define MSK_HISPI_TIMEOUT                                   (0xffff)  /* [15:0] */

typedef unsigned short hispi_timeout_t;                               /* [15:0] */


/* HISPI_TRF_ADDR */

#define MSK_HISPI_TRF_ADDR_NRW                              (0x1)     /* [0] */
#define RES_HISPI_TRF_ADDR_NRW                              (0x0)
#define SFT_HISPI_TRF_ADDR_NRW                              (0)
#define LSB_HISPI_TRF_ADDR_NRW                              (0)
#define MSB_HISPI_TRF_ADDR_NRW                              (0)
#define BIT_HISPI_TRF_ADDR_NRW                              (0x1)     /* [0] */
#define MSK_HISPI_TRF_ADDR_ADDR                             (0x7fff)  /* [15:1] */
#define RES_HISPI_TRF_ADDR_ADDR                             (0x0000)
#define SFT_HISPI_TRF_ADDR_ADDR                             (1)
#define LSB_HISPI_TRF_ADDR_ADDR                             (1)
#define MSB_HISPI_TRF_ADDR_ADDR                             (15)


/* ############################################################################ */
/**
 * \brief This structure describes HISPI transfer address
 *
 * \ingroup hispi 
 */ 
typedef struct {
  /**
   * Direction of last transfer: <br>
   * 0:read <br>
   * 1:write
   */ 
  unsigned short nrw                           :    1;       /* [0] */
  /**
   * Start ADDRESS of last transfer as sent by the host
   */ 
  unsigned short addr                          :   15;       /* [15:1] */
} hispi_trf_addr_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HISPI transfer address
 *
 * \ingroup hispi 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hispi_trf_addr_bf bf;  ///< bit field representation
} hispi_trf_addr_t;


/* HISPI_TRF_CONTROL */

#define MSK_HISPI_TRF_CONTROL                               (0x3ff)   /* [ 9:0] */

typedef unsigned short hispi_trf_control_t;                           /* [ 9:0] */


/* HISPI_TRF_DLEN */

#define MSK_HISPI_TRF_DLEN                                  (0x3ff)   /* [ 9:0] */

typedef unsigned short hispi_trf_dlen_t;                              /* [ 9:0] */


/* HISPI_PROT */

#define MSK_HISPI_PROT                                      (0xffff)  /* [15:0] */

typedef unsigned short hispi_prot_t;                                  /* [15:0] */


/* HISPI_IRQ_STATUS */

#define MSK_HISPI_IRQ_STATUS_EVT_TRF_DONE                   (0x1)     /* [0] */
#define RES_HISPI_IRQ_STATUS_EVT_TRF_DONE                   (0x0)
#define SFT_HISPI_IRQ_STATUS_EVT_TRF_DONE                   (0)
#define LSB_HISPI_IRQ_STATUS_EVT_TRF_DONE                   (0)
#define MSB_HISPI_IRQ_STATUS_EVT_TRF_DONE                   (0)
#define BIT_HISPI_IRQ_STATUS_EVT_TRF_DONE                   (0x1)     /* [0] */
#define MSK_HISPI_IRQ_STATUS_EVT_ACCESS_ERR                 (0x1)     /* [1] */
#define RES_HISPI_IRQ_STATUS_EVT_ACCESS_ERR                 (0x0)
#define SFT_HISPI_IRQ_STATUS_EVT_ACCESS_ERR                 (1)
#define LSB_HISPI_IRQ_STATUS_EVT_ACCESS_ERR                 (1)
#define MSB_HISPI_IRQ_STATUS_EVT_ACCESS_ERR                 (1)
#define BIT_HISPI_IRQ_STATUS_EVT_ACCESS_ERR                 (0x2)     /* [1] */
#define MSK_HISPI_IRQ_STATUS_EVT_SPI_ERR                    (0x1)     /* [2] */
#define RES_HISPI_IRQ_STATUS_EVT_SPI_ERR                    (0x0)
#define SFT_HISPI_IRQ_STATUS_EVT_SPI_ERR                    (2)
#define LSB_HISPI_IRQ_STATUS_EVT_SPI_ERR                    (2)
#define MSB_HISPI_IRQ_STATUS_EVT_SPI_ERR                    (2)
#define BIT_HISPI_IRQ_STATUS_EVT_SPI_ERR                    (0x4)     /* [2] */
#define MSK_HISPI_IRQ_STATUS_EVT_LEN_ERR                    (0x1)     /* [3] */
#define RES_HISPI_IRQ_STATUS_EVT_LEN_ERR                    (0x0)
#define SFT_HISPI_IRQ_STATUS_EVT_LEN_ERR                    (3)
#define LSB_HISPI_IRQ_STATUS_EVT_LEN_ERR                    (3)
#define MSB_HISPI_IRQ_STATUS_EVT_LEN_ERR                    (3)
#define BIT_HISPI_IRQ_STATUS_EVT_LEN_ERR                    (0x8)     /* [3] */


/* ############################################################################ */
/**
 * \brief This structure describes HISPI Interrupt status
 *
 * \ingroup hispi 
 */ 
typedef struct {
  /**
   * End of incoming transfer
   */ 
  unsigned short evt_trf_done                  :    1;       /* [0] */
  /**
   * Set when an address outside the defined windows is accessed
   */ 
  unsigned short evt_access_err                :    1;       /* [1] */
  /**
   * Set on SPI errors (e.g. word was interrupted by cs)
   */ 
  unsigned short evt_spi_err                   :    1;       /* [2] */
  /**
   * Set when the number of data words in a read transfer is not equal the length given in the control field
   */ 
  unsigned short evt_len_err                   :    1;       /* [3] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :   12;
} hispi_irq_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HISPI Interrupt status
 *
 * \ingroup hispi 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hispi_irq_status_bf bf;  ///< bit field representation
} hispi_irq_status_t;


/* HISPI_IRQ_MASK */

#define MSK_HISPI_IRQ_MASK                                  (0xf)     /* [ 3:0] */

typedef unsigned short hispi_irq_mask_t;                              /* [ 3:0] */


/* HISPI_IRQ_VENABLE */

#define MSK_HISPI_IRQ_VENABLE                               (0x3)     /* [ 1:0] */

typedef unsigned short hispi_irq_venable_t;                           /* [ 1:0] */


/* HISPI_IRQ_VDISABLE */

#define MSK_HISPI_IRQ_VDISABLE                              (0x3)     /* [ 1:0] */

typedef unsigned short hispi_irq_vdisable_t;                          /* [ 1:0] */


/* HISPI_IRQ_VMAX */

#define MSK_HISPI_IRQ_VMAX                                  (0x7)     /* [ 2:0] */

typedef unsigned short hispi_irq_vmax_t;                              /* [ 2:0] */


/* HISPI_IRQ_VNO */

#define MSK_HISPI_IRQ_VNO                                   (0x7)     /* [ 2:0] */

typedef unsigned short hispi_irq_vno_t;                               /* [ 2:0] */



// Register definitions for module
// Instance base address BASE_ADDR_HISPI 0x40006880U ... 

#define ADDR_HISPI_CONFIG                                    (0x00U)
#define A_HISPI_CONFIG(ba)                                   ((ba) + ADDR_HISPI_CONFIG)
#define R_HISPI_CONFIG(ba)                                   (*(volatile unsigned short *)((unsigned int)A_HISPI_CONFIG(ba)))
#define RES_HISPI_CONFIG                                     (0x0U)
#define MSB_HISPI_CONFIG                                     15
#define LSB_HISPI_CONFIG                                     0
#define AADDR_HISPI_CONFIG                                   (BASE_ADDR_HISPI + ADDR_HISPI_CONFIG)
#define REG_HISPI_CONFIG                                     (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_CONFIG))

#define ADDR_HISPI_TIMEOUT                                   (0x02U)
#define A_HISPI_TIMEOUT(ba)                                  ((ba) + ADDR_HISPI_TIMEOUT)
#define R_HISPI_TIMEOUT(ba)                                  (*(volatile unsigned short *)((unsigned int)A_HISPI_TIMEOUT(ba)))
#define RES_HISPI_TIMEOUT                                    (0x0U)
#define MSB_HISPI_TIMEOUT                                    15
#define LSB_HISPI_TIMEOUT                                    0
#define AADDR_HISPI_TIMEOUT                                  (BASE_ADDR_HISPI + ADDR_HISPI_TIMEOUT)
#define REG_HISPI_TIMEOUT                                    (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_TIMEOUT))

#define ADDR_HISPI_TRF_ADDR                                  (0x04U)
#define A_HISPI_TRF_ADDR(ba)                                 ((ba) + ADDR_HISPI_TRF_ADDR)
#define R_HISPI_TRF_ADDR(ba)                                 (*(volatile unsigned short *)((unsigned int)A_HISPI_TRF_ADDR(ba)))
#define RES_HISPI_TRF_ADDR                                   (0x0U)
#define MSB_HISPI_TRF_ADDR                                   15
#define LSB_HISPI_TRF_ADDR                                   0
#define AADDR_HISPI_TRF_ADDR                                 (BASE_ADDR_HISPI + ADDR_HISPI_TRF_ADDR)
#define REG_HISPI_TRF_ADDR                                   (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_TRF_ADDR))

#define ADDR_HISPI_TRF_CONTROL                               (0x06U)
#define A_HISPI_TRF_CONTROL(ba)                              ((ba) + ADDR_HISPI_TRF_CONTROL)
#define R_HISPI_TRF_CONTROL(ba)                              (*(volatile unsigned short *)((unsigned int)A_HISPI_TRF_CONTROL(ba)))
#define RES_HISPI_TRF_CONTROL                                (0x0U)
#define MSB_HISPI_TRF_CONTROL                                9
#define LSB_HISPI_TRF_CONTROL                                0
#define AADDR_HISPI_TRF_CONTROL                              (BASE_ADDR_HISPI + ADDR_HISPI_TRF_CONTROL)
#define REG_HISPI_TRF_CONTROL                                (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_TRF_CONTROL))

#define ADDR_HISPI_TRF_DLEN                                  (0x08U)
#define A_HISPI_TRF_DLEN(ba)                                 ((ba) + ADDR_HISPI_TRF_DLEN)
#define R_HISPI_TRF_DLEN(ba)                                 (*(volatile unsigned short *)((unsigned int)A_HISPI_TRF_DLEN(ba)))
#define RES_HISPI_TRF_DLEN                                   (0x0U)
#define MSB_HISPI_TRF_DLEN                                   9
#define LSB_HISPI_TRF_DLEN                                   0
#define AADDR_HISPI_TRF_DLEN                                 (BASE_ADDR_HISPI + ADDR_HISPI_TRF_DLEN)
#define REG_HISPI_TRF_DLEN                                   (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_TRF_DLEN))

#define ADDR_HISPI_PROT0_UPPER                               (0x0AU)
#define A_HISPI_PROT0_UPPER(ba)                              ((ba) + ADDR_HISPI_PROT0_UPPER)
#define R_HISPI_PROT0_UPPER(ba)                              (*(volatile unsigned short *)((unsigned int)A_HISPI_PROT0_UPPER(ba)))
#define RES_HISPI_PROT0_UPPER                                (0xffU)
#define MSB_HISPI_PROT0_UPPER                                15
#define LSB_HISPI_PROT0_UPPER                                0
#define AADDR_HISPI_PROT0_UPPER                              (BASE_ADDR_HISPI + ADDR_HISPI_PROT0_UPPER)
#define REG_HISPI_PROT0_UPPER                                (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_PROT0_UPPER))

#define ADDR_HISPI_PROT0_LOWER                               (0x0CU)
#define A_HISPI_PROT0_LOWER(ba)                              ((ba) + ADDR_HISPI_PROT0_LOWER)
#define R_HISPI_PROT0_LOWER(ba)                              (*(volatile unsigned short *)((unsigned int)A_HISPI_PROT0_LOWER(ba)))
#define RES_HISPI_PROT0_LOWER                                (0xffU)
#define MSB_HISPI_PROT0_LOWER                                15
#define LSB_HISPI_PROT0_LOWER                                0
#define AADDR_HISPI_PROT0_LOWER                              (BASE_ADDR_HISPI + ADDR_HISPI_PROT0_LOWER)
#define REG_HISPI_PROT0_LOWER                                (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_PROT0_LOWER))

#define ADDR_HISPI_PROT1_UPPER                               (0x0EU)
#define A_HISPI_PROT1_UPPER(ba)                              ((ba) + ADDR_HISPI_PROT1_UPPER)
#define R_HISPI_PROT1_UPPER(ba)                              (*(volatile unsigned short *)((unsigned int)A_HISPI_PROT1_UPPER(ba)))
#define RES_HISPI_PROT1_UPPER                                (0xffU)
#define MSB_HISPI_PROT1_UPPER                                15
#define LSB_HISPI_PROT1_UPPER                                0
#define AADDR_HISPI_PROT1_UPPER                              (BASE_ADDR_HISPI + ADDR_HISPI_PROT1_UPPER)
#define REG_HISPI_PROT1_UPPER                                (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_PROT1_UPPER))

#define ADDR_HISPI_PROT1_LOWER                               (0x10U)
#define A_HISPI_PROT1_LOWER(ba)                              ((ba) + ADDR_HISPI_PROT1_LOWER)
#define R_HISPI_PROT1_LOWER(ba)                              (*(volatile unsigned short *)((unsigned int)A_HISPI_PROT1_LOWER(ba)))
#define RES_HISPI_PROT1_LOWER                                (0xffU)
#define MSB_HISPI_PROT1_LOWER                                15
#define LSB_HISPI_PROT1_LOWER                                0
#define AADDR_HISPI_PROT1_LOWER                              (BASE_ADDR_HISPI + ADDR_HISPI_PROT1_LOWER)
#define REG_HISPI_PROT1_LOWER                                (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_PROT1_LOWER))

#define ADDR_HISPI_IRQ_STATUS                                (0x12U)
#define A_HISPI_IRQ_STATUS(ba)                               ((ba) + ADDR_HISPI_IRQ_STATUS)
#define R_HISPI_IRQ_STATUS(ba)                               (*(volatile unsigned short *)((unsigned int)A_HISPI_IRQ_STATUS(ba)))
#define RES_HISPI_IRQ_STATUS                                 (0x0U)
#define MSB_HISPI_IRQ_STATUS                                 3
#define LSB_HISPI_IRQ_STATUS                                 0
#define AADDR_HISPI_IRQ_STATUS                               (BASE_ADDR_HISPI + ADDR_HISPI_IRQ_STATUS)
#define REG_HISPI_IRQ_STATUS                                 (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_IRQ_STATUS))

#define ADDR_HISPI_IRQ_MASK                                  (0x16U)
#define A_HISPI_IRQ_MASK(ba)                                 ((ba) + ADDR_HISPI_IRQ_MASK)
#define R_HISPI_IRQ_MASK(ba)                                 (*(volatile unsigned short *)((unsigned int)A_HISPI_IRQ_MASK(ba)))
#define RES_HISPI_IRQ_MASK                                   (0x0U)
#define MSB_HISPI_IRQ_MASK                                   3
#define LSB_HISPI_IRQ_MASK                                   0
#define AADDR_HISPI_IRQ_MASK                                 (BASE_ADDR_HISPI + ADDR_HISPI_IRQ_MASK)
#define REG_HISPI_IRQ_MASK                                   (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_IRQ_MASK))

#define ADDR_HISPI_IRQ_VENABLE                               (0x1AU)
#define A_HISPI_IRQ_VENABLE(ba)                              ((ba) + ADDR_HISPI_IRQ_VENABLE)
#define R_HISPI_IRQ_VENABLE(ba)                              (*(volatile unsigned short *)((unsigned int)A_HISPI_IRQ_VENABLE(ba)))
#define RES_HISPI_IRQ_VENABLE                                (0x0U)
#define MSB_HISPI_IRQ_VENABLE                                1
#define LSB_HISPI_IRQ_VENABLE                                0
#define AADDR_HISPI_IRQ_VENABLE                              (BASE_ADDR_HISPI + ADDR_HISPI_IRQ_VENABLE)
#define REG_HISPI_IRQ_VENABLE                                (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_IRQ_VENABLE))

#define ADDR_HISPI_IRQ_VDISABLE                              (0x1CU)
#define A_HISPI_IRQ_VDISABLE(ba)                             ((ba) + ADDR_HISPI_IRQ_VDISABLE)
#define R_HISPI_IRQ_VDISABLE(ba)                             (*(volatile unsigned short *)((unsigned int)A_HISPI_IRQ_VDISABLE(ba)))
#define RES_HISPI_IRQ_VDISABLE                               (0x0U)
#define MSB_HISPI_IRQ_VDISABLE                               1
#define LSB_HISPI_IRQ_VDISABLE                               0
#define AADDR_HISPI_IRQ_VDISABLE                             (BASE_ADDR_HISPI + ADDR_HISPI_IRQ_VDISABLE)
#define REG_HISPI_IRQ_VDISABLE                               (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_IRQ_VDISABLE))

#define ADDR_HISPI_IRQ_VMAX                                  (0x1EU)
#define A_HISPI_IRQ_VMAX(ba)                                 ((ba) + ADDR_HISPI_IRQ_VMAX)
#define R_HISPI_IRQ_VMAX(ba)                                 (*(volatile unsigned short *)((unsigned int)A_HISPI_IRQ_VMAX(ba)))
#define RES_HISPI_IRQ_VMAX                                   (0x4U)
#define MSB_HISPI_IRQ_VMAX                                   2
#define LSB_HISPI_IRQ_VMAX                                   0
#define AADDR_HISPI_IRQ_VMAX                                 (BASE_ADDR_HISPI + ADDR_HISPI_IRQ_VMAX)
#define REG_HISPI_IRQ_VMAX                                   (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_IRQ_VMAX))

#define ADDR_HISPI_IRQ_VNO                                   (0x20U)
#define A_HISPI_IRQ_VNO(ba)                                  ((ba) + ADDR_HISPI_IRQ_VNO)
#define R_HISPI_IRQ_VNO(ba)                                  (*(volatile unsigned short *)((unsigned int)A_HISPI_IRQ_VNO(ba)))
#define RES_HISPI_IRQ_VNO                                    (0x4U)
#define MSB_HISPI_IRQ_VNO                                    2
#define LSB_HISPI_IRQ_VNO                                    0
#define AADDR_HISPI_IRQ_VNO                                  (BASE_ADDR_HISPI + ADDR_HISPI_IRQ_VNO)
#define REG_HISPI_IRQ_VNO                                    (*(volatile unsigned short *)((unsigned int)AADDR_HISPI_IRQ_VNO))




#endif
