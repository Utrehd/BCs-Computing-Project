/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         errors_api.h
*
* @brief        Error handler for API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __ERRORS_API__
#define __ERRORS_API__

#include "gpio_api_errors.h"
#include "clk_nres_api_errors.h"
#include "circular_buffer_api_errors.h"
#include "io_ctrl_api_errors.h"
#include "saradc_ctrl_api_errors.h"
#include "usi_uart_dma_api_errors.h"
#include "i2c_api_errors.h"
#include "el_ctrl_api_errors.h"

/**
 * \defgroup error_api Error handler API functions
 *
 * \ingroup  asic2_api
 * 
 * \brief    API Error handler - error types definitions and functions
 *
 */
/**@{*/ 

/* ############################################################################ */
/**
 * \brief Enumeration which describes the different types of errors
 *
 * \ingroup error_api 
 */
typedef enum {
  eError_none,                                 ///< No error
  eError_unknown,                              ///< Unknown error
  
  eError_mbox_timeout_exceed,                  ///< Timeout in swd_mailbox_acpu exceeded waiting for mailbox to be freed

  eError_systick_api_reload_value,             ///< Reload value impossible (systick_api)
  
  GPIO_API_ERRORS_CODES,                       ///< GPIO error codes (gpio_api_errors.h)
  
  CLK_NRES_API_ERRORS_CODES,                   ///< CLK_NRES error codes (clk_nres_api_errors.h)

  CIRCULAR_BUFFER_API_ERRORS_CODES,            ///< CIRCULAR BUFFER error codes (circular_buffer_api_errors.h)
  
  IO_CTRL_API_ERRORS_CODES,                    ///< IO_CTRL_API error codes (io_ctrl_api_errors.h)
  
  SARADC_CTRL_API_ERRORS_CODES,                ///< SARADC_CTRL_API error codes (saradc_ctrl_api_errors.h)
  
  USI_UART_DMA_API_ERRORS_CODES,               ///< USI_UART_DMA_API error codes (usi_uart_dma_api_errors.h)
  
  I2C_API_ERRORS_CODES,                        ///< IO_CTRL_API error codes (i2c_api_errors.h)

  EL_CTRL_API_ERRORS_CODES,                    ///< EL_CTRL_API error codes (el_ctrl_api_errors.h)

} errors_api_code_e;

/**@} */

#endif /* __ERRORS_API__ */ 
