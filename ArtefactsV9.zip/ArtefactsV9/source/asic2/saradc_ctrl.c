/* FPGA Release: 10512 */
#include "saradc_ctrl.h"

/* ======================================================================= */
/* LIST HELPER FUNCTIONS                                                   */
/* ======================================================================= */



void saradc_ctrl_create_list_item_u16(saradc_ctrl_list_entry *list_entry, uint16_t l0, uint16_t l1, uint16_t l2){
  saradc_ctrl_list_entry list_entry_temp = {0,0,0,0,1,0xFFFF};
  list_entry_temp.target_adr = l0;
  list_entry_temp.no_sample = l1; 
  list_entry_temp.no_sum = l1 >> 4; 
  list_entry_temp.ch_no = l1 >> 9; 
  list_entry_temp.trigger_type = l1 >> 14;
  list_entry_temp.trigger = l2;
  
  *list_entry = list_entry_temp;
}

void saradc_ctrl_create_list_item(saradc_ctrl_list_entry *list_entry, uint16_t target_adr, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t trigger_type, uint16_t trigger){
  saradc_ctrl_list_entry list_entry_temp = {0,0,0,0,1,0xFFFF};
  list_entry_temp.target_adr = target_adr;
  list_entry_temp.no_sample = no_sample; 
  list_entry_temp.no_sum = no_sum; 
  list_entry_temp.ch_no = ch_no; 
  list_entry_temp.trigger_type = trigger_type;
  list_entry_temp.trigger = trigger;
  
  *list_entry = list_entry_temp;
}

/* ======================================================================= */
/* MODULE HANDLING                                                         */
/* ======================================================================= */

void saradc_ctrl_set_cfg(saradc_ctrl_cfg_t cfg){
  WRITE_REG_16(AADDR_SARADC_CTRL_CFG, cfg.val);
}

saradc_ctrl_cfg_t saradc_ctrl_get_cfg(void){
  saradc_ctrl_cfg_t cfg;
  cfg.val = READ_REG_U16(AADDR_SARADC_CTRL_CFG);
  return cfg;
}

void saradc_ctrl_set_cfg_sar_timing(saradc_ctrl_cfg_sar_timing_t cfg_sar_timing){
  WRITE_REG_16(AADDR_SARADC_CTRL_CFG_SAR_TIMING, cfg_sar_timing.val);
}

saradc_ctrl_cfg_sar_timing_t saradc_ctrl_get_cfg_sar_timing(void){
  saradc_ctrl_cfg_sar_timing_t cfg_sar_timing;
  cfg_sar_timing.val = READ_REG_U16(AADDR_SARADC_CTRL_CFG_SAR_TIMING);
  return cfg_sar_timing;
}

void saradc_ctrl_set_wait_prescaler(saradc_ctrl_wait_prescaler_t wait_prescaler){
  WRITE_REG_16(AADDR_SARADC_CTRL_WAIT_PRESCALER, wait_prescaler.val);
}

saradc_ctrl_wait_prescaler_t saradc_ctrl_get_wait_prescaler(void){
  saradc_ctrl_wait_prescaler_t wait_prescaler;
  wait_prescaler.val = READ_REG_U16(AADDR_SARADC_CTRL_WAIT_PRESCALER);
  return wait_prescaler;
}


//---------
void saradc_ctrl_set_sync_out_cfg(saradc_ctrl_sync_out_cfg_t sync_out_cfg){
  WRITE_REG_16(AADDR_SARADC_CTRL_SYNC_OUT_CFG, sync_out_cfg.val);
}

saradc_ctrl_sync_out_cfg_t saradc_ctrl_get_sync_out_cfg(void){
  saradc_ctrl_sync_out_cfg_t sync_out_cfg;
  sync_out_cfg.val = READ_REG_U16(AADDR_SARADC_CTRL_SYNC_OUT_CFG);
  return sync_out_cfg;
}

void saradc_ctrl_set_sync_out_trig(saradc_ctrl_sync_out_trig_t sync_out_trig){
  WRITE_REG_16(AADDR_SARADC_CTRL_SYNC_OUT_TRIG, sync_out_trig);
}

saradc_ctrl_sync_out_trig_t saradc_ctrl_get_sync_out_trig(void){
  return (saradc_ctrl_sync_out_trig_t)READ_REG_U16(AADDR_SARADC_CTRL_SYNC_OUT_TRIG);
}

void saradc_ctrl_set_cmd(saradc_ctrl_cmd_t cmd){
  WRITE_REG_16(AADDR_SARADC_CTRL_CMD, cmd.val);
}

void saradc_ctrl_set_wadr_min(saradc_ctrl_wadr_min_t wadr_min){
  WRITE_REG_16(AADDR_SARADC_CTRL_WADR_MIN, wadr_min.val);
}

saradc_ctrl_wadr_min_t saradc_ctrl_get_wadr_min(void){
  saradc_ctrl_wadr_min_t wadr_min;
  wadr_min.val = READ_REG_U16(AADDR_SARADC_CTRL_WADR_MIN);
  return wadr_min;
}

void saradc_ctrl_set_wadr_max(saradc_ctrl_wadr_max_t wadr_max){
  WRITE_REG_16(AADDR_SARADC_CTRL_WADR_MAX, wadr_max.val);
}

saradc_ctrl_wadr_max_t saradc_ctrl_get_wadr_max(void){
  saradc_ctrl_wadr_max_t wadr_max;
  wadr_max.val = READ_REG_U16(AADDR_SARADC_CTRL_WADR_MAX);
  return wadr_max;
}

void saradc_ctrl_set_sadr_new(saradc_ctrl_sadr_new_t sadr_new){
  WRITE_REG_16(AADDR_SARADC_CTRL_SADR_NEW, sadr_new.val);
}

saradc_ctrl_sadr_current_t saradc_ctrl_get_sadr_current(void){
  return(saradc_ctrl_sadr_current_t)READ_REG_U16(AADDR_SARADC_CTRL_SADR_CURRENT);
}

saradc_ctrl_l0_current_t saradc_ctrl_get_l0_current(void){
  return(saradc_ctrl_l0_current_t)READ_REG_U16(AADDR_SARADC_CTRL_L0_CURRENT);
}
saradc_ctrl_l1_current_t saradc_ctrl_get_l1_current(void){
  saradc_ctrl_l1_current_t l1_current;
  l1_current.val = READ_REG_U16(AADDR_SARADC_CTRL_L1_CURRENT);
  return l1_current;
}
saradc_ctrl_l2_current_t saradc_ctrl_get_l2_current(void){
  return(saradc_ctrl_l2_current_t)READ_REG_U16(AADDR_SARADC_CTRL_L2_CURRENT);
}

saradc_ctrl_adr_next_t saradc_ctrl_get_adr_next(void){
  return(saradc_ctrl_adr_next_t)READ_REG_U16(AADDR_SARADC_CTRL_ADR_NEXT);
}

saradc_ctrl_tadr_t saradc_ctrl_get_tadr(void){
  return(saradc_ctrl_tadr_t)READ_REG_U16(AADDR_SARADC_CTRL_TADR);
}

void saradc_ctrl_set_direct_mode_lw(saradc_ctrl_direct_mode_lw_t direct_mode_lw){
  WRITE_REG_16(AADDR_SARADC_CTRL_DIRECT_MODE_LW, (uint16_t)direct_mode_lw);    
}

saradc_ctrl_direct_mode_lw_t saradc_ctrl_get_direct_mode_lw(void){
  return (saradc_ctrl_direct_mode_lw_t)READ_REG_U16(AADDR_SARADC_CTRL_DIRECT_MODE_LW);
}

void saradc_ctrl_set_direct_mode_hw(saradc_ctrl_direct_mode_hw_t direct_mode_hw){
  WRITE_REG_16(AADDR_SARADC_CTRL_DIRECT_MODE_HW, (uint16_t)direct_mode_hw);    
}

saradc_ctrl_direct_mode_lw_t saradc_ctrl_get_direct_mode_hw(void){
  return (saradc_ctrl_direct_mode_hw_t)READ_REG_U16(AADDR_SARADC_CTRL_DIRECT_MODE_HW);
}

saradc_ctrl_sadr_done_t saradc_ctrl_get_sadr_done(void){
  return(saradc_ctrl_sadr_done_t)READ_REG_U16(AADDR_SARADC_CTRL_SADR_DONE);
}

saradc_ctrl_state_t saradc_ctrl_get_state(void){
  return(saradc_ctrl_state_t)READ_REG_U16(AADDR_SARADC_CTRL_STATE);
}

void saradc_ctrl_skip_list() {
  WRITE_REG_16(AADDR_SARADC_CTRL_CMD, 1);
}

void saradc_ctrl_skip_item() {
  WRITE_REG_16(AADDR_SARADC_CTRL_CMD, 1>>1);
}

void saradc_ctrl_set_adc_clk_div(uint8_t adc_clk_div){
  saradc_ctrl_cfg_sar_timing_t saradc_ctrl_cfg_sar_timing = saradc_ctrl_get_cfg_sar_timing();
  saradc_ctrl_cfg_sar_timing.bf.adc_clk_div = adc_clk_div;
  saradc_ctrl_set_cfg_sar_timing(saradc_ctrl_cfg_sar_timing);
}

/* ======================================================================= */
/* PROJECT SPECIFIC  (link3d)                                              */
/* ======================================================================= */



/* ======================================================================= */
/* INTERRUPT HANDLING                                                      */
/* ======================================================================= */

void saradc_ctrl_set_irq_mask(saradc_ctrl_irq_mask_t irq_mask) {
  WRITE_REG_16(AADDR_SARADC_CTRL_IRQ_MASK, irq_mask);
}

saradc_ctrl_irq_mask_t saradc_ctrl_get_irq_mask(void) {
  return(saradc_ctrl_irq_mask_t)READ_REG_U16(AADDR_SARADC_CTRL_IRQ_MASK);
}

saradc_ctrl_irq_status_t saradc_ctrl_get_irq_status(void){
  saradc_ctrl_irq_status_t saradc_ctrl_irq_status;
  saradc_ctrl_irq_status.val = READ_REG_U16(AADDR_SARADC_CTRL_IRQ_STATUS);
  return saradc_ctrl_irq_status;
}

/*
void saradc_ctrl_handler_init(void) {

	irq_handler_init(VIC_IRQ_RESERVED, SARADC_CTRL_NUM_IRQS, (callback_t *)callback, BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_IRQ_VENABLE);
}
*/



void saradc_ctrl_clear_all_irq_events() {
  WRITE_REG_16(AADDR_SARADC_CTRL_IRQ_STATUS, 0xFFFF);
}

void saradc_ctrl_enable_irq(saradc_ctrl_irq_t irq, bool enable) {
  if (enable) WRITE_REG_16(AADDR_SARADC_CTRL_IRQ_VENABLE, (uint16_t)irq);
  else WRITE_REG_16(AADDR_SARADC_CTRL_IRQ_VDISABLE, (uint16_t)irq);
}
