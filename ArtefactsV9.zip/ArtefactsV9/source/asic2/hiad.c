/* FPGA Release: 10512 */
#include "device.h"

#include "hiad.h"
#include "hiad_bf.h"

void hiad_config (bool enable_oe,
             hiad_bus_width_t bus_width,
             bool muxed, bool muxed_8_addr,
             bool ncs_active, bool nrd_active,
             bool nwr_active, bool nwait_active,
             bool nwait_extend, bool ale_edge, bool write_sample) {
  hiad_config_t hiad_config;
  hiad_config.val = 0;
  // Die Konfiguration darf nur ver�ndert werden, wenn CONFIG.en = 0 ist.
  WRITE_REG_16(AADDR_HIAD_CONFIG, 0);
  hiad_config.bf.en_oe        = enable_oe     ? 1 : 0;
  hiad_config.bf.mode_8n16    = bus_width;
  hiad_config.bf.muxed        = muxed         ? 1 : 0;
  hiad_config.bf.muxed8_addr  = muxed_8_addr  ? 1 : 0;
  hiad_config.bf.ncs_active   = ncs_active    ? 1 : 0;
  hiad_config.bf.nrd_active   = nrd_active    ? 1 : 0;
  hiad_config.bf.nwr_active   = nwr_active    ? 1 : 0;
  hiad_config.bf.nwait_active = nwait_active  ? 1 : 0;
  hiad_config.bf.nwait_extend = nwait_extend  ? 1 : 0;
  hiad_config.bf.ale_edge     = ale_edge      ? 1 : 0;
  hiad_config.bf.write_sample = write_sample  ? 1 : 0;
  WRITE_REG_16(AADDR_HIAD_CONFIG, hiad_config.val);
}

void hiad_set_mask_adr13(bool mask){
  hiad_config_t hiad_config;
  hiad_config.val = READ_REG_U16(AADDR_HIAD_CONFIG);
  hiad_config.bf.mask_adr14   = mask;
  WRITE_REG_16(AADDR_HIAD_CONFIG, hiad_config.val);
}

void hiad_set_mask_adr14(bool mask){
  hiad_config_t hiad_config;
  hiad_config.val = READ_REG_U16(AADDR_HIAD_CONFIG);
  hiad_config.bf.mask_adr14   = mask;
  WRITE_REG_16(AADDR_HIAD_CONFIG, hiad_config.val);
}

void hiad_set_enable(bool enable){
  hiad_config_t hiad_config;
  hiad_config.val    = READ_REG_U16(AADDR_HIAD_CONFIG);
  hiad_config.bf.en  = enable ? 1 : 0;
  WRITE_REG_16(AADDR_HIAD_CONFIG, hiad_config.val);
}

void hiad_config_access_control (uint16_t addr0_low, uint16_t addr0_high,
                            uint16_t addr1_low, uint16_t addr1_high) {
  hiad_config_t hiad_config;
  hiad_config.val    = READ_REG_U16(AADDR_HIAD_CONFIG);

  /* Die Konfiguration darf nur ver�ndert werden, wenn CONFIG.en = 0 ist. */
  bool was_enabled = (hiad_config.bf.en == 1) ? true : false;
  hiad_config.bf.en = 0;
  WRITE_REG_16(AADDR_HIAD_CONFIG, hiad_config.val);

  WRITE_REG_16(AADDR_HIAD_ACCESS_ADDR0_LOW,   addr0_low);
  WRITE_REG_16(AADDR_HIAD_ACCESS_ADDR0_HIGH,  addr0_high);
  WRITE_REG_16(AADDR_HIAD_ACCESS_ADDR1_LOW,   addr1_low);
  WRITE_REG_16(AADDR_HIAD_ACCESS_ADDR1_HIGH,  addr1_high);

  hiad_config.bf.en = was_enabled ? 1 : 0;
  WRITE_REG_16(AADDR_HIAD_CONFIG, hiad_config.val);
}

