/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         cctimer32_irq.h
*
* @brief        Capture and Compare Timer 32 (CCTIMER32) HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CCTIMER32_IRQ_H__
#define __CCTIMER32_IRQ_H__

#define CCTIMER32_NUM_IRQS 16

/**
  * \brief This is an enum class for CCTIMER32 describing IRQ events
  *
  * \ingroup cctimer32
  */ 
typedef enum{
  CCTIMER32_IRQ_OVERFLOW_A =            0, ///< counter A over/underflow
  CCTIMER32_IRQ_OVERFLOW_B =            1, ///< counter B over/underflow
  CCTIMER32_IRQ_OVERFLOW_C =            2, ///< counter C over/underflow
  CCTIMER32_IRQ_OVERFLOW_D =            3, ///< counter D over/underflow
  CCTIMER32_IRQ_RESTART_A =             4, ///< counter A restart event
  CCTIMER32_IRQ_RESTART_B =             5, ///< counter B restart event
  CCTIMER32_IRQ_RESTART_C =             6, ///< counter C restart event
  CCTIMER32_IRQ_RESTART_D =             7, ///< counter D restart event
  CCTIMER32_IRQ_CAPTURE_A =             8, ///< counter A capture event
  CCTIMER32_IRQ_CAPTURE_B =             9, ///< counter B capture event
  CCTIMER32_IRQ_CAPTURE_C =             10, ///< counter C capture event
  CCTIMER32_IRQ_CAPTURE_D =             11, ///< counter D capture event
  CCTIMER32_IRQ_ED_ZM =                 12, ///< event decoder events: zero marker
  CCTIMER32_IRQ_ED_DIR_CHANGE =         13, ///< event decoder events: direction change
  CCTIMER32_IRQ_ED_POSCHANGE =          14, ///< event decoder events: position change
  CCTIMER32_IRQ_ED_AB_ERROR =           15 ///< event decoder events: A/B track error
} cctimer32_irq_t;

#endif
