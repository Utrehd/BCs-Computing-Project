/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swd_sap.h
*
* @brief        SWD_PM HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SWD_SAP_H
#define HAVE_SWD_SAP_H

#ifndef HAVE_SWD_H
#error "Please include swd.h instead of this file."
#endif


/* ############################################################################ */
/**
 * \brief enable listening on all addresses
 *
 * \ingroup swd_pm 
 */ 
void swd_sap_enable_all_dest_addrs (void);


/* ############################################################################ */
/**
 * \brief   Disable listening on all addresses + Disable all SAP destionation address
 *
 * \ingroup swd_pm 
 */ 
void swd_sap_disable_all_dest_addrs (void);


/* ############################################################################ */
/**
 * \brief       Enable PE SAP destionation address
 *
 * \ingroup swd_pm 
 * 
 * \param no 
 * 
 * \param addr  destination address <br>
 *              e.g. 0 is uni cast <br>
 *              e.g. 1 is multiple cast group 0 <br>
 *              e.g. 2 is multiple cast group 1 <br>
 *              e.g. 3 is multiple cast group 2 <br>
 */ 
void swd_sap_enable_dest_addr (uint8_t no, uint8_t addr);


/* ############################################################################ */
/**
 * \brief Disable SAP destionation address
 *
 * \ingroup swd_pm 
 * 
 * \param no The number of SAP destionation address to be disabled
 */ 
void swd_sap_disable_dest_addr (uint8_t no);


/* ############################################################################ */
/**
 * \brief Set SAP filter
 *
 * \ingroup swd_pm 
 * 
 * \param vchannel The virtual DMA channel (VCHANNEL_ACY_RX_SAPA, VCHANNEL_ACY_RX_SAPB, VCHANNEL_ACY_RX_SAPC)
 * 
 * \param mask     enables sensitivity for first 4 LSB in SAP field of acyclic transfer
 *                 sap_mask[n] = 0: bit n is not evaluated (don�t care) sap_mask[n] = 1:
 *                 bit n is evaluated with sap_value
 * 
 * \param value    values for the first 4 LSB in SAP field of acyclic transfer sensitivity for
 *                 each bit can be enabled with sap_mask
 *
 * \param inv      0: result of filter is: AND ((mask[n]=0) or (sap[n] = value[n]); n=0...3) <br>
 *                 1: result of filter is: not AND ((mask[n]=0) or (sap[n] = value[n]); n=0...3) <br>
 */ 
void swd_sap_set_filter (swd_dma_vchannel_t vchannel, uint8_t mask, uint8_t value, bool inv);


/* ############################################################################ */
/**
 * \brief                 Set SOURCE FSM COMMAND
 *
 * \ingroup swd_pm 
 * 
 * \param src              source 0/1/2/3
 * 
 * \param source_command   SOURCE FSM COMMAND <br>
 *                         000: FORCE_NONE (no address recognized) <br>
 *                         001: FORCE_ALL (all addresses recognized) <br>
 *                         010: FORCE_FIXED (fixed address used) <br>
 *                         011: FORCE_LEARN (all addresses recognized, learning active) <br>
 *                         100: CONDITIONAL_NONE (safe transition to NONE, may not be executed) <br>
 *                         111: CONDITIONAL_FIXED (safe transition to FIXED, may not be executed) <br>
 * 
 * \param source_addr      SOURCE address
 *
 * \remarks                command register is reset by hardware
 */ 
void swd_sap_source_command (swd_sap_src_t src, swd_sap_src_command_t source_command, uint8_t source_addr);


/* ############################################################################ */
/**
 * \brief                  Get SOURCE FSM status
 *
 * \ingroup swd_pm 
 * 
 * \param src              source 0/1/2/3
 * 
 * \param source_status    SOURCE FSM STATE <br>
 *                         000: NONE (no address recognized) <br>
 *                         001: ALL (all addresses recognized) <br>
 *                         010: FIXED (fixed address used) <br>
 *                         011: LEARN (all addresses recognized, learning active) <br>
 *                         111: LEARNED (learned address used) <br>
 */ 
void swd_sap_get_source_status (swd_sap_src_t src, swd_sap_source_status_t * source_status);

#endif
