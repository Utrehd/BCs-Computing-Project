/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         wdog.h
*
* @brief        Watchdog and Guard HAL functions
*
* @author       Dedourek Pavel
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_WDOG_H
#define HAVE_WDOG_H

/**
 * \example example_wdog0.c
 * This is an example of how to use WDOG0 as system watchdog.
 */
 
/**
 * \defgroup wdog ASIC2 Watchdog and Guard HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control Watchdog and Guard
 */
/**@{*/ 


#include "device.h"

#include "wdog_bf.h"

/* ############################################################################ */
/**
 * \brief Configuration of WDOG/GUARD. It is possible to configure it only when wdog is disabled, all other writes will be ignored.
 *
 * \ingroup wdog
 * 
 * \param wdog WDOG/GUARD instance
 * 
 * \param seq_init initial value for the magic cookie sequence generator. Value of 0xFF is not recommended.
 * 
 * \param seq_len number of magic cookies in the sequence seq_len=1..(2^ seq_width)-1
 * 
 * \param time_interval timeout interval in system clock cycles
 *
 */
void wdog_init (wdog_num_t wdog, uint16_t seq_init, uint16_t seq_len, uint32_t time_interval);

/* ############################################################################ */
/**
 * \brief Start the wdog. This is reflected in the status register.
 *
 * \ingroup wdog
 * 
 * \param wdog WDOG/GUARD instance
 *
 */
void wdog_enable (wdog_num_t wdog);

/* ############################################################################ */
/**
 * \brief Disable the wdog (only in GUARD mode)
 *
 * \note WDOG0 cannot be disabled
 *
 * \ingroup wdog
 * 
 * \param wdog WDOG/GUARD instance
 *
 */
void wdog_disable (wdog_num_t wdog);

/* ############################################################################ */
/**
 * \brief Is wdog running?
 *
 * \ingroup wdog
 * 
 * \param wdog WDOG/GUARD instance
 * 
 * \return true: wdog is running <br>
 *         false: wdog is disabled
 */
bool wdog_is_running (wdog_num_t wdog);

/* ############################################################################ */
/**
 * \brief Captured value of the time interval counter when a successful sequence of 
 *        magic cookies is completed, i.e. it reflects how much time was left 
 *        in the previous interval
 *
 * \ingroup wdog
 * 
 * \param wdog WDOG/GUARD instance
 * 
 * \return left interval in system clock cycles
 *
 */
uint32_t wdog_get_time_last_left (wdog_num_t wdog);

/* ############################################################################ */
/**
 * \brief Current wdog timer value. <br>
 *        Note: TIMER_VAL_HW is sampled by reading TIMER_VAL_LW (not in debug).
 *
 * \ingroup wdog
 * 
 * \param wdog WDOG/GUARD instance
 * 
 * \return current wdog timer value
 */
uint32_t wdog_get_timer_val (wdog_num_t wdog);

/* ############################################################################ */
/**
 * \brief Write the next magic cookie. The first magic cookie is seq_init. <br>
 *
 * \ingroup wdog
 * 
 * \param wdog WDOG/GUARD instance
 * 
 * \param magic_cookie next magic cookie 
 * 
 */
void wdog_set_magic_cookie (wdog_num_t wdog, uint8_t magic_cookie);

/* ############################################################################ */
/**
 * \brief Calculate next magic cookie for wdog
 *        temp = (prev >> 7) ^ (prev >> 5) ^ (prev >> 4) ^ (prev >> 3);    <br>
 *        next = ((prev >> 1) & 0x7F) | (temp << 7);                       <br>
 *
 * \ingroup wdog
 * 
 * \param prev_cookie the previous magic cookie
 * 
 * \return next magic cookie
 */
uint8_t wdog_calc_next_cookie (uint8_t prev_cookie);

/* ############################################################################ */
/**
 * \brief Read wdog status
 *
 * \ingroup wdog
 * 
 * \param wdog WDOG/GUARD instance
 * 
 * \return current value of the outgoing allok (all ok) signal 
 */
bool wdog_get_allok (wdog_num_t wdog);

/* ############################################################################ */
/**
 * \brief Reinicialize GUARDs
 *        -# disable guard
 *        -# initialize guard 
 *        -# finish when it is still running 
 *        -# enable guard
 *        -# set new magic cookie
 *        -# read all ok
 *
 * \ingroup wdog
 * 
 * \param wdog GUARD instance
 * 
 *
 */
void wdog_unlock_guard(wdog_num_t wdog);

/**@} */
#endif /* HAVE_WDOG_H */
