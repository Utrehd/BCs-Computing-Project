/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         el_ctrl.h
*
* @brief        Electronic Label HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __EL_CTRL_H__
#define __EL_CTRL_H__

/**
 * \defgroup el_ctrl ASIC2 Electronic Label HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control Electronic Label
 */
/**@{*/ 

#include "el_ctrl_bf.h"
#include "el_ctrl_irq.h"
#include "device.h"


/* ############################################################################ */
/**
 * \brief This is an enum class for EL_CTRL to identify transmission configuration parameters
 *
 * \ingroup el_ctrl 
 */ 
typedef enum {
  /**
   * Transmission trigger: disabled
   */ 
  EL_CTRL_TRIGGER_DISABLED        = 0,
  /**
   * Transmission trigger: immediately
   */ 
  EL_CTRL_TRIGGER_IMMEDIATELY     = 1,
  /**
   * Transmission trigger: when trans_start_evt detected
   */ 
  EL_CTRL_TRIGGER_TRANS_START_EVT = 2,
  /**
   * Transmission trigger: when CYC_TX_START occurs
   */ 
  EL_CTRL_TRIGGER_CYC_TX_START    = 3
} el_ctrl_tx_trigger_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for EL_CTRL to identify Tia power mode
 *
 * \ingroup el_ctrl 
 */ 
typedef enum {
  /**
   * TIA in power down
   */ 
  EL_CTRL_TIA_POWER_OFF   = 0,
  /**
   * TIA in always on
   */ 
  EL_CTRL_TIA_POWER_ON    = 1,
  /**
   * TIA in automatic power mode
   */ 
  EL_CTRL_TIA_POWER_AUTO  = 2
} el_ctrl_tia_power_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for EL_CTRL to identify control state
 *
 * \ingroup el_ctrl 
 */ 
typedef enum {
  /**
   * Status: from transmitter to receiver status
   */ 
  EL_CTRL_STATE_TX2RX   = 0,
  /**
   * Status: In receiving pre0 phase
   */ 
  EL_CTRL_STATE_RX_PRE0 = 1,
  /**
   * Status: In receiving pre1 phase
   */ 
  EL_CTRL_STATE_RX_PRE1 = 2,
  /**
   * Status: In receiver status
   */ 
  EL_CTRL_STATE_RX      = 3,
  /**
   * Status: from receiver to transmitter status
   */ 
  EL_CTRL_STATE_RX2TX   = 4,
  /**
   * Status: In pre transmission phase
   */ 
  EL_CTRL_STATE_TX_PRE  = 5,
  /**
   * Status: In transmitter status
   */ 
  EL_CTRL_STATE_TX      = 6,
  /**
   * Status: In transmitting pst phase
   */ 
  EL_CTRL_STATE_TX_PST  = 7,
  /**
   * Status: In transmitting pat phase
   */ 
  EL_CTRL_STATE_TX_PAT  = 8
} el_ctrl_state_t;

//==========================================================================
// TIA
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to configure EL_CTRL TIA
 *
 * \ingroup el_ctrl 
 * 
 * \param tia_power_mode Select the power mode for TIA
 * 
 * \param tia_cfg_hyst Electrical parameters
 */ 
void el_ctrl_tia_config(
  el_ctrl_tia_power_t tia_power_mode, 
  uint8_t             tia_cfg_hyst);

//==========================================================================
// Cycle Control
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to enable EL_CTRL cycle control
 *
 * \ingroup el_ctrl 
 * 
 * \param cyc_en 0: CYC counter stopped and cleared <br> 1: CYC counter enabled
 */ 
void el_ctrl_cyc_enable(bool cyc_en);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL cycle length
 *
 * \ingroup el_ctrl 
 * 
 * \param cyc_len Duration of one hidden communication schedule in transmit bits. Only evaluated at start of cycle, can be written at any time.
 */ 
void el_ctrl_set_cyc_len(uint16_t cyc_len);


/* ############################################################################ */
/**
 * \brief Function to get EL_CTRL cycle length
 *
 * \ingroup el_ctrl 
 * 
 * \return Value of cycle length
 */ 
uint16_t el_ctrl_get_cyc_len(void);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL cycle length
 *
 * \ingroup el_ctrl 
 * 
 * \param cyc_tx_start Start of transmit in transmit bits after start of cycle (see TX_CFG.trigger). When CYC_TX_START > CYC_CFG no transmit will occur. <br>
 * Only evaluated at start of cycle, can be written at any time.
 */ 
void el_ctrl_set_cyc_tx_start(uint16_t cyc_tx_start);

//==========================================================================
// Meas Control
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to enable EL_CTRL measurement
 *
 * \ingroup el_ctrl 
 * 
 * \param meas_en 0: disabled (MEAS_INTF is stopped and cleared) <br> 1: enabled during rx phase
 */ 
void el_ctrl_meas_enable(bool meas_en);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL measurement level
 *
 * \ingroup el_ctrl 
 * 
 * \param meas_zero_level 0: Measurement 0-Level is led_rx=0 <br> 1: Measurement 0-Level is led_rx=1
 */ 
void el_ctrl_set_meas_zero_level(uint8_t meas_zero_level);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL measurement coefficient rise/fall
 *
 * \ingroup el_ctrl 
 * 
 * \param rise Set rise value
 * 
 * \param fall Set fall value
 */ 
void el_ctrl_set_meas_intf_rise_fall(uint16_t rise, uint16_t fall);


/* ############################################################################ */
/**
 * \brief Function to get EL_CTRL measurement cycle length
 *
 * \ingroup el_ctrl 
 * 
 * \return Length of cycle between two "transmission start" events in clocks. Saturates to MAX. high and low word
 */ 
uint32_t el_ctrl_get_meas_cyc_len(void);


/* ############################################################################ */
/**
 * \brief Function to get EL_CTRL measurement pre length
 *
 * \ingroup el_ctrl 
 * 
 * \return Length of "transmission start" event to end of preamble in clocks. Saturates to MAX. high and low word
 */ 
uint32_t el_ctrl_get_meas_pre_len(void);


/* ############################################################################ */
/**
 * \brief Function to get EL_CTRL measurement minimum br
 *
 * \ingroup el_ctrl 
 * 
 * \return Minimum distance between rising edges measured during receive period. Saturates to 0. Cleared on Read.
 */ 
uint16_t el_ctrl_get_meas_br_min(void);

//==========================================================================
// TX Control
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter trigger
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_trigger Transmitter trigger configuration <br>
 *                   \see el_ctrl_tx_trigger_t
 */ 
void el_ctrl_set_tx_trigger(el_ctrl_tx_trigger_t tx_trigger);


/* ############################################################################ */
/**
 * \brief Function to enable EL_CTRL transmitter NRZ
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_use_nrz            0: transmit uses Manchester encoding <br>
 *                              1: transmit used NRZ encoding
 */ 
void el_ctrl_set_tx_use_nrz(bool tx_use_nrz);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter zero level
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_zero_level         Level during TX PRE and TX phase. Will also be used for optional TX2RX drive. <br>
 *                              -> NRZ encoding: <br>
 *                                 0: data '0' is el_tx=0 (led off) <br>
 *                                 1: data '0' is el_tx=1 (led on) <br>
 *                              -> Manchester encoding: <br>
 *                                 0: 0-Level is el_tx=0 (led off) <br>
 *                                 1: 0-Level is el_tx=1 (led on)
 */ 
void el_ctrl_set_tx_zero_level(uint8_t tx_zero_level);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter rx2tx level
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_rx2tx_level        -> Value of el_tx during rx2tx phase: <br>
 *                                 0: el_tx=0 (led off) <br>
 *                                 1: el_tx=1 (led on)
 */ 
void el_ctrl_set_tx_rx2tx_level(uint8_t tx_rx2tx_level);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter pst level
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_pst_level         -> Value of el_tx during tx pst phase: <br>
 *                                0: el_tx=0 (led off) <br>
 *                                1: el_tx=1 (led on)
 */ 
void el_ctrl_set_tx_pst_level(uint8_t tx_pst_level);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter preamble length
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_preamble_length    -> For Manchester encoding: <br>
 *                                 0: do not send preamble <br>
 *                                 1: minimal preamble <br>
 *                                 2: one additional zero before minimal preamble <br>
 *                                 3: two additional zeros before minimal preamble <br>
 *                                 ... <br>
 *                              -> For NRZ encoding preamble_length must be set to 0, i.e. no preamble is send.
 */ 
void el_ctrl_set_tx_preamble_length(uint8_t tx_preamble_length);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter ignore gpo
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_gpo_ignore          0: tx2rx and rx2tx states switch GPO and wait until gpo_now is equal to gpo_val <br>
 *                               1: ignore GPO now and switch state directly
 */ 
void el_ctrl_set_tx_gpo_ignore(bool tx_gpo_ignore);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter always pre
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_always_pre          0: go from rx2tx to tx pat when tx_empty <br>
 *                               1: always send tx pre and tx pst
 */ 
void el_ctrl_set_tx_always_pre(bool tx_always_pre);


/* ############################################################################ */
/**
 * \brief Function to enable EL_CTRL transmitter pat
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_pat_enable          0: tx pat disabled (will directly go to tx2rx phase) <br>
 *                               1: send led_on pattern during tx pat until end of cycle
 */ 
void el_ctrl_tx_pat_enable(bool tx_pat_enable);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter LED pattern
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_led_on_pattern    During the “LED on” phase led_on is transmitted. Each bit is transmitted for the duration of half a bit period. <br>
 *                             Has to be different than 0xFF or 0.
 */ 
void el_ctrl_set_tx_led_on_pattern(uint8_t tx_led_on_pattern);

// in clock cycles

/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter half bit length
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_half_bit_length   Manchester/NRZ encoding: length in clock cycles of half a bit period. Low Word.
 */ 
void el_ctrl_set_tx_half_bit_length(uint32_t tx_half_bit_length);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter maximum bytes
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_max_bytes         0: sent data until TX FIFO is empty <br>
 *                             1..MAX: maximum length of tx phase in bytes
 */ 
void el_ctrl_set_tx_max_bytes(uint8_t tx_max_bytes);

//==========================================================================
// RX Control
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to enable EL_CTRL receiver
 *
 * \ingroup el_ctrl 
 * 
 * \param rx_enable            1: receiver enabled (when not transmitting) <br>
 *                             0: receiver disabled and set to “wait for preamble” state
 */ 
void el_ctrl_rx_enable(bool rx_enable);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL receiver zero level
 *
 * \ingroup el_ctrl 
 * 
 * \param rx_zero_level        0: Manchester 0-Level is led_rx=0 <br>
 *                             1: Manchester 0-Level is led_rx=1
 */ 
void el_ctrl_set_rx_zero_level(uint8_t rx_zero_level);

// in bits

/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL receiver pre0 phase length
 *
 * \ingroup el_ctrl 
 * 
 * \param rx_pre0_phase_length       0: rx pre0 phase disabled <br>
 *                                   1..MAX: length of rx pre0 phase in bits
 */ 
void el_ctrl_set_rx_pre0_phase_length(uint8_t rx_pre0_phase_length);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL receiver pre1 phase length
 *
 * \ingroup el_ctrl 
 * 
 * \param rx_pre1_phase_length       0: rx pre1 phase disabled <br>
 *                                   1..MAX: length of rx pre1 phase in bits
 */ 
void el_ctrl_set_rx_pre1_phase_length(uint8_t rx_pre1_phase_length);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL receiver minimum preamble length
 *
 * \ingroup el_ctrl 
 * 
 * \param rx_min_preamble_length        0: minimal preamble sufficient <br>
 *                                      1: at least one additional zero before minimal preamble <br>
 *                                      2: t least two additional zeros before minimal preamble <br>
 *                                      ...
 */ 
void el_ctrl_set_rx_min_preamble_length(uint8_t rx_min_preamble_length);

// in clock cycles

/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL receiver filter threshold
 *
 * \ingroup el_ctrl 
 * 
 * \param rx_intf_threshold Value of integration filter threshold
 */ 
void el_ctrl_set_rx_intf_threshold(uint8_t rx_intf_threshold);

// in clock cycles

/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL receiver bit length
 *
 * \ingroup el_ctrl 
 * 
 * \param rx_bit_length Manchester encoding: length in clock cycles of a bit period.
 */ 
void el_ctrl_set_rx_bit_length(uint16_t rx_bit_length);

//==========================================================================
// Data Fifos
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to clear EL_CTRL transmitter FIFO
 *
 * \ingroup el_ctrl 
 */ 
void el_ctrl_clear_tx_fifo(void);


/* ############################################################################ */
/**
 * \brief Function to know when EL_CTRL transmitter FIFO is full
 *
 * \ingroup el_ctrl 
 * 
 * \return 1: FIFO is full
 */ 
bool el_ctrl_tx_fifo_full(void);

// non blocking

/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter FIFO data (non blocking)
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_data Data byte to transmit. Length of FIFO is 8 bytes.
 */ 
void el_ctrl_send_byte_nb(uint8_t tx_data);


/* ############################################################################ */
/**
 * \brief Function to set EL_CTRL transmitter FIFO data
 *
 * \ingroup el_ctrl 
 * 
 * \param tx_data Data byte to transmit. Length of FIFO is 8 bytes.
 */ 
void el_ctrl_send_byte(uint8_t tx_data);



/* ############################################################################ */
/**
 * \brief Function to clear EL_CTRL receiver FIFO data
 *
 * \ingroup el_ctrl 
 */ 
void el_ctrl_clear_rx_fifo(void);


/* ############################################################################ */
/**
 * \brief Function to know when EL_CTRL receiver FIFO is empty
 *
 * \ingroup el_ctrl 
 * 
 * \return 1: FIFO is empty
 */ 
bool el_ctrl_rx_fifo_empty(void);

// non blocking

/* ############################################################################ */
/**
 * \brief Function to get EL_CTRL receiver FIFO data (non blocking)
 *
 * \ingroup el_ctrl 
 * 
 * \return Received FIFO data
 */ 
uint8_t el_ctrl_recv_byte_nb(void);


/* ############################################################################ */
/**
 * \brief Function to get EL_CTRL receiver FIFO data
 *
 * \ingroup el_ctrl 
 * 
 * \return Received FIFO data
 */ 
uint8_t el_ctrl_recv_byte(void);

// valid after recv_byte

/* ############################################################################ */
/**
 * \brief Function to know EL_CTRL start of frame
 *
 * \ingroup el_ctrl 
 * 
 * \return 1: Start of frame
 */ 
bool el_ctrl_was_sof_flag(void);

//==========================================================================
// Status
//==========================================================================


/* ############################################################################ */
/**
 * \brief Function to get EL_CTRL state
 *
 * \ingroup el_ctrl 
 * 
 * \return          Value of the state <br>
 *                  \see el_ctrl_state_t
 */ 
el_ctrl_state_t el_ctrl_get_state(void);

//==========================================================================
// IRQs
//==========================================================================


/* ############################################################################ */
/**
 * \brief Function to enable EL_CTRL Interrupt
 *
 * \ingroup el_ctrl 
 * 
 * \param irq       Interrupt Request Number <br>
 *                  \see el_ctrl_irq_t
 * 
 * \param enable    1: Enable <br>
 *                  0: Disable
 */ 
void el_ctrl_enable_irq(el_ctrl_irq_t irq, bool enable);


/* ############################################################################ */
/**
 * \brief Function to get EL_CTRL Interrupt status
 *
 * \ingroup el_ctrl 
 * 
 * \return          Interrupt status <br>
 *                  \see el_ctrl_irq_status_t
 */ 
el_ctrl_irq_status_t el_ctrl_get_irq_status(void);


/* ############################################################################ */
/**
 * \brief Function to get EL_CTRL pending Interrupt
 *
 * \ingroup el_ctrl 
 * 
 * \return          Pending Interrupt number <br>
 *                  \see el_ctrl_irq_t
 */ 
el_ctrl_irq_t el_ctrl_get_pending_irq(void);


/* ############################################################################ */
/**
 * \brief Function to clear EL_CTRL all Interrupts
 *
 * \ingroup el_ctrl 
 */ 
void el_ctrl_clear_all_irqs(void);

/* ############################################################################ */
/**
 * \brief Function to clear EL_CTRL concrete Interrupt
 *
 * \ingroup el_ctrl 
 * 
 * \param vno Interrupt number to be cleared
 */ 
void el_ctrl_clear_irqs_vno(uint16_t vno);

/**@} */
#endif /* __EL_CTRL_H__ */
