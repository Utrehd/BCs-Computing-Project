/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         cpu_n_cpu.h
*
* @brief        CPU_N_CPU HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_CPU_N_CPU_H
#define HAVE_CPU_N_CPU_H

/**
 * \example example_cpu_n_cpu.c
 * This is an example of how to use AOUT Control block.
 */

/**
 * \defgroup cpu_n_cpu ASIC2 CPU_N_CPU HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control CPU_N_CPU
 *
 * \details See code example: @include example_cpu_n_cpu.c
 */
/**@{*/ 

#include "device.h"


#include "cpu_n_cpu_bf.h"
#include "cpu_n_cpu_irq.h"

#define CPU_N_CPU_NUM_CPUS 3

//******************************************************************************
// ACCESS CONTROL CONTROL
// only available on wb 0 => instance is always CPU_N_CPU_H430
//******************************************************************************

/* ############################################################################ */
/**
 * \brief   Function to set CPU_N_CPU access control configuration (only in wishbone interface 0)
 *
 * \ingroup cpu_n_cpu
 *
 * \param acc_n Select register bank to configure
 *
 */
void cpu_n_cpu_set_acc_n(uint16_t acc_n);
//#define cpu_n_cpu_set_acc_n(acc_n) WRITE_REG_16(CPU_N_CPU_H430 + ADDR_CPU_N_CPU_ACC_N, acc_n)

/* ############################################################################ */
/**
 * \brief   Function to get CPU_N_CPU access control configuration (only in wishbone interface 0)
 *
 * \ingroup cpu_n_cpu
 *
 * \return Value of current access control configuration
 * 
 */
uint16_t cpu_n_cpu_get_acc_n();
//#define cpu_n_cpu_get_acc_n() READ_REG_U16(CPU_N_CPU_H430 + ADDR_CPU_N_CPU_ACC_N)

/* ############################################################################ */
/**
 * \brief   Function to set CPU_N_CPU access control TSF configuration (only in wishbone interface 0)
 *
 * \ingroup cpu_n_cpu
 *
 * \param acc_tsf Select the accesses AC_TSF of wishbone interface ACC_N
 *
 */
void cpu_n_cpu_set_acc_tsf(uint16_t acc_tsf);
//#define cpu_n_cpu_set_acc_tsf(acc_tsf) WRITE_REG_16(CPU_N_CPU_H430 + ADDR_CPU_N_CPU_ACC_TSF, acc_tsf)

/* ############################################################################ */
/**
 * \brief   Function to get CPU_N_CPU access control TSF configuration (only in wishbone interface 0)
 *
 * \ingroup cpu_n_cpu
 *
 * \return Value of current TSF configuration
 * 
 */
uint16_t cpu_n_cpu_get_acc_tsf();
//#define cpu_n_cpu_get_acc_tsf() READ_REG_U16(CPU_N_CPU_H430 + ADDR_CPU_N_CPU_ACC_TSF)

/* ############################################################################ */
/**
 * \brief   Function to set CPU_N_CPU access control Interrupt Request (IRQ) (only in wishbone interface 0)
 *
 * \ingroup cpu_n_cpu
 *
 * \param acc_irq_set Select the accesses AC_IRQ_SET of wishbone interface ACC_N
 *
 */
void cpu_n_cpu_set_acc_irq_set(uint16_t acc_irq_set);
//#define cpu_n_cpu_set_acc_irq_set(acc_irq_set) WRITE_REG_16(CPU_N_CPU_H430 + ADDR_CPU_N_CPU_ACC_IRQ_SET, acc_irq_set)

/* ############################################################################ */
/**
 * \brief   Function to get CPU_N_CPU access control Interrupt Request (IRQ) (only in wishbone interface 0)
 *
 * \ingroup cpu_n_cpu
 *
 * \return Value of current Interrupt Request (IRQ)
 * 
 */
uint16_t cpu_n_cpu_get_acc_irq_set();
//#define cpu_n_cpu_get_acc_irq_set() READ_REG_U16(CPU_N_CPU_H430 + ADDR_CPU_N_CPU_ACC_IRQ_SET)

/* ############################################################################ */
/**
 * \brief   Function to clear CPU_N_CPU access control Interrupt Request (IRQ) (only in wishbone interface 0)
 *
 * \ingroup cpu_n_cpu
 *
 * \param acc_irq_clr Select the accesses AC_IRQ_CLR of wishbone interface ACC_N
 *
 */
void cpu_n_cpu_set_acc_irq_clr(uint16_t acc_irq_clr);
//#define cpu_n_cpu_set_acc_irq_clr(acc_irq_clr) WRITE_REG_16(CPU_N_CPU_H430 + ADDR_CPU_N_CPU_ACC_IRQ_CLR, acc_irq_clr)

/* ############################################################################ */
/**
 * \brief   Function to get CPU_N_CPU access control Interrupt Request (IRQ) clear status (only in wishbone interface 0)
 *
 * \ingroup cpu_n_cpu
 *
 * \return Value of current Interrupt Request (IRQ) clear status
 * 
 */
uint16_t cpu_n_cpu_get_acc_irq_clr();
//#define cpu_n_cpu_get_acc_irq_clr() READ_REG_U16(CPU_N_CPU_H430 + ADDR_CPU_N_CPU_ACC_IRQ_CLR)


//******************************************************************************
// ACCESS CONTROL
//******************************************************************************

/* ############################################################################ */
/**
 * \brief   Function to get CPU_N_CPU access control TSF setting
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 *
 * \return Value of current access control TSF setting
 * 
 */
uint16_t cpu_n_cpu_get_ac_tsf(cpu_n_cpu_num_t cpu_n_cpu_no);
//#define cpu_n_cpu_get_ac_tsf(cpu_n_cpu_no) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_AC_TSF)

/* ############################################################################ */
/**
 * \brief   Function to get CPU_N_CPU access control Interrupt Request (IRQ) status
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 *
 * \return Value of current access control Interrupt Request (IRQ) status
 * 
 */
uint16_t cpu_n_cpu_get_ac_irq_set(cpu_n_cpu_num_t cpu_n_cpu_no);
//#define cpu_n_cpu_get_ac_irq_set(cpu_n_cpu_no) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_AC_IRQ_SET)

/* ############################################################################ */
/**
 * \brief   Function to get CPU_N_CPU access control Interrupt Request (IRQ) clear status
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 *
 * \return Value of current access control Interrupt Request (IRQ) clear status
 * 
 */
uint16_t cpu_n_cpu_get_ac_irq_clr(cpu_n_cpu_num_t cpu_n_cpu_no);
//#define cpu_n_cpu_get_ac_irq_clr(cpu_n_cpu_no) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_AC_IRQ_CLR)

//******************************************************************************
// TEST/SET FLAGS
//******************************************************************************

/* ############################################################################ */
/**
 * \brief   Function to clear CPU_N_CPU access control TS Flags
 *
 * \ingroup cpu_n_cpu
 *
 * \param ts_flag_no Value to clear the flags
 *
 */
uint16_t cpu_n_cpu_test_set_flag(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t ts_flag_no);
//#define cpu_n_cpu_test_set_flag(cpu_n_cpu_no, ts_flag_no) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_TSF0 + 2*ts_flag_no)

/* ############################################################################ */
/**
 * \brief   Function to clear CPU_N_CPU access control TS Flags
 *
 * \ingroup cpu_n_cpu
 *
 * \param ts_flag_no Value to clear the flags
 *
 */
void cpu_n_cpu_clr_ts_flag(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t ts_flag_no);
//#define cpu_n_cpu_clr_ts_flag(cpu_n_cpu_no, ts_flag_no) WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_TSF0 + 2*ts_flag_no, 0xFFFF)

/* ############################################################################ */
/**
 * \brief   Function to get CPU_N_CPU access control TS Flags
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 *
 * \return Value of current access control TS Flags
 * 
 */
uint16_t cpu_n_cpu_get_ts_flags(cpu_n_cpu_num_t cpu_n_cpu_no);

//******************************************************************************
// IRQ FLAGS
//******************************************************************************

/* ############################################################################ */
/**
 * \brief Function to set CPU_N_CPU access control Interrupt Request (IRQ) Flag Set
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 *
 * \param set_no                   When access is permitted (AC_IRQ_SET(set_no)='1'): <br>
 *                                   • set_no=0..15: sets interrupt flag with number set_no set_no >15: no action <br>
 *                                 When access is disallowed (AC_IRQ_SET(set_no)='0'): <br>
 *                                   • no action
 *
 */
void cpu_n_cpu_set_irq_flag(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t set_no);
//#define cpu_n_cpu_set_irq_flag(cpu_n_cpu_no, set_no) WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR, (0xFF00 | set_no))  

/* ############################################################################ */
/**
 * \brief Function to set CPU_N_CPU access control Interrupt Request (IRQ) Flag Clear
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 *
 * \param clr_no                   When access is permitted (AC_IRQ_CLR(clr_no)='1'): <br>
 *                                   • set_no=0..15 clears interrupt flag with number clr_no clr_no>15: no action <br>
 *                                 When access is disallowed (AC_IRQ_CLR(clr_no)='0'): <br>
 *                                   • no action
 */
 
void cpu_n_cpu_clr_irq_flag(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t clr_no);
//#define cpu_n_cpu_clr_irq_flag(cpu_n_cpu_no, clr_no) WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR, (0x00FF | (clr_no << 8)))

/* ############################################################################ */
/**
 * \brief Function to set CPU_N_CPU access control Interrupt Request (IRQ) Flag Clear
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 *
 * \param set_no                   When access is permitted (AC_IRQ_SET(set_no)='1'): <br>
 *                                   • set_no=0..15: sets interrupt flag with number set_no set_no >15: no action <br>
 *                                 When access is disallowed (AC_IRQ_SET(set_no)='0'): <br>
 *                                   • no action
 * 
 * \param clr_no                   When access is permitted (AC_IRQ_CLR(clr_no)='1'): <br>
 *                                   • set_no=0..15 clears interrupt flag with number clr_no clr_no>15: no action <br>
 *                                 When access is disallowed (AC_IRQ_CLR(clr_no)='0'): <br>
 *                                   • no action
 */
void cpu_n_cpu_set_clr_irq_flag(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t set_no, uint16_t clr_no);
//#define cpu_n_cpu_set_clr_irq_flag(cpu_n_cpu_no, set_no, clr_no) WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQFLAGS_SET_CLR, (0x0000 | set_no | clr_no << 8))

//======================= IRQ ===========================================

/* ############################################################################ */
/**
 * \brief Function to set CPU_N_CPU Interrupt Request (IRQ) Mask 0
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \param mask                     Enable irq source: <br>
 *                                   1: enabled <br>
 *                                   0: disabled
 */
void cpu_n_cpu_set_irq_mask0(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t mask);
//#define cpu_n_cpu_set_irq_mask0(cpu_n_cpu_no, mask) WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_MASK0, mask) 

/* ############################################################################ */
/**
 * \brief Function to get CPU_N_CPU Interrupt Request (IRQ) Mask 0
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \return                         Enable irq source: <br>
 *                                   1: enabled <br>
 *                                   0: disabled
 */
uint16_t cpu_n_cpu_get_irq_mask0(cpu_n_cpu_num_t cpu_n_cpu_no);
//#define cpu_n_cpu_get_irq_mask0(cpu_n_cpu_no) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_MASK0) 

/* ############################################################################ */
/**
 * \brief Function to set CPU_N_CPU Interrupt Request (IRQ) Mask 1
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \param mask                     Enable irq source: <br>
 *                                   1: enabled <br>
 *                                   0: disabled
 */
void cpu_n_cpu_set_irq_mask1(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t mask);
//#define cpu_n_cpu_set_irq_mask1(cpu_n_cpu_no, mask) WRITE_REG_16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_MASK1, mask)

/* ############################################################################ */
/**
 * \brief Function to get CPU_N_CPU Interrupt Request (IRQ) Mask 1
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \return                         Enable irq source: <br>
 *                                   1: enabled <br>
 *                                   0: disabled
 */
uint16_t cpu_n_cpu_get_irq_mask1(cpu_n_cpu_num_t cpu_n_cpu_no);
//#define cpu_n_cpu_get_irq_mask1(cpu_n_cpu_no) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_MASK1) 

/* ############################################################################ */
/**
 * \brief Function to get CPU_N_CPU Interrupt Request (IRQ) Status 0
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \return                         1: irq pending
 */
uint16_t cpu_n_cpu_get_irq_status0(cpu_n_cpu_num_t cpu_n_cpu_no);
//#define cpu_n_cpu_get_irq_status0(cpu_n_cpu_no) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_STATUS0) 

/* ############################################################################ */
/**
 * \brief Function to get CPU_N_CPU Interrupt Request (IRQ) Status 1
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \return                         Inverted values of ts_flags (TSF free) <br>
 *                                 1: irq pending
 */
uint16_t cpu_n_cpu_get_irq_status1(cpu_n_cpu_num_t cpu_n_cpu_no);
//#define cpu_n_cpu_get_irq_status1(cpu_n_cpu_no) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_STATUS1) 

/* ############################################################################ */
/**
 * \brief Function to enable CPU_N_CPU Interrupt Request (IRQ) vector
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \param vno                     Vector number of interrupt to enable
 */
void cpu_n_cpu_irq_venable(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t vno);

/* ############################################################################ */
/**
 * \brief Function to disable CPU_N_CPU Interrupt Request (IRQ) vector
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \param vno                     Vector number of interrupt to disable
 */
void cpu_n_cpu_irq_vdisable(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t vno);

/* ############################################################################ */
/**
 * \brief Function to set CPU_N_CPU Interrupt Request (IRQ) nesting priority
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \param vmax                    Needed for nested interrupt support <br>
 *                                Software writes current vector number to this register, so only interrupts with higher priority (lower vector number) can nest
 */
void cpu_n_cpu_set_irq_vmax(cpu_n_cpu_num_t cpu_n_cpu_no, uint16_t vmax);

/* ############################################################################ */
/**
 * \brief Function to get CPU_N_CPU Interrupt Request (IRQ) nesting priority
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \return                        Needed for nested interrupt support <br>
 *                                Software writes current vector number to this register, so only interrupts with higher priority (lower vector number) can nest
 */
uint16_t cpu_n_cpu_get_irq_vmax(cpu_n_cpu_num_t cpu_n_cpu_no);
/*
cpu_n_cpu_irq_t cpu_n_cpu_get_irq_vno(cpu_n_cpu_num_t cpu_n_cpu_no);
//#define cpu_n_cpu_get_irq_vno(cpu_n_cpu_no) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_VNO)
*/

/* ############################################################################ */
/**
 * \brief Function to get CPU_N_CPU Interrupt Request (IRQ) vector
 *
 * \ingroup cpu_n_cpu
 *
 * \param cpu_n_cpu_no Select CPU_N_CPU instance
 * 
 * \return                        Vector number of the interrupt
 */
static cpu_n_cpu_irq_t cpu_n_cpu_get_irq_vno(cpu_n_cpu_num_t cpu_n_cpu_no){
        return (cpu_n_cpu_irq_t) READ_REG_U16(cpu_n_cpu_no + ADDR_CPU_N_CPU_IRQ_VNO);
}

/**@} */
#endif /* HAVE_CPU_N_CPU_H */


