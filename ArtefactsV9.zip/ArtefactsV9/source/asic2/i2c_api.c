#include "hardware.h"
#include "i2c_api.h"
#include "clk_nres_api.h"

#define I2C_API_READ  1
#define I2C_API_WRITE 0

#define I2C_API_ERROR_FLAG ((BIT_I2C_IRQ_STATUS_EVT_REC_FIFO_OV_ERR)| \
                            (BIT_I2C_IRQ_STATUS_EVT_REC_FIFO_UR_ERR)| \
                            (BIT_I2C_IRQ_STATUS_EVT_CMD_FIFO_OV_ERR)| \
                            (BIT_I2C_IRQ_STATUS_EVT_CMD_FIFO_UR_ERR)| \
                            (BIT_I2C_IRQ_STATUS_EVT_ACK_ERR)|         \
                            (BIT_I2C_IRQ_STATUS_EVT_BIT_ERR))
                        

/* Read Data */
static void (*ptr_fce_i2c_callback_read_done)(void);

volatile uint8_t *g_ReadData_puBuffer;
static uint8_t g_ReadData_ucSize;
volatile uint16_t g_ReadData_unCounter;

/* Command Data */
volatile bool g_bCmdDataBusy = false;

volatile uint16_t *g_CmdData_puBuffer;
static uint8_t g_CmdData_ucSize;
volatile uint16_t g_CmdData_unCounter;

static uint8_t  g_nuReadDataSize;
static uint8_t  g_nuCmdDataSize;

/* ############################################################################ */
void i2c_api_init(uint32_t i2c_freq){
  
  uint32_t clk;
  uint16_t divider;
  
  if(clk_nres_api_get_module_clock(CLKPNO_I2C, &clk)!=eError_none) {
    // No correct clock freq. value get for I2C */
    while(1);
  }
  
  /*    -> Ecuation:
   *
   *                     system clock
   *    baud divider = ----------------
   *                    8 * baud rate
   *
   */
  divider = clk / (i2c_freq * 8);
  
  i2c_init(divider);
  i2c_set_cmd_low_water( 4 );
  
}

/* ############################################################################ */
void i2c_api_master_write_data(uint8_t device_address, uint8_t *data, uint16_t data_size){
  
  uint16_t counter = 0;
  uint16_t command;
  
  /* First command: select the device */
  i2c_command( I2C_SEND | I2C_START, (device_address << 1) | I2C_API_WRITE );
  
  /* Send rest of the data */
  while(counter < data_size){
    
    command = I2C_SEND;
    if( counter == data_size-1 )
    {
      command |= I2C_STOP;
    }
    i2c_command( command, data[counter] );
    counter++;
  }
}

/* ############################################################################ */
void i2c_api_master_read_data(uint8_t device_address, uint8_t *data, uint16_t data_size){
  
  uint16_t counter = 0;
  uint16_t command;
  
  /* First command: select the device - read command (last one) */
  i2c_command( I2C_SEND | I2C_START, (device_address << 1) | I2C_API_READ);
  
  while (counter < data_size) {
    
    /* Select correct command */
    if (counter == data_size-1) {
      command = I2C_ACK1 | I2C_STOP;  // maybe I2C_ACK0
    } else {
      command = I2C_ACK0  | I2C_RECV;
    }

    /* receive data */
    i2c_command( command, 0 );

    /* get data - blocking */
    data[counter] = i2c_get_recv_data();
    counter++;
  }
}

/* ############################################################################ */
void i2c_api_master_write_data_irq(uint8_t device_address, uint8_t *data, uint16_t data_size){
  
  /* First command: select the device */
  //i2c_command( I2C_SEND | I2C_START, (device_address << 1) | I2C_API_WRITE );
  g_CmdData_puBuffer[0]=I2C_SEND | I2C_START | (device_address << 1) | I2C_API_WRITE;
  
  uint8_t unCounter=1;
  /* Send rest of the data */
  while( unCounter <= data_size) 
  {
    
    g_CmdData_puBuffer[unCounter] = I2C_SEND;
    if (unCounter == data_size) 
    {
      g_CmdData_puBuffer[unCounter] |=I2C_STOP;
    }
    
    g_CmdData_puBuffer[unCounter] |= data[unCounter-1];
    unCounter++;
  }

  g_bCmdDataBusy = true;
  if (data_size > g_nuReadDataSize)
  {
    data_size = g_nuReadDataSize;
  }
  g_CmdData_ucSize = data_size;
  
  g_CmdData_unCounter  = 0;
  
  
  if( data_size > g_nuCmdDataSize )
  {
    data_size = g_nuCmdDataSize;
  }
  g_ReadData_ucSize = data_size;
  
  g_ReadData_unCounter  = 0;
    
  i2c_enable_irq(I2C_IRQ_REC_FIFO_HIGH_WATER, true);
  i2c_enable_irq(I2C_IRQ_CMD_FIFO_LOW_WATER, true);
}

/* ############################################################################ */
bool i2c_api_master_cmd_data_busy_get(void) {
  return(g_bCmdDataBusy);
}

/* ############################################################################ */
void i2c_api_master_read_data_irq(uint8_t device_address, uint16_t data_size){
  /* prepare commands for I2C */  
  
  /* First command: select the device - read command (last one) */
  g_CmdData_puBuffer[0]=I2C_SEND | I2C_START | (device_address << 1) | I2C_API_READ;
  
  uint8_t unCounter=1;
  while( unCounter <= data_size) 
  {
    /* Select correct command */
    if (unCounter == data_size) 
    {
      g_CmdData_puBuffer[unCounter] = I2C_ACK1 | I2C_STOP;  // maybe I2C_ACK0
    } else 
    {
      g_CmdData_puBuffer[unCounter] = I2C_ACK0  | I2C_RECV;
    }
    unCounter++;
  }

  g_CmdData_ucSize = data_size;
  g_CmdData_unCounter  = 0;

  //g_ReadData_puBuffer = data;
  g_ReadData_ucSize = data_size;
  g_ReadData_unCounter  = 0;

  i2c_enable_irq(I2C_IRQ_REC_FIFO_HIGH_WATER, true);
  i2c_enable_irq(I2C_IRQ_CMD_FIFO_LOW_WATER, true);
}

/* ############################################################################ */
/* ############################ INTERRUPT CONFIGURATION ####################### */
/* ############################################################################ */

/* ########################################################################## */    
errors_api_code_e m_eErrorCode = eError_none;

/* ########################################################################## */    
void i2c_api_error_clr(void) {
  m_eErrorCode = eError_none;
  i2c_clear_all_irq_events();
}

/* ########################################################################## */    
errors_api_code_e i2c_api_error_get(void) {

  i2c_irq_status_t m_eI2CirqStatus;
  
  m_eI2CirqStatus = i2c_get_irq_status();
  
  if (( m_eI2CirqStatus.val) & (I2C_API_ERROR_FLAG )) {
    m_eErrorCode |= eError_i2c_api_error;
  }
  
  return(m_eErrorCode);
}

/* ########################################################################## */    
/*
 * I2C interrupt routine (master implementation)
 */
_INTERRUPT_ IRQ_I2C_Handler( void ) {

  i2c_irq_t irq = i2c_get_next_pending_irq();
  switch(irq) {
  case I2C_IRQ_EVT_REC_FIFO_OV_ERR: ///< software did not read incoming data fast enough
  case I2C_IRQ_EVT_REC_FIFO_UR_ERR: ///< software has read from empty receive fifo
  case I2C_IRQ_EVT_CMD_FIFO_OV_ERR: ///< software wrote data to full transmit fifo
  case I2C_IRQ_EVT_CMD_FIFO_UR_ERR: ///< software has not written outgoing data fast enough
  case I2C_IRQ_EVT_ACK_ERR:         ///< acknoledge error
  case I2C_IRQ_EVT_BIT_ERR:         ///< bit error (looped back transmit bit mismatch)
    m_eErrorCode = eError_i2c_api_error;
    break;
  
  case I2C_IRQ_REC_FIFO_NEMPTY:     ///< receive fifo is not empty
  case I2C_IRQ_REC_FIFO_FULL:       ///< receive fifo is full
  case I2C_IRQ_CMD_FIFO_EMPTY:      ///< transmit fifo is empty
  case I2C_IRQ_CMD_FIFO_NFULL:      ///< transmit fifo is not full
  case I2C_IRQ_SCL_STRETCH:         ///< scl is stretched by slow slave
    break;

  case I2C_IRQ_CMD_FIFO_LOW_WATER:  ///< transmit fifo elements <= low water level
    /* there is some space to put there new commands */ 
    while (i2c_get_cmd_delta()<I2C_CMD_FIFO_DEPTH) 
    {
      /* do it until FIFO is free */
      
      if(g_CmdData_unCounter <= g_CmdData_ucSize) 
      {
        /* there are still commands in buffer */
        WRITE_REG_16(BASE_ADDR_I2C + ADDR_I2C_CMD_DATA, g_CmdData_puBuffer[g_CmdData_unCounter] );
        g_CmdData_unCounter++;
      }
      else 
      {
         /* no commands in buffer */
        i2c_enable_irq(I2C_IRQ_CMD_FIFO_LOW_WATER, false);
        g_bCmdDataBusy = false;
        break;
      }
    }
    break;    
    
  case I2C_IRQ_REC_FIFO_HIGH_WATER: ///< receive fifo elements > high water level
    /* there are data in FIFO */
    while (i2c_get_rec_delta()) 
    {
      /* there are still data if FIFO */
      if (g_ReadData_unCounter < g_ReadData_ucSize) 
      {
        uint16_t unCnt = g_ReadData_unCounter; // Warning[Pa082]
        g_ReadData_puBuffer[unCnt] = READ_REG_U16(BASE_ADDR_I2C + ADDR_I2C_REC_DATA) & 0x00FF;
        g_ReadData_unCounter++;
      }
      
      if (g_ReadData_unCounter == g_ReadData_ucSize) 
      {
        /* we already received all requested data */
        i2c_enable_irq(I2C_IRQ_REC_FIFO_HIGH_WATER, false);
        ptr_fce_i2c_callback_read_done();
        break;
      }
    }
    break;
    

  default:
    break;
  }
  i2c_clear_irq(irq);
}

/* ############################################################################ */
void i2c_api_init_irq(uint8_t par_usi_nvic_priority, uint8_t *pnuReadData, uint8_t nuReadDataSize, uint16_t *pnuCmdData, uint8_t nuCmdDataSize) {

  g_ReadData_puBuffer = pnuReadData;
  g_nuReadDataSize = nuReadDataSize;
  
  g_CmdData_puBuffer = pnuCmdData;
  g_nuCmdDataSize = nuCmdDataSize;
    
  i2c_set_irq_mask(I2C_API_ERROR_FLAG);
  
  IRQn_Type i_IRQn = IRQ_I2C;
  
  /* NVIC Interrupt */
  NVIC_SetPriority(i_IRQn, par_usi_nvic_priority);
  NVIC_EnableIRQ(i_IRQn);
}

/* ############################################################################ */
void i2c_api_master_read_done_reg_callback(void (*p_fce_callback_read_done)(void)) {
  ptr_fce_i2c_callback_read_done = p_fce_callback_read_done;
}
