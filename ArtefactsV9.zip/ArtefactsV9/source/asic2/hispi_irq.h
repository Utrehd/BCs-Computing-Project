/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hispi_irq.h
*
* @brief        SPI Host interface HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HISPI_IRQ_H__
#define __HISPI_IRQ_H__

#define HISPI_NUM_IRQS 4


/* ############################################################################ */
/**
 * \brief List of HISPI Interrupt sources 
 *
 * \ingroup hispi 
 */ 
typedef enum{
  /**
   * End of incoming transfer
   */ 
  HISPI_IRQ_EVT_TRF_DONE =              0,
  /**
   * Set when an address outside the defined windows is accessed
   */ 
  HISPI_IRQ_EVT_ACCESS_ERR =            1,
  /**
   * Set on SPI errors (e.g. word was interrupted by cs)
   */ 
  HISPI_IRQ_EVT_SPI_ERR =               2,
  /**
   * Set when the number of data words in a read transfer is not equal the length given in the control field
   */ 
  HISPI_IRQ_EVT_LEN_ERR =               3
} hispi_irq_t;

#endif
