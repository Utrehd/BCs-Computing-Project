/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         el_ctrl_irq.h
*
* @brief        Electronic Label HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __EL_CTRL_IRQ_H__
#define __EL_CTRL_IRQ_H__

#define EL_CTRL_NUM_IRQS 15

/**
  * \brief This is an enum class for CPU_N_CPU describing IRQ events
  *
  * \ingroup el_ctrl
  */ 
typedef enum{
  EL_CTRL_IRQ_CYC_START_EVT =           0, ///< start of cycle
  EL_CTRL_IRQ_RECV_START_EVT =          1, ///< preamble detected, start of rx phase
  EL_CTRL_IRQ_TRANS_START_EVT =         2, ///< start of transmission detected
  EL_CTRL_IRQ_TX_EMPTY =                3, ///< transmit fifo empty
  EL_CTRL_IRQ_TX_FULL =                 4, ///< transmit FIFO full
  EL_CTRL_IRQ_TX_LOW_WATER =            5, ///< transmit FIFO less than 4 elements
  EL_CTRL_IRQ_TX_END_EVT =              6, ///< tx phase completed (led pat phase might still be ongoing)
  EL_CTRL_IRQ_RX_EMPTY =                7, ///< receive fifo empty
  EL_CTRL_IRQ_RX_HIGH_WATER =           8, ///< receive fifo more than 4 elements
  EL_CTRL_IRQ_RX_FIFO_TIMEOUT =         9, ///< Timeout occurs when rx fifo is not empty and when Manchester decoder is idle
  EL_CTRL_IRQ_RX_DATA_INCOMPLETE_EVT =  10, ///< 1: set when Manchester decoder “idle” and received data bits mod 8 != 0
  EL_CTRL_IRQ_RX_OVERRUN_EVT =          11, ///< receive fifo overrun
  EL_CTRL_IRQ_RX_END_EVT =              12, ///< receive completed
  EL_CTRL_IRQ_CYC_INCOMPLETE_EVT =      13, ///< cyc start event outside of TX PAT
  EL_CTRL_IRQ_MEAS_BR_EVT =             14 ///< bit rate extraction result register has been updated
} el_ctrl_irq_t;

#endif
