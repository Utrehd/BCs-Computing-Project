/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hv_ctrl.h
*
* @brief        HV Die Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HV_CTRL_H__
#define __HV_CTRL_H__

/**
 * \defgroup hv_ctrl ASIC2 HV Die Control HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control HV Die Control
 */
/**@{*/ 

#include "hv_ir_bf.h"
#include "hv_ctrl_bf.h"
#include "hv_ctrl_irq.h"
#include "device.h"


/* ############################################################################ */
/**
 * \brief This is an enum class for HV CONTROL to identify output voltage
 *
 * \ingroup hv_ctrl 
 */ 
typedef enum {
  /**
   * Reduced output voltage vdd3v3 (for external supply)
   */ 
  VREG_VDD3V3_REDUCED           = 0,
  /**
   * Standart output voltage vdd3v3
   */ 
  VREG_VDD3V3_3V3               = 1
} vreg_vdd3v3_max_t;            
                                

/* ############################################################################ */
/**
 * \brief This is an enum class for HV CONTROL to identify nominal range
 *
 * \ingroup hv_ctrl 
 */ 
typedef enum {                  
  /**
   * 4 … 16V nominal range
   */ 
  PW_VPOW_RANGE_4_16            = 0,
  /**
   * 8 … 32V nominal range
   */ 
  PW_VPOW_RANGE_8_32            = 1 
} pw_vpow_range_t;              
                                

/* ############################################################################ */
/**
 * \brief This is an enum class for HV CONTROL to identify transitions when slew rate is off
 *
 * \ingroup hv_ctrl 
 */ 
typedef enum {                  
  /**
   * Between driven '0' and '1' is done with overlapping of P and N drivers for a short time. In this mode the bus is always driven
   */ 
  HTX485_DRIVE_ALWAYS           = 0, 
  /**
   * Break-before-make (with transient tri-state)
   */ 
  HTX485_BREAK_BEFORE_MAKE      = 1
} htx485_bbm_fast_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for HV CONTROL to identify auto shutdown
 *
 * \ingroup hv_ctrl 
 */ 
typedef enum {
  /**
   * Temperature error ignored
   */ 
  HTX485_IGNORE_TEMP_ERROR      = 0,
  /**
   * Synchronous shut down: <br>
   * - tx_enable@phy will be asserted when tx_enable@pad is asserted and temperature is ok <br>
   * - tx_enable@phy will be released only when tx_enable@pad is released (stays on, even if temperature errors occurs, to ensures that the transmission is finished)
   */ 
  HTX485_FINISH_TRANSMISSION    = 2,
  /**
   * Asychronous shut down: <br>
   * - tx_enable@phy is off, when temperature error is active
   */ 
  HTX485_ASYNCHRONOUS_SHUTDOWN  = 3
} htx485_auto_shutdown_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for HV CONTROL to identify temperature sensor configuration
 *
 * \ingroup hv_ctrl 
 */ 
typedef enum {
  /**
   * Temperature sensor is always off
   */ 
  HTX485_TEMPSENSE_OFF          = 0,
  /**
   * Temperature sensor is enabled / disabled with tx_enable@pad, but stays on, when a temperature orror occurs
   */ 
  HTX485_TEMPSENSE_HW_ON_OFF    = 2,
  /**
   * Temperature sense is always on
   */ 
  HTX485_TEMPSENSE_ALWAYS_ON    = 3
} htx485_tempsens_enable_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for HV CONTROL to identify masks temperature errors
 *
 * \ingroup hv_ctrl 
 */ 
typedef enum {
  /**
   * No temperature errors
   */ 
  HTX485_TEMPSENSE_NO_ERRORS    = 0,
  /**
   * htx485_temperror
   */ 
  HTX485_TEMPSENSE_HTX485_ERR   = 1,
  /**
   * vdd5tx_temperror
   */ 
  HTX485_TEMPSENSE_VDD5TX_ERR   = 2,
  /**
   * Both temperature errors
   */ 
  HTX485_TEMPSENSE_ALL_ERRORS   = 3
} htx485_tempsens_mask_t;

//==========================================================================
// low level functions
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to check request by CPU
 *
 * \ingroup hv_ctrl 
 */ 
bool hv_ctrl_is_cpu_request(void);

/* ############################################################################ */
/**
 * \brief Function to perform TAP reset sequence instead of IR shift
 *
 * \ingroup hv_ctrl 
 */ 
void hv_ctrl_tap_reset(void);


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL JTAG IR command
 *
 * \ingroup hv_ctrl 
 * 
 * \param ir Perform JTAG IR command when status=0
 * 
 * \param read 1: perform dummy DR shift after IR shift for reading
 * 
 * \return Read previously fetched data from IR read / DR write. <B>Remark: read only valid when status = 0</B>
 */ 
uint16_t hv_ctrl_ir_shift(uint8_t ir, bool read);


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL JTAG DR command
 *
 * \ingroup hv_ctrl 
 * 
 * \param dr Perform JTAG DR command when status = 0
 * 
 * \return Read previously fetched data from IR read / DR write. <B>Remark: read only valid when status = 0</B>
 */ 
uint16_t hv_ctrl_dr_shift(uint16_t dr);

//==========================================================================
// JTAG functions
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to reset HV CONTROL JTAG
 *
 * \ingroup hv_ctrl 
 * 
 * \param nres 0: reset HV die
 */ 
void hv_ctrl_set_nres(bool nres);


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL JTAG timing
 *
 * \ingroup hv_ctrl 
 * 
 * \param timing Length of JTAG bit time in clock cycles (>=3)
 */ 
void hv_ctrl_cfg_timing(uint8_t timing);

//==========================================================================
// pad drive
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL physical drive strength
 *
 * \ingroup hv_ctrl 
 * 
 * \param ds 
 */ 
void hv_ctrl_set_phy_ds(bool ds);


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL JTAG drive strength
 *
 * \ingroup hv_ctrl 
 * 
 * \param ds 
 */ 
void hv_ctrl_set_jtag_ds(bool ds);

//==========================================================================
// HV Die functions
//==========================================================================


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL power configuration
 *
 * \ingroup hv_ctrl 
 * 
 * \param vreg_vdd5tx_npd                  0:regulator is off <br>
 *                                         1: reglator is on
 * 
 * \param pw_vdd5tx_npd                    1: powerwatch vdd5tx is on
 * 
 * \param vreg_vdd3v3_max                  0: reduced output voltage vdd3v3 (for external supply) <br>
 *                                         1: standart output voltage vdd3v3
 * 
 * \param pw_vpow_range                    0: 4 … 16V nominal range <br>
 *                                         1: 8 … 32V nominal range
 * 
 * \param pw_vpow_hyst                     Hysteresis adder for rising supply
 */ 
void hv_ctrl_pwr_config(
  bool              vreg_vdd5tx_npd,
  bool              pw_vdd5tx_npd, 
  vreg_vdd3v3_max_t vreg_vdd3v3_max, 
  pw_vpow_range_t   pw_vpow_range, 
  uint8_t                pw_vpow_hyst);


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL power threshold
 *
 * \ingroup hv_ctrl 
 * 
 * \param pw_vpow_vth Threshold of Vpow powerwatch for falling suppy. Note: 0x0 = powerwatch is off
 */
void hv_ctrl_set_pw_vpow_vth(uint8_t pw_vpow_vth);


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL JTAG RS485 configuration
 *
 * \ingroup hv_ctrl 
 * 
 * \param hrx485_npd                       1: Receiver is in functional mode <br>
 *                                         0: Receiver is in power down
 * 
 * \param htx485_npd                       1: Transmitter is in functional mode <br>
 *                                         0: Transmitter is in power down (outputs disabled))
 * 
 * \param htx485_slew_enable               1: Slewrate is in active
 * 
 * \param htx485_bbm_fast                  -> This bit controls transitions when slew rate is off: <br>
 *                                            '1': break-before-make (with transient tri-state) <br>
 *                                            '0': between driven '0' and '1' is done with overlapping of P and N drivers for a short time. In this mode the bus is always driven
 * 
 * \param htx485_auto_shutdown             00: temperature error ignored <br>
 *                                         10: synchronous shut down: <br> 
 *                                             > tx_enable@phy will be asserted when tx_enable@pad is asserted and temperature is ok <br>
 *                                             > tx_enable@phy will be released only when tx_enable@pad is released (stays on, even if temperature errors occurs, to ensures that the transmission is finished) <br>
 *                                         11: asychronous shut down: <br>
 *                                             > tx_enable@phy is off, when temperature error is active
 * 
 * \param htx485_tempsens_enable           00: temperature sensor is always off <br>
 *                                         10: temperature sensor is enabled / disabled with tx_enable@pad, but stays on, when a temperature orror occurs <br>
 *                                         11: temperature sense is always on
 * 
 * \param htx485_tempsens_mask             -> Masks temperature errors (affects htx485_auto_shutdown and htx485_tempsens_enable): <br>
 *                                            00: no temperature errors <br>
 *                                            01: htx485_temperror <br>
 *                                            10: vdd5tx_temperror <br>
 *                                            11: both temperature errors
 */ 
void hv_ctrl_cfg_phy(
  bool                      hrx485_npd, 
  bool                      htx485_npd, 
  bool                      htx485_slew_enable, 
  htx485_bbm_fast_t         htx485_bbm_fast, 
  htx485_auto_shutdown_t    htx485_auto_shutdown, 
  htx485_tempsens_enable_t  htx485_tempsens_enable, 
  htx485_tempsens_mask_t    htx485_tempsens_mask);


/* ############################################################################ */
/**
 * \brief Function to enable HV CONTROL JTAG selout
 *
 * \ingroup hv_ctrl 
 * 
 * \param enable 1: Selout powered up
 */ 
void hv_ctrl_set_selout_enable(bool enable);


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL JTAG selout
 *
 * \ingroup hv_ctrl 
 * 
 * \param selout                -> Digital selout data: <br>
 *                                 '0': selout open <br>
 *                                 '1': selout pulls to GND
 */ 
void hv_ctrl_set_selout(bool selout);


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL GPO configuration
 *
 * \ingroup hv_ctrl 
 * 
 * \param en                    -> Output enable: <br>
 *                                 0: High-Z <br>
 *                                 1: Output is driven by hgpo_out
 * 
 * \param val                   Output Data
 */ 
void hv_ctrl_set_gpo(bool en, bool val);


/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL current sinks
 *
 * \ingroup hv_ctrl 
 * 
 * \param no                    -> Identifier of ISINK: <br>
 *                                 0: ISINK0 <br>
 *                                 1: ISINK1 <br>
 *                                 2: ISINK2
 * 
 * \param val                   Output current to be used (0x0: Block is disabled)
 */ 
void hv_ctrl_set_isink(uint8_t no, uint8_t val);


/* ############################################################################ */
/**
 * \brief Function to enable HV CONTROL IR selin
 *
 * \ingroup hv_ctrl 
 * 
 * \param enable 1: Selin powered up
 * \param vlim 1: Voltage limiter on
 */ 
void hv_ctrl_set_selin_enable(bool enable, bool vlim);


/* ############################################################################ */
/**
 * \brief Function to get HV CONTROL IR selin
 *
 * \ingroup hv_ctrl 
 * 
 * \return                      -> Digital selin data: <br>
 *                                 '0': current smaller than threshold <br>
 *                                 '1': current higher than threshold
 */ 
bool hv_ctrl_get_selin(void);


/* ############################################################################ */
/**
 * \brief Function to get HV CONTROL IR selout
 *
 * \ingroup hv_ctrl 
 * 
 * \return                      -> Digital selout data: <br>
 *                                 '0': current smaller than threshold <br>
 *                                 '1': current higher than threshold
 */ 
bool hv_ctrl_get_selout(void);

/* ############################################################################ */
/**
 * \brief Function to set HV CONTROL Housekeeping Multiplexer (hhkmux)
 *
 * \ingroup hv_ctrl 
 * 
 * \param hv_ir_hvhkmux Housekeeping Multiplexer configuration
 *
 */ 
void hv_ctrl_set_r_hvhkmux(hv_ir_hvhkmux_t hv_ir_hvhkmux);

/* ############################################################################ */
/**
 * \brief Function to get HV IR status
 *
 * \ingroup hv_ctrl 
 * 
 * \return                      Current HV IR status
 *                              \see hv_ir_status_t
 */ 
hv_ir_status_t hv_ctrl_get_hv_status(void);


/* ############################################################################ */
/**
 * \brief Function to set HV IR mask
 *
 * \ingroup hv_ctrl 
 * 
 * \param mask 0: mask irq output does not affect value read by IR_STATUS
 */ 
void hv_ctrl_set_hv_mask(uint16_t mask);


/* ############################################################################ */
/**
 * \brief Function to enable HV CONTROL EL port requests
 *
 * \ingroup hv_ctrl 
 * 
 * \param en 1: Enable
 */ 
void hv_ctrl_set_gpo_el_req_enable(bool en);

//==========================================================================
// IRQs
//==========================================================================


/* ############################################################################ */
/**
 * \brief Function to enable HV CONTROL Interrupt
 *
 * \ingroup hv_ctrl 
 * 
 * \param irq                   Select Interrupt number <br>
 *                              \see hv_ctrl_irq_t
 * 
 * \param enable            1: Enable
 */ 
void hv_ctrl_enable_irq(hv_ctrl_irq_t irq, bool enable);


/* ############################################################################ */
/**
 * \brief Function to get HV CONTROL Interrupt status
 *
 * \ingroup hv_ctrl 
 * 
 * \return                      Current interrupt status
 *                              \see hv_ctrl_irq_status_t
 */ 
hv_ctrl_irq_status_t hv_ctrl_get_irq_status(void);


/* ############################################################################ */
/**
 * \brief Function to get HV CONTROL next pending interrupt
 *
 * \ingroup hv_ctrl 
 * 
 * \return                      Vector number of enabled pending interrupt with highest priority (smallest vector number). When no irq is pending the first unused irq number is returned
 *                              \see hv_ctrl_irq_t
 */ 
hv_ctrl_irq_t hv_ctrl_get_pending_irq(void);


/* ############################################################################ */
/**
 * \brief Function to clear HV CONTROL all interrupts
 *
 * \ingroup hv_ctrl 
 */ 
void hv_ctrl_clear_all_irqs(void);

/* ############################################################################ */
/**
 * \brief Function to clear HV CONTROL interrupt
 *
 * \ingroup hv_ctrl 
 * 
 * \param vno Select Interrupt vector number to clear
 */ 
void hv_ctrl_clear_irqs_vno(uint16_t vno);

/**@} */
#endif /* __HV_CTRL_H__ */
