#include <hardware.h>
#include <usi_spi_dma.h>
#include "bugs.h"


#define USI_SPI_DMA_FIFO_LENGTH 2

static volatile uint8_t g_usi_fifo=0;

/* ########################################################################## */    
static void (*ptr_fce_usi_callback_rx_done[NUMBER_USI])(void);
static void (*ptr_fce_usi_callback_error[NUMBER_USI])(void);

/* ########################################################################## */  
typedef struct {
  volatile usi_dma_rxcfg_t rx_config; ///< data structure for receive data for USI DMA
  volatile usi_dma_txcfg_t tx_config; ///< data structure for transmit data for USI DMA
} usi_wrp_struct_t;

/* ########################################################################## */  
static volatile usi_wrp_struct_t glob_usi_wrp_struct[NUMBER_USI][USI_SPI_DMA_FIFO_LENGTH];
static volatile bool glob_usi_wrp_struct_lock[NUMBER_USI][USI_SPI_DMA_FIFO_LENGTH];
static bool g_slave_nmaster;

/* ########################################################################## */    
/*
 * This interrupt routine will work only with SPI in slave mode !!!
 */
void usi_spi_dma_interrupt_subroutine(usi_num_t usi_no ) {
  
  uint8_t i_usi;
  i_usi = usi_no_to_index(usi_no);

  usi_irq_t irq = usi_get_next_pending_irq(usi_no);
  switch(irq) {

  case USI_IRQ_REVENTS_0: //spi: dma receive timeout - should never come when recv timeozt = 0
  case USI_IRQ_REVENTS_1: //word length error - real error - not recv all bits of a word
  case USI_IRQ_REVENTS_3: //spi: never
  case USI_IRQ_REVENTS_4: //spi: never
  case USI_IRQ_RADR_NEW_UDR:
    ptr_fce_usi_callback_error[i_usi]();
    break;
    
  case USI_IRQ_REVENTS_2: //sck timeout - NO ERROR!!!
    if(g_slave_nmaster) {
      /* SLAVE */
      /* read done */
      usi_dma_get_radr_done(usi_no);
      usi_dma_get_tadr_done(usi_no);

      /* unlock */
      glob_usi_wrp_struct_lock[i_usi][g_usi_fifo]=false;

      /* run callback */
      ptr_fce_usi_callback_rx_done[i_usi]();
    }
    break;
    
  case USI_IRQ_RADR_NEW_NFULL:
    break;

  case USI_IRQ_RADR_DONE_NEMPTY:
    if(!g_slave_nmaster) {
      /* MASTER */
      /* read done */
      usi_dma_get_radr_done(usi_no);
      usi_dma_get_tadr_done(usi_no);

      /* unlock */
      glob_usi_wrp_struct_lock[i_usi][g_usi_fifo]=false;

      /* run callback */
      ptr_fce_usi_callback_rx_done[i_usi]();
    }
    break;

  default:
    break;
  }
  usi_clear_irq(usi_no, irq);
}

/* ########################################################################## */  
  /* Baudrate */
  /* Examples 
   * 7.3728MHz / (32 * 48) = 4800
   * 7.3728MHz / (192) = 38400
   * 7.3728MHz / (32) = 230400
   *
   * 60MHz / 60 = 1MHz
   *
   * 16 / (30*2) = 
   */
  
/* acc = (acc + BR_INC) % BR_MOD generates ticks */ 

/* 
  static uint16_t g_br_mod[] = {60,60} ;     // @@@ {30,30};       // [comm_clk]
  static uint16_t g_br_inc[] = {1,1};        // [comm_clk]
  static uint8_t g_bit_length[] = {200,200}; // @@@ {2,2};     // [ticks]
*/
  static uint16_t g_br_mod[] = {30,30} ;     // @@@ {30,30};       // [comm_clk]
  static uint16_t g_br_inc[] = {1,1};        // [comm_clk]
  static uint8_t g_bit_length[] = {2,2}; // @@@ {2,2};     // [ticks]


/* ########################################################################## */  
void usi_spi_dma_baudrate(const usi_num_t usi_no, uint16_t par_br_mod, uint16_t par_br_inc, uint8_t par_bit_length)
{
  uint8_t i_usi;
  
  switch(usi_no) {
    case USI0: 
      i_usi=0;
      break;
      
    case USI1: 
      i_usi=1;      
      break;
      
    default: 
      /* ERROR */
      return; 
  }
  g_br_mod[i_usi] = par_br_mod;
  g_br_inc[i_usi] = par_br_inc;
  g_bit_length[i_usi] = par_bit_length;
}

/* ########################################################################## */  
void usi_spi_dma_clock(const usi_num_t usi_no, clock_source_t par_as_clock_source, uint8_t par_div) {

  clkpno_t i_clkpno;
  clk_domain_t i_as_clkpno;
  
  switch(usi_no) {
    case USI0: 
      i_clkpno = CLKPNO_USI0; 
      i_as_clkpno = AS_USI0;
      break;
      
    case USI1: 
      i_clkpno = CLKPNO_USI1; 
      i_as_clkpno = AS_USI1;
      break;
      
    default: 
      /* ERROR */
      return; 
  }

  /* CLK_NRES setup */
  wdog_unlock_guard(GUARD0);
  clk_nres_unlock();  
    /* assert reset */
    clk_nres_set_as_nreset(i_as_clkpno, false);
    clk_nres_set_nreset(i_clkpno, false);

    /* clock */
    clk_nres_set_clk_divider(i_as_clkpno, par_div);
    clk_nres_sel_clk_root(i_as_clkpno, par_as_clock_source);
    clk_nres_enable_as_clock_domain(CLK_NRES_0, i_as_clkpno, true);
    clk_nres_enable_clock_partition(CLK_NRES_0, i_clkpno, true);
        
    /* release reset */
    clk_nres_set_as_nreset(i_as_clkpno, true);
    clk_nres_set_nreset(i_clkpno, true);
    
  wdog_disable (GUARD0); // GUARD disable
  while (wdog_is_running (GUARD0)); 
  
}


/* ########################################################################## */  
void usi_spi_dma_init(const usi_num_t usi_no, const bool i_slave_nmaster, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode) {

  usi_irq_set_spi_Nuart(usi_no, USI_MODE_SPI);
  
  g_slave_nmaster = i_slave_nmaster;
  
  uint8_t i_usi;
  
  switch(usi_no) {
    case USI0: 
      i_usi = 0;
      break;
      
    case USI1: 
      i_usi = 1;
      break;
      
    default: 
      /* ERROR */
      return; 
  }

  uint16_t i_br_mod = g_br_mod[i_usi];
  uint16_t i_br_inc = g_br_inc[i_usi];
  uint8_t i_bit_length = g_bit_length[i_usi];

  
  glob_usi_wrp_struct_lock[i_usi][g_usi_fifo]=false;
  
  usi_clear_revents(usi_no);

  usi_full_enable(usi_no, false); /* To be able to change configuration */
  usi_cfg_mode(usi_no, USI_MODE_SPI); /* Enable SPI mode */
  usi_cfg_sdi_sdo_loopback(usi_no, false); /* */
 
  usi_cfg_br_mod(usi_no, i_br_mod);
  usi_cfg_br_inc(usi_no, i_br_inc);
  usi_set_bre_mode(usi_no, USI_BRE_OFF); 
  usi_dma_cfg_rx_timeout(usi_no, 0); // @@@ disabled 0xFFFF);
  usi_spi_cfg_phase(usi_no, par_phase);
  usi_spi_cfg_polarity(usi_no, par_polarity);
  usi_spi_cfg_msb_first(usi_no, par_msb_first);
  
  switch(par_bit_data_length) {
  case DATA_FRAME_8B:
    usi_spi_cfg_data_bits(usi_no, USI_SPI_DATA_LEN_8);
    break;
    
  case DATA_FRAME_16B:
    usi_spi_cfg_data_bits(usi_no, USI_SPI_DATA_LEN_16);
    break;
    
  default:
    /* ERROR */
    return; 
  } 
    
  usi_spi_cfg_slave_nmaster(usi_no, i_slave_nmaster);
  usi_spi_cfg_nss_mode(usi_no, par_nss_mode);
  
  

  
  
  
  usi_spi_cfg_sck_timeout_bitlength_sel(usi_no, USI_SPI_SCK_TIMEOUT_TICK); // @@@ Change1 USI_SPI_SCK_TIMEOUT_DETECT);
  usi_cfg_tick_bit_length(usi_no, i_bit_length);
  usi_spi_cfg_sck_timeout(usi_no, 40);
  
 
  /* 
   * dma_tx _mode & dma_rx _mode 
   * DMA transfer ands when tdlen/maxlen in reached
   */
  usi_spi_cfg_tx_dma_mode(usi_no, (bool)USI_DMA_MODE_LENGTH);
  usi_spi_cfg_rx_dma_mode(usi_no, (bool)USI_DMA_MODE_LENGTH);
  usi_spi_set_cfg_early_sdo(usi_no, 0); 
  
  usi_full_enable(usi_no, true);

}

/* ########################################################################## */  
void usi_spi_dma_frame(usi_num_t usi_no, uint8_t par_number_of_data, void * par_p_snd_data, void * par_p_rcv_data) {

  uint8_t i_usi;
  
  switch(usi_no) {
    case USI0: 
      i_usi = 0;
      break;
      
    case USI1: 
      i_usi = 1;
      break;
      
    default: 
      /* ERROR */
      return; 
  }
  
  if (glob_usi_wrp_struct_lock[i_usi][g_usi_fifo]) {
    /* ERROR */
    while(1);
  };
  
  glob_usi_wrp_struct_lock[i_usi][g_usi_fifo]=true;
  
  /* TX */
  glob_usi_wrp_struct[i_usi][g_usi_fifo].tx_config.tcfg = (0<<1) | (0<<0); 
  glob_usi_wrp_struct[i_usi][g_usi_fifo].tx_config.tdadr = (uint16_t)(0x0000FFFF & POINTER_TO_ADDRESS(par_p_snd_data));
  glob_usi_wrp_struct[i_usi][g_usi_fifo].tx_config.tdlen = par_number_of_data;

  /* RX */
  glob_usi_wrp_struct[i_usi][g_usi_fifo].rx_config.maxlen = par_number_of_data;
  glob_usi_wrp_struct[i_usi][g_usi_fifo].rx_config.rdadr = (uint16_t)(0x0000FFFF & POINTER_TO_ADDRESS(par_p_rcv_data));
  glob_usi_wrp_struct[i_usi][g_usi_fifo].rx_config.rdlen = 0; /* JUST CLEAR - NO FUNCTIONALITY */

  /* Fill in DMAs */
  /* RX */
  if (usi_radr_new_is_nfull(usi_no)) {
    usi_dma_set_radr_new(usi_no, 0x0000FFFF&(POINTER_TO_ADDRESS(&(glob_usi_wrp_struct[i_usi][g_usi_fifo].rx_config))));
  }
  else {
    // USI DMA FIFO overloaded 
    /* ??? SCK Timeout arrived in correct time ??? */
    printf("ERROR\n"); // JUST IN CASE WHEN THIS ERROR OCCUER I CAN FIX IT AFTER THAT 
    return;
  }
  
  /* TX */
  if (usi_tadr_new_is_nfull(usi_no)) {  
    usi_dma_set_tadr_new(usi_no, 0x0000FFFF&(POINTER_TO_ADDRESS(&(glob_usi_wrp_struct[i_usi][g_usi_fifo].tx_config))));
  }
  else {
    /* USI DMA FIFO overloaded */
    printf("ERROR\n");
    return;
  }
  g_usi_fifo=((g_usi_fifo+1)%USI_SPI_DMA_FIFO_LENGTH);
}

/* ########################################################################## */  
/* Wrappers which should be moved to test_usi_spi */
/* ########################################################################## */  
void usi_spi_dma_slave_baudrate(uint16_t par_br_mod, uint16_t par_br_inc, uint8_t par_bit_length) {
  /* DUMMY - SLAVE does not known baudrates */
}

/* ########################################################################## */  
void usi_spi_dma_slave_init(const usi_num_t usi_no, clock_source_t par_as_clock_source, uint8_t par_div, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode) {
  usi_spi_dma_clock(usi_no, par_as_clock_source, par_div);
  usi_spi_dma_init(usi_no, true, par_bit_data_length, par_phase, par_polarity, par_msb_first, par_nss_mode);
}

/* ########################################################################## */  
void usi_spi_dma_master_init(const usi_num_t usi_no, clock_source_t par_as_clock_source, uint8_t par_div, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode) {
  usi_spi_dma_clock(usi_no, par_as_clock_source, par_div);
  usi_spi_dma_init(usi_no, false, par_bit_data_length, par_phase, par_polarity, par_msb_first, par_nss_mode);
  
}

/* ########################################################################## */  
void usi_spi_dma_slave_init_no_clk_init(const usi_num_t usi_no, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode) {
  //usi_spi_dma_clock(usi_no); // No clock
  usi_spi_dma_init(usi_no, true, par_bit_data_length, par_phase, par_polarity, par_msb_first, par_nss_mode);
}

/* ########################################################################## */  
void usi_spi_dma_master_init_no_clk_init(const usi_num_t usi_no, const usi_spi_data_length_t par_bit_data_length, const bool par_phase, const bool par_polarity, const bool par_msb_first, usi_spi_nss_mode_t par_nss_mode) {
  //usi_spi_dma_clock(usi_no); // No clock
  usi_spi_dma_init(usi_no, false, par_bit_data_length, par_phase, par_polarity, par_msb_first, par_nss_mode);
}

/* ########################################################################## */  
void usi_spi_dma_slave_frame(usi_num_t usi_no, uint8_t par_number_of_data, void * par_p_snd_data, void * par_p_rcv_data) {
  usi_spi_dma_frame(usi_no, par_number_of_data, par_p_snd_data, par_p_rcv_data);
}

/* ########################################################################## */  
void usi_spi_dma_slave_reg_callback(usi_num_t usi_no, uint8_t par_usi_nvic_priority, void (*p_fce_callback_rx_done)(void), void (*p_fce_callback_error)(void)) {
  usi_spi_dma_reg_callback(usi_no, par_usi_nvic_priority, p_fce_callback_rx_done, p_fce_callback_error);
}

/* ########################################################################## */  
bool usi_spi_dma_status_flag(usi_num_t usi_no){
    
  uint8_t i_usi;
  
  switch(usi_no) {
    case USI0: 
      i_usi = 0;
      break;
      
    case USI1: 
      i_usi = 1;
      break;
      
    default: 
      /* ERROR */ 
      break;
  }  
  
  return glob_usi_wrp_struct_lock[i_usi][g_usi_fifo]; 
}

/* ########################################################################## */  
void usi_spi_dma_reg_callback(usi_num_t usi_no, uint8_t par_usi_nvic_priority, void (*p_fce_callback_rx_done)(void), void (*p_fce_callback_error)(void)) {

  uint8_t i_usi;
  IRQn_Type i_IRQn;
  
  switch(usi_no) {
    case USI0: 
      i_usi = 0;
      i_IRQn = IRQ_USI0;
      break;
      
    case USI1: 
      i_usi = 1;
      i_IRQn = IRQ_USI1;
      break;
      
    default: 
      /* ERROR */
      return; 
  }  
  
  /* register callbacks */
  ptr_fce_usi_callback_rx_done[i_usi]=p_fce_callback_rx_done;
  ptr_fce_usi_callback_error[i_usi]=p_fce_callback_error;
  

  /* enable interrupts */
  usi_irq_status_t usi_irq_status; 
  usi_irq_status.val = 0; 
  usi_irq_status.bf.revents = 7;
  
#ifdef BUG_5473_FIX
  usi_irq_status.bf.radr_new_udr = 0; 
#else  
  usi_irq_status.bf.radr_new_udr = 1; 
#endif
  
  
  if(g_slave_nmaster) {
    /* SPI SLAVE */
    usi_irq_status.bf.radr_done_nempty = 0;
  }
  else {
    /* SPI MASTER */
    usi_irq_status.bf.radr_done_nempty = 1;
  }
  
  WRITE_REG_16(usi_no + ADDR_USI_IRQ_MASK, usi_irq_status.val); 

  
  /* NVIC Interrupt */
  NVIC_SetPriority(i_IRQn, par_usi_nvic_priority);
  NVIC_EnableIRQ(i_IRQn);
}
