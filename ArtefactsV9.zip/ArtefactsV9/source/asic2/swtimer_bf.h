/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swtimer_bf.h
*
* @brief        Software Timers (SWTIMER) HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __SWTIMER_BF_H__
#define __SWTIMER_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_SWTIMER0
#define BASE_ADDR_SWTIMER0 0x40006080U
#endif
#ifndef BASE_ADDR_SWTIMER1
#define BASE_ADDR_SWTIMER1 0x40006800U
#endif

#define MULTIPLE_SWTIMER
#define NUMBER_SWTIMER 2


/* ############################################################################ */
/**
 * \brief This is an enum class for SWTIMER instance
 *
 * \ingroup swtimer 
 */ 
typedef enum {
  /**
   * This is instance SWTIMER0
   */ 
  SWTIMER0                       = (int)BASE_ADDR_SWTIMER0,
  /**
   * This is instance SWTIMER1
   */ 
  SWTIMER1                       = (int)BASE_ADDR_SWTIMER1
} swtimer_num_t;

// Register bit field definitions

/* SWTIMER_CONFIG */

#define MSK_SWTIMER_CONFIG_ENABLES                          (0xf)     /* [ 3:0] */
#define RES_SWTIMER_CONFIG_ENABLES                          (0x0)
#define SFT_SWTIMER_CONFIG_ENABLES                          (0)
#define LSB_SWTIMER_CONFIG_ENABLES                          (0)
#define MSB_SWTIMER_CONFIG_ENABLES                          (3)
#define MSK_SWTIMER_CONFIG_CNT_AUTO_RELOADS                 (0xf)     /* [ 7:4] */
#define RES_SWTIMER_CONFIG_CNT_AUTO_RELOADS                 (0x0)
#define SFT_SWTIMER_CONFIG_CNT_AUTO_RELOADS                 (4)
#define LSB_SWTIMER_CONFIG_CNT_AUTO_RELOADS                 (4)
#define MSB_SWTIMER_CONFIG_CNT_AUTO_RELOADS                 (7)
#define MSK_SWTIMER_CONFIG_CASCADE_0_1                      (0x1)     /* [8] */
#define RES_SWTIMER_CONFIG_CASCADE_0_1                      (0x0)
#define SFT_SWTIMER_CONFIG_CASCADE_0_1                      (8)
#define LSB_SWTIMER_CONFIG_CASCADE_0_1                      (8)
#define MSB_SWTIMER_CONFIG_CASCADE_0_1                      (8)
#define BIT_SWTIMER_CONFIG_CASCADE_0_1                      (0x100)   /* [8] */
#define MSK_SWTIMER_CONFIG_CASCADE_2_3                      (0x1)     /* [9] */
#define RES_SWTIMER_CONFIG_CASCADE_2_3                      (0x0)
#define SFT_SWTIMER_CONFIG_CASCADE_2_3                      (9)
#define LSB_SWTIMER_CONFIG_CASCADE_2_3                      (9)
#define MSB_SWTIMER_CONFIG_CASCADE_2_3                      (9)
#define BIT_SWTIMER_CONFIG_CASCADE_2_3                      (0x200)   /* [9] */
#define MSK_SWTIMER_CONFIG_CNT0_ZERO_NMI                    (0x1)     /* [10] */
#define RES_SWTIMER_CONFIG_CNT0_ZERO_NMI                    (0x0)
#define SFT_SWTIMER_CONFIG_CNT0_ZERO_NMI                    (10)
#define LSB_SWTIMER_CONFIG_CNT0_ZERO_NMI                    (10)
#define MSB_SWTIMER_CONFIG_CNT0_ZERO_NMI                    (10)
#define BIT_SWTIMER_CONFIG_CNT0_ZERO_NMI                    (0x400)   /* [10] */
#define MSK_SWTIMER_CONFIG_CNT1_ZERO_SWD_SYNC               (0x1)     /* [11] */
#define RES_SWTIMER_CONFIG_CNT1_ZERO_SWD_SYNC               (0x0)
#define SFT_SWTIMER_CONFIG_CNT1_ZERO_SWD_SYNC               (11)
#define LSB_SWTIMER_CONFIG_CNT1_ZERO_SWD_SYNC               (11)
#define MSB_SWTIMER_CONFIG_CNT1_ZERO_SWD_SYNC               (11)
#define BIT_SWTIMER_CONFIG_CNT1_ZERO_SWD_SYNC               (0x800)   /* [11] */


/* ############################################################################ */
/**
 * \brief This structure describes SWTIMER configuration
 *
 * \ingroup swtimer 
 */ 
typedef struct {
  /**
   * 1: counter n and prescaler n enabled, 0: disabled <br> 
   * bit 0 = timer 0, bit 1 = timer 1, ... <br>
   * Disabling a running counter will stop the counter and prescaler immediately.
   */ 
  unsigned short enables                       :    4;       /* [ 3:0] */
  /**
   * 1: auto reload for counter n enabled, 0: disabled <br>
   * bit 4 = timer 0, bit 5 = timer 1, ...
   */ 
  unsigned short cnt_auto_reloads              :    4;       /* [ 7:4] */
  /**
   * 0: swtimer0 and swtimer1 are individual 16 bit timers <br>
   * 1: swtimer1 counter will be increased when swtimer0 counter is zero <br>
   * (swtimer1 predivider has no effect, but might be used)
   */ 
  unsigned short cascade_0_1                   :    1;       /* [8] */
  /**
   * 0: swtimer2 and swtimer3 are individual 16 bit timers <br>
   * 1: swtimer3 counter will be increased when swtimer2 counter is zero <br>
   * (swtimer3 predivider has no effect, but might be used)
   */ 
  unsigned short cascade_2_3                   :    1;       /* [9] */
  /**
   * 1: enable nmi for corresponding CPU when counter is zero
   */ 
  unsigned short cnt0_zero_nmi                 :    1;       /* [10] */
  /**
   * 1: enable SWD sync input when counter is zero (SWTIMER0 instance only)
   */ 
  unsigned short cnt1_zero_swd_sync            :    1;       /* [11] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    4;
} swtimer_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWTIMER configuration
 *
 * \ingroup swtimer 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swtimer_config_bf bf;  ///< bit field representation
} swtimer_config_t;


/* SWTIMER_COMMAND */

#define MSK_SWTIMER_COMMAND_CNT_RELOAD_CMD                  (0xf)     /* [ 3:0] */
#define RES_SWTIMER_COMMAND_CNT_RELOAD_CMD                  (0x0)
#define SFT_SWTIMER_COMMAND_CNT_RELOAD_CMD                  (0)
#define LSB_SWTIMER_COMMAND_CNT_RELOAD_CMD                  (0)
#define MSB_SWTIMER_COMMAND_CNT_RELOAD_CMD                  (3)
#define MSK_SWTIMER_COMMAND_DIV_RELOAD_CMD                  (0xf)     /* [ 7:4] */
#define RES_SWTIMER_COMMAND_DIV_RELOAD_CMD                  (0x0)
#define SFT_SWTIMER_COMMAND_DIV_RELOAD_CMD                  (4)
#define LSB_SWTIMER_COMMAND_DIV_RELOAD_CMD                  (4)
#define MSB_SWTIMER_COMMAND_DIV_RELOAD_CMD                  (7)


/* ############################################################################ */
/**
 * \brief This structure describes SWTIMER command
 *
 * \ingroup swtimer 
 */ 
typedef struct {
  /**
   * 1: trigger counter n reload / restart <br>
   * bit 0 = counter 0, bit 1 = counter 1, ...
   */ 
  unsigned short cnt_reload_cmd                :    4;       /* [ 3:0] */
  /**
   * 1: trigger predivider n reload / restart <br>
   * bit 4 = predivider 0, bit 5 = predivider 1, ...
   */ 
  unsigned short div_reload_cmd                :    4;       /* [ 7:4] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    8;
} swtimer_command_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWTIMER command
 *
 * \ingroup swtimer 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swtimer_command_bf bf;  ///< bit field representation
} swtimer_command_t;


/* SWTIMER_CNT_RELOAD */

#define MSK_SWTIMER_CNT_RELOAD                              (0xffff)  /* [15:0] */

typedef unsigned short swtimer_cnt_reload_t;                          /* [15:0] */


/* SWTIMER_DIV_RELOAD */

#define MSK_SWTIMER_DIV_RELOAD                              (0xff)    /* [ 7:0] */

typedef unsigned short swtimer_div_reload_t;                          /* [ 7:0] */


/* SWTIMER_CNT_VALUE */

#define MSK_SWTIMER_CNT_VALUE                               (0xffff)  /* [15:0] */

typedef unsigned short swtimer_cnt_value_t;                           /* [15:0] */


/* SWTIMER_IRQ_STATUS */

#define MSK_SWTIMER_IRQ_STATUS_EVT_CNT_ZERO                 (0xf)     /* [ 3:0] */
#define RES_SWTIMER_IRQ_STATUS_EVT_CNT_ZERO                 (0x0)
#define SFT_SWTIMER_IRQ_STATUS_EVT_CNT_ZERO                 (0)
#define LSB_SWTIMER_IRQ_STATUS_EVT_CNT_ZERO                 (0)
#define MSB_SWTIMER_IRQ_STATUS_EVT_CNT_ZERO                 (3)
#define MSK_SWTIMER_IRQ_STATUS_EVT_DIV_ZERO                 (0xf)     /* [ 7:4] */
#define RES_SWTIMER_IRQ_STATUS_EVT_DIV_ZERO                 (0x0)
#define SFT_SWTIMER_IRQ_STATUS_EVT_DIV_ZERO                 (4)
#define LSB_SWTIMER_IRQ_STATUS_EVT_DIV_ZERO                 (4)
#define MSB_SWTIMER_IRQ_STATUS_EVT_DIV_ZERO                 (7)


/* ############################################################################ */
/**
 * \brief This structure describes SWTIMER Interrupt Request (IRQ) status
 *
 * \ingroup swtimer 
 */ 
typedef struct {
  /**
   * counter n has been zero <br>
   * bit 0 = counter 0, bit 1 = counter 1, ...
   */ 
  unsigned short evt_cnt_zero                  :    4;       /* [ 3:0] */
  /**
   * predivider n has been zero <br>
   * bit 4 = predivider 0, bit 5 = predivider 1, ...
   */ 
  unsigned short evt_div_zero                  :    4;       /* [ 7:4] */
  /**
   * Reserved
   */ 
  unsigned short reserved                      :    8;
} swtimer_irq_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWTIMER Interrupt Request (IRQ) status
 *
 * \ingroup swtimer 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swtimer_irq_status_bf bf;  ///< bit field representation
} swtimer_irq_status_t;


/* SWTIMER_IRQ_MASK */

#define MSK_SWTIMER_IRQ_MASK                                (0xff)    /* [ 7:0] */

typedef unsigned short swtimer_irq_mask_t;                            /* [ 7:0] */


/* SWTIMER_IRQ_VENABLE */

#define MSK_SWTIMER_IRQ_VENABLE                             (0x7)     /* [ 2:0] */

typedef unsigned short swtimer_irq_venable_t;                         /* [ 2:0] */


/* SWTIMER_IRQ_VDISABLE */

#define MSK_SWTIMER_IRQ_VDISABLE                            (0x7)     /* [ 2:0] */

typedef unsigned short swtimer_irq_vdisable_t;                        /* [ 2:0] */


/* SWTIMER_IRQ_VMAX */

#define MSK_SWTIMER_IRQ_VMAX                                (0xf)     /* [ 3:0] */

typedef unsigned short swtimer_irq_vmax_t;                            /* [ 3:0] */


/* SWTIMER_IRQ_VNO */

#define MSK_SWTIMER_IRQ_VNO                                 (0xf)     /* [ 3:0] */

typedef unsigned short swtimer_irq_vno_t;                             /* [ 3:0] */



// Register definitions for module
// Instance base address BASE_ADDR_SWTIMER0 0x40006080U ... 
// Instance base address BASE_ADDR_SWTIMER1 0x40006800U ... 

#define ADDR_SWTIMER_CONFIG                                  (0x00U)
#define A_SWTIMER_CONFIG(ba)                                 ((ba) + ADDR_SWTIMER_CONFIG)
#define R_SWTIMER_CONFIG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_SWTIMER_CONFIG(ba)))
#define RES_SWTIMER_CONFIG                                   (0x0U)
#define MSB_SWTIMER_CONFIG                                   11
#define LSB_SWTIMER_CONFIG                                   0
#define AADDR_SWTIMER0_CONFIG                                (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_CONFIG)
#define AADDR_SWTIMER1_CONFIG                                (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_CONFIG)
#define REG_SWTIMER0_CONFIG                                  (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_CONFIG))
#define REG_SWTIMER1_CONFIG                                  (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_CONFIG))

#define ADDR_SWTIMER_COMMAND                                 (0x02U)
#define A_SWTIMER_COMMAND(ba)                                ((ba) + ADDR_SWTIMER_COMMAND)
#define R_SWTIMER_COMMAND(ba)                                (*(volatile unsigned short *)((unsigned int)A_SWTIMER_COMMAND(ba)))
#define RES_SWTIMER_COMMAND                                  (0x0U)
#define MSB_SWTIMER_COMMAND                                  7
#define LSB_SWTIMER_COMMAND                                  0
#define AADDR_SWTIMER0_COMMAND                               (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_COMMAND)
#define AADDR_SWTIMER1_COMMAND                               (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_COMMAND)
#define REG_SWTIMER0_COMMAND                                 (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_COMMAND))
#define REG_SWTIMER1_COMMAND                                 (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_COMMAND))

#define ADDR_SWTIMER_CNT0_RELOAD                             (0x04U)
#define A_SWTIMER_CNT0_RELOAD(ba)                            ((ba) + ADDR_SWTIMER_CNT0_RELOAD)
#define R_SWTIMER_CNT0_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWTIMER_CNT0_RELOAD(ba)))
#define RES_SWTIMER_CNT0_RELOAD                              (0x0U)
#define MSB_SWTIMER_CNT0_RELOAD                              15
#define LSB_SWTIMER_CNT0_RELOAD                              0
#define AADDR_SWTIMER0_CNT0_RELOAD                           (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_CNT0_RELOAD)
#define AADDR_SWTIMER1_CNT0_RELOAD                           (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_CNT0_RELOAD)
#define REG_SWTIMER0_CNT0_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_CNT0_RELOAD))
#define REG_SWTIMER1_CNT0_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_CNT0_RELOAD))

#define ADDR_SWTIMER_CNT1_RELOAD                             (0x06U)
#define A_SWTIMER_CNT1_RELOAD(ba)                            ((ba) + ADDR_SWTIMER_CNT1_RELOAD)
#define R_SWTIMER_CNT1_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWTIMER_CNT1_RELOAD(ba)))
#define RES_SWTIMER_CNT1_RELOAD                              (0x0U)
#define MSB_SWTIMER_CNT1_RELOAD                              15
#define LSB_SWTIMER_CNT1_RELOAD                              0
#define AADDR_SWTIMER0_CNT1_RELOAD                           (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_CNT1_RELOAD)
#define AADDR_SWTIMER1_CNT1_RELOAD                           (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_CNT1_RELOAD)
#define REG_SWTIMER0_CNT1_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_CNT1_RELOAD))
#define REG_SWTIMER1_CNT1_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_CNT1_RELOAD))

#define ADDR_SWTIMER_CNT2_RELOAD                             (0x08U)
#define A_SWTIMER_CNT2_RELOAD(ba)                            ((ba) + ADDR_SWTIMER_CNT2_RELOAD)
#define R_SWTIMER_CNT2_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWTIMER_CNT2_RELOAD(ba)))
#define RES_SWTIMER_CNT2_RELOAD                              (0x0U)
#define MSB_SWTIMER_CNT2_RELOAD                              15
#define LSB_SWTIMER_CNT2_RELOAD                              0
#define AADDR_SWTIMER0_CNT2_RELOAD                           (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_CNT2_RELOAD)
#define AADDR_SWTIMER1_CNT2_RELOAD                           (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_CNT2_RELOAD)
#define REG_SWTIMER0_CNT2_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_CNT2_RELOAD))
#define REG_SWTIMER1_CNT2_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_CNT2_RELOAD))

#define ADDR_SWTIMER_CNT3_RELOAD                             (0x0AU)
#define A_SWTIMER_CNT3_RELOAD(ba)                            ((ba) + ADDR_SWTIMER_CNT3_RELOAD)
#define R_SWTIMER_CNT3_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWTIMER_CNT3_RELOAD(ba)))
#define RES_SWTIMER_CNT3_RELOAD                              (0x0U)
#define MSB_SWTIMER_CNT3_RELOAD                              15
#define LSB_SWTIMER_CNT3_RELOAD                              0
#define AADDR_SWTIMER0_CNT3_RELOAD                           (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_CNT3_RELOAD)
#define AADDR_SWTIMER1_CNT3_RELOAD                           (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_CNT3_RELOAD)
#define REG_SWTIMER0_CNT3_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_CNT3_RELOAD))
#define REG_SWTIMER1_CNT3_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_CNT3_RELOAD))

#define ADDR_SWTIMER_DIV0_RELOAD                             (0x0CU)
#define A_SWTIMER_DIV0_RELOAD(ba)                            ((ba) + ADDR_SWTIMER_DIV0_RELOAD)
#define R_SWTIMER_DIV0_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWTIMER_DIV0_RELOAD(ba)))
#define RES_SWTIMER_DIV0_RELOAD                              (0x0U)
#define MSB_SWTIMER_DIV0_RELOAD                              7
#define LSB_SWTIMER_DIV0_RELOAD                              0
#define AADDR_SWTIMER0_DIV0_RELOAD                           (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_DIV0_RELOAD)
#define AADDR_SWTIMER1_DIV0_RELOAD                           (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_DIV0_RELOAD)
#define REG_SWTIMER0_DIV0_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_DIV0_RELOAD))
#define REG_SWTIMER1_DIV0_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_DIV0_RELOAD))

#define ADDR_SWTIMER_DIV1_RELOAD                             (0x0EU)
#define A_SWTIMER_DIV1_RELOAD(ba)                            ((ba) + ADDR_SWTIMER_DIV1_RELOAD)
#define R_SWTIMER_DIV1_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWTIMER_DIV1_RELOAD(ba)))
#define RES_SWTIMER_DIV1_RELOAD                              (0x0U)
#define MSB_SWTIMER_DIV1_RELOAD                              7
#define LSB_SWTIMER_DIV1_RELOAD                              0
#define AADDR_SWTIMER0_DIV1_RELOAD                           (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_DIV1_RELOAD)
#define AADDR_SWTIMER1_DIV1_RELOAD                           (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_DIV1_RELOAD)
#define REG_SWTIMER0_DIV1_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_DIV1_RELOAD))
#define REG_SWTIMER1_DIV1_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_DIV1_RELOAD))

#define ADDR_SWTIMER_DIV2_RELOAD                             (0x10U)
#define A_SWTIMER_DIV2_RELOAD(ba)                            ((ba) + ADDR_SWTIMER_DIV2_RELOAD)
#define R_SWTIMER_DIV2_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWTIMER_DIV2_RELOAD(ba)))
#define RES_SWTIMER_DIV2_RELOAD                              (0x0U)
#define MSB_SWTIMER_DIV2_RELOAD                              7
#define LSB_SWTIMER_DIV2_RELOAD                              0
#define AADDR_SWTIMER0_DIV2_RELOAD                           (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_DIV2_RELOAD)
#define AADDR_SWTIMER1_DIV2_RELOAD                           (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_DIV2_RELOAD)
#define REG_SWTIMER0_DIV2_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_DIV2_RELOAD))
#define REG_SWTIMER1_DIV2_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_DIV2_RELOAD))

#define ADDR_SWTIMER_DIV3_RELOAD                             (0x12U)
#define A_SWTIMER_DIV3_RELOAD(ba)                            ((ba) + ADDR_SWTIMER_DIV3_RELOAD)
#define R_SWTIMER_DIV3_RELOAD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWTIMER_DIV3_RELOAD(ba)))
#define RES_SWTIMER_DIV3_RELOAD                              (0x0U)
#define MSB_SWTIMER_DIV3_RELOAD                              7
#define LSB_SWTIMER_DIV3_RELOAD                              0
#define AADDR_SWTIMER0_DIV3_RELOAD                           (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_DIV3_RELOAD)
#define AADDR_SWTIMER1_DIV3_RELOAD                           (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_DIV3_RELOAD)
#define REG_SWTIMER0_DIV3_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_DIV3_RELOAD))
#define REG_SWTIMER1_DIV3_RELOAD                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_DIV3_RELOAD))

#define ADDR_SWTIMER_CNT0_VALUE                              (0x14U)
#define A_SWTIMER_CNT0_VALUE(ba)                             ((ba) + ADDR_SWTIMER_CNT0_VALUE)
#define R_SWTIMER_CNT0_VALUE(ba)                             (*(volatile unsigned short *)((unsigned int)A_SWTIMER_CNT0_VALUE(ba)))
#define RES_SWTIMER_CNT0_VALUE                               (0x0U)
#define MSB_SWTIMER_CNT0_VALUE                               15
#define LSB_SWTIMER_CNT0_VALUE                               0
#define AADDR_SWTIMER0_CNT0_VALUE                            (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_CNT0_VALUE)
#define AADDR_SWTIMER1_CNT0_VALUE                            (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_CNT0_VALUE)
#define REG_SWTIMER0_CNT0_VALUE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_CNT0_VALUE))
#define REG_SWTIMER1_CNT0_VALUE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_CNT0_VALUE))

#define ADDR_SWTIMER_CNT1_VALUE                              (0x16U)
#define A_SWTIMER_CNT1_VALUE(ba)                             ((ba) + ADDR_SWTIMER_CNT1_VALUE)
#define R_SWTIMER_CNT1_VALUE(ba)                             (*(volatile unsigned short *)((unsigned int)A_SWTIMER_CNT1_VALUE(ba)))
#define RES_SWTIMER_CNT1_VALUE                               (0x0U)
#define MSB_SWTIMER_CNT1_VALUE                               15
#define LSB_SWTIMER_CNT1_VALUE                               0
#define AADDR_SWTIMER0_CNT1_VALUE                            (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_CNT1_VALUE)
#define AADDR_SWTIMER1_CNT1_VALUE                            (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_CNT1_VALUE)
#define REG_SWTIMER0_CNT1_VALUE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_CNT1_VALUE))
#define REG_SWTIMER1_CNT1_VALUE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_CNT1_VALUE))

#define ADDR_SWTIMER_CNT2_VALUE                              (0x18U)
#define A_SWTIMER_CNT2_VALUE(ba)                             ((ba) + ADDR_SWTIMER_CNT2_VALUE)
#define R_SWTIMER_CNT2_VALUE(ba)                             (*(volatile unsigned short *)((unsigned int)A_SWTIMER_CNT2_VALUE(ba)))
#define RES_SWTIMER_CNT2_VALUE                               (0x0U)
#define MSB_SWTIMER_CNT2_VALUE                               15
#define LSB_SWTIMER_CNT2_VALUE                               0
#define AADDR_SWTIMER0_CNT2_VALUE                            (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_CNT2_VALUE)
#define AADDR_SWTIMER1_CNT2_VALUE                            (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_CNT2_VALUE)
#define REG_SWTIMER0_CNT2_VALUE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_CNT2_VALUE))
#define REG_SWTIMER1_CNT2_VALUE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_CNT2_VALUE))

#define ADDR_SWTIMER_CNT3_VALUE                              (0x1AU)
#define A_SWTIMER_CNT3_VALUE(ba)                             ((ba) + ADDR_SWTIMER_CNT3_VALUE)
#define R_SWTIMER_CNT3_VALUE(ba)                             (*(volatile unsigned short *)((unsigned int)A_SWTIMER_CNT3_VALUE(ba)))
#define RES_SWTIMER_CNT3_VALUE                               (0x0U)
#define MSB_SWTIMER_CNT3_VALUE                               15
#define LSB_SWTIMER_CNT3_VALUE                               0
#define AADDR_SWTIMER0_CNT3_VALUE                            (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_CNT3_VALUE)
#define AADDR_SWTIMER1_CNT3_VALUE                            (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_CNT3_VALUE)
#define REG_SWTIMER0_CNT3_VALUE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_CNT3_VALUE))
#define REG_SWTIMER1_CNT3_VALUE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_CNT3_VALUE))

#define ADDR_SWTIMER_IRQ_STATUS                              (0x1CU)
#define A_SWTIMER_IRQ_STATUS(ba)                             ((ba) + ADDR_SWTIMER_IRQ_STATUS)
#define R_SWTIMER_IRQ_STATUS(ba)                             (*(volatile unsigned short *)((unsigned int)A_SWTIMER_IRQ_STATUS(ba)))
#define RES_SWTIMER_IRQ_STATUS                               (0x0U)
#define MSB_SWTIMER_IRQ_STATUS                               7
#define LSB_SWTIMER_IRQ_STATUS                               0
#define AADDR_SWTIMER0_IRQ_STATUS                            (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_IRQ_STATUS)
#define AADDR_SWTIMER1_IRQ_STATUS                            (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_IRQ_STATUS)
#define REG_SWTIMER0_IRQ_STATUS                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_IRQ_STATUS))
#define REG_SWTIMER1_IRQ_STATUS                              (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_IRQ_STATUS))

#define ADDR_SWTIMER_IRQ_MASK                                (0x20U)
#define A_SWTIMER_IRQ_MASK(ba)                               ((ba) + ADDR_SWTIMER_IRQ_MASK)
#define R_SWTIMER_IRQ_MASK(ba)                               (*(volatile unsigned short *)((unsigned int)A_SWTIMER_IRQ_MASK(ba)))
#define RES_SWTIMER_IRQ_MASK                                 (0x0U)
#define MSB_SWTIMER_IRQ_MASK                                 7
#define LSB_SWTIMER_IRQ_MASK                                 0
#define AADDR_SWTIMER0_IRQ_MASK                              (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_IRQ_MASK)
#define AADDR_SWTIMER1_IRQ_MASK                              (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_IRQ_MASK)
#define REG_SWTIMER0_IRQ_MASK                                (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_IRQ_MASK))
#define REG_SWTIMER1_IRQ_MASK                                (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_IRQ_MASK))

#define ADDR_SWTIMER_IRQ_VENABLE                             (0x24U)
#define A_SWTIMER_IRQ_VENABLE(ba)                            ((ba) + ADDR_SWTIMER_IRQ_VENABLE)
#define R_SWTIMER_IRQ_VENABLE(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWTIMER_IRQ_VENABLE(ba)))
#define RES_SWTIMER_IRQ_VENABLE                              (0x0U)
#define MSB_SWTIMER_IRQ_VENABLE                              2
#define LSB_SWTIMER_IRQ_VENABLE                              0
#define AADDR_SWTIMER0_IRQ_VENABLE                           (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_IRQ_VENABLE)
#define AADDR_SWTIMER1_IRQ_VENABLE                           (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_IRQ_VENABLE)
#define REG_SWTIMER0_IRQ_VENABLE                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_IRQ_VENABLE))
#define REG_SWTIMER1_IRQ_VENABLE                             (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_IRQ_VENABLE))

#define ADDR_SWTIMER_IRQ_VDISABLE                            (0x26U)
#define A_SWTIMER_IRQ_VDISABLE(ba)                           ((ba) + ADDR_SWTIMER_IRQ_VDISABLE)
#define R_SWTIMER_IRQ_VDISABLE(ba)                           (*(volatile unsigned short *)((unsigned int)A_SWTIMER_IRQ_VDISABLE(ba)))
#define RES_SWTIMER_IRQ_VDISABLE                             (0x0U)
#define MSB_SWTIMER_IRQ_VDISABLE                             2
#define LSB_SWTIMER_IRQ_VDISABLE                             0
#define AADDR_SWTIMER0_IRQ_VDISABLE                          (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_IRQ_VDISABLE)
#define AADDR_SWTIMER1_IRQ_VDISABLE                          (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_IRQ_VDISABLE)
#define REG_SWTIMER0_IRQ_VDISABLE                            (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_IRQ_VDISABLE))
#define REG_SWTIMER1_IRQ_VDISABLE                            (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_IRQ_VDISABLE))

#define ADDR_SWTIMER_IRQ_VMAX                                (0x28U)
#define A_SWTIMER_IRQ_VMAX(ba)                               ((ba) + ADDR_SWTIMER_IRQ_VMAX)
#define R_SWTIMER_IRQ_VMAX(ba)                               (*(volatile unsigned short *)((unsigned int)A_SWTIMER_IRQ_VMAX(ba)))
#define RES_SWTIMER_IRQ_VMAX                                 (0x8U)
#define MSB_SWTIMER_IRQ_VMAX                                 3
#define LSB_SWTIMER_IRQ_VMAX                                 0
#define AADDR_SWTIMER0_IRQ_VMAX                              (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_IRQ_VMAX)
#define AADDR_SWTIMER1_IRQ_VMAX                              (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_IRQ_VMAX)
#define REG_SWTIMER0_IRQ_VMAX                                (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_IRQ_VMAX))
#define REG_SWTIMER1_IRQ_VMAX                                (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_IRQ_VMAX))

#define ADDR_SWTIMER_IRQ_VNO                                 (0x2AU)
#define A_SWTIMER_IRQ_VNO(ba)                                ((ba) + ADDR_SWTIMER_IRQ_VNO)
#define R_SWTIMER_IRQ_VNO(ba)                                (*(volatile unsigned short *)((unsigned int)A_SWTIMER_IRQ_VNO(ba)))
#define RES_SWTIMER_IRQ_VNO                                  (0x8U)
#define MSB_SWTIMER_IRQ_VNO                                  3
#define LSB_SWTIMER_IRQ_VNO                                  0
#define AADDR_SWTIMER0_IRQ_VNO                               (BASE_ADDR_SWTIMER0 + ADDR_SWTIMER_IRQ_VNO)
#define AADDR_SWTIMER1_IRQ_VNO                               (BASE_ADDR_SWTIMER1 + ADDR_SWTIMER_IRQ_VNO)
#define REG_SWTIMER0_IRQ_VNO                                 (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER0_IRQ_VNO))
#define REG_SWTIMER1_IRQ_VNO                                 (*(volatile unsigned short *)((unsigned int)AADDR_SWTIMER1_IRQ_VNO))




#endif
