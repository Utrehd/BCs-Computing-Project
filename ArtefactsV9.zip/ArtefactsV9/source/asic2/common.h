/**
********************************************************************************
********************************************************************************
* \copyright    Copyright (c) 2018 Eaton Industries GmbH,
*               GERMANY, All rights reserved
* \file         common.h
* \brief        Contains functions for general porpuse usage
* \author       Samuel.A Marti
*
********************************************************************************
* \version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
* \defgroup     common General porpuse functions
* \brief        Contains functions for general purpose useage
********************************************************************************
*/

#ifndef __COMMON__
#define __COMMON__

/**
********************************************************************************
* \brief        This function will check if the value of a unsigned in of 32 bit
*               would fit into a 16bit unsinged int
*
* \ingroup      common
*
* \param        uint32 Target 32 bit int to be checked
*
* \return       Bool, True if the int fits
* \retval       True:   The given 32 bit uint fits into a 16 bit uint
* \retval       False:  The given 32 bit uint does not fit into a 16 bit uint
********************************************************************************
*/

bool common_uint32_fits_in_uint16(uint32_t target);

/**
********************************************************************************
* \brief        This function will check if the value of a unsigned in of 32 bit
*               would fit into a 8bit unsinged int
*
* \ingroup      common
*
* \param        uint32 Target 32 bit int to be checked
*
* \return       Bool, True if the int fits
* \retval       True:   The given 32 bit uint fits into a 8 bit uint
* \retval       False:  The given 32 bit uint does not fit into a 8 bit uint
********************************************************************************
*/

bool common_uint32_fits_in_uint8(uint32_t target);

#endif
