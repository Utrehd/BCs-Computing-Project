/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         diagnose_asic2.h
*
* @brief        Diagnose control functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_DIAGNOSE_ASIC2
#define HAVE_DIAGNOSE_ASIC2

#include "hardware_api.h"
#include <slave/swd_slave.h>

/**
 * \defgroup diganose_asic2_api ASIC2 Diagnose control functions
 * 
 * \brief    Functions to control Diagnose status
 *
 */

/**
  * \brief This structure describes each diagnose bit
  *
  * \ingroup diganose_asic2_api
  */
typedef struct
{
    uint32_t  bit0:1; ///> Overload, short-circuit on at least one output
    uint32_t  bit1:1;
    uint32_t  bit2:1;
    uint32_t  bit3:1;
    uint32_t  bit4:1;
    uint32_t  bit5:1;
    uint32_t  bit6:1;
    uint32_t  bit7:1;
    uint32_t  bit8:1; ///> No sensor/actuator detected at Connection X1
    uint32_t  bit9:1; ///> No sensor/actuator detected at Connection X2
    uint32_t  bit10:1;
    uint32_t  bit11:1;
    uint32_t  bit12:1;
    uint32_t  bit13:1;
    uint32_t  bit14:1;
    uint32_t  bit15:1;
    uint32_t  bit16:1; ///> Sensor/actuator power supply overload, short-circuit at Connection X1
    uint32_t  bit17:1; ///> Sensor/actuator power supply overload, short-circuit at Connection X2
    uint32_t  bit18:1;
    uint32_t  bit19:1;
    uint32_t  bit20:1;
    uint32_t  bit21:1;
    uint32_t  bit22:1;
    uint32_t  bit23:1;
    uint32_t  bit24:1;
    uint32_t  bit25:1;
    uint32_t  bit26:1;
    uint32_t  bit27:1;
    uint32_t  bit28:1;
    uint32_t  bit29:1;
    uint32_t  bit30:1;
    uint32_t  bit31:1;
} diagnose_decoded_status_t;

/**
  * \brief This is an enum class for Diagnose to define the current status of failsave mode
  *
  * \ingroup diganose_asic2_api
  */
typedef union
{
  uint32_t data; ///> Value of the 32 bits
  diagnose_decoded_status_t bits; ///> Each bit corresponds with one diagnose

} failsave_status_t;

/**
  * \brief This is an enum class for Diagnose to define the current status of diagnose
  *
  * \ingroup diganose_asic2_api
  */
typedef union
{
  uint32_t data; ///> Value of the 32 bits
  diagnose_decoded_status_t bits; ///> Each bit corresponds with one diagnose

} diagnose_status_t;

/* ############################################################################ */
/**
 * \brief   Function to set the failsave mode in the variable
 *
 * \ingroup diganose_asic2_api
 * 
 * \param tDiag Type of diagnose
 * 
 * \param failsave failsave mode: <br> true - enable <br> false - disable
 *
 */
void swd_diagnose_failsave_on_asic2 ( diag_t tDiag, bool failsave );

/* ############################################################################ */
/**
 * \brief   Function to clear the failsave mode in the variable
 *
 * \ingroup diganose_asic2_api
 * 
 * \param tDiag Type of diagnose
 * 
 * \param failsave failsave mode: <br> true - enable <br> false - disable
 *
 */
void swd_diagnose_failsave_off_asic2 ( diag_t tDiag, bool failsave );

/* ############################################################################ */
/**
 * \brief   Function to know if failsave mode is active
 *
 * \ingroup diganose_asic2_api
 * 
 * \param tDiag Type of diagnose
 * 
 * \param failsave failsave mode: <br> true - enable <br> false - disable
 * 
 * \return Returns true when there is a diagnose with failsave mode on and input failsave is true
 *
 */
bool swd_diagnose_failsave_is_on_asic2 ( diag_t tDiag, bool failsave );

/* ############################################################################ */
/**
 * \brief   Function to set the diagnose
 *
 * \ingroup diganose_asic2_api
 * 
 * \param tDiag Type of diagnose
 * 
 * \param failsave failsave mode: <br> true - enable <br> false - disable
 *
 */
void swd_diagnose_on_asic2 ( diag_t tDiag, bool failsave );

/* ############################################################################ */
/**
 * \brief   Function to clear the diagnose
 *
 * \ingroup diganose_asic2_api
 * 
 * \param tDiag Type of diagnose
 * 
 * \param failsave failsave mode: <br> true - enable <br> false - disable
 *
 */
void swd_diagnose_off_asic2 ( diag_t tDiag, bool failsave );

#endif