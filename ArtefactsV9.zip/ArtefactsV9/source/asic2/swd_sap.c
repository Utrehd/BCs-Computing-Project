/* FPGA Release: 10512 */
#include "swd.h"

void
swd_sap_enable_all_dest_addrs (void)
{
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ALL_EN, 1);
}

void
swd_sap_disable_all_dest_addrs (void)
{
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ALL_EN, 0);
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR0, 0);
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR1, 0);
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR2, 0);
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR3, 0);
}

void
swd_sap_enable_dest_addr (uint8_t no, uint8_t addr)
{
    swd_sap_destination_addr_t sap_dest_addr;
    sap_dest_addr.val = 0;
    sap_dest_addr.bf.en = 1;
    sap_dest_addr.bf.dest_addr = addr;
    switch (no) {
    case 0:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR0, sap_dest_addr.val);
        break;
    case 1:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR1, sap_dest_addr.val);
        break;
    case 2:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR2, sap_dest_addr.val);
        break;
    case 3:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR3, sap_dest_addr.val);
        break;
    }
}

void
swd_sap_disable_dest_addr (uint8_t no)
{
  switch (no) {
  case 0: WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR0, 0);  break;
  case 1: WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR1, 0);  break;
  case 2: WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR2, 0);  break;
  case 3: WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR3, 0);  break;
  }
}

void
swd_sap_set_filter (swd_dma_vchannel_t vchannel, uint8_t mask, uint8_t value,
                       bool inv)
{
  swd_sap_sap_filter_t sap_filter;
  sap_filter.val = 0;
  sap_filter.bf.value = value;
  sap_filter.bf.mask = mask;
  sap_filter.bf.inv_all = inv;
  switch (vchannel) {
  case SWD_DMA_VCHANNEL_ACY_RX_SAPA:
      WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_SAPA_FILTER, sap_filter.val);
      break;
  case SWD_DMA_VCHANNEL_ACY_RX_SAPB:
      WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_SAPB_FILTER, sap_filter.val);
      break;
  case SWD_DMA_VCHANNEL_ACY_RX_SAPC:
      WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_SAPC_FILTER, sap_filter.val);
      break;
  default:
      break;
  }
}

void
swd_sap_source_command (swd_sap_src_t src,
                           swd_sap_src_command_t source_command,
                           uint8_t source_addr)
{
    swd_sap_source_command_t src_command;
    src_command.val = 0;
    src_command.bf.source_command = source_command;
    src_command.bf.source_set_adr = source_addr;
    switch (src) {
    case SWD_SAP_SOURCE0: WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE0_COMMAND, src_command.val);  break;
    case SWD_SAP_SOURCE1: WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE1_COMMAND, src_command.val);  break;
    case SWD_SAP_SOURCE2: WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE2_COMMAND, src_command.val);  break;
    case SWD_SAP_SOURCE3: WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE3_COMMAND, src_command.val);  break;
    default:  break;
    }
}

void
swd_sap_get_source_status (swd_sap_src_t src,
                              swd_sap_source_status_t * source_status)
{
    switch (src) {
    case SWD_SAP_SOURCE0: source_status->val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE0_STATUS); break;
    case SWD_SAP_SOURCE1: source_status->val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE1_STATUS); break;
    case SWD_SAP_SOURCE2: source_status->val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE2_STATUS); break;
    case SWD_SAP_SOURCE3: source_status->val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE3_STATUS); break;
    default:  break;
    }
}
