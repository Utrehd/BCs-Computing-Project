/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         i2c.h
*
* @brief        I2C Master Interface HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __I2C_H__
#define __I2C_H__

/**
 * \example example_i2c.c
 * This is an example of how to use I2C block.
 */
 
/**
 * \defgroup i2c ASIC2 I2C Master Interface HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control I2C Master Interface
 */
/**@{*/ 

#include "device.h"

#include "i2c_bf.h"
#include "i2c_irq.h"


#define I2C_CMD_FIFO_DEPTH 8
#define I2C_REC_FIFO_DEPTH 4

/* ############################################################################ */
/** 
 * \brief This enumeration describes commands to be sent/received
 *
 * \ingroup i2c
 */
typedef enum {
  I2C_RECV  = 0x0000, ///< I2C data is received
  I2C_SEND  = 0x0100, ///< I2C data is sent

  I2C_START = 0x0200, ///< Send I2C Start condition element

  I2C_ACK0  = 0x0000, ///< Send ACK or expect acknowledge (release SDA)
  I2C_ACK1  = 0x0400, ///< Send NACK

  I2C_STOP  = 0x0800 ///< Send I2C Stop condition element
} i2c_command_t;


// =======================================================================
// MODULE HANDLING                                                        
// =======================================================================

/* ############################################################################ */
/**
 * \brief Init I2C - set baudrate divider
 *
 * \param  divider   baud divider, must be > 0. divider = system clock / ( 8 * baud rate)
 *
 * \ingroup i2c
 * 
 */
void i2c_init(uint16_t divider);

/* ############################################################################ */
/**
 * \brief Set high water receive FIFO level. Interrupt will be asserted when 
 *        receive FIFO fill level increases to this value
 *
 * \param  value high water receive FIFO level
 *
 * \ingroup i2c
 * 
 */
void i2c_set_rec_high_water(uint8_t value);

/* ############################################################################ */
/**
 * \brief Set low water command FIFO level interrupt will be asserted when 
 *        command FIFO fill level decreases to this value
 *
 * \param  value low water command FIFO level 
 *
 * \ingroup i2c
 * 
 */
void i2c_set_cmd_low_water(uint8_t value);

/* ############################################################################ */
/**
 * \brief I2C FIFO clear
 *
 * \param  cmd_fifo_clr   transmit FIFO clear
 *
 * \param  rec_fifo_clr  receiver FIFO clear
 *
 * \ingroup i2c
 * 
 */
void i2c_fifo_clear(bool cmd_fifo_clr, bool rec_fifo_clr);

/* ############################################################################ */
/**
 * \brief Get transmit FIFO fill level
 *
 * \return transmit FIFO fill level
 *
 * \ingroup i2c
 * 
 */
uint16_t i2c_get_cmd_delta(void);

/* ############################################################################ */
/**
 * \brief Get receive FIFO fill level
 *
 * \return receive FIFO fill level
 *
 * \ingroup i2c
 * 
 */
uint16_t i2c_get_rec_delta(void);

/* ############################################################################ */
/**
 * \brief Wait for transim FIFO and transmit new I2C transaction after that
 *
 * \param  flags  which I2C flags should be processed (START,READ,WRITE,ACK,NACK,STOP) see i2c_command_t
 *
 * \param  data   data to be sent
 *
 * \ingroup i2c
 * 
 */
void i2c_command(uint16_t flags, uint8_t data);

/* ############################################################################ */
/**
 * \brief Wait for data and get them from I2C
 *
 * \return received data
 *
 * \ingroup i2c
 * 
 */
uint8_t i2c_get_recv_data(void);

// =======================================================================
// INTERRUPT HANDLING                                                     
// =======================================================================

/* ############################################################################ */
/** 
 * \brief write I2C_IRQ_MASK irq_mask register
 *
 * \param irq  specify interrupt
 *
 * \param enable enable interrupt
 *
 * \note should be implemented by IRQ_VENABLE/IRQ_VDISABLE
 *
 * \ingroup i2c
 */
void i2c_enable_irq(i2c_irq_t irq, bool enable);

/* ############################################################################ */
/** 
 * \brief Clear specific I2C IRQ flag
 *
 * \param irq  specify interrupt to be cleared
 *
 * \note see i2c_set_irq_vno - there is better implementation of this function
 *
 * \ingroup i2c
 */
void i2c_clear_irq(i2c_irq_t irq);

/* ############################################################################ */
/** 
 * \brief get I2C irq status register value 
 *
 * \return  contains I2C_IRQ_STATUS 
 *
 * \ingroup i2c
 */
i2c_irq_status_t i2c_get_irq_status(void);

/* ############################################################################ */
/** 
 * \brief get I2C irq_mask register
 *
 * \return read irq_mask value 
 *
 * \ingroup i2c
 */
uint16_t i2c_get_irq_mask(void);

/* ############################################################################ */
/** 
 * \brief set I2C irq_mask register
 *
 * \ingroup i2c
 */
void i2c_set_irq_mask(uint16_t mask);

/* ############################################################################ */
/** 
 * \brief Clear all interrups flags
 */
void i2c_clear_all_irq_events(void);

/* ############################################################################ */
/** 
 * \brief vector number of interrupt event to clear
 *
 * \param irq  specify interrupt to be cleared
 *
 * \ingroup i2c
 */
void i2c_set_irq_vno(i2c_irq_t vno);

/* ############################################################################ */
/** 
 * \brief vector number of enabled pending interrupt with highest priority
 *        (smallest vector number).  when no irq is pending the first unused
 *        irq number is returned.
 *
 * \return next pending interrupt
 *
 * \ingroup i2c
 */
i2c_irq_t i2c_get_next_pending_irq(void);

/**@}*/ 
#endif /* HAVE_I2C_H */

