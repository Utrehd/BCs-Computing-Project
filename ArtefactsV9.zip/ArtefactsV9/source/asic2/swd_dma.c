/* FPGA Release: 10512 */
#include "swd.h"
#include "sram.h"

void
swd_dma_configure (bool cycl_use_tri_buffer,
                      bool cycl_reuse_tx, bool cycl_replace_tx,
                      uint16_t max_trf_length, uint16_t min_trf_break)
{
    swd_dma_config_t dma_config;
    dma_config.val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_CONFIG);
    dma_config.bf.cyc_tri        = cycl_use_tri_buffer  ? 1 : 0;
    dma_config.bf.cyc_tx_reuse   = cycl_reuse_tx        ? 1 : 0;
    dma_config.bf.cyc_tx_replace = cycl_replace_tx      ? 1 : 0;
    dma_config.bf.trf_max_burst  = max_trf_length;
    dma_config.bf.trf_min_break  = min_trf_break;
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_CONFIG, dma_config.val);
}


void
swd_dma_vchannel_reset (swd_dma_vchannel_t vchannel)
{
    swd_dma_command_t dma_command;
    dma_command.val = 0;
    dma_command.bf.dma_resets = 0x1 << vchannel;
    
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_COMMAND, dma_command.val);
}


void
swd_dma_vchannel_set_size (swd_dma_vchannel_t vchannel, uint16_t size)
{
    size++;                                                     // if odd number of bytes
    switch (vchannel) {
    case SWD_DMA_VCHANNEL_CYC_RX:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_RX_SIZE, size);
        break;
    case SWD_DMA_VCHANNEL_ACY_RX_SAPA:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPA_SIZE, size);
        break;
    case SWD_DMA_VCHANNEL_ACY_RX_SAPB:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPB_SIZE, size);
        break;
    case SWD_DMA_VCHANNEL_ACY_RX_SAPC:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPC_SIZE, size);
        break;
    case SWD_DMA_VCHANNEL_SIZES:
    case SWD_DMA_VCHANNEL_CYC_TX:
    case SWD_DMA_VCHANNEL_ACY_TX:
        /* nichts zu tun */
        break;
    }
}


void
swd_dma_vchannel_set_next_pointer (swd_dma_vchannel_t vchannel,
                                      uint16_t * pointer)
{
    switch (vchannel) {
    case SWD_DMA_VCHANNEL_SIZES:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_SIZES_NEXT_PTR, (uint16_t) ((uint32_t)pointer));
        break;
    case SWD_DMA_VCHANNEL_CYC_TX:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_TX_NEXT_PTR, (uint16_t) ((uint32_t)pointer));
        break;
    case SWD_DMA_VCHANNEL_CYC_RX:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_RX_NEXT_PTR, (uint16_t) ((uint32_t)pointer));
        break;
    case SWD_DMA_VCHANNEL_ACY_TX:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_TX_NEXT_PTR, (uint16_t) ((uint32_t)pointer));
        break;
    case SWD_DMA_VCHANNEL_ACY_RX_SAPA:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPA_NEXT_PTR, (uint16_t) ((uint32_t)pointer));
        break;
    case SWD_DMA_VCHANNEL_ACY_RX_SAPB:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPB_NEXT_PTR, (uint16_t) ((uint32_t)pointer));
        break;
    case SWD_DMA_VCHANNEL_ACY_RX_SAPC:
        WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPC_NEXT_PTR, (uint16_t) ((uint32_t)pointer));
        break;
    }
}


bool
swd_dma_vchannel_get_last_pointer (swd_dma_vchannel_t vchannel,
                                      uint16_t ** pointer)
{
    uint16_t temp = 0;
    switch (vchannel) {
    case SWD_DMA_VCHANNEL_SIZES:
        temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_SIZES_LAST_PTR);
        break;
    case SWD_DMA_VCHANNEL_CYC_TX:
        temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_TX_LAST_PTR);
        break;
    case SWD_DMA_VCHANNEL_CYC_RX:
        temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_RX_LAST_PTR);
        break;
    case SWD_DMA_VCHANNEL_ACY_TX:
        temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_TX_LAST_PTR);
        break;
    case SWD_DMA_VCHANNEL_ACY_RX_SAPA:
        temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPA_LAST_PTR);
        break;
    case SWD_DMA_VCHANNEL_ACY_RX_SAPB:
        temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPB_LAST_PTR);
        break;
    case SWD_DMA_VCHANNEL_ACY_RX_SAPC:
        temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPC_LAST_PTR);
        break;
    }

    if ((temp & 0x01) == 0x01) {
        *pointer = (uint16_t *) (BASE_ADDR_SRAM + (temp & ~(0x01)));
        return true;
    }
    else {
        return false;
    }
}


bool
swd_dma_vchannel_get_replaced_pointer (swd_dma_vchannel_t vchannel,
                                          uint16_t ** pointer)
{
    uint16_t temp = 0;
    switch (vchannel) {
    case SWD_DMA_VCHANNEL_SIZES:
        temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_SIZES_REPLACED_PTR);
        break;
    case SWD_DMA_VCHANNEL_CYC_TX:
        temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_TX_REPLACED_PTR);
        break;
    case SWD_DMA_VCHANNEL_CYC_RX:
    case SWD_DMA_VCHANNEL_ACY_TX:
    case SWD_DMA_VCHANNEL_ACY_RX_SAPA:
    case SWD_DMA_VCHANNEL_ACY_RX_SAPB:
    case SWD_DMA_VCHANNEL_ACY_RX_SAPC:
        /* nichts zu tun */
        break;
    }

    if ((temp & 0x01) == 0x01) {
        *pointer = (uint16_t *) (BASE_ADDR_SRAM + (temp & ~(0x01)));
        return true;
    }
    else {
        return false;
    }
}

void
swd_get_dma_channel_status (swd_dma_channel_status_t *
                               dma_channel_status)
{
    dma_channel_status->val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_IRQ_STATUS_DMA);
}


void
swd_get_dma_errors (swd_dma_errors_t * dma_errors)
{
    dma_errors->val = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_ERRORS);
}

void swd_dma_remove_azy_tx_pointer (void){
    swd_dma_command_t dma_command;
    dma_command.val = 0;
    dma_command.bf.azy_tx_remove = 1;
    
    WRITE_REG_16(BASE_ADDR_SWD + ADDR_SWD_DMA_COMMAND, dma_command.val);
}

bool swd_dma_get_azy_tx_removed_pointer (uint16_t ** pointer){
  uint16_t temp = READ_REG_U16(BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_TX_REMOVED_PTR);

  if ((temp & 0x01) == 0x01) {
      *pointer = (uint16_t *) (BASE_ADDR_SRAM + (temp & ~(0x01)));
      return true;
  }
  else {
      return false;
  }
}

