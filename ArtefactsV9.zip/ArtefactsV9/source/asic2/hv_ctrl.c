/* FPGA Release: 10512 */
#include "hv_ctrl.h"

static bool selout_enable;

static hv_ir_pwr_config_t hv_ir_pwr_config;


static bool hv_ctrl_is_idle(void){
  hv_ctrl_irq_status_t hv_ctrl_irq_status;
  hv_ctrl_irq_status.val = READ_REG_U16(AADDR_HV_CTRL_IRQ_STATUS);
  return hv_ctrl_irq_status.bf.jtag_idle ? true : false;
}

bool hv_ctrl_is_cpu_request(void){
  hv_ctrl_irq_status_t hv_ctrl_irq_status;
  hv_ctrl_irq_status.val = READ_REG_U16(AADDR_HV_CTRL_IRQ_STATUS);
  return hv_ctrl_irq_status.bf.cpu_request ? true : false;
}

void hv_ctrl_tap_reset(void){
  while(!hv_ctrl_is_idle() || hv_ctrl_is_cpu_request());
  WRITE_REG_16(AADDR_HV_CTRL_JTAG_IR_CMD, BIT_HV_CTRL_JTAG_IR_CMD_TAP_RESET);
}

uint16_t hv_ctrl_ir_shift(uint8_t ir, bool read){
  uint16_t temp = ir;
  temp |= read << SFT_HV_CTRL_JTAG_IR_CMD_READ;
  while(hv_ctrl_is_cpu_request());
  WRITE_REG_16(AADDR_HV_CTRL_JTAG_IR_CMD, temp);
  if (read){
    while(hv_ctrl_is_cpu_request());
    return READ_REG_U16(AADDR_HV_CTRL_JTAG_DR_CMD);
  }
  return 0;
}

uint16_t hv_ctrl_dr_shift(uint16_t dr){
  while(hv_ctrl_is_cpu_request());
  WRITE_REG_16(AADDR_HV_CTRL_JTAG_DR_CMD, dr);
  while(hv_ctrl_is_cpu_request());
  return READ_REG_U16(AADDR_HV_CTRL_JTAG_DR_CMD);
}

void hv_ctrl_set_nres(bool nres){
  WRITE_REG_16(AADDR_HV_CTRL_JTAG_RESET, nres);
  selout_enable         = false;
  hv_ir_pwr_config.val  = 0;
}

void hv_ctrl_cfg_timing(uint8_t timing){
  WRITE_REG_16(AADDR_HV_CTRL_JTAG_TIMING, timing);
}

//==========================================================================
// pad drive
//==========================================================================
void hv_ctrl_set_phy_ds(bool ds){
  hv_ctrl_drive_strength_t hv_ctrl_drive_strength;
  hv_ctrl_drive_strength.val = READ_REG_U16(AADDR_HV_CTRL_DRIVE_STRENGTH);
  hv_ctrl_drive_strength.bf.phy_ds = ds ? 1 : 0;
  WRITE_REG_16(AADDR_HV_CTRL_DRIVE_STRENGTH, hv_ctrl_drive_strength.val);
}

void hv_ctrl_set_jtag_ds(bool ds){
  hv_ctrl_drive_strength_t hv_ctrl_drive_strength;
  hv_ctrl_drive_strength.val = READ_REG_U16(AADDR_HV_CTRL_DRIVE_STRENGTH);
  hv_ctrl_drive_strength.bf.jtag_ds = ds ? 1 : 0;
  WRITE_REG_16(AADDR_HV_CTRL_DRIVE_STRENGTH, hv_ctrl_drive_strength.val);
}

void hv_ctrl_pwr_config(  bool              vreg_vdd5tx_npd, 
                          bool              pw_vdd5tx_npd, 
                          vreg_vdd3v3_max_t vreg_vdd3v3_max, 
                          pw_vpow_range_t   pw_vpow_range, 
                          uint8_t           pw_vpow_hyst){
  hv_ir_pwr_config.bf.vreg_vdd5tx_npd = vreg_vdd5tx_npd;
  hv_ir_pwr_config.bf.pw_vdd5tx_npd   = pw_vdd5tx_npd;
  hv_ir_pwr_config.bf.vreg_vdd3v3_max = vreg_vdd3v3_max;
  hv_ir_pwr_config.bf.pw_vpow_hyst    = pw_vpow_hyst;
  hv_ir_pwr_config.bf.pw_vpow_range   = pw_vpow_range;
  hv_ctrl_ir_shift(ADDR_HV_IR_IR_PWR_CONFIG, false);
  hv_ctrl_dr_shift(hv_ir_pwr_config.val);
}

void hv_ctrl_set_pw_vpow_vth(uint8_t pw_vpow_vth){
  hv_ir_pwr_config.bf.pw_vpow_vth   = pw_vpow_vth;
  hv_ctrl_ir_shift(ADDR_HV_IR_IR_PWR_CONFIG, false);
  hv_ctrl_dr_shift(hv_ir_pwr_config.val);
}

void hv_ctrl_set_selout_enable(bool enable){
  selout_enable = enable;
  if (!enable){
    hv_ctrl_set_selout(false);
  }
}

void hv_ctrl_set_selout(bool selout){
  uint16_t temp = 0;
  temp |= selout_enable << SFT_HV_IR_SELOUT_HSELOUT_NPD;
  temp |= selout        << SFT_HV_IR_SELOUT_HSELOUT_TX;
  hv_ctrl_ir_shift(ADDR_HV_IR_IR_SELOUT, false);
  hv_ctrl_dr_shift(temp);
}

void hv_ctrl_set_gpo(bool en, bool val){
  uint16_t temp = 0;
  temp |= en    << SFT_HV_IR_GPO5V_HGPO_EN;
  temp |= val   << SFT_HV_IR_GPO5V_HGPO_OUT;
  hv_ctrl_ir_shift(ADDR_HV_IR_IR_GPO5V, false);
  hv_ctrl_dr_shift(temp);
}

void hv_ctrl_set_isink(uint8_t no, uint8_t val){
  switch(no){
  case 0: hv_ctrl_ir_shift(ADDR_HV_IR_IR_ISINK0, false); break;
  case 1: hv_ctrl_ir_shift(ADDR_HV_IR_IR_ISINK1, false); break;
  case 2: hv_ctrl_ir_shift(ADDR_HV_IR_IR_ISINK2, false); break;
  }
  hv_ctrl_dr_shift(val);
}

void hv_ctrl_set_selin_enable(bool enable, bool vlim){
  uint16_t temp = 0;
  temp |= enable << SFT_HV_IR_SELIN_CONFIG_HSELIN_NPD;
  temp |= vlim   << SFT_HV_IR_SELIN_CONFIG_HSELIN_VLIM;
  hv_ctrl_ir_shift(ADDR_HV_IR_IR_SELIN_CONFIG, false);
  hv_ctrl_dr_shift(temp);
}

bool hv_ctrl_get_selin(void){
  return (hv_ctrl_ir_shift(ADDR_HV_IR_IR_SELIO_STATUS, true) & BIT_HV_IR_SELIN_STATUS_HSELIN_RX) ? true : false;
}

bool hv_ctrl_get_selout(void){
  return (hv_ctrl_ir_shift(ADDR_HV_IR_IR_SELIO_STATUS, true) & BIT_HV_IR_SELIN_STATUS_HSELOUT_ACK) ? true : false;
}

void hv_ctrl_cfg_phy( bool                      hrx485_npd, 
                      bool                      htx485_npd, 
                      bool                      htx485_slew_enable, 
                      htx485_bbm_fast_t         htx485_bbm_fast, 
                      htx485_auto_shutdown_t    htx485_auto_shutdown, 
                      htx485_tempsens_enable_t  htx485_tempsens_enable, 
                      htx485_tempsens_mask_t    htx485_tempsens_mask){
  uint16_t temp = 0;
  temp |= hrx485_npd              << SFT_HV_IR_RS485_CONFIG_HRX485_NPD;
  temp |= htx485_npd              << SFT_HV_IR_RS485_CONFIG_HTX485_NPD;
  temp |= htx485_slew_enable      << SFT_HV_IR_RS485_CONFIG_HTX485_SLEW_ENABLE;
  temp |= htx485_bbm_fast         << SFT_HV_IR_RS485_CONFIG_HTX485_BBM_FAST;
  temp |= htx485_auto_shutdown    << SFT_HV_IR_RS485_CONFIG_HTX485_AUTO_SHUTDOWN;
  temp |= htx485_tempsens_enable  << SFT_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_ENABLE;
  temp |= htx485_tempsens_mask    << SFT_HV_IR_RS485_CONFIG_HTX485_TEMPSENS_MASK;
  
  hv_ctrl_ir_shift(ADDR_HV_IR_IR_RS485_CONFIG, false);
  hv_ctrl_dr_shift(temp);
}

void hv_ctrl_set_r_hvhkmux(hv_ir_hvhkmux_t hv_ir_hvhkmux){
  hv_ctrl_ir_shift(ADDR_HV_IR_IR_HVHKMUX, false);
  hv_ctrl_dr_shift(hv_ir_hvhkmux.val);
}

hv_ir_status_t hv_ctrl_get_hv_status(void){
  hv_ir_status_t temp;
  temp.val = hv_ctrl_ir_shift(ADDR_HV_IR_IR_STATUS, true);
  return temp;
}

void hv_ctrl_set_hv_mask(uint16_t mask){
  hv_ctrl_ir_shift(ADDR_HV_IR_IR_MASK, false);
  hv_ctrl_dr_shift(mask);
}

void hv_ctrl_set_gpo_el_req_enable(bool en){
  hv_ctrl_gpo_filter_t hv_ctrl_gpo_filter;
  hv_ctrl_gpo_filter.val = READ_REG_U16(AADDR_HV_CTRL_GPO_FILTER);
  hv_ctrl_gpo_filter.bf.req_enable = en;
  WRITE_REG_16(AADDR_HV_CTRL_GPO_FILTER, hv_ctrl_gpo_filter.val);
}

void hv_ctrl_enable_irq(hv_ctrl_irq_t irq, bool enable){  
  if (enable) WRITE_REG_16(AADDR_HV_CTRL_IRQ_VENABLE, irq);
  else WRITE_REG_16(AADDR_HV_CTRL_IRQ_VDISABLE, irq);
}

hv_ctrl_irq_status_t hv_ctrl_get_irq_status(void){
  hv_ctrl_irq_status_t status;
  status.val = READ_REG_U16(AADDR_HV_CTRL_IRQ_STATUS);
  return status;
}

void hv_ctrl_clear_all_irqs(void){
  WRITE_REG_16(AADDR_HV_CTRL_IRQ_STATUS, 0xFFFF);
}

void hv_ctrl_clear_irqs_vno(uint16_t vno){
  WRITE_REG_16(AADDR_HV_CTRL_IRQ_VNO, vno);
}

hv_ctrl_irq_t hv_ctrl_get_pending_irq(void){
    return (hv_ctrl_irq_t) READ_REG_U16(AADDR_HV_CTRL_IRQ_VNO);
}
