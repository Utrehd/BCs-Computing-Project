/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         gpio.h
*
* @brief        General Purpose Input/Output HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_GPIO_H
#define HAVE_GPIO_H

/**
 * \example example_gpio.c
 * This is an example of how to use GPIO block.
 */

/**
 * \defgroup gpio ASIC2 General Purpose Input/Output HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control General Purpose Input/Output
 *
 * \details See code example: @include example_gpio.c
 */
/**@{*/ 

#include "device.h"
#include "gpio_bf.h"
#include "gpio_irq.h"

#define GPIO0_WIDTH  9 ///< GPIO Group 0 width
#define GPIO1_WIDTH  9 ///< GPIO Group 1 width
#define GPIO2_WIDTH  9 ///< GPIO Group 2 width
#define GPIO3_WIDTH  9 ///< GPIO Group 3 width


/* ############################################################################ */
/**
 * \brief This is an enum class for GPIO to identify bits
 *
 * \ingroup gpio 
 */ 
typedef enum {
  /**
   * Bit 0
   */ 
  GPIO_BIT_0                  = 0x0001,
  /**
   * Bit 1
   */ 
  GPIO_BIT_1                  = 0x0002,
  /**
   * Bit 2
   */ 
  GPIO_BIT_2                  = 0x0004,
  /**
   * Bit 3
   */ 
  GPIO_BIT_3                  = 0x0008,
  /**
   * Bit 4
   */ 
  GPIO_BIT_4                  = 0x0010,
  /**
   * Bit 5
   */ 
  GPIO_BIT_5                  = 0x0020,
  /**
   * Bit 6
   */ 
  GPIO_BIT_6                  = 0x0040,
  /**
   * Bit 7
   */ 
  GPIO_BIT_7                  = 0x0080,
  /**
   * Bit 8
   */ 
  GPIO_BIT_8                  = 0x0100,
  /**
   * Bit 9
   */ 
  GPIO_BIT_9                  = 0x0200,
  /**
   * Bit 10
   */ 
  GPIO_BIT_10                 = 0x0400,
  /**
   * Bit 11
   */ 
  GPIO_BIT_11                 = 0x0800,
  /**
   * Bit 12
   */ 
  GPIO_BIT_12                 = 0x1000,
  /**
   * Bit 13
   */ 
  GPIO_BIT_13                 = 0x2000,
  /**
   * Bit 14
   */ 
  GPIO_BIT_14                 = 0x4000,
  /**
   * Bit 15
   */ 
  GPIO_BIT_15                 = 0x8000,
  /**
   * All bits
   */ 
  GPIO_BIT_ALL                = 0xFFFF,
} gpio_bits_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for GPIO to identify group
 *
 * \ingroup gpio 
 */ 
typedef enum {
  /**
   * Group 0
   */ 
  GPIO_GROUP_0                = 0,
  /**
   * Group 1
   */ 
  GPIO_GROUP_1                = 1,
  /**
   * Group 2
   */ 
  GPIO_GROUP_2                = 2,
  /**
   * Group 3
   */ 
  GPIO_GROUP_3                = 3,
} gpio_group_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for GPIO to identify source selection
 *
 * \ingroup gpio 
 */ 
typedef enum {
  /**
   * Select resyn_pp
   */ 
  GPIO_SRC_SEL_RESYN_PP       = 0x00,
  /**
   * Select filter f0
   */ 
  GPIO_SRC_SEL_F0             = 0x01,
  /**
   * Select filter f1
   */ 
  GPIO_SRC_SEL_F1             = 0x02,

} gpio_src_sel_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for GPIO to identify interrupt event
 *
 * \ingroup gpio 
 */ 
typedef enum {
  /**
   * no interrupt event generation
   */ 
  GPIO_IRQ_TYPE_NONE          = 0x00,
  /**
   * level irq = 0
   */ 
  GPIO_IRQ_TYPE_LEVEL_0       = 0x01,
  /**
   * level irq = 1
   */ 
  GPIO_IRQ_TYPE_LEVEL_1       = 0x02,
  /**
   * rising edge
   */ 
  GPIO_IRQ_TYPE_EDGE_RISING   = 0x03,
  /**
   * falling edge
   */ 
  GPIO_IRQ_TYPE_EDGE_FALLING  = 0x04,
  /**
   * both edges
   */ 
  GPIO_IRQ_TYPE_EDGE_BOTH     = 0x05,
} gpio_irq_type_t;


// Aktiviert die Eingangsfilter F0 und F1 einer Gruppe.

/* ############################################################################ */
/**
 * \brief Function to enable GPIO filter
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param enable     1: Enable
 */ 
void gpio_enable_filter(gpio_group_t group, bool enable);

// Aktiviert die Hardwaresynchronisierung.

/* ############################################################################ */
/**
 * \brief Function to enable GPIO hardware sync
 *
 * \ingroup gpio 
 * 
 * \param enable 1: Enable
 */ 
void gpio_enable_hwsync(bool enable);

// Synchronisiert die GPIOs.

/* ############################################################################ */
/**
 * \brief Function to cause GPIO sync event
 *
 * \ingroup gpio 
 */ 
void gpio_synchronize(void);

// Setzt die Samplingperiode des Eingangsfilters F0 einer Gruppe.

/* ############################################################################ */
/**
 * \brief Function to set GPIO filter f0 period
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t 
 * 
 * \param period     Sampling period of f0, in system clock cycles; >=1
 */ 
void gpio_set_f0_period(gpio_group_t group, uint8_t period);

// Gibt die Samplingperiode des Eingangsfilters F0 einer Gruppe zur�ck.

/* ############################################################################ */
/**
 * \brief Function to get GPIO filter f0 period
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \return           Value of ampling period of f0
 */ 
uint16_t gpio_get_f0_period(gpio_group_t group);

// Setzt die Samplingperiode des Eingangsfilters F1 einer Gruppe.

/* ############################################################################ */
/**
 * \brief Function to set GPIO filter f1 period
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param period     Sampling period of f1, in periods of f0; >=1
 */ 
void gpio_set_f1_period(gpio_group_t group, uint16_t period);

// Gibt die Samplingperiode des Eingangsfilters F1 einer Gruppe zur�ck.

/* ############################################################################ */
/**
 * \brief Function to get GPIO filter f1 period
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \return           Value of sampling period of f1, in periods of f0; >=1
 */ 
uint16_t gpio_get_f1_period(gpio_group_t group);

// Setzt Output Enable einer Gruppe.

/* ############################################################################ */
/**
 * \brief Function to enable GPIO output
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 * 
 * \param oe        1 : driver of the pad is enabled
 */ 
void gpio_set_oe(gpio_group_t group, gpio_bits_t bits, bool oe);

// Setzt Input Enable einer Gruppe.

/* ############################################################################ */
/**
 * \brief Function to enable GPIO input
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 * 
 * \param ie        1 : input of the pad is enabled, enable only when pad is driven externally
 */ 
void gpio_set_ie(gpio_group_t group, gpio_bits_t bits, bool ie);

// Setzt die Ausg�nge einer Gruppe.

/* ############################################################################ */
/**
 * \brief Function to set GPIO output
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 * 
 * \param data      Value assigned to the output driver
 */ 
void gpio_set_out(gpio_group_t group, gpio_bits_t bits, uint16_t data);


/* ############################################################################ */
/**
 * \brief Function to set GPIO output driver (atomic operation)
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 */ 
void gpio_cmd_out_set(gpio_group_t group, gpio_bits_t bits);


/* ############################################################################ */
/**
 * \brief Function to clear GPIO output driver (atomic operation)
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 */ 
void gpio_cmd_out_clr(gpio_group_t group, gpio_bits_t bits);


/* ############################################################################ */
/**
 * \brief Function to toggle GPIO output driver (atomic operation)
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 */ 
void gpio_cmd_out_toggle(gpio_group_t group, gpio_bits_t bits);

// Gibt die Ausg�nge einer Gruppe zur�ck.

/* ############################################################################ */
/**
 * \brief Function to get GPIO output value
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 * 
 * \return          Value of the current output
 */ 
uint16_t gpio_get_out(gpio_group_t group, gpio_bits_t bits);


// Gibt die Eing�nge einer Gruppe zur�ck.

/* ############################################################################ */
/**
 * \brief Function to get GPIO input value
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 * 
 * \return          Value of the current input
 */ 
uint16_t gpio_get_in(gpio_group_t group, gpio_bits_t bits);

// Gibt den Wert des Eingangsfilters F0 zur�ck.

/* ############################################################################ */
/**
 * \brief Function to get GPIO filter f0 configuration value
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 * 
 * \return          Value of the current filter f0 configuration
 */ 
uint16_t gpio_get_f0(gpio_group_t group, gpio_bits_t bits);

// Gibt den Wert des Eingangsfilters F1 zur�ck.

/* ############################################################################ */
/**
 * \brief Function to get GPIO filter f1 configuration value
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 * 
 * \return          Value of the current filter f1 configuration
 */ 
uint16_t gpio_get_f1(gpio_group_t group, gpio_bits_t bits);

// Setzt den Wert des synchronisierten Ausgangs.

/* ############################################################################ */
/**
 * \brief Function to set GPIO synchronized value
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 * 
 * \param data      Synchronized value
 */ 
void gpio_set_sync(gpio_group_t group, gpio_bits_t bits, uint16_t data);

// Gibt den Wert des synchronisierten Eingangs zur�ck.

/* ############################################################################ */
/**
 * \brief Function to get GPIO synchronized value
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param bits      Select pinout bit <br>
 *                   \see gpio_bits_t
 * 
 * \return          Current synchronized value
 */ 
uint16_t gpio_get_sync(gpio_group_t group, gpio_bits_t bits);

// Setzt die Quelle f�r den synchronisierten Eingang.

/* ############################################################################ */
/**
 * \brief Function to set GPIO source for the sync register
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param source     Select source for the sync register <br>
 *                   \see gpio_src_sel_t
 */ 
void gpio_set_sync_source(gpio_group_t group, gpio_src_sel_t source);

// Gibt die Quelle f�r den synchronisierten Eingang zur�ck.

/* ############################################################################ */
/**
 * \brief Function to get GPIO source for the sync register
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \return           Current source for the sync register <br>
 *                   \see gpio_src_sel_t
 */ 
gpio_src_sel_t gpio_get_sync_source(gpio_group_t group);

// config GPIO NMI

/* ############################################################################ */
/**
 * \brief Function to set GPIO Non Maskable Interrupt (NMI) configuration
 *
 * \ingroup gpio 
 * 
 * \param group                     Select GPIO group to use as NMI input <br>
 *                                  \see gpio_group_t
 * 
 * \param pin                       Select GPIO group pin to use as NMI input
 * 
 * \param ccpu0_nmi_enable          1: enable NMI for CCPU0
 * 
 * \param acpu1_nmi_enable          1: enable NMI for ACPU1
 */ 
void gpio_config_nmi(gpio_group_t group, uint8_t pin, bool ccpu0_nmi_enable, bool acpu1_nmi_enable);

// Setzt die Interrupt-Quelle einer Gruppe.

/* ############################################################################ */
/**
 * \brief Function to set GPIO Interrupt source
 *
 * \ingroup gpio 
 * 
 * \param group      Select pinout group <br>
 *                   \see gpio_group_t
 * 
 * \param source     Select interrupt source <br>
 *                   \see gpio_src_sel_t
 */ 
void gpio_set_irq_source(gpio_group_t group, gpio_src_sel_t source);

// Setzt den Typ eines Interrupts.

/* ############################################################################ */
/**
 * \brief Function to set GPIO Interrupt event
 *
 * \ingroup gpio 
 * 
 * \param irq        Select Interrupt number <br>
 *                   \see gpio_irq_t
 * 
 * \param type       Select type of event <br>
 *                   \see gpio_irq_type_t
 */ 
void gpio_set_irq_type(gpio_irq_t irq, gpio_irq_type_t type);

// Aktiviert ein GPIO-Interrupt.

/* ############################################################################ */
/**
 * \brief Function to enable GPIO Interrupt
 *
 * \ingroup gpio 
 * 
 * \param irq        Select Interrupt number <br>
 *                   \see gpio_irq_t
 * 
 * \param enable     1: Enable
 */ 
void gpio_enable_irq(gpio_irq_t irq, bool enable);

// Aktiviert ein GPIO-Interrupt.

/* ############################################################################ */
/**
 * \brief Function to enable GPIO Interrupt (only with the vector number)
 *
 * \ingroup gpio 
 * 
 * \param irq        Select Interrupt vector number <br>
 *                   \see gpio_irq_t
 */ 
void gpio_venable_irq(gpio_irq_t irq);

// Dektiviert ein GPIO-Interrupt.

/* ############################################################################ */
/**
 * \brief Function to disable GPIO Interrupt (only with the vector number)
 *
 * \ingroup gpio 
 * 
 * \param irq        Select Interrupt vector number <br>
 *                   \see gpio_irq_t
 */ 
void gpio_vdisable_irq(gpio_irq_t irq);

// L�scht ein GPIO-Interrupt.

/* ############################################################################ */
/**
 * \brief Function to clear GPIO Interrupt (only with the vector number)
 *
 * \ingroup gpio 
 * 
 * \param irq        Select Interrupt vector number <br>
 *                   \see gpio_irq_t
 */ 
void gpio_vclear_irq(gpio_irq_t irq);

// L�scht ein GPIO-Interrupt.

/* ############################################################################ */
/**
 * \brief Function to clear GPIO Interrupt
 *
 * \ingroup gpio 
 * 
 * \param irq        Select Interrupt vector number <br>
 *                   \see gpio_irq_t
 */ 
void gpio_clear_irq(gpio_irq_t irq);

/* ############################################################################ */
/**
 * \brief Function to clear GPIO Interrupt (only with the vector number)
 *
 * \ingroup gpio 
 * 
 * \param irq        Select Interrupt vector number <br>
 *                   \see gpio_irq_t
 */ 
void gpio_clear_irq_vno(gpio_irq_t irq);


/* ############################################################################ */
/**
 * \brief Function to get GPIO next pending interrupt
 *
 * \ingroup gpio 
 * 
 * \return             vector number of enabled pending interrupt with highest priority
 *                     (smallest vector number). when no irq is pending the first unused irq
 *                     number is returned.
 *                     \see gpio_irq_t
 */ 
gpio_irq_t gpio_get_next_pending_irq(void);

/* ############################################################################ */
/**
 * \brief Function to get GPIO Interrupt status
 *
 * \ingroup gpio 
 * 
 * \return Current interrupt status
 */ 
uint16_t gpio_get_irq_status(void);

/* ############################################################################ */
/**
 * \brief Function to get GPIO Interrupt mask
 *
 * \ingroup gpio 
 * 
 * \return Current interrupt mask value
 */ 
uint16_t gpio_get_irq_mask(void);

/**@{*/ 
#endif /* HAVE_GPIO_H */
