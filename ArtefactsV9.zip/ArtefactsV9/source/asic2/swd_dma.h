/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swd_dma.h
*
* @brief        SWD_PM HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SWD_DMA_H
#define HAVE_SWD_DMA_H

#ifndef HAVE_SWD_H
#error "Please include swd.h instead of this file."
#endif


/* ############################################################################ */
/**
 * \brief Configures the SWD DMA module
 *
 * \ingroup swd_pm 
 * 
 * \param cycl_use_tri_buffer If TRUE is given here, Receiver tripplebuffering used. <br>
 *                            Otherwise, doublebuffering is used.
 * 
 * \param cycl_reuse_tx       If TRUE is given here, the last
 *                            remaining pointers in VCHANNEL_CYC_TX reused.
 * 
 * 
 * \param cycl_replace_tx     If TRUE is given here,
 *                            VCHANNEL_CYC_TX written pointers overwritten when new pointers in VCHANNEL_CYC_TX. <br>
 *                            Otherwise the new pointers are ignored.
 * 
 * \param max_transfer_length maximum transfer length (maximum length = trf_max_burst+1)
 * 
 * \param min_transfer_break  minimum transfer break when maximum transfer done (0 = no break)
 */ 
void swd_dma_configure (bool cycl_use_tri_buffer,
                           bool cycl_reuse_tx,
                           bool cycl_replace_tx,
                           uint16_t max_transfer_length,
                           uint16_t min_transfer_break);



/* ############################################################################ */
/**
 * \brief Reset DMA command
 *
 * \ingroup swd_pm 
 * 
 * \param vchannel 1: reset and clear complete (NEXT and LAST) DMA virtual channel pointer FIFO<br>
 *                 bit 0: VCHANNEL_SIZES <br>
 *                 bit 1: VCHANNEL_CYC_TX <br>
 *                 bit 2: VCHANNEL_CYC_RX <br>
 *                 bit 3: VCHANNEL_AZY_TX <br>
 *                 bit 4: VCHANNEL_AZY_RX_SAPA <br>
 *                 bit 5: VCHANNEL_AZY_RX_SAPB <br>
 *                 bit 6: VCHANNEL_AZY_RX_SAPC <br>
 *
 * \remark DMA_COMMAND will be reset by hardware.
 */ 
void swd_dma_vchannel_reset (swd_dma_vchannel_t vchannel);


/* ############################################################################ */
/**
 * \brief Sets the size of the virtual DMA channel in bytes.
 *
 * \ingroup swd_pm 
 * 
 * \param vchannel  The virtual DMA channel (CYC_RX, AZY_RX_SAPA, AZY_RX_SAPB, AZY_RX_SAPC)
 * 
 * \param size      maximum window size in words
 */ 
void swd_dma_vchannel_set_size (swd_dma_vchannel_t vchannel, uint16_t size);


/* ############################################################################ */
/**
 * \brief Sets the next pointer to use for a virtual DMA channel.
 *
 * \ingroup swd_pm 
 * 
 * \param vchannel The virtual DMA channel (CYC_RX, AZY_RX_SAPA, AZY_RX_SAPB, AZY_RX_SAPC)
 * 
 * \param pointer next pointer in words to by used by PM for frame window FIFO
 *
 * \remarks In effect on providing a pointer by DMA_AZY_TX_NEXT_PTR a request for acyclic transfer is queried via
 *          cyclic transfer automaticlly. If this request is granted successfully, the request will be reset by deleting the pointer.
 */ 
void swd_dma_vchannel_set_next_pointer (swd_dma_vchannel_t vchannel,
                                           uint16_t * pointer);


/// Liest den zuletzt benutzten Zeiger eines virtuellen DMA-Kanals aus.
/**
 * @param vchannel              Der virtuelle DMA-Kanal, fuer den der Zeiger
 *                              ausgelesen werden soll.
 * @param pointer               Ein Zeiger auf die Variable, in die der
 *                              ausgelesene Zeiger abgelegt werden soll.
 * @return                      Wenn ein gueltiger Zeiger vorlag wird TRUE
 *                              zurueckgegeben.
 */

/* ############################################################################ */
/**
 * \brief Reads the last used pointer of a virtual DMA channel.
 *
 * \ingroup swd_pm 
 * 
 * \param vchannel   The virtual DMA channel for which the pointer is to be read out.
 * 
 * \param pointer    A pointer to the variable to which the read out pointers.
 * 
 * \return           If a valid pointer is present, TRUE returned.
 */ 
bool swd_dma_vchannel_get_last_pointer (swd_dma_vchannel_t vchannel,
                                           uint16_t ** pointer);


/* ############################################################################ */
/**
 * \brief Get replaced pointer
 *
 * \ingroup swd_pm 
 * 
 * \param vchannel    The virtual DMA channel for which the pointer is to be read out.
 * 
 * \param pointer     pointer to replaced pointer when next pointer was written to full CYC TX FIFO
 *                    and �Replace� Option was enabled
 * 
 * \return            pointer is valid (Pointer was replaced)
 *
 * \remarks           The Replaced Pointer is invalidated on read.
 */ 
bool swd_dma_vchannel_get_replaced_pointer (swd_dma_vchannel_t vchannel, uint16_t ** pointer);


/* ############################################################################ */
/**
 * \brief Get DMA irq status
 *
 * \ingroup swd_pm 
 * 
 * \param dma_channel_status pointer to DMA irq status
 */ 
void swd_get_dma_channel_status (swd_dma_channel_status_t * dma_channel_status);


/* ############################################################################ */
/**
 * \brief Get DMA errors
 *
 * \ingroup swd_pm 
 * 
 * \param dma_errors  pointer to DMA errors
 *
 * \remarks Register will be reset on read
 */ 
void swd_get_dma_errors (swd_dma_errors_t * dma_errors);


/* ############################################################################ */
/**
 * \brief Safe remove acyclic transmit pointer (only when not used)
 *
 * \ingroup swd_pm 
 *
 * \remarks DMA_COMMAND will be reset by hardware.
 */ 
void swd_dma_remove_azy_tx_pointer (void);

/* ############################################################################ */
/**
 * \brief Get removed pointer after remove command
 *
 * \ingroup swd_pm 
 * 
 * \param pointer removed pointer after remove command
 * 
 * \return  pointer is valid (Pointer was replaced)
 */ 
bool swd_dma_get_azy_tx_removed_pointer (uint16_t ** pointer);

#endif /* HAVE_SWD_DMA_H */
