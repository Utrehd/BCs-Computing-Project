/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         saradc_ctrl.h
*
* @brief        SAR ADC Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SARADC_CTRL_H
#define HAVE_SARADC_CTRL_H

/**
 * \example example_saradc.c
 * This is an example of how to use SAR ADC control block.
 */
 
/**
 * \defgroup saradc_ctrl ASIC2 SAR ADC Control HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control SAR ADC Control
 */
/**@{*/ 

#include "device.h"
#include "saradc_ctrl_bf.h"
#include "saradc_ctrl_irq.h"

/// @cond DEV
#define SARC_TRIGGER_MIMM       0xFFC0
#define SARC_TRIGGER_SMUXIMM    0xFFC0
#define SARC_TRIGGER_ANOOR_0    0xFFD0
#define SARC_TRIGGER_AOOR_0     0xFFE0
#define SARC_TRIGGER_BUS_WRITE  0xFFF0
#define SARC_TRIGGER_WRITE_CFG  0xFFF1
#define SARC_TRIGGER_SYNC_EVT   0xFFF2
#define SARC_TRIGGER_WAIT       0xFFF3
#define SARC_TRIGGER_ST_BP      0xFFF4
#define SARC_TRIGGER_ST_TADR    0xFFF5
#define SARC_TRIGGER_LOOP_BP    0xFFF6
#define SARC_TRIGGER_LOOP_NBP   0xFFF7
#define SARC_TRIGGER_LOOP_TADR  0xFFF8
#define SARC_TRIGGER_LOOP_NTADR 0xFFF9
#define SARC_TRIGGER_GOTO_SUMLEQ 0xFFFA
#define SARC_TRIGGER_GOTO_SUMNLEQ 0xFFFB
#define SARC_TRIGGER_GOTO_BPLEQ 0xFFFC
#define SARC_TRIGGER_GOTO_BPNLEQ 0xFFFD
#define SARC_TRIGGER_GOTO       0xFFFE
#define SARC_TRIGGER_END        0xFFFF
#define SARC_TRIGGER_MIMM_HIST  0xFFE9

// ------------------------------------------------------------
// these structures need to be packed
// ------------------------------------------------------------
#ifdef __GNUC__
#define _PACKED_ __attribute__ ((packed))
#endif

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(push)
#pragma pack(2)
#endif
/// @endcond


/** 
 * \brief This structure describes SAR ADC instruction 
 *
 * \ingroup saradc_ctrl
 */
typedef struct _PACKED_{
  /**
   * 16bit L0 Word which contains
   * # target address
   * # condition value
   */
  volatile uint16_t target_adr                    :    16;      /* [15:0]  */
  
  /**
   * 0..15 number of samples minus one to sum, i.e. 1..16 samples can be summed
   */
  volatile uint16_t no_sample                     :    4;       /* [19:16] */
  
  /**
   * 0: do not perform any sampling, only set multiplexer when trigger occurs <br>
   * 1..31 number of sums to write to memory
   */
  volatile uint16_t no_sum                        :    5;       /* [24:20] */
  
  /**
   * 0..31 channel no to set after conversion of the last sample of this sample sequence
   * for the next sample sequence (if CFG_SAR_TIMING . mux_phase>3)
   */
  volatile uint16_t ch_no                         :    5;       /* [29:25] */
  
  /**
   *  see trigger
   */
  volatile uint16_t trigger_type                  :    2;       /* [31:30] */
  
  /**
   * L2 word <br>
   * sample sequence starts
   * - for trigger type [1:0] = 00 : when pwm_phase[15:0] matches trigger[15:0]
   * - for trigger type [1 :0] = 10 or 11 and trigger is
   *   + 0x0000..0x03FF: when base_phase[9:0] matches trigger[9:0]
   *   + 0xFFC0: immediately
   *   + 0xFFD0 "CMP" Assert "out of range" [15:0irq IRQ_STATUS.oor0 when the
   *            following condition is met:0x02[14:0] <= last_sum <= target_adr[15:0].
   *   + 0xFFD1 " " IRQ_STATUS.oor1 " "
   *   + 0xFFD2 " " IRQ_STATUS.oor2 " "
   *   + 0xFFD3 " " IRQ_STATUS.oor3 " "
   *   + 0xFFD4 " " IRQ_STATUS.oor4 " "
   *   + 0xFFD5 " " IRQ_STATUS.oor5 " "
   *   + 0xFFD6 " " IRQ_STATUS.oor6 " "
   *   + 0xFFD7 " " IRQ_STATUS.oor7 " "
   *   + 0xFFD8 " " IRQ_STATUS.oor8 " "
   * Special functions (do not wait for a trigger, not use ADC nor modify mux):
   *   + 0xFFE0 "CMP" Assert "out of range" irq IRQ_STATUS.oor0 when the
   *     following condition is violated:
   *     0x02[14:0] <= last_sum <= target_adr[15:0].
   *   + 0xFFE1 " " IRQ_STATUS.oor1 " "
   *   + 0xFFE2 " " IRQ_STATUS.oor2 " "
   *   + 0xFFE3 " " IRQ_STATUS.oor3 " "
   *   + 0xFFE4 " " IRQ_STATUS.oor4 " "
   *   + 0xFFE5 " " IRQ_STATUS.oor5 " "
   *   + 0xFFE6 " " IRQ_STATUS.oor6 " "
   *   + 0xFFE7 " " IRQ_STATUS.oor7 " "
   *   + 0xFFE8 " " IRQ_STATUS.oor8 " "
   *   + 0xFFF1 WRITE_CFG Apply target_adr [13:0] to CFG register
   *   + 0xFFF2 "SYNC_OUT" trigger sync out event (see SYNC_OUT_CFG)
   *   + 0xFFF3 "WAIT" wait for target_adr+2 clk cycles
   *   + 0xFFF4 "ST_BP" store base_phase in place of sum
   *   + 0xFFF5 "ST_TADR" store TADR in place of sum
   *   + 0xFFF6 LOOP UNTIL (0x02[14:0] <= base_phase <= target_adr[15:0])
   *   + 0xFFF7 LOOP UNTIL NOT (0x02[14:0] <= base_phase <= target_adr[15:0])
   *   + 0xFFF8 LOOP UNTIL (0x02[14:0] <= TADR <= target_adr[15:0])
   *   + 0xFFF9 LOOP UNTIL NOT (0x02[14:0] <= TADR <= target_adr[15:0])
   *   + 0xFFFA GOTO target_adr[15:0] WHEN last_sum <= 0x02[14:0]
   *   + 0xFFFB GOTO target_adr[15:0] WHEN NOT last_sum <= 0x02[14:0]
   *   + 0xFFFC GOTO target_adr[15:0] WHEN base_phase <= 0x02[14:0]
   *   + 0xFFFD GOTO target_adr[15:0] WHEN NOT base phase <= 0x02[14:0]
   *   + 0xFFFE "GOTO" target_adr[15:0] 0x02[14:0]
   *   + 0xFFFF "END" list completed (last list item)
   * - for trigger type[1:0]= 01
   *   + 0x<wait>01 .. 0x<wait>FF "DEAD TIME TRIGGER"
   *     A trigger occurs when dead_time_evt[7:0] occurrs and the corresponding
   *     bit 0x04[7.0] is set. Sampling is executed after <wait>*
   *     WAIT_PRESCALER_DEAD_TIME clock cycles after the trigger.
   *   + 0x<ext>00 SAMPLE IMMEDIATELY with sample time extension
   *     The ADC starts sampling immediately. The minimal sampling phase is
   *     extended by <ext>*WAIT_PRESCALER_SAMPLING_EXTENSION number
   *     of clock cycles for each sample.
   */
  volatile uint16_t trigger                       :    16;      /* [47:32] */
} saradc_ctrl_list_entry;

#ifdef __IAR_SYSTEMS_ICC__
#pragma pack(pop)
#endif 

// ------------------------------------------------------------
// no packing needed here
// ------------------------------------------------------------

//...

/* ======================================================================= */
/* ADDRESS HELPER FUNCTIONS                                                */
/* ======================================================================= */
/// @cond DEV
#define ADR_TO_SARC(adr) ((uint16_t *) (adr))
/// @endcond

/* ======================================================================= */
/* LIST HELPER FUNCTIONS                                                   */
/* ======================================================================= */

/* ############################################################################ */
/**
 * \brief create list item using explicit encoding of L0, L1, L2
 *
 * \param  cmd   pointer to the list entry
 *
 * \param  L0   first 16 bit word of list entry
 *
 * \param  L1   second 16 bit word of list entry
 *
 * \param  L2   third 16 bit word of list entry
 */
void saradc_ctrl_create_list_item_u16(saradc_ctrl_list_entry *list_entry, uint16_t l0, uint16_t l1, uint16_t l2);

/* ############################################################################ */
/** 
 * \brief  create list item using generic sampling command structure
 *
 * \param  target_adr   target memory address for storing samples
 *
 * \param  no_sample   number of samples per sum -1
 *
 * \param  no_sum   number of sums
 *
 * \param  ch_no   channel to be selected after sampling
 *
 * \param  trigger_type   trigger type, see ASIC2 specification 6.28.5
 *
 * \param  trigger   trigger, see ASIC2 specification 6.28.5
 */
void saradc_ctrl_create_list_item(saradc_ctrl_list_entry *list_entry, uint16_t target_adr, uint16_t no_sample, uint16_t no_sum, uint16_t ch_no, uint16_t trigger_type, uint16_t trigger);

/* ======================================================================= */
/* MODULE HANDLING                                                         */
/* ======================================================================= */

/* ############################################################################ */
/** 
 * \brief  write SAR_ADC_CTRL cfg register
 *
 * \param  cfg  configuration data
 *
 * \return void
 */
void saradc_ctrl_set_cfg(saradc_ctrl_cfg_t cfg);

/* ############################################################################ */
/** 
 * \brief  read SAR_ADC_CTRL cfg register
 *
 * \return configuration data
 */
saradc_ctrl_cfg_t saradc_ctrl_get_cfg(void);

/* ############################################################################ */
/** 
 * \brief  write SAR_ADC_CTRL cfg_timing register
 *
 * \param  cfg_sar_timing  timing configuration data
 */
void saradc_ctrl_set_cfg_sar_timing(saradc_ctrl_cfg_sar_timing_t cfg_sar_timing);

/* ############################################################################ */
/** 
 * \brief  read SAR_ADC_CTRL cfg_timing register
 *
 * \return timing configuration data
 */
saradc_ctrl_cfg_sar_timing_t saradc_ctrl_get_cfg_sar_timing(void);

/* ############################################################################ */
/** 
 * \brief  write SAR_ADC_CTRL wait_prescaler register used by WAIT, MIMM_SE commands
 *
 * \param  wait_prescaler  prescaler configuration data
 */
void saradc_ctrl_set_wait_prescaler(saradc_ctrl_wait_prescaler_t wait_prescaler);

/* ############################################################################ */
/** 
 * \brief  read SAR_ADC_CTRL wait_prescaler register
 *
 * \return prescaler configuration data
 */
saradc_ctrl_wait_prescaler_t saradc_ctrl_get_wait_prescaler(void);

/* ############################################################################ */
/** 
 * \brief  write SAR_ADC_CTRL sync_out_cfg register
 *
 * \param  sync_out_cfg  sync_out configuration data
 */
void saradc_ctrl_set_sync_out_cfg(saradc_ctrl_sync_out_cfg_t sync_out_cfg);

/* ############################################################################ */
/** 
 * \brief   read SAR_ADC_CTRL sync_out_cfg register
 *
 * \return  sync_out_cfg  sync_out configuration data
 */
saradc_ctrl_sync_out_cfg_t saradc_ctrl_get_sync_out_cfg(void);

/* ############################################################################ */
/** 
 * \brief  write SAR_ADC_CTRL sync_out_trig register
 *
 * \param  sync_out_cfg  sync_out trigger configuration data
 */
void saradc_ctrl_set_sync_out_trig(saradc_ctrl_sync_out_trig_t sync_out_trig);

/* ############################################################################ */
/** 
 * \brief   read SAR_ADC_CTRL sync_out_trig register
 *
 * \return  sync_out_cfg  sync_out trigger configuration data
 */
saradc_ctrl_sync_out_trig_t saradc_ctrl_get_sync_out_trig(void);

/* ############################################################################ */
/** 
 * \brief write SAR_ADC_CTRL cmd register
 *
 * \param   cmd  cmd data
 *
 * \return  void
 */
void saradc_ctrl_set_cmd(saradc_ctrl_cmd_t cmd);

/* ############################################################################ */
/** 
 * \brief  write SAR_ADC_CTRL wadr_min register (lowest permitted write address for DMA)
 * 
 * \param  wadr_min  value to write
 */
void saradc_ctrl_set_wadr_min(saradc_ctrl_wadr_min_t wadr_min);

/* ############################################################################ */
/** 
 * \brief read SAR_ADC_CTRL wadr_min register (lowest permitted write address for DMA)
 *
 * \return  content of wadr_min register
 */
saradc_ctrl_wadr_min_t saradc_ctrl_get_wadr_min(void);

/* ############################################################################ */
/** 
 * \brief  write SAR_ADC_CTRL wadr_max register (highest permitted write address for DMA)
 *
 * \param  wadr_max   value to write
 */
void saradc_ctrl_set_wadr_max(saradc_ctrl_wadr_max_t wadr_max);

/* ############################################################################ */
/** 
 * \brief read SAR_ADC_CTRL wadr_max register (highest permitted  write address for DMA)
 *
 * \return  content of wadr_max register
 */
saradc_ctrl_wadr_max_t saradc_ctrl_get_wadr_max(void);

/* ############################################################################ */
/** 
 * \brief  write new list start address to SAR_ADC_CTRL sadr_new register
 *
 * \param  sadr_new  new list start address
 *
 * \return void
 */
void saradc_ctrl_set_sadr_new(saradc_ctrl_sadr_new_t sadr_new);

/* ############################################################################ */
/**
 * \brief   read current list start address from SAR_ADC_CTRL sadr_current register
 *
 * \return  start address of the current list
 */
saradc_ctrl_sadr_current_t saradc_ctrl_get_sadr_current(void);

/* ############################################################################ */
/**
 * \brief   read value of the currently active list item
 *
 * \return  current target_adr value
 */
saradc_ctrl_l0_current_t saradc_ctrl_get_l0_current(void);

/* ############################################################################ */
/**
 * \brief   read value of the currently active list item
 *
 * \return  current trigger_type & ch_no & no_sum & no_sample  value
 */
saradc_ctrl_l1_current_t saradc_ctrl_get_l1_current(void);

/* ############################################################################ */
/**
 * \brief   read value of the currently active list item
 *
 * \return  current trigger value 
 */
saradc_ctrl_l2_current_t saradc_ctrl_get_l2_current(void);


/* ############################################################################ */ 
/** 
 * \brief read current TADR register value
 *
 * \return  content of TADR register
 */ 
saradc_ctrl_tadr_t       saradc_ctrl_get_tadr(void);

/* ############################################################################ */
/** 
 * \brief write direct mode register low word
 *
 * \param direct_mode_lw value to write
 */
void saradc_ctrl_set_direct_mode_lw(saradc_ctrl_direct_mode_lw_t direct_mode_lw);

/* ############################################################################ */
/** 
 * \brief read current direct_mode_lw register value
 *
 * \return  content of direct_mode_lw register
 */
saradc_ctrl_direct_mode_lw_t saradc_ctrl_get_direct_mode_lw(void);

/* ############################################################################ */
/**
 * \brief write direct mode register high word
 *
 * \param direct_mode_hw value to write
 */
void saradc_ctrl_set_direct_mode_hw(saradc_ctrl_direct_mode_hw_t direct_mode_hw);

/* ############################################################################ */
/** 
 * \brief read current direct_mode_hw register value
 *
 * \return  content of direct_mode_hw register
 */
saradc_ctrl_direct_mode_hw_t saradc_ctrl_get_direct_mode_hw(void);

/* ############################################################################ */
/** 
 * \brief read next DMA read address
 *
 * \return  content of adr_next register
 */
saradc_ctrl_adr_next_t saradc_ctrl_get_adr_next(void);

/* ############################################################################ */
/** 
 * \brief read start address done register
 *
 * \return  content of sadr_done register
 */
saradc_ctrl_sadr_done_t saradc_ctrl_get_sadr_done(void);

/* ############################################################################ */
/** 
 * \brief read current FSM state of SARADC_CTRL protocol machine
 *
 * \return  content of state register
 */
saradc_ctrl_state_t saradc_ctrl_get_state(void);

/* ############################################################################ */
/** 
 * \brief skip current list by writing to SRADC_CTRL cmd register
 */
void saradc_ctrl_skip_list();

/* ############################################################################ */
/** 
 * \brief skip current list command by writing to SRADC_CTRL cmd register
 */
void saradc_ctrl_skip_item();

/* ############################################################################ */
/** 
 * \brief setting of timing for SAR ADC control state machine 
 *
 * \param adc_clk_div  0: adc_clk equal to module clk <br>
 *                     1..MAX Period of adc clk is 2*adc_clk_div clk cycles. 
 */
void saradc_ctrl_set_adc_clk_div(uint8_t adc_clk_div);

/* ======================================================================= */
/* PROJECT SPECIFIC (link3d)                                               */
/* ======================================================================= */

/* ======================================================================= */
/* INTERRUPT HANDLING                                                      */
/* ======================================================================= */

/* ############################################################################ */
/** 
 * \brief write SARADC_CTRL irq_mask register
 *
 * \param irq_mask value to write
 */
void saradc_ctrl_set_irq_mask(saradc_ctrl_irq_mask_t irq_mask);

/* ############################################################################ */
/** 
 * \brief get SARADC_CTRL irq_mask register
 *
 * \return read irq_mask value 
 */
saradc_ctrl_irq_mask_t saradc_ctrl_get_irq_mask(void);

/* ############################################################################ */
/** 
 * \brief Enable all interrupts
 */
void saradc_ctrl_test_enable_all_irqs(void);

/* ############################################################################ */
/** 
 * \brief Enable/Disable specific interrupt
 *
 * \param irq specify interrupt which is controlled
 *
 * \param enable enable specific interrupt
 */
void saradc_ctrl_enable_irq(saradc_ctrl_irq_t irq, bool enable);

/* ############################################################################ */
/** 
 * \brief Read interrupt status
 *
 * \retrun current interrupt status
 */
saradc_ctrl_irq_status_t saradc_ctrl_get_irq_status(void);

/* ############################################################################ */
/** 
 * \brief Clear all interrups flags
 */
void saradc_ctrl_clear_all_irq_events(void);


/**@}*/ 
#endif /* HAVE_SARADC_CTRL_H */

