/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         pwmn_irq.h
*
* @brief        PWMN HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __PWMN_IRQ_H__
#define __PWMN_IRQ_H__

#define PWMN_NUM_IRQS 11


/* ############################################################################ */
/**
 * \brief List of PWMN Interrupt sources
 *
 * \ingroup pwmn 
 */ 
typedef enum{
  /**
   * Over current
   */ 
  PWMN_IRQ_OC =                         0,
  /**
   * Start of NTH_START pwm period and associated reload event occurred
   */ 
  PWMN_IRQ_START_EVT =                  1,
  /**
   * Middle of pwm period occurred
   */ 
  PWMN_IRQ_MIDDLE_EVT =                 2,
  /**
   * Dead time event 0 occurred (channel 0, pos)
   */ 
  PWMN_IRQ_DEAD_TIME_EVT_0 =            3,
  /**
   * Dead time event 1 occurred (channel 0, neg)
   */ 
  PWMN_IRQ_DEAD_TIME_EVT_1 =            4,
  /**
   * Dead time event 2 occurred (channel 1, pos)
   */ 
  PWMN_IRQ_DEAD_TIME_EVT_2 =            5,
  /**
   * Dead time event 3 occurred (channel 1, neg)
   */ 
  PWMN_IRQ_DEAD_TIME_EVT_3 =            6,
  /**
   * Dead time event 4 occurred (channel 2, pos)
   */ 
  PWMN_IRQ_DEAD_TIME_EVT_4 =            7,
  /**
   * Dead time event 5 occurred (channel 2, neg)
   */ 
  PWMN_IRQ_DEAD_TIME_EVT_5 =            8,
  /**
   * Dead time event 6 occurred (channel 3, pos)
   */ 
  PWMN_IRQ_DEAD_TIME_EVT_6 =            9,
  /**
   * Dead time event 7 occurred (channel 3, neg)
   */ 
  PWMN_IRQ_DEAD_TIME_EVT_7 =            10
} pwmn_irq_t;

#endif
