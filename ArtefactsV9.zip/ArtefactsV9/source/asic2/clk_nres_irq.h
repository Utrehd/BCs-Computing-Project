/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         clk_nres_irq.h
*
* @brief        Clock and Reset Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CLK_NRES_IRQ_H__
#define __CLK_NRES_IRQ_H__

#define CLK_NRES_NUM_IRQS 4

/**
  * \brief This is an enum class for Clock and Reset Control describing IRQ events
  *
  * \ingroup clk_nres
  */ 
typedef enum{
  CLK_NRES_IRQ_WDOG1_ASSERTED =         0, ///< 1: wdog1 was asserted
  CLK_NRES_IRQ_PERI0_OFF_ACC =          1, ///< 1: access to a disabled module on peri0 bus
  CLK_NRES_IRQ_PERI1_OFF_ACC =          2, ///< 1: access to a disabled module on peri1 bus
  CLK_NRES_IRQ_PERIE_OFF_ACC =          3 ///< 1: access to a disabled module on periE bus
} clk_nres_irq_t;

#endif
