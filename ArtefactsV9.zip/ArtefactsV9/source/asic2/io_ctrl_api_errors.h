/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         io_ctrl_api_errors.h
*
* @brief        Error handler for IO_CTRL API functions
*
* @author       Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

/**
 * \ingroup error_api
 */

#ifndef __IO_CTRL_API_ERRORS__
#define __IO_CTRL_API_ERRORS__

#define IO_CTRL_API_ERRORS_CODES                                              \
  /**                                                                          \
   * The selection pinout does not have the desired functionality              \
   */                                                                          \
  eError_io_ctrl_api_incorrect_group                                                                                       
    
#endif
 
