#include "diagnose_asic2.h"

failsave_status_t failsave_status = { .data = 0 }; ///> Initialize failsave structure
diagnose_status_t diagnose_status = { .data = 0 }; ///> Initialize diagnose structure

void swd_diagnose_failsave_on_asic2 ( diag_t tDiag, bool failsave )
{
  // If the failsave mode is enable, set the correspond bit in the structure
  if( failsave )
  {
    failsave_status.data |= ( 1 << (uint32_t)tDiag );
  }
}

void swd_diagnose_failsave_off_asic2 ( diag_t tDiag, bool failsave )
{
  // If the failsave mode is disable, clear the correspond bit in the structure
  if( !failsave )
  {
    failsave_status.data &= ~( 1 << (uint32_t)tDiag );
  }
}

bool swd_diagnose_failsave_is_on_asic2 ( diag_t tDiag, bool failsave )
{
  bool failsave_is_on = true;
  
  //It only says failsave_is_on is false if the failsave mode is required to be off (failsave == false)
  if( (failsave_status.data == 0) && !failsave)
  {
    failsave_is_on = false;
  }
  return failsave_is_on;
}

void swd_diagnose_on_asic2 ( diag_t tDiag, bool failsave )
{

  // Set the failsave structure (if it is needed)
  swd_diagnose_failsave_on_asic2 ( tDiag, failsave );
  
  // Set the diagnose structure
  diagnose_status.data |= ( 1 << (uint32_t)tDiag );
  
  // Activate the diagnose
  swd_diagnose_on( tDiag, failsave );
  
}

void swd_diagnose_off_asic2 ( diag_t tDiag, bool failsave )
{
  
  bool failsave_mode;
  
  // Set the failsave structure (if it is needed)
  swd_diagnose_failsave_off_asic2 ( tDiag, failsave );
  
  // Check if the failsave mode has to be on or off
  failsave_mode = swd_diagnose_failsave_is_on_asic2 ( tDiag, failsave );
  
  // Deactivate the diagnose
  swd_diagnose_off( tDiag, failsave_mode );  
}
