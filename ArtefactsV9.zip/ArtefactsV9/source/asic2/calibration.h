/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         calibration.h
*
* @brief        Calibration HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CALIBRATION_H__
#define __CALIBRATION_H__

/**
 * \defgroup api_calibration ASIC2 Calibration HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to calibrate system
 */
/**@{*/ 

#include "device.h"


/* ############################################################################ */
/**
 * \brief Read calibration from FLASH and set it in LV die
 *
 * \ingroup api_calibration
 *
 */
void calibrate_lv(void);

/* ############################################################################ */
/**
 * \brief Read calibration from FLASH and set it in HV die
 *
 * \ingroup api_calibration
 *
 */
void calibrate_hv(void);

/* ############################################################################ */
/**
 * \brief Read callibration from FLASH - get word of RCOSC_LF frequency in Hz
 *
 * \ingroup api_calibration
 *
 * \return word of RCOSC_LF frequency in Hz
 */
uint32_t calibration_get_rcosc_lf_freq(void);

/* ############################################################################ */
/**
 * \brief Read callibration from FLASH - AOUT (DAC) offset
 *
 * \ingroup api_calibration
 *
 * \return DAC offset factor
 */
uint16_t calibration_get_aout_offset(uint8_t i_aout);

/* ############################################################################ */
/**
 * \brief Read callibration from FLASH - AOUT (DAC) gain
 *
 * \ingroup api_calibration
 *
 * \return DAC gain factor
 */
uint16_t calibration_get_aout_gain(uint8_t i_aout);

/* ############################################################################ */
/**
 * \brief Read unique serial number
 *
 * \ingroup api_calibration
 *
 * \return word of unique serial number
 */
uint32_t calibration_get_serial(void);

/* ############################################################################ */
/**
 * \brief Read version (0xFFEF)
 *
 * \ingroup api_calibration
 *
 * \return version
 */
uint16_t calibration_get_version(void);

/**@} */
#endif /* __CALIBRATION_H__ */
