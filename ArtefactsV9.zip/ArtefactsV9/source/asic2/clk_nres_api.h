/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         clk_nres_api.h
*
* @brief        CLK_NRES API functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

/**
* \file 
*
* \brief  CLK_NRES API functions
*
* \author Eaton European Innovation Center 
*
* \version FPGA Release: 10512 / ASIC2 Specification (Revision 2.9.3)
*/

#ifndef __CLK_NRES_API__
#define __CLK_NRES_API__

/**
 * \defgroup clk_nres_api ASIC2 Clock and Reset Control API functions
 * 
 * \ingroup  clk_nres   asic2_api
 *
 * \brief    API function to control CLK_NRES
 *
 */
#include "clk_nres.h"
#include "errors_api.h"

#define CLOCK_FREQ_RCOSC_HF 16000000 ///< RCOSC HF frequency: 16 MHz
#define CLOCK_FREQ_RCOSC_LF 810000   ///< RCOSC LF frequency: 810 KHz


/* 
 * Instead of this definition, use definition in device_settings.h
 */
#ifdef CLOCK_FREQ_QOSC_2M
  #define CLOCK_FREQ_QOSC 2000000LU ///< External oscillator frequency: 2 MHz
#endif

#ifdef CLOCK_FREQ_QOSC_4M
  #define CLOCK_FREQ_QOSC 4000000LU ///< External oscillator frequency: 4 MHz
#endif

#ifdef CLOCK_FREQ_QOSC_10M
  #define CLOCK_FREQ_QOSC 10000000LU ///< External oscillator frequency: 10 MHz
#endif

#ifdef CLOCK_FREQ_QOSC_16M5
  #define CLOCK_FREQ_QOSC 16500000LU ///< External oscillator frequency: 10 MHz
#endif

#ifdef CLOCK_FREQ_QOSC_15M
  #define CLOCK_FREQ_QOSC 15000000LU ///< External oscillator frequency: 15 MHz
#endif

#ifdef CLOCK_FREQ_QOSC_24M
  #define CLOCK_FREQ_QOSC 24000000LU ///< External oscillator frequency: 15 MHz
#endif

#ifdef CLOCK_FREQ_QOSC_28M
  #define CLOCK_FREQ_QOSC 28000000LU ///< External oscillator frequency: 15 MHz
#endif

#ifdef CLOCK_FREQ_QOSC_30M
  #define CLOCK_FREQ_QOSC 30000000LU ///< External oscillator frequency: 30 MHz
#endif

#ifdef CLOCK_FREQ_QOSC_33M
  #define CLOCK_FREQ_QOSC 33000000LU ///< External oscillator frequency: 33 MHz
#endif

#ifndef CLOCK_FREQ_QOSC 
  #define CLOCK_FREQ_QOSC 0 ///< External oscillator - no definition
#endif

/* ############################################################################ */
/**
 * \brief  Set the clock partition for a specific module
 *
 * \ingroup clk_nres_api 
 *
 * \param clkpno Select the desired hardware module
 * \param enable true: enable clock partition <br> false: disable clock partition
 * \return Error code
 */
errors_api_code_e clk_nres_api_set_clock_partition(clkpno_t clkpno, bool enable);

/* ############################################################################ */
/**
 * \brief  Returns system clock value
 *
 * \ingroup clk_nres_api 
 *
 * \param domain as clock domain
 *
 * \param as_clock_freq Pointer to the as clock frequency value in Hertz
 *
 * \return Error code
 */
errors_api_code_e clk_nres_api_get_as_clock(clk_domain_t domain, uint32_t * as_clock_freq);

/* ############################################################################ */
/**
 * \brief  Returns system clock value
 *
 * \ingroup clk_nres_api 
 *
 * \param system_clock Pointer to the system clock frequency value in Hertz
 * \return Error code
 */
errors_api_code_e clk_nres_api_get_system_clock(uint32_t * system_clock);

/* ############################################################################ */
/**
 * \brief  Get the module rate
 *         This function returns the rate of the desired module
 *
 * \ingroup clk_nres_api 
 *
 * \param clkpno Select the module
 * \return Value of corresponding rate in enumeration (clk_rate_t) format
 */
clk_rate_t clk_nres_api_get_rate_sel(clkpno_t clkpno);

/* ############################################################################ */
/**
 * \brief  Get the module clock frequency
 *         This function returns a pointer to the module clock frequency value in Hertz of the desired module
 *
 * \ingroup clk_nres_api 
 *
 * \param clkpno Select the module
 * \param Pointer to the module clock frequency value in Hertz
 * \return Error code
 */
errors_api_code_e clk_nres_api_get_module_clock(clkpno_t module, uint32_t * module_clock);

/* ############################################################################ */
/**
 * \brief  Get the output frequency of PLL
 *         This function returns a pointer to the value of the PLL output frequency. The calculation is made according to the formula.
 *
 *         -> Formula:
 *                          NF + 1       1
 *            FOUT = FIN * -------- * ------- 
 *                          NF - 1     2^(OD)
 *
 * \ingroup clk_nres_api 
 *
 * \param Pointer to the PLL output frequency in Hertz
 * \return Error code
 */
errors_api_code_e clk_nres_api_get_pll_freq(uint32_t * pll_freq);

/* ############################################################################ */
/**
 * \brief Function used for resetting all blocks (except GUARD0/GUARD1/HV_CTRL)
 *
 * \ingroup clk_nres_api 
 */
void clk_nres_api_reset_all_blocks(void);


#endif
