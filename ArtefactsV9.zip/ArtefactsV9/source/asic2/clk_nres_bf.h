/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         clk_nres_bf.h
*
* @brief        Clock and Reset Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __CLK_NRES_BF_H__
#define __CLK_NRES_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_CLK_NRES_0
#define BASE_ADDR_CLK_NRES_0 0x40006000U
#endif
#ifndef BASE_ADDR_CLK_NRES_1
#define BASE_ADDR_CLK_NRES_1 0x40006D80U
#endif

#define MULTIPLE_CLK_NRES
#define NUMBER_CLK_NRES 2

/**
  * \brief This is an enum class for Clock and Reset Control instance
  *
  * \ingroup clk_nres
  */ 
typedef enum {
  CLK_NRES_0                     = (int)BASE_ADDR_CLK_NRES_0, ///< This is instance CLK_NRES_0
  CLK_NRES_1                     = (int)BASE_ADDR_CLK_NRES_1 ///< This is instance CLK_NRES_1
} clk_nres_num_t;

// Register bit field definitions

/* CLK_NRES_GUARD */

#define MSK_CLK_NRES_GUARD                                  (0xff)    /* [ 7:0] */

typedef unsigned short clk_nres_guard_t;                              /* [ 7:0] */


/* CLK_NRES_CFG_WRITE_ENABLED */

#define MSK_CLK_NRES_CFG_WRITE_ENABLED                      (0x1)     /* [0] */

typedef unsigned short clk_nres_cfg_write_enabled_t;                  /* [0] */


/* CLK_NRES_CFG_ANA_OSC */

#define MSK_CLK_NRES_CFG_ANA_OSC_RCOSC_HF_PD_N              (0x1)     /* [0] */
#define RES_CLK_NRES_CFG_ANA_OSC_RCOSC_HF_PD_N              (0x1)
#define SFT_CLK_NRES_CFG_ANA_OSC_RCOSC_HF_PD_N              (0)
#define LSB_CLK_NRES_CFG_ANA_OSC_RCOSC_HF_PD_N              (0)
#define MSB_CLK_NRES_CFG_ANA_OSC_RCOSC_HF_PD_N              (0)
#define BIT_CLK_NRES_CFG_ANA_OSC_RCOSC_HF_PD_N              (0x1)     /* [0] */
#define MSK_CLK_NRES_CFG_ANA_OSC_QOSC_PD_N                  (0x1)     /* [1] */
#define RES_CLK_NRES_CFG_ANA_OSC_QOSC_PD_N                  (0x0)
#define SFT_CLK_NRES_CFG_ANA_OSC_QOSC_PD_N                  (1)
#define LSB_CLK_NRES_CFG_ANA_OSC_QOSC_PD_N                  (1)
#define MSB_CLK_NRES_CFG_ANA_OSC_QOSC_PD_N                  (1)
#define BIT_CLK_NRES_CFG_ANA_OSC_QOSC_PD_N                  (0x2)     /* [1] */
#define MSK_CLK_NRES_CFG_ANA_OSC_QOSC_STRENGTH              (0x7)     /* [ 4:2] */
#define RES_CLK_NRES_CFG_ANA_OSC_QOSC_STRENGTH              (0x3)
#define SFT_CLK_NRES_CFG_ANA_OSC_QOSC_STRENGTH              (2)
#define LSB_CLK_NRES_CFG_ANA_OSC_QOSC_STRENGTH              (2)
#define MSB_CLK_NRES_CFG_ANA_OSC_QOSC_STRENGTH              (4)
#define MSK_CLK_NRES_CFG_ANA_OSC_QOSC_CLK_BYPASS            (0x1)     /* [5] */
#define RES_CLK_NRES_CFG_ANA_OSC_QOSC_CLK_BYPASS            (0x0)
#define SFT_CLK_NRES_CFG_ANA_OSC_QOSC_CLK_BYPASS            (5)
#define LSB_CLK_NRES_CFG_ANA_OSC_QOSC_CLK_BYPASS            (5)
#define MSB_CLK_NRES_CFG_ANA_OSC_QOSC_CLK_BYPASS            (5)
#define BIT_CLK_NRES_CFG_ANA_OSC_QOSC_CLK_BYPASS            (0x20)    /* [5] */

// rcosc_hf_pd_n
#define CLK_NRES_RCOSC_HF_DISABLE  0
#define CLK_NRES_RCOSC_HF_ENABLE   1

// qosc_pd_n
#define CLK_NRES_QOSC_DISABLE  0
#define CLK_NRES_QOSC_ENABLE   1


/** 
 * \brief This structure describes Clock and Reset Control analog oscilator configuration 
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short rcosc_hf_pd_n                 :    1; ///< <B>bit 0</B> <br> 1: turn on module <br> 0: turn off module
  unsigned short qosc_pd_n                     :    1; ///< <B>bit 1</B> <br> 1: turn on module <br> 0: turn off module
  unsigned short qosc_strength                 :    3; ///< <B>bits 4:2</B> <br> Driving strength of Quartz Oscillator
  unsigned short qosc_clk_bypass               :    1; ///< <B>bit 5</B> <br> 0: normal quartz operation <br> 1: QOSC pad allows single ended clock
  unsigned short reserved                      :   10; ///< <B>bits 15:6</B> <br> Reserved
} clk_nres_cfg_ana_osc_bf;

/**
 * \brief Conversion type between word and bit representation of Clock and Reset Control analog oscilator configuration
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_ana_osc_bf bf; ///< word representation
} clk_nres_cfg_ana_osc_t;     ///< bit field representation


/* CLK_NRES_CFG_ANA_PLL0 */

#define MSK_CLK_NRES_CFG_ANA_PLL0_PLL_FIN_SRC               (0x1)     /* [0] */
#define RES_CLK_NRES_CFG_ANA_PLL0_PLL_FIN_SRC               (0x0)
#define SFT_CLK_NRES_CFG_ANA_PLL0_PLL_FIN_SRC               (0)
#define LSB_CLK_NRES_CFG_ANA_PLL0_PLL_FIN_SRC               (0)
#define MSB_CLK_NRES_CFG_ANA_PLL0_PLL_FIN_SRC               (0)
#define BIT_CLK_NRES_CFG_ANA_PLL0_PLL_FIN_SRC               (0x1)     /* [0] */
#define MSK_CLK_NRES_CFG_ANA_PLL0_PLL_OE                    (0x1)     /* [1] */
#define RES_CLK_NRES_CFG_ANA_PLL0_PLL_OE                    (0x0)
#define SFT_CLK_NRES_CFG_ANA_PLL0_PLL_OE                    (1)
#define LSB_CLK_NRES_CFG_ANA_PLL0_PLL_OE                    (1)
#define MSB_CLK_NRES_CFG_ANA_PLL0_PLL_OE                    (1)
#define BIT_CLK_NRES_CFG_ANA_PLL0_PLL_OE                    (0x2)     /* [1] */
#define MSK_CLK_NRES_CFG_ANA_PLL0_PLL_PD_N                  (0x1)     /* [3] */
#define RES_CLK_NRES_CFG_ANA_PLL0_PLL_PD_N                  (0x0)
#define SFT_CLK_NRES_CFG_ANA_PLL0_PLL_PD_N                  (3)
#define LSB_CLK_NRES_CFG_ANA_PLL0_PLL_PD_N                  (3)
#define MSB_CLK_NRES_CFG_ANA_PLL0_PLL_PD_N                  (3)
#define BIT_CLK_NRES_CFG_ANA_PLL0_PLL_PD_N                  (0x8)     /* [3] */


// pll_fin_src
#define CLK_NRES_RCOSC_SOURCE_FOR_PLL  0
#define CLK_NRES_QOSC_SOURCE_FOR_PLL   1

// pll_oe
#define CLK_NRES_PLL_OUTPUT_DISABLE    0
#define CLK_NRES_PLL_OUTPUT_ENABLED    1

// pll_pd_n     
#define CLK_NRES_PLL_DISABLE           0
#define CLK_NRES_PLL_ENABLE            1


/** 
 * \brief This structure describes Clock and Reset Control analog PLL0 configuration 
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short pll_fin_src                   :    1; ///< <B>bit 0</B> <br> 0: rcosc_hf selected as clock input for pll <br> 1: qosc selected as clock input for pll
  unsigned short pll_oe                        :    1; ///< <B>bit 1</B> <br> 0: fout forced to zero <br> 1: FOUT enable pin
  unsigned short reserved2                     :    1; ///< <B>bit 2</B> <br> reserved
  unsigned short pll_pd_n                      :    1; ///< <B>bit 3</B> <br> 1: PLL enabled <br> 0: power down mode
  unsigned short reserved                      :   12; ///< <B>bits 15:4</B> <br> Reserved
} clk_nres_cfg_ana_pll0_bf;

/**
 * \brief Conversion type between word and bit representation of Clock and Reset Control analog PLL0 configuration
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_ana_pll0_bf bf; ///< word representation
} clk_nres_cfg_ana_pll0_t;     ///< bit field representation


/* CLK_NRES_CFG_ANA_PLL1 */

#define MSK_CLK_NRES_CFG_ANA_PLL1_PLL_OD                    (0x3)     /* [ 1:0] */
#define RES_CLK_NRES_CFG_ANA_PLL1_PLL_OD                    (0x0)
#define SFT_CLK_NRES_CFG_ANA_PLL1_PLL_OD                    (0)
#define LSB_CLK_NRES_CFG_ANA_PLL1_PLL_OD                    (0)
#define MSB_CLK_NRES_CFG_ANA_PLL1_PLL_OD                    (1)
#define MSK_CLK_NRES_CFG_ANA_PLL1_PLL_NR                    (0x7)     /* [ 4:2] */
#define RES_CLK_NRES_CFG_ANA_PLL1_PLL_NR                    (0x0)
#define SFT_CLK_NRES_CFG_ANA_PLL1_PLL_NR                    (2)
#define LSB_CLK_NRES_CFG_ANA_PLL1_PLL_NR                    (2)
#define MSB_CLK_NRES_CFG_ANA_PLL1_PLL_NR                    (4)
#define MSK_CLK_NRES_CFG_ANA_PLL1_PLL_NF                    (0x1f)    /* [ 9:5] */
#define RES_CLK_NRES_CFG_ANA_PLL1_PLL_NF                    (0x00)
#define SFT_CLK_NRES_CFG_ANA_PLL1_PLL_NF                    (5)
#define LSB_CLK_NRES_CFG_ANA_PLL1_PLL_NF                    (5)
#define MSB_CLK_NRES_CFG_ANA_PLL1_PLL_NF                    (9)

/** 
 * \brief This structure describes Clock and Reset Control analog PLL1 configuration 
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short pll_od                        :    2; ///< <B>bits 1:0</B> <br> Output divider
  unsigned short pll_nr                        :    3; ///< <B>bits 4:2</B> <br> Input divider
  unsigned short pll_nf                        :    5; ///< <B>bit 9:5</B> <br> Feed back bit divider
  unsigned short reserved                      :    6; ///< <B>bits 15:10</B> <br> Reserved
} clk_nres_cfg_ana_pll1_bf;

/**
 * \brief Conversion type between word and bit representation of Clock and Reset Control analog PLL1 configuration
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_ana_pll1_bf bf; ///< word representation
} clk_nres_cfg_ana_pll1_t;     ///< bit field representation


/* CLK_NRES_CFG */

#define MSK_CLK_NRES_CFG_CLK_SRC                            (0x3)     /* [ 1:0] */
#define RES_CLK_NRES_CFG_CLK_SRC                            (0x0)
#define SFT_CLK_NRES_CFG_CLK_SRC                            (0)
#define LSB_CLK_NRES_CFG_CLK_SRC                            (0)
#define MSB_CLK_NRES_CFG_CLK_SRC                            (1)
#define MSK_CLK_NRES_CFG_CLK_DIV                            (0xff)    /* [ 9:2] */
#define RES_CLK_NRES_CFG_CLK_DIV                            (0x02)
#define SFT_CLK_NRES_CFG_CLK_DIV                            (2)
#define LSB_CLK_NRES_CFG_CLK_DIV                            (2)
#define MSB_CLK_NRES_CFG_CLK_DIV                            (9)

/** 
 * \brief This structure describes Clock and Reset Control clock dividers
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short clk_src                       :    2; ///< <B>bits 1:0</B> <br> Selects clock source clk_src[clk_src]
/**
 * 0..MAX Selected clock is divided by clk_div <br>
 * <B>bits 9:2</B> <br> 
 * 0,1 : bypass / clock is not divided <br>
 * 2 : clock is divided by 2 <br>
 * 2 : clock is divided by 2 <br>
 * 3 : clock is divided by 3 (asymmetric duty cycle) <br>
 * ...
 */
  unsigned short clk_div                       :    8;
  unsigned short reserved                      :    6; ///< <B>bits 15:10</B> <br> Reserved 
} clk_nres_cfg_bf;

/**
 * \brief Conversion type between word and bit representation of Clock and Reset Control clock dividers
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val; ///< word representation
  clk_nres_cfg_bf bf; ///< bit field representation
} clk_nres_cfg_t;


/* CLK_NRES_CFG_RATE */

#define MSK_CLK_NRES_CFG_RATE_CFG_LOW_RATE_0                (0x1f)    /* [ 4:0] */
#define RES_CLK_NRES_CFG_RATE_CFG_LOW_RATE_0                (0x01)
#define SFT_CLK_NRES_CFG_RATE_CFG_LOW_RATE_0                (0)
#define LSB_CLK_NRES_CFG_RATE_CFG_LOW_RATE_0                (0)
#define MSB_CLK_NRES_CFG_RATE_CFG_LOW_RATE_0                (4)
#define MSK_CLK_NRES_CFG_RATE_CFG_LOW_RATE_1                (0x1f)    /* [ 9:5] */
#define RES_CLK_NRES_CFG_RATE_CFG_LOW_RATE_1                (0x01)
#define SFT_CLK_NRES_CFG_RATE_CFG_LOW_RATE_1                (5)
#define LSB_CLK_NRES_CFG_RATE_CFG_LOW_RATE_1                (5)
#define MSB_CLK_NRES_CFG_RATE_CFG_LOW_RATE_1                (9)
#define MSK_CLK_NRES_CFG_RATE_CFG_HIGH_RATE                 (0x1f)    /* [14:10] */
#define RES_CLK_NRES_CFG_RATE_CFG_HIGH_RATE                 (0x01)
#define SFT_CLK_NRES_CFG_RATE_CFG_HIGH_RATE                 (10)
#define LSB_CLK_NRES_CFG_RATE_CFG_HIGH_RATE                 (10)
#define MSB_CLK_NRES_CFG_RATE_CFG_HIGH_RATE                 (14)

/** 
 * \brief This structure describes Clock and Reset Control clock configuration rate
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short cfg_low_rate_0                :    5; ///< <B>bits 4:0</B> <br> 1..MAX <br> For the low rate every CFG_LOW_RATE clock pulse of the hr is let through
  unsigned short cfg_low_rate_1                :    5; ///< <B>bits 9:5</B> <br> 1..MAX <br> For the low rate every CFG_LOW_RATE clock pulse of the hr is let through
  unsigned short cfg_high_rate                 :    5; ///< <B>bits 14:10</B> <br> 1..MAX <br> For the high rate every CFG_HIGH_RATE clk pulse of the main system clock is let through
  unsigned short reserved                      :    1; ///< <B>bit 15</B> <br> Reserved
} clk_nres_cfg_rate_bf;

/**
 * \brief Conversion type between word and bit representation of Clock and Reset Control clock configuration rate
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_rate_bf bf; ///< word representation
} clk_nres_cfg_rate_t;     ///< bit field representation


/* CLK_NRES_CFG_RATE_SEL_0 */

#define MSK_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_TSU        (0x3)     /* [ 1:0] */
#define RES_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_TSU        (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_TSU        (0)
#define LSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_TSU        (0)
#define MSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_TSU        (1)
#define MSK_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GPIO       (0x3)     /* [ 3:2] */
#define RES_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GPIO       (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GPIO       (2)
#define LSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GPIO       (2)
#define MSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GPIO       (3)
#define MSK_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD0     (0x3)     /* [ 5:4] */
#define RES_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD0     (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD0     (4)
#define LSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD0     (4)
#define MSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD0     (5)
#define MSK_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD1     (0x3)     /* [ 7:6] */
#define RES_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD1     (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD1     (6)
#define LSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD1     (6)
#define MSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_GUARD1     (7)
#define MSK_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER0   (0x3)     /* [ 9:8] */
#define RES_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER0   (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER0   (8)
#define LSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER0   (8)
#define MSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER0   (9)
#define MSK_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER1   (0x3)     /* [11:10] */
#define RES_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER1   (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER1   (10)
#define LSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER1   (10)
#define MSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_SWTIMER1   (11)
#define MSK_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_PWMN       (0x3)     /* [13:12] */
#define RES_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_PWMN       (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_PWMN       (12)
#define LSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_PWMN       (12)
#define MSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_PWMN       (13)
#define MSK_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_VIC_EXT    (0x3)     /* [15:14] */
#define RES_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_VIC_EXT    (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_VIC_EXT    (14)
#define LSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_VIC_EXT    (14)
#define MSB_CLK_NRES_CFG_RATE_SEL_0_CFG_RATE_SEL_VIC_EXT    (15)

/** 
 * \brief This structure describes Clock and Reset Control clock configuration rate selector 0
 *
 * \ingroup clk_nres
 */
typedef struct {
/**
 * <B>bits 1:0</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[11 ] - CLKPNO_TSU
 */
  unsigned short cfg_rate_sel_tsu              :    2;
/**
 * <B>bits 3:2</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[12] - CLKPNO_GPIO <br>
 */
  unsigned short cfg_rate_sel_gpio             :    2;
/**
 * <B>bits 5:4</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[13] - CLKPNO_GUARD0
 */
  unsigned short cfg_rate_sel_guard0           :    2;
/**
 * <B>bits 7:6</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[14] - CLKPNO_GUARD1
 */
  unsigned short cfg_rate_sel_guard1           :    2;
/**
 * <B>bits 9:8</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[15] - CLKPNO_SWTIMER0
 */
  unsigned short cfg_rate_sel_swtimer0         :    2;
/**
 * <B>bits 11:10</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[16] - CLKPNO_SWTIMER1
 */
  unsigned short cfg_rate_sel_swtimer1         :    2;
/**
 * <B>bits 13:12</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[17] - CLKPNO_PWMN
 */
  unsigned short cfg_rate_sel_pwmn             :    2;
/**
 * <B>bits 15:14</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[18] - CLKPNO_VIC_EXT
 */
  unsigned short cfg_rate_sel_vic_ext          :    2;
} clk_nres_cfg_rate_sel_0_bf;

/**
 * \brief Conversion type between word and bit representation of Clock and Reset Control clock configuration rate selector 0
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_rate_sel_0_bf bf; ///< word representation
} clk_nres_cfg_rate_sel_0_t;     ///< bit field representation


/* CLK_NRES_CFG_RATE_SEL_1 */

#define MSK_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG0      (0x3)     /* [ 1:0] */
#define RES_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG0      (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG0      (0)
#define LSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG0      (0)
#define MSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG0      (1)
#define MSK_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG1      (0x3)     /* [ 3:2] */
#define RES_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG1      (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG1      (2)
#define LSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG1      (2)
#define MSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_WDOG1      (3)
#define MSK_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CPU_N_CPU  (0x3)     /* [ 5:4] */
#define RES_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CPU_N_CPU  (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CPU_N_CPU  (4)
#define LSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CPU_N_CPU  (4)
#define MSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CPU_N_CPU  (5)
#define MSK_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER0   (0x3)     /* [ 7:6] */
#define RES_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER0   (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER0   (6)
#define LSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER0   (6)
#define MSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER0   (7)
#define MSK_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER1   (0x3)     /* [ 9:8] */
#define RES_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER1   (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER1   (8)
#define LSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER1   (8)
#define MSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_CCTIMER1   (9)
#define MSK_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_IO_CTRL    (0x3)     /* [11:10] */
#define RES_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_IO_CTRL    (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_IO_CTRL    (10)
#define LSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_IO_CTRL    (10)
#define MSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_IO_CTRL    (11)
#define MSK_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ANALOG_CTRL (0x3)     /* [13:12] */
#define RES_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ANALOG_CTRL (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ANALOG_CTRL (12)
#define LSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ANALOG_CTRL (12)
#define MSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ANALOG_CTRL (13)
#define MSK_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ACCESS_CTRL (0x3)     /* [15:14] */
#define RES_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ACCESS_CTRL (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ACCESS_CTRL (14)
#define LSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ACCESS_CTRL (14)
#define MSB_CLK_NRES_CFG_RATE_SEL_1_CFG_RATE_SEL_ACCESS_CTRL (15)

/** 
 * \brief This structure describes Clock and Reset Control clock configuration rate selector 1
 *
 * \ingroup clk_nres
 */
typedef struct {
/**
 * <B>bits 1:0</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[19] - CLKPNO_WDOG0
 */
  unsigned short cfg_rate_sel_wdog0            :    2;
/**
 * <B>bits 3:2</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[20] - CLKPNO_WDOG1
 */
  unsigned short cfg_rate_sel_wdog1            :    2;
/**
 * <B>bits 5:4</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[21] - CLKPNO_CPU_N_CPU
 */
  unsigned short cfg_rate_sel_cpu_n_cpu        :    2;
/**
 * <B>bits 7:6</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[22] - CLKPNO_CCTIMER0
 */
  unsigned short cfg_rate_sel_cctimer0         :    2;
/**
 * <B>bits 9:8</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[23] - CLKPNO_CCTIMER1
 */
  unsigned short cfg_rate_sel_cctimer1         :    2;
/**
 * <B>bits 11:10</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[24] - CLKPNO_IO_CTRL 
 */
  unsigned short cfg_rate_sel_io_ctrl          :    2;
/**
 * <B>bits 13:12</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[25] - CLKPNO_ANALOG_CTRL
 */
  unsigned short cfg_rate_sel_analog_ctrl      :    2;
/**
 * <B>bits 15:14</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[26] - CLKPNO_ACCESS_CONTROL
 */
  unsigned short cfg_rate_sel_access_ctrl      :    2;
} clk_nres_cfg_rate_sel_1_bf;

/**
 * \brief Conversion type between word and bit representation of Clock and Reset Control clock configuration rate selector 1
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_rate_sel_1_bf bf; ///< word representation
} clk_nres_cfg_rate_sel_1_t;     ///< bit field representation


/* CLK_NRES_CFG_RATE_SEL_2 */

#define MSK_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_HV_CTRL    (0x3)     /* [ 1:0] */
#define RES_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_HV_CTRL    (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_HV_CTRL    (0)
#define LSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_HV_CTRL    (0)
#define MSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_HV_CTRL    (1)
#define MSK_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_UART       (0x3)     /* [ 3:2] */
#define RES_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_UART       (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_UART       (2)
#define LSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_UART       (2)
#define MSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_UART       (3)
#define MSK_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_AOUT_CTRL  (0x3)     /* [ 5:4] */
#define RES_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_AOUT_CTRL  (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_AOUT_CTRL  (4)
#define LSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_AOUT_CTRL  (4)
#define MSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_AOUT_CTRL  (5)
#define MSK_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_I2C        (0x3)     /* [ 7:6] */
#define RES_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_I2C        (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_I2C        (6)
#define LSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_I2C        (6)
#define MSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_I2C        (7)
#define MSK_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_EL_CTRL    (0x3)     /* [ 9:8] */
#define RES_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_EL_CTRL    (0x1)
#define SFT_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_EL_CTRL    (8)
#define LSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_EL_CTRL    (8)
#define MSB_CLK_NRES_CFG_RATE_SEL_2_CFG_RATE_SEL_EL_CTRL    (9)

/** 
 * \brief This structure describes Clock and Reset Control clock configuration rate selector 2
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short cfg_rate_sel_hv_ctrl          :    2;
/**
 * <B>bits 1:0</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[27] - CLKPNO_HV_CTRL
 */
  unsigned short cfg_rate_sel_uart             :    2;
/**
 * <B>bits 3:2</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[28] - CLKPNO_UART
 */
  unsigned short cfg_rate_sel_aout_ctrl        :    2;
/**
 * <B>bits 5:4</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[29] - CLKPNO_AOUT_CTRL
 */
  unsigned short cfg_rate_sel_i2c              :    2;
/**
 * <B>bits 7:6</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[30] - CLKPNO_I2C
 */
  unsigned short cfg_rate_sel_el_ctrl          :    2;
/**
 * <B>bits 9:8</B> <br>
 * “0”: full rate selected for clock partition clk[0] <br>
 * “1”: high rate " " <br>
 * “2”: low rate 0 " " <br>
 * “3”: low rate 1 " " <br>
 * for clock partiton clk[31] - CLKPNO_EL_CTRL
 */
  unsigned short reserved                      :    6; ///< <B>bits 15:10</B> <br> Reserved
} clk_nres_cfg_rate_sel_2_bf;

/**
 * \brief Conversion type between word and bit representation of Clock and Reset Control clock configuration rate selector 2
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_rate_sel_2_bf bf; ///< word representation
} clk_nres_cfg_rate_sel_2_t;     ///< bit field representation


/* CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS */

#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK0_SWD_TSU (0x1)     /* [0] */
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK0_SWD_TSU (0x0)
#define SFT_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK0_SWD_TSU (0)
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK0_SWD_TSU (0)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK0_SWD_TSU (0)
#define BIT_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK0_SWD_TSU (0x1)     /* [0] */
#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK1_USI0    (0x1)     /* [1] */
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK1_USI0    (0x0)
#define SFT_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK1_USI0    (1)
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK1_USI0    (1)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK1_USI0    (1)
#define BIT_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK1_USI0    (0x2)     /* [1] */
#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK2_USI1    (0x1)     /* [2] */
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK2_USI1    (0x0)
#define SFT_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK2_USI1    (2)
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK2_USI1    (2)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK2_USI1    (2)
#define BIT_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK2_USI1    (0x4)     /* [2] */
#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK3_HISPI   (0x1)     /* [3] */
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK3_HISPI   (0x0)
#define SFT_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK3_HISPI   (3)
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK3_HISPI   (3)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK3_HISPI   (3)
#define BIT_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS_AS_CLK3_HISPI   (0x8)     /* [3] */

/** 
 * \brief This structure describes the configuration of clock on/off control (WBUS0)
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short as_clk0_swd_tsu               :    1; ///< <B>bit 0</B> <br> Software control via bus interface wbus[0] access on registers CLK_SW_ON / OFF_AS for as_clk[0] disabled
  unsigned short as_clk1_usi0                  :    1; ///< <B>bit 1</B> <br> Software control via bus interface wbus[0] access on registers CLK_SW_ON / OFF_AS for as_clk[1] disabled
  unsigned short as_clk2_usi1                  :    1; ///< <B>bit 2</B> <br> Software control via bus interface wbus[0] access on registers CLK_SW_ON / OFF_AS for as_clk[2] disabled
  unsigned short as_clk3_hispi                 :    1; ///< <B>bit 3</B> <br> Software control via bus interface wbus[0] access on registers CLK_SW_ON / OFF_AS for as_clk[3] disabled
  unsigned short reserved                      :   12; ///< <B>bits 15:4</B> <br> reserved
} clk_nres_cfg_sw_onoff_en_wb0_as_bf;

/**
 * \brief Conversion type between word and bit representation of clock on/off control (WBUS0)
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_sw_onoff_en_wb0_as_bf bf; ///< word representation
} clk_nres_cfg_sw_onoff_en_wb0_as_t;     ///< bit field representation


/* CLK_NRES_CFG_SW_ONOFF_EN_WB0 */

#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB0                    (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_cfg_sw_onoff_en_wb0_t;                /* [15:0] */


/* CLK_NRES_CFG_CW */

#define MSK_CLK_NRES_CFG_CW_NRESET                          (0x1)     /* [0] */
#define RES_CLK_NRES_CFG_CW_NRESET                          (0x0)
#define SFT_CLK_NRES_CFG_CW_NRESET                          (0)
#define LSB_CLK_NRES_CFG_CW_NRESET                          (0)
#define MSB_CLK_NRES_CFG_CW_NRESET                          (0)
#define BIT_CLK_NRES_CFG_CW_NRESET                          (0x1)     /* [0] */
#define MSK_CLK_NRES_CFG_CW_SLOW_CLK_SRC                    (0x3)     /* [ 2:1] */
#define RES_CLK_NRES_CFG_CW_SLOW_CLK_SRC                    (0x0)
#define SFT_CLK_NRES_CFG_CW_SLOW_CLK_SRC                    (1)
#define LSB_CLK_NRES_CFG_CW_SLOW_CLK_SRC                    (1)
#define MSB_CLK_NRES_CFG_CW_SLOW_CLK_SRC                    (2)
#define MSK_CLK_NRES_CFG_CW_FAST_CLK_SRC                    (0x3)     /* [ 4:3] */
#define RES_CLK_NRES_CFG_CW_FAST_CLK_SRC                    (0x0)
#define SFT_CLK_NRES_CFG_CW_FAST_CLK_SRC                    (3)
#define LSB_CLK_NRES_CFG_CW_FAST_CLK_SRC                    (3)
#define MSB_CLK_NRES_CFG_CW_FAST_CLK_SRC                    (4)
#define MSK_CLK_NRES_CFG_CW_DIV_N                           (0xff)    /* [12:5] */
#define RES_CLK_NRES_CFG_CW_DIV_N                           (0x01)
#define SFT_CLK_NRES_CFG_CW_DIV_N                           (5)
#define LSB_CLK_NRES_CFG_CW_DIV_N                           (5)
#define MSB_CLK_NRES_CFG_CW_DIV_N                           (12)
#define MSK_CLK_NRES_CFG_CW_SLOW_RESET_EN                   (0x1)     /* [13] */
#define RES_CLK_NRES_CFG_CW_SLOW_RESET_EN                   (0x0)
#define SFT_CLK_NRES_CFG_CW_SLOW_RESET_EN                   (13)
#define LSB_CLK_NRES_CFG_CW_SLOW_RESET_EN                   (13)
#define MSB_CLK_NRES_CFG_CW_SLOW_RESET_EN                   (13)
#define BIT_CLK_NRES_CFG_CW_SLOW_RESET_EN                   (0x2000)  /* [13] */
#define MSK_CLK_NRES_CFG_CW_FAST_RESET_EN                   (0x1)     /* [14] */
#define RES_CLK_NRES_CFG_CW_FAST_RESET_EN                   (0x0)
#define SFT_CLK_NRES_CFG_CW_FAST_RESET_EN                   (14)
#define LSB_CLK_NRES_CFG_CW_FAST_RESET_EN                   (14)
#define MSB_CLK_NRES_CFG_CW_FAST_RESET_EN                   (14)
#define BIT_CLK_NRES_CFG_CW_FAST_RESET_EN                   (0x4000)  /* [14] */

/** 
 * \brief This structure describes the configuration of the clock watches
 *
 * \ingroup clk_nres
 */
typedef struct {
/**
 * <B>bit 0</B> <br>
 * 0: assert reset to clock watch module (this disables the module completely). The fields slow/fast_clk_src and n may only be changed when nreset=0.
 */
  unsigned short nreset                        :    1;
  unsigned short slow_clk_src                  :    2; ///< <B>bits 2:1</B> <br> 0..3 select clock source for slow clock 
  unsigned short fast_clk_src                  :    2; ///< <B>bits 4:3</B> <br> 0..3 select clock source for fast clock
  unsigned short div_n                         :    8; ///< <B>bits 12:5</B> <br> 1..MAX predivider of slow clock increase if both clocks have nearly the same frequency
  unsigned short slow_reset_en                 :    1; ///< <B>bit 13</B> <br> 0: the reset output of the slow clock watch is disabled
  unsigned short fast_reset_en                 :    1; ///< <B>bit 14</B> <br> 0: the reset output of the fast clock watch is disabled
  unsigned short reserved                      :    1; ///< <B>bit 15</B> <br> reserved
} clk_nres_cfg_cw_bf;

/**
 * \brief Conversion type between word and bit representation of the clock watches
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_cw_bf bf;
} clk_nres_cfg_cw_t;


/* CLK_NRES_CFG_CW_MIN */

#define MSK_CLK_NRES_CFG_CW_MIN                             (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_cfg_cw_min_t;                         /* [15:0] */


/* CLK_NRES_CFG_CW_MAX */

#define MSK_CLK_NRES_CFG_CW_MAX                             (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_cfg_cw_max_t;                         /* [15:0] */


/* CLK_NRES_CFG_WDOG1_NRES_EN_AS */

#define MSK_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES0_SWD_TSU  (0x1)     /* [0] */
#define RES_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES0_SWD_TSU  (0x0)
#define SFT_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES0_SWD_TSU  (0)
#define LSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES0_SWD_TSU  (0)
#define MSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES0_SWD_TSU  (0)
#define BIT_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES0_SWD_TSU  (0x1)     /* [0] */
#define MSK_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES1_USI0     (0x1)     /* [1] */
#define RES_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES1_USI0     (0x0)
#define SFT_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES1_USI0     (1)
#define LSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES1_USI0     (1)
#define MSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES1_USI0     (1)
#define BIT_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES1_USI0     (0x2)     /* [1] */
#define MSK_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES2_USI1     (0x1)     /* [2] */
#define RES_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES2_USI1     (0x0)
#define SFT_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES2_USI1     (2)
#define LSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES2_USI1     (2)
#define MSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES2_USI1     (2)
#define BIT_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES2_USI1     (0x4)     /* [2] */
#define MSK_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES3_HISPI    (0x1)     /* [3] */
#define RES_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES3_HISPI    (0x0)
#define SFT_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES3_HISPI    (3)
#define LSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES3_HISPI    (3)
#define MSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES3_HISPI    (3)
#define BIT_CLK_NRES_CFG_WDOG1_NRES_EN_AS_AS_NRES3_HISPI    (0x8)     /* [3] */

/** 
 * \brief This structure describes the configuration of the reset control by wdog1
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short as_nres0_swd_tsu              :    1; ///< <B>bit 0</B> <br> 1 : as_nres0 will be asserted when wdog1 expires
  unsigned short as_nres1_usi0                 :    1; ///< <B>bit 1</B> <br> 1 : as_nres1 will be asserted when wdog1 expires
  unsigned short as_nres2_usi1                 :    1; ///< <B>bit 2</B> <br> 1 : as_nres2 will be asserted when wdog1 expires
  unsigned short as_nres3_hispi                :    1; ///< <B>bit 3</B> <br> 1 : as_nres3 will be asserted when wdog1 expires
  unsigned short reserved                      :   12; ///< <B>bits 15:4</B> <br> reserved
} clk_nres_cfg_wdog1_nres_en_as_bf;

/**
 * \brief Conversion type between word and bit representation of the reset control by wdog1
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_wdog1_nres_en_as_bf bf; ///< word representation
} clk_nres_cfg_wdog1_nres_en_as_t;     ///< bit field representation


/* CLK_NRES_CFG_WDOG1_NRES_EN */

#define MSK_CLK_NRES_CFG_WDOG1_NRES_EN                      (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_cfg_wdog1_nres_en_t;                  /* [15:0] */


/* CLK_NRES_CFG_NRESET_AS */

#define MSK_CLK_NRES_CFG_NRESET_AS_AS_NRES0_SWD_TSU         (0x1)     /* [0] */
#define RES_CLK_NRES_CFG_NRESET_AS_AS_NRES0_SWD_TSU         (0x0)
#define SFT_CLK_NRES_CFG_NRESET_AS_AS_NRES0_SWD_TSU         (0)
#define LSB_CLK_NRES_CFG_NRESET_AS_AS_NRES0_SWD_TSU         (0)
#define MSB_CLK_NRES_CFG_NRESET_AS_AS_NRES0_SWD_TSU         (0)
#define BIT_CLK_NRES_CFG_NRESET_AS_AS_NRES0_SWD_TSU         (0x1)     /* [0] */
#define MSK_CLK_NRES_CFG_NRESET_AS_AS_NRES1_USI0            (0x1)     /* [1] */
#define RES_CLK_NRES_CFG_NRESET_AS_AS_NRES1_USI0            (0x0)
#define SFT_CLK_NRES_CFG_NRESET_AS_AS_NRES1_USI0            (1)
#define LSB_CLK_NRES_CFG_NRESET_AS_AS_NRES1_USI0            (1)
#define MSB_CLK_NRES_CFG_NRESET_AS_AS_NRES1_USI0            (1)
#define BIT_CLK_NRES_CFG_NRESET_AS_AS_NRES1_USI0            (0x2)     /* [1] */
#define MSK_CLK_NRES_CFG_NRESET_AS_AS_NRES2_USI1            (0x1)     /* [2] */
#define RES_CLK_NRES_CFG_NRESET_AS_AS_NRES2_USI1            (0x0)
#define SFT_CLK_NRES_CFG_NRESET_AS_AS_NRES2_USI1            (2)
#define LSB_CLK_NRES_CFG_NRESET_AS_AS_NRES2_USI1            (2)
#define MSB_CLK_NRES_CFG_NRESET_AS_AS_NRES2_USI1            (2)
#define BIT_CLK_NRES_CFG_NRESET_AS_AS_NRES2_USI1            (0x4)     /* [2] */
#define MSK_CLK_NRES_CFG_NRESET_AS_AS_NRES3_HISPI           (0x1)     /* [3] */
#define RES_CLK_NRES_CFG_NRESET_AS_AS_NRES3_HISPI           (0x0)
#define SFT_CLK_NRES_CFG_NRESET_AS_AS_NRES3_HISPI           (3)
#define LSB_CLK_NRES_CFG_NRESET_AS_AS_NRES3_HISPI           (3)
#define MSB_CLK_NRES_CFG_NRESET_AS_AS_NRES3_HISPI           (3)
#define BIT_CLK_NRES_CFG_NRESET_AS_AS_NRES3_HISPI           (0x8)     /* [3] */

/** 
 * \brief This structure describes the configuration of the reset control by software
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short as_nres0_swd_tsu              :    1; ///< <B>bit 0</B> <br> 0: reset asserted for as_nres0
  unsigned short as_nres1_usi0                 :    1; ///< <B>bit 1</B> <br> 0: reset asserted for as_nres1
  unsigned short as_nres2_usi1                 :    1; ///< <B>bit 2</B> <br> 0: reset asserted for as_nres2
  unsigned short as_nres3_hispi                :    1; ///< <B>bit 3</B> <br> 0: reset asserted for as_nres3
  unsigned short reserved                      :   12; ///< <B>bits 15:4</B> <br> reserved
} clk_nres_cfg_nreset_as_bf;

/**
 * \brief Conversion type between word and bit representation of the reset control by software
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_nreset_as_bf bf; ///< word representation
} clk_nres_cfg_nreset_as_t;     ///< bit field representation


/* CLK_NRES_CFG_NRESET_SW */

#define MSK_CLK_NRES_CFG_NRESET_SW                          (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_cfg_nreset_sw_t;                      /* [15:0] */


/* CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS */

#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK0_SWD_TSU (0x1)     /* [0] */
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK0_SWD_TSU (0x0)
#define SFT_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK0_SWD_TSU (0)
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK0_SWD_TSU (0)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK0_SWD_TSU (0)
#define BIT_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK0_SWD_TSU (0x1)     /* [0] */
#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK1_USI0    (0x1)     /* [1] */
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK1_USI0    (0x0)
#define SFT_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK1_USI0    (1)
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK1_USI0    (1)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK1_USI0    (1)
#define BIT_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK1_USI0    (0x2)     /* [1] */
#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK2_USI1    (0x1)     /* [2] */
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK2_USI1    (0x0)
#define SFT_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK2_USI1    (2)
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK2_USI1    (2)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK2_USI1    (2)
#define BIT_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK2_USI1    (0x4)     /* [2] */
#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK3_HISPI   (0x1)     /* [3] */
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK3_HISPI   (0x0)
#define SFT_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK3_HISPI   (3)
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK3_HISPI   (3)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK3_HISPI   (3)
#define BIT_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS_AS_CLK3_HISPI   (0x8)     /* [3] */

/** 
 * \brief This structure describes the configuration of clock on/off control (WBUS1)
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short as_clk0_swd_tsu               :    1; ///< <B>bit 0</B> <br> 0: software control via bus interface wbus[1] access on registers CLK_SW_ON / OFF_AS for as_clk[0] disabled
  unsigned short as_clk1_usi0                  :    1; ///< <B>bit 1</B> <br> 0: software control via bus interface wbus[1] access on registers CLK_SW_ON / OFF_AS for as_clk[1] disabled
  unsigned short as_clk2_usi1                  :    1; ///< <B>bit 2</B> <br> 0: software control via bus interface wbus[1] access on registers CLK_SW_ON / OFF_AS for as_clk[2] disabled
  unsigned short as_clk3_hispi                 :    1; ///< <B>bit 3</B> <br> 0: software control via bus interface wbus[1] access on registers CLK_SW_ON / OFF_AS for as_clk[3] disabled
  unsigned short reserved                      :   12; ///< <B>bits 15:4</B> <br> reserved
} clk_nres_cfg_sw_onoff_en_wb1_as_bf;

/**
 * \brief Conversion type between word and bit representation of clock on/off control (WBUS1)
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_sw_onoff_en_wb1_as_bf bf; ///< word representation
} clk_nres_cfg_sw_onoff_en_wb1_as_t;     ///< bit field representation


/* CLK_NRES_CFG_SW_ONOFF_EN_WB1 */

#define MSK_CLK_NRES_CFG_SW_ONOFF_EN_WB1                    (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_cfg_sw_onoff_en_wb1_t;                /* [15:0] */


/* CLK_NRES_CFG_RESET */

#define MSK_CLK_NRES_CFG_RESET_WDOG1_GLOBAL                 (0x1)     /* [0] */
#define RES_CLK_NRES_CFG_RESET_WDOG1_GLOBAL                 (0x0)
#define SFT_CLK_NRES_CFG_RESET_WDOG1_GLOBAL                 (0)
#define LSB_CLK_NRES_CFG_RESET_WDOG1_GLOBAL                 (0)
#define MSB_CLK_NRES_CFG_RESET_WDOG1_GLOBAL                 (0)
#define BIT_CLK_NRES_CFG_RESET_WDOG1_GLOBAL                 (0x1)     /* [0] */
#define MSK_CLK_NRES_CFG_RESET_PERI0_OFF_ACC                (0x1)     /* [1] */
#define RES_CLK_NRES_CFG_RESET_PERI0_OFF_ACC                (0x0)
#define SFT_CLK_NRES_CFG_RESET_PERI0_OFF_ACC                (1)
#define LSB_CLK_NRES_CFG_RESET_PERI0_OFF_ACC                (1)
#define MSB_CLK_NRES_CFG_RESET_PERI0_OFF_ACC                (1)
#define BIT_CLK_NRES_CFG_RESET_PERI0_OFF_ACC                (0x2)     /* [1] */
#define MSK_CLK_NRES_CFG_RESET_PERI1_OFF_ACC                (0x1)     /* [2] */
#define RES_CLK_NRES_CFG_RESET_PERI1_OFF_ACC                (0x0)
#define SFT_CLK_NRES_CFG_RESET_PERI1_OFF_ACC                (2)
#define LSB_CLK_NRES_CFG_RESET_PERI1_OFF_ACC                (2)
#define MSB_CLK_NRES_CFG_RESET_PERI1_OFF_ACC                (2)
#define BIT_CLK_NRES_CFG_RESET_PERI1_OFF_ACC                (0x4)     /* [2] */
#define MSK_CLK_NRES_CFG_RESET_PERIE_OFF_ACC                (0x1)     /* [3] */
#define RES_CLK_NRES_CFG_RESET_PERIE_OFF_ACC                (0x0)
#define SFT_CLK_NRES_CFG_RESET_PERIE_OFF_ACC                (3)
#define LSB_CLK_NRES_CFG_RESET_PERIE_OFF_ACC                (3)
#define MSB_CLK_NRES_CFG_RESET_PERIE_OFF_ACC                (3)
#define BIT_CLK_NRES_CFG_RESET_PERIE_OFF_ACC                (0x8)     /* [3] */
#define MSK_CLK_NRES_CFG_RESET_CCPU0_LOCKUP                 (0x1)     /* [4] */
#define RES_CLK_NRES_CFG_RESET_CCPU0_LOCKUP                 (0x0)
#define SFT_CLK_NRES_CFG_RESET_CCPU0_LOCKUP                 (4)
#define LSB_CLK_NRES_CFG_RESET_CCPU0_LOCKUP                 (4)
#define MSB_CLK_NRES_CFG_RESET_CCPU0_LOCKUP                 (4)
#define BIT_CLK_NRES_CFG_RESET_CCPU0_LOCKUP                 (0x10)    /* [4] */
#define MSK_CLK_NRES_CFG_RESET_ACPU1_LOCKUP                 (0x1)     /* [5] */
#define RES_CLK_NRES_CFG_RESET_ACPU1_LOCKUP                 (0x0)
#define SFT_CLK_NRES_CFG_RESET_ACPU1_LOCKUP                 (5)
#define LSB_CLK_NRES_CFG_RESET_ACPU1_LOCKUP                 (5)
#define MSB_CLK_NRES_CFG_RESET_ACPU1_LOCKUP                 (5)
#define BIT_CLK_NRES_CFG_RESET_ACPU1_LOCKUP                 (0x20)    /* [5] */

/** 
 * \brief This structure describes the configuration of the clock partitions
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short wdog1_global                  :    1; ///< <B>bit 0</B> <br> 1: WDOG1 resets the whole system, like WDOG0
  unsigned short peri0_off_acc                 :    1; ///< <B>bit 1</B> <br> 1: enabled reset when access to a disabled module on peri0 bus
  unsigned short peri1_off_acc                 :    1; ///< <B>bit 2</B> <br> 1: enabled reset when access to a disabled module on peri1 bus
  unsigned short perie_off_acc                 :    1; ///< <B>bit 3</B> <br> 1: enabled reset when access to a disabled module on periE bus
  unsigned short ccpu0_lockup                  :    1; ///< <B>bit 4</B> <br> 1: enable reset when CCPU0 lockup
  unsigned short acpu1_lockup                  :    1; ///< <B>bit 5</B> <br> 1: enable reset when ACPU1 lockup
  unsigned short reserved                      :   10; ///< <B>bit 15:6</B> <br>
} clk_nres_cfg_reset_bf;

/**
 * \brief Conversion type between word and bit representation of the clock partitions
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_cfg_reset_bf bf; ///< word representation
} clk_nres_cfg_reset_t;     ///< bit field representation


/* CLK_NRES_CLK_SW_OFF */

#define MSK_CLK_NRES_CLK_SW_OFF                             (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_clk_sw_off_t;                         /* [15:0] */


/* CLK_NRES_CLK_STATUS_AS */

#define MSK_CLK_NRES_CLK_STATUS_AS                          (0xf)     /* [ 3:0] */

typedef unsigned short clk_nres_clk_status_as_t;                      /* [ 3:0] */


/* CLK_NRES_CLK_STATUS */

#define MSK_CLK_NRES_CLK_STATUS                             (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_clk_status_t;                         /* [15:0] */


/* CLK_NRES_CW_MEASUREMENT */

#define MSK_CLK_NRES_CW_MEASUREMENT                         (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_cw_measurement_t;                     /* [15:0] */


/* CLK_NRES_CLK_SW_ON_AS */

#define MSK_CLK_NRES_CLK_SW_ON_AS_AS_CLK0_SWD_TSU_ON        (0x1)     /* [0] */
#define RES_CLK_NRES_CLK_SW_ON_AS_AS_CLK0_SWD_TSU_ON        (0x0)
#define SFT_CLK_NRES_CLK_SW_ON_AS_AS_CLK0_SWD_TSU_ON        (0)
#define LSB_CLK_NRES_CLK_SW_ON_AS_AS_CLK0_SWD_TSU_ON        (0)
#define MSB_CLK_NRES_CLK_SW_ON_AS_AS_CLK0_SWD_TSU_ON        (0)
#define BIT_CLK_NRES_CLK_SW_ON_AS_AS_CLK0_SWD_TSU_ON        (0x1)     /* [0] */
#define MSK_CLK_NRES_CLK_SW_ON_AS_AS_CLK1_USI0_ON           (0x1)     /* [1] */
#define RES_CLK_NRES_CLK_SW_ON_AS_AS_CLK1_USI0_ON           (0x0)
#define SFT_CLK_NRES_CLK_SW_ON_AS_AS_CLK1_USI0_ON           (1)
#define LSB_CLK_NRES_CLK_SW_ON_AS_AS_CLK1_USI0_ON           (1)
#define MSB_CLK_NRES_CLK_SW_ON_AS_AS_CLK1_USI0_ON           (1)
#define BIT_CLK_NRES_CLK_SW_ON_AS_AS_CLK1_USI0_ON           (0x2)     /* [1] */
#define MSK_CLK_NRES_CLK_SW_ON_AS_AS_CLK2_USI1_ON           (0x1)     /* [2] */
#define RES_CLK_NRES_CLK_SW_ON_AS_AS_CLK2_USI1_ON           (0x0)
#define SFT_CLK_NRES_CLK_SW_ON_AS_AS_CLK2_USI1_ON           (2)
#define LSB_CLK_NRES_CLK_SW_ON_AS_AS_CLK2_USI1_ON           (2)
#define MSB_CLK_NRES_CLK_SW_ON_AS_AS_CLK2_USI1_ON           (2)
#define BIT_CLK_NRES_CLK_SW_ON_AS_AS_CLK2_USI1_ON           (0x4)     /* [2] */
#define MSK_CLK_NRES_CLK_SW_ON_AS_AS_CLK3_HISPI_ON          (0x1)     /* [3] */
#define RES_CLK_NRES_CLK_SW_ON_AS_AS_CLK3_HISPI_ON          (0x0)
#define SFT_CLK_NRES_CLK_SW_ON_AS_AS_CLK3_HISPI_ON          (3)
#define LSB_CLK_NRES_CLK_SW_ON_AS_AS_CLK3_HISPI_ON          (3)
#define MSB_CLK_NRES_CLK_SW_ON_AS_AS_CLK3_HISPI_ON          (3)
#define BIT_CLK_NRES_CLK_SW_ON_AS_AS_CLK3_HISPI_ON          (0x8)     /* [3] */

/** 
 * \brief This structure describes the configuration of the dynamic settings (ON)
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short as_clk0_swd_tsu_on            :    1; ///< <B>bit 0</B> <br> writing a '1' will turn on clock partition as_clk0 if CFG_SW_ONOFF_EN_0.as_clk0 ='1'
  unsigned short as_clk1_usi0_on               :    1; ///< <B>bit 1</B> <br> writing a '1' will turn on clock partition as_clk1 if CFG_SW_ONOFF_EN_0.as_clk1 ='1'
  unsigned short as_clk2_usi1_on               :    1; ///< <B>bit 2</B> <br> writing a '1' will turn on clock partition as_clk2 if CFG_SW_ONOFF_EN_0.as_clk2 ='1'
  unsigned short as_clk3_hispi_on              :    1; ///< <B>bit 3</B> <br> writing a '1' will turn on clock partition as_clk3 if CFG_SW_ONOFF_EN_0.as_clk3 ='1'
  unsigned short reserved                      :   12; ///< <B>bits 15:4</B> <br> reserved
} clk_nres_clk_sw_on_as_bf;

/**
 * \brief Conversion type between word and bit representation of the dynamic settings (ON)
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_clk_sw_on_as_bf bf; ///< word representation
} clk_nres_clk_sw_on_as_t;     ///< bit field representation


/* CLK_NRES_CLK_SW_ON */

#define MSK_CLK_NRES_CLK_SW_ON                              (0xffff)  /* [15:0] */

typedef unsigned short clk_nres_clk_sw_on_t;                          /* [15:0] */


/* CLK_NRES_NRESET_SOURCES */

#define MSK_CLK_NRES_NRESET_SOURCES_POR                     (0x1)     /* [0] */
#define RES_CLK_NRES_NRESET_SOURCES_POR                     (0x1)
#define SFT_CLK_NRES_NRESET_SOURCES_POR                     (0)
#define LSB_CLK_NRES_NRESET_SOURCES_POR                     (0)
#define MSB_CLK_NRES_NRESET_SOURCES_POR                     (0)
#define BIT_CLK_NRES_NRESET_SOURCES_POR                     (0x1)     /* [0] */
#define MSK_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3A      (0x1)     /* [1] */
#define RES_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3A      (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3A      (1)
#define LSB_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3A      (1)
#define MSB_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3A      (1)
#define BIT_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3A      (0x2)     /* [1] */
#define MSK_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3       (0x1)     /* [2] */
#define RES_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3       (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3       (2)
#define LSB_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3       (2)
#define MSB_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3       (2)
#define BIT_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD3V3       (0x4)     /* [2] */
#define MSK_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8A      (0x1)     /* [3] */
#define RES_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8A      (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8A      (3)
#define LSB_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8A      (3)
#define MSB_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8A      (3)
#define BIT_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8A      (0x8)     /* [3] */
#define MSK_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8       (0x1)     /* [4] */
#define RES_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8       (0x1)
#define SFT_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8       (4)
#define LSB_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8       (4)
#define MSB_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8       (4)
#define BIT_CLK_NRES_NRESET_SOURCES_POWER_FAIL_VDD1V8       (0x10)    /* [4] */
#define MSK_CLK_NRES_NRESET_SOURCES_WDOG0                   (0x1)     /* [5] */
#define RES_CLK_NRES_NRESET_SOURCES_WDOG0                   (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_WDOG0                   (5)
#define LSB_CLK_NRES_NRESET_SOURCES_WDOG0                   (5)
#define MSB_CLK_NRES_NRESET_SOURCES_WDOG0                   (5)
#define BIT_CLK_NRES_NRESET_SOURCES_WDOG0                   (0x20)    /* [5] */
#define MSK_CLK_NRES_NRESET_SOURCES_WDOG1                   (0x1)     /* [6] */
#define RES_CLK_NRES_NRESET_SOURCES_WDOG1                   (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_WDOG1                   (6)
#define LSB_CLK_NRES_NRESET_SOURCES_WDOG1                   (6)
#define MSB_CLK_NRES_NRESET_SOURCES_WDOG1                   (6)
#define BIT_CLK_NRES_NRESET_SOURCES_WDOG1                   (0x40)    /* [6] */
#define MSK_CLK_NRES_NRESET_SOURCES_CW0                     (0x1)     /* [7] */
#define RES_CLK_NRES_NRESET_SOURCES_CW0                     (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_CW0                     (7)
#define LSB_CLK_NRES_NRESET_SOURCES_CW0                     (7)
#define MSB_CLK_NRES_NRESET_SOURCES_CW0                     (7)
#define BIT_CLK_NRES_NRESET_SOURCES_CW0                     (0x80)    /* [7] */
#define MSK_CLK_NRES_NRESET_SOURCES_CW1                     (0x1)     /* [8] */
#define RES_CLK_NRES_NRESET_SOURCES_CW1                     (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_CW1                     (8)
#define LSB_CLK_NRES_NRESET_SOURCES_CW1                     (8)
#define MSB_CLK_NRES_NRESET_SOURCES_CW1                     (8)
#define BIT_CLK_NRES_NRESET_SOURCES_CW1                     (0x100)   /* [8] */
#define MSK_CLK_NRES_NRESET_SOURCES_PERI0_OFF_ACC           (0x1)     /* [9] */
#define RES_CLK_NRES_NRESET_SOURCES_PERI0_OFF_ACC           (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_PERI0_OFF_ACC           (9)
#define LSB_CLK_NRES_NRESET_SOURCES_PERI0_OFF_ACC           (9)
#define MSB_CLK_NRES_NRESET_SOURCES_PERI0_OFF_ACC           (9)
#define BIT_CLK_NRES_NRESET_SOURCES_PERI0_OFF_ACC           (0x200)   /* [9] */
#define MSK_CLK_NRES_NRESET_SOURCES_PERI1_OFF_ACC           (0x1)     /* [10] */
#define RES_CLK_NRES_NRESET_SOURCES_PERI1_OFF_ACC           (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_PERI1_OFF_ACC           (10)
#define LSB_CLK_NRES_NRESET_SOURCES_PERI1_OFF_ACC           (10)
#define MSB_CLK_NRES_NRESET_SOURCES_PERI1_OFF_ACC           (10)
#define BIT_CLK_NRES_NRESET_SOURCES_PERI1_OFF_ACC           (0x400)   /* [10] */
#define MSK_CLK_NRES_NRESET_SOURCES_PERIE_OFF_ACC           (0x1)     /* [11] */
#define RES_CLK_NRES_NRESET_SOURCES_PERIE_OFF_ACC           (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_PERIE_OFF_ACC           (11)
#define LSB_CLK_NRES_NRESET_SOURCES_PERIE_OFF_ACC           (11)
#define MSB_CLK_NRES_NRESET_SOURCES_PERIE_OFF_ACC           (11)
#define BIT_CLK_NRES_NRESET_SOURCES_PERIE_OFF_ACC           (0x800)   /* [11] */
#define MSK_CLK_NRES_NRESET_SOURCES_NRES_PAD                (0x1)     /* [12] */
#define RES_CLK_NRES_NRESET_SOURCES_NRES_PAD                (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_NRES_PAD                (12)
#define LSB_CLK_NRES_NRESET_SOURCES_NRES_PAD                (12)
#define MSB_CLK_NRES_NRESET_SOURCES_NRES_PAD                (12)
#define BIT_CLK_NRES_NRESET_SOURCES_NRES_PAD                (0x1000)  /* [12] */
#define MSK_CLK_NRES_NRESET_SOURCES_CCPU0_LOCKUP            (0x1)     /* [13] */
#define RES_CLK_NRES_NRESET_SOURCES_CCPU0_LOCKUP            (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_CCPU0_LOCKUP            (13)
#define LSB_CLK_NRES_NRESET_SOURCES_CCPU0_LOCKUP            (13)
#define MSB_CLK_NRES_NRESET_SOURCES_CCPU0_LOCKUP            (13)
#define BIT_CLK_NRES_NRESET_SOURCES_CCPU0_LOCKUP            (0x2000)  /* [13] */
#define MSK_CLK_NRES_NRESET_SOURCES_ACPU1_LOCKUP            (0x1)     /* [14] */
#define RES_CLK_NRES_NRESET_SOURCES_ACPU1_LOCKUP            (0x0)
#define SFT_CLK_NRES_NRESET_SOURCES_ACPU1_LOCKUP            (14)
#define LSB_CLK_NRES_NRESET_SOURCES_ACPU1_LOCKUP            (14)
#define MSB_CLK_NRES_NRESET_SOURCES_ACPU1_LOCKUP            (14)
#define BIT_CLK_NRES_NRESET_SOURCES_ACPU1_LOCKUP            (0x4000)  /* [14] */

/** 
 * \brief This structure describes the configuration of status
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short por                           :    1; ///< <B>bit 0</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short power_fail_vdd3v3a            :    1; ///< <B>bit 1</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short power_fail_vdd3v3             :    1; ///< <B>bit 2</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short power_fail_vdd1v8a            :    1; ///< <B>bit 3</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short power_fail_vdd1v8             :    1; ///< <B>bit 4</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short wdog0                         :    1; ///< <B>bit 5</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short wdog1                         :    1; ///< <B>bit 6</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short cw0                           :    1; ///< <B>bit 7</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short cw1                           :    1; ///< <B>bit 8</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short peri0_off_acc                 :    1; ///< <B>bit 9</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short peri1_off_acc                 :    1; ///< <B>bit 10</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short perie_off_acc                 :    1; ///< <B>bit 11</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short nres_pad                      :    1; ///< <B>bit 12</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short ccpu0_lockup                  :    1; ///< <B>bit 13</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short acpu1_lockup                  :    1; ///< <B>bit 14</B> <br> 1: corresponding source has caused a reset. Writing '1' will clear the respective bit.
  unsigned short reserved                      :    1; ///< <B>bit 15</B> <br> reserved
} clk_nres_nreset_sources_bf;

/**
 * \brief Conversion type between word and bit representation of status
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_nreset_sources_bf bf; ///< word representation
} clk_nres_nreset_sources_t;     ///< bit field representation


/* CLK_NRES_CMD_CPU1_WAKE */

#define MSK_CLK_NRES_CMD_CPU1_WAKE                          (0x1)     /* [0] */

typedef unsigned short clk_nres_cmd_cpu1_wake_t;                      /* [0] */


/* CLK_NRES_IRQ_STATUS */

#define MSK_CLK_NRES_IRQ_STATUS_WDOG1_ASSERTED              (0x1)     /* [0] */
#define RES_CLK_NRES_IRQ_STATUS_WDOG1_ASSERTED              (0x0)
#define SFT_CLK_NRES_IRQ_STATUS_WDOG1_ASSERTED              (0)
#define LSB_CLK_NRES_IRQ_STATUS_WDOG1_ASSERTED              (0)
#define MSB_CLK_NRES_IRQ_STATUS_WDOG1_ASSERTED              (0)
#define BIT_CLK_NRES_IRQ_STATUS_WDOG1_ASSERTED              (0x1)     /* [0] */
#define MSK_CLK_NRES_IRQ_STATUS_PERI0_OFF_ACC               (0x1)     /* [1] */
#define RES_CLK_NRES_IRQ_STATUS_PERI0_OFF_ACC               (0x0)
#define SFT_CLK_NRES_IRQ_STATUS_PERI0_OFF_ACC               (1)
#define LSB_CLK_NRES_IRQ_STATUS_PERI0_OFF_ACC               (1)
#define MSB_CLK_NRES_IRQ_STATUS_PERI0_OFF_ACC               (1)
#define BIT_CLK_NRES_IRQ_STATUS_PERI0_OFF_ACC               (0x2)     /* [1] */
#define MSK_CLK_NRES_IRQ_STATUS_PERI1_OFF_ACC               (0x1)     /* [2] */
#define RES_CLK_NRES_IRQ_STATUS_PERI1_OFF_ACC               (0x0)
#define SFT_CLK_NRES_IRQ_STATUS_PERI1_OFF_ACC               (2)
#define LSB_CLK_NRES_IRQ_STATUS_PERI1_OFF_ACC               (2)
#define MSB_CLK_NRES_IRQ_STATUS_PERI1_OFF_ACC               (2)
#define BIT_CLK_NRES_IRQ_STATUS_PERI1_OFF_ACC               (0x4)     /* [2] */
#define MSK_CLK_NRES_IRQ_STATUS_PERIE_OFF_ACC               (0x1)     /* [3] */
#define RES_CLK_NRES_IRQ_STATUS_PERIE_OFF_ACC               (0x0)
#define SFT_CLK_NRES_IRQ_STATUS_PERIE_OFF_ACC               (3)
#define LSB_CLK_NRES_IRQ_STATUS_PERIE_OFF_ACC               (3)
#define MSB_CLK_NRES_IRQ_STATUS_PERIE_OFF_ACC               (3)
#define BIT_CLK_NRES_IRQ_STATUS_PERIE_OFF_ACC               (0x8)     /* [3] */

/** 
 * \brief This structure describes the configuration of IRQ
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short wdog1_asserted                :    1; ///< <B>bit 0</B> <br> 1: wdog1 was asserted
  unsigned short peri0_off_acc                 :    1; ///< <B>bit 1</B> <br> 1: access to a disabled module on peri0 bus
  unsigned short peri1_off_acc                 :    1; ///< <B>bit 2</B> <br> 1: access to a disabled module on peri1 bus
  unsigned short perie_off_acc                 :    1; ///< <B>bit 3</B> <br> 1: access to a disabled module on periE bus
  unsigned short reserved                      :   12; ///< <B>bits 15:4</B> <br>
} clk_nres_irq_status_bf;

/**
 * \brief Conversion type between word and bit representation of IRQ
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_irq_status_bf bf; ///< word representation
} clk_nres_irq_status_t;     ///< bit field representation


/* CLK_NRES_IRQ_MASK */

#define MSK_CLK_NRES_IRQ_MASK                               (0xf)     /* [ 3:0] */

typedef unsigned short clk_nres_irq_mask_t;                           /* [ 3:0] */


/* CLK_NRES_IRQ_VENABLE */

#define MSK_CLK_NRES_IRQ_VENABLE                            (0x3)     /* [ 1:0] */

typedef unsigned short clk_nres_irq_venable_t;                        /* [ 1:0] */


/* CLK_NRES_IRQ_VDISABLE */

#define MSK_CLK_NRES_IRQ_VDISABLE                           (0x3)     /* [ 1:0] */

typedef unsigned short clk_nres_irq_vdisable_t;                       /* [ 1:0] */


/* CLK_NRES_IRQ_VMAX */

#define MSK_CLK_NRES_IRQ_VMAX                               (0x7)     /* [ 2:0] */

typedef unsigned short clk_nres_irq_vmax_t;                           /* [ 2:0] */


/* CLK_NRES_IRQ_VNO */

#define MSK_CLK_NRES_IRQ_VNO                                (0x7)     /* [ 2:0] */

typedef unsigned short clk_nres_irq_vno_t;                            /* [ 2:0] */


/* CLK_NRES_CLK_SW_OFF_AS */

#define MSK_CLK_NRES_CLK_SW_OFF_AS_AS_CLK0_SWD_TSU_OFF      (0x1)     /* [0] */
#define RES_CLK_NRES_CLK_SW_OFF_AS_AS_CLK0_SWD_TSU_OFF      (0x0)
#define SFT_CLK_NRES_CLK_SW_OFF_AS_AS_CLK0_SWD_TSU_OFF      (0)
#define LSB_CLK_NRES_CLK_SW_OFF_AS_AS_CLK0_SWD_TSU_OFF      (0)
#define MSB_CLK_NRES_CLK_SW_OFF_AS_AS_CLK0_SWD_TSU_OFF      (0)
#define BIT_CLK_NRES_CLK_SW_OFF_AS_AS_CLK0_SWD_TSU_OFF      (0x1)     /* [0] */
#define MSK_CLK_NRES_CLK_SW_OFF_AS_AS_CLK1_USI0_OFF         (0x1)     /* [1] */
#define RES_CLK_NRES_CLK_SW_OFF_AS_AS_CLK1_USI0_OFF         (0x0)
#define SFT_CLK_NRES_CLK_SW_OFF_AS_AS_CLK1_USI0_OFF         (1)
#define LSB_CLK_NRES_CLK_SW_OFF_AS_AS_CLK1_USI0_OFF         (1)
#define MSB_CLK_NRES_CLK_SW_OFF_AS_AS_CLK1_USI0_OFF         (1)
#define BIT_CLK_NRES_CLK_SW_OFF_AS_AS_CLK1_USI0_OFF         (0x2)     /* [1] */
#define MSK_CLK_NRES_CLK_SW_OFF_AS_AS_CLK2_USI1_OFF         (0x1)     /* [2] */
#define RES_CLK_NRES_CLK_SW_OFF_AS_AS_CLK2_USI1_OFF         (0x0)
#define SFT_CLK_NRES_CLK_SW_OFF_AS_AS_CLK2_USI1_OFF         (2)
#define LSB_CLK_NRES_CLK_SW_OFF_AS_AS_CLK2_USI1_OFF         (2)
#define MSB_CLK_NRES_CLK_SW_OFF_AS_AS_CLK2_USI1_OFF         (2)
#define BIT_CLK_NRES_CLK_SW_OFF_AS_AS_CLK2_USI1_OFF         (0x4)     /* [2] */
#define MSK_CLK_NRES_CLK_SW_OFF_AS_AS_CLK3_HISPI_OFF        (0x1)     /* [3] */
#define RES_CLK_NRES_CLK_SW_OFF_AS_AS_CLK3_HISPI_OFF        (0x0)
#define SFT_CLK_NRES_CLK_SW_OFF_AS_AS_CLK3_HISPI_OFF        (3)
#define LSB_CLK_NRES_CLK_SW_OFF_AS_AS_CLK3_HISPI_OFF        (3)
#define MSB_CLK_NRES_CLK_SW_OFF_AS_AS_CLK3_HISPI_OFF        (3)
#define BIT_CLK_NRES_CLK_SW_OFF_AS_AS_CLK3_HISPI_OFF        (0x8)     /* [3] */

/** 
 * \brief This structure describes the configuration of the dynamic settings (OFF)
 *
 * \ingroup clk_nres
 */
typedef struct {
  unsigned short as_clk0_swd_tsu_off           :    1; ///< <B>bit 0</B> <br> writing a '1' will turn off clock partition as_clk0 if CFG_SW_ONOFF_EN_0.as_clk0 ='1'
  unsigned short as_clk1_usi0_off              :    1; ///< <B>bit 1</B> <br> writing a '1' will turn off clock partition as_clk1 if CFG_SW_ONOFF_EN_0.as_clk1 ='1'
  unsigned short as_clk2_usi1_off              :    1; ///< <B>bit 2</B> <br> writing a '1' will turn off clock partition as_clk2 if CFG_SW_ONOFF_EN_0.as_clk2 ='1'
  unsigned short as_clk3_hispi_off             :    1; ///< <B>bit 3</B> <br> writing a '1' will turn off clock partition as_clk3 if CFG_SW_ONOFF_EN_0.as_clk3 ='1'
  unsigned short reserved                      :   12; ///< <B>bits 15:4</B> <br> reserved
} clk_nres_clk_sw_off_as_bf;

/**
 * \brief Conversion type between word and bit representation of the dynamic settings (OFF)
 *
 * \ingroup clk_nres
 */
typedef union {
  unsigned short val;
  clk_nres_clk_sw_off_as_bf bf; ///< word representation
} clk_nres_clk_sw_off_as_t;     ///< bit field representation



// Register definitions for module
// Instance base address BASE_ADDR_CLK_NRES_0 0x40006000U ... 
// Instance base address BASE_ADDR_CLK_NRES_1 0x40006D80U ... 

#define ADDR_CLK_NRES_GUARD                                  (0x00U)
#define A_CLK_NRES_GUARD(ba)                                 ((ba) + ADDR_CLK_NRES_GUARD)
#define R_CLK_NRES_GUARD(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_GUARD(ba)))
#define RES_CLK_NRES_GUARD                                   (0x0U)
#define MSB_CLK_NRES_GUARD                                   7
#define LSB_CLK_NRES_GUARD                                   0
#define AADDR_CLK_NRES_0_GUARD                               (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_GUARD)
#define AADDR_CLK_NRES_1_GUARD                               (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_GUARD)
#define REG_CLK_NRES_0_GUARD                                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_GUARD))
#define REG_CLK_NRES_1_GUARD                                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_GUARD))

#define ADDR_CLK_NRES_CFG_WRITE_ENABLED                      (0x02U)
#define A_CLK_NRES_CFG_WRITE_ENABLED(ba)                     ((ba) + ADDR_CLK_NRES_CFG_WRITE_ENABLED)
#define R_CLK_NRES_CFG_WRITE_ENABLED(ba)                     (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_WRITE_ENABLED(ba)))
#define RES_CLK_NRES_CFG_WRITE_ENABLED                       (0x0U)
#define MSB_CLK_NRES_CFG_WRITE_ENABLED                       0
#define LSB_CLK_NRES_CFG_WRITE_ENABLED                       0
#define AADDR_CLK_NRES_0_CFG_WRITE_ENABLED                   (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_WRITE_ENABLED)
#define AADDR_CLK_NRES_1_CFG_WRITE_ENABLED                   (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_WRITE_ENABLED)
#define REG_CLK_NRES_0_CFG_WRITE_ENABLED                     (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_WRITE_ENABLED))
#define REG_CLK_NRES_1_CFG_WRITE_ENABLED                     (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_WRITE_ENABLED))

#define ADDR_CLK_NRES_CFG_ANA_OSC                            (0x04U)
#define A_CLK_NRES_CFG_ANA_OSC(ba)                           ((ba) + ADDR_CLK_NRES_CFG_ANA_OSC)
#define R_CLK_NRES_CFG_ANA_OSC(ba)                           (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_ANA_OSC(ba)))
#define RES_CLK_NRES_CFG_ANA_OSC                             (0xdU)
#define MSB_CLK_NRES_CFG_ANA_OSC                             5
#define LSB_CLK_NRES_CFG_ANA_OSC                             0
#define AADDR_CLK_NRES_0_CFG_ANA_OSC                         (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_OSC)
#define AADDR_CLK_NRES_1_CFG_ANA_OSC                         (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_ANA_OSC)
#define REG_CLK_NRES_0_CFG_ANA_OSC                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_ANA_OSC))
#define REG_CLK_NRES_1_CFG_ANA_OSC                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_ANA_OSC))

#define ADDR_CLK_NRES_CFG_ANA_PLL0                           (0x06U)
#define A_CLK_NRES_CFG_ANA_PLL0(ba)                          ((ba) + ADDR_CLK_NRES_CFG_ANA_PLL0)
#define R_CLK_NRES_CFG_ANA_PLL0(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_ANA_PLL0(ba)))
#define RES_CLK_NRES_CFG_ANA_PLL0                            (0x0U)
#define MSB_CLK_NRES_CFG_ANA_PLL0                            3
#define LSB_CLK_NRES_CFG_ANA_PLL0                            0
#define AADDR_CLK_NRES_0_CFG_ANA_PLL0                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL0)
#define AADDR_CLK_NRES_1_CFG_ANA_PLL0                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_ANA_PLL0)
#define REG_CLK_NRES_0_CFG_ANA_PLL0                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_ANA_PLL0))
#define REG_CLK_NRES_1_CFG_ANA_PLL0                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_ANA_PLL0))

#define ADDR_CLK_NRES_CFG_ANA_PLL1                           (0x08U)
#define A_CLK_NRES_CFG_ANA_PLL1(ba)                          ((ba) + ADDR_CLK_NRES_CFG_ANA_PLL1)
#define R_CLK_NRES_CFG_ANA_PLL1(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_ANA_PLL1(ba)))
#define RES_CLK_NRES_CFG_ANA_PLL1                            (0x0U)
#define MSB_CLK_NRES_CFG_ANA_PLL1                            9
#define LSB_CLK_NRES_CFG_ANA_PLL1                            0
#define AADDR_CLK_NRES_0_CFG_ANA_PLL1                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_ANA_PLL1)
#define AADDR_CLK_NRES_1_CFG_ANA_PLL1                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_ANA_PLL1)
#define REG_CLK_NRES_0_CFG_ANA_PLL1                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_ANA_PLL1))
#define REG_CLK_NRES_1_CFG_ANA_PLL1                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_ANA_PLL1))

#define ADDR_CLK_NRES_CFG_AS0_SWD_TSU                        (0x0AU)
#define A_CLK_NRES_CFG_AS0_SWD_TSU(ba)                       ((ba) + ADDR_CLK_NRES_CFG_AS0_SWD_TSU)
#define R_CLK_NRES_CFG_AS0_SWD_TSU(ba)                       (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_AS0_SWD_TSU(ba)))
#define RES_CLK_NRES_CFG_AS0_SWD_TSU                         (0x8U)
#define MSB_CLK_NRES_CFG_AS0_SWD_TSU                         9
#define LSB_CLK_NRES_CFG_AS0_SWD_TSU                         0
#define AADDR_CLK_NRES_0_CFG_AS0_SWD_TSU                     (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS0_SWD_TSU)
#define AADDR_CLK_NRES_1_CFG_AS0_SWD_TSU                     (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_AS0_SWD_TSU)
#define REG_CLK_NRES_0_CFG_AS0_SWD_TSU                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_AS0_SWD_TSU))
#define REG_CLK_NRES_1_CFG_AS0_SWD_TSU                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_AS0_SWD_TSU))

#define ADDR_CLK_NRES_CFG_AS1_USI0                           (0x0CU)
#define A_CLK_NRES_CFG_AS1_USI0(ba)                          ((ba) + ADDR_CLK_NRES_CFG_AS1_USI0)
#define R_CLK_NRES_CFG_AS1_USI0(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_AS1_USI0(ba)))
#define RES_CLK_NRES_CFG_AS1_USI0                            (0x8U)
#define MSB_CLK_NRES_CFG_AS1_USI0                            9
#define LSB_CLK_NRES_CFG_AS1_USI0                            0
#define AADDR_CLK_NRES_0_CFG_AS1_USI0                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS1_USI0)
#define AADDR_CLK_NRES_1_CFG_AS1_USI0                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_AS1_USI0)
#define REG_CLK_NRES_0_CFG_AS1_USI0                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_AS1_USI0))
#define REG_CLK_NRES_1_CFG_AS1_USI0                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_AS1_USI0))

#define ADDR_CLK_NRES_CFG_AS2_USI1                           (0x0EU)
#define A_CLK_NRES_CFG_AS2_USI1(ba)                          ((ba) + ADDR_CLK_NRES_CFG_AS2_USI1)
#define R_CLK_NRES_CFG_AS2_USI1(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_AS2_USI1(ba)))
#define RES_CLK_NRES_CFG_AS2_USI1                            (0x8U)
#define MSB_CLK_NRES_CFG_AS2_USI1                            9
#define LSB_CLK_NRES_CFG_AS2_USI1                            0
#define AADDR_CLK_NRES_0_CFG_AS2_USI1                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS2_USI1)
#define AADDR_CLK_NRES_1_CFG_AS2_USI1                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_AS2_USI1)
#define REG_CLK_NRES_0_CFG_AS2_USI1                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_AS2_USI1))
#define REG_CLK_NRES_1_CFG_AS2_USI1                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_AS2_USI1))

#define ADDR_CLK_NRES_CFG_M                                  (0x10U)
#define A_CLK_NRES_CFG_M(ba)                                 ((ba) + ADDR_CLK_NRES_CFG_M)
#define R_CLK_NRES_CFG_M(ba)                                 (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_M(ba)))
#define RES_CLK_NRES_CFG_M                                   (0x8U)
#define MSB_CLK_NRES_CFG_M                                   9
#define LSB_CLK_NRES_CFG_M                                   0
#define AADDR_CLK_NRES_0_CFG_M                               (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_M)
#define AADDR_CLK_NRES_1_CFG_M                               (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_M)
#define REG_CLK_NRES_0_CFG_M                                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_M))
#define REG_CLK_NRES_1_CFG_M                                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_M))

#define ADDR_CLK_NRES_CFG_RATE                               (0x12U)
#define A_CLK_NRES_CFG_RATE(ba)                              ((ba) + ADDR_CLK_NRES_CFG_RATE)
#define R_CLK_NRES_CFG_RATE(ba)                              (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_RATE(ba)))
#define RES_CLK_NRES_CFG_RATE                                (0x421U)
#define MSB_CLK_NRES_CFG_RATE                                14
#define LSB_CLK_NRES_CFG_RATE                                0
#define AADDR_CLK_NRES_0_CFG_RATE                            (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE)
#define AADDR_CLK_NRES_1_CFG_RATE                            (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_RATE)
#define REG_CLK_NRES_0_CFG_RATE                              (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_RATE))
#define REG_CLK_NRES_1_CFG_RATE                              (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_RATE))

#define ADDR_CLK_NRES_CFG_RATE_SEL_0                         (0x14U)
#define A_CLK_NRES_CFG_RATE_SEL_0(ba)                        ((ba) + ADDR_CLK_NRES_CFG_RATE_SEL_0)
#define R_CLK_NRES_CFG_RATE_SEL_0(ba)                        (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_RATE_SEL_0(ba)))
#define RES_CLK_NRES_CFG_RATE_SEL_0                          (0x5555U)
#define MSB_CLK_NRES_CFG_RATE_SEL_0                          15
#define LSB_CLK_NRES_CFG_RATE_SEL_0                          0
#define AADDR_CLK_NRES_0_CFG_RATE_SEL_0                      (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE_SEL_0)
#define AADDR_CLK_NRES_1_CFG_RATE_SEL_0                      (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_RATE_SEL_0)
#define REG_CLK_NRES_0_CFG_RATE_SEL_0                        (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_RATE_SEL_0))
#define REG_CLK_NRES_1_CFG_RATE_SEL_0                        (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_RATE_SEL_0))

#define ADDR_CLK_NRES_CFG_RATE_SEL_1                         (0x16U)
#define A_CLK_NRES_CFG_RATE_SEL_1(ba)                        ((ba) + ADDR_CLK_NRES_CFG_RATE_SEL_1)
#define R_CLK_NRES_CFG_RATE_SEL_1(ba)                        (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_RATE_SEL_1(ba)))
#define RES_CLK_NRES_CFG_RATE_SEL_1                          (0x5555U)
#define MSB_CLK_NRES_CFG_RATE_SEL_1                          15
#define LSB_CLK_NRES_CFG_RATE_SEL_1                          0
#define AADDR_CLK_NRES_0_CFG_RATE_SEL_1                      (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE_SEL_1)
#define AADDR_CLK_NRES_1_CFG_RATE_SEL_1                      (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_RATE_SEL_1)
#define REG_CLK_NRES_0_CFG_RATE_SEL_1                        (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_RATE_SEL_1))
#define REG_CLK_NRES_1_CFG_RATE_SEL_1                        (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_RATE_SEL_1))

#define ADDR_CLK_NRES_CFG_RATE_SEL_2                         (0x18U)
#define A_CLK_NRES_CFG_RATE_SEL_2(ba)                        ((ba) + ADDR_CLK_NRES_CFG_RATE_SEL_2)
#define R_CLK_NRES_CFG_RATE_SEL_2(ba)                        (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_RATE_SEL_2(ba)))
#define RES_CLK_NRES_CFG_RATE_SEL_2                          (0x155U)
#define MSB_CLK_NRES_CFG_RATE_SEL_2                          9
#define LSB_CLK_NRES_CFG_RATE_SEL_2                          0
#define AADDR_CLK_NRES_0_CFG_RATE_SEL_2                      (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_RATE_SEL_2)
#define AADDR_CLK_NRES_1_CFG_RATE_SEL_2                      (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_RATE_SEL_2)
#define REG_CLK_NRES_0_CFG_RATE_SEL_2                        (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_RATE_SEL_2))
#define REG_CLK_NRES_1_CFG_RATE_SEL_2                        (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_RATE_SEL_2))

#define ADDR_CLK_NRES_CFG_AS3_HISPI                          (0x1AU)
#define A_CLK_NRES_CFG_AS3_HISPI(ba)                         ((ba) + ADDR_CLK_NRES_CFG_AS3_HISPI)
#define R_CLK_NRES_CFG_AS3_HISPI(ba)                         (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_AS3_HISPI(ba)))
#define RES_CLK_NRES_CFG_AS3_HISPI                           (0x8U)
#define MSB_CLK_NRES_CFG_AS3_HISPI                           9
#define LSB_CLK_NRES_CFG_AS3_HISPI                           0
#define AADDR_CLK_NRES_0_CFG_AS3_HISPI                       (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_AS3_HISPI)
#define AADDR_CLK_NRES_1_CFG_AS3_HISPI                       (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_AS3_HISPI)
#define REG_CLK_NRES_0_CFG_AS3_HISPI                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_AS3_HISPI))
#define REG_CLK_NRES_1_CFG_AS3_HISPI                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_AS3_HISPI))

#define ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS                 (0x1CU)
#define A_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS(ba)                ((ba) + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS)
#define R_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS(ba)                (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS(ba)))
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS                  (0x0U)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS                  3
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS                  0
#define AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB0_AS              (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS)
#define AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB0_AS              (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_AS)
#define REG_CLK_NRES_0_CFG_SW_ONOFF_EN_WB0_AS                (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB0_AS))
#define REG_CLK_NRES_1_CFG_SW_ONOFF_EN_WB0_AS                (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB0_AS))

#define ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0                  (0x1EU)
#define A_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0(ba)                 ((ba) + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0)
#define R_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0(ba)                 (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0(ba)))
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0                   (0x0U)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0                   15
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0                   0
#define AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB0_0               (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0)
#define AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB0_0               (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_0)
#define REG_CLK_NRES_0_CFG_SW_ONOFF_EN_WB0_0                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB0_0))
#define REG_CLK_NRES_1_CFG_SW_ONOFF_EN_WB0_0                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB0_0))

#define ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1                  (0x20U)
#define A_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1(ba)                 ((ba) + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1)
#define R_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1(ba)                 (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1(ba)))
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1                   (0x0U)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1                   15
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1                   0
#define AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB0_1               (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1)
#define AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB0_1               (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB0_1)
#define REG_CLK_NRES_0_CFG_SW_ONOFF_EN_WB0_1                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB0_1))
#define REG_CLK_NRES_1_CFG_SW_ONOFF_EN_WB0_1                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB0_1))

#define ADDR_CLK_NRES_CFG_CW0                                (0x28U)
#define A_CLK_NRES_CFG_CW0(ba)                               ((ba) + ADDR_CLK_NRES_CFG_CW0)
#define R_CLK_NRES_CFG_CW0(ba)                               (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_CW0(ba)))
#define RES_CLK_NRES_CFG_CW0                                 (0x20U)
#define MSB_CLK_NRES_CFG_CW0                                 14
#define LSB_CLK_NRES_CFG_CW0                                 0
#define AADDR_CLK_NRES_0_CFG_CW0                             (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0)
#define AADDR_CLK_NRES_1_CFG_CW0                             (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_CW0)
#define REG_CLK_NRES_0_CFG_CW0                               (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_CW0))
#define REG_CLK_NRES_1_CFG_CW0                               (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_CW0))

#define ADDR_CLK_NRES_CFG_CW1                                (0x2AU)
#define A_CLK_NRES_CFG_CW1(ba)                               ((ba) + ADDR_CLK_NRES_CFG_CW1)
#define R_CLK_NRES_CFG_CW1(ba)                               (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_CW1(ba)))
#define RES_CLK_NRES_CFG_CW1                                 (0x20U)
#define MSB_CLK_NRES_CFG_CW1                                 14
#define LSB_CLK_NRES_CFG_CW1                                 0
#define AADDR_CLK_NRES_0_CFG_CW1                             (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW1)
#define AADDR_CLK_NRES_1_CFG_CW1                             (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_CW1)
#define REG_CLK_NRES_0_CFG_CW1                               (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_CW1))
#define REG_CLK_NRES_1_CFG_CW1                               (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_CW1))

#define ADDR_CLK_NRES_CFG_CW0_MIN                            (0x2CU)
#define A_CLK_NRES_CFG_CW0_MIN(ba)                           ((ba) + ADDR_CLK_NRES_CFG_CW0_MIN)
#define R_CLK_NRES_CFG_CW0_MIN(ba)                           (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_CW0_MIN(ba)))
#define RES_CLK_NRES_CFG_CW0_MIN                             (0x0U)
#define MSB_CLK_NRES_CFG_CW0_MIN                             15
#define LSB_CLK_NRES_CFG_CW0_MIN                             0
#define AADDR_CLK_NRES_0_CFG_CW0_MIN                         (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0_MIN)
#define AADDR_CLK_NRES_1_CFG_CW0_MIN                         (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_CW0_MIN)
#define REG_CLK_NRES_0_CFG_CW0_MIN                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_CW0_MIN))
#define REG_CLK_NRES_1_CFG_CW0_MIN                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_CW0_MIN))

#define ADDR_CLK_NRES_CFG_CW1_MIN                            (0x2EU)
#define A_CLK_NRES_CFG_CW1_MIN(ba)                           ((ba) + ADDR_CLK_NRES_CFG_CW1_MIN)
#define R_CLK_NRES_CFG_CW1_MIN(ba)                           (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_CW1_MIN(ba)))
#define RES_CLK_NRES_CFG_CW1_MIN                             (0x0U)
#define MSB_CLK_NRES_CFG_CW1_MIN                             15
#define LSB_CLK_NRES_CFG_CW1_MIN                             0
#define AADDR_CLK_NRES_0_CFG_CW1_MIN                         (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW1_MIN)
#define AADDR_CLK_NRES_1_CFG_CW1_MIN                         (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_CW1_MIN)
#define REG_CLK_NRES_0_CFG_CW1_MIN                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_CW1_MIN))
#define REG_CLK_NRES_1_CFG_CW1_MIN                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_CW1_MIN))

#define ADDR_CLK_NRES_CFG_CW0_MAX                            (0x30U)
#define A_CLK_NRES_CFG_CW0_MAX(ba)                           ((ba) + ADDR_CLK_NRES_CFG_CW0_MAX)
#define R_CLK_NRES_CFG_CW0_MAX(ba)                           (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_CW0_MAX(ba)))
#define RES_CLK_NRES_CFG_CW0_MAX                             (0x0U)
#define MSB_CLK_NRES_CFG_CW0_MAX                             15
#define LSB_CLK_NRES_CFG_CW0_MAX                             0
#define AADDR_CLK_NRES_0_CFG_CW0_MAX                         (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW0_MAX)
#define AADDR_CLK_NRES_1_CFG_CW0_MAX                         (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_CW0_MAX)
#define REG_CLK_NRES_0_CFG_CW0_MAX                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_CW0_MAX))
#define REG_CLK_NRES_1_CFG_CW0_MAX                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_CW0_MAX))

#define ADDR_CLK_NRES_CFG_CW1_MAX                            (0x32U)
#define A_CLK_NRES_CFG_CW1_MAX(ba)                           ((ba) + ADDR_CLK_NRES_CFG_CW1_MAX)
#define R_CLK_NRES_CFG_CW1_MAX(ba)                           (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_CW1_MAX(ba)))
#define RES_CLK_NRES_CFG_CW1_MAX                             (0x0U)
#define MSB_CLK_NRES_CFG_CW1_MAX                             15
#define LSB_CLK_NRES_CFG_CW1_MAX                             0
#define AADDR_CLK_NRES_0_CFG_CW1_MAX                         (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_CW1_MAX)
#define AADDR_CLK_NRES_1_CFG_CW1_MAX                         (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_CW1_MAX)
#define REG_CLK_NRES_0_CFG_CW1_MAX                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_CW1_MAX))
#define REG_CLK_NRES_1_CFG_CW1_MAX                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_CW1_MAX))

#define ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_AS                   (0x34U)
#define A_CLK_NRES_CFG_WDOG1_NRES_EN_AS(ba)                  ((ba) + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_AS)
#define R_CLK_NRES_CFG_WDOG1_NRES_EN_AS(ba)                  (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_WDOG1_NRES_EN_AS(ba)))
#define RES_CLK_NRES_CFG_WDOG1_NRES_EN_AS                    (0x0U)
#define MSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS                    3
#define LSB_CLK_NRES_CFG_WDOG1_NRES_EN_AS                    0
#define AADDR_CLK_NRES_0_CFG_WDOG1_NRES_EN_AS                (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_AS)
#define AADDR_CLK_NRES_1_CFG_WDOG1_NRES_EN_AS                (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_AS)
#define REG_CLK_NRES_0_CFG_WDOG1_NRES_EN_AS                  (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_WDOG1_NRES_EN_AS))
#define REG_CLK_NRES_1_CFG_WDOG1_NRES_EN_AS                  (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_WDOG1_NRES_EN_AS))

#define ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_0                    (0x36U)
#define A_CLK_NRES_CFG_WDOG1_NRES_EN_0(ba)                   ((ba) + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_0)
#define R_CLK_NRES_CFG_WDOG1_NRES_EN_0(ba)                   (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_WDOG1_NRES_EN_0(ba)))
#define RES_CLK_NRES_CFG_WDOG1_NRES_EN_0                     (0x0U)
#define MSB_CLK_NRES_CFG_WDOG1_NRES_EN_0                     15
#define LSB_CLK_NRES_CFG_WDOG1_NRES_EN_0                     0
#define AADDR_CLK_NRES_0_CFG_WDOG1_NRES_EN_0                 (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_0)
#define AADDR_CLK_NRES_1_CFG_WDOG1_NRES_EN_0                 (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_0)
#define REG_CLK_NRES_0_CFG_WDOG1_NRES_EN_0                   (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_WDOG1_NRES_EN_0))
#define REG_CLK_NRES_1_CFG_WDOG1_NRES_EN_0                   (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_WDOG1_NRES_EN_0))

#define ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_1                    (0x38U)
#define A_CLK_NRES_CFG_WDOG1_NRES_EN_1(ba)                   ((ba) + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_1)
#define R_CLK_NRES_CFG_WDOG1_NRES_EN_1(ba)                   (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_WDOG1_NRES_EN_1(ba)))
#define RES_CLK_NRES_CFG_WDOG1_NRES_EN_1                     (0x0U)
#define MSB_CLK_NRES_CFG_WDOG1_NRES_EN_1                     15
#define LSB_CLK_NRES_CFG_WDOG1_NRES_EN_1                     0
#define AADDR_CLK_NRES_0_CFG_WDOG1_NRES_EN_1                 (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_1)
#define AADDR_CLK_NRES_1_CFG_WDOG1_NRES_EN_1                 (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_WDOG1_NRES_EN_1)
#define REG_CLK_NRES_0_CFG_WDOG1_NRES_EN_1                   (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_WDOG1_NRES_EN_1))
#define REG_CLK_NRES_1_CFG_WDOG1_NRES_EN_1                   (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_WDOG1_NRES_EN_1))

#define ADDR_CLK_NRES_CFG_NRESET_AS                          (0x3CU)
#define A_CLK_NRES_CFG_NRESET_AS(ba)                         ((ba) + ADDR_CLK_NRES_CFG_NRESET_AS)
#define R_CLK_NRES_CFG_NRESET_AS(ba)                         (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_NRESET_AS(ba)))
#define RES_CLK_NRES_CFG_NRESET_AS                           (0x0U)
#define MSB_CLK_NRES_CFG_NRESET_AS                           3
#define LSB_CLK_NRES_CFG_NRESET_AS                           0
#define AADDR_CLK_NRES_0_CFG_NRESET_AS                       (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_NRESET_AS)
#define AADDR_CLK_NRES_1_CFG_NRESET_AS                       (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_NRESET_AS)
#define REG_CLK_NRES_0_CFG_NRESET_AS                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_NRESET_AS))
#define REG_CLK_NRES_1_CFG_NRESET_AS                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_NRESET_AS))

#define ADDR_CLK_NRES_CFG_NRESET_SW_0                        (0x3EU)
#define A_CLK_NRES_CFG_NRESET_SW_0(ba)                       ((ba) + ADDR_CLK_NRES_CFG_NRESET_SW_0)
#define R_CLK_NRES_CFG_NRESET_SW_0(ba)                       (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_NRESET_SW_0(ba)))
#define RES_CLK_NRES_CFG_NRESET_SW_0                         (0xffffU)
#define MSB_CLK_NRES_CFG_NRESET_SW_0                         15
#define LSB_CLK_NRES_CFG_NRESET_SW_0                         0
#define AADDR_CLK_NRES_0_CFG_NRESET_SW_0                     (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_NRESET_SW_0)
#define AADDR_CLK_NRES_1_CFG_NRESET_SW_0                     (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_NRESET_SW_0)
#define REG_CLK_NRES_0_CFG_NRESET_SW_0                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_NRESET_SW_0))
#define REG_CLK_NRES_1_CFG_NRESET_SW_0                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_NRESET_SW_0))

#define ADDR_CLK_NRES_CFG_NRESET_SW_1                        (0x40U)
#define A_CLK_NRES_CFG_NRESET_SW_1(ba)                       ((ba) + ADDR_CLK_NRES_CFG_NRESET_SW_1)
#define R_CLK_NRES_CFG_NRESET_SW_1(ba)                       (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_NRESET_SW_1(ba)))
#define RES_CLK_NRES_CFG_NRESET_SW_1                         (0xffffU)
#define MSB_CLK_NRES_CFG_NRESET_SW_1                         15
#define LSB_CLK_NRES_CFG_NRESET_SW_1                         0
#define AADDR_CLK_NRES_0_CFG_NRESET_SW_1                     (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_NRESET_SW_1)
#define AADDR_CLK_NRES_1_CFG_NRESET_SW_1                     (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_NRESET_SW_1)
#define REG_CLK_NRES_0_CFG_NRESET_SW_1                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_NRESET_SW_1))
#define REG_CLK_NRES_1_CFG_NRESET_SW_1                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_NRESET_SW_1))

#define ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS                 (0x44U)
#define A_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS(ba)                ((ba) + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS)
#define R_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS(ba)                (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS(ba)))
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS                  (0x0U)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS                  3
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS                  0
#define AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB1_AS              (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS)
#define AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB1_AS              (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_AS)
#define REG_CLK_NRES_0_CFG_SW_ONOFF_EN_WB1_AS                (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB1_AS))
#define REG_CLK_NRES_1_CFG_SW_ONOFF_EN_WB1_AS                (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB1_AS))

#define ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0                  (0x46U)
#define A_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0(ba)                 ((ba) + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0)
#define R_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0(ba)                 (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0(ba)))
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0                   (0x0U)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0                   15
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0                   0
#define AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB1_0               (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0)
#define AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB1_0               (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_0)
#define REG_CLK_NRES_0_CFG_SW_ONOFF_EN_WB1_0                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB1_0))
#define REG_CLK_NRES_1_CFG_SW_ONOFF_EN_WB1_0                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB1_0))

#define ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1                  (0x48U)
#define A_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1(ba)                 ((ba) + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1)
#define R_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1(ba)                 (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1(ba)))
#define RES_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1                   (0x0U)
#define MSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1                   15
#define LSB_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1                   0
#define AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB1_1               (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1)
#define AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB1_1               (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_SW_ONOFF_EN_WB1_1)
#define REG_CLK_NRES_0_CFG_SW_ONOFF_EN_WB1_1                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_SW_ONOFF_EN_WB1_1))
#define REG_CLK_NRES_1_CFG_SW_ONOFF_EN_WB1_1                 (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_SW_ONOFF_EN_WB1_1))

#define ADDR_CLK_NRES_CFG_RESET                              (0x4CU)
#define A_CLK_NRES_CFG_RESET(ba)                             ((ba) + ADDR_CLK_NRES_CFG_RESET)
#define R_CLK_NRES_CFG_RESET(ba)                             (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CFG_RESET(ba)))
#define RES_CLK_NRES_CFG_RESET                               (0x0U)
#define MSB_CLK_NRES_CFG_RESET                               5
#define LSB_CLK_NRES_CFG_RESET                               0
#define AADDR_CLK_NRES_0_CFG_RESET                           (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CFG_RESET)
#define AADDR_CLK_NRES_1_CFG_RESET                           (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CFG_RESET)
#define REG_CLK_NRES_0_CFG_RESET                             (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CFG_RESET))
#define REG_CLK_NRES_1_CFG_RESET                             (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CFG_RESET))

#define ADDR_CLK_NRES_CLK_SW_OFF_0                           (0x4EU)
#define A_CLK_NRES_CLK_SW_OFF_0(ba)                          ((ba) + ADDR_CLK_NRES_CLK_SW_OFF_0)
#define R_CLK_NRES_CLK_SW_OFF_0(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CLK_SW_OFF_0(ba)))
#define RES_CLK_NRES_CLK_SW_OFF_0                            (0x0U)
#define MSB_CLK_NRES_CLK_SW_OFF_0                            15
#define LSB_CLK_NRES_CLK_SW_OFF_0                            0
#define AADDR_CLK_NRES_0_CLK_SW_OFF_0                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CLK_SW_OFF_0)
#define AADDR_CLK_NRES_1_CLK_SW_OFF_0                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CLK_SW_OFF_0)
#define REG_CLK_NRES_0_CLK_SW_OFF_0                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CLK_SW_OFF_0))
#define REG_CLK_NRES_1_CLK_SW_OFF_0                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CLK_SW_OFF_0))

#define ADDR_CLK_NRES_CLK_SW_OFF_1                           (0x50U)
#define A_CLK_NRES_CLK_SW_OFF_1(ba)                          ((ba) + ADDR_CLK_NRES_CLK_SW_OFF_1)
#define R_CLK_NRES_CLK_SW_OFF_1(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CLK_SW_OFF_1(ba)))
#define RES_CLK_NRES_CLK_SW_OFF_1                            (0x0U)
#define MSB_CLK_NRES_CLK_SW_OFF_1                            15
#define LSB_CLK_NRES_CLK_SW_OFF_1                            0
#define AADDR_CLK_NRES_0_CLK_SW_OFF_1                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CLK_SW_OFF_1)
#define AADDR_CLK_NRES_1_CLK_SW_OFF_1                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CLK_SW_OFF_1)
#define REG_CLK_NRES_0_CLK_SW_OFF_1                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CLK_SW_OFF_1))
#define REG_CLK_NRES_1_CLK_SW_OFF_1                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CLK_SW_OFF_1))

#define ADDR_CLK_NRES_CLK_STATUS_AS                          (0x54U)
#define A_CLK_NRES_CLK_STATUS_AS(ba)                         ((ba) + ADDR_CLK_NRES_CLK_STATUS_AS)
#define R_CLK_NRES_CLK_STATUS_AS(ba)                         (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CLK_STATUS_AS(ba)))
#define RES_CLK_NRES_CLK_STATUS_AS                           (0x0U)
#define MSB_CLK_NRES_CLK_STATUS_AS                           3
#define LSB_CLK_NRES_CLK_STATUS_AS                           0
#define AADDR_CLK_NRES_0_CLK_STATUS_AS                       (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CLK_STATUS_AS)
#define AADDR_CLK_NRES_1_CLK_STATUS_AS                       (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CLK_STATUS_AS)
#define REG_CLK_NRES_0_CLK_STATUS_AS                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CLK_STATUS_AS))
#define REG_CLK_NRES_1_CLK_STATUS_AS                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CLK_STATUS_AS))

#define ADDR_CLK_NRES_CLK_STATUS_0                           (0x56U)
#define A_CLK_NRES_CLK_STATUS_0(ba)                          ((ba) + ADDR_CLK_NRES_CLK_STATUS_0)
#define R_CLK_NRES_CLK_STATUS_0(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CLK_STATUS_0(ba)))
#define RES_CLK_NRES_CLK_STATUS_0                            (0x0U)
#define MSB_CLK_NRES_CLK_STATUS_0                            15
#define LSB_CLK_NRES_CLK_STATUS_0                            0
#define AADDR_CLK_NRES_0_CLK_STATUS_0                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CLK_STATUS_0)
#define AADDR_CLK_NRES_1_CLK_STATUS_0                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CLK_STATUS_0)
#define REG_CLK_NRES_0_CLK_STATUS_0                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CLK_STATUS_0))
#define REG_CLK_NRES_1_CLK_STATUS_0                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CLK_STATUS_0))

#define ADDR_CLK_NRES_CLK_STATUS_1                           (0x58U)
#define A_CLK_NRES_CLK_STATUS_1(ba)                          ((ba) + ADDR_CLK_NRES_CLK_STATUS_1)
#define R_CLK_NRES_CLK_STATUS_1(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CLK_STATUS_1(ba)))
#define RES_CLK_NRES_CLK_STATUS_1                            (0x0U)
#define MSB_CLK_NRES_CLK_STATUS_1                            15
#define LSB_CLK_NRES_CLK_STATUS_1                            0
#define AADDR_CLK_NRES_0_CLK_STATUS_1                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CLK_STATUS_1)
#define AADDR_CLK_NRES_1_CLK_STATUS_1                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CLK_STATUS_1)
#define REG_CLK_NRES_0_CLK_STATUS_1                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CLK_STATUS_1))
#define REG_CLK_NRES_1_CLK_STATUS_1                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CLK_STATUS_1))

#define ADDR_CLK_NRES_CW0_MEASUREMENT                        (0x5CU)
#define A_CLK_NRES_CW0_MEASUREMENT(ba)                       ((ba) + ADDR_CLK_NRES_CW0_MEASUREMENT)
#define R_CLK_NRES_CW0_MEASUREMENT(ba)                       (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CW0_MEASUREMENT(ba)))
#define RES_CLK_NRES_CW0_MEASUREMENT                         (0x0U)
#define MSB_CLK_NRES_CW0_MEASUREMENT                         15
#define LSB_CLK_NRES_CW0_MEASUREMENT                         0
#define AADDR_CLK_NRES_0_CW0_MEASUREMENT                     (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CW0_MEASUREMENT)
#define AADDR_CLK_NRES_1_CW0_MEASUREMENT                     (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CW0_MEASUREMENT)
#define REG_CLK_NRES_0_CW0_MEASUREMENT                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CW0_MEASUREMENT))
#define REG_CLK_NRES_1_CW0_MEASUREMENT                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CW0_MEASUREMENT))

#define ADDR_CLK_NRES_CW1_MEASUREMENT                        (0x5EU)
#define A_CLK_NRES_CW1_MEASUREMENT(ba)                       ((ba) + ADDR_CLK_NRES_CW1_MEASUREMENT)
#define R_CLK_NRES_CW1_MEASUREMENT(ba)                       (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CW1_MEASUREMENT(ba)))
#define RES_CLK_NRES_CW1_MEASUREMENT                         (0x0U)
#define MSB_CLK_NRES_CW1_MEASUREMENT                         15
#define LSB_CLK_NRES_CW1_MEASUREMENT                         0
#define AADDR_CLK_NRES_0_CW1_MEASUREMENT                     (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CW1_MEASUREMENT)
#define AADDR_CLK_NRES_1_CW1_MEASUREMENT                     (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CW1_MEASUREMENT)
#define REG_CLK_NRES_0_CW1_MEASUREMENT                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CW1_MEASUREMENT))
#define REG_CLK_NRES_1_CW1_MEASUREMENT                       (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CW1_MEASUREMENT))

#define ADDR_CLK_NRES_CLK_SW_ON_AS                           (0x60U)
#define A_CLK_NRES_CLK_SW_ON_AS(ba)                          ((ba) + ADDR_CLK_NRES_CLK_SW_ON_AS)
#define R_CLK_NRES_CLK_SW_ON_AS(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CLK_SW_ON_AS(ba)))
#define RES_CLK_NRES_CLK_SW_ON_AS                            (0x0U)
#define MSB_CLK_NRES_CLK_SW_ON_AS                            3
#define LSB_CLK_NRES_CLK_SW_ON_AS                            0
#define AADDR_CLK_NRES_0_CLK_SW_ON_AS                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CLK_SW_ON_AS)
#define AADDR_CLK_NRES_1_CLK_SW_ON_AS                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CLK_SW_ON_AS)
#define REG_CLK_NRES_0_CLK_SW_ON_AS                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CLK_SW_ON_AS))
#define REG_CLK_NRES_1_CLK_SW_ON_AS                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CLK_SW_ON_AS))

#define ADDR_CLK_NRES_CLK_SW_ON_0                            (0x62U)
#define A_CLK_NRES_CLK_SW_ON_0(ba)                           ((ba) + ADDR_CLK_NRES_CLK_SW_ON_0)
#define R_CLK_NRES_CLK_SW_ON_0(ba)                           (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CLK_SW_ON_0(ba)))
#define RES_CLK_NRES_CLK_SW_ON_0                             (0x0U)
#define MSB_CLK_NRES_CLK_SW_ON_0                             15
#define LSB_CLK_NRES_CLK_SW_ON_0                             0
#define AADDR_CLK_NRES_0_CLK_SW_ON_0                         (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CLK_SW_ON_0)
#define AADDR_CLK_NRES_1_CLK_SW_ON_0                         (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CLK_SW_ON_0)
#define REG_CLK_NRES_0_CLK_SW_ON_0                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CLK_SW_ON_0))
#define REG_CLK_NRES_1_CLK_SW_ON_0                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CLK_SW_ON_0))

#define ADDR_CLK_NRES_CLK_SW_ON_1                            (0x64U)
#define A_CLK_NRES_CLK_SW_ON_1(ba)                           ((ba) + ADDR_CLK_NRES_CLK_SW_ON_1)
#define R_CLK_NRES_CLK_SW_ON_1(ba)                           (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CLK_SW_ON_1(ba)))
#define RES_CLK_NRES_CLK_SW_ON_1                             (0x0U)
#define MSB_CLK_NRES_CLK_SW_ON_1                             15
#define LSB_CLK_NRES_CLK_SW_ON_1                             0
#define AADDR_CLK_NRES_0_CLK_SW_ON_1                         (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CLK_SW_ON_1)
#define AADDR_CLK_NRES_1_CLK_SW_ON_1                         (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CLK_SW_ON_1)
#define REG_CLK_NRES_0_CLK_SW_ON_1                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CLK_SW_ON_1))
#define REG_CLK_NRES_1_CLK_SW_ON_1                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CLK_SW_ON_1))

#define ADDR_CLK_NRES_NRESET_SOURCES                         (0x68U)
#define A_CLK_NRES_NRESET_SOURCES(ba)                        ((ba) + ADDR_CLK_NRES_NRESET_SOURCES)
#define R_CLK_NRES_NRESET_SOURCES(ba)                        (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_NRESET_SOURCES(ba)))
#define RES_CLK_NRES_NRESET_SOURCES                          (0x11U)
#define MSB_CLK_NRES_NRESET_SOURCES                          14
#define LSB_CLK_NRES_NRESET_SOURCES                          0
#define AADDR_CLK_NRES_0_NRESET_SOURCES                      (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_NRESET_SOURCES)
#define AADDR_CLK_NRES_1_NRESET_SOURCES                      (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_NRESET_SOURCES)
#define REG_CLK_NRES_0_NRESET_SOURCES                        (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_NRESET_SOURCES))
#define REG_CLK_NRES_1_NRESET_SOURCES                        (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_NRESET_SOURCES))

#define ADDR_CLK_NRES_CMD_CPU1_WAKE                          (0x6CU)
#define A_CLK_NRES_CMD_CPU1_WAKE(ba)                         ((ba) + ADDR_CLK_NRES_CMD_CPU1_WAKE)
#define R_CLK_NRES_CMD_CPU1_WAKE(ba)                         (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CMD_CPU1_WAKE(ba)))
#define RES_CLK_NRES_CMD_CPU1_WAKE                           (0x0U)
#define MSB_CLK_NRES_CMD_CPU1_WAKE                           0
#define LSB_CLK_NRES_CMD_CPU1_WAKE                           0
#define AADDR_CLK_NRES_0_CMD_CPU1_WAKE                       (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CMD_CPU1_WAKE)
#define AADDR_CLK_NRES_1_CMD_CPU1_WAKE                       (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CMD_CPU1_WAKE)
#define REG_CLK_NRES_0_CMD_CPU1_WAKE                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CMD_CPU1_WAKE))
#define REG_CLK_NRES_1_CMD_CPU1_WAKE                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CMD_CPU1_WAKE))

#define ADDR_CLK_NRES_IRQ_STATUS                             (0x6EU)
#define A_CLK_NRES_IRQ_STATUS(ba)                            ((ba) + ADDR_CLK_NRES_IRQ_STATUS)
#define R_CLK_NRES_IRQ_STATUS(ba)                            (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_IRQ_STATUS(ba)))
#define RES_CLK_NRES_IRQ_STATUS                              (0x0U)
#define MSB_CLK_NRES_IRQ_STATUS                              3
#define LSB_CLK_NRES_IRQ_STATUS                              0
#define AADDR_CLK_NRES_0_IRQ_STATUS                          (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_IRQ_STATUS)
#define AADDR_CLK_NRES_1_IRQ_STATUS                          (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_IRQ_STATUS)
#define REG_CLK_NRES_0_IRQ_STATUS                            (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_IRQ_STATUS))
#define REG_CLK_NRES_1_IRQ_STATUS                            (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_IRQ_STATUS))

#define ADDR_CLK_NRES_IRQ_MASK                               (0x72U)
#define A_CLK_NRES_IRQ_MASK(ba)                              ((ba) + ADDR_CLK_NRES_IRQ_MASK)
#define R_CLK_NRES_IRQ_MASK(ba)                              (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_IRQ_MASK(ba)))
#define RES_CLK_NRES_IRQ_MASK                                (0x0U)
#define MSB_CLK_NRES_IRQ_MASK                                3
#define LSB_CLK_NRES_IRQ_MASK                                0
#define AADDR_CLK_NRES_0_IRQ_MASK                            (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_IRQ_MASK)
#define AADDR_CLK_NRES_1_IRQ_MASK                            (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_IRQ_MASK)
#define REG_CLK_NRES_0_IRQ_MASK                              (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_IRQ_MASK))
#define REG_CLK_NRES_1_IRQ_MASK                              (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_IRQ_MASK))

#define ADDR_CLK_NRES_IRQ_VENABLE                            (0x76U)
#define A_CLK_NRES_IRQ_VENABLE(ba)                           ((ba) + ADDR_CLK_NRES_IRQ_VENABLE)
#define R_CLK_NRES_IRQ_VENABLE(ba)                           (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_IRQ_VENABLE(ba)))
#define RES_CLK_NRES_IRQ_VENABLE                             (0x0U)
#define MSB_CLK_NRES_IRQ_VENABLE                             1
#define LSB_CLK_NRES_IRQ_VENABLE                             0
#define AADDR_CLK_NRES_0_IRQ_VENABLE                         (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_IRQ_VENABLE)
#define AADDR_CLK_NRES_1_IRQ_VENABLE                         (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_IRQ_VENABLE)
#define REG_CLK_NRES_0_IRQ_VENABLE                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_IRQ_VENABLE))
#define REG_CLK_NRES_1_IRQ_VENABLE                           (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_IRQ_VENABLE))

#define ADDR_CLK_NRES_IRQ_VDISABLE                           (0x78U)
#define A_CLK_NRES_IRQ_VDISABLE(ba)                          ((ba) + ADDR_CLK_NRES_IRQ_VDISABLE)
#define R_CLK_NRES_IRQ_VDISABLE(ba)                          (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_IRQ_VDISABLE(ba)))
#define RES_CLK_NRES_IRQ_VDISABLE                            (0x0U)
#define MSB_CLK_NRES_IRQ_VDISABLE                            1
#define LSB_CLK_NRES_IRQ_VDISABLE                            0
#define AADDR_CLK_NRES_0_IRQ_VDISABLE                        (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_IRQ_VDISABLE)
#define AADDR_CLK_NRES_1_IRQ_VDISABLE                        (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_IRQ_VDISABLE)
#define REG_CLK_NRES_0_IRQ_VDISABLE                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_IRQ_VDISABLE))
#define REG_CLK_NRES_1_IRQ_VDISABLE                          (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_IRQ_VDISABLE))

#define ADDR_CLK_NRES_IRQ_VMAX                               (0x7AU)
#define A_CLK_NRES_IRQ_VMAX(ba)                              ((ba) + ADDR_CLK_NRES_IRQ_VMAX)
#define R_CLK_NRES_IRQ_VMAX(ba)                              (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_IRQ_VMAX(ba)))
#define RES_CLK_NRES_IRQ_VMAX                                (0x4U)
#define MSB_CLK_NRES_IRQ_VMAX                                2
#define LSB_CLK_NRES_IRQ_VMAX                                0
#define AADDR_CLK_NRES_0_IRQ_VMAX                            (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_IRQ_VMAX)
#define AADDR_CLK_NRES_1_IRQ_VMAX                            (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_IRQ_VMAX)
#define REG_CLK_NRES_0_IRQ_VMAX                              (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_IRQ_VMAX))
#define REG_CLK_NRES_1_IRQ_VMAX                              (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_IRQ_VMAX))

#define ADDR_CLK_NRES_IRQ_VNO                                (0x7CU)
#define A_CLK_NRES_IRQ_VNO(ba)                               ((ba) + ADDR_CLK_NRES_IRQ_VNO)
#define R_CLK_NRES_IRQ_VNO(ba)                               (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_IRQ_VNO(ba)))
#define RES_CLK_NRES_IRQ_VNO                                 (0x4U)
#define MSB_CLK_NRES_IRQ_VNO                                 2
#define LSB_CLK_NRES_IRQ_VNO                                 0
#define AADDR_CLK_NRES_0_IRQ_VNO                             (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_IRQ_VNO)
#define AADDR_CLK_NRES_1_IRQ_VNO                             (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_IRQ_VNO)
#define REG_CLK_NRES_0_IRQ_VNO                               (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_IRQ_VNO))
#define REG_CLK_NRES_1_IRQ_VNO                               (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_IRQ_VNO))

#define ADDR_CLK_NRES_CLK_SW_OFF_AS                          (0x7EU)
#define A_CLK_NRES_CLK_SW_OFF_AS(ba)                         ((ba) + ADDR_CLK_NRES_CLK_SW_OFF_AS)
#define R_CLK_NRES_CLK_SW_OFF_AS(ba)                         (*(volatile unsigned short *)((unsigned int)A_CLK_NRES_CLK_SW_OFF_AS(ba)))
#define RES_CLK_NRES_CLK_SW_OFF_AS                           (0x0U)
#define MSB_CLK_NRES_CLK_SW_OFF_AS                           3
#define LSB_CLK_NRES_CLK_SW_OFF_AS                           0
#define AADDR_CLK_NRES_0_CLK_SW_OFF_AS                       (BASE_ADDR_CLK_NRES_0 + ADDR_CLK_NRES_CLK_SW_OFF_AS)
#define AADDR_CLK_NRES_1_CLK_SW_OFF_AS                       (BASE_ADDR_CLK_NRES_1 + ADDR_CLK_NRES_CLK_SW_OFF_AS)
#define REG_CLK_NRES_0_CLK_SW_OFF_AS                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_0_CLK_SW_OFF_AS))
#define REG_CLK_NRES_1_CLK_SW_OFF_AS                         (*(volatile unsigned short *)((unsigned int)AADDR_CLK_NRES_1_CLK_SW_OFF_AS))




#endif
