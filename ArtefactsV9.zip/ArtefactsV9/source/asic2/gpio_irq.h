/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         gpio_irq.h
*
* @brief        General Purpose Input/Output HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __GPIO_IRQ_H__
#define __GPIO_IRQ_H__

#define GPIO_NUM_IRQS 16

/**
  * \brief This is an enum class for GPIO describing IRQ events
  *
  * \ingroup gpio
  */ 
typedef enum{
  GPIO_IRQ_EVT_G0_PIN1 =                0,   ///< interrupt event occurred in group 0 pin 1
  GPIO_IRQ_EVT_G0_PIN2 =                1,   ///< interrupt event occurred in group 0 pin 2
  GPIO_IRQ_EVT_G0_PIN3 =                2,   ///< interrupt event occurred in group 0 pin 3
  GPIO_IRQ_EVT_G0_PIN4 =                3,   ///< interrupt event occurred in group 0 pin 4
  GPIO_IRQ_EVT_G1_PIN1 =                4,   ///< interrupt event occurred in group 1 pin 1
  GPIO_IRQ_EVT_G1_PIN6 =                5,   ///< interrupt event occurred in group 1 pin 6
  GPIO_IRQ_EVT_G1_PIN7 =                6,   ///< interrupt event occurred in group 1 pin 7
  GPIO_IRQ_EVT_G1_PIN8 =                7,   ///< interrupt event occurred in group 1 pin 8
  GPIO_IRQ_EVT_G2_PIN2 =                8,   ///< interrupt event occurred in group 2 pin 2
  GPIO_IRQ_EVT_G2_PIN3 =                9,   ///< interrupt event occurred in group 2 pin 3
  GPIO_IRQ_EVT_G2_PIN7 =                10,  ///< interrupt event occurred in group 2 pin 7
  GPIO_IRQ_EVT_G2_PIN8 =                11,  ///< interrupt event occurred in group 2 pin 8
  GPIO_IRQ_EVT_G3_PIN3 =                12,  ///< interrupt event occurred in group 3 pin 3
  GPIO_IRQ_EVT_G3_PIN4 =                13,  ///< interrupt event occurred in group 3 pin 4
  GPIO_IRQ_EVT_G3_PIN5 =                14,  ///< interrupt event occurred in group 3 pin 5
  GPIO_IRQ_EVT_G3_PIN6 =                15   ///< interrupt event occurred in group 3 pin 6
} gpio_irq_t;

#endif
