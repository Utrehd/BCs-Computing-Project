/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swd_bf.h
*
* @brief        SWD_PM HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __SWD_BF_H__
#define __SWD_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_SWD
#define BASE_ADDR_SWD 0x40006200U
#endif

#define NUMBER_SWD 1


/* ############################################################################ */
/**
 * \brief SWD PM instancies
 *
 * \ingroup api_swd_pm 
 */ 
typedef enum {
  /**
   * SWD PM instance
   */ 
  SWD                            = (int)BASE_ADDR_SWD
} swd_num_t;

// Register bit field definitions

/* SWD_PHY_CONFIG */

#define MSK_SWD_PHY_CONFIG_INV_RXD_0                        (0x1)     /* [0] */
#define RES_SWD_PHY_CONFIG_INV_RXD_0                        (0x0)
#define SFT_SWD_PHY_CONFIG_INV_RXD_0                        (0)
#define LSB_SWD_PHY_CONFIG_INV_RXD_0                        (0)
#define MSB_SWD_PHY_CONFIG_INV_RXD_0                        (0)
#define BIT_SWD_PHY_CONFIG_INV_RXD_0                        (0x1)     /* [0] */
#define MSK_SWD_PHY_CONFIG_INV_OE_0                         (0x1)     /* [1] */
#define RES_SWD_PHY_CONFIG_INV_OE_0                         (0x0)
#define SFT_SWD_PHY_CONFIG_INV_OE_0                         (1)
#define LSB_SWD_PHY_CONFIG_INV_OE_0                         (1)
#define MSB_SWD_PHY_CONFIG_INV_OE_0                         (1)
#define BIT_SWD_PHY_CONFIG_INV_OE_0                         (0x2)     /* [1] */
#define MSK_SWD_PHY_CONFIG_INV_TXD_0                        (0x1)     /* [2] */
#define RES_SWD_PHY_CONFIG_INV_TXD_0                        (0x0)
#define SFT_SWD_PHY_CONFIG_INV_TXD_0                        (2)
#define LSB_SWD_PHY_CONFIG_INV_TXD_0                        (2)
#define MSB_SWD_PHY_CONFIG_INV_TXD_0                        (2)
#define BIT_SWD_PHY_CONFIG_INV_TXD_0                        (0x4)     /* [2] */
#define MSK_SWD_PHY_CONFIG_LOCAL_FEEDBACK_0                 (0x1)     /* [3] */
#define RES_SWD_PHY_CONFIG_LOCAL_FEEDBACK_0                 (0x0)
#define SFT_SWD_PHY_CONFIG_LOCAL_FEEDBACK_0                 (3)
#define LSB_SWD_PHY_CONFIG_LOCAL_FEEDBACK_0                 (3)
#define MSB_SWD_PHY_CONFIG_LOCAL_FEEDBACK_0                 (3)
#define BIT_SWD_PHY_CONFIG_LOCAL_FEEDBACK_0                 (0x8)     /* [3] */
#define MSK_SWD_PHY_CONFIG_INV_RXD_1                        (0x1)     /* [4] */
#define RES_SWD_PHY_CONFIG_INV_RXD_1                        (0x0)
#define SFT_SWD_PHY_CONFIG_INV_RXD_1                        (4)
#define LSB_SWD_PHY_CONFIG_INV_RXD_1                        (4)
#define MSB_SWD_PHY_CONFIG_INV_RXD_1                        (4)
#define BIT_SWD_PHY_CONFIG_INV_RXD_1                        (0x10)    /* [4] */
#define MSK_SWD_PHY_CONFIG_INV_OE_1                         (0x1)     /* [5] */
#define RES_SWD_PHY_CONFIG_INV_OE_1                         (0x0)
#define SFT_SWD_PHY_CONFIG_INV_OE_1                         (5)
#define LSB_SWD_PHY_CONFIG_INV_OE_1                         (5)
#define MSB_SWD_PHY_CONFIG_INV_OE_1                         (5)
#define BIT_SWD_PHY_CONFIG_INV_OE_1                         (0x20)    /* [5] */
#define MSK_SWD_PHY_CONFIG_INV_TXD_1                        (0x1)     /* [6] */
#define RES_SWD_PHY_CONFIG_INV_TXD_1                        (0x0)
#define SFT_SWD_PHY_CONFIG_INV_TXD_1                        (6)
#define LSB_SWD_PHY_CONFIG_INV_TXD_1                        (6)
#define MSB_SWD_PHY_CONFIG_INV_TXD_1                        (6)
#define BIT_SWD_PHY_CONFIG_INV_TXD_1                        (0x40)    /* [6] */
#define MSK_SWD_PHY_CONFIG_LOCAL_FEEDBACK_1                 (0x1)     /* [7] */
#define RES_SWD_PHY_CONFIG_LOCAL_FEEDBACK_1                 (0x0)
#define SFT_SWD_PHY_CONFIG_LOCAL_FEEDBACK_1                 (7)
#define LSB_SWD_PHY_CONFIG_LOCAL_FEEDBACK_1                 (7)
#define MSB_SWD_PHY_CONFIG_LOCAL_FEEDBACK_1                 (7)
#define BIT_SWD_PHY_CONFIG_LOCAL_FEEDBACK_1                 (0x80)    /* [7] */


/* ############################################################################ */
/**
 * \brief This structure describes SWD PM COMM Configuration
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: invert RXD 0
   */ 
  unsigned short inv_rxd_0                     :    1;       /* [0] */
  /**
   * 1: invert OE 0
   */ 
  unsigned short inv_oe_0                      :    1;       /* [1] */
  /**
   * 1: invert TXD 0
   */ 
  unsigned short inv_txd_0                     :    1;       /* [2] */
  /**
   * 1: enable local feedback from TX to RX for bus 0
   */ 
  unsigned short local_feedback_0              :    1;       /* [3] */
  /**
   * 1: invert RXD 1
   */ 
  unsigned short inv_rxd_1                     :    1;       /* [4] */
  /**
   * 1: invert OE 1
   */ 
  unsigned short inv_oe_1                      :    1;       /* [5] */
  /**
   * 1: invert TXD 1
   */ 
  unsigned short inv_txd_1                     :    1;       /* [6] */
  /**
   * 1: enable local feedback from TX to RX for bus 1
   */ 
  unsigned short local_feedback_1              :    1;       /* [7] */
  unsigned short reserved                      :    8;
} swd_phy_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM COMM Configuration
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_phy_config_bf bf;  ///< bit field representation
} swd_phy_config_t;


/* SWD_INTEGRATOR_DPLL_THRESHOLD */

#define MSK_SWD_INTEGRATOR_DPLL_THRESHOLD                   (0x1fff)  /* [12:0] */

typedef unsigned short swd_integrator_dpll_threshold_t;               /* [12:0] */


/* SWD_INTEGRATOR_DISACK_THRESHOLD */

#define MSK_SWD_INTEGRATOR_DISACK_THRESHOLD                 (0xffff)  /* [15:0] */

typedef unsigned short swd_integrator_disack_threshold_t;             /* [15:0] */


/* SWD_IDLE_DPLL_THRESHOLD_LW */

#define MSK_SWD_IDLE_DPLL_THRESHOLD_LW                      (0xffff)  /* [15:0] */

typedef unsigned short swd_idle_dpll_threshold_lw_t;                  /* [15:0] */


/* SWD_IDLE_PE_THRESHOLD_LW */

#define MSK_SWD_IDLE_PE_THRESHOLD_LW                        (0xffff)  /* [15:0] */

typedef unsigned short swd_idle_pe_threshold_lw_t;                    /* [15:0] */


/* SWD_DPLL_OV_FRAC_PERIOD */

#define MSK_SWD_DPLL_OV_FRAC_PERIOD_OV_EN                   (0x1)     /* [0] */
#define RES_SWD_DPLL_OV_FRAC_PERIOD_OV_EN                   (0x0)
#define SFT_SWD_DPLL_OV_FRAC_PERIOD_OV_EN                   (0)
#define LSB_SWD_DPLL_OV_FRAC_PERIOD_OV_EN                   (0)
#define MSB_SWD_DPLL_OV_FRAC_PERIOD_OV_EN                   (0)
#define BIT_SWD_DPLL_OV_FRAC_PERIOD_OV_EN                   (0x1)     /* [0] */
#define MSK_SWD_DPLL_OV_FRAC_PERIOD_OV_FRACVAL              (0x7)     /* [ 3:1] */
#define RES_SWD_DPLL_OV_FRAC_PERIOD_OV_FRACVAL              (0x0)
#define SFT_SWD_DPLL_OV_FRAC_PERIOD_OV_FRACVAL              (1)
#define LSB_SWD_DPLL_OV_FRAC_PERIOD_OV_FRACVAL              (1)
#define MSB_SWD_DPLL_OV_FRAC_PERIOD_OV_FRACVAL              (3)
#define MSK_SWD_DPLL_OV_FRAC_PERIOD_OV_PERIOD               (0xfff)   /* [15:4] */
#define RES_SWD_DPLL_OV_FRAC_PERIOD_OV_PERIOD               (0x000)
#define SFT_SWD_DPLL_OV_FRAC_PERIOD_OV_PERIOD               (4)
#define LSB_SWD_DPLL_OV_FRAC_PERIOD_OV_PERIOD               (4)
#define MSB_SWD_DPLL_OV_FRAC_PERIOD_OV_PERIOD               (15)


/* ############################################################################ */
/**
 * \brief This structure describes SWD PM Overflow Fractional Period
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: Override Fractional and Period value for TX DPLL (must be
   *    enabled for coordinator)
   */ 
  unsigned short ov_en                         :    1;       /* [0] */
  /**
   * fractional value for DPLL ( val= (3b/2) + (2b/4) + (1b/8) )
   */ 
  unsigned short ov_fracval                    :    3;       /* [ 3:1] */
  /**
   * period value for DPLL; period = COMM frequency / bus speed; where COMM = AS_SWD_TSU
   */ 
  unsigned short ov_period                     :   12;       /* [15:4] */
} swd_dpll_ov_frac_period_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Overflow Fractional Period
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dpll_ov_frac_period_bf bf;  ///< bit field representation
} swd_dpll_ov_frac_period_t;


/* SWD_DPLL_MIN_PERIOD */

#define MSK_SWD_DPLL_MIN_PERIOD                             (0xffff)  /* [15:0] */

typedef unsigned short swd_dpll_min_period_t;                         /* [15:0] */


/* SWD_DPLL_MAX_PERIOD */

#define MSK_SWD_DPLL_MAX_PERIOD                             (0xffff)  /* [15:0] */

typedef unsigned short swd_dpll_max_period_t;                         /* [15:0] */


/* SWD_DPLL_LAST_FRAC_PERIOD */

#define MSK_SWD_DPLL_LAST_FRAC_PERIOD_NOT_USED              (0x1)     /* [0] */
#define RES_SWD_DPLL_LAST_FRAC_PERIOD_NOT_USED              (0x0)
#define SFT_SWD_DPLL_LAST_FRAC_PERIOD_NOT_USED              (0)
#define LSB_SWD_DPLL_LAST_FRAC_PERIOD_NOT_USED              (0)
#define MSB_SWD_DPLL_LAST_FRAC_PERIOD_NOT_USED              (0)
#define BIT_SWD_DPLL_LAST_FRAC_PERIOD_NOT_USED              (0x1)     /* [0] */
#define MSK_SWD_DPLL_LAST_FRAC_PERIOD_FRACVAL               (0x7)     /* [ 3:1] */
#define RES_SWD_DPLL_LAST_FRAC_PERIOD_FRACVAL               (0x0)
#define SFT_SWD_DPLL_LAST_FRAC_PERIOD_FRACVAL               (1)
#define LSB_SWD_DPLL_LAST_FRAC_PERIOD_FRACVAL               (1)
#define MSB_SWD_DPLL_LAST_FRAC_PERIOD_FRACVAL               (3)
#define MSK_SWD_DPLL_LAST_FRAC_PERIOD_PERIOD                (0xfff)   /* [15:4] */
#define RES_SWD_DPLL_LAST_FRAC_PERIOD_PERIOD                (0x000)
#define SFT_SWD_DPLL_LAST_FRAC_PERIOD_PERIOD                (4)
#define LSB_SWD_DPLL_LAST_FRAC_PERIOD_PERIOD                (4)
#define MSB_SWD_DPLL_LAST_FRAC_PERIOD_PERIOD                (15)


/* ############################################################################ */
/**
 * \brief This structure describes SWD PM Last Fractional Period
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * read as 0
   */ 
  unsigned short not_used                      :    1;       /* [0] */
  /**
   * last detected fractional value
   */ 
  unsigned short fracval                       :    3;       /* [ 3:1] */
  /**
   * last detected bit length
   */ 
  unsigned short period                        :   12;       /* [15:4] */
} swd_dpll_last_frac_period_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Last Fractional Period
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dpll_last_frac_period_bf bf;  ///< bit field representation
} swd_dpll_last_frac_period_t;


/* SWD_DPLL_MEAN_ALPHA */

#define MSK_SWD_DPLL_MEAN_ALPHA                             (0x7)     /* [ 2:0] */

typedef unsigned short swd_dpll_mean_alpha_t;                         /* [ 2:0] */


/* SWD_DPLL_MEAN_FRAC_PERIOD */

#define MSK_SWD_DPLL_MEAN_FRAC_PERIOD_NOT_USED              (0x1)     /* [0] */
#define RES_SWD_DPLL_MEAN_FRAC_PERIOD_NOT_USED              (0x0)
#define SFT_SWD_DPLL_MEAN_FRAC_PERIOD_NOT_USED              (0)
#define LSB_SWD_DPLL_MEAN_FRAC_PERIOD_NOT_USED              (0)
#define MSB_SWD_DPLL_MEAN_FRAC_PERIOD_NOT_USED              (0)
#define BIT_SWD_DPLL_MEAN_FRAC_PERIOD_NOT_USED              (0x1)     /* [0] */
#define MSK_SWD_DPLL_MEAN_FRAC_PERIOD_FRACVAL               (0x7)     /* [ 3:1] */
#define RES_SWD_DPLL_MEAN_FRAC_PERIOD_FRACVAL               (0x0)
#define SFT_SWD_DPLL_MEAN_FRAC_PERIOD_FRACVAL               (1)
#define LSB_SWD_DPLL_MEAN_FRAC_PERIOD_FRACVAL               (1)
#define MSB_SWD_DPLL_MEAN_FRAC_PERIOD_FRACVAL               (3)
#define MSK_SWD_DPLL_MEAN_FRAC_PERIOD_PERIOD                (0xfff)   /* [15:4] */
#define RES_SWD_DPLL_MEAN_FRAC_PERIOD_PERIOD                (0x000)
#define SFT_SWD_DPLL_MEAN_FRAC_PERIOD_PERIOD                (4)
#define LSB_SWD_DPLL_MEAN_FRAC_PERIOD_PERIOD                (4)
#define MSB_SWD_DPLL_MEAN_FRAC_PERIOD_PERIOD                (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Last Calculated Mean Fractional Period
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * read as 0
   */ 
  unsigned short not_used                      :    1;       /* [0] */
  /**
   * last calculated mean fractional value
   */ 
  unsigned short fracval                       :    3;       /* [ 3:1] */
  /**
   * last calculated mean entitlemen
   */ 
  unsigned short period                        :   12;       /* [15:4] */
} swd_dpll_mean_frac_period_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Last Calculated Mean Fractional Period
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dpll_mean_frac_period_bf bf;  ///< bit field representation
} swd_dpll_mean_frac_period_t;


/* SWD_START_THRESHOLD */

#define MSK_SWD_START_THRESHOLD                             (0x7ff)   /* [10:0] */

typedef unsigned short swd_start_threshold_t;                         /* [10:0] */


/* SWD_DATA_OFFSET */

#define MSK_SWD_DATA_OFFSET                                 (0x1fff)  /* [12:0] */

typedef unsigned short swd_data_offset_t;                             /* [12:0] */


/* SWD_TIMEOUT_RX */

#define MSK_SWD_TIMEOUT_RX                                  (0xff)    /* [ 7:0] */

typedef unsigned short swd_timeout_rx_t;                              /* [ 7:0] */


/* SWD_TIMEOUT_REPLACE */

#define MSK_SWD_TIMEOUT_REPLACE                             (0xff)    /* [ 7:0] */

typedef unsigned short swd_timeout_replace_t;                         /* [ 7:0] */


/* SWD_TX_PRESTART_SYNC */

#define MSK_SWD_TX_PRESTART_SYNC                            (0xffff)  /* [15:0] */

typedef unsigned short swd_tx_prestart_sync_t;                        /* [15:0] */


/* SWD_TX_PRESTART_DATA */

#define MSK_SWD_TX_PRESTART_DATA                            (0x1fff)  /* [12:0] */

typedef unsigned short swd_tx_prestart_data_t;                        /* [12:0] */


/* SWD_TX_END_OF_SYNC */

#define MSK_SWD_TX_END_OF_SYNC                              (0x3)     /* [ 1:0] */

typedef unsigned short swd_tx_end_of_sync_t;                          /* [ 1:0] */


/* SWD_TIMEOUT_DISACK */

#define MSK_SWD_TIMEOUT_DISACK                              (0xffff)  /* [15:0] */

typedef unsigned short swd_timeout_disack_t;                          /* [15:0] */


/* SWD_COMM_CONFIG */

#define MSK_SWD_COMM_CONFIG_COMM_ENABLE                     (0x1)     /* [0] */
#define RES_SWD_COMM_CONFIG_COMM_ENABLE                     (0x0)
#define SFT_SWD_COMM_CONFIG_COMM_ENABLE                     (0)
#define LSB_SWD_COMM_CONFIG_COMM_ENABLE                     (0)
#define MSB_SWD_COMM_CONFIG_COMM_ENABLE                     (0)
#define BIT_SWD_COMM_CONFIG_COMM_ENABLE                     (0x1)     /* [0] */
#define MSK_SWD_COMM_CONFIG_RX_ENABLE                       (0x1)     /* [1] */
#define RES_SWD_COMM_CONFIG_RX_ENABLE                       (0x0)
#define SFT_SWD_COMM_CONFIG_RX_ENABLE                       (1)
#define LSB_SWD_COMM_CONFIG_RX_ENABLE                       (1)
#define MSB_SWD_COMM_CONFIG_RX_ENABLE                       (1)
#define BIT_SWD_COMM_CONFIG_RX_ENABLE                       (0x2)     /* [1] */
#define MSK_SWD_COMM_CONFIG_REPEATER_ENABLE                 (0x1)     /* [2] */
#define RES_SWD_COMM_CONFIG_REPEATER_ENABLE                 (0x0)
#define SFT_SWD_COMM_CONFIG_REPEATER_ENABLE                 (2)
#define LSB_SWD_COMM_CONFIG_REPEATER_ENABLE                 (2)
#define MSB_SWD_COMM_CONFIG_REPEATER_ENABLE                 (2)
#define BIT_SWD_COMM_CONFIG_REPEATER_ENABLE                 (0x4)     /* [2] */
#define MSK_SWD_COMM_CONFIG_BUS_SELECT                      (0x1)     /* [3] */
#define RES_SWD_COMM_CONFIG_BUS_SELECT                      (0x0)
#define SFT_SWD_COMM_CONFIG_BUS_SELECT                      (3)
#define LSB_SWD_COMM_CONFIG_BUS_SELECT                      (3)
#define MSB_SWD_COMM_CONFIG_BUS_SELECT                      (3)
#define BIT_SWD_COMM_CONFIG_BUS_SELECT                      (0x8)     /* [3] */
#define MSK_SWD_COMM_CONFIG_DISACK2_ENABLE                  (0x1)     /* [4] */
#define RES_SWD_COMM_CONFIG_DISACK2_ENABLE                  (0x0)
#define SFT_SWD_COMM_CONFIG_DISACK2_ENABLE                  (4)
#define LSB_SWD_COMM_CONFIG_DISACK2_ENABLE                  (4)
#define MSB_SWD_COMM_CONFIG_DISACK2_ENABLE                  (4)
#define BIT_SWD_COMM_CONFIG_DISACK2_ENABLE                  (0x10)    /* [4] */
#define MSK_SWD_COMM_CONFIG_VARIABLE_STATE_0                (0x1)     /* [5] */
#define RES_SWD_COMM_CONFIG_VARIABLE_STATE_0                (0x0)
#define SFT_SWD_COMM_CONFIG_VARIABLE_STATE_0                (5)
#define LSB_SWD_COMM_CONFIG_VARIABLE_STATE_0                (5)
#define MSB_SWD_COMM_CONFIG_VARIABLE_STATE_0                (5)
#define BIT_SWD_COMM_CONFIG_VARIABLE_STATE_0                (0x20)    /* [5] */
#define MSK_SWD_COMM_CONFIG_VARIABLE_STATE_1                (0x1)     /* [6] */
#define RES_SWD_COMM_CONFIG_VARIABLE_STATE_1                (0x0)
#define SFT_SWD_COMM_CONFIG_VARIABLE_STATE_1                (6)
#define LSB_SWD_COMM_CONFIG_VARIABLE_STATE_1                (6)
#define MSB_SWD_COMM_CONFIG_VARIABLE_STATE_1                (6)
#define BIT_SWD_COMM_CONFIG_VARIABLE_STATE_1                (0x40)    /* [6] */
#define MSK_SWD_COMM_CONFIG_REPEATER_DRIVE_IDLE             (0x1)     /* [7] */
#define RES_SWD_COMM_CONFIG_REPEATER_DRIVE_IDLE             (0x1)
#define SFT_SWD_COMM_CONFIG_REPEATER_DRIVE_IDLE             (7)
#define LSB_SWD_COMM_CONFIG_REPEATER_DRIVE_IDLE             (7)
#define MSB_SWD_COMM_CONFIG_REPEATER_DRIVE_IDLE             (7)
#define BIT_SWD_COMM_CONFIG_REPEATER_DRIVE_IDLE             (0x80)    /* [7] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD COMM_CONFIG
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 0: disabled and reset <br>
   * 1: Enabling filters <br>
   */ 
  unsigned short comm_enable                   :    1;       /* [0] */
  /**
   * 1: enable receiver
   */ 
  unsigned short rx_enable                     :    1;       /* [1] */
  /**
   * 1: repeater enabled
   */ 
  unsigned short repeater_enable               :    1;       /* [2] */
  /**
   * connection to DPLL, RX, Timeout, SelIn (selection of upstream bus)
   * 0: rxd0
   * 1: rxd1
   */ 
  unsigned short bus_select                    :    1;       /* [3] */
  /**
   * 1: enabled DisAck2 function
   */ 
  unsigned short disack2_enable                :    1;       /* [4] */
  /**
   * 1: enable variable idle state for bus 0
   */ 
  unsigned short variable_state_0              :    1;       /* [5] */
  /**
   * 1: enable variable idle state for bus 1
   */ 
  unsigned short variable_state_1              :    1;       /* [6] */
  /**
   * 0: downstream bus (bus_select) will be undriven when not repeating <br>
   * 1: drive downstream bus when repeater is idle (e.g. before SYNC) <br>
   */ 
  unsigned short repeater_drive_idle           :    1;       /* [7] */
  /**
   * 
   */ 
  unsigned short reserved                      :    8;
} swd_comm_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD COMM_CONFIG 
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_comm_config_bf bf;  ///< bit field representation
} swd_comm_config_t;


/* SWD_COMM_STATUS */

#define MSK_SWD_COMM_STATUS_IDLE_DPLL                       (0x1)     /* [0] */
#define RES_SWD_COMM_STATUS_IDLE_DPLL                       (0x0)
#define SFT_SWD_COMM_STATUS_IDLE_DPLL                       (0)
#define LSB_SWD_COMM_STATUS_IDLE_DPLL                       (0)
#define MSB_SWD_COMM_STATUS_IDLE_DPLL                       (0)
#define BIT_SWD_COMM_STATUS_IDLE_DPLL                       (0x1)     /* [0] */
#define MSK_SWD_COMM_STATUS_IDLE_PE                         (0x1)     /* [1] */
#define RES_SWD_COMM_STATUS_IDLE_PE                         (0x0)
#define SFT_SWD_COMM_STATUS_IDLE_PE                         (1)
#define LSB_SWD_COMM_STATUS_IDLE_PE                         (1)
#define MSB_SWD_COMM_STATUS_IDLE_PE                         (1)
#define BIT_SWD_COMM_STATUS_IDLE_PE                         (0x2)     /* [1] */
#define MSK_SWD_COMM_STATUS_DPLL_LOCKED                     (0x1)     /* [2] */
#define RES_SWD_COMM_STATUS_DPLL_LOCKED                     (0x0)
#define SFT_SWD_COMM_STATUS_DPLL_LOCKED                     (2)
#define LSB_SWD_COMM_STATUS_DPLL_LOCKED                     (2)
#define MSB_SWD_COMM_STATUS_DPLL_LOCKED                     (2)
#define BIT_SWD_COMM_STATUS_DPLL_LOCKED                     (0x4)     /* [2] */
#define MSK_SWD_COMM_STATUS_IDLE_DPLL_0                     (0x1)     /* [3] */
#define RES_SWD_COMM_STATUS_IDLE_DPLL_0                     (0x0)
#define SFT_SWD_COMM_STATUS_IDLE_DPLL_0                     (3)
#define LSB_SWD_COMM_STATUS_IDLE_DPLL_0                     (3)
#define MSB_SWD_COMM_STATUS_IDLE_DPLL_0                     (3)
#define BIT_SWD_COMM_STATUS_IDLE_DPLL_0                     (0x8)     /* [3] */
#define MSK_SWD_COMM_STATUS_IDLE_DPLL_1                     (0x1)     /* [4] */
#define RES_SWD_COMM_STATUS_IDLE_DPLL_1                     (0x0)
#define SFT_SWD_COMM_STATUS_IDLE_DPLL_1                     (4)
#define LSB_SWD_COMM_STATUS_IDLE_DPLL_1                     (4)
#define MSB_SWD_COMM_STATUS_IDLE_DPLL_1                     (4)
#define BIT_SWD_COMM_STATUS_IDLE_DPLL_1                     (0x10)    /* [4] */
#define MSK_SWD_COMM_STATUS_INT_DPLL_DATA_0                 (0x1)     /* [5] */
#define RES_SWD_COMM_STATUS_INT_DPLL_DATA_0                 (0x0)
#define SFT_SWD_COMM_STATUS_INT_DPLL_DATA_0                 (5)
#define LSB_SWD_COMM_STATUS_INT_DPLL_DATA_0                 (5)
#define MSB_SWD_COMM_STATUS_INT_DPLL_DATA_0                 (5)
#define BIT_SWD_COMM_STATUS_INT_DPLL_DATA_0                 (0x20)    /* [5] */
#define MSK_SWD_COMM_STATUS_INT_DPLL_DATA_1                 (0x1)     /* [6] */
#define RES_SWD_COMM_STATUS_INT_DPLL_DATA_1                 (0x0)
#define SFT_SWD_COMM_STATUS_INT_DPLL_DATA_1                 (6)
#define LSB_SWD_COMM_STATUS_INT_DPLL_DATA_1                 (6)
#define MSB_SWD_COMM_STATUS_INT_DPLL_DATA_1                 (6)
#define BIT_SWD_COMM_STATUS_INT_DPLL_DATA_1                 (0x40)    /* [6] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD COMM_STATUS
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: Idle threshold reached on selected bus (DPLL may lock)
   */ 
  unsigned short idle_dpll                     :    1;       /* [0] */
  /**
   * 1: Idle PE threshold reached on selected bus (coordinator may send)
   */ 
  unsigned short idle_pe                       :    1;       /* [1] */
  /**
   * 1: DPLL locked on selected bus (after SYNC detected)
   */ 
  unsigned short dpll_locked                   :    1;       /* [2] */
  /**
   * 1: Idle threshold reached on bus 0
   */ 
  unsigned short idle_dpll_0                   :    1;       /* [3] */
  /**
   * 1: Idle threshold reached on bus 1
   */ 
  unsigned short idle_dpll_1                   :    1;       /* [4] */
  /**
   * Output of DPLL Integrator on bus 0
   */ 
  unsigned short int_dpll_data_0               :    1;       /* [5] */
  /**
   * Output of DPLL Integrator on bus 1
   */ 
  unsigned short int_dpll_data_1               :    1;       /* [6] */
  /**
   * 
   */ 
  unsigned short reserved                      :    9;
} swd_comm_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD COMM_STATUS
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val; ///< word representation
  swd_comm_status_bf bf;  ///< bit field representation
} swd_comm_status_t;


/* SWD_SAP_SOURCE_STATUS */

#define MSK_SWD_SAP_SOURCE_STATUS_SOURCE_STATE              (0xff)    /* [ 7:0] */
#define RES_SWD_SAP_SOURCE_STATUS_SOURCE_STATE              (0x00)
#define SFT_SWD_SAP_SOURCE_STATUS_SOURCE_STATE              (0)
#define LSB_SWD_SAP_SOURCE_STATUS_SOURCE_STATE              (0)
#define MSB_SWD_SAP_SOURCE_STATUS_SOURCE_STATE              (7)
#define MSK_SWD_SAP_SOURCE_STATUS_SOURCE_IS_ADR             (0xff)    /* [15:8] */
#define RES_SWD_SAP_SOURCE_STATUS_SOURCE_IS_ADR             (0x00)
#define SFT_SWD_SAP_SOURCE_STATUS_SOURCE_IS_ADR             (8)
#define LSB_SWD_SAP_SOURCE_STATUS_SOURCE_IS_ADR             (8)
#define MSB_SWD_SAP_SOURCE_STATUS_SOURCE_IS_ADR             (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM SAP (Service Access Points) source status
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * SOURCE FSM STATE <br>
   * 000: NONE (no address recognized) <br>
   * 001: ALL (all addresses recognized) <br>
   * 010: FIXED (fixed address used) <br>
   * 011: LEARN (all addresses recognized, learning active) <br>
   * 111: LEARNED (learned address used) <br>
   */ 
  unsigned short source_state                  :    8;       /* [ 7:0] */
  /**
   * SOURCE address
   */ 
  unsigned short source_is_adr                 :    8;       /* [15:8] */
} swd_sap_source_status_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM SAP (Service Access Points) source status
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_sap_source_status_bf bf;  ///< bit field representation
} swd_sap_source_status_t;


/* SWD_SAP_SOURCE_COMMAND */

#define MSK_SWD_SAP_SOURCE_COMMAND_SOURCE_COMMAND           (0xff)    /* [ 7:0] */
#define RES_SWD_SAP_SOURCE_COMMAND_SOURCE_COMMAND           (0x00)
#define SFT_SWD_SAP_SOURCE_COMMAND_SOURCE_COMMAND           (0)
#define LSB_SWD_SAP_SOURCE_COMMAND_SOURCE_COMMAND           (0)
#define MSB_SWD_SAP_SOURCE_COMMAND_SOURCE_COMMAND           (7)
#define MSK_SWD_SAP_SOURCE_COMMAND_SOURCE_SET_ADR           (0xff)    /* [15:8] */
#define RES_SWD_SAP_SOURCE_COMMAND_SOURCE_SET_ADR           (0x00)
#define SFT_SWD_SAP_SOURCE_COMMAND_SOURCE_SET_ADR           (8)
#define LSB_SWD_SAP_SOURCE_COMMAND_SOURCE_SET_ADR           (8)
#define MSB_SWD_SAP_SOURCE_COMMAND_SOURCE_SET_ADR           (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM SAP (Service Access Points) source command
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * SOURCE FSM COMMAND
   * 000: FORCE_NONE (no address recognized)
   * 001: FORCE_ALL (all addresses recognized)
   * 010: FORCE_FIXED (fixed address used)
   * 011: FORCE_LEARN (all addresses recognized, learning active)
   * 100: CONDITIONAL_NONE (safe transition to NONE, may not be executed)
   * 111: CONDITIONAL_FIXED (safe transition to FIXED, may not be executed)
   */ 
  unsigned short source_command                :    8;       /* [ 7:0] */
  /**
   * SOURCE address
   */ 
  unsigned short source_set_adr                :    8;       /* [15:8] */
} swd_sap_source_command_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM SAP (Service Access Points) source command
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_sap_source_command_bf bf;  ///< bit field representation
} swd_sap_source_command_t;


/* SWD_DATA_LENGTH */

#define MSK_SWD_DATA_LENGTH                                 (0x1fff)  /* [12:0] */

typedef unsigned short swd_data_length_t;                             /* [12:0] */


/* SWD_PE_CONFIG_LW */

#define MSK_SWD_PE_CONFIG_LW_PE_ENABLE                      (0x1)     /* [0] */
#define RES_SWD_PE_CONFIG_LW_PE_ENABLE                      (0x0)
#define SFT_SWD_PE_CONFIG_LW_PE_ENABLE                      (0)
#define LSB_SWD_PE_CONFIG_LW_PE_ENABLE                      (0)
#define MSB_SWD_PE_CONFIG_LW_PE_ENABLE                      (0)
#define BIT_SWD_PE_CONFIG_LW_PE_ENABLE                      (0x1)     /* [0] */
#define MSK_SWD_PE_CONFIG_LW_PE_SYNC                        (0x1)     /* [1] */
#define RES_SWD_PE_CONFIG_LW_PE_SYNC                        (0x0)
#define SFT_SWD_PE_CONFIG_LW_PE_SYNC                        (1)
#define LSB_SWD_PE_CONFIG_LW_PE_SYNC                        (1)
#define MSB_SWD_PE_CONFIG_LW_PE_SYNC                        (1)
#define BIT_SWD_PE_CONFIG_LW_PE_SYNC                        (0x2)     /* [1] */
#define MSK_SWD_PE_CONFIG_LW_SDZ_ENABLE                     (0x1)     /* [2] */
#define RES_SWD_PE_CONFIG_LW_SDZ_ENABLE                     (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDZ_ENABLE                     (2)
#define LSB_SWD_PE_CONFIG_LW_SDZ_ENABLE                     (2)
#define MSB_SWD_PE_CONFIG_LW_SDZ_ENABLE                     (2)
#define BIT_SWD_PE_CONFIG_LW_SDZ_ENABLE                     (0x4)     /* [2] */
#define MSK_SWD_PE_CONFIG_LW_SDZ_NO_DISACK                  (0x1)     /* [3] */
#define RES_SWD_PE_CONFIG_LW_SDZ_NO_DISACK                  (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDZ_NO_DISACK                  (3)
#define LSB_SWD_PE_CONFIG_LW_SDZ_NO_DISACK                  (3)
#define MSB_SWD_PE_CONFIG_LW_SDZ_NO_DISACK                  (3)
#define BIT_SWD_PE_CONFIG_LW_SDZ_NO_DISACK                  (0x8)     /* [3] */
#define MSK_SWD_PE_CONFIG_LW_SDG_ENABLE                     (0x1)     /* [4] */
#define RES_SWD_PE_CONFIG_LW_SDG_ENABLE                     (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDG_ENABLE                     (4)
#define LSB_SWD_PE_CONFIG_LW_SDG_ENABLE                     (4)
#define MSB_SWD_PE_CONFIG_LW_SDG_ENABLE                     (4)
#define BIT_SWD_PE_CONFIG_LW_SDG_ENABLE                     (0x10)    /* [4] */
#define MSK_SWD_PE_CONFIG_LW_SDW_ENABLE                     (0x1)     /* [5] */
#define RES_SWD_PE_CONFIG_LW_SDW_ENABLE                     (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDW_ENABLE                     (5)
#define LSB_SWD_PE_CONFIG_LW_SDW_ENABLE                     (5)
#define MSB_SWD_PE_CONFIG_LW_SDW_ENABLE                     (5)
#define BIT_SWD_PE_CONFIG_LW_SDW_ENABLE                     (0x20)    /* [5] */
#define MSK_SWD_PE_CONFIG_LW_SDW_NO_DISACK                  (0x1)     /* [6] */
#define RES_SWD_PE_CONFIG_LW_SDW_NO_DISACK                  (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDW_NO_DISACK                  (6)
#define LSB_SWD_PE_CONFIG_LW_SDW_NO_DISACK                  (6)
#define MSB_SWD_PE_CONFIG_LW_SDW_NO_DISACK                  (6)
#define BIT_SWD_PE_CONFIG_LW_SDW_NO_DISACK                  (0x40)    /* [6] */
#define MSK_SWD_PE_CONFIG_LW_SDW_NO_CRC32                   (0x1)     /* [7] */
#define RES_SWD_PE_CONFIG_LW_SDW_NO_CRC32                   (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDW_NO_CRC32                   (7)
#define LSB_SWD_PE_CONFIG_LW_SDW_NO_CRC32                   (7)
#define MSB_SWD_PE_CONFIG_LW_SDW_NO_CRC32                   (7)
#define BIT_SWD_PE_CONFIG_LW_SDW_NO_CRC32                   (0x80)    /* [7] */
#define MSK_SWD_PE_CONFIG_LW_SDW_IGNORE_DISACK              (0x1)     /* [8] */
#define RES_SWD_PE_CONFIG_LW_SDW_IGNORE_DISACK              (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDW_IGNORE_DISACK              (8)
#define LSB_SWD_PE_CONFIG_LW_SDW_IGNORE_DISACK              (8)
#define MSB_SWD_PE_CONFIG_LW_SDW_IGNORE_DISACK              (8)
#define BIT_SWD_PE_CONFIG_LW_SDW_IGNORE_DISACK              (0x100)   /* [8] */
#define MSK_SWD_PE_CONFIG_LW_SDB_ENABLE                     (0x1)     /* [9] */
#define RES_SWD_PE_CONFIG_LW_SDB_ENABLE                     (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDB_ENABLE                     (9)
#define LSB_SWD_PE_CONFIG_LW_SDB_ENABLE                     (9)
#define MSB_SWD_PE_CONFIG_LW_SDB_ENABLE                     (9)
#define BIT_SWD_PE_CONFIG_LW_SDB_ENABLE                     (0x200)   /* [9] */
#define MSK_SWD_PE_CONFIG_LW_SDB_NO_DISACK                  (0x1)     /* [10] */
#define RES_SWD_PE_CONFIG_LW_SDB_NO_DISACK                  (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDB_NO_DISACK                  (10)
#define LSB_SWD_PE_CONFIG_LW_SDB_NO_DISACK                  (10)
#define MSB_SWD_PE_CONFIG_LW_SDB_NO_DISACK                  (10)
#define BIT_SWD_PE_CONFIG_LW_SDB_NO_DISACK                  (0x400)   /* [10] */
#define MSK_SWD_PE_CONFIG_LW_SDB_IGNORE_DISACK              (0x1)     /* [11] */
#define RES_SWD_PE_CONFIG_LW_SDB_IGNORE_DISACK              (0x0)
#define SFT_SWD_PE_CONFIG_LW_SDB_IGNORE_DISACK              (11)
#define LSB_SWD_PE_CONFIG_LW_SDB_IGNORE_DISACK              (11)
#define MSB_SWD_PE_CONFIG_LW_SDB_IGNORE_DISACK              (11)
#define BIT_SWD_PE_CONFIG_LW_SDB_IGNORE_DISACK              (0x800)   /* [11] */
#define MSK_SWD_PE_CONFIG_LW_CYC_TX_UPDATE                  (0x1)     /* [12] */
#define RES_SWD_PE_CONFIG_LW_CYC_TX_UPDATE                  (0x0)
#define SFT_SWD_PE_CONFIG_LW_CYC_TX_UPDATE                  (12)
#define LSB_SWD_PE_CONFIG_LW_CYC_TX_UPDATE                  (12)
#define MSB_SWD_PE_CONFIG_LW_CYC_TX_UPDATE                  (12)
#define BIT_SWD_PE_CONFIG_LW_CYC_TX_UPDATE                  (0x1000)  /* [12] */
#define MSK_SWD_PE_CONFIG_LW_CYC_SUCC_NO_RES                (0x1)     /* [13] */
#define RES_SWD_PE_CONFIG_LW_CYC_SUCC_NO_RES                (0x0)
#define SFT_SWD_PE_CONFIG_LW_CYC_SUCC_NO_RES                (13)
#define LSB_SWD_PE_CONFIG_LW_CYC_SUCC_NO_RES                (13)
#define MSB_SWD_PE_CONFIG_LW_CYC_SUCC_NO_RES                (13)
#define BIT_SWD_PE_CONFIG_LW_CYC_SUCC_NO_RES                (0x2000)  /* [13] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE Configuration and Status
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: enable decoding of frames and events, disabled is reset
   */ 
  unsigned short pe_enable                     :    1;       /* [0] */
  /**
   * 1: enable sync mode (cyclic frames started by HW sync input e.g. TSU)
   */ 
  unsigned short pe_sync                       :    1;       /* [1] */
  /**
   * 1: enable incoming cyclic transfer (crc32 DisAck and DMA channel open) <br>
   *    PE_CYC_WRITE_OFFSET and PE_CYC_WRITE_LENGTH have to be valid
   */ 
  unsigned short sdz_enable                    :    1;       /* [2] */
  /**
   * 1: send no disack when crc32 error detected in cyclic frame
   */ 
  unsigned short sdz_no_disack                 :    1;       /* [3] */
  /**
   * 1: enable reaction to incoming grants <br>
   * PE_GNT_SELF has to be valid
   */ 
  unsigned short sdg_enable                    :    1;       /* [4] */
  /**
   * 1: enable incoming acyclic transfers (crc32 DisAck and DMA channel open)
   */ 
  unsigned short sdw_enable                    :    1;       /* [5] */
  /**
   * 1: send no disack when crc32 error detected in acyclic write
   */ 
  unsigned short sdw_no_disack                 :    1;       /* [6] */
  /**
   * 1: do not send crc32 even if node is destination of uni cast
   */ 
  unsigned short sdw_no_crc32                  :    1;       /* [7] */
  /**
   * 1: ignore disack
   */ 
  unsigned short sdw_ignore_disack             :    1;       /* [8] */
  /**
   * 1: enable incoming broadcasts (crc32 DisAck and DMA channel open)
   */ 
  unsigned short sdb_enable                    :    1;       /* [9] */
  /**
   * 1: send no disack when crc32 error detected in acyclic broadcast
   */ 
  unsigned short sdb_no_disack                 :    1;       /* [10] */
  /**
   * 1: ignore disack
   */ 
  unsigned short sdb_ignore_disack             :    1;       /* [11] */
  /**
   * 1: always close CYC TX DMA channel, even when error (keeps data window up-to-date) <br>
   * Remark: When using �Reuse� Option the DMA Channel will not run empty, even with cyc_tx_update enabled
   */ 
  unsigned short cyc_tx_update                 :    1;       /* [12] */
  /**
   * generate no result event on successful receiving cyclic transfer
   */ 
  unsigned short cyc_succ_no_res               :    1;       /* [13] */
  /**
   * 
   */ 
  unsigned short reserved                      :    2;
} swd_pe_config_lw_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE Configuration and Status
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_pe_config_lw_bf bf;  ///< bit field representation
} swd_pe_config_lw_t;


/* SWD_PE_GNT_SELF */

#define MSK_SWD_PE_GNT_SELF                                 (0xff)    /* [ 7:0] */

typedef unsigned short swd_pe_gnt_self_t;                             /* [ 7:0] */


/* SWD_PE_CYC_WRITE_OFFSET */

#define MSK_SWD_PE_CYC_WRITE_OFFSET                         (0x7ff)   /* [10:0] */

typedef unsigned short swd_pe_cyc_write_offset_t;                     /* [10:0] */


/* SWD_PE_CYC_WRITE_LENGTH */

#define MSK_SWD_PE_CYC_WRITE_LENGTH                         (0x7ff)   /* [10:0] */

typedef unsigned short swd_pe_cyc_write_length_t;                     /* [10:0] */


/* SWD_PE_CYC_RX_CUT_START */

#define MSK_SWD_PE_CYC_RX_CUT_START                         (0x7ff)   /* [10:0] */

typedef unsigned short swd_pe_cyc_rx_cut_start_t;                     /* [10:0] */


/* SWD_PE_CYC_RX_CUT_LENGTH */

#define MSK_SWD_PE_CYC_RX_CUT_LENGTH                        (0x7ff)   /* [10:0] */

typedef unsigned short swd_pe_cyc_rx_cut_length_t;                    /* [10:0] */


/* SWD_STATUS_MASK_OFFSET */

#define MSK_SWD_STATUS_MASK_OFFSET_STAT_MASK                (0xff)    /* [ 7:0] */
#define RES_SWD_STATUS_MASK_OFFSET_STAT_MASK                (0x00)
#define SFT_SWD_STATUS_MASK_OFFSET_STAT_MASK                (0)
#define LSB_SWD_STATUS_MASK_OFFSET_STAT_MASK                (0)
#define MSB_SWD_STATUS_MASK_OFFSET_STAT_MASK                (7)
#define MSK_SWD_STATUS_MASK_OFFSET_STAT_OFFSET              (0xff)    /* [15:8] */
#define RES_SWD_STATUS_MASK_OFFSET_STAT_OFFSET              (0x00)
#define SFT_SWD_STATUS_MASK_OFFSET_STAT_OFFSET              (8)
#define LSB_SWD_STATUS_MASK_OFFSET_STAT_OFFSET              (8)
#define MSB_SWD_STATUS_MASK_OFFSET_STAT_OFFSET              (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM status mask
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * bit mask for status field, 1: sensitive to corresponding �1� bit in status byte
   */ 
  unsigned short stat_mask                     :    8;       /* [ 7:0] */
  /**
   * count offset (see description of status byte filtering)
   */ 
  unsigned short stat_offset                   :    8;       /* [15:8] */
} swd_status_mask_offset_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM status nodes
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_status_mask_offset_bf bf;  ///< bit field representation
} swd_status_mask_offset_t;


/* SWD_STATUS_COMMAND */

#define MSK_SWD_STATUS_COMMAND                              (0x1)     /* [0] */

typedef unsigned short swd_status_command_t;                          /* [0] */


/* SWD_STATUS_NODES */

#define MSK_SWD_STATUS_NODES_NODE_ID                        (0xff)    /* [ 7:0] */
#define RES_SWD_STATUS_NODES_NODE_ID                        (0x00)
#define SFT_SWD_STATUS_NODES_NODE_ID                        (0)
#define LSB_SWD_STATUS_NODES_NODE_ID                        (0)
#define MSB_SWD_STATUS_NODES_NODE_ID                        (7)
#define MSK_SWD_STATUS_NODES_VALID                          (0x1)     /* [8] */
#define RES_SWD_STATUS_NODES_VALID                          (0x0)
#define SFT_SWD_STATUS_NODES_VALID                          (8)
#define LSB_SWD_STATUS_NODES_VALID                          (8)
#define MSB_SWD_STATUS_NODES_VALID                          (8)
#define BIT_SWD_STATUS_NODES_VALID                          (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM status nodes
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * Node ID of Node with status byte set matching to given mask (e.g. acyclic request)
   */ 
  unsigned short node_id                       :    8;       /* [ 7:0] */
  /**
   * Node ID is valid
   */ 
  unsigned short valid                         :    1;       /* [8] */
  /**
   * 
   */ 
  unsigned short reserved                      :    7;
} swd_status_nodes_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM 
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_status_nodes_bf bf;  ///< bit field representation
} swd_status_nodes_t;


/* SWD_SAP_DESTINATION_ALL_EN */

#define MSK_SWD_SAP_DESTINATION_ALL_EN                      (0x1)     /* [0] */

typedef unsigned short swd_sap_destination_all_en_t;                  /* [0] */


/* SWD_SAP_DESTINATION_ADDR */

#define MSK_SWD_SAP_DESTINATION_ADDR_DEST_ADDR              (0xff)    /* [ 7:0] */
#define RES_SWD_SAP_DESTINATION_ADDR_DEST_ADDR              (0x00)
#define SFT_SWD_SAP_DESTINATION_ADDR_DEST_ADDR              (0)
#define LSB_SWD_SAP_DESTINATION_ADDR_DEST_ADDR              (0)
#define MSB_SWD_SAP_DESTINATION_ADDR_DEST_ADDR              (7)
#define MSK_SWD_SAP_DESTINATION_ADDR_EN                     (0x1)     /* [8] */
#define RES_SWD_SAP_DESTINATION_ADDR_EN                     (0x0)
#define SFT_SWD_SAP_DESTINATION_ADDR_EN                     (8)
#define LSB_SWD_SAP_DESTINATION_ADDR_EN                     (8)
#define MSB_SWD_SAP_DESTINATION_ADDR_EN                     (8)
#define BIT_SWD_SAP_DESTINATION_ADDR_EN                     (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM SAP (Service Access Points) destination address
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * destination address <br>
   * e.g. 0 is uni cast <br>
   * e.g. 1 is multiple cast group 0 <br>
   * e.g. 2 is multiple cast group 1 <br>
   * e.g. 3 is multiple cast group 2 <br>
   */ 
  unsigned short dest_addr                     :    8;       /* [ 7:0] */
  /**
   * enable
   */ 
  unsigned short en                            :    1;       /* [8] */
  /**
   * 
   */ 
  unsigned short reserved                      :    7;
} swd_sap_destination_addr_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM SAP (Service Access Points) destination address
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_sap_destination_addr_bf bf;  ///< bit field representation
} swd_sap_destination_addr_t;


/* SWD_SAP_SAP_FILTER */

#define MSK_SWD_SAP_SAP_FILTER_VALUE                        (0xf)     /* [ 3:0] */
#define RES_SWD_SAP_SAP_FILTER_VALUE                        (0x0)
#define SFT_SWD_SAP_SAP_FILTER_VALUE                        (0)
#define LSB_SWD_SAP_SAP_FILTER_VALUE                        (0)
#define MSB_SWD_SAP_SAP_FILTER_VALUE                        (3)
#define MSK_SWD_SAP_SAP_FILTER_MASK                         (0xf)     /* [ 7:4] */
#define RES_SWD_SAP_SAP_FILTER_MASK                         (0x0)
#define SFT_SWD_SAP_SAP_FILTER_MASK                         (4)
#define LSB_SWD_SAP_SAP_FILTER_MASK                         (4)
#define MSB_SWD_SAP_SAP_FILTER_MASK                         (7)
#define MSK_SWD_SAP_SAP_FILTER_INV_ALL                      (0x1)     /* [8] */
#define RES_SWD_SAP_SAP_FILTER_INV_ALL                      (0x0)
#define SFT_SWD_SAP_SAP_FILTER_INV_ALL                      (8)
#define LSB_SWD_SAP_SAP_FILTER_INV_ALL                      (8)
#define MSB_SWD_SAP_SAP_FILTER_INV_ALL                      (8)
#define BIT_SWD_SAP_SAP_FILTER_INV_ALL                      (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM SAP (Service Access Points) SAP filter
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * values for the first 4 LSB in SAP field of acyclic transfer sensitivity for
   * each bit can be enabled with sap_mask
   */ 
  unsigned short value                         :    4;       /* [ 3:0] */
  /**
   * enables sensitivity for first 4 LSB in SAP field of acyclic transfer
   * sap_mask[n] = 0: bit n is not evaluated (don�t care) sap_mask[n] = 1:
   * bit n is evaluated with sap_value
   */ 
  unsigned short mask                          :    4;       /* [ 7:4] */
  /**
   * 0: result of filter is: AND ((mask[n]=0) or (sap[n] = value[n]); n=0...3)
   * 1: result of filter is: not AND ((mask[n]=0) or (sap[n] = value[n]); n=0...3)
   */ 
  unsigned short inv_all                       :    1;       /* [8] */
  /**
   * 
   */ 
  unsigned short reserved                      :    7;
} swd_sap_sap_filter_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM SAP (Service Access Points) SAP filter 
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_sap_sap_filter_bf bf;  ///< bit field representation
} swd_sap_sap_filter_t;


/* SWD_DMA_CONFIG */

#define MSK_SWD_DMA_CONFIG_CYC_TRI                          (0x1)     /* [0] */
#define RES_SWD_DMA_CONFIG_CYC_TRI                          (0x0)
#define SFT_SWD_DMA_CONFIG_CYC_TRI                          (0)
#define LSB_SWD_DMA_CONFIG_CYC_TRI                          (0)
#define MSB_SWD_DMA_CONFIG_CYC_TRI                          (0)
#define BIT_SWD_DMA_CONFIG_CYC_TRI                          (0x1)     /* [0] */
#define MSK_SWD_DMA_CONFIG_CYC_TX_REUSE                     (0x1)     /* [1] */
#define RES_SWD_DMA_CONFIG_CYC_TX_REUSE                     (0x0)
#define SFT_SWD_DMA_CONFIG_CYC_TX_REUSE                     (1)
#define LSB_SWD_DMA_CONFIG_CYC_TX_REUSE                     (1)
#define MSB_SWD_DMA_CONFIG_CYC_TX_REUSE                     (1)
#define BIT_SWD_DMA_CONFIG_CYC_TX_REUSE                     (0x2)     /* [1] */
#define MSK_SWD_DMA_CONFIG_CYC_TX_REPLACE                   (0x1)     /* [2] */
#define RES_SWD_DMA_CONFIG_CYC_TX_REPLACE                   (0x0)
#define SFT_SWD_DMA_CONFIG_CYC_TX_REPLACE                   (2)
#define LSB_SWD_DMA_CONFIG_CYC_TX_REPLACE                   (2)
#define MSB_SWD_DMA_CONFIG_CYC_TX_REPLACE                   (2)
#define BIT_SWD_DMA_CONFIG_CYC_TX_REPLACE                   (0x4)     /* [2] */
#define MSK_SWD_DMA_CONFIG_TRF_MAX_BURST                    (0x3)     /* [ 4:3] */
#define RES_SWD_DMA_CONFIG_TRF_MAX_BURST                    (0x3)
#define SFT_SWD_DMA_CONFIG_TRF_MAX_BURST                    (3)
#define LSB_SWD_DMA_CONFIG_TRF_MAX_BURST                    (3)
#define MSB_SWD_DMA_CONFIG_TRF_MAX_BURST                    (4)
#define MSK_SWD_DMA_CONFIG_TRF_MIN_BREAK                    (0x3)     /* [ 6:5] */
#define RES_SWD_DMA_CONFIG_TRF_MIN_BREAK                    (0x0)
#define SFT_SWD_DMA_CONFIG_TRF_MIN_BREAK                    (5)
#define LSB_SWD_DMA_CONFIG_TRF_MIN_BREAK                    (5)
#define MSB_SWD_DMA_CONFIG_TRF_MIN_BREAK                    (6)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA configuration
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 0: use Double Buffer Mode for CYC RX Channel
   * 1: use TriBuffer Mode for CYC RX Channel
   */ 
  unsigned short cyc_tri                       :    1;       /* [0] */
  /**
   * 0: reuse for Pointer FIFO of CYC TX Channel disabled, last <br>
   *    remaining Pointer will be removed <br>
   * 1: reuse for Pointer FIFO of CYC TX Channel enabled, last <br>
   *    remaining Pointer will be reused <br>
   */ 
  unsigned short cyc_tx_reuse                  :    1;       /* [1] */
  /**
   * 0: replacing of last written Pointer for CYC TX Channel disabled, new Pointers will be ignored
   * 1: replacing of last written Pointer for CYC TX Channel enabled, new Pointers will replace last written one
   */ 
  unsigned short cyc_tx_replace                :    1;       /* [2] */
  /**
   * maximum transfer length (maximum length = trf_max_burst+1)
   */ 
  unsigned short trf_max_burst                 :    2;       /* [ 4:3] */
  /**
   * minimum transfer break when maximum transfer done (0 = no break)
   */ 
  unsigned short trf_min_break                 :    2;       /* [ 6:5] */
  /**
   * 
   */ 
  unsigned short reserved                      :    9;
} swd_dma_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA configuration
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dma_config_bf bf;  ///< bit field representation
} swd_dma_config_t;


/* SWD_DMA_COMMAND */

#define MSK_SWD_DMA_COMMAND_DMA_RESETS                      (0x7f)    /* [ 6:0] */
#define RES_SWD_DMA_COMMAND_DMA_RESETS                      (0x00)
#define SFT_SWD_DMA_COMMAND_DMA_RESETS                      (0)
#define LSB_SWD_DMA_COMMAND_DMA_RESETS                      (0)
#define MSB_SWD_DMA_COMMAND_DMA_RESETS                      (6)
#define MSK_SWD_DMA_COMMAND_AZY_TX_REMOVE                   (0x1)     /* [7] */
#define RES_SWD_DMA_COMMAND_AZY_TX_REMOVE                   (0x0)
#define SFT_SWD_DMA_COMMAND_AZY_TX_REMOVE                   (7)
#define LSB_SWD_DMA_COMMAND_AZY_TX_REMOVE                   (7)
#define MSB_SWD_DMA_COMMAND_AZY_TX_REMOVE                   (7)
#define BIT_SWD_DMA_COMMAND_AZY_TX_REMOVE                   (0x80)    /* [7] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA commands
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: reset and clear complete (NEXT and LAST) DMA virtual channel pointer FIFO <br>
   * bit 0: VCHANNEL_SIZES <br>
   * bit 1: VCHANNEL_CYC_TX <br>
   * bit 2: VCHANNEL_CYC_RX <br>
   * bit 3: VCHANNEL_AZY_TX <br>
   * bit 4: VCHANNEL_AZY_RX_SAPA <br>
   * bit 5: VCHANNEL_AZY_RX_SAPB <br>
   * bit 6: VCHANNEL_AZY_RX_SAPC <br>
   */ 
  unsigned short dma_resets                    :    7;       /* [ 6:0] */
  /**
   * Safe remove acyclic transmit pointer (only when not used)
   */ 
  unsigned short azy_tx_remove                 :    1;       /* [7] */
  /**
   * 
   */ 
  unsigned short reserved                      :    8;
} swd_dma_command_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA commands
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dma_command_bf bf;  ///< bit field representation
} swd_dma_command_t;


/* SWD_DMA_SIZE */

#define MSK_SWD_DMA_SIZE_NOT_USED                           (0x1)     /* [0] */
#define RES_SWD_DMA_SIZE_NOT_USED                           (0x0)
#define SFT_SWD_DMA_SIZE_NOT_USED                           (0)
#define LSB_SWD_DMA_SIZE_NOT_USED                           (0)
#define MSB_SWD_DMA_SIZE_NOT_USED                           (0)
#define BIT_SWD_DMA_SIZE_NOT_USED                           (0x1)     /* [0] */
#define MSK_SWD_DMA_SIZE_WINDOW_SIZE                        (0x7fff)  /* [15:1] */
#define RES_SWD_DMA_SIZE_WINDOW_SIZE                        (0x0000)
#define SFT_SWD_DMA_SIZE_WINDOW_SIZE                        (1)
#define LSB_SWD_DMA_SIZE_WINDOW_SIZE                        (1)
#define MSB_SWD_DMA_SIZE_WINDOW_SIZE                        (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA RX size
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * read as 0
   */ 
  unsigned short not_used                      :    1;       /* [0] */
  /**
   * maximum window size in words
   */ 
  unsigned short window_size                   :   15;       /* [15:1] */
} swd_dma_size_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA RX size
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dma_size_bf bf;  ///< bit field representation
} swd_dma_size_t;


/* SWD_DMA_NEXT_PTR */

#define MSK_SWD_DMA_NEXT_PTR_NOT_USED                       (0x1)     /* [0] */
#define RES_SWD_DMA_NEXT_PTR_NOT_USED                       (0x0)
#define SFT_SWD_DMA_NEXT_PTR_NOT_USED                       (0)
#define LSB_SWD_DMA_NEXT_PTR_NOT_USED                       (0)
#define MSB_SWD_DMA_NEXT_PTR_NOT_USED                       (0)
#define BIT_SWD_DMA_NEXT_PTR_NOT_USED                       (0x1)     /* [0] */
#define MSK_SWD_DMA_NEXT_PTR_DMA_PTR                        (0x7fff)  /* [15:1] */
#define RES_SWD_DMA_NEXT_PTR_DMA_PTR                        (0x0000)
#define SFT_SWD_DMA_NEXT_PTR_DMA_PTR                        (1)
#define LSB_SWD_DMA_NEXT_PTR_DMA_PTR                        (1)
#define MSB_SWD_DMA_NEXT_PTR_DMA_PTR                        (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * ignored
   */ 
  unsigned short not_used                      :    1;       /* [0] */
  /**
   * next pointer in words to by used by PM for frame window FIFO
   */ 
  unsigned short dma_ptr                       :   15;       /* [15:1] */
} swd_dma_next_ptr_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of 
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dma_next_ptr_bf bf;  ///< bit field representation
} swd_dma_next_ptr_t;


/* SWD_DMA_LAST_PTR */

#define MSK_SWD_DMA_LAST_PTR_VALID                          (0x1)     /* [0] */
#define RES_SWD_DMA_LAST_PTR_VALID                          (0x0)
#define SFT_SWD_DMA_LAST_PTR_VALID                          (0)
#define LSB_SWD_DMA_LAST_PTR_VALID                          (0)
#define MSB_SWD_DMA_LAST_PTR_VALID                          (0)
#define BIT_SWD_DMA_LAST_PTR_VALID                          (0x1)     /* [0] */
#define MSK_SWD_DMA_LAST_PTR_DMA_PTR                        (0x7fff)  /* [15:1] */
#define RES_SWD_DMA_LAST_PTR_DMA_PTR                        (0x0000)
#define SFT_SWD_DMA_LAST_PTR_DMA_PTR                        (1)
#define LSB_SWD_DMA_LAST_PTR_DMA_PTR                        (1)
#define MSB_SWD_DMA_LAST_PTR_DMA_PTR                        (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA last pointer
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: pointer is valid (FIFO was not empty)
   */ 
  unsigned short valid                         :    1;       /* [0] */
  /**
   * last used pointer in words from frame pointer FIFO
   */ 
  unsigned short dma_ptr                       :   15;       /* [15:1] */
} swd_dma_last_ptr_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA last pointer
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dma_last_ptr_bf bf;  ///< bit field representation
} swd_dma_last_ptr_t;


/* SWD_DMA_REPLACED_PTR */

#define MSK_SWD_DMA_REPLACED_PTR_VALID                      (0x1)     /* [0] */
#define RES_SWD_DMA_REPLACED_PTR_VALID                      (0x0)
#define SFT_SWD_DMA_REPLACED_PTR_VALID                      (0)
#define LSB_SWD_DMA_REPLACED_PTR_VALID                      (0)
#define MSB_SWD_DMA_REPLACED_PTR_VALID                      (0)
#define BIT_SWD_DMA_REPLACED_PTR_VALID                      (0x1)     /* [0] */
#define MSK_SWD_DMA_REPLACED_PTR_DMA_PTR                    (0x7fff)  /* [15:1] */
#define RES_SWD_DMA_REPLACED_PTR_DMA_PTR                    (0x0000)
#define SFT_SWD_DMA_REPLACED_PTR_DMA_PTR                    (1)
#define LSB_SWD_DMA_REPLACED_PTR_DMA_PTR                    (1)
#define MSB_SWD_DMA_REPLACED_PTR_DMA_PTR                    (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA replaced pointer
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: pointer is valid (Pointer was replaced)
   */ 
  unsigned short valid                         :    1;       /* [0] */
  /**
   * replaced pointer when next pointer was written to full CYC TX FIFO
   * and �Replace� Option was enabled
   */ 
  unsigned short dma_ptr                       :   15;       /* [15:1] */
} swd_dma_replaced_ptr_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA replaced pointer
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dma_replaced_ptr_bf bf;  ///< bit field representation
} swd_dma_replaced_ptr_t;


/* SWD_DMA_AZY_TX_REMOVED_PTR */

#define MSK_SWD_DMA_AZY_TX_REMOVED_PTR_VALID                (0x1)     /* [0] */
#define RES_SWD_DMA_AZY_TX_REMOVED_PTR_VALID                (0x0)
#define SFT_SWD_DMA_AZY_TX_REMOVED_PTR_VALID                (0)
#define LSB_SWD_DMA_AZY_TX_REMOVED_PTR_VALID                (0)
#define MSB_SWD_DMA_AZY_TX_REMOVED_PTR_VALID                (0)
#define BIT_SWD_DMA_AZY_TX_REMOVED_PTR_VALID                (0x1)     /* [0] */
#define MSK_SWD_DMA_AZY_TX_REMOVED_PTR_DMA_PTR              (0x7fff)  /* [15:1] */
#define RES_SWD_DMA_AZY_TX_REMOVED_PTR_DMA_PTR              (0x0000)
#define SFT_SWD_DMA_AZY_TX_REMOVED_PTR_DMA_PTR              (1)
#define LSB_SWD_DMA_AZY_TX_REMOVED_PTR_DMA_PTR              (1)
#define MSB_SWD_DMA_AZY_TX_REMOVED_PTR_DMA_PTR              (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA removed pointer
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: pointer is valid (Pointer was replaced)
   */ 
  unsigned short valid                         :    1;       /* [0] */
  /**
   * removed pointer after remove command
   */ 
  unsigned short dma_ptr                       :   15;       /* [15:1] */
} swd_dma_azy_tx_removed_ptr_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA removed pointer
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dma_azy_tx_removed_ptr_bf bf;  ///< bit field representation
} swd_dma_azy_tx_removed_ptr_t;


/* SWD_DMA_ERRORS */

#define MSK_SWD_DMA_ERRORS_EVT_SIZES_ACCESS_ERR             (0x1)     /* [0] */
#define RES_SWD_DMA_ERRORS_EVT_SIZES_ACCESS_ERR             (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_SIZES_ACCESS_ERR             (0)
#define LSB_SWD_DMA_ERRORS_EVT_SIZES_ACCESS_ERR             (0)
#define MSB_SWD_DMA_ERRORS_EVT_SIZES_ACCESS_ERR             (0)
#define BIT_SWD_DMA_ERRORS_EVT_SIZES_ACCESS_ERR             (0x1)     /* [0] */
#define MSK_SWD_DMA_ERRORS_EVT_CYC_TX_ACCESS_ERR            (0x1)     /* [1] */
#define RES_SWD_DMA_ERRORS_EVT_CYC_TX_ACCESS_ERR            (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_CYC_TX_ACCESS_ERR            (1)
#define LSB_SWD_DMA_ERRORS_EVT_CYC_TX_ACCESS_ERR            (1)
#define MSB_SWD_DMA_ERRORS_EVT_CYC_TX_ACCESS_ERR            (1)
#define BIT_SWD_DMA_ERRORS_EVT_CYC_TX_ACCESS_ERR            (0x2)     /* [1] */
#define MSK_SWD_DMA_ERRORS_EVT_CYC_RX_ACCESS_ERR            (0x1)     /* [2] */
#define RES_SWD_DMA_ERRORS_EVT_CYC_RX_ACCESS_ERR            (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_CYC_RX_ACCESS_ERR            (2)
#define LSB_SWD_DMA_ERRORS_EVT_CYC_RX_ACCESS_ERR            (2)
#define MSB_SWD_DMA_ERRORS_EVT_CYC_RX_ACCESS_ERR            (2)
#define BIT_SWD_DMA_ERRORS_EVT_CYC_RX_ACCESS_ERR            (0x4)     /* [2] */
#define MSK_SWD_DMA_ERRORS_EVT_AZY_TX_ACCESS_ERR            (0x1)     /* [3] */
#define RES_SWD_DMA_ERRORS_EVT_AZY_TX_ACCESS_ERR            (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_AZY_TX_ACCESS_ERR            (3)
#define LSB_SWD_DMA_ERRORS_EVT_AZY_TX_ACCESS_ERR            (3)
#define MSB_SWD_DMA_ERRORS_EVT_AZY_TX_ACCESS_ERR            (3)
#define BIT_SWD_DMA_ERRORS_EVT_AZY_TX_ACCESS_ERR            (0x8)     /* [3] */
#define MSK_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_ACCESS_ERR       (0x1)     /* [4] */
#define RES_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_ACCESS_ERR       (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_ACCESS_ERR       (4)
#define LSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_ACCESS_ERR       (4)
#define MSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_ACCESS_ERR       (4)
#define BIT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_ACCESS_ERR       (0x10)    /* [4] */
#define MSK_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_ACCESS_ERR       (0x1)     /* [5] */
#define RES_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_ACCESS_ERR       (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_ACCESS_ERR       (5)
#define LSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_ACCESS_ERR       (5)
#define MSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_ACCESS_ERR       (5)
#define BIT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_ACCESS_ERR       (0x20)    /* [5] */
#define MSK_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_ACCESS_ERR       (0x1)     /* [6] */
#define RES_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_ACCESS_ERR       (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_ACCESS_ERR       (6)
#define LSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_ACCESS_ERR       (6)
#define MSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_ACCESS_ERR       (6)
#define BIT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_ACCESS_ERR       (0x40)    /* [6] */
#define MSK_SWD_DMA_ERRORS_EVT_CYC_RX_SIZE_ERR              (0x1)     /* [7] */
#define RES_SWD_DMA_ERRORS_EVT_CYC_RX_SIZE_ERR              (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_CYC_RX_SIZE_ERR              (7)
#define LSB_SWD_DMA_ERRORS_EVT_CYC_RX_SIZE_ERR              (7)
#define MSB_SWD_DMA_ERRORS_EVT_CYC_RX_SIZE_ERR              (7)
#define BIT_SWD_DMA_ERRORS_EVT_CYC_RX_SIZE_ERR              (0x80)    /* [7] */
#define MSK_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_SIZE_ERR         (0x1)     /* [8] */
#define RES_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_SIZE_ERR         (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_SIZE_ERR         (8)
#define LSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_SIZE_ERR         (8)
#define MSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_SIZE_ERR         (8)
#define BIT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPA_SIZE_ERR         (0x100)   /* [8] */
#define MSK_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_SIZE_ERR         (0x1)     /* [9] */
#define RES_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_SIZE_ERR         (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_SIZE_ERR         (9)
#define LSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_SIZE_ERR         (9)
#define MSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_SIZE_ERR         (9)
#define BIT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPB_SIZE_ERR         (0x200)   /* [9] */
#define MSK_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_SIZE_ERR         (0x1)     /* [10] */
#define RES_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_SIZE_ERR         (0x0)
#define SFT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_SIZE_ERR         (10)
#define LSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_SIZE_ERR         (10)
#define MSB_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_SIZE_ERR         (10)
#define BIT_SWD_DMA_ERRORS_EVT_AZY_RX_SAPC_SIZE_ERR         (0x400)   /* [10] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA errors
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * error in DMA Pointer FIFO (either next empty or last full)
   */ 
  unsigned short evt_sizes_access_err          :    1;       /* [0] */
  /**
   * error in DMA Pointer FIFO (either next empty or last full)
   */ 
  unsigned short evt_cyc_tx_access_err         :    1;       /* [1] */
  /**
   * error in DMA Pointer FIFO (either next empty or last full)
   */ 
  unsigned short evt_cyc_rx_access_err         :    1;       /* [2] */
  /**
   * error in DMA Pointer FIFO (either next empty or last full)
   */ 
  unsigned short evt_azy_tx_access_err         :    1;       /* [3] */
  /**
   * error in DMA Pointer FIFO (either next empty or last full)
   */ 
  unsigned short evt_azy_rx_sapa_access_err    :    1;       /* [4] */
  /**
   * error in DMA Pointer FIFO (either next empty or last full)
   */ 
  unsigned short evt_azy_rx_sapb_access_err    :    1;       /* [5] */
  /**
   * error in DMA Pointer FIFO (either next empty or last full)
   */ 
  unsigned short evt_azy_rx_sapc_access_err    :    1;       /* [6] */
  /**
   * error in DMA RX sub channel
   */ 
  unsigned short evt_cyc_rx_size_err           :    1;       /* [7] */
  /**
   * error in DMA RX sub channel
   */ 
  unsigned short evt_azy_rx_sapa_size_err      :    1;       /* [8] */
  /**
   * error in DMA RX sub channel
   */ 
  unsigned short evt_azy_rx_sapb_size_err      :    1;       /* [9] */
  /**
   * error in DMA RX sub channel
   */ 
  unsigned short evt_azy_rx_sapc_size_err      :    1;       /* [10] */
  /**
   * 
   */ 
  unsigned short reserved                      :    5;
} swd_dma_errors_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM DMA errors
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_dma_errors_bf bf;  ///< bit field representation
} swd_dma_errors_t;


/* SWD_PE_COMMAND */

#define MSK_SWD_PE_COMMAND_COMMAND                          (0x3)     /* [ 1:0] */
#define RES_SWD_PE_COMMAND_COMMAND                          (0x0)
#define SFT_SWD_PE_COMMAND_COMMAND                          (0)
#define LSB_SWD_PE_COMMAND_COMMAND                          (0)
#define MSB_SWD_PE_COMMAND_COMMAND                          (1)
#define MSK_SWD_PE_COMMAND_USER_TAG                         (0x7)     /* [ 4:2] */
#define RES_SWD_PE_COMMAND_USER_TAG                         (0x0)
#define SFT_SWD_PE_COMMAND_USER_TAG                         (2)
#define LSB_SWD_PE_COMMAND_USER_TAG                         (2)
#define MSB_SWD_PE_COMMAND_USER_TAG                         (4)
#define MSK_SWD_PE_COMMAND_PARAM                            (0xff)    /* [12:5] */
#define RES_SWD_PE_COMMAND_PARAM                            (0x00)
#define SFT_SWD_PE_COMMAND_PARAM                            (5)
#define LSB_SWD_PE_COMMAND_PARAM                            (5)
#define MSB_SWD_PE_COMMAND_PARAM                            (12)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM  PE Command
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * only for coordinator! <br>
   * 01: start cyclic transfer <br>
   * 10: start grant for start acyclic transfer <br>
   */ 
  unsigned short command                       :    2;       /* [ 1:0] */
  /**
   * user command tag. will be visible in results register when finished
   */ 
  unsigned short user_tag                      :    3;       /* [ 4:2] */
  /**
   * pe_command = 01: no meaning <br>
   * pe_command = 10: initiator node which is allowed to start cyclic transfer <br>
   */ 
  unsigned short param                         :    8;       /* [12:5] */
  /**
   * 
   */ 
  unsigned short reserved                      :    3;
} swd_pe_command_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM  PE Command
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_pe_command_bf bf;  ///< bit field representation
} swd_pe_command_t;


/* SWD_PE_CYC_FRAME_LENGTH */

#define MSK_SWD_PE_CYC_FRAME_LENGTH                         (0x7ff)   /* [10:0] */

typedef unsigned short swd_pe_cyc_frame_length_t;                     /* [10:0] */


/* SWD_PE_CYC_TIMEOUT_ID */

#define MSK_SWD_PE_CYC_TIMEOUT_ID_SIZES_ENTRY_ID            (0xff)    /* [ 7:0] */
#define RES_SWD_PE_CYC_TIMEOUT_ID_SIZES_ENTRY_ID            (0x00)
#define SFT_SWD_PE_CYC_TIMEOUT_ID_SIZES_ENTRY_ID            (0)
#define LSB_SWD_PE_CYC_TIMEOUT_ID_SIZES_ENTRY_ID            (0)
#define MSB_SWD_PE_CYC_TIMEOUT_ID_SIZES_ENTRY_ID            (7)
#define MSK_SWD_PE_CYC_TIMEOUT_ID_VALID                     (0x1)     /* [8] */
#define RES_SWD_PE_CYC_TIMEOUT_ID_VALID                     (0x0)
#define SFT_SWD_PE_CYC_TIMEOUT_ID_VALID                     (8)
#define LSB_SWD_PE_CYC_TIMEOUT_ID_VALID                     (8)
#define MSB_SWD_PE_CYC_TIMEOUT_ID_VALID                     (8)
#define BIT_SWD_PE_CYC_TIMEOUT_ID_VALID                     (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE cyclic timeout ID
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * when timeout during cyclic transfer, register contains write length ID
   * of last received node
   */ 
  unsigned short sizes_entry_id                :    8;       /* [ 7:0] */
  /**
   * Value becomes valid after a timeout during cyclic transfer and stays
   * valid until reading this register
   */ 
  unsigned short valid                         :    1;       /* [8] */
  /**
   * 
   */ 
  unsigned short reserved                      :    7;
} swd_pe_cyc_timeout_id_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE cyclic timeout ID
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_pe_cyc_timeout_id_bf bf;  ///< bit field representation
} swd_pe_cyc_timeout_id_t;


/* SWD_PE_CYC_NOT_REPLACED_ID */

#define MSK_SWD_PE_CYC_NOT_REPLACED_ID_SIZES_ENTRY_ID       (0xff)    /* [ 7:0] */
#define RES_SWD_PE_CYC_NOT_REPLACED_ID_SIZES_ENTRY_ID       (0x00)
#define SFT_SWD_PE_CYC_NOT_REPLACED_ID_SIZES_ENTRY_ID       (0)
#define LSB_SWD_PE_CYC_NOT_REPLACED_ID_SIZES_ENTRY_ID       (0)
#define MSB_SWD_PE_CYC_NOT_REPLACED_ID_SIZES_ENTRY_ID       (7)
#define MSK_SWD_PE_CYC_NOT_REPLACED_ID_VALID                (0x1)     /* [8] */
#define RES_SWD_PE_CYC_NOT_REPLACED_ID_VALID                (0x0)
#define SFT_SWD_PE_CYC_NOT_REPLACED_ID_VALID                (8)
#define LSB_SWD_PE_CYC_NOT_REPLACED_ID_VALID                (8)
#define MSB_SWD_PE_CYC_NOT_REPLACED_ID_VALID                (8)
#define BIT_SWD_PE_CYC_NOT_REPLACED_ID_VALID                (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE cyclick not replaced ID
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * when nodes should be replaced during cyclic transfer: <br>
   * register contains write length ID of first not replaced node, that was
   * expected to be replaced
   */ 
  unsigned short sizes_entry_id                :    8;       /* [ 7:0] */
  /**
   * Value becomes valid with first not replaced node during cyclic
   * transfer and stays valid until reading this register
   */ 
  unsigned short valid                         :    1;       /* [8] */
  /**
   * 
   */ 
  unsigned short reserved                      :    7;
} swd_pe_cyc_not_replaced_id_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE cyclick not replaced ID
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_pe_cyc_not_replaced_id_bf bf;  ///< bit field representation
} swd_pe_cyc_not_replaced_id_t;


/* SWD_PE_RESULT */

#define MSK_SWD_PE_RESULT_VALID                             (0x1)     /* [0] */
#define RES_SWD_PE_RESULT_VALID                             (0x0)
#define SFT_SWD_PE_RESULT_VALID                             (0)
#define LSB_SWD_PE_RESULT_VALID                             (0)
#define MSB_SWD_PE_RESULT_VALID                             (0)
#define BIT_SWD_PE_RESULT_VALID                             (0x1)     /* [0] */
#define MSK_SWD_PE_RESULT_WAS_KOO                           (0x1)     /* [1] */
#define RES_SWD_PE_RESULT_WAS_KOO                           (0x0)
#define SFT_SWD_PE_RESULT_WAS_KOO                           (1)
#define LSB_SWD_PE_RESULT_WAS_KOO                           (1)
#define MSB_SWD_PE_RESULT_WAS_KOO                           (1)
#define BIT_SWD_PE_RESULT_WAS_KOO                           (0x2)     /* [1] */
#define MSK_SWD_PE_RESULT_WAS_INI                           (0x1)     /* [2] */
#define RES_SWD_PE_RESULT_WAS_INI                           (0x0)
#define SFT_SWD_PE_RESULT_WAS_INI                           (2)
#define LSB_SWD_PE_RESULT_WAS_INI                           (2)
#define MSB_SWD_PE_RESULT_WAS_INI                           (2)
#define BIT_SWD_PE_RESULT_WAS_INI                           (0x4)     /* [2] */
#define MSK_SWD_PE_RESULT_WAS_DST                           (0x1)     /* [3] */
#define RES_SWD_PE_RESULT_WAS_DST                           (0x0)
#define SFT_SWD_PE_RESULT_WAS_DST                           (3)
#define LSB_SWD_PE_RESULT_WAS_DST                           (3)
#define MSB_SWD_PE_RESULT_WAS_DST                           (3)
#define BIT_SWD_PE_RESULT_WAS_DST                           (0x8)     /* [3] */
#define MSK_SWD_PE_RESULT_USER_TAG                          (0x7)     /* [ 6:4] */
#define RES_SWD_PE_RESULT_USER_TAG                          (0x0)
#define SFT_SWD_PE_RESULT_USER_TAG                          (4)
#define LSB_SWD_PE_RESULT_USER_TAG                          (4)
#define MSB_SWD_PE_RESULT_USER_TAG                          (6)
#define MSK_SWD_PE_RESULT_TRANSFER_TYPE                     (0x3)     /* [ 8:7] */
#define RES_SWD_PE_RESULT_TRANSFER_TYPE                     (0x0)
#define SFT_SWD_PE_RESULT_TRANSFER_TYPE                     (7)
#define LSB_SWD_PE_RESULT_TRANSFER_TYPE                     (7)
#define MSB_SWD_PE_RESULT_TRANSFER_TYPE                     (8)
#define MSK_SWD_PE_RESULT_RESULT                            (0x7f)    /* [15:9] */
#define RES_SWD_PE_RESULT_RESULT                            (0x00)
#define SFT_SWD_PE_RESULT_RESULT                            (9)
#define LSB_SWD_PE_RESULT_RESULT                            (9)
#define MSB_SWD_PE_RESULT_RESULT                            (15)


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE result
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * Result FIFO is not empty
   */ 
  unsigned short valid                         :    1;       /* [0] */
  /**
   * frame was started by this node
   */ 
  unsigned short was_koo                       :    1;       /* [1] */
  /**
   * this node was initiator of acyclic transfer
   * (with transfer type = 00 or transfer type = 11)
   */ 
  unsigned short was_ini                       :    1;       /* [2] */
  /**
   * this node was destination of acyclic transfer
   * (with transfer type = 11)
   */ 
  unsigned short was_dst                       :    1;       /* [3] */
  /**
   * user command tag
   * (only valid with result type = 01)
   */ 
  unsigned short user_tag                      :    3;       /* [ 6:4] */
  /**
   * 00: no transfer <br>
   * 01: cyclic transfer <br>
   * 10: grant transfer <br>
   * 11: acyclic transfer <br>
   */ 
  unsigned short transfer_type                 :    2;       /* [ 8:7] */
  /**
   * 01: SUCCESS (transfer successful) <br>
   * 02: START_ERR (start-bit error) <br>
   * 03: STOP_ERR (stop-bit error) <br>
   * 04: READBACK_DATA_ERR (data readback error) <br>
   * 05: RX_TIMEOUT (receive timeout) <br>
   * 06: CRC8_ERR (CRC8 header error) <br>
   * 07: CRC32_ERR (CRC32 frame error) <br>
   * 08: DMA_ERR (DMA error (see DMA_ERRORS) <br>
   * 09: DISACK (DisAck detected, but no error detected) <br>
   * 10: GRANT_ERR (Grant error, only with transfer_type = 10) <br>
   * 11: SDN_ERR (SDN error, with transfer type = 00 or 11)) <br>
   * 12: TAKEOVER_ERR (Takeover error) <br>
   * 13: SPEED_ERR (resync speed error) <br>
   * 14: READBACK_DISACK_ERR (disack readback error) <br>
   * 15: NOT_IDLE (not idle error) <br>
   * 16: DISACK2 (DisAck2 detected, but no error detected) <br>
   * 17: READBACK_REPEAT_ERR (repeat readback error) <br>
   * 18: READBACK_NO_RX_ERR (readback error because of no rx data) <br>
   */ 
  unsigned short result                        :    7;       /* [15:9] */
} swd_pe_result_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE result
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_pe_result_bf bf;  ///< bit field representation
} swd_pe_result_t;


/* SWD_PE_CYC_SUCC_RES_CNT */

#define MSK_SWD_PE_CYC_SUCC_RES_CNT                         (0xf)     /* [ 3:0] */

typedef unsigned short swd_pe_cyc_succ_res_cnt_t;                     /* [ 3:0] */


/* SWD_EVENTS */

#define MSK_SWD_EVENTS_EVT_RESTART                          (0x1)     /* [0] */
#define RES_SWD_EVENTS_EVT_RESTART                          (0x0)
#define SFT_SWD_EVENTS_EVT_RESTART                          (0)
#define LSB_SWD_EVENTS_EVT_RESTART                          (0)
#define MSB_SWD_EVENTS_EVT_RESTART                          (0)
#define BIT_SWD_EVENTS_EVT_RESTART                          (0x1)     /* [0] */
#define MSK_SWD_EVENTS_EVT_CYC_STARTED                      (0x1)     /* [1] */
#define RES_SWD_EVENTS_EVT_CYC_STARTED                      (0x0)
#define SFT_SWD_EVENTS_EVT_CYC_STARTED                      (1)
#define LSB_SWD_EVENTS_EVT_CYC_STARTED                      (1)
#define MSB_SWD_EVENTS_EVT_CYC_STARTED                      (1)
#define BIT_SWD_EVENTS_EVT_CYC_STARTED                      (0x2)     /* [1] */
#define MSK_SWD_EVENTS_EVT_GNT_STARTED                      (0x1)     /* [2] */
#define RES_SWD_EVENTS_EVT_GNT_STARTED                      (0x0)
#define SFT_SWD_EVENTS_EVT_GNT_STARTED                      (2)
#define LSB_SWD_EVENTS_EVT_GNT_STARTED                      (2)
#define MSB_SWD_EVENTS_EVT_GNT_STARTED                      (2)
#define BIT_SWD_EVENTS_EVT_GNT_STARTED                      (0x4)     /* [2] */
#define MSK_SWD_EVENTS_EVT_DPLL_IDLE_0                      (0x1)     /* [3] */
#define RES_SWD_EVENTS_EVT_DPLL_IDLE_0                      (0x0)
#define SFT_SWD_EVENTS_EVT_DPLL_IDLE_0                      (3)
#define LSB_SWD_EVENTS_EVT_DPLL_IDLE_0                      (3)
#define MSB_SWD_EVENTS_EVT_DPLL_IDLE_0                      (3)
#define BIT_SWD_EVENTS_EVT_DPLL_IDLE_0                      (0x8)     /* [3] */
#define MSK_SWD_EVENTS_EVT_DPLL_IDLE_1                      (0x1)     /* [4] */
#define RES_SWD_EVENTS_EVT_DPLL_IDLE_1                      (0x0)
#define SFT_SWD_EVENTS_EVT_DPLL_IDLE_1                      (4)
#define LSB_SWD_EVENTS_EVT_DPLL_IDLE_1                      (4)
#define MSB_SWD_EVENTS_EVT_DPLL_IDLE_1                      (4)
#define BIT_SWD_EVENTS_EVT_DPLL_IDLE_1                      (0x10)    /* [4] */
#define MSK_SWD_EVENTS_EVT_DPLL_LOCKED_0                    (0x1)     /* [5] */
#define RES_SWD_EVENTS_EVT_DPLL_LOCKED_0                    (0x0)
#define SFT_SWD_EVENTS_EVT_DPLL_LOCKED_0                    (5)
#define LSB_SWD_EVENTS_EVT_DPLL_LOCKED_0                    (5)
#define MSB_SWD_EVENTS_EVT_DPLL_LOCKED_0                    (5)
#define BIT_SWD_EVENTS_EVT_DPLL_LOCKED_0                    (0x20)    /* [5] */
#define MSK_SWD_EVENTS_EVT_DPLL_LOCKED_1                    (0x1)     /* [6] */
#define RES_SWD_EVENTS_EVT_DPLL_LOCKED_1                    (0x0)
#define SFT_SWD_EVENTS_EVT_DPLL_LOCKED_1                    (6)
#define LSB_SWD_EVENTS_EVT_DPLL_LOCKED_1                    (6)
#define MSB_SWD_EVENTS_EVT_DPLL_LOCKED_1                    (6)
#define BIT_SWD_EVENTS_EVT_DPLL_LOCKED_1                    (0x40)    /* [6] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Events
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * PE was restarted by DPLL lock
   */ 
  unsigned short evt_restart                   :    1;       /* [0] */
  /**
   * start of cyclic frame (after successful CRC8)
   */ 
  unsigned short evt_cyc_started               :    1;       /* [1] */
  /**
   * start of acyclic frame with grant (after successful CRC8)
   */ 
  unsigned short evt_gnt_started               :    1;       /* [2] */
  /**
   * bus0: became idle
   */ 
  unsigned short evt_dpll_idle_0               :    1;       /* [3] */
  /**
   * bus1: became idle
   */ 
  unsigned short evt_dpll_idle_1               :    1;       /* [4] */
  /**
   * bus0: DLL has locked (equal to restart)
   */ 
  unsigned short evt_dpll_locked_0             :    1;       /* [5] */
  /**
   * bus1: DLL has locked (equal to restart)
   */ 
  unsigned short evt_dpll_locked_1             :    1;       /* [6] */
  /**
   * 
   */ 
  unsigned short reserved                      :    9;
} swd_events_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Events
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_events_bf bf;  ///< bit field representation
} swd_events_t;


/* SWD_IRQ_STATUS_PE */

#define MSK_SWD_IRQ_STATUS_PE_EVT_RESTART                   (0x1)     /* [0] */
#define RES_SWD_IRQ_STATUS_PE_EVT_RESTART                   (0x0)
#define SFT_SWD_IRQ_STATUS_PE_EVT_RESTART                   (0)
#define LSB_SWD_IRQ_STATUS_PE_EVT_RESTART                   (0)
#define MSB_SWD_IRQ_STATUS_PE_EVT_RESTART                   (0)
#define BIT_SWD_IRQ_STATUS_PE_EVT_RESTART                   (0x1)     /* [0] */
#define MSK_SWD_IRQ_STATUS_PE_EVT_CYC_STARTED               (0x1)     /* [1] */
#define RES_SWD_IRQ_STATUS_PE_EVT_CYC_STARTED               (0x0)
#define SFT_SWD_IRQ_STATUS_PE_EVT_CYC_STARTED               (1)
#define LSB_SWD_IRQ_STATUS_PE_EVT_CYC_STARTED               (1)
#define MSB_SWD_IRQ_STATUS_PE_EVT_CYC_STARTED               (1)
#define BIT_SWD_IRQ_STATUS_PE_EVT_CYC_STARTED               (0x2)     /* [1] */
#define MSK_SWD_IRQ_STATUS_PE_EVT_GNT_STARTED               (0x1)     /* [2] */
#define RES_SWD_IRQ_STATUS_PE_EVT_GNT_STARTED               (0x0)
#define SFT_SWD_IRQ_STATUS_PE_EVT_GNT_STARTED               (2)
#define LSB_SWD_IRQ_STATUS_PE_EVT_GNT_STARTED               (2)
#define MSB_SWD_IRQ_STATUS_PE_EVT_GNT_STARTED               (2)
#define BIT_SWD_IRQ_STATUS_PE_EVT_GNT_STARTED               (0x4)     /* [2] */
#define MSK_SWD_IRQ_STATUS_PE_RESULT_NEMPTY                 (0x1)     /* [3] */
#define RES_SWD_IRQ_STATUS_PE_RESULT_NEMPTY                 (0x0)
#define SFT_SWD_IRQ_STATUS_PE_RESULT_NEMPTY                 (3)
#define LSB_SWD_IRQ_STATUS_PE_RESULT_NEMPTY                 (3)
#define MSB_SWD_IRQ_STATUS_PE_RESULT_NEMPTY                 (3)
#define BIT_SWD_IRQ_STATUS_PE_RESULT_NEMPTY                 (0x8)     /* [3] */
#define MSK_SWD_IRQ_STATUS_PE_STATUS1_REQ                   (0x1)     /* [4] */
#define RES_SWD_IRQ_STATUS_PE_STATUS1_REQ                   (0x0)
#define SFT_SWD_IRQ_STATUS_PE_STATUS1_REQ                   (4)
#define LSB_SWD_IRQ_STATUS_PE_STATUS1_REQ                   (4)
#define MSB_SWD_IRQ_STATUS_PE_STATUS1_REQ                   (4)
#define BIT_SWD_IRQ_STATUS_PE_STATUS1_REQ                   (0x10)    /* [4] */
#define MSK_SWD_IRQ_STATUS_PE_CYC_RES_CNT_ZERO              (0x1)     /* [5] */
#define RES_SWD_IRQ_STATUS_PE_CYC_RES_CNT_ZERO              (0x1)
#define SFT_SWD_IRQ_STATUS_PE_CYC_RES_CNT_ZERO              (5)
#define LSB_SWD_IRQ_STATUS_PE_CYC_RES_CNT_ZERO              (5)
#define MSB_SWD_IRQ_STATUS_PE_CYC_RES_CNT_ZERO              (5)
#define BIT_SWD_IRQ_STATUS_PE_CYC_RES_CNT_ZERO              (0x20)    /* [5] */
#define MSK_SWD_IRQ_STATUS_PE_NOT_REPLACED_NEMPTY           (0x1)     /* [6] */
#define RES_SWD_IRQ_STATUS_PE_NOT_REPLACED_NEMPTY           (0x0)
#define SFT_SWD_IRQ_STATUS_PE_NOT_REPLACED_NEMPTY           (6)
#define LSB_SWD_IRQ_STATUS_PE_NOT_REPLACED_NEMPTY           (6)
#define MSB_SWD_IRQ_STATUS_PE_NOT_REPLACED_NEMPTY           (6)
#define BIT_SWD_IRQ_STATUS_PE_NOT_REPLACED_NEMPTY           (0x40)    /* [6] */
#define MSK_SWD_IRQ_STATUS_PE_STATUS2_REQ                   (0x1)     /* [7] */
#define RES_SWD_IRQ_STATUS_PE_STATUS2_REQ                   (0x0)
#define SFT_SWD_IRQ_STATUS_PE_STATUS2_REQ                   (7)
#define LSB_SWD_IRQ_STATUS_PE_STATUS2_REQ                   (7)
#define MSB_SWD_IRQ_STATUS_PE_STATUS2_REQ                   (7)
#define BIT_SWD_IRQ_STATUS_PE_STATUS2_REQ                   (0x80)    /* [7] */
#define MSK_SWD_IRQ_STATUS_PE_DEC_IDLE                      (0x1)     /* [8] */
#define RES_SWD_IRQ_STATUS_PE_DEC_IDLE                      (0x1)
#define SFT_SWD_IRQ_STATUS_PE_DEC_IDLE                      (8)
#define LSB_SWD_IRQ_STATUS_PE_DEC_IDLE                      (8)
#define MSB_SWD_IRQ_STATUS_PE_DEC_IDLE                      (8)
#define BIT_SWD_IRQ_STATUS_PE_DEC_IDLE                      (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Status PE
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * see corresponding event
   */ 
  unsigned short evt_restart                   :    1;       /* [0] */
  /**
   * see corresponding event
   */ 
  unsigned short evt_cyc_started               :    1;       /* [1] */
  /**
   * see corresponding event
   */ 
  unsigned short evt_gnt_started               :    1;       /* [2] */
  /**
   * result FIFO not empty
   */ 
  unsigned short result_nempty                 :    1;       /* [3] */
  /**
   * Status1 Module captured at least one request, e.g. acyclic transfer request
   */ 
  unsigned short status1_req                   :    1;       /* [4] */
  /**
   * Cyclic Successful Result Counter is zero
   */ 
  unsigned short cyc_res_cnt_zero              :    1;       /* [5] */
  /**
   * Not replaced node ID available
   */ 
  unsigned short not_replaced_nempty           :    1;       /* [6] */
  /**
   * Status2 Module captured at least one request, e.g. real-time not valid event
   */ 
  unsigned short status2_req                   :    1;       /* [7] */
  /**
   * Decoder Idle (waiting for SYNC preamble)
   */ 
  unsigned short dec_idle                      :    1;       /* [8] */
  /**
   * 
   */ 
  unsigned short reserved                      :    7;
} swd_irq_status_pe_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Status PE
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_irq_status_pe_bf bf;  ///< bit field representation
} swd_irq_status_pe_t;


/* SWD_IRQ_STATUS_DMA */

#define MSK_SWD_IRQ_STATUS_DMA_SIZES_NEXT_NFULL             (0x1)     /* [0] */
#define RES_SWD_IRQ_STATUS_DMA_SIZES_NEXT_NFULL             (0x1)
#define SFT_SWD_IRQ_STATUS_DMA_SIZES_NEXT_NFULL             (0)
#define LSB_SWD_IRQ_STATUS_DMA_SIZES_NEXT_NFULL             (0)
#define MSB_SWD_IRQ_STATUS_DMA_SIZES_NEXT_NFULL             (0)
#define BIT_SWD_IRQ_STATUS_DMA_SIZES_NEXT_NFULL             (0x1)     /* [0] */
#define MSK_SWD_IRQ_STATUS_DMA_SIZES_LAST_NEMPTY            (0x1)     /* [1] */
#define RES_SWD_IRQ_STATUS_DMA_SIZES_LAST_NEMPTY            (0x0)
#define SFT_SWD_IRQ_STATUS_DMA_SIZES_LAST_NEMPTY            (1)
#define LSB_SWD_IRQ_STATUS_DMA_SIZES_LAST_NEMPTY            (1)
#define MSB_SWD_IRQ_STATUS_DMA_SIZES_LAST_NEMPTY            (1)
#define BIT_SWD_IRQ_STATUS_DMA_SIZES_LAST_NEMPTY            (0x2)     /* [1] */
#define MSK_SWD_IRQ_STATUS_DMA_CYC_TX_NEXT_NFULL            (0x1)     /* [2] */
#define RES_SWD_IRQ_STATUS_DMA_CYC_TX_NEXT_NFULL            (0x1)
#define SFT_SWD_IRQ_STATUS_DMA_CYC_TX_NEXT_NFULL            (2)
#define LSB_SWD_IRQ_STATUS_DMA_CYC_TX_NEXT_NFULL            (2)
#define MSB_SWD_IRQ_STATUS_DMA_CYC_TX_NEXT_NFULL            (2)
#define BIT_SWD_IRQ_STATUS_DMA_CYC_TX_NEXT_NFULL            (0x4)     /* [2] */
#define MSK_SWD_IRQ_STATUS_DMA_CYC_TX_LAST_NEMPTY           (0x1)     /* [3] */
#define RES_SWD_IRQ_STATUS_DMA_CYC_TX_LAST_NEMPTY           (0x0)
#define SFT_SWD_IRQ_STATUS_DMA_CYC_TX_LAST_NEMPTY           (3)
#define LSB_SWD_IRQ_STATUS_DMA_CYC_TX_LAST_NEMPTY           (3)
#define MSB_SWD_IRQ_STATUS_DMA_CYC_TX_LAST_NEMPTY           (3)
#define BIT_SWD_IRQ_STATUS_DMA_CYC_TX_LAST_NEMPTY           (0x8)     /* [3] */
#define MSK_SWD_IRQ_STATUS_DMA_CYC_RX_NEXT_NFULL            (0x1)     /* [4] */
#define RES_SWD_IRQ_STATUS_DMA_CYC_RX_NEXT_NFULL            (0x1)
#define SFT_SWD_IRQ_STATUS_DMA_CYC_RX_NEXT_NFULL            (4)
#define LSB_SWD_IRQ_STATUS_DMA_CYC_RX_NEXT_NFULL            (4)
#define MSB_SWD_IRQ_STATUS_DMA_CYC_RX_NEXT_NFULL            (4)
#define BIT_SWD_IRQ_STATUS_DMA_CYC_RX_NEXT_NFULL            (0x10)    /* [4] */
#define MSK_SWD_IRQ_STATUS_DMA_CYC_RX_LAST_NEMPTY           (0x1)     /* [5] */
#define RES_SWD_IRQ_STATUS_DMA_CYC_RX_LAST_NEMPTY           (0x0)
#define SFT_SWD_IRQ_STATUS_DMA_CYC_RX_LAST_NEMPTY           (5)
#define LSB_SWD_IRQ_STATUS_DMA_CYC_RX_LAST_NEMPTY           (5)
#define MSB_SWD_IRQ_STATUS_DMA_CYC_RX_LAST_NEMPTY           (5)
#define BIT_SWD_IRQ_STATUS_DMA_CYC_RX_LAST_NEMPTY           (0x20)    /* [5] */
#define MSK_SWD_IRQ_STATUS_DMA_AZY_TX_NEXT_NFULL            (0x1)     /* [6] */
#define RES_SWD_IRQ_STATUS_DMA_AZY_TX_NEXT_NFULL            (0x1)
#define SFT_SWD_IRQ_STATUS_DMA_AZY_TX_NEXT_NFULL            (6)
#define LSB_SWD_IRQ_STATUS_DMA_AZY_TX_NEXT_NFULL            (6)
#define MSB_SWD_IRQ_STATUS_DMA_AZY_TX_NEXT_NFULL            (6)
#define BIT_SWD_IRQ_STATUS_DMA_AZY_TX_NEXT_NFULL            (0x40)    /* [6] */
#define MSK_SWD_IRQ_STATUS_DMA_AZY_TX_LAST_NEMPTY           (0x1)     /* [7] */
#define RES_SWD_IRQ_STATUS_DMA_AZY_TX_LAST_NEMPTY           (0x0)
#define SFT_SWD_IRQ_STATUS_DMA_AZY_TX_LAST_NEMPTY           (7)
#define LSB_SWD_IRQ_STATUS_DMA_AZY_TX_LAST_NEMPTY           (7)
#define MSB_SWD_IRQ_STATUS_DMA_AZY_TX_LAST_NEMPTY           (7)
#define BIT_SWD_IRQ_STATUS_DMA_AZY_TX_LAST_NEMPTY           (0x80)    /* [7] */
#define MSK_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_NEXT_NFULL       (0x1)     /* [8] */
#define RES_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_NEXT_NFULL       (0x1)
#define SFT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_NEXT_NFULL       (8)
#define LSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_NEXT_NFULL       (8)
#define MSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_NEXT_NFULL       (8)
#define BIT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_NEXT_NFULL       (0x100)   /* [8] */
#define MSK_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_LAST_NEMPTY      (0x1)     /* [9] */
#define RES_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_LAST_NEMPTY      (0x0)
#define SFT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_LAST_NEMPTY      (9)
#define LSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_LAST_NEMPTY      (9)
#define MSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_LAST_NEMPTY      (9)
#define BIT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPA_LAST_NEMPTY      (0x200)   /* [9] */
#define MSK_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_NEXT_NFULL       (0x1)     /* [10] */
#define RES_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_NEXT_NFULL       (0x1)
#define SFT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_NEXT_NFULL       (10)
#define LSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_NEXT_NFULL       (10)
#define MSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_NEXT_NFULL       (10)
#define BIT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_NEXT_NFULL       (0x400)   /* [10] */
#define MSK_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_LAST_NEMPTY      (0x1)     /* [11] */
#define RES_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_LAST_NEMPTY      (0x0)
#define SFT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_LAST_NEMPTY      (11)
#define LSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_LAST_NEMPTY      (11)
#define MSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_LAST_NEMPTY      (11)
#define BIT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPB_LAST_NEMPTY      (0x800)   /* [11] */
#define MSK_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_NEXT_NFULL       (0x1)     /* [12] */
#define RES_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_NEXT_NFULL       (0x1)
#define SFT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_NEXT_NFULL       (12)
#define LSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_NEXT_NFULL       (12)
#define MSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_NEXT_NFULL       (12)
#define BIT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_NEXT_NFULL       (0x1000)  /* [12] */
#define MSK_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_LAST_NEMPTY      (0x1)     /* [13] */
#define RES_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_LAST_NEMPTY      (0x0)
#define SFT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_LAST_NEMPTY      (13)
#define LSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_LAST_NEMPTY      (13)
#define MSB_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_LAST_NEMPTY      (13)
#define BIT_SWD_IRQ_STATUS_DMA_AZY_RX_SAPC_LAST_NEMPTY      (0x2000)  /* [13] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM IRQ status DMA
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * VCHANNEL_SIZES next Pointer FIFO not full
   */ 
  unsigned short sizes_next_nfull              :    1;       /* [0] */
  /**
   * VCHANNEL_SIZES last Pointer FIFO not empty
   */ 
  unsigned short sizes_last_nempty             :    1;       /* [1] */
  /**
   * VCHANNEL_CYC_TX next Pointer FIFO not full
   */ 
  unsigned short cyc_tx_next_nfull             :    1;       /* [2] */
  /**
   * VCHANNEL_CYC_TX last Pointer FIFO not empty
   */ 
  unsigned short cyc_tx_last_nempty            :    1;       /* [3] */
  /**
   * VCHANNEL_CYC_RX next Pointer FIFO not full
   */ 
  unsigned short cyc_rx_next_nfull             :    1;       /* [4] */
  /**
   * VCHANNEL_CYC_RX last Pointer FIFO not empty
   */ 
  unsigned short cyc_rx_last_nempty            :    1;       /* [5] */
  /**
   * VCHANNEL_AZY_TX next Pointer FIFO not full
   */ 
  unsigned short azy_tx_next_nfull             :    1;       /* [6] */
  /**
   * VCHANNEL_AZY_TX last Pointer FIFO not empty
   */ 
  unsigned short azy_tx_last_nempty            :    1;       /* [7] */
  /**
   * VCHANNEL_AZY_RX_SAPA next Pointer FIFO not full
   */ 
  unsigned short azy_rx_sapa_next_nfull        :    1;       /* [8] */
  /**
   * VCHANNEL_AZY_RX_SAPA last Pointer FIFO not empty
   */ 
  unsigned short azy_rx_sapa_last_nempty       :    1;       /* [9] */
  /**
   * VCHANNEL_AZY_RX_SAPB next Pointer FIFO not full
   */ 
  unsigned short azy_rx_sapb_next_nfull        :    1;       /* [10] */
  /**
   * VCHANNEL_AZY_RX_SAPB last Pointer FIFO not empty
   */ 
  unsigned short azy_rx_sapb_last_nempty       :    1;       /* [11] */
  /**
   * VCHANNEL_AZY_RX_SAPC next Pointer FIFO not full
   */ 
  unsigned short azy_rx_sapc_next_nfull        :    1;       /* [12] */
  /**
   * VCHANNEL_AZY_RX_SAPC last Pointer FIFO not empty
   */ 
  unsigned short azy_rx_sapc_last_nempty       :    1;       /* [13] */
  /**
   * 
   */ 
  unsigned short reserved                      :    2;
} swd_irq_status_dma_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM IRQ status DMA
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_irq_status_dma_bf bf;  ///< bit field representation
} swd_irq_status_dma_t;


/* SWD_IRQ_MASK_PE */

#define MSK_SWD_IRQ_MASK_PE                                 (0xffff)  /* [15:0] */

typedef unsigned short swd_irq_mask_pe_t;                             /* [15:0] */


/* SWD_IRQ_MASK_DMA */

#define MSK_SWD_IRQ_MASK_DMA                                (0xffff)  /* [15:0] */

typedef unsigned short swd_irq_mask_dma_t;                            /* [15:0] */


/* SWD_IRQ_NO */

#define MSK_SWD_IRQ_NO                                      (0x7f)    /* [ 6:0] */

typedef unsigned short swd_irq_no_t;                                  /* [ 6:0] */


/* SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW */

#define MSK_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW      (0xffff)  /* [15:0] */

typedef unsigned short swd_idle_disack2_detect_start_threshold_lw_t;       /* [15:0] */


/* SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW */

#define MSK_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW      (0xff)    /* [ 7:0] */

typedef unsigned short swd_idle_disack2_detect_start_threshold_hw_t;       /* [ 7:0] */


/* SWD_INTEGRATOR_DISACK2_THRESHOLD */

#define MSK_SWD_INTEGRATOR_DISACK2_THRESHOLD                (0xffff)  /* [15:0] */

typedef unsigned short swd_integrator_disack2_threshold_t;            /* [15:0] */


/* SWD_IDLE_DPLL_THRESHOLD_HW */

#define MSK_SWD_IDLE_DPLL_THRESHOLD_HW                      (0xff)    /* [ 7:0] */

typedef unsigned short swd_idle_dpll_threshold_hw_t;                  /* [ 7:0] */


/* SWD_IDLE_PE_THRESHOLD_HW */

#define MSK_SWD_IDLE_PE_THRESHOLD_HW                        (0xff)    /* [ 7:0] */

typedef unsigned short swd_idle_pe_threshold_hw_t;                    /* [ 7:0] */


/* SWD_IDLE_DISACK2_SEND_THRESHOLD_LW */

#define MSK_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW              (0xffff)  /* [15:0] */

typedef unsigned short swd_idle_disack2_send_threshold_lw_t;          /* [15:0] */


/* SWD_IDLE_DISACK2_SEND_THRESHOLD_HW */

#define MSK_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW              (0xff)    /* [ 7:0] */

typedef unsigned short swd_idle_disack2_send_threshold_hw_t;          /* [ 7:0] */


/* SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW */

#define MSK_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW        (0xffff)  /* [15:0] */

typedef unsigned short swd_idle_disack2_detect_end_threshold_lw_t;       /* [15:0] */


/* SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW */

#define MSK_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW        (0xff)    /* [ 7:0] */

typedef unsigned short swd_idle_disack2_detect_end_threshold_hw_t;       /* [ 7:0] */


/* SWD_TAKEOVER_DATA */

#define MSK_SWD_TAKEOVER_DATA                               (0xffff)  /* [15:0] */

typedef unsigned short swd_takeover_data_t;                           /* [15:0] */


/* SWD_TAKEOVER_DISACK */

#define MSK_SWD_TAKEOVER_DISACK                             (0xffff)  /* [15:0] */

typedef unsigned short swd_takeover_disack_t;                         /* [15:0] */


/* SWD_TX_DISACK2_LENGTH */

#define MSK_SWD_TX_DISACK2_LENGTH                           (0xff)    /* [ 7:0] */

typedef unsigned short swd_tx_disack2_length_t;                       /* [ 7:0] */


/* SWD_PE_CONFIG_HW */

#define MSK_SWD_PE_CONFIG_HW_SDW_ALL_DISACK                 (0x1)     /* [0] */
#define RES_SWD_PE_CONFIG_HW_SDW_ALL_DISACK                 (0x1)
#define SFT_SWD_PE_CONFIG_HW_SDW_ALL_DISACK                 (0)
#define LSB_SWD_PE_CONFIG_HW_SDW_ALL_DISACK                 (0)
#define MSB_SWD_PE_CONFIG_HW_SDW_ALL_DISACK                 (0)
#define BIT_SWD_PE_CONFIG_HW_SDW_ALL_DISACK                 (0x1)     /* [0] */
#define MSK_SWD_PE_CONFIG_HW_SDB_ALL_DISACK                 (0x1)     /* [1] */
#define RES_SWD_PE_CONFIG_HW_SDB_ALL_DISACK                 (0x1)
#define SFT_SWD_PE_CONFIG_HW_SDB_ALL_DISACK                 (1)
#define LSB_SWD_PE_CONFIG_HW_SDB_ALL_DISACK                 (1)
#define MSB_SWD_PE_CONFIG_HW_SDB_ALL_DISACK                 (1)
#define BIT_SWD_PE_CONFIG_HW_SDB_ALL_DISACK                 (0x2)     /* [1] */
#define MSK_SWD_PE_CONFIG_HW_SDZ_NO_DISACK2                 (0x1)     /* [2] */
#define RES_SWD_PE_CONFIG_HW_SDZ_NO_DISACK2                 (0x0)
#define SFT_SWD_PE_CONFIG_HW_SDZ_NO_DISACK2                 (2)
#define LSB_SWD_PE_CONFIG_HW_SDZ_NO_DISACK2                 (2)
#define MSB_SWD_PE_CONFIG_HW_SDZ_NO_DISACK2                 (2)
#define BIT_SWD_PE_CONFIG_HW_SDZ_NO_DISACK2                 (0x4)     /* [2] */
#define MSK_SWD_PE_CONFIG_HW_SDZ_IGNORE_DISACK2             (0x1)     /* [3] */
#define RES_SWD_PE_CONFIG_HW_SDZ_IGNORE_DISACK2             (0x0)
#define SFT_SWD_PE_CONFIG_HW_SDZ_IGNORE_DISACK2             (3)
#define LSB_SWD_PE_CONFIG_HW_SDZ_IGNORE_DISACK2             (3)
#define MSB_SWD_PE_CONFIG_HW_SDZ_IGNORE_DISACK2             (3)
#define BIT_SWD_PE_CONFIG_HW_SDZ_IGNORE_DISACK2             (0x8)     /* [3] */
#define MSK_SWD_PE_CONFIG_HW_SDW_NO_DISACK2                 (0x1)     /* [4] */
#define RES_SWD_PE_CONFIG_HW_SDW_NO_DISACK2                 (0x0)
#define SFT_SWD_PE_CONFIG_HW_SDW_NO_DISACK2                 (4)
#define LSB_SWD_PE_CONFIG_HW_SDW_NO_DISACK2                 (4)
#define MSB_SWD_PE_CONFIG_HW_SDW_NO_DISACK2                 (4)
#define BIT_SWD_PE_CONFIG_HW_SDW_NO_DISACK2                 (0x10)    /* [4] */
#define MSK_SWD_PE_CONFIG_HW_SDW_IGNORE_DISACK2             (0x1)     /* [5] */
#define RES_SWD_PE_CONFIG_HW_SDW_IGNORE_DISACK2             (0x0)
#define SFT_SWD_PE_CONFIG_HW_SDW_IGNORE_DISACK2             (5)
#define LSB_SWD_PE_CONFIG_HW_SDW_IGNORE_DISACK2             (5)
#define MSB_SWD_PE_CONFIG_HW_SDW_IGNORE_DISACK2             (5)
#define BIT_SWD_PE_CONFIG_HW_SDW_IGNORE_DISACK2             (0x20)    /* [5] */
#define MSK_SWD_PE_CONFIG_HW_SDB_NO_DISACK2                 (0x1)     /* [6] */
#define RES_SWD_PE_CONFIG_HW_SDB_NO_DISACK2                 (0x0)
#define SFT_SWD_PE_CONFIG_HW_SDB_NO_DISACK2                 (6)
#define LSB_SWD_PE_CONFIG_HW_SDB_NO_DISACK2                 (6)
#define MSB_SWD_PE_CONFIG_HW_SDB_NO_DISACK2                 (6)
#define BIT_SWD_PE_CONFIG_HW_SDB_NO_DISACK2                 (0x40)    /* [6] */
#define MSK_SWD_PE_CONFIG_HW_SDB_IGNORE_DISACK2             (0x1)     /* [7] */
#define RES_SWD_PE_CONFIG_HW_SDB_IGNORE_DISACK2             (0x0)
#define SFT_SWD_PE_CONFIG_HW_SDB_IGNORE_DISACK2             (7)
#define LSB_SWD_PE_CONFIG_HW_SDB_IGNORE_DISACK2             (7)
#define MSB_SWD_PE_CONFIG_HW_SDB_IGNORE_DISACK2             (7)
#define BIT_SWD_PE_CONFIG_HW_SDB_IGNORE_DISACK2             (0x80)    /* [7] */
#define MSK_SWD_PE_CONFIG_HW_NO_TRF_NO_DISACK2              (0x1)     /* [8] */
#define RES_SWD_PE_CONFIG_HW_NO_TRF_NO_DISACK2              (0x0)
#define SFT_SWD_PE_CONFIG_HW_NO_TRF_NO_DISACK2              (8)
#define LSB_SWD_PE_CONFIG_HW_NO_TRF_NO_DISACK2              (8)
#define MSB_SWD_PE_CONFIG_HW_NO_TRF_NO_DISACK2              (8)
#define BIT_SWD_PE_CONFIG_HW_NO_TRF_NO_DISACK2              (0x100)   /* [8] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE config HV
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: all nodes will send DisAck
   * 0: only nodes that take part in the transfer will send DisAck
   */ 
  unsigned short sdw_all_disack                :    1;       /* [0] */
  /**
   * 1: all nodes will send DisAck
   * 0: only nodes that take part in the transfer will send DisAck
   */ 
  unsigned short sdb_all_disack                :    1;       /* [1] */
  /**
   * 1: send no disack2 when errors are detected in cyclic frame
   */ 
  unsigned short sdz_no_disack2                :    1;       /* [2] */
  /**
   * 1: ignore disack2 in cyclic frames
   */ 
  unsigned short sdz_ignore_disack2            :    1;       /* [3] */
  /**
   * 1: send no disack2 when errors are detected in acyclic writes
   */ 
  unsigned short sdw_no_disack2                :    1;       /* [4] */
  /**
   * 1: ignore disack2 in acyclic writes
   */ 
  unsigned short sdw_ignore_disack2            :    1;       /* [5] */
  /**
   * 1: send no disack2 when errors are detected in acyclic broadcasts
   */ 
  unsigned short sdb_no_disack2                :    1;       /* [6] */
  /**
   * 1: ignore disack2 in acyclic broadcasts
   */ 
  unsigned short sdb_ignore_disack2            :    1;       /* [7] */
  /**
   * 1: send no disack2 when errors are detected in frame header
   */ 
  unsigned short no_trf_no_disack2             :    1;       /* [8] */
  /**
   * 
   */ 
  unsigned short reserved                      :    7;
} swd_pe_config_hw_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM PE config HV
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_pe_config_hw_bf bf;  ///< bit field representation
} swd_pe_config_hw_t;


/* SWD_IRQ_STATUS_COMM */

#define MSK_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_0             (0x1)     /* [0] */
#define RES_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_0             (0x0)
#define SFT_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_0             (0)
#define LSB_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_0             (0)
#define MSB_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_0             (0)
#define BIT_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_0             (0x1)     /* [0] */
#define MSK_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_1             (0x1)     /* [1] */
#define RES_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_1             (0x0)
#define SFT_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_1             (1)
#define LSB_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_1             (1)
#define MSB_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_1             (1)
#define BIT_SWD_IRQ_STATUS_COMM_EVT_DPLL_IDLE_1             (0x2)     /* [1] */
#define MSK_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_0           (0x1)     /* [2] */
#define RES_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_0           (0x0)
#define SFT_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_0           (2)
#define LSB_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_0           (2)
#define MSB_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_0           (2)
#define BIT_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_0           (0x4)     /* [2] */
#define MSK_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_1           (0x1)     /* [3] */
#define RES_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_1           (0x0)
#define SFT_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_1           (3)
#define LSB_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_1           (3)
#define MSB_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_1           (3)
#define BIT_SWD_IRQ_STATUS_COMM_EVT_DPLL_LOCKED_1           (0x8)     /* [3] */
#define MSK_SWD_IRQ_STATUS_COMM_PHY_OE_0                    (0x1)     /* [4] */
#define RES_SWD_IRQ_STATUS_COMM_PHY_OE_0                    (0x0)
#define SFT_SWD_IRQ_STATUS_COMM_PHY_OE_0                    (4)
#define LSB_SWD_IRQ_STATUS_COMM_PHY_OE_0                    (4)
#define MSB_SWD_IRQ_STATUS_COMM_PHY_OE_0                    (4)
#define BIT_SWD_IRQ_STATUS_COMM_PHY_OE_0                    (0x10)    /* [4] */
#define MSK_SWD_IRQ_STATUS_COMM_PHY_OE_1                    (0x1)     /* [5] */
#define RES_SWD_IRQ_STATUS_COMM_PHY_OE_1                    (0x0)
#define SFT_SWD_IRQ_STATUS_COMM_PHY_OE_1                    (5)
#define LSB_SWD_IRQ_STATUS_COMM_PHY_OE_1                    (5)
#define MSB_SWD_IRQ_STATUS_COMM_PHY_OE_1                    (5)
#define BIT_SWD_IRQ_STATUS_COMM_PHY_OE_1                    (0x20)    /* [5] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM IRQ status COMM
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * see corresponding event
   */ 
  unsigned short evt_dpll_idle_0               :    1;       /* [0] */
  /**
   * see corresponding event
   */ 
  unsigned short evt_dpll_idle_1               :    1;       /* [1] */
  /**
   * see corresponding event
   */ 
  unsigned short evt_dpll_locked_0             :    1;       /* [2] */
  /**
   * see corresponding event
   */ 
  unsigned short evt_dpll_locked_1             :    1;       /* [3] */
  /**
   * PHY 0 currently transmitting
   */ 
  unsigned short phy_oe_0                      :    1;       /* [4] */
  /**
   * PHY 1 currently transmitting
   */ 
  unsigned short phy_oe_1                      :    1;       /* [5] */
  /**
   * 
   */ 
  unsigned short reserved                      :   10;
} swd_irq_status_comm_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM IRQ status COMM
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_irq_status_comm_bf bf;  ///< bit field representation
} swd_irq_status_comm_t;


/* SWD_IRQ_MASK_COMM */

#define MSK_SWD_IRQ_MASK_COMM                               (0xffff)  /* [15:0] */

typedef unsigned short swd_irq_mask_comm_t;                           /* [15:0] */


/* SWD_TAKEOVER_DISACK2 */

#define MSK_SWD_TAKEOVER_DISACK2                            (0xffff)  /* [15:0] */

typedef unsigned short swd_takeover_disack2_t;                        /* [15:0] */


/* SWD_REPEATER_IDLE_STATE_IN */

#define MSK_SWD_REPEATER_IDLE_STATE_IN                      (0x1)     /* [0] */

typedef unsigned short swd_repeater_idle_state_in_t;                  /* [0] */


/* SWD_REPEATER_IDLE_STATE_OUT */

#define MSK_SWD_REPEATER_IDLE_STATE_OUT_FORCE_STATE         (0x1)     /* [0] */
#define RES_SWD_REPEATER_IDLE_STATE_OUT_FORCE_STATE         (0x0)
#define SFT_SWD_REPEATER_IDLE_STATE_OUT_FORCE_STATE         (0)
#define LSB_SWD_REPEATER_IDLE_STATE_OUT_FORCE_STATE         (0)
#define MSB_SWD_REPEATER_IDLE_STATE_OUT_FORCE_STATE         (0)
#define BIT_SWD_REPEATER_IDLE_STATE_OUT_FORCE_STATE         (0x1)     /* [0] */
#define MSK_SWD_REPEATER_IDLE_STATE_OUT_IDLE_STATE          (0x1)     /* [1] */
#define RES_SWD_REPEATER_IDLE_STATE_OUT_IDLE_STATE          (0x0)
#define SFT_SWD_REPEATER_IDLE_STATE_OUT_IDLE_STATE          (1)
#define LSB_SWD_REPEATER_IDLE_STATE_OUT_IDLE_STATE          (1)
#define MSB_SWD_REPEATER_IDLE_STATE_OUT_IDLE_STATE          (1)
#define BIT_SWD_REPEATER_IDLE_STATE_OUT_IDLE_STATE          (0x2)     /* [1] */


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Repeater idle state out
 *
 * \ingroup api_swd_pm 
 */ 
typedef struct {
  /**
   * 1: force idle_state on not selected bus
   * (can be used as selout, only for repeater)
   */ 
  unsigned short force_state                   :    1;       /* [0] */
  /**
   * forced idle state on not selected bus
   */ 
  unsigned short idle_state                    :    1;       /* [1] */
  /**
   * 
   */ 
  unsigned short reserved                      :   14;
} swd_repeater_idle_state_out_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of SWD PM Repeater idle state out
 *
 * \ingroup api_swd_pm 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  swd_repeater_idle_state_out_bf bf;  ///< bit field representation
} swd_repeater_idle_state_out_t;


/* SWD_TX_STOP_BIT_EXT */

#define MSK_SWD_TX_STOP_BIT_EXT                             (0xffff)  /* [15:0] */

typedef unsigned short swd_tx_stop_bit_ext_t;                         /* [15:0] */



// Register definitions for module
// Instance base address BASE_ADDR_SWD 0x40006200U ... 

#define ADDR_SWD_PHY_CONFIG                                  (0x00U)
#define A_SWD_PHY_CONFIG(ba)                                 ((ba) + ADDR_SWD_PHY_CONFIG)
#define R_SWD_PHY_CONFIG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_SWD_PHY_CONFIG(ba)))
#define RES_SWD_PHY_CONFIG                                   (0x0U)
#define MSB_SWD_PHY_CONFIG                                   7
#define LSB_SWD_PHY_CONFIG                                   0
#define AADDR_SWD_PHY_CONFIG                                 (BASE_ADDR_SWD + ADDR_SWD_PHY_CONFIG)
#define REG_SWD_PHY_CONFIG                                   (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PHY_CONFIG))

#define ADDR_SWD_INTEGRATOR_DPLL_THRESHOLD                   (0x02U)
#define A_SWD_INTEGRATOR_DPLL_THRESHOLD(ba)                  ((ba) + ADDR_SWD_INTEGRATOR_DPLL_THRESHOLD)
#define R_SWD_INTEGRATOR_DPLL_THRESHOLD(ba)                  (*(volatile unsigned short *)((unsigned int)A_SWD_INTEGRATOR_DPLL_THRESHOLD(ba)))
#define RES_SWD_INTEGRATOR_DPLL_THRESHOLD                    (0x1U)
#define MSB_SWD_INTEGRATOR_DPLL_THRESHOLD                    12
#define LSB_SWD_INTEGRATOR_DPLL_THRESHOLD                    0
#define AADDR_SWD_INTEGRATOR_DPLL_THRESHOLD                  (BASE_ADDR_SWD + ADDR_SWD_INTEGRATOR_DPLL_THRESHOLD)
#define REG_SWD_INTEGRATOR_DPLL_THRESHOLD                    (*(volatile unsigned short *)((unsigned int)AADDR_SWD_INTEGRATOR_DPLL_THRESHOLD))

#define ADDR_SWD_INTEGRATOR_DISACK_THRESHOLD                 (0x04U)
#define A_SWD_INTEGRATOR_DISACK_THRESHOLD(ba)                ((ba) + ADDR_SWD_INTEGRATOR_DISACK_THRESHOLD)
#define R_SWD_INTEGRATOR_DISACK_THRESHOLD(ba)                (*(volatile unsigned short *)((unsigned int)A_SWD_INTEGRATOR_DISACK_THRESHOLD(ba)))
#define RES_SWD_INTEGRATOR_DISACK_THRESHOLD                  (0x1U)
#define MSB_SWD_INTEGRATOR_DISACK_THRESHOLD                  15
#define LSB_SWD_INTEGRATOR_DISACK_THRESHOLD                  0
#define AADDR_SWD_INTEGRATOR_DISACK_THRESHOLD                (BASE_ADDR_SWD + ADDR_SWD_INTEGRATOR_DISACK_THRESHOLD)
#define REG_SWD_INTEGRATOR_DISACK_THRESHOLD                  (*(volatile unsigned short *)((unsigned int)AADDR_SWD_INTEGRATOR_DISACK_THRESHOLD))

#define ADDR_SWD_IDLE_DPLL_THRESHOLD_LW                      (0x06U)
#define A_SWD_IDLE_DPLL_THRESHOLD_LW(ba)                     ((ba) + ADDR_SWD_IDLE_DPLL_THRESHOLD_LW)
#define R_SWD_IDLE_DPLL_THRESHOLD_LW(ba)                     (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_DPLL_THRESHOLD_LW(ba)))
#define RES_SWD_IDLE_DPLL_THRESHOLD_LW                       (0x0U)
#define MSB_SWD_IDLE_DPLL_THRESHOLD_LW                       15
#define LSB_SWD_IDLE_DPLL_THRESHOLD_LW                       0
#define AADDR_SWD_IDLE_DPLL_THRESHOLD_LW                     (BASE_ADDR_SWD + ADDR_SWD_IDLE_DPLL_THRESHOLD_LW)
#define REG_SWD_IDLE_DPLL_THRESHOLD_LW                       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_DPLL_THRESHOLD_LW))

#define ADDR_SWD_IDLE_PE_THRESHOLD_LW                        (0x08U)
#define A_SWD_IDLE_PE_THRESHOLD_LW(ba)                       ((ba) + ADDR_SWD_IDLE_PE_THRESHOLD_LW)
#define R_SWD_IDLE_PE_THRESHOLD_LW(ba)                       (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_PE_THRESHOLD_LW(ba)))
#define RES_SWD_IDLE_PE_THRESHOLD_LW                         (0x0U)
#define MSB_SWD_IDLE_PE_THRESHOLD_LW                         15
#define LSB_SWD_IDLE_PE_THRESHOLD_LW                         0
#define AADDR_SWD_IDLE_PE_THRESHOLD_LW                       (BASE_ADDR_SWD + ADDR_SWD_IDLE_PE_THRESHOLD_LW)
#define REG_SWD_IDLE_PE_THRESHOLD_LW                         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_PE_THRESHOLD_LW))

#define ADDR_SWD_DPLL_OV_FRAC_PERIOD                         (0x0AU)
#define A_SWD_DPLL_OV_FRAC_PERIOD(ba)                        ((ba) + ADDR_SWD_DPLL_OV_FRAC_PERIOD)
#define R_SWD_DPLL_OV_FRAC_PERIOD(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_DPLL_OV_FRAC_PERIOD(ba)))
#define RES_SWD_DPLL_OV_FRAC_PERIOD                          (0x0U)
#define MSB_SWD_DPLL_OV_FRAC_PERIOD                          15
#define LSB_SWD_DPLL_OV_FRAC_PERIOD                          0
#define AADDR_SWD_DPLL_OV_FRAC_PERIOD                        (BASE_ADDR_SWD + ADDR_SWD_DPLL_OV_FRAC_PERIOD)
#define REG_SWD_DPLL_OV_FRAC_PERIOD                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DPLL_OV_FRAC_PERIOD))

#define ADDR_SWD_DPLL_MIN_PERIOD                             (0x0CU)
#define A_SWD_DPLL_MIN_PERIOD(ba)                            ((ba) + ADDR_SWD_DPLL_MIN_PERIOD)
#define R_SWD_DPLL_MIN_PERIOD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_DPLL_MIN_PERIOD(ba)))
#define RES_SWD_DPLL_MIN_PERIOD                              (0x0U)
#define MSB_SWD_DPLL_MIN_PERIOD                              15
#define LSB_SWD_DPLL_MIN_PERIOD                              0
#define AADDR_SWD_DPLL_MIN_PERIOD                            (BASE_ADDR_SWD + ADDR_SWD_DPLL_MIN_PERIOD)
#define REG_SWD_DPLL_MIN_PERIOD                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DPLL_MIN_PERIOD))

#define ADDR_SWD_DPLL_MAX_PERIOD                             (0x0EU)
#define A_SWD_DPLL_MAX_PERIOD(ba)                            ((ba) + ADDR_SWD_DPLL_MAX_PERIOD)
#define R_SWD_DPLL_MAX_PERIOD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_DPLL_MAX_PERIOD(ba)))
#define RES_SWD_DPLL_MAX_PERIOD                              (0x0U)
#define MSB_SWD_DPLL_MAX_PERIOD                              15
#define LSB_SWD_DPLL_MAX_PERIOD                              0
#define AADDR_SWD_DPLL_MAX_PERIOD                            (BASE_ADDR_SWD + ADDR_SWD_DPLL_MAX_PERIOD)
#define REG_SWD_DPLL_MAX_PERIOD                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DPLL_MAX_PERIOD))

#define ADDR_SWD_DPLL_LAST_FRAC_PERIOD                       (0x10U)
#define A_SWD_DPLL_LAST_FRAC_PERIOD(ba)                      ((ba) + ADDR_SWD_DPLL_LAST_FRAC_PERIOD)
#define R_SWD_DPLL_LAST_FRAC_PERIOD(ba)                      (*(volatile unsigned short *)((unsigned int)A_SWD_DPLL_LAST_FRAC_PERIOD(ba)))
#define RES_SWD_DPLL_LAST_FRAC_PERIOD                        (0x0U)
#define MSB_SWD_DPLL_LAST_FRAC_PERIOD                        15
#define LSB_SWD_DPLL_LAST_FRAC_PERIOD                        0
#define AADDR_SWD_DPLL_LAST_FRAC_PERIOD                      (BASE_ADDR_SWD + ADDR_SWD_DPLL_LAST_FRAC_PERIOD)
#define REG_SWD_DPLL_LAST_FRAC_PERIOD                        (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DPLL_LAST_FRAC_PERIOD))

#define ADDR_SWD_DPLL_MEAN_ALPHA                             (0x12U)
#define A_SWD_DPLL_MEAN_ALPHA(ba)                            ((ba) + ADDR_SWD_DPLL_MEAN_ALPHA)
#define R_SWD_DPLL_MEAN_ALPHA(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_DPLL_MEAN_ALPHA(ba)))
#define RES_SWD_DPLL_MEAN_ALPHA                              (0x0U)
#define MSB_SWD_DPLL_MEAN_ALPHA                              2
#define LSB_SWD_DPLL_MEAN_ALPHA                              0
#define AADDR_SWD_DPLL_MEAN_ALPHA                            (BASE_ADDR_SWD + ADDR_SWD_DPLL_MEAN_ALPHA)
#define REG_SWD_DPLL_MEAN_ALPHA                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DPLL_MEAN_ALPHA))

#define ADDR_SWD_DPLL_MEAN_FRAC_PERIOD                       (0x14U)
#define A_SWD_DPLL_MEAN_FRAC_PERIOD(ba)                      ((ba) + ADDR_SWD_DPLL_MEAN_FRAC_PERIOD)
#define R_SWD_DPLL_MEAN_FRAC_PERIOD(ba)                      (*(volatile unsigned short *)((unsigned int)A_SWD_DPLL_MEAN_FRAC_PERIOD(ba)))
#define RES_SWD_DPLL_MEAN_FRAC_PERIOD                        (0x0U)
#define MSB_SWD_DPLL_MEAN_FRAC_PERIOD                        15
#define LSB_SWD_DPLL_MEAN_FRAC_PERIOD                        0
#define AADDR_SWD_DPLL_MEAN_FRAC_PERIOD                      (BASE_ADDR_SWD + ADDR_SWD_DPLL_MEAN_FRAC_PERIOD)
#define REG_SWD_DPLL_MEAN_FRAC_PERIOD                        (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DPLL_MEAN_FRAC_PERIOD))

#define ADDR_SWD_START_THRESHOLD                             (0x16U)
#define A_SWD_START_THRESHOLD(ba)                            ((ba) + ADDR_SWD_START_THRESHOLD)
#define R_SWD_START_THRESHOLD(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_START_THRESHOLD(ba)))
#define RES_SWD_START_THRESHOLD                              (0x1U)
#define MSB_SWD_START_THRESHOLD                              10
#define LSB_SWD_START_THRESHOLD                              0
#define AADDR_SWD_START_THRESHOLD                            (BASE_ADDR_SWD + ADDR_SWD_START_THRESHOLD)
#define REG_SWD_START_THRESHOLD                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_START_THRESHOLD))

#define ADDR_SWD_DATA_OFFSET                                 (0x18U)
#define A_SWD_DATA_OFFSET(ba)                                ((ba) + ADDR_SWD_DATA_OFFSET)
#define R_SWD_DATA_OFFSET(ba)                                (*(volatile unsigned short *)((unsigned int)A_SWD_DATA_OFFSET(ba)))
#define RES_SWD_DATA_OFFSET                                  (0x1U)
#define MSB_SWD_DATA_OFFSET                                  12
#define LSB_SWD_DATA_OFFSET                                  0
#define AADDR_SWD_DATA_OFFSET                                (BASE_ADDR_SWD + ADDR_SWD_DATA_OFFSET)
#define REG_SWD_DATA_OFFSET                                  (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DATA_OFFSET))

#define ADDR_SWD_TIMEOUT_RX                                  (0x1AU)
#define A_SWD_TIMEOUT_RX(ba)                                 ((ba) + ADDR_SWD_TIMEOUT_RX)
#define R_SWD_TIMEOUT_RX(ba)                                 (*(volatile unsigned short *)((unsigned int)A_SWD_TIMEOUT_RX(ba)))
#define RES_SWD_TIMEOUT_RX                                   (0x0U)
#define MSB_SWD_TIMEOUT_RX                                   7
#define LSB_SWD_TIMEOUT_RX                                   0
#define AADDR_SWD_TIMEOUT_RX                                 (BASE_ADDR_SWD + ADDR_SWD_TIMEOUT_RX)
#define REG_SWD_TIMEOUT_RX                                   (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TIMEOUT_RX))

#define ADDR_SWD_TIMEOUT_REPLACE                             (0x1CU)
#define A_SWD_TIMEOUT_REPLACE(ba)                            ((ba) + ADDR_SWD_TIMEOUT_REPLACE)
#define R_SWD_TIMEOUT_REPLACE(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_TIMEOUT_REPLACE(ba)))
#define RES_SWD_TIMEOUT_REPLACE                              (0x0U)
#define MSB_SWD_TIMEOUT_REPLACE                              7
#define LSB_SWD_TIMEOUT_REPLACE                              0
#define AADDR_SWD_TIMEOUT_REPLACE                            (BASE_ADDR_SWD + ADDR_SWD_TIMEOUT_REPLACE)
#define REG_SWD_TIMEOUT_REPLACE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TIMEOUT_REPLACE))

#define ADDR_SWD_TX_PRESTART_SYNC                            (0x20U)
#define A_SWD_TX_PRESTART_SYNC(ba)                           ((ba) + ADDR_SWD_TX_PRESTART_SYNC)
#define R_SWD_TX_PRESTART_SYNC(ba)                           (*(volatile unsigned short *)((unsigned int)A_SWD_TX_PRESTART_SYNC(ba)))
#define RES_SWD_TX_PRESTART_SYNC                             (0x0U)
#define MSB_SWD_TX_PRESTART_SYNC                             15
#define LSB_SWD_TX_PRESTART_SYNC                             0
#define AADDR_SWD_TX_PRESTART_SYNC                           (BASE_ADDR_SWD + ADDR_SWD_TX_PRESTART_SYNC)
#define REG_SWD_TX_PRESTART_SYNC                             (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TX_PRESTART_SYNC))

#define ADDR_SWD_TX_PRESTART_DATA                            (0x22U)
#define A_SWD_TX_PRESTART_DATA(ba)                           ((ba) + ADDR_SWD_TX_PRESTART_DATA)
#define R_SWD_TX_PRESTART_DATA(ba)                           (*(volatile unsigned short *)((unsigned int)A_SWD_TX_PRESTART_DATA(ba)))
#define RES_SWD_TX_PRESTART_DATA                             (0x0U)
#define MSB_SWD_TX_PRESTART_DATA                             12
#define LSB_SWD_TX_PRESTART_DATA                             0
#define AADDR_SWD_TX_PRESTART_DATA                           (BASE_ADDR_SWD + ADDR_SWD_TX_PRESTART_DATA)
#define REG_SWD_TX_PRESTART_DATA                             (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TX_PRESTART_DATA))

#define ADDR_SWD_TX_END_OF_SYNC                              (0x24U)
#define A_SWD_TX_END_OF_SYNC(ba)                             ((ba) + ADDR_SWD_TX_END_OF_SYNC)
#define R_SWD_TX_END_OF_SYNC(ba)                             (*(volatile unsigned short *)((unsigned int)A_SWD_TX_END_OF_SYNC(ba)))
#define RES_SWD_TX_END_OF_SYNC                               (0x0U)
#define MSB_SWD_TX_END_OF_SYNC                               1
#define LSB_SWD_TX_END_OF_SYNC                               0
#define AADDR_SWD_TX_END_OF_SYNC                             (BASE_ADDR_SWD + ADDR_SWD_TX_END_OF_SYNC)
#define REG_SWD_TX_END_OF_SYNC                               (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TX_END_OF_SYNC))

#define ADDR_SWD_TIMEOUT_DISACK                              (0x26U)
#define A_SWD_TIMEOUT_DISACK(ba)                             ((ba) + ADDR_SWD_TIMEOUT_DISACK)
#define R_SWD_TIMEOUT_DISACK(ba)                             (*(volatile unsigned short *)((unsigned int)A_SWD_TIMEOUT_DISACK(ba)))
#define RES_SWD_TIMEOUT_DISACK                               (0xaU)
#define MSB_SWD_TIMEOUT_DISACK                               15
#define LSB_SWD_TIMEOUT_DISACK                               0
#define AADDR_SWD_TIMEOUT_DISACK                             (BASE_ADDR_SWD + ADDR_SWD_TIMEOUT_DISACK)
#define REG_SWD_TIMEOUT_DISACK                               (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TIMEOUT_DISACK))

#define ADDR_SWD_COMM_CONFIG                                 (0x28U)
#define A_SWD_COMM_CONFIG(ba)                                ((ba) + ADDR_SWD_COMM_CONFIG)
#define R_SWD_COMM_CONFIG(ba)                                (*(volatile unsigned short *)((unsigned int)A_SWD_COMM_CONFIG(ba)))
#define RES_SWD_COMM_CONFIG                                  (0x80U)
#define MSB_SWD_COMM_CONFIG                                  7
#define LSB_SWD_COMM_CONFIG                                  0
#define AADDR_SWD_COMM_CONFIG                                (BASE_ADDR_SWD + ADDR_SWD_COMM_CONFIG)
#define REG_SWD_COMM_CONFIG                                  (*(volatile unsigned short *)((unsigned int)AADDR_SWD_COMM_CONFIG))

#define ADDR_SWD_COMM_STATUS                                 (0x2AU)
#define A_SWD_COMM_STATUS(ba)                                ((ba) + ADDR_SWD_COMM_STATUS)
#define R_SWD_COMM_STATUS(ba)                                (*(volatile unsigned short *)((unsigned int)A_SWD_COMM_STATUS(ba)))
#define RES_SWD_COMM_STATUS                                  (0x0U)
#define MSB_SWD_COMM_STATUS                                  6
#define LSB_SWD_COMM_STATUS                                  0
#define AADDR_SWD_COMM_STATUS                                (BASE_ADDR_SWD + ADDR_SWD_COMM_STATUS)
#define REG_SWD_COMM_STATUS                                  (*(volatile unsigned short *)((unsigned int)AADDR_SWD_COMM_STATUS))

#define ADDR_SWD_SAP_SOURCE2_STATUS                          (0x2CU)
#define A_SWD_SAP_SOURCE2_STATUS(ba)                         ((ba) + ADDR_SWD_SAP_SOURCE2_STATUS)
#define R_SWD_SAP_SOURCE2_STATUS(ba)                         (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SOURCE2_STATUS(ba)))
#define RES_SWD_SAP_SOURCE2_STATUS                           (0x0U)
#define MSB_SWD_SAP_SOURCE2_STATUS                           15
#define LSB_SWD_SAP_SOURCE2_STATUS                           0
#define AADDR_SWD_SAP_SOURCE2_STATUS                         (BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE2_STATUS)
#define REG_SWD_SAP_SOURCE2_STATUS                           (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SOURCE2_STATUS))

#define ADDR_SWD_SAP_SOURCE3_STATUS                          (0x2EU)
#define A_SWD_SAP_SOURCE3_STATUS(ba)                         ((ba) + ADDR_SWD_SAP_SOURCE3_STATUS)
#define R_SWD_SAP_SOURCE3_STATUS(ba)                         (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SOURCE3_STATUS(ba)))
#define RES_SWD_SAP_SOURCE3_STATUS                           (0x0U)
#define MSB_SWD_SAP_SOURCE3_STATUS                           15
#define LSB_SWD_SAP_SOURCE3_STATUS                           0
#define AADDR_SWD_SAP_SOURCE3_STATUS                         (BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE3_STATUS)
#define REG_SWD_SAP_SOURCE3_STATUS                           (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SOURCE3_STATUS))

#define ADDR_SWD_SAP_SOURCE2_COMMAND                         (0x30U)
#define A_SWD_SAP_SOURCE2_COMMAND(ba)                        ((ba) + ADDR_SWD_SAP_SOURCE2_COMMAND)
#define R_SWD_SAP_SOURCE2_COMMAND(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SOURCE2_COMMAND(ba)))
#define RES_SWD_SAP_SOURCE2_COMMAND                          (0x0U)
#define MSB_SWD_SAP_SOURCE2_COMMAND                          15
#define LSB_SWD_SAP_SOURCE2_COMMAND                          0
#define AADDR_SWD_SAP_SOURCE2_COMMAND                        (BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE2_COMMAND)
#define REG_SWD_SAP_SOURCE2_COMMAND                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SOURCE2_COMMAND))

#define ADDR_SWD_SAP_SOURCE3_COMMAND                         (0x32U)
#define A_SWD_SAP_SOURCE3_COMMAND(ba)                        ((ba) + ADDR_SWD_SAP_SOURCE3_COMMAND)
#define R_SWD_SAP_SOURCE3_COMMAND(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SOURCE3_COMMAND(ba)))
#define RES_SWD_SAP_SOURCE3_COMMAND                          (0x0U)
#define MSB_SWD_SAP_SOURCE3_COMMAND                          15
#define LSB_SWD_SAP_SOURCE3_COMMAND                          0
#define AADDR_SWD_SAP_SOURCE3_COMMAND                        (BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE3_COMMAND)
#define REG_SWD_SAP_SOURCE3_COMMAND                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SOURCE3_COMMAND))

#define ADDR_SWD_DATA_LENGTH                                 (0x34U)
#define A_SWD_DATA_LENGTH(ba)                                ((ba) + ADDR_SWD_DATA_LENGTH)
#define R_SWD_DATA_LENGTH(ba)                                (*(volatile unsigned short *)((unsigned int)A_SWD_DATA_LENGTH(ba)))
#define RES_SWD_DATA_LENGTH                                  (0x1U)
#define MSB_SWD_DATA_LENGTH                                  12
#define LSB_SWD_DATA_LENGTH                                  0
#define AADDR_SWD_DATA_LENGTH                                (BASE_ADDR_SWD + ADDR_SWD_DATA_LENGTH)
#define REG_SWD_DATA_LENGTH                                  (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DATA_LENGTH))

#define ADDR_SWD_PE_CONFIG_LW                                (0x48U)
#define A_SWD_PE_CONFIG_LW(ba)                               ((ba) + ADDR_SWD_PE_CONFIG_LW)
#define R_SWD_PE_CONFIG_LW(ba)                               (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CONFIG_LW(ba)))
#define RES_SWD_PE_CONFIG_LW                                 (0x0U)
#define MSB_SWD_PE_CONFIG_LW                                 13
#define LSB_SWD_PE_CONFIG_LW                                 0
#define AADDR_SWD_PE_CONFIG_LW                               (BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_LW)
#define REG_SWD_PE_CONFIG_LW                                 (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CONFIG_LW))

#define ADDR_SWD_PE_GNT_SELF                                 (0x4AU)
#define A_SWD_PE_GNT_SELF(ba)                                ((ba) + ADDR_SWD_PE_GNT_SELF)
#define R_SWD_PE_GNT_SELF(ba)                                (*(volatile unsigned short *)((unsigned int)A_SWD_PE_GNT_SELF(ba)))
#define RES_SWD_PE_GNT_SELF                                  (0x0U)
#define MSB_SWD_PE_GNT_SELF                                  7
#define LSB_SWD_PE_GNT_SELF                                  0
#define AADDR_SWD_PE_GNT_SELF                                (BASE_ADDR_SWD + ADDR_SWD_PE_GNT_SELF)
#define REG_SWD_PE_GNT_SELF                                  (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_GNT_SELF))

#define ADDR_SWD_PE_CYC_WRITE_OFFSET                         (0x4CU)
#define A_SWD_PE_CYC_WRITE_OFFSET(ba)                        ((ba) + ADDR_SWD_PE_CYC_WRITE_OFFSET)
#define R_SWD_PE_CYC_WRITE_OFFSET(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_WRITE_OFFSET(ba)))
#define RES_SWD_PE_CYC_WRITE_OFFSET                          (0x0U)
#define MSB_SWD_PE_CYC_WRITE_OFFSET                          10
#define LSB_SWD_PE_CYC_WRITE_OFFSET                          0
#define AADDR_SWD_PE_CYC_WRITE_OFFSET                        (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_WRITE_OFFSET)
#define REG_SWD_PE_CYC_WRITE_OFFSET                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_WRITE_OFFSET))

#define ADDR_SWD_PE_CYC_WRITE_LENGTH                         (0x4EU)
#define A_SWD_PE_CYC_WRITE_LENGTH(ba)                        ((ba) + ADDR_SWD_PE_CYC_WRITE_LENGTH)
#define R_SWD_PE_CYC_WRITE_LENGTH(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_WRITE_LENGTH(ba)))
#define RES_SWD_PE_CYC_WRITE_LENGTH                          (0x0U)
#define MSB_SWD_PE_CYC_WRITE_LENGTH                          10
#define LSB_SWD_PE_CYC_WRITE_LENGTH                          0
#define AADDR_SWD_PE_CYC_WRITE_LENGTH                        (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_WRITE_LENGTH)
#define REG_SWD_PE_CYC_WRITE_LENGTH                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_WRITE_LENGTH))

#define ADDR_SWD_PE_CYC_RX_CUT_START0                        (0x50U)
#define A_SWD_PE_CYC_RX_CUT_START0(ba)                       ((ba) + ADDR_SWD_PE_CYC_RX_CUT_START0)
#define R_SWD_PE_CYC_RX_CUT_START0(ba)                       (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_RX_CUT_START0(ba)))
#define RES_SWD_PE_CYC_RX_CUT_START0                         (0x0U)
#define MSB_SWD_PE_CYC_RX_CUT_START0                         10
#define LSB_SWD_PE_CYC_RX_CUT_START0                         0
#define AADDR_SWD_PE_CYC_RX_CUT_START0                       (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_START0)
#define REG_SWD_PE_CYC_RX_CUT_START0                         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_RX_CUT_START0))

#define ADDR_SWD_PE_CYC_RX_CUT_START1                        (0x52U)
#define A_SWD_PE_CYC_RX_CUT_START1(ba)                       ((ba) + ADDR_SWD_PE_CYC_RX_CUT_START1)
#define R_SWD_PE_CYC_RX_CUT_START1(ba)                       (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_RX_CUT_START1(ba)))
#define RES_SWD_PE_CYC_RX_CUT_START1                         (0x0U)
#define MSB_SWD_PE_CYC_RX_CUT_START1                         10
#define LSB_SWD_PE_CYC_RX_CUT_START1                         0
#define AADDR_SWD_PE_CYC_RX_CUT_START1                       (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_START1)
#define REG_SWD_PE_CYC_RX_CUT_START1                         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_RX_CUT_START1))

#define ADDR_SWD_PE_CYC_RX_CUT_LENGTH0                       (0x54U)
#define A_SWD_PE_CYC_RX_CUT_LENGTH0(ba)                      ((ba) + ADDR_SWD_PE_CYC_RX_CUT_LENGTH0)
#define R_SWD_PE_CYC_RX_CUT_LENGTH0(ba)                      (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_RX_CUT_LENGTH0(ba)))
#define RES_SWD_PE_CYC_RX_CUT_LENGTH0                        (0x3ffU)
#define MSB_SWD_PE_CYC_RX_CUT_LENGTH0                        10
#define LSB_SWD_PE_CYC_RX_CUT_LENGTH0                        0
#define AADDR_SWD_PE_CYC_RX_CUT_LENGTH0                      (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_LENGTH0)
#define REG_SWD_PE_CYC_RX_CUT_LENGTH0                        (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_RX_CUT_LENGTH0))

#define ADDR_SWD_PE_CYC_RX_CUT_LENGTH1                       (0x56U)
#define A_SWD_PE_CYC_RX_CUT_LENGTH1(ba)                      ((ba) + ADDR_SWD_PE_CYC_RX_CUT_LENGTH1)
#define R_SWD_PE_CYC_RX_CUT_LENGTH1(ba)                      (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_RX_CUT_LENGTH1(ba)))
#define RES_SWD_PE_CYC_RX_CUT_LENGTH1                        (0x3ffU)
#define MSB_SWD_PE_CYC_RX_CUT_LENGTH1                        10
#define LSB_SWD_PE_CYC_RX_CUT_LENGTH1                        0
#define AADDR_SWD_PE_CYC_RX_CUT_LENGTH1                      (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_LENGTH1)
#define REG_SWD_PE_CYC_RX_CUT_LENGTH1                        (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_RX_CUT_LENGTH1))

#define ADDR_SWD_STATUS0_MASK_OFFSET                         (0x5AU)
#define A_SWD_STATUS0_MASK_OFFSET(ba)                        ((ba) + ADDR_SWD_STATUS0_MASK_OFFSET)
#define R_SWD_STATUS0_MASK_OFFSET(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_STATUS0_MASK_OFFSET(ba)))
#define RES_SWD_STATUS0_MASK_OFFSET                          (0x0U)
#define MSB_SWD_STATUS0_MASK_OFFSET                          15
#define LSB_SWD_STATUS0_MASK_OFFSET                          0
#define AADDR_SWD_STATUS0_MASK_OFFSET                        (BASE_ADDR_SWD + ADDR_SWD_STATUS0_MASK_OFFSET)
#define REG_SWD_STATUS0_MASK_OFFSET                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_STATUS0_MASK_OFFSET))

#define ADDR_SWD_STATUS1_MASK_OFFSET                         (0x5CU)
#define A_SWD_STATUS1_MASK_OFFSET(ba)                        ((ba) + ADDR_SWD_STATUS1_MASK_OFFSET)
#define R_SWD_STATUS1_MASK_OFFSET(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_STATUS1_MASK_OFFSET(ba)))
#define RES_SWD_STATUS1_MASK_OFFSET                          (0x0U)
#define MSB_SWD_STATUS1_MASK_OFFSET                          15
#define LSB_SWD_STATUS1_MASK_OFFSET                          0
#define AADDR_SWD_STATUS1_MASK_OFFSET                        (BASE_ADDR_SWD + ADDR_SWD_STATUS1_MASK_OFFSET)
#define REG_SWD_STATUS1_MASK_OFFSET                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_STATUS1_MASK_OFFSET))

#define ADDR_SWD_STATUS1_COMMAND                             (0x5EU)
#define A_SWD_STATUS1_COMMAND(ba)                            ((ba) + ADDR_SWD_STATUS1_COMMAND)
#define R_SWD_STATUS1_COMMAND(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_STATUS1_COMMAND(ba)))
#define RES_SWD_STATUS1_COMMAND                              (0x0U)
#define MSB_SWD_STATUS1_COMMAND                              0
#define LSB_SWD_STATUS1_COMMAND                              0
#define AADDR_SWD_STATUS1_COMMAND                            (BASE_ADDR_SWD + ADDR_SWD_STATUS1_COMMAND)
#define REG_SWD_STATUS1_COMMAND                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_STATUS1_COMMAND))

#define ADDR_SWD_STATUS1_NODES                               (0x60U)
#define A_SWD_STATUS1_NODES(ba)                              ((ba) + ADDR_SWD_STATUS1_NODES)
#define R_SWD_STATUS1_NODES(ba)                              (*(volatile unsigned short *)((unsigned int)A_SWD_STATUS1_NODES(ba)))
#define RES_SWD_STATUS1_NODES                                (0x0U)
#define MSB_SWD_STATUS1_NODES                                8
#define LSB_SWD_STATUS1_NODES                                0
#define AADDR_SWD_STATUS1_NODES                              (BASE_ADDR_SWD + ADDR_SWD_STATUS1_NODES)
#define REG_SWD_STATUS1_NODES                                (*(volatile unsigned short *)((unsigned int)AADDR_SWD_STATUS1_NODES))

#define ADDR_SWD_SAP_DESTINATION_ALL_EN                      (0x64U)
#define A_SWD_SAP_DESTINATION_ALL_EN(ba)                     ((ba) + ADDR_SWD_SAP_DESTINATION_ALL_EN)
#define R_SWD_SAP_DESTINATION_ALL_EN(ba)                     (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_DESTINATION_ALL_EN(ba)))
#define RES_SWD_SAP_DESTINATION_ALL_EN                       (0x0U)
#define MSB_SWD_SAP_DESTINATION_ALL_EN                       0
#define LSB_SWD_SAP_DESTINATION_ALL_EN                       0
#define AADDR_SWD_SAP_DESTINATION_ALL_EN                     (BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ALL_EN)
#define REG_SWD_SAP_DESTINATION_ALL_EN                       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_DESTINATION_ALL_EN))

#define ADDR_SWD_SAP_DESTINATION_ADDR0                       (0x66U)
#define A_SWD_SAP_DESTINATION_ADDR0(ba)                      ((ba) + ADDR_SWD_SAP_DESTINATION_ADDR0)
#define R_SWD_SAP_DESTINATION_ADDR0(ba)                      (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_DESTINATION_ADDR0(ba)))
#define RES_SWD_SAP_DESTINATION_ADDR0                        (0x0U)
#define MSB_SWD_SAP_DESTINATION_ADDR0                        8
#define LSB_SWD_SAP_DESTINATION_ADDR0                        0
#define AADDR_SWD_SAP_DESTINATION_ADDR0                      (BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR0)
#define REG_SWD_SAP_DESTINATION_ADDR0                        (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_DESTINATION_ADDR0))

#define ADDR_SWD_SAP_DESTINATION_ADDR1                       (0x68U)
#define A_SWD_SAP_DESTINATION_ADDR1(ba)                      ((ba) + ADDR_SWD_SAP_DESTINATION_ADDR1)
#define R_SWD_SAP_DESTINATION_ADDR1(ba)                      (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_DESTINATION_ADDR1(ba)))
#define RES_SWD_SAP_DESTINATION_ADDR1                        (0x0U)
#define MSB_SWD_SAP_DESTINATION_ADDR1                        8
#define LSB_SWD_SAP_DESTINATION_ADDR1                        0
#define AADDR_SWD_SAP_DESTINATION_ADDR1                      (BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR1)
#define REG_SWD_SAP_DESTINATION_ADDR1                        (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_DESTINATION_ADDR1))

#define ADDR_SWD_SAP_DESTINATION_ADDR2                       (0x6AU)
#define A_SWD_SAP_DESTINATION_ADDR2(ba)                      ((ba) + ADDR_SWD_SAP_DESTINATION_ADDR2)
#define R_SWD_SAP_DESTINATION_ADDR2(ba)                      (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_DESTINATION_ADDR2(ba)))
#define RES_SWD_SAP_DESTINATION_ADDR2                        (0x0U)
#define MSB_SWD_SAP_DESTINATION_ADDR2                        8
#define LSB_SWD_SAP_DESTINATION_ADDR2                        0
#define AADDR_SWD_SAP_DESTINATION_ADDR2                      (BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR2)
#define REG_SWD_SAP_DESTINATION_ADDR2                        (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_DESTINATION_ADDR2))

#define ADDR_SWD_SAP_DESTINATION_ADDR3                       (0x6CU)
#define A_SWD_SAP_DESTINATION_ADDR3(ba)                      ((ba) + ADDR_SWD_SAP_DESTINATION_ADDR3)
#define R_SWD_SAP_DESTINATION_ADDR3(ba)                      (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_DESTINATION_ADDR3(ba)))
#define RES_SWD_SAP_DESTINATION_ADDR3                        (0x0U)
#define MSB_SWD_SAP_DESTINATION_ADDR3                        8
#define LSB_SWD_SAP_DESTINATION_ADDR3                        0
#define AADDR_SWD_SAP_DESTINATION_ADDR3                      (BASE_ADDR_SWD + ADDR_SWD_SAP_DESTINATION_ADDR3)
#define REG_SWD_SAP_DESTINATION_ADDR3                        (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_DESTINATION_ADDR3))

#define ADDR_SWD_SAP_SAPA_FILTER                             (0x6EU)
#define A_SWD_SAP_SAPA_FILTER(ba)                            ((ba) + ADDR_SWD_SAP_SAPA_FILTER)
#define R_SWD_SAP_SAPA_FILTER(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SAPA_FILTER(ba)))
#define RES_SWD_SAP_SAPA_FILTER                              (0x0U)
#define MSB_SWD_SAP_SAPA_FILTER                              8
#define LSB_SWD_SAP_SAPA_FILTER                              0
#define AADDR_SWD_SAP_SAPA_FILTER                            (BASE_ADDR_SWD + ADDR_SWD_SAP_SAPA_FILTER)
#define REG_SWD_SAP_SAPA_FILTER                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SAPA_FILTER))

#define ADDR_SWD_SAP_SAPB_FILTER                             (0x70U)
#define A_SWD_SAP_SAPB_FILTER(ba)                            ((ba) + ADDR_SWD_SAP_SAPB_FILTER)
#define R_SWD_SAP_SAPB_FILTER(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SAPB_FILTER(ba)))
#define RES_SWD_SAP_SAPB_FILTER                              (0x0U)
#define MSB_SWD_SAP_SAPB_FILTER                              8
#define LSB_SWD_SAP_SAPB_FILTER                              0
#define AADDR_SWD_SAP_SAPB_FILTER                            (BASE_ADDR_SWD + ADDR_SWD_SAP_SAPB_FILTER)
#define REG_SWD_SAP_SAPB_FILTER                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SAPB_FILTER))

#define ADDR_SWD_SAP_SAPC_FILTER                             (0x72U)
#define A_SWD_SAP_SAPC_FILTER(ba)                            ((ba) + ADDR_SWD_SAP_SAPC_FILTER)
#define R_SWD_SAP_SAPC_FILTER(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SAPC_FILTER(ba)))
#define RES_SWD_SAP_SAPC_FILTER                              (0x0U)
#define MSB_SWD_SAP_SAPC_FILTER                              8
#define LSB_SWD_SAP_SAPC_FILTER                              0
#define AADDR_SWD_SAP_SAPC_FILTER                            (BASE_ADDR_SWD + ADDR_SWD_SAP_SAPC_FILTER)
#define REG_SWD_SAP_SAPC_FILTER                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SAPC_FILTER))

#define ADDR_SWD_SAP_SOURCE0_STATUS                          (0x74U)
#define A_SWD_SAP_SOURCE0_STATUS(ba)                         ((ba) + ADDR_SWD_SAP_SOURCE0_STATUS)
#define R_SWD_SAP_SOURCE0_STATUS(ba)                         (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SOURCE0_STATUS(ba)))
#define RES_SWD_SAP_SOURCE0_STATUS                           (0x0U)
#define MSB_SWD_SAP_SOURCE0_STATUS                           15
#define LSB_SWD_SAP_SOURCE0_STATUS                           0
#define AADDR_SWD_SAP_SOURCE0_STATUS                         (BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE0_STATUS)
#define REG_SWD_SAP_SOURCE0_STATUS                           (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SOURCE0_STATUS))

#define ADDR_SWD_SAP_SOURCE1_STATUS                          (0x76U)
#define A_SWD_SAP_SOURCE1_STATUS(ba)                         ((ba) + ADDR_SWD_SAP_SOURCE1_STATUS)
#define R_SWD_SAP_SOURCE1_STATUS(ba)                         (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SOURCE1_STATUS(ba)))
#define RES_SWD_SAP_SOURCE1_STATUS                           (0x0U)
#define MSB_SWD_SAP_SOURCE1_STATUS                           15
#define LSB_SWD_SAP_SOURCE1_STATUS                           0
#define AADDR_SWD_SAP_SOURCE1_STATUS                         (BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE1_STATUS)
#define REG_SWD_SAP_SOURCE1_STATUS                           (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SOURCE1_STATUS))

#define ADDR_SWD_SAP_SOURCE0_COMMAND                         (0x78U)
#define A_SWD_SAP_SOURCE0_COMMAND(ba)                        ((ba) + ADDR_SWD_SAP_SOURCE0_COMMAND)
#define R_SWD_SAP_SOURCE0_COMMAND(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SOURCE0_COMMAND(ba)))
#define RES_SWD_SAP_SOURCE0_COMMAND                          (0x0U)
#define MSB_SWD_SAP_SOURCE0_COMMAND                          15
#define LSB_SWD_SAP_SOURCE0_COMMAND                          0
#define AADDR_SWD_SAP_SOURCE0_COMMAND                        (BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE0_COMMAND)
#define REG_SWD_SAP_SOURCE0_COMMAND                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SOURCE0_COMMAND))

#define ADDR_SWD_SAP_SOURCE1_COMMAND                         (0x7AU)
#define A_SWD_SAP_SOURCE1_COMMAND(ba)                        ((ba) + ADDR_SWD_SAP_SOURCE1_COMMAND)
#define R_SWD_SAP_SOURCE1_COMMAND(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_SAP_SOURCE1_COMMAND(ba)))
#define RES_SWD_SAP_SOURCE1_COMMAND                          (0x0U)
#define MSB_SWD_SAP_SOURCE1_COMMAND                          15
#define LSB_SWD_SAP_SOURCE1_COMMAND                          0
#define AADDR_SWD_SAP_SOURCE1_COMMAND                        (BASE_ADDR_SWD + ADDR_SWD_SAP_SOURCE1_COMMAND)
#define REG_SWD_SAP_SOURCE1_COMMAND                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_SAP_SOURCE1_COMMAND))

#define ADDR_SWD_DMA_CONFIG                                  (0x7EU)
#define A_SWD_DMA_CONFIG(ba)                                 ((ba) + ADDR_SWD_DMA_CONFIG)
#define R_SWD_DMA_CONFIG(ba)                                 (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_CONFIG(ba)))
#define RES_SWD_DMA_CONFIG                                   (0x18U)
#define MSB_SWD_DMA_CONFIG                                   6
#define LSB_SWD_DMA_CONFIG                                   0
#define AADDR_SWD_DMA_CONFIG                                 (BASE_ADDR_SWD + ADDR_SWD_DMA_CONFIG)
#define REG_SWD_DMA_CONFIG                                   (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_CONFIG))

#define ADDR_SWD_DMA_COMMAND                                 (0x80U)
#define A_SWD_DMA_COMMAND(ba)                                ((ba) + ADDR_SWD_DMA_COMMAND)
#define R_SWD_DMA_COMMAND(ba)                                (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_COMMAND(ba)))
#define RES_SWD_DMA_COMMAND                                  (0x0U)
#define MSB_SWD_DMA_COMMAND                                  7
#define LSB_SWD_DMA_COMMAND                                  0
#define AADDR_SWD_DMA_COMMAND                                (BASE_ADDR_SWD + ADDR_SWD_DMA_COMMAND)
#define REG_SWD_DMA_COMMAND                                  (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_COMMAND))

#define ADDR_SWD_DMA_CYC_RX_SIZE                             (0x82U)
#define A_SWD_DMA_CYC_RX_SIZE(ba)                            ((ba) + ADDR_SWD_DMA_CYC_RX_SIZE)
#define R_SWD_DMA_CYC_RX_SIZE(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_CYC_RX_SIZE(ba)))
#define RES_SWD_DMA_CYC_RX_SIZE                              (0x0U)
#define MSB_SWD_DMA_CYC_RX_SIZE                              15
#define LSB_SWD_DMA_CYC_RX_SIZE                              0
#define AADDR_SWD_DMA_CYC_RX_SIZE                            (BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_RX_SIZE)
#define REG_SWD_DMA_CYC_RX_SIZE                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_CYC_RX_SIZE))

#define ADDR_SWD_DMA_AZY_RX_SAPA_SIZE                        (0x84U)
#define A_SWD_DMA_AZY_RX_SAPA_SIZE(ba)                       ((ba) + ADDR_SWD_DMA_AZY_RX_SAPA_SIZE)
#define R_SWD_DMA_AZY_RX_SAPA_SIZE(ba)                       (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_RX_SAPA_SIZE(ba)))
#define RES_SWD_DMA_AZY_RX_SAPA_SIZE                         (0x0U)
#define MSB_SWD_DMA_AZY_RX_SAPA_SIZE                         15
#define LSB_SWD_DMA_AZY_RX_SAPA_SIZE                         0
#define AADDR_SWD_DMA_AZY_RX_SAPA_SIZE                       (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPA_SIZE)
#define REG_SWD_DMA_AZY_RX_SAPA_SIZE                         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_RX_SAPA_SIZE))

#define ADDR_SWD_DMA_AZY_RX_SAPB_SIZE                        (0x86U)
#define A_SWD_DMA_AZY_RX_SAPB_SIZE(ba)                       ((ba) + ADDR_SWD_DMA_AZY_RX_SAPB_SIZE)
#define R_SWD_DMA_AZY_RX_SAPB_SIZE(ba)                       (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_RX_SAPB_SIZE(ba)))
#define RES_SWD_DMA_AZY_RX_SAPB_SIZE                         (0x0U)
#define MSB_SWD_DMA_AZY_RX_SAPB_SIZE                         15
#define LSB_SWD_DMA_AZY_RX_SAPB_SIZE                         0
#define AADDR_SWD_DMA_AZY_RX_SAPB_SIZE                       (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPB_SIZE)
#define REG_SWD_DMA_AZY_RX_SAPB_SIZE                         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_RX_SAPB_SIZE))

#define ADDR_SWD_DMA_AZY_RX_SAPC_SIZE                        (0x88U)
#define A_SWD_DMA_AZY_RX_SAPC_SIZE(ba)                       ((ba) + ADDR_SWD_DMA_AZY_RX_SAPC_SIZE)
#define R_SWD_DMA_AZY_RX_SAPC_SIZE(ba)                       (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_RX_SAPC_SIZE(ba)))
#define RES_SWD_DMA_AZY_RX_SAPC_SIZE                         (0x0U)
#define MSB_SWD_DMA_AZY_RX_SAPC_SIZE                         15
#define LSB_SWD_DMA_AZY_RX_SAPC_SIZE                         0
#define AADDR_SWD_DMA_AZY_RX_SAPC_SIZE                       (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPC_SIZE)
#define REG_SWD_DMA_AZY_RX_SAPC_SIZE                         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_RX_SAPC_SIZE))

#define ADDR_SWD_DMA_SIZES_NEXT_PTR                          (0x8AU)
#define A_SWD_DMA_SIZES_NEXT_PTR(ba)                         ((ba) + ADDR_SWD_DMA_SIZES_NEXT_PTR)
#define R_SWD_DMA_SIZES_NEXT_PTR(ba)                         (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_SIZES_NEXT_PTR(ba)))
#define RES_SWD_DMA_SIZES_NEXT_PTR                           (0x0U)
#define MSB_SWD_DMA_SIZES_NEXT_PTR                           15
#define LSB_SWD_DMA_SIZES_NEXT_PTR                           0
#define AADDR_SWD_DMA_SIZES_NEXT_PTR                         (BASE_ADDR_SWD + ADDR_SWD_DMA_SIZES_NEXT_PTR)
#define REG_SWD_DMA_SIZES_NEXT_PTR                           (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_SIZES_NEXT_PTR))

#define ADDR_SWD_DMA_CYC_TX_NEXT_PTR                         (0x8CU)
#define A_SWD_DMA_CYC_TX_NEXT_PTR(ba)                        ((ba) + ADDR_SWD_DMA_CYC_TX_NEXT_PTR)
#define R_SWD_DMA_CYC_TX_NEXT_PTR(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_CYC_TX_NEXT_PTR(ba)))
#define RES_SWD_DMA_CYC_TX_NEXT_PTR                          (0x0U)
#define MSB_SWD_DMA_CYC_TX_NEXT_PTR                          15
#define LSB_SWD_DMA_CYC_TX_NEXT_PTR                          0
#define AADDR_SWD_DMA_CYC_TX_NEXT_PTR                        (BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_TX_NEXT_PTR)
#define REG_SWD_DMA_CYC_TX_NEXT_PTR                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_CYC_TX_NEXT_PTR))

#define ADDR_SWD_DMA_CYC_RX_NEXT_PTR                         (0x8EU)
#define A_SWD_DMA_CYC_RX_NEXT_PTR(ba)                        ((ba) + ADDR_SWD_DMA_CYC_RX_NEXT_PTR)
#define R_SWD_DMA_CYC_RX_NEXT_PTR(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_CYC_RX_NEXT_PTR(ba)))
#define RES_SWD_DMA_CYC_RX_NEXT_PTR                          (0x0U)
#define MSB_SWD_DMA_CYC_RX_NEXT_PTR                          15
#define LSB_SWD_DMA_CYC_RX_NEXT_PTR                          0
#define AADDR_SWD_DMA_CYC_RX_NEXT_PTR                        (BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_RX_NEXT_PTR)
#define REG_SWD_DMA_CYC_RX_NEXT_PTR                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_CYC_RX_NEXT_PTR))

#define ADDR_SWD_DMA_AZY_TX_NEXT_PTR                         (0x90U)
#define A_SWD_DMA_AZY_TX_NEXT_PTR(ba)                        ((ba) + ADDR_SWD_DMA_AZY_TX_NEXT_PTR)
#define R_SWD_DMA_AZY_TX_NEXT_PTR(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_TX_NEXT_PTR(ba)))
#define RES_SWD_DMA_AZY_TX_NEXT_PTR                          (0x0U)
#define MSB_SWD_DMA_AZY_TX_NEXT_PTR                          15
#define LSB_SWD_DMA_AZY_TX_NEXT_PTR                          0
#define AADDR_SWD_DMA_AZY_TX_NEXT_PTR                        (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_TX_NEXT_PTR)
#define REG_SWD_DMA_AZY_TX_NEXT_PTR                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_TX_NEXT_PTR))

#define ADDR_SWD_DMA_AZY_RX_SAPA_NEXT_PTR                    (0x92U)
#define A_SWD_DMA_AZY_RX_SAPA_NEXT_PTR(ba)                   ((ba) + ADDR_SWD_DMA_AZY_RX_SAPA_NEXT_PTR)
#define R_SWD_DMA_AZY_RX_SAPA_NEXT_PTR(ba)                   (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_RX_SAPA_NEXT_PTR(ba)))
#define RES_SWD_DMA_AZY_RX_SAPA_NEXT_PTR                     (0x0U)
#define MSB_SWD_DMA_AZY_RX_SAPA_NEXT_PTR                     15
#define LSB_SWD_DMA_AZY_RX_SAPA_NEXT_PTR                     0
#define AADDR_SWD_DMA_AZY_RX_SAPA_NEXT_PTR                   (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPA_NEXT_PTR)
#define REG_SWD_DMA_AZY_RX_SAPA_NEXT_PTR                     (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_RX_SAPA_NEXT_PTR))

#define ADDR_SWD_DMA_AZY_RX_SAPB_NEXT_PTR                    (0x94U)
#define A_SWD_DMA_AZY_RX_SAPB_NEXT_PTR(ba)                   ((ba) + ADDR_SWD_DMA_AZY_RX_SAPB_NEXT_PTR)
#define R_SWD_DMA_AZY_RX_SAPB_NEXT_PTR(ba)                   (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_RX_SAPB_NEXT_PTR(ba)))
#define RES_SWD_DMA_AZY_RX_SAPB_NEXT_PTR                     (0x0U)
#define MSB_SWD_DMA_AZY_RX_SAPB_NEXT_PTR                     15
#define LSB_SWD_DMA_AZY_RX_SAPB_NEXT_PTR                     0
#define AADDR_SWD_DMA_AZY_RX_SAPB_NEXT_PTR                   (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPB_NEXT_PTR)
#define REG_SWD_DMA_AZY_RX_SAPB_NEXT_PTR                     (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_RX_SAPB_NEXT_PTR))

#define ADDR_SWD_DMA_AZY_RX_SAPC_NEXT_PTR                    (0x96U)
#define A_SWD_DMA_AZY_RX_SAPC_NEXT_PTR(ba)                   ((ba) + ADDR_SWD_DMA_AZY_RX_SAPC_NEXT_PTR)
#define R_SWD_DMA_AZY_RX_SAPC_NEXT_PTR(ba)                   (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_RX_SAPC_NEXT_PTR(ba)))
#define RES_SWD_DMA_AZY_RX_SAPC_NEXT_PTR                     (0x0U)
#define MSB_SWD_DMA_AZY_RX_SAPC_NEXT_PTR                     15
#define LSB_SWD_DMA_AZY_RX_SAPC_NEXT_PTR                     0
#define AADDR_SWD_DMA_AZY_RX_SAPC_NEXT_PTR                   (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPC_NEXT_PTR)
#define REG_SWD_DMA_AZY_RX_SAPC_NEXT_PTR                     (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_RX_SAPC_NEXT_PTR))

#define ADDR_SWD_DMA_SIZES_LAST_PTR                          (0x98U)
#define A_SWD_DMA_SIZES_LAST_PTR(ba)                         ((ba) + ADDR_SWD_DMA_SIZES_LAST_PTR)
#define R_SWD_DMA_SIZES_LAST_PTR(ba)                         (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_SIZES_LAST_PTR(ba)))
#define RES_SWD_DMA_SIZES_LAST_PTR                           (0x0U)
#define MSB_SWD_DMA_SIZES_LAST_PTR                           15
#define LSB_SWD_DMA_SIZES_LAST_PTR                           0
#define AADDR_SWD_DMA_SIZES_LAST_PTR                         (BASE_ADDR_SWD + ADDR_SWD_DMA_SIZES_LAST_PTR)
#define REG_SWD_DMA_SIZES_LAST_PTR                           (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_SIZES_LAST_PTR))

#define ADDR_SWD_DMA_CYC_TX_LAST_PTR                         (0x9AU)
#define A_SWD_DMA_CYC_TX_LAST_PTR(ba)                        ((ba) + ADDR_SWD_DMA_CYC_TX_LAST_PTR)
#define R_SWD_DMA_CYC_TX_LAST_PTR(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_CYC_TX_LAST_PTR(ba)))
#define RES_SWD_DMA_CYC_TX_LAST_PTR                          (0x0U)
#define MSB_SWD_DMA_CYC_TX_LAST_PTR                          15
#define LSB_SWD_DMA_CYC_TX_LAST_PTR                          0
#define AADDR_SWD_DMA_CYC_TX_LAST_PTR                        (BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_TX_LAST_PTR)
#define REG_SWD_DMA_CYC_TX_LAST_PTR                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_CYC_TX_LAST_PTR))

#define ADDR_SWD_DMA_CYC_RX_LAST_PTR                         (0x9CU)
#define A_SWD_DMA_CYC_RX_LAST_PTR(ba)                        ((ba) + ADDR_SWD_DMA_CYC_RX_LAST_PTR)
#define R_SWD_DMA_CYC_RX_LAST_PTR(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_CYC_RX_LAST_PTR(ba)))
#define RES_SWD_DMA_CYC_RX_LAST_PTR                          (0x0U)
#define MSB_SWD_DMA_CYC_RX_LAST_PTR                          15
#define LSB_SWD_DMA_CYC_RX_LAST_PTR                          0
#define AADDR_SWD_DMA_CYC_RX_LAST_PTR                        (BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_RX_LAST_PTR)
#define REG_SWD_DMA_CYC_RX_LAST_PTR                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_CYC_RX_LAST_PTR))

#define ADDR_SWD_DMA_AZY_TX_LAST_PTR                         (0x9EU)
#define A_SWD_DMA_AZY_TX_LAST_PTR(ba)                        ((ba) + ADDR_SWD_DMA_AZY_TX_LAST_PTR)
#define R_SWD_DMA_AZY_TX_LAST_PTR(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_TX_LAST_PTR(ba)))
#define RES_SWD_DMA_AZY_TX_LAST_PTR                          (0x0U)
#define MSB_SWD_DMA_AZY_TX_LAST_PTR                          15
#define LSB_SWD_DMA_AZY_TX_LAST_PTR                          0
#define AADDR_SWD_DMA_AZY_TX_LAST_PTR                        (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_TX_LAST_PTR)
#define REG_SWD_DMA_AZY_TX_LAST_PTR                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_TX_LAST_PTR))

#define ADDR_SWD_DMA_AZY_RX_SAPA_LAST_PTR                    (0xA0U)
#define A_SWD_DMA_AZY_RX_SAPA_LAST_PTR(ba)                   ((ba) + ADDR_SWD_DMA_AZY_RX_SAPA_LAST_PTR)
#define R_SWD_DMA_AZY_RX_SAPA_LAST_PTR(ba)                   (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_RX_SAPA_LAST_PTR(ba)))
#define RES_SWD_DMA_AZY_RX_SAPA_LAST_PTR                     (0x0U)
#define MSB_SWD_DMA_AZY_RX_SAPA_LAST_PTR                     15
#define LSB_SWD_DMA_AZY_RX_SAPA_LAST_PTR                     0
#define AADDR_SWD_DMA_AZY_RX_SAPA_LAST_PTR                   (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPA_LAST_PTR)
#define REG_SWD_DMA_AZY_RX_SAPA_LAST_PTR                     (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_RX_SAPA_LAST_PTR))

#define ADDR_SWD_DMA_AZY_RX_SAPB_LAST_PTR                    (0xA2U)
#define A_SWD_DMA_AZY_RX_SAPB_LAST_PTR(ba)                   ((ba) + ADDR_SWD_DMA_AZY_RX_SAPB_LAST_PTR)
#define R_SWD_DMA_AZY_RX_SAPB_LAST_PTR(ba)                   (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_RX_SAPB_LAST_PTR(ba)))
#define RES_SWD_DMA_AZY_RX_SAPB_LAST_PTR                     (0x0U)
#define MSB_SWD_DMA_AZY_RX_SAPB_LAST_PTR                     15
#define LSB_SWD_DMA_AZY_RX_SAPB_LAST_PTR                     0
#define AADDR_SWD_DMA_AZY_RX_SAPB_LAST_PTR                   (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPB_LAST_PTR)
#define REG_SWD_DMA_AZY_RX_SAPB_LAST_PTR                     (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_RX_SAPB_LAST_PTR))

#define ADDR_SWD_DMA_AZY_RX_SAPC_LAST_PTR                    (0xA4U)
#define A_SWD_DMA_AZY_RX_SAPC_LAST_PTR(ba)                   ((ba) + ADDR_SWD_DMA_AZY_RX_SAPC_LAST_PTR)
#define R_SWD_DMA_AZY_RX_SAPC_LAST_PTR(ba)                   (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_RX_SAPC_LAST_PTR(ba)))
#define RES_SWD_DMA_AZY_RX_SAPC_LAST_PTR                     (0x0U)
#define MSB_SWD_DMA_AZY_RX_SAPC_LAST_PTR                     15
#define LSB_SWD_DMA_AZY_RX_SAPC_LAST_PTR                     0
#define AADDR_SWD_DMA_AZY_RX_SAPC_LAST_PTR                   (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_RX_SAPC_LAST_PTR)
#define REG_SWD_DMA_AZY_RX_SAPC_LAST_PTR                     (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_RX_SAPC_LAST_PTR))

#define ADDR_SWD_DMA_CYC_TX_REPLACED_PTR                     (0xA6U)
#define A_SWD_DMA_CYC_TX_REPLACED_PTR(ba)                    ((ba) + ADDR_SWD_DMA_CYC_TX_REPLACED_PTR)
#define R_SWD_DMA_CYC_TX_REPLACED_PTR(ba)                    (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_CYC_TX_REPLACED_PTR(ba)))
#define RES_SWD_DMA_CYC_TX_REPLACED_PTR                      (0x0U)
#define MSB_SWD_DMA_CYC_TX_REPLACED_PTR                      15
#define LSB_SWD_DMA_CYC_TX_REPLACED_PTR                      0
#define AADDR_SWD_DMA_CYC_TX_REPLACED_PTR                    (BASE_ADDR_SWD + ADDR_SWD_DMA_CYC_TX_REPLACED_PTR)
#define REG_SWD_DMA_CYC_TX_REPLACED_PTR                      (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_CYC_TX_REPLACED_PTR))

#define ADDR_SWD_DMA_SIZES_REPLACED_PTR                      (0xA8U)
#define A_SWD_DMA_SIZES_REPLACED_PTR(ba)                     ((ba) + ADDR_SWD_DMA_SIZES_REPLACED_PTR)
#define R_SWD_DMA_SIZES_REPLACED_PTR(ba)                     (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_SIZES_REPLACED_PTR(ba)))
#define RES_SWD_DMA_SIZES_REPLACED_PTR                       (0x0U)
#define MSB_SWD_DMA_SIZES_REPLACED_PTR                       15
#define LSB_SWD_DMA_SIZES_REPLACED_PTR                       0
#define AADDR_SWD_DMA_SIZES_REPLACED_PTR                     (BASE_ADDR_SWD + ADDR_SWD_DMA_SIZES_REPLACED_PTR)
#define REG_SWD_DMA_SIZES_REPLACED_PTR                       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_SIZES_REPLACED_PTR))

#define ADDR_SWD_DMA_AZY_TX_REMOVED_PTR                      (0xAAU)
#define A_SWD_DMA_AZY_TX_REMOVED_PTR(ba)                     ((ba) + ADDR_SWD_DMA_AZY_TX_REMOVED_PTR)
#define R_SWD_DMA_AZY_TX_REMOVED_PTR(ba)                     (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_AZY_TX_REMOVED_PTR(ba)))
#define RES_SWD_DMA_AZY_TX_REMOVED_PTR                       (0x0U)
#define MSB_SWD_DMA_AZY_TX_REMOVED_PTR                       15
#define LSB_SWD_DMA_AZY_TX_REMOVED_PTR                       0
#define AADDR_SWD_DMA_AZY_TX_REMOVED_PTR                     (BASE_ADDR_SWD + ADDR_SWD_DMA_AZY_TX_REMOVED_PTR)
#define REG_SWD_DMA_AZY_TX_REMOVED_PTR                       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_AZY_TX_REMOVED_PTR))

#define ADDR_SWD_DMA_ERRORS                                  (0xACU)
#define A_SWD_DMA_ERRORS(ba)                                 ((ba) + ADDR_SWD_DMA_ERRORS)
#define R_SWD_DMA_ERRORS(ba)                                 (*(volatile unsigned short *)((unsigned int)A_SWD_DMA_ERRORS(ba)))
#define RES_SWD_DMA_ERRORS                                   (0x0U)
#define MSB_SWD_DMA_ERRORS                                   10
#define LSB_SWD_DMA_ERRORS                                   0
#define AADDR_SWD_DMA_ERRORS                                 (BASE_ADDR_SWD + ADDR_SWD_DMA_ERRORS)
#define REG_SWD_DMA_ERRORS                                   (*(volatile unsigned short *)((unsigned int)AADDR_SWD_DMA_ERRORS))

#define ADDR_SWD_PE_COMMAND                                  (0xB0U)
#define A_SWD_PE_COMMAND(ba)                                 ((ba) + ADDR_SWD_PE_COMMAND)
#define R_SWD_PE_COMMAND(ba)                                 (*(volatile unsigned short *)((unsigned int)A_SWD_PE_COMMAND(ba)))
#define RES_SWD_PE_COMMAND                                   (0x0U)
#define MSB_SWD_PE_COMMAND                                   12
#define LSB_SWD_PE_COMMAND                                   0
#define AADDR_SWD_PE_COMMAND                                 (BASE_ADDR_SWD + ADDR_SWD_PE_COMMAND)
#define REG_SWD_PE_COMMAND                                   (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_COMMAND))

#define ADDR_SWD_PE_CYC_FRAME_LENGTH                         (0xB2U)
#define A_SWD_PE_CYC_FRAME_LENGTH(ba)                        ((ba) + ADDR_SWD_PE_CYC_FRAME_LENGTH)
#define R_SWD_PE_CYC_FRAME_LENGTH(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_FRAME_LENGTH(ba)))
#define RES_SWD_PE_CYC_FRAME_LENGTH                          (0x0U)
#define MSB_SWD_PE_CYC_FRAME_LENGTH                          10
#define LSB_SWD_PE_CYC_FRAME_LENGTH                          0
#define AADDR_SWD_PE_CYC_FRAME_LENGTH                        (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_FRAME_LENGTH)
#define REG_SWD_PE_CYC_FRAME_LENGTH                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_FRAME_LENGTH))

#define ADDR_SWD_PE_CYC_TIMEOUT_ID                           (0xB4U)
#define A_SWD_PE_CYC_TIMEOUT_ID(ba)                          ((ba) + ADDR_SWD_PE_CYC_TIMEOUT_ID)
#define R_SWD_PE_CYC_TIMEOUT_ID(ba)                          (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_TIMEOUT_ID(ba)))
#define RES_SWD_PE_CYC_TIMEOUT_ID                            (0x0U)
#define MSB_SWD_PE_CYC_TIMEOUT_ID                            8
#define LSB_SWD_PE_CYC_TIMEOUT_ID                            0
#define AADDR_SWD_PE_CYC_TIMEOUT_ID                          (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_TIMEOUT_ID)
#define REG_SWD_PE_CYC_TIMEOUT_ID                            (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_TIMEOUT_ID))

#define ADDR_SWD_PE_CYC_NOT_REPLACED_ID                      (0xB6U)
#define A_SWD_PE_CYC_NOT_REPLACED_ID(ba)                     ((ba) + ADDR_SWD_PE_CYC_NOT_REPLACED_ID)
#define R_SWD_PE_CYC_NOT_REPLACED_ID(ba)                     (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_NOT_REPLACED_ID(ba)))
#define RES_SWD_PE_CYC_NOT_REPLACED_ID                       (0x0U)
#define MSB_SWD_PE_CYC_NOT_REPLACED_ID                       8
#define LSB_SWD_PE_CYC_NOT_REPLACED_ID                       0
#define AADDR_SWD_PE_CYC_NOT_REPLACED_ID                     (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_NOT_REPLACED_ID)
#define REG_SWD_PE_CYC_NOT_REPLACED_ID                       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_NOT_REPLACED_ID))

#define ADDR_SWD_PE_RESULT                                   (0xB8U)
#define A_SWD_PE_RESULT(ba)                                  ((ba) + ADDR_SWD_PE_RESULT)
#define R_SWD_PE_RESULT(ba)                                  (*(volatile unsigned short *)((unsigned int)A_SWD_PE_RESULT(ba)))
#define RES_SWD_PE_RESULT                                    (0x0U)
#define MSB_SWD_PE_RESULT                                    15
#define LSB_SWD_PE_RESULT                                    0
#define AADDR_SWD_PE_RESULT                                  (BASE_ADDR_SWD + ADDR_SWD_PE_RESULT)
#define REG_SWD_PE_RESULT                                    (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_RESULT))

#define ADDR_SWD_PE_CYC_SUCC_RES_CNT                         (0xBAU)
#define A_SWD_PE_CYC_SUCC_RES_CNT(ba)                        ((ba) + ADDR_SWD_PE_CYC_SUCC_RES_CNT)
#define R_SWD_PE_CYC_SUCC_RES_CNT(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_SUCC_RES_CNT(ba)))
#define RES_SWD_PE_CYC_SUCC_RES_CNT                          (0x0U)
#define MSB_SWD_PE_CYC_SUCC_RES_CNT                          3
#define LSB_SWD_PE_CYC_SUCC_RES_CNT                          0
#define AADDR_SWD_PE_CYC_SUCC_RES_CNT                        (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_SUCC_RES_CNT)
#define REG_SWD_PE_CYC_SUCC_RES_CNT                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_SUCC_RES_CNT))

#define ADDR_SWD_EVENTS                                      (0xBEU)
#define A_SWD_EVENTS(ba)                                     ((ba) + ADDR_SWD_EVENTS)
#define R_SWD_EVENTS(ba)                                     (*(volatile unsigned short *)((unsigned int)A_SWD_EVENTS(ba)))
#define RES_SWD_EVENTS                                       (0x0U)
#define MSB_SWD_EVENTS                                       6
#define LSB_SWD_EVENTS                                       0
#define AADDR_SWD_EVENTS                                     (BASE_ADDR_SWD + ADDR_SWD_EVENTS)
#define REG_SWD_EVENTS                                       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_EVENTS))

#define ADDR_SWD_IRQ_STATUS_PE                               (0xC0U)
#define A_SWD_IRQ_STATUS_PE(ba)                              ((ba) + ADDR_SWD_IRQ_STATUS_PE)
#define R_SWD_IRQ_STATUS_PE(ba)                              (*(volatile unsigned short *)((unsigned int)A_SWD_IRQ_STATUS_PE(ba)))
#define RES_SWD_IRQ_STATUS_PE                                (0x120U)
#define MSB_SWD_IRQ_STATUS_PE                                8
#define LSB_SWD_IRQ_STATUS_PE                                0
#define AADDR_SWD_IRQ_STATUS_PE                              (BASE_ADDR_SWD + ADDR_SWD_IRQ_STATUS_PE)
#define REG_SWD_IRQ_STATUS_PE                                (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IRQ_STATUS_PE))

#define ADDR_SWD_IRQ_STATUS_DMA                              (0xC2U)
#define A_SWD_IRQ_STATUS_DMA(ba)                             ((ba) + ADDR_SWD_IRQ_STATUS_DMA)
#define R_SWD_IRQ_STATUS_DMA(ba)                             (*(volatile unsigned short *)((unsigned int)A_SWD_IRQ_STATUS_DMA(ba)))
#define RES_SWD_IRQ_STATUS_DMA                               (0x1555U)
#define MSB_SWD_IRQ_STATUS_DMA                               13
#define LSB_SWD_IRQ_STATUS_DMA                               0
#define AADDR_SWD_IRQ_STATUS_DMA                             (BASE_ADDR_SWD + ADDR_SWD_IRQ_STATUS_DMA)
#define REG_SWD_IRQ_STATUS_DMA                               (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IRQ_STATUS_DMA))

#define ADDR_SWD_IRQ_MASK_PE                                 (0xC4U)
#define A_SWD_IRQ_MASK_PE(ba)                                ((ba) + ADDR_SWD_IRQ_MASK_PE)
#define R_SWD_IRQ_MASK_PE(ba)                                (*(volatile unsigned short *)((unsigned int)A_SWD_IRQ_MASK_PE(ba)))
#define RES_SWD_IRQ_MASK_PE                                  (0x0U)
#define MSB_SWD_IRQ_MASK_PE                                  15
#define LSB_SWD_IRQ_MASK_PE                                  0
#define AADDR_SWD_IRQ_MASK_PE                                (BASE_ADDR_SWD + ADDR_SWD_IRQ_MASK_PE)
#define REG_SWD_IRQ_MASK_PE                                  (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IRQ_MASK_PE))

#define ADDR_SWD_IRQ_MASK_DMA                                (0xC6U)
#define A_SWD_IRQ_MASK_DMA(ba)                               ((ba) + ADDR_SWD_IRQ_MASK_DMA)
#define R_SWD_IRQ_MASK_DMA(ba)                               (*(volatile unsigned short *)((unsigned int)A_SWD_IRQ_MASK_DMA(ba)))
#define RES_SWD_IRQ_MASK_DMA                                 (0x0U)
#define MSB_SWD_IRQ_MASK_DMA                                 15
#define LSB_SWD_IRQ_MASK_DMA                                 0
#define AADDR_SWD_IRQ_MASK_DMA                               (BASE_ADDR_SWD + ADDR_SWD_IRQ_MASK_DMA)
#define REG_SWD_IRQ_MASK_DMA                                 (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IRQ_MASK_DMA))

#define ADDR_SWD_IRQ_NO                                      (0xC8U)
#define A_SWD_IRQ_NO(ba)                                     ((ba) + ADDR_SWD_IRQ_NO)
#define R_SWD_IRQ_NO(ba)                                     (*(volatile unsigned short *)((unsigned int)A_SWD_IRQ_NO(ba)))
#define RES_SWD_IRQ_NO                                       (0x20U)
#define MSB_SWD_IRQ_NO                                       6
#define LSB_SWD_IRQ_NO                                       0
#define AADDR_SWD_IRQ_NO                                     (BASE_ADDR_SWD + ADDR_SWD_IRQ_NO)
#define REG_SWD_IRQ_NO                                       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IRQ_NO))

#define ADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW      (0xCCU)
#define A_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW(ba)     ((ba) + ADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW)
#define R_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW(ba)     (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW(ba)))
#define RES_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW       (0x0U)
#define MSB_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW       15
#define LSB_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW       0
#define AADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW     (BASE_ADDR_SWD + ADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW)
#define REG_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_LW))

#define ADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW      (0xCEU)
#define A_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW(ba)     ((ba) + ADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW)
#define R_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW(ba)     (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW(ba)))
#define RES_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW       (0x0U)
#define MSB_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW       7
#define LSB_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW       0
#define AADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW     (BASE_ADDR_SWD + ADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW)
#define REG_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_DISACK2_DETECT_START_THRESHOLD_HW))

#define ADDR_SWD_INTEGRATOR_DISACK2_THRESHOLD                (0xD0U)
#define A_SWD_INTEGRATOR_DISACK2_THRESHOLD(ba)               ((ba) + ADDR_SWD_INTEGRATOR_DISACK2_THRESHOLD)
#define R_SWD_INTEGRATOR_DISACK2_THRESHOLD(ba)               (*(volatile unsigned short *)((unsigned int)A_SWD_INTEGRATOR_DISACK2_THRESHOLD(ba)))
#define RES_SWD_INTEGRATOR_DISACK2_THRESHOLD                 (0x1U)
#define MSB_SWD_INTEGRATOR_DISACK2_THRESHOLD                 15
#define LSB_SWD_INTEGRATOR_DISACK2_THRESHOLD                 0
#define AADDR_SWD_INTEGRATOR_DISACK2_THRESHOLD               (BASE_ADDR_SWD + ADDR_SWD_INTEGRATOR_DISACK2_THRESHOLD)
#define REG_SWD_INTEGRATOR_DISACK2_THRESHOLD                 (*(volatile unsigned short *)((unsigned int)AADDR_SWD_INTEGRATOR_DISACK2_THRESHOLD))

#define ADDR_SWD_IDLE_DPLL_THRESHOLD_HW                      (0xD2U)
#define A_SWD_IDLE_DPLL_THRESHOLD_HW(ba)                     ((ba) + ADDR_SWD_IDLE_DPLL_THRESHOLD_HW)
#define R_SWD_IDLE_DPLL_THRESHOLD_HW(ba)                     (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_DPLL_THRESHOLD_HW(ba)))
#define RES_SWD_IDLE_DPLL_THRESHOLD_HW                       (0x0U)
#define MSB_SWD_IDLE_DPLL_THRESHOLD_HW                       7
#define LSB_SWD_IDLE_DPLL_THRESHOLD_HW                       0
#define AADDR_SWD_IDLE_DPLL_THRESHOLD_HW                     (BASE_ADDR_SWD + ADDR_SWD_IDLE_DPLL_THRESHOLD_HW)
#define REG_SWD_IDLE_DPLL_THRESHOLD_HW                       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_DPLL_THRESHOLD_HW))

#define ADDR_SWD_IDLE_PE_THRESHOLD_HW                        (0xD4U)
#define A_SWD_IDLE_PE_THRESHOLD_HW(ba)                       ((ba) + ADDR_SWD_IDLE_PE_THRESHOLD_HW)
#define R_SWD_IDLE_PE_THRESHOLD_HW(ba)                       (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_PE_THRESHOLD_HW(ba)))
#define RES_SWD_IDLE_PE_THRESHOLD_HW                         (0x0U)
#define MSB_SWD_IDLE_PE_THRESHOLD_HW                         7
#define LSB_SWD_IDLE_PE_THRESHOLD_HW                         0
#define AADDR_SWD_IDLE_PE_THRESHOLD_HW                       (BASE_ADDR_SWD + ADDR_SWD_IDLE_PE_THRESHOLD_HW)
#define REG_SWD_IDLE_PE_THRESHOLD_HW                         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_PE_THRESHOLD_HW))

#define ADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW              (0xD6U)
#define A_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW(ba)             ((ba) + ADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW)
#define R_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW(ba)             (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW(ba)))
#define RES_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW               (0x0U)
#define MSB_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW               15
#define LSB_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW               0
#define AADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW             (BASE_ADDR_SWD + ADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW)
#define REG_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW               (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_LW))

#define ADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW              (0xD8U)
#define A_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW(ba)             ((ba) + ADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW)
#define R_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW(ba)             (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW(ba)))
#define RES_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW               (0x0U)
#define MSB_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW               7
#define LSB_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW               0
#define AADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW             (BASE_ADDR_SWD + ADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW)
#define REG_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW               (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_DISACK2_SEND_THRESHOLD_HW))

#define ADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW        (0xDAU)
#define A_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW(ba)       ((ba) + ADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW)
#define R_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW(ba)       (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW(ba)))
#define RES_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW         (0x0U)
#define MSB_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW         15
#define LSB_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW         0
#define AADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW       (BASE_ADDR_SWD + ADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW)
#define REG_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_LW))

#define ADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW        (0xDCU)
#define A_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW(ba)       ((ba) + ADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW)
#define R_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW(ba)       (*(volatile unsigned short *)((unsigned int)A_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW(ba)))
#define RES_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW         (0x0U)
#define MSB_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW         7
#define LSB_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW         0
#define AADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW       (BASE_ADDR_SWD + ADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW)
#define REG_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IDLE_DISACK2_DETECT_END_THRESHOLD_HW))

#define ADDR_SWD_TAKEOVER_DATA                               (0xDEU)
#define A_SWD_TAKEOVER_DATA(ba)                              ((ba) + ADDR_SWD_TAKEOVER_DATA)
#define R_SWD_TAKEOVER_DATA(ba)                              (*(volatile unsigned short *)((unsigned int)A_SWD_TAKEOVER_DATA(ba)))
#define RES_SWD_TAKEOVER_DATA                                (0x0U)
#define MSB_SWD_TAKEOVER_DATA                                15
#define LSB_SWD_TAKEOVER_DATA                                0
#define AADDR_SWD_TAKEOVER_DATA                              (BASE_ADDR_SWD + ADDR_SWD_TAKEOVER_DATA)
#define REG_SWD_TAKEOVER_DATA                                (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TAKEOVER_DATA))

#define ADDR_SWD_TAKEOVER_DISACK                             (0xE0U)
#define A_SWD_TAKEOVER_DISACK(ba)                            ((ba) + ADDR_SWD_TAKEOVER_DISACK)
#define R_SWD_TAKEOVER_DISACK(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_TAKEOVER_DISACK(ba)))
#define RES_SWD_TAKEOVER_DISACK                              (0x0U)
#define MSB_SWD_TAKEOVER_DISACK                              15
#define LSB_SWD_TAKEOVER_DISACK                              0
#define AADDR_SWD_TAKEOVER_DISACK                            (BASE_ADDR_SWD + ADDR_SWD_TAKEOVER_DISACK)
#define REG_SWD_TAKEOVER_DISACK                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TAKEOVER_DISACK))

#define ADDR_SWD_TX_DISACK2_LENGTH                           (0xE2U)
#define A_SWD_TX_DISACK2_LENGTH(ba)                          ((ba) + ADDR_SWD_TX_DISACK2_LENGTH)
#define R_SWD_TX_DISACK2_LENGTH(ba)                          (*(volatile unsigned short *)((unsigned int)A_SWD_TX_DISACK2_LENGTH(ba)))
#define RES_SWD_TX_DISACK2_LENGTH                            (0xaU)
#define MSB_SWD_TX_DISACK2_LENGTH                            7
#define LSB_SWD_TX_DISACK2_LENGTH                            0
#define AADDR_SWD_TX_DISACK2_LENGTH                          (BASE_ADDR_SWD + ADDR_SWD_TX_DISACK2_LENGTH)
#define REG_SWD_TX_DISACK2_LENGTH                            (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TX_DISACK2_LENGTH))

#define ADDR_SWD_PE_CONFIG_HW                                (0xE4U)
#define A_SWD_PE_CONFIG_HW(ba)                               ((ba) + ADDR_SWD_PE_CONFIG_HW)
#define R_SWD_PE_CONFIG_HW(ba)                               (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CONFIG_HW(ba)))
#define RES_SWD_PE_CONFIG_HW                                 (0x3U)
#define MSB_SWD_PE_CONFIG_HW                                 8
#define LSB_SWD_PE_CONFIG_HW                                 0
#define AADDR_SWD_PE_CONFIG_HW                               (BASE_ADDR_SWD + ADDR_SWD_PE_CONFIG_HW)
#define REG_SWD_PE_CONFIG_HW                                 (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CONFIG_HW))

#define ADDR_SWD_STATUS2_MASK_OFFSET                         (0xE6U)
#define A_SWD_STATUS2_MASK_OFFSET(ba)                        ((ba) + ADDR_SWD_STATUS2_MASK_OFFSET)
#define R_SWD_STATUS2_MASK_OFFSET(ba)                        (*(volatile unsigned short *)((unsigned int)A_SWD_STATUS2_MASK_OFFSET(ba)))
#define RES_SWD_STATUS2_MASK_OFFSET                          (0x0U)
#define MSB_SWD_STATUS2_MASK_OFFSET                          15
#define LSB_SWD_STATUS2_MASK_OFFSET                          0
#define AADDR_SWD_STATUS2_MASK_OFFSET                        (BASE_ADDR_SWD + ADDR_SWD_STATUS2_MASK_OFFSET)
#define REG_SWD_STATUS2_MASK_OFFSET                          (*(volatile unsigned short *)((unsigned int)AADDR_SWD_STATUS2_MASK_OFFSET))

#define ADDR_SWD_STATUS2_COMMAND                             (0xE8U)
#define A_SWD_STATUS2_COMMAND(ba)                            ((ba) + ADDR_SWD_STATUS2_COMMAND)
#define R_SWD_STATUS2_COMMAND(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_STATUS2_COMMAND(ba)))
#define RES_SWD_STATUS2_COMMAND                              (0x0U)
#define MSB_SWD_STATUS2_COMMAND                              0
#define LSB_SWD_STATUS2_COMMAND                              0
#define AADDR_SWD_STATUS2_COMMAND                            (BASE_ADDR_SWD + ADDR_SWD_STATUS2_COMMAND)
#define REG_SWD_STATUS2_COMMAND                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_STATUS2_COMMAND))

#define ADDR_SWD_STATUS2_NODES                               (0xEAU)
#define A_SWD_STATUS2_NODES(ba)                              ((ba) + ADDR_SWD_STATUS2_NODES)
#define R_SWD_STATUS2_NODES(ba)                              (*(volatile unsigned short *)((unsigned int)A_SWD_STATUS2_NODES(ba)))
#define RES_SWD_STATUS2_NODES                                (0x0U)
#define MSB_SWD_STATUS2_NODES                                8
#define LSB_SWD_STATUS2_NODES                                0
#define AADDR_SWD_STATUS2_NODES                              (BASE_ADDR_SWD + ADDR_SWD_STATUS2_NODES)
#define REG_SWD_STATUS2_NODES                                (*(volatile unsigned short *)((unsigned int)AADDR_SWD_STATUS2_NODES))

#define ADDR_SWD_IRQ_STATUS_COMM                             (0xECU)
#define A_SWD_IRQ_STATUS_COMM(ba)                            ((ba) + ADDR_SWD_IRQ_STATUS_COMM)
#define R_SWD_IRQ_STATUS_COMM(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_IRQ_STATUS_COMM(ba)))
#define RES_SWD_IRQ_STATUS_COMM                              (0x0U)
#define MSB_SWD_IRQ_STATUS_COMM                              5
#define LSB_SWD_IRQ_STATUS_COMM                              0
#define AADDR_SWD_IRQ_STATUS_COMM                            (BASE_ADDR_SWD + ADDR_SWD_IRQ_STATUS_COMM)
#define REG_SWD_IRQ_STATUS_COMM                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IRQ_STATUS_COMM))

#define ADDR_SWD_IRQ_MASK_COMM                               (0xEEU)
#define A_SWD_IRQ_MASK_COMM(ba)                              ((ba) + ADDR_SWD_IRQ_MASK_COMM)
#define R_SWD_IRQ_MASK_COMM(ba)                              (*(volatile unsigned short *)((unsigned int)A_SWD_IRQ_MASK_COMM(ba)))
#define RES_SWD_IRQ_MASK_COMM                                (0x0U)
#define MSB_SWD_IRQ_MASK_COMM                                15
#define LSB_SWD_IRQ_MASK_COMM                                0
#define AADDR_SWD_IRQ_MASK_COMM                              (BASE_ADDR_SWD + ADDR_SWD_IRQ_MASK_COMM)
#define REG_SWD_IRQ_MASK_COMM                                (*(volatile unsigned short *)((unsigned int)AADDR_SWD_IRQ_MASK_COMM))

#define ADDR_SWD_TAKEOVER_DISACK2                            (0xF0U)
#define A_SWD_TAKEOVER_DISACK2(ba)                           ((ba) + ADDR_SWD_TAKEOVER_DISACK2)
#define R_SWD_TAKEOVER_DISACK2(ba)                           (*(volatile unsigned short *)((unsigned int)A_SWD_TAKEOVER_DISACK2(ba)))
#define RES_SWD_TAKEOVER_DISACK2                             (0x0U)
#define MSB_SWD_TAKEOVER_DISACK2                             15
#define LSB_SWD_TAKEOVER_DISACK2                             0
#define AADDR_SWD_TAKEOVER_DISACK2                           (BASE_ADDR_SWD + ADDR_SWD_TAKEOVER_DISACK2)
#define REG_SWD_TAKEOVER_DISACK2                             (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TAKEOVER_DISACK2))

#define ADDR_SWD_PE_CYC_RX_CUT_START2                        (0xF2U)
#define A_SWD_PE_CYC_RX_CUT_START2(ba)                       ((ba) + ADDR_SWD_PE_CYC_RX_CUT_START2)
#define R_SWD_PE_CYC_RX_CUT_START2(ba)                       (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_RX_CUT_START2(ba)))
#define RES_SWD_PE_CYC_RX_CUT_START2                         (0x0U)
#define MSB_SWD_PE_CYC_RX_CUT_START2                         10
#define LSB_SWD_PE_CYC_RX_CUT_START2                         0
#define AADDR_SWD_PE_CYC_RX_CUT_START2                       (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_START2)
#define REG_SWD_PE_CYC_RX_CUT_START2                         (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_RX_CUT_START2))

#define ADDR_SWD_PE_CYC_RX_CUT_LENGTH2                       (0xF4U)
#define A_SWD_PE_CYC_RX_CUT_LENGTH2(ba)                      ((ba) + ADDR_SWD_PE_CYC_RX_CUT_LENGTH2)
#define R_SWD_PE_CYC_RX_CUT_LENGTH2(ba)                      (*(volatile unsigned short *)((unsigned int)A_SWD_PE_CYC_RX_CUT_LENGTH2(ba)))
#define RES_SWD_PE_CYC_RX_CUT_LENGTH2                        (0x3ffU)
#define MSB_SWD_PE_CYC_RX_CUT_LENGTH2                        10
#define LSB_SWD_PE_CYC_RX_CUT_LENGTH2                        0
#define AADDR_SWD_PE_CYC_RX_CUT_LENGTH2                      (BASE_ADDR_SWD + ADDR_SWD_PE_CYC_RX_CUT_LENGTH2)
#define REG_SWD_PE_CYC_RX_CUT_LENGTH2                        (*(volatile unsigned short *)((unsigned int)AADDR_SWD_PE_CYC_RX_CUT_LENGTH2))

#define ADDR_SWD_REPEATER_IDLE_STATE_IN                      (0xF6U)
#define A_SWD_REPEATER_IDLE_STATE_IN(ba)                     ((ba) + ADDR_SWD_REPEATER_IDLE_STATE_IN)
#define R_SWD_REPEATER_IDLE_STATE_IN(ba)                     (*(volatile unsigned short *)((unsigned int)A_SWD_REPEATER_IDLE_STATE_IN(ba)))
#define RES_SWD_REPEATER_IDLE_STATE_IN                       (0x0U)
#define MSB_SWD_REPEATER_IDLE_STATE_IN                       0
#define LSB_SWD_REPEATER_IDLE_STATE_IN                       0
#define AADDR_SWD_REPEATER_IDLE_STATE_IN                     (BASE_ADDR_SWD + ADDR_SWD_REPEATER_IDLE_STATE_IN)
#define REG_SWD_REPEATER_IDLE_STATE_IN                       (*(volatile unsigned short *)((unsigned int)AADDR_SWD_REPEATER_IDLE_STATE_IN))

#define ADDR_SWD_REPEATER_IDLE_STATE_OUT                     (0xF8U)
#define A_SWD_REPEATER_IDLE_STATE_OUT(ba)                    ((ba) + ADDR_SWD_REPEATER_IDLE_STATE_OUT)
#define R_SWD_REPEATER_IDLE_STATE_OUT(ba)                    (*(volatile unsigned short *)((unsigned int)A_SWD_REPEATER_IDLE_STATE_OUT(ba)))
#define RES_SWD_REPEATER_IDLE_STATE_OUT                      (0x0U)
#define MSB_SWD_REPEATER_IDLE_STATE_OUT                      1
#define LSB_SWD_REPEATER_IDLE_STATE_OUT                      0
#define AADDR_SWD_REPEATER_IDLE_STATE_OUT                    (BASE_ADDR_SWD + ADDR_SWD_REPEATER_IDLE_STATE_OUT)
#define REG_SWD_REPEATER_IDLE_STATE_OUT                      (*(volatile unsigned short *)((unsigned int)AADDR_SWD_REPEATER_IDLE_STATE_OUT))

#define ADDR_SWD_TX_STOP_BIT_EXT                             (0xFAU)
#define A_SWD_TX_STOP_BIT_EXT(ba)                            ((ba) + ADDR_SWD_TX_STOP_BIT_EXT)
#define R_SWD_TX_STOP_BIT_EXT(ba)                            (*(volatile unsigned short *)((unsigned int)A_SWD_TX_STOP_BIT_EXT(ba)))
#define RES_SWD_TX_STOP_BIT_EXT                              (0x0U)
#define MSB_SWD_TX_STOP_BIT_EXT                              15
#define LSB_SWD_TX_STOP_BIT_EXT                              0
#define AADDR_SWD_TX_STOP_BIT_EXT                            (BASE_ADDR_SWD + ADDR_SWD_TX_STOP_BIT_EXT)
#define REG_SWD_TX_STOP_BIT_EXT                              (*(volatile unsigned short *)((unsigned int)AADDR_SWD_TX_STOP_BIT_EXT))




#endif
