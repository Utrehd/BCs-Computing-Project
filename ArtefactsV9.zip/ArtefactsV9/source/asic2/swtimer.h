/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         swtimer.h
*
* @brief        Software Timers (SWTIMER) HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_SWTIMER_H
#define HAVE_SWTIMER_H

/**
 * \example example_swtimer.c
 * This is an example of how to use SWTIMER to generate interrupt every 1ms.
 */
 
/**
 * \defgroup swtimer ASIC2 Software Timers (SWTIMER) HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control Software Timers (SWTIMER)
 *
 * \details See code example: @include example_swtimer.c
 */
/**@{*/ 

#include "device.h"

#include "swtimer_bf.h"
#include "swtimer_irq.h"


#define   SUBTIMERS   (SWTIMER_NUM_IRQS >> 1)


/* ############################################################################ */
/**
 * \brief This is an enum class for SWTIMER to identify each subtimer (SWSUBTIMER)
 *
 * \ingroup swtimer 
 */ 
typedef enum {
  /**
   * Identifier for SWSUBTIMER_0
   */ 
	SWSUBTIMER_0  = 0,
  /**
   * Identifier for SWSUBTIMER_1
   */ 
	SWSUBTIMER_1  = 1,
  /**
   * Identifier for SWSUBTIMER_2
   */ 
	SWSUBTIMER_2  = 2,
  /**
   * Identifier for SWSUBTIMER_3
   */ 
	SWSUBTIMER_3  = 3,
} swtimer_sub_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for SWTIMER to identify reload commands
 *
 * \ingroup swtimer 
 */ 
typedef enum {
  /**
   * Identify counter 0
   */ 
	SWSUBTIMER_RESTART_0    = (1 <<           SWSUBTIMER_0),
  /**
   * Identify counter 1
   */ 
	SWSUBTIMER_RESTART_1    = (1 <<           SWSUBTIMER_1),
  /**
   * Identify counter 2
   */ 
	SWSUBTIMER_RESTART_2    = (1 <<           SWSUBTIMER_2),
  /**
   * Identify counter 3
   */ 
	SWSUBTIMER_RESTART_3    = (1 <<           SWSUBTIMER_3),
  /**
   * Identify predivider 0
   */ 
	SWSUBPRETIMER_RESTART_0 = (1 <<(SUBTIMERS + SWSUBTIMER_0)),
  /**
   * Identify predivider 1
   */ 
	SWSUBPRETIMER_RESTART_1 = (1 <<(SUBTIMERS + SWSUBTIMER_1)),
  /**
   * Identify predivider 2
   */ 
	SWSUBPRETIMER_RESTART_2 = (1 <<(SUBTIMERS + SWSUBTIMER_2)),
  /**
   * Identify predivider 3
   */ 
	SWSUBPRETIMER_RESTART_3 = (1 <<(SUBTIMERS + SWSUBTIMER_3)),
} swtimer_cmd_t;



/* ############################################################################ */
/**
 * \brief This is an enum class for SWTIMER to identify cascades
 *
 * \ingroup swtimer 
 */ 
typedef enum {
  /**
   * Identify cascade sub0 and cascade sub1
   */ 
  SWTIMER_CASCADE_SUB0_SUB1 = 8,
  /**
   * Identify cascade sub2 and cascade sub3
   */ 
  SWTIMER_CASCADE_SUB2_SUB3 = 9,
} swtimer_cascade_t;

/* ======================================================================= */
/* MODULE HANDLING                                                         */
/* ======================================================================= */

/* ############################################################################ */
/**
 * \brief Function to initialize SWTIMER
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 */ 
void swtimer_init(swtimer_num_t nr);


/* ############################################################################ */
/**
 * \brief Function to set SWTIMER command
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param command           Set desired command
 *                          \see swtimer_cmd_t
 *
 *                          \note The COMMAND register will be reset by hardware
 */ 
void swtimer_set_command(swtimer_num_t nr, swtimer_cmd_t command);


/* ############################################################################ */
/**
 * \brief Function to enable SWTIMER
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param swtimer_dev       Select subtimer
 *                          \see swtimer_sub_t
 * 
 * \param enable            1: counter and prescaler selected are enabled
 */ 
void swtimer_enable(swtimer_num_t nr, swtimer_sub_t swtimer_dev, bool enable);


/* ############################################################################ */
/**
 * \brief Function to enable SWTIMER cascade
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param cascade           Select cascade
 *                          \see swtimer_cascade_t
 * 
 * \param enable            0: swtimer0 and swtimer1 are individual 16 bit timers <br>
 *                          1: swtimer1 counter will be increased when swtimer0 counter is zero <br>
 *                          (swtimer1 predivider has no effect, but might be used)
 */ 
void swtimer_cascade_enable(swtimer_num_t nr,swtimer_cascade_t cascade, bool enable);


/* ############################################################################ */
/**
 * \brief Function to enable SWTIMER autoreload
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param swtimer_dev       Select subtimer
 *                          \see swtimer_sub_t
 * 
 * \param enable            1: auto reload for selected counter is enabled <br> 
 *                          0: auto reload for selected counter is disabled
 */ 
void swtimer_autoreload_enable(swtimer_num_t nr, swtimer_sub_t swtimer_dev, bool enable);


/* ############################################################################ */
/**
 * \brief Function to set SWTIMER counter reload
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param swtimer_dev       Select subtimer
 *                          \see swtimer_sub_t
 * 
 * \param val               Counter reload value (cnt_reload_val = clock cycles -1)
 */ 
void swtimer_set_counter_reload(swtimer_num_t nr, swtimer_sub_t swtimer_dev, uint16_t val);


/* ############################################################################ */
/**
 * \brief Function to set SWTIMER prescaler reload
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param swtimer_dev       Select subtimer
 *                          \see swtimer_sub_t
 * 
 * \param val               Predivider reload value (div_reload_val = clock cycles -1)
 */ 
void swtimer_set_prescaler_reload(swtimer_num_t nr, swtimer_sub_t swtimer_dev, uint16_t val);


/* ############################################################################ */
/**
 * \brief Function to get SWTIMER counter value
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param swtimer_dev       Select subtimer
 *                          \see swtimer_sub_t
 * 
 * \return                  Current counter value (clock cycles = cnt_val +1)
 */ 
uint16_t swtimer_get_counter_value(swtimer_num_t nr, swtimer_sub_t swtimer_dev);


/* ############################################################################ */
/**
 * \brief Function to get SWTIMER counter reload value
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param swtimer_dev       Select subtimer
 *                          \see swtimer_sub_t
 * 
 * \return                  Current counter reload value (cnt_reload_val = clock cycles -1)
 */ 
uint16_t swtimer_get_reload_value(swtimer_num_t nr, swtimer_sub_t swtimer_dev);


/* ############################################################################ */
/**
 * \brief Function to enable SWTIMER Non-Maskable Interrupt
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param enable            1: enable NMI for corresponding CPU when counter is zero
 */ 
void swtimer_set_nmi_enable(swtimer_num_t nr, bool enable);


/* ############################################################################ */
/**
 * \brief Function to enable SWTIMER SWD synchronization
 *
 * \ingroup swtimer 
 * 
 * \param enable            1: enable SWD sync input when counter is zero (SWTIMER0 instance only)
 */ 
void swtimer0_set_set_swd_sync_enable(bool enable);

/* ======================================================================= */
/* INTERRUPT CALLBACKS                                                     */
/* ======================================================================= */

typedef void (*swtimer_callback_t) (void); ///< Declaration of callback function pointer

/* ############################################################################ */
/**
 * \brief Function to set external SWTIMER Interrupt Handler
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param callback          Desired external Interrupt Handler
 */ 
void swtimer_use_ext_irq_handler(swtimer_num_t nr, swtimer_callback_t callback);


/* ############################################################################ */
/**
 * \brief Function to set external SWTIMER Interrupt Handler to an individual interrupt source
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param irq               Vector number of interrupt
 *                          \see swtimer_irq_t
 * 
 * \param callback          Desired external Interrupt Handler
 */ 
void swtimer_register(swtimer_num_t nr, swtimer_irq_t irq, swtimer_callback_t callback);

/* ======================================================================= */
/* INTERRUPT HANDLING                                                      */
/* ======================================================================= */

/* ############################################################################ */
/**
 * \brief Function to enable SWTIMER Interrupt Request (IRQ)
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param irq               Vector number of interrupt
 *                          \see swtimer_irq_t
 * 
 * \param enable            Enable irq source: 1: enabled, 0: disabled
 */ 
void swtimer_enable_irq(swtimer_num_t nr, swtimer_irq_t irq, bool enable);


/* ############################################################################ */
/**
 * \brief Function to clear SWTIMER Interrupt Request (IRQ)
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param irq               Vector number of interrupt
 *                          \see swtimer_irq_t
 */ 
void swtimer_clear_irq(swtimer_num_t nr, swtimer_irq_t irq);


/* ############################################################################ */
/**
 * \brief Function to get SWTIMER Interrupt Request (IRQ) status
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \return                  Current interrupt status
 *                          \see swtimer_irq_status_t
 */ 
swtimer_irq_status_t swtimer_get_irq_status(swtimer_num_t nr);


/* ############################################################################ */
/**
 * \brief Function to get SWTIMER Interrupt Request (IRQ) mask
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 *
 * \return                  Enable irq source: 1: enabled, 0: disabled
 */ 
uint16_t swtimer_get_irq_mask(swtimer_num_t nr);


/* ############################################################################ */
/**
 * \brief Function to clear SWTIMER all Interrupt Requests (IRQs)
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 */ 
void swtimer_clear_all_irq_events(swtimer_num_t nr);


/* ############################################################################ */
/**
 * \brief Function to get SWTIMER next pending interrupt
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \return                  Vector number of interrupt
 *                          \see swtimer_irq_t
 *
 *                          \note Vector number of enabled pending interrupt with highest priority (smallest vector number) <br>
 *                                When no irq is pending the first unused irq number is returned
 */ 
swtimer_irq_t swtimer_get_next_pending_irq(swtimer_num_t nr);


/* ############################################################################ */
/**
 * \brief Function to clear SWTIMER interrupt event
 *
 * \ingroup swtimer 
 * 
 * \param nr                Select SWTIMER instance
 *                          \see swtimer_num_t
 * 
 * \param vno               Vector number of interrupt event to clear
 */ 
void swtimer_set_irq_vno(swtimer_num_t nr, swtimer_irq_t vno);

/**@{*/ 
#endif /* HAVE_SWTIMER_H */

