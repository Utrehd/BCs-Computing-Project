/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         tsu.h
*
* @brief        TSU Module HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_TSU_H
#define HAVE_TSU_H

#include "device.h"
#include "tsu_irq.h"
#include "tsu_bf.h"
#include "utils.h"

/**
 * \example example_tsu.c
 * This is an example of how to use TSU block.
 */

/**
 * \defgroup tsu ASIC2 TSU Module HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control TSU Module
 */
/**@{*/ 

#define SYNC_NO 12

/* ############################################################################ */
/** 
 * \brief Sync Pulse Mapping
 *
 * \ingroup tsu
 */
typedef enum {
  SYNC_GEN_0          = (1 << 0),
  /**
   * sync_out[0] - used by TSU - set parameters to itself
   */
  SYNC_GEN_TSU        = SYNC_GEN_0,
 
 
  SYNC_GEN_1          = (1 << 1),
  /**
   * sync_out[1] - used by SWD_PM - starts cyclic frame
   */
  SYNC_GEN_SWD        = SYNC_GEN_1,
  
  
  SYNC_GEN_2          = (1 << 2),
  /**
   * sync_out[2] - used by GPIO - captures inputs and sets outputs
   */
  SYNC_GEN_GPIO0      = SYNC_GEN_2,
  
  
  SYNC_GEN_3          = (1 << 3),
  /**
   * sync_out[3] - used by GPIO - captures inputs and sets outputs
   * Both sync outs are ored together to enable
   * two IO transfers per bus cycle.
   */
  SYNC_GEN_GPIO1      = SYNC_GEN_3,
  
  
  SYNC_GEN_4          = (1 << 4),
  /** 
   * sync_out[4] - used by PWMN - captures pwm phase
   */
  SYNC_GEN_PWMN       = SYNC_GEN_4,
  

  SYNC_GEN_5          = (1 << 5),
  /**
   * sync_out[5] - used by USI0 - starts transmission
   */
  SYNC_GEN_USI0       = SYNC_GEN_5,
  
  
  SYNC_GEN_6          = (1 << 6),
  /**
   * sync_out[6] - used by USI1 - starts transmission
   */
  SYNC_GEN_USI1       = SYNC_GEN_6,
  
  
  SYNC_GEN_7          = (1 << 7),
  /**
   * sync_out[7] - used by AOUT_CTRL - set DAC value
   */
  SYNC_GEN_AOUT_CTRL  = SYNC_GEN_7,
  
  
  SYNC_GEN_8          = (1 << 8),
  /**
   * sync_out[8] - used by CCTIMER0 - see CCTIMER32
   */
  SYNC_GEN_CCTIMER0   = SYNC_GEN_8,


  SYNC_GEN_9          = (1 << 9),
  /**
   * sync_out[9] - used by CCTIMER1 - see CCTIMER32
   */
  SYNC_GEN_CCTIMER1   = SYNC_GEN_9,


  SYNC_GEN_10         = (1 << 10),
  /**
   * sync_out[10] / sync_out_ext[0] - used by IOMUX - external sync 0
   */
  SYNC_GEN_EXT0       = SYNC_GEN_10,


  SYNC_GEN_11         = (1 << 11),
  /**
   * sync_out[11] / sync_out_ext[1] - used by IOMUX - external sync 1
   */
  SYNC_GEN_EXT1       = SYNC_GEN_11,
} tsu_sync_gen_t;

#define SYNC_IN_DIS                         0 ///< 00: sync input disabled
#define SYNC_IN_EXT_RISE                    1 ///< 01: triggers on rising edge of sync_in_ext
#define SYNC_IN_EXT_FALL                    2 ///< 10: "" falling edge ""
#define SYNC_IN_EXT_ANY_EDGE                3 ///< 11: "" both edges ""
                                            
#define SYNC_GEN_MODE_DIS                   0 ///< 00 : Periodic sync generation disabled.
#define SYNC_GEN_MODE_BASE_ONLY             1 ///< 01: The sync generator N must only match the base period.
#define SYNC_GEN_MODE_BASE_SUB_P0           2 ///< 10:The sync generator N must match the base period and SUB_PHASE.p0
#define SYNC_GEN_MODE_BASE_SUB_P1           3 ///< 11:The sync generator N must match the base period and SUB_PHASE.p1
                                            
#define RWS_CMD_ABORT                       0 ///< 0: abort current command.
#define RWS_CMD_READ_SYNC                   1 ///< 1 : software read sync. Performed immediately.
#define RWS_CMD_WRITE_SYNC                  2 ///< 2 : software write sync. Performed immediately.
#define RWS_CMD_SYNC0_READ                  3 ///< 3 : sync_out[0] read sync. : Triggered by next sync_out[0] event
#define RWS_CMD_SYNC0_WRITE                 4 ///< 4 : sync_out[0] write sync
#define RWS_CMD_SYNC_IN_EXT_READ            5 ///< 5: sync_in_ext read sync
#define RWS_CMD_SYNC_IN_EXT_WRITE           6 ///< 6: sync_in_ext write sync: A write sync is performed when the next sync event occurs on the sync input.
#define RWS_CMD_SYNC_IN_EXT_WRITE_REPEAT    7 ///< 7: same as 6, but command is automatically repeated until an abort


// functions accessing comm_clk domain registers


/* ############################################################################ */
/**
 * \brief Get RWS status
 *
 * \ingroup tsu tsu 
 * 
 * \return 0 : idle <br>
 *         1 : busy, transfer in progress or waiting for sync event<br>
 */ 
uint16_t tsu_get_rws_status(void);


/* ############################################################################ */
/**
 * \brief Get transfer status
 *
 * \ingroup tsu  
 * 
 * \param void 
 * 
 * \return 0: idle, no transfer is in progress<br>
 *         1: transfer pending
 */ 
uint16_t tsu_get_transfer_status(void);

// write


/* ############################################################################ */
/**
 * \brief Set Timebase increment update registers
 *
 * The used timebase increment is updated with the values below when a sync_out[0] event occurs. In case a
 * RWS_* write sync occurs simultaneously with the sync_out[0] event, the values from the RWS registers will
 * be used.
 *
 * \ingroup tsu  
 * 
 * \param up_timebase_inc increment step value
 */ 
void tsu_set_up_timebase_inc(uint32_t up_timebase_inc);


/* ############################################################################ */
/**
 * \brief Set TSU configuration
 *
 * \ingroup tsu  
 * 
 * \param config 0b -> enable - 0   : timebase is stopped, i.e. not incremented <br>
 *               1b -> up_tb_inc_s0 : 1: update timebase_inc on sync[0] event <br>
 */ 
void tsu_set_cfg(uint16_t config);


/* ############################################################################ */
/**
 * \brief Set timebase modulo
 *
 * \ingroup tsu  
 * 
 * \param cfg_timebase_modulus  Selects the bit of the timebase[tb_mod] i.e. timebase[63..0] whose
 *                              overflow is used to advance the base period.
 */ 
void tsu_set_cfg_timebase_modulus(uint16_t cfg_timebase_modulus);


/* ############################################################################ */
/**
 * \brief Set base period reload
 *
 * \ingroup tsu  
 * 
 * \param cfg_base_period_reload (base_phase_width-1:0) The base period counter counts from this
 *                               value to 0.
 */ 
void tsu_set_cfg_base_period_reload(uint16_t cfg_base_period_reload);


/* ############################################################################ */
/**
 * \brief Set sub periods
 *
 * \ingroup tsu  
 * 
 * \param p0_max (p0_width -1:0) The counter SUB_PHASE.p0 counts from this value to 0.
 * 
 * \param p1_max (( p1_width+p0_width -1): p0_width ) The counter SUB_PHASE.p1
 *               counts from this value to 0.
 */ 
void tsu_set_cfg_sub_period_reload(uint16_t p0_max, uint16_t p1_max);


/* ############################################################################ */
/**
 * \brief Setup configuration for external synchonization signals
 *
 * \ingroup tsu  
 * 
 * \param polarity0 active polarity of sync_out_ext[0]
 * 
 * \param length0   duration of the sync_out_ext[0] pulse in comm_clk cycles = {1..127}
 * 
 * \param polarity1 active polarity of sync_out_ext[1]
 * 
 * \param length1   duration of the sync_out_ext[1] pulse in comm_clk cycles = {1..127}
 */ 
void tsu_set_cfg_sync_out_ext(uint8_t polarity0, uint8_t length0, uint8_t polarity1, uint8_t length1);


/* ############################################################################ */
/**
 * \brief Setup configuration for synchronization inputs
 *
 * \ingroup tsu  
 * 
 * \param cfg_sync_in configuration for the sync inputs: <br>
 *                    00: SYNC_IN_DIS - sync input disabled <br>
 *                    01: SYNC_IN_EXT_RISE - triggers on rising edge of sync_in_ext <br>
 *                    10: SYNC_IN_EXT_FALL - triggers on falling edge of sync_in_ext <br>
 *                    11: SYNC_IN_EXT_ANY_EDGE - triggers on both edge of sync_in_ext <br>
 */ 
void tsu_set_cfg_sync_in(uint16_t cfg_sync_in);



/* ############################################################################ */
/**
 * \brief Set synchronization enable bits
 *
 * \ingroup tsu  
 * 
 * \param cfg_sync_enable 1: corresponding sync generator enabled <br>
 *                        For N = {0..  sync_no -1} (N corresponds to the sync pulse sync_out[N]) <br>
 *                        
 * \note  sync_en = 1 and mode != 00 -> use tsu_set_cfg_sync_in()
 */ 
void tsu_set_cfg_sync_enable(uint16_t cfg_sync_enable);


/* ############################################################################ */
/**
 * \brief Set synchornization base phase for specific sync. output
 *
 * \ingroup tsu  
 * 
 * \param sync the number of synchronization generator
 * 
 * \param cfg_sync_base_phase Phase match for sync generator (sync).<br>
 *                            The TIMEBASE must match this value for a sync event to occur.<br>
 *
 * \note The sync generators check their condition only if the base phase changes its value. Therefore only at a
 *       base phase change sync strobes are generated even if the condition for generating a sync strobe is true!
 *       This may affect the system behavior at the beginning (when CFG.enable is set to 1). <br>
 *
 * Example: If the base phase has a value of 5 and sync generator X is configured to generate a sync strobe if
 *          the base phase is 5. If you enable the system no sync strobe is generated by sync generator X because no
 *          base phase change occurs in which the result of the base phase is 5. The best solution is to start with a base
 *          period value which is not used by a sync strobe.
 */ 
void tsu_set_cfg_sync_base_phase(uint16_t sync, uint16_t cfg_sync_base_phase);


/* ############################################################################ */
/**
 * \brief Set configuration of sync sub phases and modes for TSU
 *
 * \ingroup tsu  
 * 
 * \param sync   the number of synchronization generator
 * 
 * \param mode   00: Periodic sync generation disabled. <br>
 *               01: The sync generator N must only match the base period. <br>
 *               10:The sync generator N must match the base period and SUB_PHASE.p0 <br>
 *               11:The sync generator N must match the base period and SUB_PHASE.p1 <br>
 * 
 * \param sub_phase ( p_max_width+1:2) Value for matching the SUB_PHASE selected above
 */ 
void tsu_set_cfg_sync_sub_phase(uint16_t sync, uint8_t mode, uint16_t sub_phase);


/* ############################################################################ */
/**
 * \brief generate sync pulse (can generate more sync pulses simultaneously)
 *
 * \ingroup tsu  
 * 
 * \param cmd_sync_out ( sync_no- 1:0) Writing a '1' will cause a sync pulse on the
 *                     corresponding sync generator N (bit oriented).
 *
 * \note Forcing a sync event through a command register may cause one or more events at the sync generators 
 *       and the interrupt controller (depending on their configuration), even if CFG.enable=0.
 */ 
void tsu_set_cmd_sync_out(uint16_t cmd_sync_out);


/* ############################################################################ */
/**
 * \brief generate sync pulse (can generate only one sync pulse)
 *
 * \ingroup tsu  
 * 
 * \param sync_out_no number of sync pulse generator
 *
 * \note Forcing a sync event through a command register may cause one or more events at the sync generators 
 *       and the interrupt controller (depending on their configuration), even if CFG.enable=0.
 */ 
void tsu_set_cmd_sync_out_no(uint8_t sync_out_no);


/* ############################################################################ */
/**
 * \brief Set RWS command
 *
 * \ingroup tsu  
 * 
 * \param rws_cmd 0: abort current command. <br>
 *                1: software read sync. Performed immediately. <br>
 *                2: software write sync. Performed immediately. <br>
 *                3: sync_out[0] read sync. : Triggered by next sync_out[0] event <br>
 *                4: sync_out[0] write sync <br>
 *                5: sync_in_ext read sync <br>
 *                6: sync_in_ext write sync: A write sync is performed when the next sync event occurs on the sync input. <br>
 *                7: same as 6, but command is automatically repeated until an abort <br>
 */ 
void tsu_set_rws_cmd(uint16_t rws_cmd);


/* ############################################################################ */
/**
 * \brief Set RWS timebase increments
 *
 * \ingroup tsu  
 * 
 * \param rws_timebase_inc RWS timebase increment step
 */ 
void tsu_set_rws_timebase_inc(uint32_t rws_timebase_inc);


/* ############################################################################ */
/**
 * \brief Set RWS timebase
 *
 * \ingroup tsu  
 * 
 * \param rws_timebase RWS timebase
 */ 
void tsu_set_rws_timebase(uint64_t rws_timebase);


/* ############################################################################ */
/**
 * \brief Set RWS base phase
 *
 * \ingroup tsu  
 * 
 * \param rws_base_phase RWS base phase
 */ 
void tsu_set_rws_base_phase(uint16_t rws_base_phase);


/* ############################################################################ */
/**
 * \brief Set RWS sub phases
 *
 * \ingroup tsu  
 * 
 * \param p0 RWS sub phase p0
 * 
 * \param p1 RWS sub phase p1 
 */ 
void tsu_set_rws_sub_phase(uint16_t p0, uint16_t p1);


/* ############################################################################ */
/**
 * \brief Force update of timebase inc
 *
 * \ingroup tsu  
 */ 
void tsu_up_timebase_inc(void);

// read


/* ############################################################################ */
/**
 * \brief Get Timebase increment update registers
 *
 * \ingroup tsu  
 * 
 * \return current increment step value
 */ 
uint32_t tsu_get_up_timebase_inc(void);


/* ############################################################################ */
/**
 * \brief Get TSU configuration
 *
 * \ingroup tsu  
 * 
 * \return 0b -> enable - 0   : timebase is stopped, i.e. not incremented <br>
 *         1b -> up_tb_inc_s0 : 1: update timebase_inc on sync[0] event <br>
 */ 
uint16_t tsu_get_cfg(void);


/* ############################################################################ */
/**
 * \brief Get timebase modulo
 *
 * \ingroup tsu  
 * 
 * \return current timebase modulo
 */ 
uint16_t tsu_get_cfg_timebase_modulus(void);


/* ############################################################################ */
/**
 * \brief Get base period reload
 *
 * \ingroup tsu  
 * 
 * \return current base period
 */ 
uint16_t tsu_get_cfg_base_period_reload(void);


/* ############################################################################ */
/**
 * \brief Get sub periods
 *
 * \ingroup tsu  
 * 
 * \return current sub periods
 */ 
tsu_cfg_sub_period_reload_t tsu_get_cfg_sub_period_reload(void);


/* ############################################################################ */
/**
 * \brief Get configuration for external synchonization signals
 *
 * \ingroup tsu  
 * 
 * \return see structure tsu_cfg_sync_out_ext_t
 */ 
tsu_cfg_sync_out_ext_t tsu_get_cfg_sync_out_ext(void);


/* ############################################################################ */
/**
 * \brief Get configuration for synchronization inputs
 *
 * \ingroup tsu  
 * 
 * \return current configuration for the sync inputs: <br>
 *                    00: SYNC_IN_DIS - sync input disabled <br>
 *                    01: SYNC_IN_EXT_RISE - triggers on rising edge of sync_in_ext <br>
 *                    10: SYNC_IN_EXT_FALL - triggers on falling edge of sync_in_ext <br>
 *                    11: SYNC_IN_EXT_ANY_EDGE - triggers on both edge of sync_in_ext <br>
 */ 
uint16_t tsu_get_cfg_sync_in(void);


/* ############################################################################ */
/**
 * \brief Get RWS timebase increments
 *
 * \ingroup tsu  
 * 
 * \return current RWS timebase increments
 */ 
uint32_t tsu_get_rws_timebase_inc(void);


/* ############################################################################ */
/**
 * \brief Get RWS timebase
 *
 * \ingroup tsu  
 * 
 * \return current RWS timebase
 */ 
uint64_t tsu_get_rws_timebase(void);


/* ############################################################################ */
/**
 * \brief Get RWS base phase
 *
 * \ingroup tsu  
 * 
 * \return current RWS base phase
 */ 
uint16_t tsu_get_rws_base_phase(void);


/* ############################################################################ */
/**
 * \brief Get RWS sub phases
 *
 * \ingroup tsu  
 * 
 * \return current RWS sub phases, see tsu_rws_sub_phase_t
 */ 
tsu_rws_sub_phase_t tsu_get_rws_sub_phase(void);


/* ############################################################################ */
/**
 * \brief Get RWS sub phases p0
 *
 * \ingroup tsu  
 * 
 * \return current RWS sub phases p0
 */ 
uint16_t tsu_get_rws_sub_phase_0(void);


/* ############################################################################ */
/**
 * \brief Get RWS sub phases p1
 *
 * \ingroup tsu  
 * 
 * \return current RWS sub phases p1
 */ 
uint16_t tsu_get_rws_sub_phase_1(void);

// irq


/* ############################################################################ */
/**
 * \brief Set IRQ mask
 *
 * \ingroup tsu  
 * 
 * \param irq    interrupt source
 * 
 * \param enable enable irq source
 *
 */ 
void tsu_enable_irq(tsu_irq_t irq, bool enable);


/* ############################################################################ */
/**
 * \brief Get pending TSU interrupt
 *
 * \ingroup tsu
 *
 * \return vector number of enabled pending interrupt with highest priority
 *         (smallest vector number). when no irq is pending the first unused irq
 *         number is returned.
 *
 */ 
tsu_irq_t tsu_get_next_pending_irq(void);


/* ############################################################################ */
/**
 * \brief Get IRQ status of TSU
 *
 * \ingroup tsu
 *
 * \return IRQ status of TSU
 *
 * \note unmasked status of all pending irqs<br>
 *             1: pending <br>
 *             0: no request <br>
 *
 * \note write: clear event flags <br>
 *              1: clear related flag <br>
 *              0: do not change flag <br>
 */  
tsu_irq_status_t tsu_get_irq_status(void);


/* ############################################################################ */
/**
 * \brief get TSU irq_mask register
 *
 * \ingroup tsu  
 * 
 * \return read irq_mask value 
 */ 
tsu_irq_mask_t tsu_get_irq_mask(void);


/* ############################################################################ */
/**
 * \brief Clear interrupt flag of TSU
 *
 * \ingroup tsu
 *
 * \param   irq       specify irq bit which should be cleared
 */
void tsu_clear_irq(tsu_irq_t irq);

/* ############################################################################ */
/** 
 * \brief vector number of interrupt event to clear
 *
 * \ingroup tsu
 *
 * \param irq  specify interrupt to be cleared
 *
 */
void tsu_clear_irq_vno(tsu_irq_t irq);

/* ############################################################################ */
/** 
 * \brief Clear all interrups flags
 *
 * \ingroup tsu
 */
void tsu_clear_all_irq(void);

/**@}*/ 
#endif /* HAVE_TSU_H */

