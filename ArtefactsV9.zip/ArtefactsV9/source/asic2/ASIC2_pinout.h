/* ################################################################################ */
/* This file is genereted by asic2_gen_pinout.py */
/* Do not modify it manually! Always change and run the asic2_gen_pinout.py script before. */
/* ################################################################################ */

#ifndef ASIC2_PINOUT_H
#define ASIC2_PINOUT_H

#include "io_ctrl.h"
#include "gpio.h"

/* ############### Macro definition for each port ############### */
/* Macro P0*/
#define IOMUX_PAD0_GPIO_BITS			GPIO_BIT_0
#define IOMUX_PAD0_GPIO_GROUP			GPIO_GROUP_0
/* Macro P1*/
#define IOMUX_PAD1_GPIO_BITS			GPIO_BIT_1
#define IOMUX_PAD1_GPIO_GROUP			GPIO_GROUP_0
/* Macro P2*/
#define IOMUX_PAD2_GPIO_BITS			GPIO_BIT_2
#define IOMUX_PAD2_GPIO_GROUP			GPIO_GROUP_0
/* Macro P3*/
#define IOMUX_PAD3_GPIO_BITS			GPIO_BIT_3
#define IOMUX_PAD3_GPIO_GROUP			GPIO_GROUP_0
/* Macro P4*/
#define IOMUX_PAD4_GPIO_BITS			GPIO_BIT_4
#define IOMUX_PAD4_GPIO_GROUP			GPIO_GROUP_0
/* Macro P5*/
#define IOMUX_PAD5_GPIO_BITS			GPIO_BIT_5
#define IOMUX_PAD5_GPIO_GROUP			GPIO_GROUP_0
/* Macro P6*/
#define IOMUX_PAD6_GPIO_BITS			GPIO_BIT_6
#define IOMUX_PAD6_GPIO_GROUP			GPIO_GROUP_0
/* Macro P7*/
#define IOMUX_PAD7_GPIO_BITS			GPIO_BIT_7
#define IOMUX_PAD7_GPIO_GROUP			GPIO_GROUP_0
/* Macro P8*/
#define IOMUX_PAD8_GPIO_BITS			GPIO_BIT_8
#define IOMUX_PAD8_GPIO_GROUP			GPIO_GROUP_0
/* Macro P9*/
#define IOMUX_PAD9_GPIO_BITS			GPIO_BIT_0
#define IOMUX_PAD9_GPIO_GROUP			GPIO_GROUP_1
/* Macro P10*/
#define IOMUX_PAD10_GPIO_BITS			GPIO_BIT_1
#define IOMUX_PAD10_GPIO_GROUP			GPIO_GROUP_1
/* Macro P11*/
#define IOMUX_PAD11_GPIO_BITS			GPIO_BIT_2
#define IOMUX_PAD11_GPIO_GROUP			GPIO_GROUP_1
/* Macro P12*/
#define IOMUX_PAD12_GPIO_BITS			GPIO_BIT_3
#define IOMUX_PAD12_GPIO_GROUP			GPIO_GROUP_1
/* Macro P13*/
#define IOMUX_PAD13_GPIO_BITS			GPIO_BIT_4
#define IOMUX_PAD13_GPIO_GROUP			GPIO_GROUP_1
/* Macro P14*/
#define IOMUX_PAD14_GPIO_BITS			GPIO_BIT_5
#define IOMUX_PAD14_GPIO_GROUP			GPIO_GROUP_1
/* Macro P15*/
#define IOMUX_PAD15_GPIO_BITS			GPIO_BIT_6
#define IOMUX_PAD15_GPIO_GROUP			GPIO_GROUP_1
/* Macro P16*/
#define IOMUX_PAD16_GPIO_BITS			GPIO_BIT_7
#define IOMUX_PAD16_GPIO_GROUP			GPIO_GROUP_1
/* Macro P17*/
#define IOMUX_PAD17_GPIO_BITS			GPIO_BIT_8
#define IOMUX_PAD17_GPIO_GROUP			GPIO_GROUP_1
/* Macro P18*/
#define IOMUX_PAD18_GPIO_BITS			GPIO_BIT_0
#define IOMUX_PAD18_GPIO_GROUP			GPIO_GROUP_2
/* Macro P19*/
#define IOMUX_PAD19_GPIO_BITS			GPIO_BIT_1
#define IOMUX_PAD19_GPIO_GROUP			GPIO_GROUP_2
/* Macro P20*/
#define IOMUX_PAD20_GPIO_BITS			GPIO_BIT_2
#define IOMUX_PAD20_GPIO_GROUP			GPIO_GROUP_2
/* Macro P21*/
#define IOMUX_PAD21_GPIO_BITS			GPIO_BIT_3
#define IOMUX_PAD21_GPIO_GROUP			GPIO_GROUP_2
/* Macro P22*/
#define IOMUX_PAD22_GPIO_BITS			GPIO_BIT_4
#define IOMUX_PAD22_GPIO_GROUP			GPIO_GROUP_2
/* Macro P23*/
#define IOMUX_PAD23_GPIO_BITS			GPIO_BIT_5
#define IOMUX_PAD23_GPIO_GROUP			GPIO_GROUP_2
/* Macro P24*/
#define IOMUX_PAD24_GPIO_BITS			GPIO_BIT_6
#define IOMUX_PAD24_GPIO_GROUP			GPIO_GROUP_2
/* Macro P25*/
#define IOMUX_PAD25_GPIO_BITS			GPIO_BIT_7
#define IOMUX_PAD25_GPIO_GROUP			GPIO_GROUP_2
/* Macro P26*/
#define IOMUX_PAD26_GPIO_BITS			GPIO_BIT_8
#define IOMUX_PAD26_GPIO_GROUP			GPIO_GROUP_2
/* Macro P27*/
#define IOMUX_PAD27_GPIO_BITS			GPIO_BIT_0
#define IOMUX_PAD27_GPIO_GROUP			GPIO_GROUP_3
/* Macro P28*/
#define IOMUX_PAD28_GPIO_BITS			GPIO_BIT_1
#define IOMUX_PAD28_GPIO_GROUP			GPIO_GROUP_3
/* Macro P29*/
#define IOMUX_PAD29_GPIO_BITS			GPIO_BIT_2
#define IOMUX_PAD29_GPIO_GROUP			GPIO_GROUP_3
/* Macro P30*/
#define IOMUX_PAD30_GPIO_BITS			GPIO_BIT_3
#define IOMUX_PAD30_GPIO_GROUP			GPIO_GROUP_3
/* Macro P31*/
#define IOMUX_PAD31_GPIO_BITS			GPIO_BIT_4
#define IOMUX_PAD31_GPIO_GROUP			GPIO_GROUP_3
/* Macro P32*/
#define IOMUX_PAD32_GPIO_BITS			GPIO_BIT_5
#define IOMUX_PAD32_GPIO_GROUP			GPIO_GROUP_3
/* Macro P33*/
#define IOMUX_PAD33_GPIO_BITS			GPIO_BIT_6
#define IOMUX_PAD33_GPIO_GROUP			GPIO_GROUP_3
/* Macro P34*/
#define IOMUX_PAD34_GPIO_BITS			GPIO_BIT_7
#define IOMUX_PAD34_GPIO_GROUP			GPIO_GROUP_3
/* Macro P35*/
#define IOMUX_PAD35_GPIO_BITS			GPIO_BIT_8
#define IOMUX_PAD35_GPIO_GROUP			GPIO_GROUP_3

/* ############### Macro definition for structure ############### */
 typedef enum functionality{  
   func_a,
   func_b,
   func_c,
   func_d,
 } functionality;                 

/* -> Structure: */
 typedef struct device_pinout_t{  
   iomux_pad_t   iomux_pad;
   gpio_bits_t   gpio_bits;
   gpio_group_t  gpio_group;
   functionality  function_group;
   uint8_t  number_pin;   
 } device_pinout;                 

/* Macro P0*/
#define IOMUX_PAD0_STRUCT { \
							.iomux_pad = IOMUX_PAD0,\
							.gpio_bits = GPIO_BIT_0,\
							.gpio_group = GPIO_GROUP_0,\
							.function_group = func_c,\
							.number_pin = 0\
							}
/* Macro P1*/
#define IOMUX_PAD1_STRUCT { \
							.iomux_pad = IOMUX_PAD1,\
							.gpio_bits = GPIO_BIT_1,\
							.gpio_group = GPIO_GROUP_0,\
							.function_group = func_a,\
							.number_pin = 1\
							}
/* Macro P2*/
#define IOMUX_PAD2_STRUCT { \
							.iomux_pad = IOMUX_PAD2,\
							.gpio_bits = GPIO_BIT_2,\
							.gpio_group = GPIO_GROUP_0,\
							.function_group = func_b,\
							.number_pin = 2\
							}
/* Macro P3*/
#define IOMUX_PAD3_STRUCT { \
							.iomux_pad = IOMUX_PAD3,\
							.gpio_bits = GPIO_BIT_3,\
							.gpio_group = GPIO_GROUP_0,\
							.function_group = func_c,\
							.number_pin = 3\
							}
/* Macro P4*/
#define IOMUX_PAD4_STRUCT { \
							.iomux_pad = IOMUX_PAD4,\
							.gpio_bits = GPIO_BIT_4,\
							.gpio_group = GPIO_GROUP_0,\
							.function_group = func_d,\
							.number_pin = 4\
							}
/* Macro P5*/
#define IOMUX_PAD5_STRUCT { \
							.iomux_pad = IOMUX_PAD5,\
							.gpio_bits = GPIO_BIT_5,\
							.gpio_group = GPIO_GROUP_0,\
							.function_group = func_a,\
							.number_pin = 5\
							}
/* Macro P6*/
#define IOMUX_PAD6_STRUCT { \
							.iomux_pad = IOMUX_PAD6,\
							.gpio_bits = GPIO_BIT_6,\
							.gpio_group = GPIO_GROUP_0,\
							.function_group = func_b,\
							.number_pin = 6\
							}
/* Macro P7*/
#define IOMUX_PAD7_STRUCT { \
							.iomux_pad = IOMUX_PAD7,\
							.gpio_bits = GPIO_BIT_7,\
							.gpio_group = GPIO_GROUP_0,\
							.function_group = func_c,\
							.number_pin = 7\
							}
/* Macro P8*/
#define IOMUX_PAD8_STRUCT { \
							.iomux_pad = IOMUX_PAD8,\
							.gpio_bits = GPIO_BIT_8,\
							.gpio_group = GPIO_GROUP_0,\
							.function_group = func_d,\
							.number_pin = 8\
							}
/* Macro P9*/
#define IOMUX_PAD9_STRUCT { \
							.iomux_pad = IOMUX_PAD9,\
							.gpio_bits = GPIO_BIT_0,\
							.gpio_group = GPIO_GROUP_1,\
							.function_group = func_a,\
							.number_pin = 0\
							}
/* Macro P10*/
#define IOMUX_PAD10_STRUCT { \
							.iomux_pad = IOMUX_PAD10,\
							.gpio_bits = GPIO_BIT_1,\
							.gpio_group = GPIO_GROUP_1,\
							.function_group = func_b,\
							.number_pin = 1\
							}
/* Macro P11*/
#define IOMUX_PAD11_STRUCT { \
							.iomux_pad = IOMUX_PAD11,\
							.gpio_bits = GPIO_BIT_2,\
							.gpio_group = GPIO_GROUP_1,\
							.function_group = func_c,\
							.number_pin = 2\
							}
/* Macro P12*/
#define IOMUX_PAD12_STRUCT { \
							.iomux_pad = IOMUX_PAD12,\
							.gpio_bits = GPIO_BIT_3,\
							.gpio_group = GPIO_GROUP_1,\
							.function_group = func_d,\
							.number_pin = 3\
							}
/* Macro P13*/
#define IOMUX_PAD13_STRUCT { \
							.iomux_pad = IOMUX_PAD13,\
							.gpio_bits = GPIO_BIT_4,\
							.gpio_group = GPIO_GROUP_1,\
							.function_group = func_a,\
							.number_pin = 4\
							}
/* Macro P14*/
#define IOMUX_PAD14_STRUCT { \
							.iomux_pad = IOMUX_PAD14,\
							.gpio_bits = GPIO_BIT_5,\
							.gpio_group = GPIO_GROUP_1,\
							.function_group = func_b,\
							.number_pin = 5\
							}
/* Macro P15*/
#define IOMUX_PAD15_STRUCT { \
							.iomux_pad = IOMUX_PAD15,\
							.gpio_bits = GPIO_BIT_6,\
							.gpio_group = GPIO_GROUP_1,\
							.function_group = func_c,\
							.number_pin = 6\
							}
/* Macro P16*/
#define IOMUX_PAD16_STRUCT { \
							.iomux_pad = IOMUX_PAD16,\
							.gpio_bits = GPIO_BIT_7,\
							.gpio_group = GPIO_GROUP_1,\
							.function_group = func_d,\
							.number_pin = 7\
							}
/* Macro P17*/
#define IOMUX_PAD17_STRUCT { \
							.iomux_pad = IOMUX_PAD17,\
							.gpio_bits = GPIO_BIT_8,\
							.gpio_group = GPIO_GROUP_1,\
							.function_group = func_a,\
							.number_pin = 8\
							}
/* Macro P18*/
#define IOMUX_PAD18_STRUCT { \
							.iomux_pad = IOMUX_PAD18,\
							.gpio_bits = GPIO_BIT_0,\
							.gpio_group = GPIO_GROUP_2,\
							.function_group = func_b,\
							.number_pin = 0\
							}
/* Macro P19*/
#define IOMUX_PAD19_STRUCT { \
							.iomux_pad = IOMUX_PAD19,\
							.gpio_bits = GPIO_BIT_1,\
							.gpio_group = GPIO_GROUP_2,\
							.function_group = func_c,\
							.number_pin = 1\
							}
/* Macro P20*/
#define IOMUX_PAD20_STRUCT { \
							.iomux_pad = IOMUX_PAD20,\
							.gpio_bits = GPIO_BIT_2,\
							.gpio_group = GPIO_GROUP_2,\
							.function_group = func_d,\
							.number_pin = 2\
							}
/* Macro P21*/
#define IOMUX_PAD21_STRUCT { \
							.iomux_pad = IOMUX_PAD21,\
							.gpio_bits = GPIO_BIT_3,\
							.gpio_group = GPIO_GROUP_2,\
							.function_group = func_a,\
							.number_pin = 3\
							}
/* Macro P22*/
#define IOMUX_PAD22_STRUCT { \
							.iomux_pad = IOMUX_PAD22,\
							.gpio_bits = GPIO_BIT_4,\
							.gpio_group = GPIO_GROUP_2,\
							.function_group = func_b,\
							.number_pin = 4\
							}
/* Macro P23*/
#define IOMUX_PAD23_STRUCT { \
							.iomux_pad = IOMUX_PAD23,\
							.gpio_bits = GPIO_BIT_5,\
							.gpio_group = GPIO_GROUP_2,\
							.function_group = func_c,\
							.number_pin = 5\
							}
/* Macro P24*/
#define IOMUX_PAD24_STRUCT { \
							.iomux_pad = IOMUX_PAD24,\
							.gpio_bits = GPIO_BIT_6,\
							.gpio_group = GPIO_GROUP_2,\
							.function_group = func_d,\
							.number_pin = 6\
							}
/* Macro P25*/
#define IOMUX_PAD25_STRUCT { \
							.iomux_pad = IOMUX_PAD25,\
							.gpio_bits = GPIO_BIT_7,\
							.gpio_group = GPIO_GROUP_2,\
							.function_group = func_b,\
							.number_pin = 7\
							}
/* Macro P26*/
#define IOMUX_PAD26_STRUCT { \
							.iomux_pad = IOMUX_PAD26,\
							.gpio_bits = GPIO_BIT_8,\
							.gpio_group = GPIO_GROUP_2,\
							.function_group = func_c,\
							.number_pin = 8\
							}
/* Macro P27*/
#define IOMUX_PAD27_STRUCT { \
							.iomux_pad = IOMUX_PAD27,\
							.gpio_bits = GPIO_BIT_0,\
							.gpio_group = GPIO_GROUP_3,\
							.function_group = func_d,\
							.number_pin = 0\
							}
/* Macro P28*/
#define IOMUX_PAD28_STRUCT { \
							.iomux_pad = IOMUX_PAD28,\
							.gpio_bits = GPIO_BIT_1,\
							.gpio_group = GPIO_GROUP_3,\
							.function_group = func_a,\
							.number_pin = 1\
							}
/* Macro P29*/
#define IOMUX_PAD29_STRUCT { \
							.iomux_pad = IOMUX_PAD29,\
							.gpio_bits = GPIO_BIT_2,\
							.gpio_group = GPIO_GROUP_3,\
							.function_group = func_b,\
							.number_pin = 2\
							}
/* Macro P30*/
#define IOMUX_PAD30_STRUCT { \
							.iomux_pad = IOMUX_PAD30,\
							.gpio_bits = GPIO_BIT_3,\
							.gpio_group = GPIO_GROUP_3,\
							.function_group = func_c,\
							.number_pin = 3\
							}
/* Macro P31*/
#define IOMUX_PAD31_STRUCT { \
							.iomux_pad = IOMUX_PAD31,\
							.gpio_bits = GPIO_BIT_4,\
							.gpio_group = GPIO_GROUP_3,\
							.function_group = func_d,\
							.number_pin = 4\
							}
/* Macro P32*/
#define IOMUX_PAD32_STRUCT { \
							.iomux_pad = IOMUX_PAD32,\
							.gpio_bits = GPIO_BIT_5,\
							.gpio_group = GPIO_GROUP_3,\
							.function_group = func_a,\
							.number_pin = 5\
							}
/* Macro P33*/
#define IOMUX_PAD33_STRUCT { \
							.iomux_pad = IOMUX_PAD33,\
							.gpio_bits = GPIO_BIT_6,\
							.gpio_group = GPIO_GROUP_3,\
							.function_group = func_b,\
							.number_pin = 6\
							}
/* Macro P34*/
#define IOMUX_PAD34_STRUCT { \
							.iomux_pad = IOMUX_PAD34,\
							.gpio_bits = GPIO_BIT_7,\
							.gpio_group = GPIO_GROUP_3,\
							.function_group = func_c,\
							.number_pin = 7\
							}
/* Macro P35*/
#define IOMUX_PAD35_STRUCT { \
							.iomux_pad = IOMUX_PAD35,\
							.gpio_bits = GPIO_BIT_8,\
							.gpio_group = GPIO_GROUP_3,\
							.function_group = func_d,\
							.number_pin = 8\
							}

#endif