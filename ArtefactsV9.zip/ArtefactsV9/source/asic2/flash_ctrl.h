/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         flash_ctrl.h
*
* @brief        FLASH Controller HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef HAVE_FLASH_CTRL_H
#define HAVE_FLASH_CTRL_H

/**
 * \example example_flash_ctrl.c
 * This is an example of how to use Flash Control block.
 */

/**
 * \defgroup flash_ctrl ASIC2 FLASH Controller HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control FLASH Controller
 */
/**@{*/ 

#include "device.h"

#include "flash_ctrl_bf.h"

#define FLASH_CTRL_LSB_PAGES 9

#define BASE_ADDR_FLASH       0x00010000U
#define BASE_ADDR_FLASH0      BASE_ADDR_FLASH
#define BASE_ADDR_FLASH1      0x0001A000U

#define BASE_ADDR_FLASH0_INFO 0x00030000U
#define BASE_ADDR_FLASH1_INFO 0x00040000U


/* ############################################################################ */
/**
 * \brief This is an enum class for Flash Control to identify the flash
 *
 * \ingroup flash_ctrl 
 */ 
typedef enum {
  /**
   * Flash 0 identifier
   */ 
  FLASH0                    = (int)BASE_ADDR_FLASH0,
  /**
   * Flash 01 identifier
   */ 
  FLASH1                    = (int)BASE_ADDR_FLASH1
} flash_num_t;

#define FLASH_PAGE_SIZE        0x0200

// Main Block:
#define FLASH_MAIN_ROW_SIZE    0x0080
#define FLASH0_MAIN_PAGES          80
#define FLASH1_MAIN_PAGES         176
#define FLASH0_MAIN_SIZE       (FLASH_PAGE_SIZE * FLASH0_MAIN_PAGES)
#define FLASH1_MAIN_SIZE       (FLASH_PAGE_SIZE * FLASH1_MAIN_PAGES)

#define FLASH_MAIN_SIZE        (FLASH0_MAIN_SIZE + FLASH1_MAIN_SIZE)

// Info Block:
#define FLASH_INFO_ROW_SIZE    0x0080 
#define FLASH_INFO_PAGES            2
#define FLASH_INFO_SIZE        (FLASH_PAGE_SIZE * FLASH_INFO_PAGES)



/* ############################################################################ */
/**
 * \brief This is an enum class for Flash Control to identify the mode
 *
 * \ingroup flash_ctrl 
 */ 
typedef enum {
  /**
   * Main and info block read (selected by address)
   */ 
  FLASH_READ            = 0x01,
  /**
   * Info block read (mapped to main address)
   */ 
  FLASH_INFO_READ       = 0x02,
  /**
   * Main block program
   */ 
  FLASH_MAIN_WRITE      = 0x04,
  /**
   * Info block program
   */ 
  FLASH_INFO_WRITE      = 0x08,
  /**
   * Erase main page
   */ 
  FLASH_MAIN_ERASE      = 0x10,
  /**
   * Erase info page
   */ 
  FLASH_INFO_ERASE      = 0x20,
  /**
   * Mass erase main block
   */ 
  FLASH_MAIN_MASS_ERASE = 0x40
} flash_mode_t;


/* ############################################################################ */
/**
 * \brief This is an enum class for Flash Control to identify different flash blocks
 *
 * \ingroup flash_ctrl 
 */ 
typedef enum {
  /**
   * Flash main area
   */ 
	FLASH_MAIN = 1,
  /**
   * Flash info area
   */ 
	FLASH_INFO = 2,
} flash_block_t;


/* ############################################################################ */
/**
 * \brief This structure describes Flash Control configuration
 *
 * \ingroup flash_ctrl 
 */ 
typedef struct {
  /**
   * Instance of the Flash
   */ 
  flash_ctrl_num_t  flash_ctrl_num;
  /**
   * Select the Flash block
   */ 
  flash_block_t     flash_block;
  /**
   * Select the BASE ADDRESS
   */ 
  uint32_t          flash_base_addr;
  /**
   * elect the Flash page
   */ 
  uint8_t           flash_page;
} flash_select_t;

/* ############################################################################ */
/**
 * \brief This structure describes Flash timming
 *
 * \ingroup flash_ctrl 
 */ 
typedef struct{
  /**
   * NVSTR setup and hold time\n
   * waitcycles = TNVS,TNVH * system_clock + 1
   */
  uint8_t tnvs_tnvh;
  
  /**
   * NVSTR hold time at mass erase\n
   * waitcycles = TNVH1 * system_clock + 1
   */
  uint16_t tnvh1;
  
  /**
   * Program setup time.\n
   * waitcycles = TPGS * system_clock + 1
   */
  uint16_t tpgs;
  
  /**
   * Recovery time.\n
   * waitcycles = TRCV * system_clock + 1
   */
  uint8_t trcv;
  
  /**
   * Program time.\n
   * waitcycles = TPROG * system_clock + 1
   */
  uint16_t tprog;
  
  /** 
   * Page erase time.\n
   * waitcycles = TERASE * system_clock / 2^8 + 1
   */
  uint16_t terase;
  
  /**
   * Mass erase time.\n
   * waitcycles = TME * system_clock / 2^8 + 1
   */
  uint16_t tme;
}flash_timings_t;


#ifndef __IAR_SYSTEMS_ICC__
#define __ramfunc
#endif

// common timing config controlled by FLASH_CTRL0

/* ############################################################################ */
/**
 * \brief Function to set Flash Control half clock rate
 *
 * \ingroup flash_ctrl 
 * 
 * \param half_rate               0: 1:1 flash clk = switch clk <br>
 *                                1: 2:1 flash clk = 0.5 system clk
 *
 *                                \note It can only be written for FLASH_CTRL0 instance
 */ 
void flash_ctrl_use_half_clock_speed(bool half_rate);

/* ############################################################################ */
/**
 * \brief Function to set Flash Control Timing Configuration
 *
 * \ingroup flash_ctrl 
 * 
 * \param see flash_timings_t
 * 
 */ 
void flash_ctrl_set_timings(flash_timings_t flash_timings);


// Protection configured in Controller

/* ############################################################################ */
/**
 * \brief Function to set Flash Control start page of writeable / eraseable area
 *
 * \ingroup flash_ctrl 
 * 
 * \param flash_ctrl                        Instance of the Flash
 * 
 * \param start_page                        FLASH area write and erase protection <br>
 *                                          Start page of writeable / eraseable area <br>
 *                                          MAIN AREA: <br>
 *                                          0x00 - 0x50 (40kb) <br>
 *                                          0x00 - 0xB0 (88kb) <br>
 *                                          INFO AREA (virtual) : 0xF0 – 0xF1 (2 pages) <br>
 *                                          If AREA_MIN is greater than AREA_MAX no page is writeable
 */ 
void flash_ctrl_set_area_min(flash_ctrl_num_t flash_ctrl, uint8_t start_page);

/* ############################################################################ */
/**
 * \brief Function to set Flash Control end page of writeable / eraseable area
 *
 * \ingroup flash_ctrl 
 * 
 * \param flash_ctrl                        Instance of the Flash
 * 
 * \param end_page                          End page of writeable / eraseable area
 */ 
void flash_ctrl_set_area_max(flash_ctrl_num_t flash_ctrl, uint8_t end_page);

// Address Decode Helper

/* ############################################################################ */
/**
 * \brief Function to get Flash Control page
 *
 * \ingroup flash_ctrl 
 * 
 * \param flash_addr Address of the desired page
 * 
 * \return Selected page
 */ 
uint8_t flash_ctrl_get_page(uint32_t flash_addr);

// RAM COPY AREA START: these functions have to be copied to RAM
__ramfunc void flash_ctrl_decode_addr(uint32_t flash_addr, flash_select_t * flash_select);
__ramfunc bool flash_row_prog(uint32_t row_base_addr, uint32_t *row_data);
__ramfunc bool flash_dword_prog(uint32_t word_addr, uint32_t data);
__ramfunc bool flash_page_erase(uint32_t page_base_addr);
__ramfunc bool flash_mass_erase(flash_num_t flash, flash_block_t block);
// RAM COPY AREA END


#define FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK 8000000UL
#define FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK_KHZ ((FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK)/(1000U))

#define FLASH_CTRL_ACCESS_TIME_TNVS_TNVH(system_clock) ( ( (  49U * ( (system_clock) / (1000U) ) ) / ( FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK_KHZ ) ) + 1 )
#define FLASH_CTRL_ACCESS_TIME_TNVH1(system_clock)     ( ( ( 881U * ( (system_clock) / (1000U) ) ) / ( FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK_KHZ ) ) + 1 )  
#define FLASH_CTRL_ACCESS_TIME_TPGS(system_clock)      ( ( (  89U * ( (system_clock) / (1000U) ) ) / ( FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK_KHZ ) ) + 1 )  
#define FLASH_CTRL_ACCESS_TIME_TRCV(system_clock)      ( ( (   9U * ( (system_clock) / (1000U) ) ) / ( FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK_KHZ ) ) + 1 )  
#define FLASH_CTRL_ACCESS_TIME_TPROG(system_clock)     ( ( ( 177U * ( (system_clock) / (1000U) ) ) / ( FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK_KHZ ) ) + 1 )  
#define FLASH_CTRL_ACCESS_TIME_TERASE(system_clock)    ( ( ( 672U * ( (system_clock) / (1000U) ) ) / ( FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK_KHZ ) ) + 1 )  
#define FLASH_CTRL_ACCESS_TIME_TME(system_clock)       ( ( ( 672U * ( (system_clock) / (1000U) ) ) / ( FLASH_CTRL_ACCESS_TIME_DEFAULT_SYSTEM_CLOCK_KHZ ) ) + 1 )




/**@} */
#endif /* HAVE_FLASH_CTRL_H */

