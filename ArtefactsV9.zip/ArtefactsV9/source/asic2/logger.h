/***************************************************************************
 *
 *  SWD-Slave Stack 
 *  This Stack implements the behaviour required to join a Smartwire DT Bus Collection.
 *
 *  Copyright (c) 2010, Eaton Industries GmbH
 *  All rights reserved.
 *  Subject to alterations without notice.
 *
 *  All brand and product names are trademarks or registered trademarks of
 *  the owner concerned.
 *
 *  See User Guide Slave Stack.pdf Document for further information.
 *
 ****************************************************************************/

#ifndef HAVE_LOGGER_H
#define HAVE_LOGGER_H

#include <stdio.h>

#define CLEAR_SCREEN            "\033[2J"

#ifdef NDEBUG
#ifndef LEVEL_LOG
#define LEVEL_LOG               0 //LEVEL_INFO
#endif
#else
#ifndef LEVEL_LOG
#define LEVEL_LOG               0  //LEVEL_INFO
#endif
#endif

#define LEVEL_FATAL             0
#define LEVEL_ERROR             1
#define LEVEL_WARN              2
#define LEVEL_INFO              3
#define LEVEL_DEBUG             4
#define LEVEL_DEBUG_API         5


#if (LEVEL_LOG >= LEVEL_DEBUG_API)
#define debug_api(...)              printf ("[%15.15s] DEBUG_API: ", __func__); printf (__VA_ARGS__)
#else
#define debug_api(...)              ;
#endif

#if (LEVEL_LOG >= LEVEL_DEBUG)
#define debug(...)              printf ("[%15.15s] DEBUG: ", __func__); printf (__VA_ARGS__)
#else
#define debug(...)              ;
#endif

#if (LEVEL_LOG >= LEVEL_INFO)
#define info(...)               printf ("[%15.15s]  INFO: ", __func__); printf (__VA_ARGS__)
#else
#define info(...)               ;
#endif

#if (LEVEL_LOG >= LEVEL_WARN)
#define warn(...)               printf ("[%15.15s]  WARN: ", __func__); printf (__VA_ARGS__)
#else
#define warn(...)               ;
#endif

#if (LEVEL_LOG >= LEVEL_ERROR)
#define error(...)              printf ("[%15.15s] ERROR: ", __func__); printf (__VA_ARGS__)
#else
#define error(...)              ;
#endif

#if (LEVEL_LOG >= LEVEL_FATAL)
#define fatal(...)              printf ("[%15.15s] FATAL: ", __func__); printf (__VA_ARGS__)
#else
#define fatal(...)              ;
#endif

#define ENTER                   debug ("Entering %s.\n", __func__);
#define EXIT                    debug ("Finished %s.\n", __func__);

#endif /* HAVE_LOGGER_H */
