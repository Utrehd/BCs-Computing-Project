/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         saradc_ctrl_bf.h
*
* @brief        SAR ADC Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __SARADC_CTRL_BF_H__
#define __SARADC_CTRL_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_SARADC_CTRL
#define BASE_ADDR_SARADC_CTRL 0x40006C00U
#endif

#define NUMBER_SARADC_CTRL 1

/**
  * \brief This is an enum class for SAR ADC instance
  *
  * \ingroup saradc_ctrl
  */ 
typedef enum {
  SARADC_CTRL                    = (int)BASE_ADDR_SARADC_CTRL
} saradc_ctrl_num_t;

// Register bit field definitions

/* SARADC_CTRL_CFG */

#define MSK_SARADC_CTRL_CFG_ADC_ON                          (0x1)     /* [0] */
#define RES_SARADC_CTRL_CFG_ADC_ON                          (0x0)
#define SFT_SARADC_CTRL_CFG_ADC_ON                          (0)
#define LSB_SARADC_CTRL_CFG_ADC_ON                          (0)
#define MSB_SARADC_CTRL_CFG_ADC_ON                          (0)
#define BIT_SARADC_CTRL_CFG_ADC_ON                          (0x1)     /* [0] */
#define MSK_SARADC_CTRL_CFG_ADC_IDLE_N                      (0x1)     /* [1] */
#define RES_SARADC_CTRL_CFG_ADC_IDLE_N                      (0x0)
#define SFT_SARADC_CTRL_CFG_ADC_IDLE_N                      (1)
#define LSB_SARADC_CTRL_CFG_ADC_IDLE_N                      (1)
#define MSB_SARADC_CTRL_CFG_ADC_IDLE_N                      (1)
#define BIT_SARADC_CTRL_CFG_ADC_IDLE_N                      (0x2)     /* [1] */
#define MSK_SARADC_CTRL_CFG_BUFFER_ON                       (0x1)     /* [2] */
#define RES_SARADC_CTRL_CFG_BUFFER_ON                       (0x0)
#define SFT_SARADC_CTRL_CFG_BUFFER_ON                       (2)
#define LSB_SARADC_CTRL_CFG_BUFFER_ON                       (2)
#define MSB_SARADC_CTRL_CFG_BUFFER_ON                       (2)
#define BIT_SARADC_CTRL_CFG_BUFFER_ON                       (0x4)     /* [2] */
#define MSK_SARADC_CTRL_CFG_BUFFER_FASTMODE                 (0x1)     /* [3] */
#define RES_SARADC_CTRL_CFG_BUFFER_FASTMODE                 (0x0)
#define SFT_SARADC_CTRL_CFG_BUFFER_FASTMODE                 (3)
#define LSB_SARADC_CTRL_CFG_BUFFER_FASTMODE                 (3)
#define MSB_SARADC_CTRL_CFG_BUFFER_FASTMODE                 (3)
#define BIT_SARADC_CTRL_CFG_BUFFER_FASTMODE                 (0x8)     /* [3] */
#define MSK_SARADC_CTRL_CFG_SEL_INT_REF                     (0x1)     /* [4] */
#define RES_SARADC_CTRL_CFG_SEL_INT_REF                     (0x0)
#define SFT_SARADC_CTRL_CFG_SEL_INT_REF                     (4)
#define LSB_SARADC_CTRL_CFG_SEL_INT_REF                     (4)
#define MSB_SARADC_CTRL_CFG_SEL_INT_REF                     (4)
#define BIT_SARADC_CTRL_CFG_SEL_INT_REF                     (0x10)    /* [4] */
#define MSK_SARADC_CTRL_CFG_ADC_RESET                       (0x3)     /* [ 6:5] */
#define RES_SARADC_CTRL_CFG_ADC_RESET                       (0x0)
#define SFT_SARADC_CTRL_CFG_ADC_RESET                       (5)
#define LSB_SARADC_CTRL_CFG_ADC_RESET                       (5)
#define MSB_SARADC_CTRL_CFG_ADC_RESET                       (6)
#define MSK_SARADC_CTRL_CFG_CONCURRENT_TRIGGER              (0x1)     /* [7] */
#define RES_SARADC_CTRL_CFG_CONCURRENT_TRIGGER              (0x0)
#define SFT_SARADC_CTRL_CFG_CONCURRENT_TRIGGER              (7)
#define LSB_SARADC_CTRL_CFG_CONCURRENT_TRIGGER              (7)
#define MSB_SARADC_CTRL_CFG_CONCURRENT_TRIGGER              (7)
#define BIT_SARADC_CTRL_CFG_CONCURRENT_TRIGGER              (0x80)    /* [7] */


/** 
 * \brief This structure describes SAR ADC configuration 
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  /**
   * 0: adc is powered down
   * 1: adc is powered up
   */
  unsigned short adc_on                        :    1;       /* [0] */
  
  /**
   * 0: adc is in idle mode
   * 1: adc is in run mode
   */
  unsigned short adc_idle_n                    :    1;       /* [1] */
  
  /**
   * 0: input-buffer is on
   * 1: input-buffer is off
   */
  unsigned short buffer_on                     :    1;       /* [2] */
  
  /**
   * 0: slow settling time (power saving) mode for buffer
   * 1: fast settling time mode for buffer
   */
  unsigned short buffer_fastmode               :    1;       /* [3] */
  
  /**
   * 0: internal reference
   * 1: external reference
   */
  unsigned short sel_int_ref                   :    1;       /* [4] */
  
  /**
   * 0: adc_reset after every sample sequence
   * 1: adc reset permanently not asserted (conversion possible)
   * 3: adc reset permanently asserted (conversion not posible)
   */
  unsigned short adc_reset                     :    2;       /* [ 6:5] */
  
  /**
   * 0: only the trigger condition for the current list item is monitored. All
   *    other triggers are ignored. <br>
   *
   * 1: the trigger for the next list item is monitored concurrently to the
   *    processing of the current trigger. If the next trigger (including its wait
   *    time) would result in a sampling time which collides with the current
   *    list item then a missed_trigger event is generated and 0XFFFF is
   *    written for all the sums of the next list item. The channel is set as
   *    specified but no actual sampling will be performed.
   *    Only dead time triggers are supported as concurrent triggers.
   */
  unsigned short concurrent_trigger            :    1;       /* [7] */
  
  unsigned short reserved                      :    8;
} saradc_ctrl_cfg_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC configuration
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;    ///< word representation
  saradc_ctrl_cfg_bf bf; ///< bit field representation
} saradc_ctrl_cfg_t;


/* SARADC_CTRL_CFG_SAR_TIMING */

#define MSK_SARADC_CTRL_CFG_SAR_TIMING_ADC_CLK_DIV          (0x7)     /* [ 2:0] */
#define RES_SARADC_CTRL_CFG_SAR_TIMING_ADC_CLK_DIV          (0x1)
#define SFT_SARADC_CTRL_CFG_SAR_TIMING_ADC_CLK_DIV          (0)
#define LSB_SARADC_CTRL_CFG_SAR_TIMING_ADC_CLK_DIV          (0)
#define MSB_SARADC_CTRL_CFG_SAR_TIMING_ADC_CLK_DIV          (2)
#define MSK_SARADC_CTRL_CFG_SAR_TIMING_MUX_PHASE            (0x1f)    /* [ 7:3] */
#define RES_SARADC_CTRL_CFG_SAR_TIMING_MUX_PHASE            (0x06)
#define SFT_SARADC_CTRL_CFG_SAR_TIMING_MUX_PHASE            (3)
#define LSB_SARADC_CTRL_CFG_SAR_TIMING_MUX_PHASE            (3)
#define MSB_SARADC_CTRL_CFG_SAR_TIMING_MUX_PHASE            (7)

/** 
 * \brief This structure describes SAR ADC timing
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  /**
   * 0: adc_clk equal to module clk <br>
   * 1..MAX Period of adc clk is 2*adc_clk_div clk cycles.
   */
  unsigned short adc_clk_div                   :    3;       /* [ 2:0] */
  
  /**
   * 6..27 clock edge number when the multiplexer is changed. Use
   * default value 6 for adc_clk_div > 0. Use 8 for adc_clk_div == 0.
   * Values <6 are not supported
   */
  unsigned short mux_phase                     :    5;       /* [ 7:3] */
    
  unsigned short reserved                      :    8;
} saradc_ctrl_cfg_sar_timing_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC timing
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;               ///< word representation
  saradc_ctrl_cfg_sar_timing_bf bf; ///< bit field representation
} saradc_ctrl_cfg_sar_timing_t;


/* SARADC_CTRL_WAIT_PRESCALER */

#define MSK_SARADC_CTRL_WAIT_PRESCALER_DEAD_TIME            (0xff)    /* [ 7:0] */
#define RES_SARADC_CTRL_WAIT_PRESCALER_DEAD_TIME            (0x00)
#define SFT_SARADC_CTRL_WAIT_PRESCALER_DEAD_TIME            (0)
#define LSB_SARADC_CTRL_WAIT_PRESCALER_DEAD_TIME            (0)
#define MSB_SARADC_CTRL_WAIT_PRESCALER_DEAD_TIME            (7)
#define MSK_SARADC_CTRL_WAIT_PRESCALER_SAMPLING_EXTENSION   (0xff)    /* [15:8] */
#define RES_SARADC_CTRL_WAIT_PRESCALER_SAMPLING_EXTENSION   (0x00)
#define SFT_SARADC_CTRL_WAIT_PRESCALER_SAMPLING_EXTENSION   (8)
#define LSB_SARADC_CTRL_WAIT_PRESCALER_SAMPLING_EXTENSION   (8)
#define MSB_SARADC_CTRL_WAIT_PRESCALER_SAMPLING_EXTENSION   (15)

/** 
 * \brief This structure describes SAR ADC prescaler
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  /**
   * prescaler for wait cycles after dead time event
   */
  unsigned short dead_time                     :    8;       /* [ 7:0] */
  
  /**
   * prescaler for sampling extension
   */
  unsigned short sampling_extension            :    8;       /* [15:8] */
} saradc_ctrl_wait_prescaler_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC prescaler
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;               ///< word representation
  saradc_ctrl_wait_prescaler_bf bf; ///< bit field representation
} saradc_ctrl_wait_prescaler_t;


/* SARADC_CTRL_SYNC_OUT_CFG */

#define MSK_SARADC_CTRL_SYNC_OUT_CFG_LENGTH                 (0xff)    /* [ 7:0] */
#define RES_SARADC_CTRL_SYNC_OUT_CFG_LENGTH                 (0x00)
#define SFT_SARADC_CTRL_SYNC_OUT_CFG_LENGTH                 (0)
#define LSB_SARADC_CTRL_SYNC_OUT_CFG_LENGTH                 (0)
#define MSB_SARADC_CTRL_SYNC_OUT_CFG_LENGTH                 (7)
#define MSK_SARADC_CTRL_SYNC_OUT_CFG_POL                    (0x1)     /* [8] */
#define RES_SARADC_CTRL_SYNC_OUT_CFG_POL                    (0x1)
#define SFT_SARADC_CTRL_SYNC_OUT_CFG_POL                    (8)
#define LSB_SARADC_CTRL_SYNC_OUT_CFG_POL                    (8)
#define MSB_SARADC_CTRL_SYNC_OUT_CFG_POL                    (8)
#define BIT_SARADC_CTRL_SYNC_OUT_CFG_POL                    (0x100)   /* [8] */
#define MSK_SARADC_CTRL_SYNC_OUT_CFG_SRC                    (0x3)     /* [10:9] */
#define RES_SARADC_CTRL_SYNC_OUT_CFG_SRC                    (0x0)
#define SFT_SARADC_CTRL_SYNC_OUT_CFG_SRC                    (9)
#define LSB_SARADC_CTRL_SYNC_OUT_CFG_SRC                    (9)
#define MSB_SARADC_CTRL_SYNC_OUT_CFG_SRC                    (10)

/** 
 * \brief This structure describes SAR ADC synchronization
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  /**
   * length of the sync_out pulse in clock cycles
   */
  unsigned short length                        :    8;       /* [ 7:0] */
  
  /**
   * polarity of sync_out when asserted
   */
  unsigned short pol                           :    1;       /* [8] */
  
  /**
   * 0: base_phase <br>
   * 1: pwm_phase <br>
   * 2: list command (see above) <br>
   * 3: disabled <br>
   */
  unsigned short src                           :    2;       /* [10:9] */
  unsigned short reserved                      :    5;
} saradc_ctrl_sync_out_cfg_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC prescaler
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;             ///< word representation
  saradc_ctrl_sync_out_cfg_bf bf; ///< bit field representation
} saradc_ctrl_sync_out_cfg_t;


/* SARADC_CTRL_SYNC_OUT_TRIG */

#define MSK_SARADC_CTRL_SYNC_OUT_TRIG                       (0xffff)  /* [15:0] */

typedef unsigned short saradc_ctrl_sync_out_trig_t;                   /* [15:0] */


/* SARADC_CTRL_CMD */

#define MSK_SARADC_CTRL_CMD_LIST_SKIP                       (0x1)     /* [0] */
#define RES_SARADC_CTRL_CMD_LIST_SKIP                       (0x0)
#define SFT_SARADC_CTRL_CMD_LIST_SKIP                       (0)
#define LSB_SARADC_CTRL_CMD_LIST_SKIP                       (0)
#define MSB_SARADC_CTRL_CMD_LIST_SKIP                       (0)
#define BIT_SARADC_CTRL_CMD_LIST_SKIP                       (0x1)     /* [0] */
#define MSK_SARADC_CTRL_CMD_SEQ_SKIP                        (0x1)     /* [1] */
#define RES_SARADC_CTRL_CMD_SEQ_SKIP                        (0x0)
#define SFT_SARADC_CTRL_CMD_SEQ_SKIP                        (1)
#define LSB_SARADC_CTRL_CMD_SEQ_SKIP                        (1)
#define MSB_SARADC_CTRL_CMD_SEQ_SKIP                        (1)
#define BIT_SARADC_CTRL_CMD_SEQ_SKIP                        (0x2)     /* [1] */

/** 
 * \brief This structure describes SAR ADC command
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  /**
   * 1: terminate (skip) current list of sample sequences and continue with the next
   */
  unsigned short list_skip                     :    1;       /* [0] */
  
  /**
   * 1: terminate (skip) current list item (sample sequence or waiting for 
   *    trigger) and continue with the next.
   */
  unsigned short seq_skip                      :    1;       /* [1] */
  unsigned short reserved                      :   14;
} saradc_ctrl_cmd_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC command
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;    ///< word representation
  saradc_ctrl_cmd_bf bf; ///< bit field representation
} saradc_ctrl_cmd_t;


/* SARADC_CTRL_WADR_MIN */

#define MSK_SARADC_CTRL_WADR_MIN_WADR_MIN                   (0x7ff)   /* [15:5] */
#define RES_SARADC_CTRL_WADR_MIN_WADR_MIN                   (0x000)
#define SFT_SARADC_CTRL_WADR_MIN_WADR_MIN                   (5)
#define LSB_SARADC_CTRL_WADR_MIN_WADR_MIN                   (5)
#define MSB_SARADC_CTRL_WADR_MIN_WADR_MIN                   (15)

/** 
 * \brief This structure describes SAR ADC  memory write protection (min)
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  unsigned short reserved4                     :    5;       /* [ 4:0] */
  /**
   * Memory write protection. The module only performs writes when
   * WADR_MIN <= target_address < WADR_MAX
   */
  unsigned short wadr_min                      :   11;       /* [15:5] */
} saradc_ctrl_wadr_min_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC memory write protection (min)
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;         ///< word representation
  saradc_ctrl_wadr_min_bf bf; ///< bit field representation
} saradc_ctrl_wadr_min_t;


/* SARADC_CTRL_WADR_MAX */

#define MSK_SARADC_CTRL_WADR_MAX_WADR_MAX                   (0x7ff)   /* [15:5] */
#define RES_SARADC_CTRL_WADR_MAX_WADR_MAX                   (0x000)
#define SFT_SARADC_CTRL_WADR_MAX_WADR_MAX                   (5)
#define LSB_SARADC_CTRL_WADR_MAX_WADR_MAX                   (5)
#define MSB_SARADC_CTRL_WADR_MAX_WADR_MAX                   (15)

/** 
 * \brief This structure describes SAR ADC  memory write protection (max)
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  unsigned short reserved4                     :    5;       /* [ 4:0] */
  /**
   * Memory write protection. The module only performs writes when
   * WADR_MIN <= target_address < WADR_MAX
   */
  unsigned short wadr_max                      :   11;       /* [15:5] */
} saradc_ctrl_wadr_max_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC memory write protection (max)
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;         ///< word representation
  saradc_ctrl_wadr_max_bf bf; ///< bit field representation
} saradc_ctrl_wadr_max_t;


/* SARADC_CTRL_SADR_NEW */

#define MSK_SARADC_CTRL_SADR_NEW_LIST_SKIP                  (0x1)     /* [0] */
#define RES_SARADC_CTRL_SADR_NEW_LIST_SKIP                  (0x0)
#define SFT_SARADC_CTRL_SADR_NEW_LIST_SKIP                  (0)
#define LSB_SARADC_CTRL_SADR_NEW_LIST_SKIP                  (0)
#define MSB_SARADC_CTRL_SADR_NEW_LIST_SKIP                  (0)
#define BIT_SARADC_CTRL_SADR_NEW_LIST_SKIP                  (0x1)     /* [0] */
#define MSK_SARADC_CTRL_SADR_NEW_START_ADR                  (0x7fff)  /* [15:1] */
#define RES_SARADC_CTRL_SADR_NEW_START_ADR                  (0x0000)
#define SFT_SARADC_CTRL_SADR_NEW_START_ADR                  (1)
#define LSB_SARADC_CTRL_SADR_NEW_START_ADR                  (1)
#define MSB_SARADC_CTRL_SADR_NEW_START_ADR                  (15)

/** 
 * \brief This structure describes SAR ADC DMA new address
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  /**
   * same as CMD.list_skip
   */
  unsigned short list_skip                     :    1;       /* [0] */
  
  /**
   * new start address. Execution starts once the current list has
   * completed or is skipped.
   */
  unsigned short start_adr                     :   15;       /* [15:1] */
} saradc_ctrl_sadr_new_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC DMA new address
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;         ///< word representation
  saradc_ctrl_sadr_new_bf bf; ///< bit field representation
} saradc_ctrl_sadr_new_t;


/* SARADC_CTRL_SADR_CURRENT */

#define MSK_SARADC_CTRL_SADR_CURRENT                        (0xffff)  /* [15:0] */

typedef unsigned short saradc_ctrl_sadr_current_t;                    /* [15:0] */


/* SARADC_CTRL_L0_CURRENT */

#define MSK_SARADC_CTRL_L0_CURRENT                          (0xffff)  /* [15:0] */

typedef unsigned short saradc_ctrl_l0_current_t;                      /* [15:0] */


/* SARADC_CTRL_L1_CURRENT */

#define MSK_SARADC_CTRL_L1_CURRENT_NO_SAMPLE                (0xf)     /* [ 3:0] */
#define RES_SARADC_CTRL_L1_CURRENT_NO_SAMPLE                (0x0)
#define SFT_SARADC_CTRL_L1_CURRENT_NO_SAMPLE                (0)
#define LSB_SARADC_CTRL_L1_CURRENT_NO_SAMPLE                (0)
#define MSB_SARADC_CTRL_L1_CURRENT_NO_SAMPLE                (3)
#define MSK_SARADC_CTRL_L1_CURRENT_NO_SUM                   (0x1f)    /* [ 8:4] */
#define RES_SARADC_CTRL_L1_CURRENT_NO_SUM                   (0x00)
#define SFT_SARADC_CTRL_L1_CURRENT_NO_SUM                   (4)
#define LSB_SARADC_CTRL_L1_CURRENT_NO_SUM                   (4)
#define MSB_SARADC_CTRL_L1_CURRENT_NO_SUM                   (8)
#define MSK_SARADC_CTRL_L1_CURRENT_CH_NO                    (0x1f)    /* [13:9] */
#define RES_SARADC_CTRL_L1_CURRENT_CH_NO                    (0x00)
#define SFT_SARADC_CTRL_L1_CURRENT_CH_NO                    (9)
#define LSB_SARADC_CTRL_L1_CURRENT_CH_NO                    (9)
#define MSB_SARADC_CTRL_L1_CURRENT_CH_NO                    (13)
#define MSK_SARADC_CTRL_L1_CURRENT_TRIGGER_TYPE             (0x3)     /* [15:14] */
#define RES_SARADC_CTRL_L1_CURRENT_TRIGGER_TYPE             (0x0)
#define SFT_SARADC_CTRL_L1_CURRENT_TRIGGER_TYPE             (14)
#define LSB_SARADC_CTRL_L1_CURRENT_TRIGGER_TYPE             (14)
#define MSB_SARADC_CTRL_L1_CURRENT_TRIGGER_TYPE             (15)

/** 
 * \brief This structure describes SAR ADC L1 word
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  /**
   *  0..15 number of samples minus one to sum, i.e. 1..16 samples can be summed
   */
  unsigned short no_sample                     :    4;       /* [ 3:0] */
  
  /**
   * 0: do not perform any sampling, only set multiplexer when trigger occurs <br>
   * 1..31 number of sums to write to memory
   */
  unsigned short no_sum                        :    5;       /* [ 8:4] */
  
  /**
   * 0..31 channel no to set after conversion of the last sample of this sample sequence
   * for the next sample sequence (if CFG_SAR_TIMING . mux_phase>3)
   */
  unsigned short ch_no                         :    5;       /* [13:9] */
  
  /**
   *  see trigger
   */  
  unsigned short trigger_type                  :    2;       /* [15:14] */
} saradc_ctrl_l1_current_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC DMA new address
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;           ///< word representation
  saradc_ctrl_l1_current_bf bf; ///< bit field representation
} saradc_ctrl_l1_current_t;


/* SARADC_CTRL_L2_CURRENT */

#define MSK_SARADC_CTRL_L2_CURRENT                          (0xffff)  /* [15:0] */

typedef unsigned short saradc_ctrl_l2_current_t;                      /* [15:0] */


/* SARADC_CTRL_ADR_NEXT */

#define MSK_SARADC_CTRL_ADR_NEXT                            (0xffff)  /* [15:0] */

typedef unsigned short saradc_ctrl_adr_next_t;                        /* [15:0] */


/* SARADC_CTRL_SADR_DONE */

#define MSK_SARADC_CTRL_SADR_DONE                           (0xffff)  /* [15:0] */

typedef unsigned short saradc_ctrl_sadr_done_t;                       /* [15:0] */


/* SARADC_CTRL_STATE */

#define MSK_SARADC_CTRL_STATE                               (0x3)     /* [ 1:0] */

typedef unsigned short saradc_ctrl_state_t;                           /* [ 1:0] */


/* SARADC_CTRL_TADR */

#define MSK_SARADC_CTRL_TADR                                (0xffff)  /* [15:0] */

typedef unsigned short saradc_ctrl_tadr_t;                            /* [15:0] */


/* SARADC_CTRL_DIRECT_MODE_LW */

#define MSK_SARADC_CTRL_DIRECT_MODE_LW                      (0xffff)  /* [15:0] */

typedef unsigned short saradc_ctrl_direct_mode_lw_t;                  /* [15:0] */


/* SARADC_CTRL_DIRECT_MODE_HW */

#define MSK_SARADC_CTRL_DIRECT_MODE_HW                      (0x7)     /* [ 2:0] */

typedef unsigned short saradc_ctrl_direct_mode_hw_t;                  /* [ 2:0] */


/* SARADC_CTRL_IRQ_STATUS */

#define MSK_SARADC_CTRL_IRQ_STATUS_DMA_WRITE_ERR            (0x1)     /* [0] */
#define RES_SARADC_CTRL_IRQ_STATUS_DMA_WRITE_ERR            (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_DMA_WRITE_ERR            (0)
#define LSB_SARADC_CTRL_IRQ_STATUS_DMA_WRITE_ERR            (0)
#define MSB_SARADC_CTRL_IRQ_STATUS_DMA_WRITE_ERR            (0)
#define BIT_SARADC_CTRL_IRQ_STATUS_DMA_WRITE_ERR            (0x1)     /* [0] */
#define MSK_SARADC_CTRL_IRQ_STATUS_SUM_WRITTEN_EVT          (0x1)     /* [1] */
#define RES_SARADC_CTRL_IRQ_STATUS_SUM_WRITTEN_EVT          (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_SUM_WRITTEN_EVT          (1)
#define LSB_SARADC_CTRL_IRQ_STATUS_SUM_WRITTEN_EVT          (1)
#define MSB_SARADC_CTRL_IRQ_STATUS_SUM_WRITTEN_EVT          (1)
#define BIT_SARADC_CTRL_IRQ_STATUS_SUM_WRITTEN_EVT          (0x2)     /* [1] */
#define MSK_SARADC_CTRL_IRQ_STATUS_LIST_DONE_EVT            (0x1)     /* [2] */
#define RES_SARADC_CTRL_IRQ_STATUS_LIST_DONE_EVT            (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_LIST_DONE_EVT            (2)
#define LSB_SARADC_CTRL_IRQ_STATUS_LIST_DONE_EVT            (2)
#define MSB_SARADC_CTRL_IRQ_STATUS_LIST_DONE_EVT            (2)
#define BIT_SARADC_CTRL_IRQ_STATUS_LIST_DONE_EVT            (0x4)     /* [2] */
#define MSK_SARADC_CTRL_IRQ_STATUS_SADR_DONE_NEMPTY         (0x1)     /* [3] */
#define RES_SARADC_CTRL_IRQ_STATUS_SADR_DONE_NEMPTY         (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_SADR_DONE_NEMPTY         (3)
#define LSB_SARADC_CTRL_IRQ_STATUS_SADR_DONE_NEMPTY         (3)
#define MSB_SARADC_CTRL_IRQ_STATUS_SADR_DONE_NEMPTY         (3)
#define BIT_SARADC_CTRL_IRQ_STATUS_SADR_DONE_NEMPTY         (0x8)     /* [3] */
#define MSK_SARADC_CTRL_IRQ_STATUS_SADR_NEW_NFULL           (0x1)     /* [4] */
#define RES_SARADC_CTRL_IRQ_STATUS_SADR_NEW_NFULL           (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_SADR_NEW_NFULL           (4)
#define LSB_SARADC_CTRL_IRQ_STATUS_SADR_NEW_NFULL           (4)
#define MSB_SARADC_CTRL_IRQ_STATUS_SADR_NEW_NFULL           (4)
#define BIT_SARADC_CTRL_IRQ_STATUS_SADR_NEW_NFULL           (0x10)    /* [4] */
#define MSK_SARADC_CTRL_IRQ_STATUS_OOR0                     (0x1)     /* [5] */
#define RES_SARADC_CTRL_IRQ_STATUS_OOR0                     (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_OOR0                     (5)
#define LSB_SARADC_CTRL_IRQ_STATUS_OOR0                     (5)
#define MSB_SARADC_CTRL_IRQ_STATUS_OOR0                     (5)
#define BIT_SARADC_CTRL_IRQ_STATUS_OOR0                     (0x20)    /* [5] */
#define MSK_SARADC_CTRL_IRQ_STATUS_OOR1                     (0x1)     /* [6] */
#define RES_SARADC_CTRL_IRQ_STATUS_OOR1                     (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_OOR1                     (6)
#define LSB_SARADC_CTRL_IRQ_STATUS_OOR1                     (6)
#define MSB_SARADC_CTRL_IRQ_STATUS_OOR1                     (6)
#define BIT_SARADC_CTRL_IRQ_STATUS_OOR1                     (0x40)    /* [6] */
#define MSK_SARADC_CTRL_IRQ_STATUS_OOR2                     (0x1)     /* [7] */
#define RES_SARADC_CTRL_IRQ_STATUS_OOR2                     (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_OOR2                     (7)
#define LSB_SARADC_CTRL_IRQ_STATUS_OOR2                     (7)
#define MSB_SARADC_CTRL_IRQ_STATUS_OOR2                     (7)
#define BIT_SARADC_CTRL_IRQ_STATUS_OOR2                     (0x80)    /* [7] */
#define MSK_SARADC_CTRL_IRQ_STATUS_OOR3                     (0x1)     /* [8] */
#define RES_SARADC_CTRL_IRQ_STATUS_OOR3                     (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_OOR3                     (8)
#define LSB_SARADC_CTRL_IRQ_STATUS_OOR3                     (8)
#define MSB_SARADC_CTRL_IRQ_STATUS_OOR3                     (8)
#define BIT_SARADC_CTRL_IRQ_STATUS_OOR3                     (0x100)   /* [8] */
#define MSK_SARADC_CTRL_IRQ_STATUS_OOR4                     (0x1)     /* [9] */
#define RES_SARADC_CTRL_IRQ_STATUS_OOR4                     (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_OOR4                     (9)
#define LSB_SARADC_CTRL_IRQ_STATUS_OOR4                     (9)
#define MSB_SARADC_CTRL_IRQ_STATUS_OOR4                     (9)
#define BIT_SARADC_CTRL_IRQ_STATUS_OOR4                     (0x200)   /* [9] */
#define MSK_SARADC_CTRL_IRQ_STATUS_OOR5                     (0x1)     /* [10] */
#define RES_SARADC_CTRL_IRQ_STATUS_OOR5                     (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_OOR5                     (10)
#define LSB_SARADC_CTRL_IRQ_STATUS_OOR5                     (10)
#define MSB_SARADC_CTRL_IRQ_STATUS_OOR5                     (10)
#define BIT_SARADC_CTRL_IRQ_STATUS_OOR5                     (0x400)   /* [10] */
#define MSK_SARADC_CTRL_IRQ_STATUS_OOR6                     (0x1)     /* [11] */
#define RES_SARADC_CTRL_IRQ_STATUS_OOR6                     (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_OOR6                     (11)
#define LSB_SARADC_CTRL_IRQ_STATUS_OOR6                     (11)
#define MSB_SARADC_CTRL_IRQ_STATUS_OOR6                     (11)
#define BIT_SARADC_CTRL_IRQ_STATUS_OOR6                     (0x800)   /* [11] */
#define MSK_SARADC_CTRL_IRQ_STATUS_OOR7                     (0x1)     /* [12] */
#define RES_SARADC_CTRL_IRQ_STATUS_OOR7                     (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_OOR7                     (12)
#define LSB_SARADC_CTRL_IRQ_STATUS_OOR7                     (12)
#define MSB_SARADC_CTRL_IRQ_STATUS_OOR7                     (12)
#define BIT_SARADC_CTRL_IRQ_STATUS_OOR7                     (0x1000)  /* [12] */
#define MSK_SARADC_CTRL_IRQ_STATUS_OOR8                     (0x1)     /* [13] */
#define RES_SARADC_CTRL_IRQ_STATUS_OOR8                     (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_OOR8                     (13)
#define LSB_SARADC_CTRL_IRQ_STATUS_OOR8                     (13)
#define MSB_SARADC_CTRL_IRQ_STATUS_OOR8                     (13)
#define BIT_SARADC_CTRL_IRQ_STATUS_OOR8                     (0x2000)  /* [13] */
#define MSK_SARADC_CTRL_IRQ_STATUS_MISSED_TRIGGER           (0x1)     /* [14] */
#define RES_SARADC_CTRL_IRQ_STATUS_MISSED_TRIGGER           (0x0)
#define SFT_SARADC_CTRL_IRQ_STATUS_MISSED_TRIGGER           (14)
#define LSB_SARADC_CTRL_IRQ_STATUS_MISSED_TRIGGER           (14)
#define MSB_SARADC_CTRL_IRQ_STATUS_MISSED_TRIGGER           (14)
#define BIT_SARADC_CTRL_IRQ_STATUS_MISSED_TRIGGER           (0x4000)  /* [14] */

/** 
 * \brief This structure describes SAR ADC status interrupts
 *
 * \ingroup saradc_ctrl
 */
typedef struct {
  /**
   * 1: a sum was not written to memory. The associated
   *    address has been skipped.
   */
  unsigned short dma_write_err                 :    1;       /* [0] */
  
  /**
   * 1: sum written to memory
   */
  unsigned short sum_written_evt               :    1;       /* [1] */
  
  /**
   * 1: list completed
   */
  unsigned short list_done_evt                 :    1;       /* [2] */
  
  /**
   * 1: SADR_DONE contains a new completed start address.
   */
  unsigned short sadr_done_nempty              :    1;       /* [3] */
  
  /**
   * 1: SADR_NEW can accept a new start address.
   */
  unsigned short sadr_new_nfull                :    1;       /* [4] */
  
  /**
   * 1: sum out of range
   */
  unsigned short oor0                          :    1;       /* [5] */

  /**
   * 1: sum out of range
   */
  unsigned short oor1                          :    1;       /* [6] */

  /**
   * 1: sum out of range
   */
  unsigned short oor2                          :    1;       /* [7] */

  /**
   * 1: sum out of range
   */
  unsigned short oor3                          :    1;       /* [8] */

  /**
   * 1: sum out of range
   */
  unsigned short oor4                          :    1;       /* [9] */

  /**
   * 1: sum out of range
   */
  unsigned short oor5                          :    1;       /* [10] */

  /**
   * 1: sum out of range
   */
  unsigned short oor6                          :    1;       /* [11] */

  /**
   * 1: sum out of range
   */
  unsigned short oor7                          :    1;       /* [12] */

  /**
   * 1: sum out of range
   */
  unsigned short oor8                          :    1;       /* [13] */
  /**
   * the current trigger occurred after the previous trigger but
   * before it could be processed (e.h. because the ADC is still
   * converting)- 0xFFFFF is written to all no_sum sums.
   */
  unsigned short missed_trigger                :    1;       /* [14] */
  unsigned short reserved                      :    1;
} saradc_ctrl_irq_status_bf;

/**
 * \brief Conversion type between word and bit representation of SAR ADC status interrupts
 *
 * \ingroup saradc_ctrl
 */
typedef union {
  unsigned short val;           ///< word representation
  saradc_ctrl_irq_status_bf bf; ///< bit field representation
} saradc_ctrl_irq_status_t;


/* SARADC_CTRL_IRQ_MASK */

#define MSK_SARADC_CTRL_IRQ_MASK                            (0x7fff)  /* [14:0] */

typedef unsigned short saradc_ctrl_irq_mask_t;                        /* [14:0] */


/* SARADC_CTRL_IRQ_VENABLE */

#define MSK_SARADC_CTRL_IRQ_VENABLE                         (0xf)     /* [ 3:0] */

typedef unsigned short saradc_ctrl_irq_venable_t;                     /* [ 3:0] */


/* SARADC_CTRL_IRQ_VDISABLE */

#define MSK_SARADC_CTRL_IRQ_VDISABLE                        (0xf)     /* [ 3:0] */

typedef unsigned short saradc_ctrl_irq_vdisable_t;                    /* [ 3:0] */


/* SARADC_CTRL_IRQ_VMAX */

#define MSK_SARADC_CTRL_IRQ_VMAX                            (0x1f)    /* [ 4:0] */

typedef unsigned short saradc_ctrl_irq_vmax_t;                        /* [ 4:0] */


/* SARADC_CTRL_IRQ_VNO */

#define MSK_SARADC_CTRL_IRQ_VNO                             (0x1f)    /* [ 4:0] */

typedef unsigned short saradc_ctrl_irq_vno_t;                         /* [ 4:0] */



// Register definitions for module
// Instance base address BASE_ADDR_SARADC_CTRL 0x40006C00U ... 

#define ADDR_SARADC_CTRL_CFG                                 (0x00U)
#define A_SARADC_CTRL_CFG(ba)                                ((ba) + ADDR_SARADC_CTRL_CFG)
#define R_SARADC_CTRL_CFG(ba)                                (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_CFG(ba)))
#define RES_SARADC_CTRL_CFG                                  (0x0U)
#define MSB_SARADC_CTRL_CFG                                  7
#define LSB_SARADC_CTRL_CFG                                  0
#define AADDR_SARADC_CTRL_CFG                                (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_CFG)
#define REG_SARADC_CTRL_CFG                                  (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_CFG))

#define ADDR_SARADC_CTRL_CFG_SAR_TIMING                      (0x02U)
#define A_SARADC_CTRL_CFG_SAR_TIMING(ba)                     ((ba) + ADDR_SARADC_CTRL_CFG_SAR_TIMING)
#define R_SARADC_CTRL_CFG_SAR_TIMING(ba)                     (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_CFG_SAR_TIMING(ba)))
#define RES_SARADC_CTRL_CFG_SAR_TIMING                       (0x31U)
#define MSB_SARADC_CTRL_CFG_SAR_TIMING                       7
#define LSB_SARADC_CTRL_CFG_SAR_TIMING                       0
#define AADDR_SARADC_CTRL_CFG_SAR_TIMING                     (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_CFG_SAR_TIMING)
#define REG_SARADC_CTRL_CFG_SAR_TIMING                       (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_CFG_SAR_TIMING))

#define ADDR_SARADC_CTRL_WAIT_PRESCALER                      (0x06U)
#define A_SARADC_CTRL_WAIT_PRESCALER(ba)                     ((ba) + ADDR_SARADC_CTRL_WAIT_PRESCALER)
#define R_SARADC_CTRL_WAIT_PRESCALER(ba)                     (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_WAIT_PRESCALER(ba)))
#define RES_SARADC_CTRL_WAIT_PRESCALER                       (0x0U)
#define MSB_SARADC_CTRL_WAIT_PRESCALER                       15
#define LSB_SARADC_CTRL_WAIT_PRESCALER                       0
#define AADDR_SARADC_CTRL_WAIT_PRESCALER                     (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_WAIT_PRESCALER)
#define REG_SARADC_CTRL_WAIT_PRESCALER                       (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_WAIT_PRESCALER))

#define ADDR_SARADC_CTRL_SYNC_OUT_CFG                        (0x08U)
#define A_SARADC_CTRL_SYNC_OUT_CFG(ba)                       ((ba) + ADDR_SARADC_CTRL_SYNC_OUT_CFG)
#define R_SARADC_CTRL_SYNC_OUT_CFG(ba)                       (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_SYNC_OUT_CFG(ba)))
#define RES_SARADC_CTRL_SYNC_OUT_CFG                         (0x100U)
#define MSB_SARADC_CTRL_SYNC_OUT_CFG                         10
#define LSB_SARADC_CTRL_SYNC_OUT_CFG                         0
#define AADDR_SARADC_CTRL_SYNC_OUT_CFG                       (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_SYNC_OUT_CFG)
#define REG_SARADC_CTRL_SYNC_OUT_CFG                         (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_SYNC_OUT_CFG))

#define ADDR_SARADC_CTRL_SYNC_OUT_TRIG                       (0x0AU)
#define A_SARADC_CTRL_SYNC_OUT_TRIG(ba)                      ((ba) + ADDR_SARADC_CTRL_SYNC_OUT_TRIG)
#define R_SARADC_CTRL_SYNC_OUT_TRIG(ba)                      (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_SYNC_OUT_TRIG(ba)))
#define RES_SARADC_CTRL_SYNC_OUT_TRIG                        (0x0U)
#define MSB_SARADC_CTRL_SYNC_OUT_TRIG                        15
#define LSB_SARADC_CTRL_SYNC_OUT_TRIG                        0
#define AADDR_SARADC_CTRL_SYNC_OUT_TRIG                      (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_SYNC_OUT_TRIG)
#define REG_SARADC_CTRL_SYNC_OUT_TRIG                        (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_SYNC_OUT_TRIG))

#define ADDR_SARADC_CTRL_CMD                                 (0x0CU)
#define A_SARADC_CTRL_CMD(ba)                                ((ba) + ADDR_SARADC_CTRL_CMD)
#define R_SARADC_CTRL_CMD(ba)                                (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_CMD(ba)))
#define RES_SARADC_CTRL_CMD                                  (0x0U)
#define MSB_SARADC_CTRL_CMD                                  1
#define LSB_SARADC_CTRL_CMD                                  0
#define AADDR_SARADC_CTRL_CMD                                (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_CMD)
#define REG_SARADC_CTRL_CMD                                  (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_CMD))

#define ADDR_SARADC_CTRL_WADR_MIN                            (0x0EU)
#define A_SARADC_CTRL_WADR_MIN(ba)                           ((ba) + ADDR_SARADC_CTRL_WADR_MIN)
#define R_SARADC_CTRL_WADR_MIN(ba)                           (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_WADR_MIN(ba)))
#define RES_SARADC_CTRL_WADR_MIN                             (0x0U)
#define MSB_SARADC_CTRL_WADR_MIN                             15
#define LSB_SARADC_CTRL_WADR_MIN                             0
#define AADDR_SARADC_CTRL_WADR_MIN                           (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_WADR_MIN)
#define REG_SARADC_CTRL_WADR_MIN                             (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_WADR_MIN))

#define ADDR_SARADC_CTRL_WADR_MAX                            (0x10U)
#define A_SARADC_CTRL_WADR_MAX(ba)                           ((ba) + ADDR_SARADC_CTRL_WADR_MAX)
#define R_SARADC_CTRL_WADR_MAX(ba)                           (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_WADR_MAX(ba)))
#define RES_SARADC_CTRL_WADR_MAX                             (0x0U)
#define MSB_SARADC_CTRL_WADR_MAX                             15
#define LSB_SARADC_CTRL_WADR_MAX                             0
#define AADDR_SARADC_CTRL_WADR_MAX                           (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_WADR_MAX)
#define REG_SARADC_CTRL_WADR_MAX                             (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_WADR_MAX))

#define ADDR_SARADC_CTRL_SADR_NEW                            (0x12U)
#define A_SARADC_CTRL_SADR_NEW(ba)                           ((ba) + ADDR_SARADC_CTRL_SADR_NEW)
#define R_SARADC_CTRL_SADR_NEW(ba)                           (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_SADR_NEW(ba)))
#define RES_SARADC_CTRL_SADR_NEW                             (0x0U)
#define MSB_SARADC_CTRL_SADR_NEW                             15
#define LSB_SARADC_CTRL_SADR_NEW                             0
#define AADDR_SARADC_CTRL_SADR_NEW                           (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_SADR_NEW)
#define REG_SARADC_CTRL_SADR_NEW                             (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_SADR_NEW))

#define ADDR_SARADC_CTRL_SADR_CURRENT                        (0x14U)
#define A_SARADC_CTRL_SADR_CURRENT(ba)                       ((ba) + ADDR_SARADC_CTRL_SADR_CURRENT)
#define R_SARADC_CTRL_SADR_CURRENT(ba)                       (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_SADR_CURRENT(ba)))
#define RES_SARADC_CTRL_SADR_CURRENT                         (0x0U)
#define MSB_SARADC_CTRL_SADR_CURRENT                         15
#define LSB_SARADC_CTRL_SADR_CURRENT                         0
#define AADDR_SARADC_CTRL_SADR_CURRENT                       (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_SADR_CURRENT)
#define REG_SARADC_CTRL_SADR_CURRENT                         (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_SADR_CURRENT))

#define ADDR_SARADC_CTRL_L0_CURRENT                          (0x16U)
#define A_SARADC_CTRL_L0_CURRENT(ba)                         ((ba) + ADDR_SARADC_CTRL_L0_CURRENT)
#define R_SARADC_CTRL_L0_CURRENT(ba)                         (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_L0_CURRENT(ba)))
#define RES_SARADC_CTRL_L0_CURRENT                           (0x0U)
#define MSB_SARADC_CTRL_L0_CURRENT                           15
#define LSB_SARADC_CTRL_L0_CURRENT                           0
#define AADDR_SARADC_CTRL_L0_CURRENT                         (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_L0_CURRENT)
#define REG_SARADC_CTRL_L0_CURRENT                           (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_L0_CURRENT))

#define ADDR_SARADC_CTRL_L1_CURRENT                          (0x18U)
#define A_SARADC_CTRL_L1_CURRENT(ba)                         ((ba) + ADDR_SARADC_CTRL_L1_CURRENT)
#define R_SARADC_CTRL_L1_CURRENT(ba)                         (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_L1_CURRENT(ba)))
#define RES_SARADC_CTRL_L1_CURRENT                           (0x0U)
#define MSB_SARADC_CTRL_L1_CURRENT                           15
#define LSB_SARADC_CTRL_L1_CURRENT                           0
#define AADDR_SARADC_CTRL_L1_CURRENT                         (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_L1_CURRENT)
#define REG_SARADC_CTRL_L1_CURRENT                           (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_L1_CURRENT))

#define ADDR_SARADC_CTRL_L2_CURRENT                          (0x1AU)
#define A_SARADC_CTRL_L2_CURRENT(ba)                         ((ba) + ADDR_SARADC_CTRL_L2_CURRENT)
#define R_SARADC_CTRL_L2_CURRENT(ba)                         (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_L2_CURRENT(ba)))
#define RES_SARADC_CTRL_L2_CURRENT                           (0x0U)
#define MSB_SARADC_CTRL_L2_CURRENT                           15
#define LSB_SARADC_CTRL_L2_CURRENT                           0
#define AADDR_SARADC_CTRL_L2_CURRENT                         (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_L2_CURRENT)
#define REG_SARADC_CTRL_L2_CURRENT                           (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_L2_CURRENT))

#define ADDR_SARADC_CTRL_ADR_NEXT                            (0x1CU)
#define A_SARADC_CTRL_ADR_NEXT(ba)                           ((ba) + ADDR_SARADC_CTRL_ADR_NEXT)
#define R_SARADC_CTRL_ADR_NEXT(ba)                           (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_ADR_NEXT(ba)))
#define RES_SARADC_CTRL_ADR_NEXT                             (0x0U)
#define MSB_SARADC_CTRL_ADR_NEXT                             15
#define LSB_SARADC_CTRL_ADR_NEXT                             0
#define AADDR_SARADC_CTRL_ADR_NEXT                           (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_ADR_NEXT)
#define REG_SARADC_CTRL_ADR_NEXT                             (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_ADR_NEXT))

#define ADDR_SARADC_CTRL_SADR_DONE                           (0x1EU)
#define A_SARADC_CTRL_SADR_DONE(ba)                          ((ba) + ADDR_SARADC_CTRL_SADR_DONE)
#define R_SARADC_CTRL_SADR_DONE(ba)                          (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_SADR_DONE(ba)))
#define RES_SARADC_CTRL_SADR_DONE                            (0x0U)
#define MSB_SARADC_CTRL_SADR_DONE                            15
#define LSB_SARADC_CTRL_SADR_DONE                            0
#define AADDR_SARADC_CTRL_SADR_DONE                          (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_SADR_DONE)
#define REG_SARADC_CTRL_SADR_DONE                            (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_SADR_DONE))

#define ADDR_SARADC_CTRL_STATE                               (0x20U)
#define A_SARADC_CTRL_STATE(ba)                              ((ba) + ADDR_SARADC_CTRL_STATE)
#define R_SARADC_CTRL_STATE(ba)                              (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_STATE(ba)))
#define RES_SARADC_CTRL_STATE                                (0x0U)
#define MSB_SARADC_CTRL_STATE                                1
#define LSB_SARADC_CTRL_STATE                                0
#define AADDR_SARADC_CTRL_STATE                              (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_STATE)
#define REG_SARADC_CTRL_STATE                                (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_STATE))

#define ADDR_SARADC_CTRL_TADR                                (0x26U)
#define A_SARADC_CTRL_TADR(ba)                               ((ba) + ADDR_SARADC_CTRL_TADR)
#define R_SARADC_CTRL_TADR(ba)                               (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_TADR(ba)))
#define RES_SARADC_CTRL_TADR                                 (0x0U)
#define MSB_SARADC_CTRL_TADR                                 15
#define LSB_SARADC_CTRL_TADR                                 0
#define AADDR_SARADC_CTRL_TADR                               (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_TADR)
#define REG_SARADC_CTRL_TADR                                 (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_TADR))

#define ADDR_SARADC_CTRL_DIRECT_MODE_LW                      (0x28U)
#define A_SARADC_CTRL_DIRECT_MODE_LW(ba)                     ((ba) + ADDR_SARADC_CTRL_DIRECT_MODE_LW)
#define R_SARADC_CTRL_DIRECT_MODE_LW(ba)                     (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_DIRECT_MODE_LW(ba)))
#define RES_SARADC_CTRL_DIRECT_MODE_LW                       (0x0U)
#define MSB_SARADC_CTRL_DIRECT_MODE_LW                       15
#define LSB_SARADC_CTRL_DIRECT_MODE_LW                       0
#define AADDR_SARADC_CTRL_DIRECT_MODE_LW                     (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_DIRECT_MODE_LW)
#define REG_SARADC_CTRL_DIRECT_MODE_LW                       (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_DIRECT_MODE_LW))

#define ADDR_SARADC_CTRL_DIRECT_MODE_HW                      (0x2AU)
#define A_SARADC_CTRL_DIRECT_MODE_HW(ba)                     ((ba) + ADDR_SARADC_CTRL_DIRECT_MODE_HW)
#define R_SARADC_CTRL_DIRECT_MODE_HW(ba)                     (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_DIRECT_MODE_HW(ba)))
#define RES_SARADC_CTRL_DIRECT_MODE_HW                       (0x0U)
#define MSB_SARADC_CTRL_DIRECT_MODE_HW                       2
#define LSB_SARADC_CTRL_DIRECT_MODE_HW                       0
#define AADDR_SARADC_CTRL_DIRECT_MODE_HW                     (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_DIRECT_MODE_HW)
#define REG_SARADC_CTRL_DIRECT_MODE_HW                       (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_DIRECT_MODE_HW))

#define ADDR_SARADC_CTRL_IRQ_STATUS                          (0x40U)
#define A_SARADC_CTRL_IRQ_STATUS(ba)                         ((ba) + ADDR_SARADC_CTRL_IRQ_STATUS)
#define R_SARADC_CTRL_IRQ_STATUS(ba)                         (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_IRQ_STATUS(ba)))
#define RES_SARADC_CTRL_IRQ_STATUS                           (0x0U)
#define MSB_SARADC_CTRL_IRQ_STATUS                           14
#define LSB_SARADC_CTRL_IRQ_STATUS                           0
#define AADDR_SARADC_CTRL_IRQ_STATUS                         (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_IRQ_STATUS)
#define REG_SARADC_CTRL_IRQ_STATUS                           (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_IRQ_STATUS))

#define ADDR_SARADC_CTRL_IRQ_MASK                            (0x44U)
#define A_SARADC_CTRL_IRQ_MASK(ba)                           ((ba) + ADDR_SARADC_CTRL_IRQ_MASK)
#define R_SARADC_CTRL_IRQ_MASK(ba)                           (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_IRQ_MASK(ba)))
#define RES_SARADC_CTRL_IRQ_MASK                             (0x0U)
#define MSB_SARADC_CTRL_IRQ_MASK                             14
#define LSB_SARADC_CTRL_IRQ_MASK                             0
#define AADDR_SARADC_CTRL_IRQ_MASK                           (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_IRQ_MASK)
#define REG_SARADC_CTRL_IRQ_MASK                             (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_IRQ_MASK))

#define ADDR_SARADC_CTRL_IRQ_VENABLE                         (0x48U)
#define A_SARADC_CTRL_IRQ_VENABLE(ba)                        ((ba) + ADDR_SARADC_CTRL_IRQ_VENABLE)
#define R_SARADC_CTRL_IRQ_VENABLE(ba)                        (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_IRQ_VENABLE(ba)))
#define RES_SARADC_CTRL_IRQ_VENABLE                          (0x0U)
#define MSB_SARADC_CTRL_IRQ_VENABLE                          3
#define LSB_SARADC_CTRL_IRQ_VENABLE                          0
#define AADDR_SARADC_CTRL_IRQ_VENABLE                        (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_IRQ_VENABLE)
#define REG_SARADC_CTRL_IRQ_VENABLE                          (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_IRQ_VENABLE))

#define ADDR_SARADC_CTRL_IRQ_VDISABLE                        (0x4AU)
#define A_SARADC_CTRL_IRQ_VDISABLE(ba)                       ((ba) + ADDR_SARADC_CTRL_IRQ_VDISABLE)
#define R_SARADC_CTRL_IRQ_VDISABLE(ba)                       (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_IRQ_VDISABLE(ba)))
#define RES_SARADC_CTRL_IRQ_VDISABLE                         (0x0U)
#define MSB_SARADC_CTRL_IRQ_VDISABLE                         3
#define LSB_SARADC_CTRL_IRQ_VDISABLE                         0
#define AADDR_SARADC_CTRL_IRQ_VDISABLE                       (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_IRQ_VDISABLE)
#define REG_SARADC_CTRL_IRQ_VDISABLE                         (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_IRQ_VDISABLE))

#define ADDR_SARADC_CTRL_IRQ_VMAX                            (0x4CU)
#define A_SARADC_CTRL_IRQ_VMAX(ba)                           ((ba) + ADDR_SARADC_CTRL_IRQ_VMAX)
#define R_SARADC_CTRL_IRQ_VMAX(ba)                           (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_IRQ_VMAX(ba)))
#define RES_SARADC_CTRL_IRQ_VMAX                             (0x10U)
#define MSB_SARADC_CTRL_IRQ_VMAX                             4
#define LSB_SARADC_CTRL_IRQ_VMAX                             0
#define AADDR_SARADC_CTRL_IRQ_VMAX                           (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_IRQ_VMAX)
#define REG_SARADC_CTRL_IRQ_VMAX                             (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_IRQ_VMAX))

#define ADDR_SARADC_CTRL_IRQ_VNO                             (0x4EU)
#define A_SARADC_CTRL_IRQ_VNO(ba)                            ((ba) + ADDR_SARADC_CTRL_IRQ_VNO)
#define R_SARADC_CTRL_IRQ_VNO(ba)                            (*(volatile unsigned short *)((unsigned int)A_SARADC_CTRL_IRQ_VNO(ba)))
#define RES_SARADC_CTRL_IRQ_VNO                              (0xfU)
#define MSB_SARADC_CTRL_IRQ_VNO                              4
#define LSB_SARADC_CTRL_IRQ_VNO                              0
#define AADDR_SARADC_CTRL_IRQ_VNO                            (BASE_ADDR_SARADC_CTRL + ADDR_SARADC_CTRL_IRQ_VNO)
#define REG_SARADC_CTRL_IRQ_VNO                              (*(volatile unsigned short *)((unsigned int)AADDR_SARADC_CTRL_IRQ_VNO))




#endif
