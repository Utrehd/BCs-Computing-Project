/* FPGA Release: 10512 */
#include "hispi.h"
#include "hispi_bf.h"
#include "hispi_irq.h"


//==========================================================================
// CONFIG
//==========================================================================
void hispi_set_config(hispi_config_t * config){
  WRITE_REG_16(BASE_ADDR_HISPI + ADDR_HISPI_CONFIG, config->val);
}

void hispi_config(bool enable, bool inv_nss, bool cpol, bool ncpha, 
  bool msb_nlsb_first, bool timeout, bool early_miso, uint8_t early_miso_phase){

  hispi_config_t hispi_config;
  hispi_config.val = 0;
  
  hispi_config.bf.enable            = enable;
  hispi_config.bf.inv_nss           = inv_nss;
  hispi_config.bf.cpol              = cpol;
  hispi_config.bf.ncpha             = ncpha;
  hispi_config.bf.msb_nlsb_first    = msb_nlsb_first;
  hispi_config.bf.timeout           = timeout;
  hispi_config.bf.early_miso        = early_miso;
  hispi_config.bf.early_miso_phase  = early_miso_phase;
  WRITE_REG_16(BASE_ADDR_HISPI + ADDR_HISPI_CONFIG, hispi_config.val);
}

void hispi_config_access_control(uint16_t addr0_low, uint16_t addr0_high,
                                 uint16_t addr1_low, uint16_t addr1_high){
  WRITE_REG_16(BASE_ADDR_HISPI + ADDR_HISPI_PROT0_LOWER,addr0_low);
  WRITE_REG_16(BASE_ADDR_HISPI + ADDR_HISPI_PROT0_UPPER,addr0_high);
  WRITE_REG_16(BASE_ADDR_HISPI + ADDR_HISPI_PROT1_LOWER,addr1_low);
  WRITE_REG_16(BASE_ADDR_HISPI + ADDR_HISPI_PROT1_UPPER,addr1_high);
}

void hispi_config_timeout(uint16_t timeout){
  WRITE_REG_16(BASE_ADDR_HISPI + ADDR_HISPI_TIMEOUT, timeout);
}

//==========================================================================
// IRQ
//==========================================================================

void hispi_enable_irq(hispi_irq_t irq, bool enable){
  uint16_t irq_mask = READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_IRQ_MASK);
  if (enable) {
    irq_mask |= (0x01 << irq);
  } else {
    irq_mask &= ~(0x01 << irq);
  }
  WRITE_REG_16(BASE_ADDR_HISPI + ADDR_HISPI_IRQ_MASK, irq_mask);
}

hispi_irq_t hispi_get_next_pending_irq(void){
  return (hispi_irq_t) READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_IRQ_VNO);
}

hispi_irq_status_t hispi_get_irq_status(void){
  hispi_irq_status_t status;
  status.val = READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_IRQ_STATUS);
  return status; 
}

hispi_irq_mask_t hispi_get_irq_mask(void){
  hispi_irq_mask_t mask;
  mask = READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_IRQ_MASK);
  return mask; 
}

void hispi_clear_irq (hispi_irq_t irq) {
    WRITE_REG_16(BASE_ADDR_HISPI + ADDR_HISPI_IRQ_STATUS, (uint16_t) (0x01 << irq));
}

uint16_t hispi_get_debug_addr(void){
  return READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_TRF_ADDR);
}

uint16_t hispi_get_debug_ctrl(void){
  return READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_TRF_CONTROL);
}

uint16_t hispi_get_debug_dlen(void){
  return READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_TRF_DLEN);
}

void hispi_get_debug(uint16_t * addr, uint16_t * ctrl, uint16_t * dlen){
  *addr = READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_TRF_ADDR);
  *ctrl = READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_TRF_CONTROL);
  *dlen = READ_REG_U16(BASE_ADDR_HISPI + ADDR_HISPI_TRF_DLEN);
}

