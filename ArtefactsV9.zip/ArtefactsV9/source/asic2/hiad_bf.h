/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hiad_bf.h
*
* @brief        Parallel Host-Interface HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HIAD_BF_H__
#define __HIAD_BF_H__

// Instance base addresses

#ifndef BASE_ADDR_HIAD
#define BASE_ADDR_HIAD 0x40006900U
#endif

#define NUMBER_HIAD 1


/* ############################################################################ */
/**
 * \brief This is an enum class for HIAD instance
 *
 * \ingroup hiad 
 */ 
typedef enum {
  /**
   * This is instance HIAD
   */ 
  HIAD                           = (int)BASE_ADDR_HIAD
} hiad_num_t;

// Register bit field definitions

/* HIAD_CONFIG */

#define MSK_HIAD_CONFIG_EN                                  (0x1)     /* [0] */
#define RES_HIAD_CONFIG_EN                                  (0x0)
#define SFT_HIAD_CONFIG_EN                                  (0)
#define LSB_HIAD_CONFIG_EN                                  (0)
#define MSB_HIAD_CONFIG_EN                                  (0)
#define BIT_HIAD_CONFIG_EN                                  (0x1)     /* [0] */
#define MSK_HIAD_CONFIG_EN_OE                               (0x1)     /* [1] */
#define RES_HIAD_CONFIG_EN_OE                               (0x0)
#define SFT_HIAD_CONFIG_EN_OE                               (1)
#define LSB_HIAD_CONFIG_EN_OE                               (1)
#define MSB_HIAD_CONFIG_EN_OE                               (1)
#define BIT_HIAD_CONFIG_EN_OE                               (0x2)     /* [1] */
#define MSK_HIAD_CONFIG_MODE_8N16                           (0x1)     /* [2] */
#define RES_HIAD_CONFIG_MODE_8N16                           (0x0)
#define SFT_HIAD_CONFIG_MODE_8N16                           (2)
#define LSB_HIAD_CONFIG_MODE_8N16                           (2)
#define MSB_HIAD_CONFIG_MODE_8N16                           (2)
#define BIT_HIAD_CONFIG_MODE_8N16                           (0x4)     /* [2] */
#define MSK_HIAD_CONFIG_MUXED                               (0x1)     /* [3] */
#define RES_HIAD_CONFIG_MUXED                               (0x0)
#define SFT_HIAD_CONFIG_MUXED                               (3)
#define LSB_HIAD_CONFIG_MUXED                               (3)
#define MSB_HIAD_CONFIG_MUXED                               (3)
#define BIT_HIAD_CONFIG_MUXED                               (0x8)     /* [3] */
#define MSK_HIAD_CONFIG_MUXED8_ADDR                         (0x1)     /* [4] */
#define RES_HIAD_CONFIG_MUXED8_ADDR                         (0x0)
#define SFT_HIAD_CONFIG_MUXED8_ADDR                         (4)
#define LSB_HIAD_CONFIG_MUXED8_ADDR                         (4)
#define MSB_HIAD_CONFIG_MUXED8_ADDR                         (4)
#define BIT_HIAD_CONFIG_MUXED8_ADDR                         (0x10)    /* [4] */
#define MSK_HIAD_CONFIG_NCS_ACTIVE                          (0x1)     /* [5] */
#define RES_HIAD_CONFIG_NCS_ACTIVE                          (0x0)
#define SFT_HIAD_CONFIG_NCS_ACTIVE                          (5)
#define LSB_HIAD_CONFIG_NCS_ACTIVE                          (5)
#define MSB_HIAD_CONFIG_NCS_ACTIVE                          (5)
#define BIT_HIAD_CONFIG_NCS_ACTIVE                          (0x20)    /* [5] */
#define MSK_HIAD_CONFIG_NRD_ACTIVE                          (0x1)     /* [6] */
#define RES_HIAD_CONFIG_NRD_ACTIVE                          (0x0)
#define SFT_HIAD_CONFIG_NRD_ACTIVE                          (6)
#define LSB_HIAD_CONFIG_NRD_ACTIVE                          (6)
#define MSB_HIAD_CONFIG_NRD_ACTIVE                          (6)
#define BIT_HIAD_CONFIG_NRD_ACTIVE                          (0x40)    /* [6] */
#define MSK_HIAD_CONFIG_NWR_ACTIVE                          (0x1)     /* [7] */
#define RES_HIAD_CONFIG_NWR_ACTIVE                          (0x0)
#define SFT_HIAD_CONFIG_NWR_ACTIVE                          (7)
#define LSB_HIAD_CONFIG_NWR_ACTIVE                          (7)
#define MSB_HIAD_CONFIG_NWR_ACTIVE                          (7)
#define BIT_HIAD_CONFIG_NWR_ACTIVE                          (0x80)    /* [7] */
#define MSK_HIAD_CONFIG_NWAIT_ACTIVE                        (0x1)     /* [8] */
#define RES_HIAD_CONFIG_NWAIT_ACTIVE                        (0x0)
#define SFT_HIAD_CONFIG_NWAIT_ACTIVE                        (8)
#define LSB_HIAD_CONFIG_NWAIT_ACTIVE                        (8)
#define MSB_HIAD_CONFIG_NWAIT_ACTIVE                        (8)
#define BIT_HIAD_CONFIG_NWAIT_ACTIVE                        (0x100)   /* [8] */
#define MSK_HIAD_CONFIG_NWAIT_EXTEND                        (0x1)     /* [9] */
#define RES_HIAD_CONFIG_NWAIT_EXTEND                        (0x0)
#define SFT_HIAD_CONFIG_NWAIT_EXTEND                        (9)
#define LSB_HIAD_CONFIG_NWAIT_EXTEND                        (9)
#define MSB_HIAD_CONFIG_NWAIT_EXTEND                        (9)
#define BIT_HIAD_CONFIG_NWAIT_EXTEND                        (0x200)   /* [9] */
#define MSK_HIAD_CONFIG_ALE_EDGE                            (0x1)     /* [10] */
#define RES_HIAD_CONFIG_ALE_EDGE                            (0x0)
#define SFT_HIAD_CONFIG_ALE_EDGE                            (10)
#define LSB_HIAD_CONFIG_ALE_EDGE                            (10)
#define MSB_HIAD_CONFIG_ALE_EDGE                            (10)
#define BIT_HIAD_CONFIG_ALE_EDGE                            (0x400)   /* [10] */
#define MSK_HIAD_CONFIG_WRITE_SAMPLE                        (0x1)     /* [11] */
#define RES_HIAD_CONFIG_WRITE_SAMPLE                        (0x0)
#define SFT_HIAD_CONFIG_WRITE_SAMPLE                        (11)
#define LSB_HIAD_CONFIG_WRITE_SAMPLE                        (11)
#define MSB_HIAD_CONFIG_WRITE_SAMPLE                        (11)
#define BIT_HIAD_CONFIG_WRITE_SAMPLE                        (0x800)   /* [11] */
#define MSK_HIAD_CONFIG_MASK_ADR13                          (0x1)     /* [12] */
#define RES_HIAD_CONFIG_MASK_ADR13                          (0x0)
#define SFT_HIAD_CONFIG_MASK_ADR13                          (12)
#define LSB_HIAD_CONFIG_MASK_ADR13                          (12)
#define MSB_HIAD_CONFIG_MASK_ADR13                          (12)
#define BIT_HIAD_CONFIG_MASK_ADR13                          (0x1000)  /* [12] */
#define MSK_HIAD_CONFIG_MASK_ADR14                          (0x1)     /* [13] */
#define RES_HIAD_CONFIG_MASK_ADR14                          (0x0)
#define SFT_HIAD_CONFIG_MASK_ADR14                          (13)
#define LSB_HIAD_CONFIG_MASK_ADR14                          (13)
#define MSB_HIAD_CONFIG_MASK_ADR14                          (13)
#define BIT_HIAD_CONFIG_MASK_ADR14                          (0x2000)  /* [13] */


/* ############################################################################ */
/**
 * \brief This structure describes HIAD configuration
 *
 * \ingroup hiad 
 */ 
typedef struct {
  /**
   * 1: Enable bus interface <br>
   * When not enabled no AHBL access will be performed.
   */ 
  unsigned short en                            :    1;       /* [0] */
  /**
   * 0 : The output drivers are never enabled (i.e. reads are executed as normal, but the result is never driven by the pads) <br>
   * 1 : tThe ouput drivers operate normally
   */ 
  unsigned short en_oe                         :    1;       /* [1] */
  /**
   * 0: 16 bit bus width <br>
   * 1: 8 bit bus width
   */ 
  unsigned short mode_8n16                     :    1;       /* [2] */
  /**
   * 1: Multiplexed addresses
   */ 
  unsigned short muxed                         :    1;       /* [3] */
  /**
   * Valid for 8-Bit MUXED Mode <br>
   * 0: Upper Addr. Lines taken from addr_i <br>
   * 1: Upper Addr. Lines taken from ad_i
   */ 
  unsigned short muxed8_addr                   :    1;       /* [4] */
  /**
   * Active polarity of ncs. An A/D bus cycle takes place when ncs is active.
   */ 
  unsigned short ncs_active                    :    1;       /* [5] */
  /**
   * Active polarity of nrd (-> rising / falling Edge)
   */ 
  unsigned short nrd_active                    :    1;       /* [6] */
  /**
   * Active polarity of nwr (-> rising / falling Edge). <B> Also valid for wrl / wrh </B>
   */ 
  unsigned short nwr_active                    :    1;       /* [7] */
  /**
   * Active polarity of nwait (-> rising / falling Edge)
   */ 
  unsigned short nwait_active                  :    1;       /* [8] */
  /**
   * 0: nwait ends at the same rising edge of the clk at the same edge the data becomes valid. Can only be used if the A/D bus master samples the nwait signal before the data <br>
   * 1: nwait ends at a falling edge of the clk, half a clock cycle after the data becomes valid
   */ 
  unsigned short nwait_extend                  :    1;       /* [9] */
  /**
   * 0: sample multiplexed addresses at rising edge of ale <br>
   * 1: sample multiplexed addresses at falling edge of ale
   */ 
  unsigned short ale_edge                      :    1;       /* [10] */
  /**
   * 0: sample write data at the same time as addresses <br>
   * 1: sample write data one clk cycle later than addresses
   */ 
  unsigned short write_sample                  :    1;       /* [11] */
  /**
   * 0: adr[13] is used <br>
   * 1: adr[13] is ignored (decreases addressable range)
   */ 
  unsigned short mask_adr13                    :    1;       /* [12] */
  /**
   * 0: adr[14] is used <br>
   * 1: adr[14] is ignored (decreases addressable range)
   */ 
  unsigned short mask_adr14                    :    1;       /* [13] */
  /**
   * reserved
   */ 
  unsigned short reserved                      :    2;
} hiad_config_bf;


/* ############################################################################ */
/**
 * \brief Conversion type between word and bit representation of HIAD configuration
 *
 * \ingroup hiad 
 */ 
typedef union {
  unsigned short val;  ///< word representation
  hiad_config_bf bf;  ///< bit field representation
} hiad_config_t;


/* HIAD_ACCESS_ADDR_LOW */

#define MSK_HIAD_ACCESS_ADDR_LOW                            (0x7fff)  /* [14:0] */

typedef unsigned short hiad_access_addr_low_t;                        /* [14:0] */


/* HIAD_ACCESS_ADDR_HIGH */

#define MSK_HIAD_ACCESS_ADDR_HIGH                           (0x7fff)  /* [14:0] */

typedef unsigned short hiad_access_addr_high_t;                       /* [14:0] */



// Register definitions for module
// Instance base address BASE_ADDR_HIAD 0x40006900U ... 

#define ADDR_HIAD_CONFIG                                     (0x00U)
#define A_HIAD_CONFIG(ba)                                    ((ba) + ADDR_HIAD_CONFIG)
#define R_HIAD_CONFIG(ba)                                    (*(volatile unsigned short *)((unsigned int)A_HIAD_CONFIG(ba)))
#define RES_HIAD_CONFIG                                      (0x0U)
#define MSB_HIAD_CONFIG                                      13
#define LSB_HIAD_CONFIG                                      0
#define AADDR_HIAD_CONFIG                                    (BASE_ADDR_HIAD + ADDR_HIAD_CONFIG)
#define REG_HIAD_CONFIG                                      (*(volatile unsigned short *)((unsigned int)AADDR_HIAD_CONFIG))

#define ADDR_HIAD_ACCESS_ADDR0_LOW                           (0x02U)
#define A_HIAD_ACCESS_ADDR0_LOW(ba)                          ((ba) + ADDR_HIAD_ACCESS_ADDR0_LOW)
#define R_HIAD_ACCESS_ADDR0_LOW(ba)                          (*(volatile unsigned short *)((unsigned int)A_HIAD_ACCESS_ADDR0_LOW(ba)))
#define RES_HIAD_ACCESS_ADDR0_LOW                            (0x0U)
#define MSB_HIAD_ACCESS_ADDR0_LOW                            14
#define LSB_HIAD_ACCESS_ADDR0_LOW                            0
#define AADDR_HIAD_ACCESS_ADDR0_LOW                          (BASE_ADDR_HIAD + ADDR_HIAD_ACCESS_ADDR0_LOW)
#define REG_HIAD_ACCESS_ADDR0_LOW                            (*(volatile unsigned short *)((unsigned int)AADDR_HIAD_ACCESS_ADDR0_LOW))

#define ADDR_HIAD_ACCESS_ADDR1_LOW                           (0x04U)
#define A_HIAD_ACCESS_ADDR1_LOW(ba)                          ((ba) + ADDR_HIAD_ACCESS_ADDR1_LOW)
#define R_HIAD_ACCESS_ADDR1_LOW(ba)                          (*(volatile unsigned short *)((unsigned int)A_HIAD_ACCESS_ADDR1_LOW(ba)))
#define RES_HIAD_ACCESS_ADDR1_LOW                            (0x0U)
#define MSB_HIAD_ACCESS_ADDR1_LOW                            14
#define LSB_HIAD_ACCESS_ADDR1_LOW                            0
#define AADDR_HIAD_ACCESS_ADDR1_LOW                          (BASE_ADDR_HIAD + ADDR_HIAD_ACCESS_ADDR1_LOW)
#define REG_HIAD_ACCESS_ADDR1_LOW                            (*(volatile unsigned short *)((unsigned int)AADDR_HIAD_ACCESS_ADDR1_LOW))

#define ADDR_HIAD_ACCESS_ADDR0_HIGH                          (0x06U)
#define A_HIAD_ACCESS_ADDR0_HIGH(ba)                         ((ba) + ADDR_HIAD_ACCESS_ADDR0_HIGH)
#define R_HIAD_ACCESS_ADDR0_HIGH(ba)                         (*(volatile unsigned short *)((unsigned int)A_HIAD_ACCESS_ADDR0_HIGH(ba)))
#define RES_HIAD_ACCESS_ADDR0_HIGH                           (0x7fffU)
#define MSB_HIAD_ACCESS_ADDR0_HIGH                           14
#define LSB_HIAD_ACCESS_ADDR0_HIGH                           0
#define AADDR_HIAD_ACCESS_ADDR0_HIGH                         (BASE_ADDR_HIAD + ADDR_HIAD_ACCESS_ADDR0_HIGH)
#define REG_HIAD_ACCESS_ADDR0_HIGH                           (*(volatile unsigned short *)((unsigned int)AADDR_HIAD_ACCESS_ADDR0_HIGH))

#define ADDR_HIAD_ACCESS_ADDR1_HIGH                          (0x08U)
#define A_HIAD_ACCESS_ADDR1_HIGH(ba)                         ((ba) + ADDR_HIAD_ACCESS_ADDR1_HIGH)
#define R_HIAD_ACCESS_ADDR1_HIGH(ba)                         (*(volatile unsigned short *)((unsigned int)A_HIAD_ACCESS_ADDR1_HIGH(ba)))
#define RES_HIAD_ACCESS_ADDR1_HIGH                           (0x7fffU)
#define MSB_HIAD_ACCESS_ADDR1_HIGH                           14
#define LSB_HIAD_ACCESS_ADDR1_HIGH                           0
#define AADDR_HIAD_ACCESS_ADDR1_HIGH                         (BASE_ADDR_HIAD + ADDR_HIAD_ACCESS_ADDR1_HIGH)
#define REG_HIAD_ACCESS_ADDR1_HIGH                           (*(volatile unsigned short *)((unsigned int)AADDR_HIAD_ACCESS_ADDR1_HIGH))




#endif
