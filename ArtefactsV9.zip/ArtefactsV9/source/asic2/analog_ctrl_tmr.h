/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         analog_ctrl_tmr.h
*
* @brief        Analog Control HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __ANALOG_CTRL_TMR_H__
#define __ANALOG_CTRL_TMR_H__

#include "analog_ctrl_bf.h"
#include "device.h"

//==========================================================================
// these functions are for testmode only
//==========================================================================

/* ############################################################################ */
/**
 * \brief   Function to read if CPU has control
 *
 * \ingroup analog_ctrl
 *
 * \return 1: CPU has control
 *
 */
bool analog_ctrl_tmr_has_control(void);

/* ############################################################################ */
/**
 * \brief   Function to write in the Testmode Register
 *
 * \ingroup analog_ctrl
 * 
 * \param adr Testmode register address
 * 
 * \param data Testmode register data
 *
 */
void analog_ctrl_tmr_write(uint8_t adr, uint16_t data);

/* ############################################################################ */
/**
 * \brief   Function to read the Testmode Register
 *
 * \ingroup analog_ctrl
 * 
 * \param adr Testmode register address
 *
 * \return Testmode register data
 *
 */
uint16_t analog_ctrl_tmr_read(uint8_t adr);

#endif
