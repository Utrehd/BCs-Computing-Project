/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         hispi.h
*
* @brief        SPI Host interface HAL functions
*
* @author       MAZ, Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __HISPI_H__
#define __HISPI_H__

/**
 * \example example_hispi.c
 * This is an example of how to use CRC block.
 */

/**
 * \defgroup hispi ASIC2 SPI Hostinterface HAL functions
 * 
 * \ingroup  asic2_hal
 * 
 * \brief    Functions to control SPI Hostinterface
 *
 * \details See code example: @include example_hispi.c
 */
/**@{*/

#include "device.h"

#include "hispi_irq.h"
#include "hispi_bf.h"


//==========================================================================
// CONFIG
//==========================================================================

/* ############################################################################ */
/**
 * \brief Function to set HISPI configuration (with hispi_config_t)
 *
 * \ingroup hispi 
 * 
 * \param config          Pointer to the desired configuration structure
 *                        \see hispi_config_t
 *                        \note The “early miso” output option may not be compatible to all SPI masters
 */ 
void hispi_set_config(hispi_config_t * config);


/* ############################################################################ */
/**
 * \brief Function to set HISPI configuration
 *
 * \ingroup hispi 
 * 
 * \param enable 1: enable SPI Hostinterface
 * 
 * \param inv_nss Invert nss (1: nss is high active, 0: nss is low active)
 * 
 * \param cpol Cclock polarity (see timing diagram)
 * 
 * \param ncpha Clock phase (see timing diagram)
 * 
 * \param msb_nlsb_first 1: MSB first, 0: LSB first
 * 
 * \param timeout 1: timeout mode enabled, 0: cs controlled
 * 
 * \param early_miso 1: early miso output (after edge before) is enabled, this allows hispi to speed up to 1 / 4 of comm_clk, otherwise the speed of read transfer is limited to 1 / 8 of comm_clk
 * 
 * \param early_miso_phase phase offset for miso data in number of comm clock cycles valid only when early miso is enabled
 * 
 * \note The “early miso” output option may not be compatible to all SPI masters
 */ 
void hispi_config(bool enable, bool inv_nss, bool cpol, bool ncpha, 
  bool msb_nlsb_first, bool timeout, bool early_miso, uint8_t early_miso_phase);


/* ############################################################################ */
/**
 * \brief Function to set HISPI Upper / Lower border for access areas
 *
 * \ingroup hispi 
 * 
 * \param addr0_low Lower limit for memory area 0
 * 
 * \param addr0_high Upper limit for memory area 0
 * 
 * \param addr1_low Lower limit for memory area 1
 * 
 * \param addr1_high Upper limit for memory area 1
 *
 * \note Bits 15 to 1 are used for address comparison. <br>
 *       It is not guaranteed which vale will be return from protected area.
 */ 
void hispi_config_access_control(uint16_t addr0_low, uint16_t addr0_high,
                                 uint16_t addr1_low, uint16_t addr1_high);


/* ############################################################################ */
/**
 * \brief Function to set HISPI timeout
 *
 * \ingroup hispi 
 * 
 * \param Timeout       Length of timeout in comm_clock cycles (0 = 1 cycle), should be > 2 bit times. <br>
 *                      Timeout = the number of clock cycles in the AS domain
 *
 * \note                -> Example: <br>
 *                         baudrate = 62500 bps <br>
 *                         freq(comm_clk) = 2MHz <br>
 *                         bit = (freq_comm_clk / baudrate) * 3 <br>
 *                         timeout = 2e6 / 62500 * 3 = 96
 */ 
void hispi_config_timeout(uint16_t timeout);


/* ======================================================================= */
/* INTERRUPT HANDLING                                                      */
/* ======================================================================= */


/* ############################################################################ */
/**
 * \brief Function to enable HISPI Interrupt
 *
 * \ingroup hispi 
 * 
 * \param irq           Vector number of interrupt to enable
 *                      \see hispi_irq_t
 * 
 * \param enable        1: Enable
 */ 
void hispi_enable_irq(hispi_irq_t irq, bool enable);


/* ############################################################################ */
/**
 * \brief Function to get HISPI next pending interrupt
 *
 * \ingroup hispi 
 * 
 * \return              Vector number of enabled pending interrupt with highest priority (smallest vector number). When no irq is pending the first unused irq number is returned.
 *                      \see hispi_irq_t
 */ 
hispi_irq_t hispi_get_next_pending_irq(void);


/* ############################################################################ */
/**
 * \brief Function to get HISPI interrupt status
 *
 * \ingroup hispi 
 * 
 * \return              Current interrupt status
 *                      \see hispi_irq_status_t 
 */ 
hispi_irq_status_t hispi_get_irq_status(void);


/* ############################################################################ */
/**
 * \brief Function to get HISPI interrupt mask
 *
 * \ingroup hispi 
 * 
 * \return              Current interrupt mask value
 *                      \see hispi_irq_mask_t 
 */ 
hispi_irq_mask_t hispi_get_irq_mask(void);


/* ############################################################################ */
/**
 * \brief Function to clear HISPI interrupts
 *
 * \ingroup hispi 
 * 
 * \param irq           Vector number of interrupt to clear
 *                      \see hispi_irq_t
 */ 
void hispi_clear_irq (hispi_irq_t irq);


/* ############################################################################ */
/**
 * \brief Function to get HISPI debug transfer address
 *
 * \ingroup hispi 
 * 
 * \return Start ADDRESS of last transfer as sent by the host
 *
 * \note Updated before the end of a transfer, guaranteed valid when trf_done event is signaled
 */ 
uint16_t hispi_get_debug_addr(void);


/* ############################################################################ */
/**
 * \brief Function to get HISPI debug transfer control
 *
 * \ingroup hispi 
 * 
 * \return Word length of last read transfer as sent by the host
 *
 * \note Updated before the end of a transfer, guaranteed valid when trf_done event is signaled
 */ 
uint16_t hispi_get_debug_ctrl(void);


/* ############################################################################ */
/**
 * \brief Function to get HISPI debug transfer length
 *
 * \ingroup hispi 
 * 
 * \return Number of complete 16 bit data words in the last transfer
 *
 * \note Updated before the end of a transfer, guaranteed valid when trf_done event is signaled
 */ 
uint16_t hispi_get_debug_dlen(void);


/* ############################################################################ */
/**
 * \brief Function to get HISPI debug transfer configuration
 *
 * \ingroup hispi 
 * 
 * \param addr Start ADDRESS of last transfer as sent by the host
 * 
 * \param ctrl Word length of last read transfer as sent by the host
 * 
 * \param dlen Number of complete 16 bit data words in the last transfer
 *
 * \note Updated before the end of a transfer, guaranteed valid when trf_done event is signaled
 */ 
void hispi_get_debug(uint16_t * addr, uint16_t * ctrl, uint16_t * dlen);

/**@} */
#endif /* __HISPI_H__ */
