/**
********************************************************************************
********************************************************************************
* @copyright    Copyright (c) 2017 Eaton Industries GmbH, 
*               GERMANY, All rights reserved
*
* @file         io_ctrl_api.h
*
* @brief        IO Control API functions
*
* @author       Dedourek Pavel, Cid Mateo
*
********************************************************************************
* @version      ASIC2 Specification (Revision 2.9.3)
********************************************************************************
********************************************************************************
*/

#ifndef __IO_CTRL_API__
#define __IO_CTRL_API__

#include "ASIC2_pinout.h"
#include "errors_api.h"

/**
 * \defgroup io_ctrl_api ASIC2 Input Output Control API functions
 * 
 * \ingroup  io_ctrl   asic2_api
 *
 * \brief    API function to control Inputs/Outputs
 *
 */

/**@{*/ 

/* ############################################################################ */
/**
 * \brief Enumeration which describes the different functionality for each module
 *
 * \ingroup io_ctrl_api 
 */
typedef enum{
  UART_OE,                      ///<- UART module - Output Enable (OE)
  UART_RX,                      ///<- UART module - Receiver (RX)
  UART_TX,                      ///<- UART module - Transmitter (TX)
  HISPI_CS,                     ///<- HISPI module - Chip Select (CS)
  HISPI_SCLK,                   ///<- HISPI module - Source Clock (SCLK)
  HISPI_MOSI,                   ///<- HISPI module - Master Output Slave Input (MOSI)
  HISPI_MISO,                   ///<- HISPI module - Master Input Slave Output (MISO)
  I2C_SCL,                      ///<- I2C module - Clock line (SCL)
  I2C_SDA,                      ///<- I2C module - Data line (SDA)
  VIC_EXT_IRQ,                  ///<- VIC_EXT module - Interrupt (IRQ)
  HV_RS485_TXEN,                ///<- HV_CTRL module - RS485 Transmitter Enable (RS485_TXEN)
  HV_RS485_TX,                  ///<- HV_CTRL module - RS485 Transmitter (RS485_TX)
  HV_RS485_RX,                  ///<- HV_CTRL module - RS485 Receiver (RS485_RX)
  SWD_TXEN_0,                   ///<- SWD module - SWD Transmitter Enable 0 (SWD_TXEN_0)
  SWD_TX_0,                     ///<- SWD module - SWD Transmitter 0 (SWD_TX_0)
  SWD_RX_0,                     ///<- SWD module - SWD Receiver 0 (SWD_RX_0)
  SWD_TXEN_1,                   ///<- SWD module - SWD Transmitter Enable 1 (SWD_TXEN_1)
  SWD_TX_1,                     ///<- SWD module - SWD Transmitter 1 (SWD_TX_1)
  SWD_RX_1,                     ///<- SWD module - SWD Receiver 1 (SWD_RX_1)
  USI0_NSS,                     ///<- USI0 module - Negative Slave Select (NSS)
  USI0_SCK,                     ///<- USI0 module - Clock (SCK)
  USI0_SDI_RX,                  ///<- USI0 module - Serial Data Input / Receiver (SDI/RX)
  USI0_SDO_TX,                  ///<- USI0 module - Serial Data Output / Transmitter (SDO/TX)
  USI1_NSS,                     ///<- USI1 module - Negative Slave Select (NSS)
  USI1_SCK,                     ///<- USI1 module - Clock (SCK)
  USI1_SDI_RX,                  ///<- USI1 module - Serial Data Input / Receiver (SDI/RX)
  USI1_SDO_TX,                  ///<- USI1 module - Serial Data Output / Transmitter (SDO/TX)
  TSU_SYNC_EXT_OUT_0,           ///<- TSU module - External Synchronization Output 0 (SYNC_EXT_OUT_0)
  TSU_SYNC_EXT_IN,              ///<- TSU module - External Synchronization Input (SYNC_EXT_IN)
  TSU_SYNC_EXT_OUT_1,           ///<- TSU module - External Synchronization Output 1 (SYNC_EXT_OUT_1)
  PWMN_HS_0,                    ///<- PWMN module - High Side 0 (HS_0)
  PWMN_LS_0,                    ///<- PWMN module - Low Side 0 (LS_0)
  PWMN_HS_1,                    ///<- PWMN module - High Side 1 (HS_1)
  PWMN_LS_1,                    ///<- PWMN module - Low Side 0 (LS_1)
  PWMN_HS_2,                    ///<- PWMN module - High Side 2 (HS_2)
  PWMN_LS_2,                    ///<- PWMN module - Low Side 0 (LS_2)
  PWMN_HS_3,                    ///<- PWMN module - High Side 3 (HS_3)
  PWMN_LS_3,                    ///<- PWMN module - Low Side 3 (LS_3)
  PWMN_NALLOFF,                 ///<- PWMN module - Negative All Off (NALLOFF)
  HIAD_ALE,                     ///<- PWMN module - Address Latch Enable (ALE)
  CCTIMER0_MEAS_0,              ///<- CCTIMER0 module - Measurement 0 (MEAS_0)
  CCTIMER0_MEAS_1,              ///<- CCTIMER0 module - Measurement 1 (MEAS_1)
  CCTIMER0_MEAS_2,              ///<- CCTIMER0 module - Measurement 2 (MEAS_2)
  CCTIMER0_MEAS_3,              ///<- CCTIMER0 module - Measurement 3 (MEAS_3)
  CCTIMER0_PWM_0,               ///<- CCTIMER0 module - PWM 0 (PWM_0)
  CCTIMER0_PWM_1,               ///<- CCTIMER0 module - PWM 1 (PWM_1)
  CCTIMER1_MEAS_0,              ///<- CCTIMER1 module - Measurement 0 (MEAS_0)
  CCTIMER1_MEAS_1,              ///<- CCTIMER1 module - Measurement 1 (MEAS_1)          
  CCTIMER1_MEAS_2,              ///<- CCTIMER1 module - Measurement 2 (MEAS_2)  
  CCTIMER1_MEAS_3,              ///<- CCTIMER1 module - Measurement 3 (MEAS_3)
  CCTIMER1_PWM_0,               ///<- CCTIMER1 module - PWM 0 (PWM_0)
  CCTIMER1_PWM_1,               ///<- CCTIMER1 module - PWM 1 (PWM_1)
  SARADC_SYNC_OUT,              ///<- SARADC module - External Synchronization Output (SYNC_OUT)
  EL_CTRL_TX_EN,                ///<- EL_CTRL module - Transmitter Enable (TX_EN)
  EL_CTRL_TX,                   ///<- EL_CTRL module - Transmitter (TX)
  EL_CTRL_TIA_INT,              ///<- EL_CTRL module - TIA Interrupt (TIA_INT)
  EL_CTRL_RX_EXT                ///<- EL_CTRL module - Receiver External (RX_EXT)
} io_ctrl_api_func_e;

/* ############################################################################ */
/**
 * \brief  This function connect modul with the selected pinout
 *
 * \ingroup io_ctrl_api 
 *
 * \param gpio_pinout Desired pin
 *
 * \param module      Module to be connected to pin
 *
 * \return Error code
 */
errors_api_code_e io_ctrl_api_sel(device_pinout gpio_pinout, io_pin_func_t module);

/* ############################################################################ */
/**
 * \brief  This function checks if the desired functionality is available for the selected pinout
 *
 * \ingroup io_ctrl_api 
 *
 * \param gpio_pinout Desired pin
 * \param functionality Desired functionality
 * \param module Return pointer to the module which belongs the selected functionality
 * \return Error code
 */
errors_api_code_e io_ctrl_api_check_sel_func(device_pinout gpio_pinout, io_ctrl_api_func_e functionality, io_pin_func_t * module);

/* ############################################################################ */
/**
 * \brief  This function set the desired functionality for the selected pinout
 *
 * \ingroup io_ctrl_api 
 *
 * \param gpio_pinout Desired pin
 * \param functionality Desired functionality
 * \return Error code
 */
errors_api_code_e io_ctrl_api_set_sel_func(device_pinout gpio_pinout, io_ctrl_api_func_e functionality);

/* ############################################################################ */
/**
 * \brief Convert pad number (integer) to IOMUX value ( 0 -> IOMUX_PAD0)
 *
 * \param par_pad_idx pad number
 */
iomux_pad_t io_ctrl_api_num2iomux(int8_t par_pad_idx);
   
   
/* ############################################################################ */
/**
 * \brief  This function set for all pads pullups
 *
 * \ingroup io_ctrl_api 
 *
 */
void io_ctrl_api_all_pin_pullup(void);

/* ############################################################################ */
/**
 * \brief  This function set pullup to a specific pad
 *
 * \ingroup io_ctrl_api 
 *
 * \param gpio_pinout Desired pin
 *
 * \param enable pad 0: disable pullup <br>
 *                   1: enable pullup
 */
void io_ctrl_api_pullup_enable(device_pinout gpio_pinout, uint8_t enable);

/* ############################################################################ */
/**
 * \brief  Route RS-485 phy to pads
 *
 * \ingroup io_ctrl_api 
 *
 * \param pinout_hv_rs485_txen pad to control hv_txen
 *
 * \param pinout_hv_rs485_tx pad to control hv_tx
 *
 * \param pinout_hv_rs485_rx pad to control hv_rx
 *
 */
errors_api_code_e io_ctrl_api_rs485_hv_ctrl_pins(device_pinout pinout_hv_rs485_txen, device_pinout pinout_hv_rs485_tx, device_pinout pinout_hv_rs485_rx);


#endif