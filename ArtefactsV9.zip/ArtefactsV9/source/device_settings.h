/**
* \file 
*
* \brief  Device settings
*
* \author Eaton European Innovation Center 
*
*/

#ifndef __HAVE_DEVICE_SETTING_H__
#define __HAVE_DEVICE_SETTING_H__


/* ASIC2 pinout definition */
#include <ASIC2_pinout.h> // it is in asic2 repo submodule



/* Device type - see shared/include/SWD_Slave/swd_device_db.h */
#define SWD_DEVICE_DB_SWD4_BS24_1

/* SWD Slave Stack is used */
#define SWD_SLAVE_STACK


/* Device pinout declaration */
extern const device_pinout LED_4G;
extern const device_pinout BTN1;
extern const device_pinout BTN2;
extern const device_pinout BTN3;


/* ISINK definition */
#define ISINK_BLUE  0
#define ISINK_GREEN 1
#define ISINK_RED   2



// 
//  REQUIRED: Fill all these macros 
//

// Control WDOG0 behavioral in CCPU0
// 0 - normal setting 
// 1 - for debugging - WDOG0 does not reset device when ACPU freeze
#define APPLICATION_CONFIG_DISABLE_WATCHDOG_FOR_DEVELOPMENT_ONLY 0

// 0 - SWD status LED is connected to GPO
// 1 - SWD status LED is connected between GPO and ELRX
#define APPLICATION_CONFIG_USE_GPO_SWD_LED_AND_NOT_EL 0

// Software version
#define APPLICATION_CONFIG_SW_VER         1

// Hardware version
#define APPLICATION_CONFIG_HW_VER         1

// 1 - SWD Serial Debug interface
// 0 - JTAG interface
#define APPLICATION_CONFIG_JTAG_DIO       0  ///< 1 == SWD, 0 == JTAG

// REPEATER FUNCTIONALITY
#define APPLICATION_CONFIG_REPEATER_TYPE  REPEATER_OFF

// Where Flash0 starts - for bootloader mode crc checksum check
#define APPLICATION_CONFIG_BOOTLOADER_FLASH0_CRC16_START_ADDR   BASE_ADDR_FLASH0

// Flash0 size - for bootloader mode crc checksum check
#define APPLICATION_CONFIG_BOOTLOADER_FLASH0_CRC16_LENGTH       FLASH0_MAIN_SIZE-4

// Where Flash1 starts - for bootloader mode crc checksum check
#define APPLICATION_CONFIG_BOOTLOADER_FLASH1_CRC16_START_ADDR   BASE_ADDR_FLASH1

// Flash1 size - for bootloader mode crc checksum check
#define APPLICATION_CONFIG_BOOTLOADER_FLASH1_CRC16_LENGTH       FLASH1_MAIN_SIZE-4-512

// Bootloader mode 
// It is recommended to use only BOOTLOADER_MODE_CRC
#define APPLICATION_CONFIG_BOOTLOADER_MODE                      BOOTLOADER_MODE_CRC



// Selection of pad to be used for bootloader mode
//
// Example: p0=0, p1=1, p2=2, ...., p35=35 (does not depend on ASIC package)

//#define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P               2
//#define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P               15
//#define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P               24
//#define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_P               33 // X603.30

// The level on pad which tell to bootloader when to entry boortloader mode
//#define APPLICATION_CONFIG_BOOTLOADER_FORCE_PIN_VALUE            1

// It is dualcore application (true)
// DO NOT CHANGE
#define APPLICATION_CONFIG_BOOTLOADER_DUALCORE                  true



// 
//  REQUIRED: (search for all REQUIRED in this file to set all settings)
//    Please, select correct frequency of external oscillator or crystal
//
//#define CLK_NRES_QOSC_CLK_FREQ_HZ 14745600U // [Hz]
//#define CLK_NRES_QOSC_CLK_FREQ_HZ 1U // [Hz]
//#define CLK_NRES_QOSC_CLK_FREQ_HZ 2000000U // [Hz] (2MHz)
//#define CLK_NRES_QOSC_CLK_FREQ_HZ 10000000U // [Hz] (10MHz)
//
//


// 
//  REQUIRED: (search for all REQUIRED in this file to set all settings)
//    Please, select correct external clock source
//
#define CLK_NRES_ANA_OSC_QOSC_CLK_BYPASS   0 // quartz/XTAL resonator (passive)
//#define CLK_NRES_ANA_OSC_QOSC_CLK_BYPASS   1 // external oscillator (active)



// Freq [MHz]|      4      |      8      |     12      |     16      |     20      |     24      |     28   
//-----------|------|------|------|------|------|------|------|------|------|------|------|------|------|------
//STRENGTH   | min  | max  | min  | max  | min  | max  | min  | max  | min  | max  | min  | max  | min  | max
//       0   |  11  |  24  |   7  |  14  |   6  |  11  |   5  |   9  |   5  |   8  |   5  |   7  |   5  |   7
//       1   |  13  |  32  |   9  |  18  |   7  |  13  |   6  |  11  |   6  |  10  |   5  |   9  |   5  |   8
//       2   |  16  |  38  |  10  |  21  |   8  |  15  |   7  |  13  |   6  |  11  |   6  |  10  |   5  |   9
//       3   |  18  |  43  |  11  |  24  |   8  |  17  |   7  |  14  |   6  |  12  |   6  |  11  |   6  |  10
//       4   |  19  |  48  |  11  |  26  |   9  |  19  |   8  |  15  |   7  |  13  |   6  |  11  |   6  |  10
//       5   |  21  |  52  |  12  |  28  |   9  |  20  |   8  |  16  |   7  |  14  |   6  |  12  |   6  |  11
//       6   |  22  |  56  |  13  |  30  |  10  |  21  |   8  |  17  |   7  |  15  |   7  |  13  |   6  |  12
//       7   |  23  |  59  |  13  |  32  |  10  |  23  |   9  |  18  |   8  |  15  |   7  |  13  |   6  |  12
//
// Load Capacitor of Crystal Osc (CL)
//
//
//  REQUIRED: (search for all REQUIRED in this file to set all settings)
//    Please, select correct driving strength at a given load capacitance and frequency
#define CLK_NRES_RCOSC_QOSC_STRENGTH   3
//
//
// ==================================================================================================================================================
//
// ====================
// == Setting of PLL ==
// ====================
//
// 
// REQUIRED: 
// Please, select clock source for AS0 clock domain used for SWD and TSU units
// - comment not needed clock
// - uncomment needed clock
// 

#define CLK_NRES_PLL_FIN_CLK_SRC    CLK_NRES_RCOSC_SOURCE_FOR_PLL
//#define CLK_NRES_PLL_FIN_CLK_SRC    CLK_NRES_QOSC_SOURCE_FOR_PLL

//
//   PLL(FOUT) = FIN  * (NF+1) / (NR+1) * 1/(2^OD) =
//
#define CLK_NRES_PLL_NF   3
#define CLK_NRES_PLL_NR   0
#define CLK_NRES_PLL_OD   0
//
// ==================================================================================================================================================
// ==================================================================================================================================================
//
//
//
//                                                                    +-------+                              +---------+
//       rcosc_hf_clk (16MHz)+- CLK_NRES_RCOSC_HF_CLK_FREQ_HZ +------>+       |                              | NR-DIV  |
//                                                                    |  MUX  |                              |         |
//       qosc_clk +------------ CLK_NRES_QOSC_CLK_FREQ_HZ +---------->+       |                              |  INPUT  |
//                                                                    |       +-- CLK_NRES_PLL_FIN_FREQ_HZ --+ DIVIDER +--->+
//                                                                    +-------+         (4 .. 50 MHz )       |         |    |
//                                                                        |                                  | 1,2,3,4 |    |
//                                                                        |                                  | 5,6,7,8 |    |
//       CLK_NRES_CFG_ANA_PLL0.pll_fin_src +------------------------------+                                  +---------+    |
//                                                                                                               |          |
//       CLK_NRES_CFG_ANA_PLL1.pll_nr +--------------------------------------------------------------------------+          |
//                                                                                                                          |
//                                                                                                                          |
//       ^------------------------------------------------------------------------------------------------------------------+
//       |
//       |
//       |                                                                                          +---------+
//       |                                                                                          | OD-DIV  |
//       |  +------+                                  +-----+                                       |         |
//       |  | PFD  |                                  |     |                                       | OUTPUT  |
//       +--+      +-> CLK_NRES_PLL_FCMP_FREQ_HZ +--->+ VCO +-->   CLK_NRES_PLL_VCO_FREQ_HZ +--+--->+ DIVIDER +--->  CLK_NRES_PLL_FOUT_FREQ_HZ ---> pll_fout 
//          |      |         (4 .. 25 MHz )           |     |            (50 .. 100 MHz )      |    |         |
//          | phase|                                  +-----+                                  |    | 1,2,4,8 |
//       +--+ det. |                                                                           |    |         |
//       |  |      |                                                                           |    +---------+
//       |  +------+                                                                           |
//       |                                                           +---------+               |
//       |                                                           | NF-DIV  |               |
//       |                                                           |         |               |    The Asic is not able to operate
//       |                                                           | FEEDBACK|               |    with all possible PLL frequencies
//       +<----------------------------------------------------------+ DIVIDER | <-------------+
//                                                                   |         |
//                                                                   | 1,2,3,8 |
//                                                                   | .....32 |
//                                                                   +---------+
//
//
// ==================================================================================================================================================
//
// ============================================================
// == Setting of AS0 (SWD and TSU) clock source and dividers ==
// ============================================================
//
// 
// REQUIRED: 
// Please, select clock source for AS0 clock domain used for SWD and TSU units
// - comment not needed clock
// - uncomment needed clock
// 
//USE HERE MACRO DEFINITION, NOT enum (because PREPROCESSOR calculate all equations)
//

//#define CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC    M_CLOCK_SOURCE_RCOSC_HF
//#define CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC    M_CLOCK_SOURCE_QOSC
#define CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC    M_CLOCK_SOURCE_PLL
//#define CLK_NRES_CFG_AS0_SWD_TSU_CLK_SRC    
//
//
//
#define CLK_NRES_CFG_AS0_SWD_TSU_CLK_DIV    1
//
//
//
// ==================================================================================================================================================
//
//
//
//                                                                   +-------+    +---------+
//      rcosc_hf_clk (16MHz)+- CLK_NRES_RCOSC_HF_CLK_FREQ_HZ +------>+       |    |         |
//                                                                   |  MUX  |    | DIVIDER |
//      qosc_clk +------------ CLK_NRES_QOSC_CLK_FREQ_HZ +---------->+       |    |         |
//                                                                   |       +--->+         +---> CLK_NRES_AS0_SWD_TSU_FREQ_HZ +---> clk_as[0] +--> SWD
//      pll_fout +------------ CLK_NRES_PLL_FOUT_FREQ_HZ +---------->+       |    |         |                                                  |
//                                                                   |       |    |         |                                                  +--> TSU
//      rcosc_lf_clk +-------- CLK_NRES_RCOSC_LF_CLK +-------------->+       |    |         |
//                                                                   +---+---+    +---+-----+
//                                                                       ^            |
//                                                                       |            |
//                                 CLK_NRES_CFG_AS0_SWD_TSU.clk_src +----+            |
//                                                                                    |
//                                 CLK_NRES_CFG_AS0_SWD_TSU.clk_div +-----------------+
//
//
//
//
// ==================================================================================================================================================
//
// ============================================================
// == Setting of AS1 (USI0) clock source and dividers ==
// ============================================================
//
// REQUIRED: 
// Please, select clock source for AS1 clock domain used for USI0 units
// - comment not needed clock
// - uncomment needed clock
// 
//USE HERE MACRO DEFINITION, NOT enum (because PREPROCESSOR calculate all equations)
//
//
//#define CLK_NRES_CFG_AS1_USI0_CLK_SRC    M_CLOCK_SOURCE_RCOSC_HF
//#define CLK_NRES_CFG_AS1_USI0_CLK_SRC    M_CLOCK_SOURCE_QOSC
#define CLK_NRES_CFG_AS1_USI0_CLK_SRC    M_CLOCK_SOURCE_PLL
//#define CLK_NRES_CFG_AS1_USI0_CLK_SRC    M_CLOCK_SOURCE_RCOSC_LF
//
//
//
#define CLK_NRES_CFG_AS1_USI0_CLK_DIV    2
//
//
//
// ==================================================================================================================================================
//
//
//
//                                                                   +-------+    +---------+
//      rcosc_hf_clk (16MHz)+- CLK_NRES_RCOSC_HF_CLK_FREQ_HZ +------>+       |    |         |
//                                                                   |  MUX  |    | DIVIDER |
//      qosc_clk +------------ CLK_NRES_QOSC_CLK_FREQ_HZ +---------->+       |    |         |
//                                                                   |       +--->+         +---> CLK_NRES_AS1_USI0_FREQ_HZ +---> clk_as[1] +--> USI0
//      pll_fout +------------ CLK_NRES_PLL_FOUT_FREQ_HZ +---------->+       |    |         |
//                                                                   |       |    |         |
//      rcosc_lf_clk +-------- CLK_NRES_RCOSC_LF_CLK +-------------->+       |    |         |
//                                                                   +---+---+    +---+-----+
//                                                                       ^            |
//                                                                       |            |
//                                 CLK_NRES_CFG_AS0_SWD_TSU.clk_src +----+            |
//                                                                                    |
//                                 CLK_NRES_CFG_AS0_SWD_TSU.clk_div +-----------------+
//
//
//
//
// ==================================================================================================================================================
//
// ============================================================
// == Setting of AS2 (USI1) clock source and dividers ==
// ============================================================
//
// REQUIRED: 
// Please, select clock source for AS2 clock domain used for USI1 units
// - comment not needed clock
// - uncomment needed clock
// 
//USE HERE MACRO DEFINITION, NOT enum (because PREPROCESSOR calculate all equations)
//
//
//#define CLK_NRES_CFG_AS2_USI1_CLK_SRC    M_CLOCK_SOURCE_RCOSC_HF
//#define CLK_NRES_CFG_AS2_USI1_CLK_SRC    M_CLOCK_SOURCE_QOSC
#define CLK_NRES_CFG_AS2_USI1_CLK_SRC    M_CLOCK_SOURCE_PLL
//#define CLK_NRES_CFG_AS2_USI1_CLK_SRC    M_CLOCK_SOURCE_RCOSC_LF
//
//
//
#define CLK_NRES_CFG_AS2_USI1_CLK_DIV    2
//
//
//
// ==================================================================================================================================================
//
//
//
//                                                                   +-------+    +---------+
//      rcosc_hf_clk (16MHz)+- CLK_NRES_RCOSC_HF_CLK_FREQ_HZ +------>+       |    |         |
//                                                                   |  MUX  |    | DIVIDER |
//      qosc_clk +------------ CLK_NRES_QOSC_CLK_FREQ_HZ +---------->+       |    |         |
//                                                                   |       +--->+         +---> CLK_NRES_AS2_USI1_FREQ_HZ +---> clk_as[2] +--> USI1
//      pll_fout +------------ CLK_NRES_PLL_FOUT_FREQ_HZ +---------->+       |    |         |
//                                                                   |       |    |         |
//      rcosc_lf_clk +-------- CLK_NRES_RCOSC_LF_CLK +-------------->+       |    |         |
//                                                                   +---+---+    +---+-----+
//                                                                       ^            |
//                                                                       |            |
//                                 CLK_NRES_CFG_AS0_SWD_TSU.clk_src +----+            |
//                                                                                    |
//                                 CLK_NRES_CFG_AS0_SWD_TSU.clk_div +-----------------+
//
//
//
//
// ==================================================================================================================================================
//
// ============================================================
// == Setting of AS3 (HISPI) clock source and dividers ==
// ============================================================
//
// REQUIRED: 
// Please, select clock source for AS3 clock domain used for HISPI units
// - comment not needed clock
// - uncomment needed clock
// 
//USE HERE MACRO DEFINITION, NOT enum (because PREPROCESSOR calculate all equations)
//
//
//#define CLK_NRES_CFG_AS3_HISPI_CLK_SRC    M_CLOCK_SOURCE_RCOSC_HF
//#define CLK_NRES_CFG_AS3_HISPI_CLK_SRC    M_CLOCK_SOURCE_QOSC
#define CLK_NRES_CFG_AS3_HISPI_CLK_SRC    M_CLOCK_SOURCE_PLL
//#define CLK_NRES_CFG_AS3_HISPI_CLK_SRC    M_CLOCK_SOURCE_RCOSC_LF
//
//
//
#define CLK_NRES_CFG_AS3_HISPI_CLK_DIV    2
//
//
//
// ==================================================================================================================================================
//
//
//
//                                                                   +-------+    +---------+
//      rcosc_hf_clk (16MHz)+- CLK_NRES_RCOSC_HF_CLK_FREQ_HZ +------>+       |    |         |
//                                                                   |  MUX  |    | DIVIDER |
//      qosc_clk +------------ CLK_NRES_QOSC_CLK_FREQ_HZ +---------->+       |    |         |
//                                                                   |       +--->+         +---> CLK_NRES_AS3_HISPI_FREQ_HZ +---> clk_as[3] +--> HISPI
//      pll_fout +------------ CLK_NRES_PLL_FOUT_FREQ_HZ +---------->+       |    |         |
//                                                                   |       |    |         |
//      rcosc_lf_clk +-------- CLK_NRES_RCOSC_LF_CLK +-------------->+       |    |         |
//                                                                   +---+---+    +---+-----+
//                                                                       ^            |
//                                                                       |            |
//                                 CLK_NRES_CFG_AS0_SWD_TSU.clk_src +----+            |
//                                                                                    |
//                                 CLK_NRES_CFG_AS0_SWD_TSU.clk_div +-----------------+
//
//
//
//
// ==================================================================================================================================================
//
// ===============================================
// == Setting of MAIN clock source and dividers ==
// ===============================================
//
// REQUIRED: 
// Please, select clock source for main clock
// - comment not needed clock
// - uncomment needed clock
// 
//USE HERE MACRO DEFINITION, NOT enum (because PREPROCESSOR calculate all equations)
//
//
//#define CLK_NRES_CFG_M_CLK_SRC    M_CLOCK_SOURCE_RCOSC_HF
//#define CLK_NRES_CFG_M_CLK_SRC    M_CLOCK_SOURCE_QOSC
#define CLK_NRES_CFG_M_CLK_SRC    M_CLOCK_SOURCE_PLL
//#define CLK_NRES_CFG_M_CLK_SRC    M_CLOCK_SOURCE_RCOSC_LF
//
//
//
#define CLK_NRES_CFG_M_CLK_DIV    2
//
//
//
// ==================================================================================================================================================
//
//
//
//                                                                     +-------+    +---------+
//        rcosc_hf_clk (16MHz)+- CLK_NRES_RCOSC_HF_CLK_FREQ_HZ +------>+       |    |         |                              clk_main
//                                                                     |  MUX  |    | DIVIDER |                               |
//        qosc_clk +------------ CLK_NRES_QOSC_CLK_FREQ_HZ +---------->+       |    |         |                               +---> CCPU0/ACPU1
//                                                                     |       +--->+         +---> CLK_NRES_CLK_MAIN_FREQ_HZ |
//        pll_fout +------------ CLK_NRES_PLL_FOUT_FREQ_HZ +---------->+       |    |         |                               +---> CRC0
//                                                                     |       |    |         |                               |
//        rcosc_lf_clk +-------- CLK_NRES_RCOSC_LF_CLK +-------------->+       |    |         |                               +---> CRC1
//                                                                     +---+---+    +---+-----+                               |
//                                                                         ^            |                                     +---> HIAD
//                                                                         |            |                                     |
//                                             CLK_NRES_CFG_M.clk_src +----+            |                                     +---> HISPI
//                                                                                      |                                     |
//                                             CLK_NRES_CFG_M.clk_div +-----------------+                                     +---> SWD
//                                                                                                                            |
//                                                                                                                            +---> SARADC_CTRL
//                                                                                                                            |
//                                                                                                                            +---> USI0
//                                                                                                                            |
//                                                                                                                            +---> USI1
//
//
//
//
// ==================================================================================================================================================
//
// ==========================================
// == Setting of peripheral clock dividers ==
// ==========================================
//
// REQUIRED: 
// Please, select division ration for each peripheral clock domain
//
#define CLK_NRES_CFG_LOW_RATE_0   1
#define CLK_NRES_CFG_LOW_RATE_1   1
#define CLK_NRES_CFG_HIGH_RATE    1
//
//
//
// ==================================================================================================================================================
//
//                                                                                                        +-------+
//                                                                                                        |       |
//                    +--------------------------> CLK_NRES_FULL_RATE_FREQ_HZ +------------------+------->+       |
//                    |                                                                          |        |       |
//                    |       DIVIDERS                                                           |        |  MUX  |
//                    |      +-----------+                                                       |        |       |
//                    +----> |/HIGH_RATE +-------> CLK_NRES_HIGH_RATE_FREQ_HZ +--------------+----------->+       |                  +------+
//                    |      +-----------+                                                   |   |        |       |                  |      |
//      clk_main +----+                                                                      |   |        |       +-> clk( 11 )  +-->+ TSU  |
//                    |      +-----------+                                                   |   |        |       |                  |      |
//                    +----> |/LOW_RATE_0+-------> CLK_NRES_LOW_RATE_0_FREQ_HZ +---------+--------------->+       |                  +------+
//                    |      +-----------+                                               |   |   |        |       |
//                    |                                                                  |   |   |        |       |
//                    |      +-----------+                                               |   |   |        |       |   There is MUX for each
//                    +----> |/LOW_RATE_1+-------> CLK_NRES_LOW_RATE_1_FREQ_HZ +-----+------------------->+       |   peripheral block where
//                           +-----------+                                           |   |   |   |        |       |   you can select which clock
//                                                                                   |   |   |   |        +-^-----+   is used for this block
//                                                                                   |   |   |   |          |  .
//      cfg_rate_sel_tsu +----------------------------------------------------------------------------------+  .
//         ...                                                                       |   |   |   |             .
//      cfg_rate_sel_el_ctrl +------------------------------------------------------------------------------+  .
//                                                                                   |   |   |   |        +-v-----+
//                   +-------------------+ +------------------------+                |   |   |   |        |       |                     .
//                   | clk     peri      | | clk     peri           |                |   |   |   +------->+       |                     .
//                   +-------------------+ +------------------------+                |   |   |            |       |                     .
//                   | 11      TSU       | | 22      CCTIMER0       |                |   |   |            |       |                     .
//                   | 12      GPIO      | | 23      CCTIMER1       |                |   |   |            |  MUX  |                     .
//                   | 13      GUARD0    | | 24      IO_CTRL        |                |   |   |            |       |
//                   | 14      GUARD1    | | 25      ANALOG_CTRL    |                |   |   +----------->+       |                  +--------+
//                   | 15      SWTIMER0  | | 26      ACCESS_CONTROL |                |   |                |       |                  |        |
//                   | 16      SWTIMER1  | | 27      HV_CTRL        |                |   |                |       +-> clk( 31 )  +-->+EL_CTRL |
//                   | 17      PWMN      | | 28      UART           |                |   |                |       |                  |        |
//                   | 18      VIC_EXT   | | 29      AOUT_CTRL      |                |   +--------------->+       |                  +--------+
//                   | 19      WDOG0     | | 30      I2C            |                |                    |       |
//                   | 20      WDOG1     | | 31      EL_CTRL        |                |                    |       |
//                   | 21      CPU_N_CPU | |                        |                |                    |       |
//                   | 22      CCTIMER0  | |                        |                +------------------->+       |
//                   |                   | |                        |                                     |       |
//                   +-------------------+ +------------------------+                                     +-------+
//
// ==================================================================================================================================================
//
// =========================================
// == Setting of peripheral clock domains ==
// =========================================
//
// 
// REQUIRED: 
// Please, select peripheral clock domain for each peripheral
//
// USE HERE MACRO DEFINITION, NOT enum (because PREPROCESSOR calculate all equations)
//
// Use following macro definition:
//  FULL_RATE
//  HIGH_RATE
//  LOW_RATE_0
//  LOW_RATE_1
//
#define CLK_NRES_CFG_RATE_SEL_TSU           HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_GPIO          HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_GUARD0        HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_GUARD1        HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_SWTIMER0      HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_SWTIMER1      HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_PWMN          HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_VIC_EXT       HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_WDOG0         HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_WDOG1         HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_CPU_N_CPU     HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_CCTIMER0      HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_CCTIMER1      HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_IO_CTRL       HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_ANALOG_CTRL   HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_ACCESS_CTRL   HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_HV_CTRL       HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_UART          HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_AOUT_CTRL     HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_I2C           HIGH_RATE
#define CLK_NRES_CFG_RATE_SEL_EL_CTRL       HIGH_RATE

  

#endif
  