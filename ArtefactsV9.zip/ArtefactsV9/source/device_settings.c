#include "ASIC2_pinout.h"

#include "hardware.h"

  const device_pinout LED_4G = IOMUX_PAD28_STRUCT;  ///< LED4 (green)   <-> X603.20
  const device_pinout BTN1   = IOMUX_PAD29_STRUCT;  ///< Button 1  X214 <-> X603.22
  const device_pinout BTN2   = IOMUX_PAD30_STRUCT;  ///< Button 2  X215 <-> X603.24
  const device_pinout BTN3   = IOMUX_PAD31_STRUCT;  ///< Button 3  X216 <-> X603.26
  

  