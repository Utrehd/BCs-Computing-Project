// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_states.c
// *
// * @brief        Defines the different states used within the state machine.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_states.h"

#warning "Memory location for protoype, should be updated by new ASIC2 lib."
// The construct containing the memory location of the LCF Instructions
extern const application_config_t application_config;

// *****************************************************************************
// **** STATE FUNCTIONS ********************************************************
// *****************************************************************************

// **** INITALIZATION **********************************************************
void lcf_state_initalization()
{
  // Set up IO's
  lcf_io_handler_init();
  // Init memeory manager with defining the location of the LCF code
  lcf_memory_manager_init(application_config.reserved2);
}

// **** READING ****************************************************************
void lcf_state_reading_io()
{
  // Read all inputs into the register.
  lcf_io_reader_read_io_to_input_register();
}

// **** INTERPRETING ***********************************************************
void lcf_state_interpreting()
{
  // While within payload
  while(lcf_memory_manager_check_index_within_payload())
  {
    // Read instruction from memory.
    uint8_t instruction = lcf_memory_manager_get_next_payload_element();
    lcf_instruction_execution_run_instruction(instruction);
  }
  // Set back payload pointer back to memory 
  lcf_memory_manager_reset_payload_index();  
}

// **** WRITING ****************************************************************
void lcf_state_writing_io()
{
  // Read all inputs into the register.
  lcf_io_writer_write_output_register_to_io();
}

// **** ERROR ******************************************************************
void lcf_state_error()
{
  // All Outptus off.
  lcf_io_handler_write_output(eQ0, false);
  lcf_io_handler_write_output(eQ1, false);
  lcf_io_handler_write_output(eQ2, false);
  lcf_io_handler_write_output(eQ3, false);
}

