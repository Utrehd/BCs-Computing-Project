// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_io_writer.c
// *
// * @brief        Defines the IO writer functions for the LCF Interpreter.
// *               Based on the 4D4D.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_io_writer.h"
#include "lcf_io_handler.h"

// *****************************************************************************
// **** INITALIZATION **********************************************************
// *****************************************************************************
bool lcf_io_writer_output_register[4] = {false, false, false, false};

// *****************************************************************************
// **** FUNCTIONS **************************************************************
// *****************************************************************************

// **** SAVE VALUE IN OUTPUT REGISTER ******************************************
// Will update a new output register
void lcf_io_writer_save_value_in_output_register(
        lcf_io_handler_output_e output, bool value)
{
  lcf_io_writer_output_register[output] = value;
}

// **** WRITE IO'S TO REGISTER *************************************************
// Will write the whole output register to the IO.
void lcf_io_writer_write_output_register_to_io()
{
  // Write register value to output zero
  lcf_io_handler_write_output(eQ0, lcf_io_writer_output_register[eQ0]);
  // Write register value to output one
  lcf_io_handler_write_output(eQ1, lcf_io_writer_output_register[eQ1]);
  // Write register value to output tow
  lcf_io_handler_write_output(eQ2, lcf_io_writer_output_register[eQ2]);
  // Write register value to output three
  lcf_io_handler_write_output(eQ3, lcf_io_writer_output_register[eQ3]);
}