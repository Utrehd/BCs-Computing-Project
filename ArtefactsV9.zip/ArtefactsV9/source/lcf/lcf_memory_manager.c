// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_memory_manager.c
// *
// * @brief        Manages the memory where the encoded LCF code is stored
// *               within the ASIC2.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_memory_manager.h"

// *****************************************************************************
// **** DECLARATIONS ***********************************************************
// *****************************************************************************
// The memory payload looks like this:
// [payload_size],[Version],[Payload],[""],[Checksum]

// Defines the memory of the lcf code. 
const uint8_t *ptr_memory;

// Contains the actually used space of the memory.
uint8_t payload_size;

// Define the operation index used for pointing to code within the memory.
uint8_t payload_index;

// Checksum
uint8_t memory_checksum;

// *****************************************************************************
// **** INITIALIZATION *********************************************************
// *****************************************************************************

// Defines the index of the element, defining the size of the payload.
const uint8_t payload_size_index = 0;
// Version index
const uint8_t version_index = 1;
// The size of the header
const uint8_t header_size = 2;
// The size of the checksum
const uint8_t checksum_size = 1;


// *****************************************************************************
// **** MEMORY FUNCTIONS *******************************************************
// *****************************************************************************

// **** SET MEMORY *************************************************************
void lcf_memory_manager_init(const uint8_t target_memory[LCF_MEMORY_SIZE])
{
  // Set the memory
  ptr_memory = target_memory;
  // Get the used space
  payload_size = ptr_memory[payload_size_index];
  // Set the payload index to a position before the payload starts.
  payload_index = version_index;
}

// **** GET NEXT ELEMENT *******************************************************
uint8_t lcf_memory_manager_get_next_payload_element()
{
  // Increment payload
  payload_index ++;
  uint8_t element = ptr_memory[payload_index];
  return element;
}

// **** CHECK WITHIN PAYLOAD ***************************************************
bool lcf_memory_manager_check_index_within_payload()
{
  // If the index is below the used memory space.
  if(payload_index <
      (version_index + payload_size))
  {
    return true;
  }
  return false;
}

// **** SET INDEX TO START *****************************************************
void lcf_memory_manager_reset_payload_index()
{
  // Set index to beginning of lcf code in the memory.
  payload_index = version_index;
}

// **** GET CHECKSUM ***********************************************************
uint8_t lcf_memory_manager_get_checksum()
{
  // Get checksum which is at the end of the payload
  uint8_t checksum = ptr_memory[version_index + payload_size + checksum_size];
  return checksum;
}

// **** GET VERSION ************************************************************
uint8_t lcf_memory_manager_get_version()
{
  uint8_t version = ptr_memory[version_index];
  return version;
}