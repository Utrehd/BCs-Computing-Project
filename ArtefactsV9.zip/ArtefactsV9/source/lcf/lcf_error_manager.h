
/**
********************************************************************************
********************************************************************************
**** @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
****               Cezchia, All rights reserved
****
**** @file         lcf_states.h
****
**** @brief        Declears the states of the LCF state machine.
****
**** @author       Samuel A. Marti
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
**** @defgroup     LCF_Error_Manager
**** @brief        Declears the error manager used for managing the errors of 
****               LCF.
********************************************************************************
*/
#ifndef __LCF_ERROR_MANAGER__
#define __LCF_ERROR_MANAGER__

/**
********************************************************************************
**** @brief        Defines the possible error states of the device.
******************************************************************************** 
*/
typedef enum 
{
  eError_LCF_None,
  eError_LCF_Read_IO_Input,
  eError_LCF_Write_IO_Output,
  eError_LCF_IO_Init_Clock,
  eError_LCF_IO_Init_Output,
  eError_LCF_IO_Init_Input,
  eError_LCF_Stack_Machine_Full,
  eError_LCF_Stack_Machine_Empty
} lcf_error_manager_error_e;

/**
********************************************************************************
**** @brief        Set the error behaviour into motion.
**** @remark       will enter the error state defined in the state machine.
********************************************************************************
*/
void lcf_error_manager_set_error(lcf_error_manager_error_e error);

/**
********************************************************************************
**** @brief        Will return the current state of the error
********************************************************************************
*/
lcf_error_manager_error_e lcf_error_manager_get_error_state();

#endif