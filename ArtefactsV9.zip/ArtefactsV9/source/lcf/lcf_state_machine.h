/**
********************************************************************************
********************************************************************************
**** @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
****               Cezchia, All rights reserved
****
**** @file         lcf_stack_machine.h
****
**** @brief        Declears the stack machine functions.
****
**** @author       Samuel A. Marti
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
**** @defgroup     LCF_State_Machine
**** @brief        Declears the state machine of the interpreter.
********************************************************************************
*/

#ifndef __LCF_STATE_MACHINE__
#define __LCF_STATE_MACHINE__

#include "lcf_states.h"
#include "lcf_error_manager.h"

/**
********************************************************************************
**** @brief        Runs the state machine of the interpreter.
********************************************************************************
*/
void lcf_state_machine_run();

/**
********************************************************************************
**** @brief        Will enter the error state when called.
********************************************************************************
*/
void lcf_state_machine_enter_error_state();
#endif