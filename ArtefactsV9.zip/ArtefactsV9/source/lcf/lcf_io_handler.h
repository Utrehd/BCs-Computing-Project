/**
********************************************************************************
********************************************************************************
**** @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
****               Cezchia, All rights reserved
****
**** @file         lcf_io_handler.h
****
**** @brief        Defines the IO functions for the lcf interpreter
****
**** @author       Samuel A. Marti
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
**** @defgroup     LCF_IO_Handler
**** @brief        Contains functions for the usage of the IO's of the 4D4D.
********************************************************************************
*/
#ifndef __LCF_IO_HANDLER__
#define __LCF_IO_HANDLER__

#include "gpio_api.h"
#include "io_ctrl_api.h"
#include "clk_nres_api.h"
#include "errors_api.h"
#include "ASIC2_pinout.h"
#include "lcf_error_manager.h"

/**
********************************************************************************
**** @brief        Defines the 4D4D IO Outputs.
******************************************************************************** 
*/
typedef enum
{
  eQ0,
  eQ1,
  eQ2,
  eQ3
} lcf_io_handler_output_e;

/**
********************************************************************************
**** @brief        Defines the 4D4D IO Inputs.
******************************************************************************** 
*/
typedef enum
{
  eI0,
  eI1,
  eI2,
  eI3
} lcf_io_handler_input_e;

/**
********************************************************************************
**** @brief        Will try init the IO's of the 4D4D.
**** @remark       If function fails the lcf_error_handling will be called.
********************************************************************************
*/
void lcf_io_handler_init();

/**
********************************************************************************
**** @brief        Will try write read the value from defined input.
**** @param        input        The input of which the value will be read.
**** @return       bool         Value of read input
**** @remark       If function fails the lcf_error_handling will be called.
********************************************************************************
*/
bool lcf_io_handler_read_input(lcf_io_handler_input_e input);

/**
********************************************************************************
**** @brief        Will try write value to output zero.
**** @param        output       The target output to write value.
**** @param        value        The value which should be written.
**** @remark       If function fails the lcf_error_handling will be called.
********************************************************************************
*/
void lcf_io_handler_write_output(lcf_io_handler_output_e output, bool value);

#endif