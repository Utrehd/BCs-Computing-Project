// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_io_handler.c
// *
// * @brief        Defines the IO functions for the 4D4D IO module.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_io_handler.h"

// *****************************************************************************
// **** INITALIZATION **********************************************************
// *****************************************************************************
// Defines the IO's used by the 4D4D.
// Input Array
const device_pinout io_inputs[]= 
{
  IOMUX_PAD4_STRUCT,
  IOMUX_PAD3_STRUCT,
  IOMUX_PAD2_STRUCT,
  IOMUX_PAD1_STRUCT
};

// Output Array
const device_pinout io_outputs[]= 
{
  IOMUX_PAD18_STRUCT,
  IOMUX_PAD19_STRUCT,
  IOMUX_PAD20_STRUCT,
  IOMUX_PAD21_STRUCT
};

// Diag Output
const device_pinout Diag = IOMUX_PAD31_STRUCT;

// *****************************************************************************
// **** INIT IO FUNCTIONS ******************************************************
// *****************************************************************************

// **** INIT INPUT *************************************************************
static void lcf_io_handler_init_input(device_pinout input)
{
  // Inite new error code 
  errors_api_code_e error = eError_none;
  // Select Pin
  error |= io_ctrl_api_sel(input, IO_GPIO);
  // Set pin mode as input
  error |= gpio_api_pin_mode(input, eInput);
  // Set sampler time
  gpio_api_set_sampler_f0_time(input, 30);
  
  // Check if error and handle it.
  if(error != eError_none)
  {
    lcf_error_manager_set_error(eError_LCF_IO_Init_Input);
  }
}

// **** INIT OUTPUT ************************************************************
static void lcf_io_handler_init_output(device_pinout output)
{
  // Inite new error code 
  errors_api_code_e error = eError_none;
  // Select Pin
  error |= io_ctrl_api_sel(output, IO_GPIO);
  // Set pin mode as output
  error |= gpio_api_pin_mode(output, eOutput);
  // Set output to low
  gpio_api_digital_output(output, eLow);
  
  // Check if error and handle it.
  if(error != eError_none)
  {
    lcf_error_manager_set_error(eError_LCF_IO_Init_Output);
  }
}

// **** INIT *******************************************************************
void lcf_io_handler_init()
{
  // Inite new error code 
  errors_api_code_e error;
  
  // Set GPIO Clock
  error = clk_nres_api_set_clock_partition(CLKPNO_GPIO , true);
  
  // Init input pins
  lcf_io_handler_init_input(io_inputs[0]);
  lcf_io_handler_init_input(io_inputs[1]);
  lcf_io_handler_init_input(io_inputs[2]);
  lcf_io_handler_init_input(io_inputs[3]);
  
  // Init output pins
  lcf_io_handler_init_output(io_outputs[0]);
  lcf_io_handler_init_output(io_outputs[1]);
  lcf_io_handler_init_output(io_outputs[2]);
  lcf_io_handler_init_output(io_outputs[3]);

  // Check if error and handle it.
  if(error != eError_none)
  {
    lcf_error_manager_set_error(eError_LCF_IO_Init_Clock);
  }
}

// *****************************************************************************
// **** READ INPUT FUNCTIONS ***************************************************
// *****************************************************************************

// **** GET PIN ****************************************************************
// Will match the given enum with the array in order to get the correct pinout.
static device_pinout lcf_io_handler_get_io_input(lcf_io_handler_input_e io)
{
  return io_inputs[io];
}

// **** READ INPUT *************************************************************
// Will try to read the input and handle the error as defined.
bool lcf_io_handler_read_input(lcf_io_handler_input_e input)
{
  // Init var for result
  bool result;
  // Init error var for handling potential errors
  errors_api_code_e error;
  // Init io pinout
  device_pinout pinout;
  
  // Get pinout from enum
  pinout = lcf_io_handler_get_io_input(input);
  // Try to read input
  error = gpio_api_digital_input(pinout, eFilter_f0, &result);
  
  // Check if error and handle it.
  if(error != eError_none)
  {
    lcf_error_manager_set_error(eError_LCF_Read_IO_Input);
  }
  // Return inverted result, since hardware is inverting the value beforehand.
  return !result;
}

// *****************************************************************************
// **** WRITE OUTPUT FUNCTIONS *************************************************
// *****************************************************************************

// **** GET PIN ****************************************************************
// Will match the given enum with the array in order to get the correct pinout.
static device_pinout lcf_io_handler_get_io_output(lcf_io_handler_output_e io)
{
  return io_outputs[io];
}

// **** READ OUTPUT ************************************************************
// Will try to write to an output and handle the error as defined.
void lcf_io_handler_write_output(lcf_io_handler_output_e output, bool value)
{
  // Init error var for handling potential errors
  errors_api_code_e error;
  // Get io pinout
  device_pinout pinout;
  
  // Get device pinout
  pinout = lcf_io_handler_get_io_output(output);
  // Write value to output
  if(value == true)
  {
    // Write true to GPIO
    error = gpio_api_digital_output(pinout, eHigh);
  }
  else
  {
    // Write false to GPIO
    error = gpio_api_digital_output(pinout, eLow);
  }
  
  // Check if error and handle it.
  if(error != eError_none)
  {
    lcf_error_manager_set_error(eError_LCF_Write_IO_Output);
  }
}