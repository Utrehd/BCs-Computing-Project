// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_state_machine.c
// *
// * @brief        Defines the IO functions for the lcf interpreter
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_state_machine.h"

// *****************************************************************************
// **** DECLARATION ************************************************************
// *****************************************************************************

// *****************************************************************************
// * @brief        Defines the states of the statemachine.
// ***************************************************************************** 
typedef enum
{
  eSTATE_INITALIZATION,
  eSTATE_READING,
  eSTATE_WRITING,
  eSTATE_INTERPRETING,
  eSTATE_ERROR
} lcf_state_e;

// *****************************************************************************
// **** INITALIZATION **********************************************************
// *****************************************************************************
lcf_state_e state = eSTATE_INITALIZATION;

// *****************************************************************************
// **** STATE MACHINE **********************************************************
// *****************************************************************************
void lcf_state_machine_run()
{
  switch(state)
  {
    case eSTATE_INITALIZATION:
      lcf_state_initalization();
      state = eSTATE_READING;
      break;
      
    case eSTATE_READING:
      lcf_state_reading_io();
      state = eSTATE_INTERPRETING;
      break;
      
    case eSTATE_INTERPRETING:
      lcf_state_interpreting();
      state = eSTATE_WRITING;
      break;
      
    case eSTATE_WRITING:
      lcf_state_writing_io();
      state = eSTATE_READING;
      break;
      
    case eSTATE_ERROR:
      lcf_state_error();
      break;
  }
  // Check the error manager and move into the error state.
  if(lcf_error_manager_get_error_state() != eError_LCF_None)
  {
    state = eSTATE_ERROR;
  }
}
