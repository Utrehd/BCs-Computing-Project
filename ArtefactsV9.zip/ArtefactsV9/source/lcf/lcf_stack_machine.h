/**
********************************************************************************
********************************************************************************
**** @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
****               Cezchia, All rights reserved
****
**** @file         lcf_stack_machine.h
****
**** @brief        Declears the stack machine functions.
****
**** @author       Samuel A. Marti
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
**** @defgroup     LCF_Stack_Machine
**** @brief        Declears the stack machine functions.
********************************************************************************
*/
#ifndef __LCF_STACK_MACHINE__
#define __LCF_STACK_MACHINE__

#include "lcf_io_reader.h"
#include "lcf_io_writer.h"
#include "lcf_io_handler.h"
#include "lcf_error_manager.h"

/**
********************************************************************************
**** @brief        Will push given value onto the stack.
**** @param        value; The value to be pushed.
********************************************************************************
*/
void lcf_stack_machine_push(uint8_t value);

/**
********************************************************************************
**** @brief        Will push value from defined input.
**** @param        input; The the input from which the value should be pushed.
**** @remark       The value will be taken from the input register and not 
****               directly from the input.
********************************************************************************
*/
void lcf_stack_machine_push_p(lcf_io_handler_input_e input);

/**
********************************************************************************
**** @brief        Will pop the top most value from the stack.
**** @return       uint8_t; The value which was popped from the stack.
********************************************************************************
*/
uint8_t lcf_stack_machine_pop();

/**
********************************************************************************
**** @brief        Will pop the top most value from the stack and write it to 
****               the address of an output.
**** @param        output; The output to which the value should be buffered for.
**** @remark       This function will write to the output register.
********************************************************************************
*/
void lcf_stack_machine_pop_p(lcf_io_handler_output_e output);

/**
********************************************************************************
**** @brief        Will determind the biggest value of the topmost two elemenst,  
****               remove both, and place the result back on the stack. 
********************************************************************************
*/
void lcf_stack_machine_max();

/**
********************************************************************************
**** @brief        Will determind the smaller value of the topmost two elemenst, 
****               remove both, and place the result back on the stack.
********************************************************************************
*/
void lcf_stack_machine_min();

/**
********************************************************************************
**** @brief        Substract second element from the top from the first element,
****               removes both values from the stack, and puts the result back.
********************************************************************************
*/
void lcf_stack_machine_sub();

/**
********************************************************************************
**** @brief        Compares the top most elements of the stack if they are 
****               unequal will remove both and push 1 if they are equal push 0.
********************************************************************************
*/
void lcf_stack_machine_compare_neq();

#endif