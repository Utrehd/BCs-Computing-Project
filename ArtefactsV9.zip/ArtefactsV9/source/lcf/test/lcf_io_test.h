// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_io_test.h
// *
// * @brief        Defines the io test functions, of the lcf handler, writer and
// *               reader.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// * @defgroup     LCF Tests
// * @brief        Functions for testing the LCF code.
// *****************************************************************************

#ifndef __LCF_IO_TEST__
#define __LCF_IO_TEST__

#include <lcf_io_reader.h>
#include <lcf_io_writer.h>

// *****************************************************************************
// * @brief        Will start the IO test.
// * @remark       The IO test requires physical input of the tester.
// *               It will just map all pyhsical input to a physical output in
// *               following manner.
// *               Q0 --> I0, Q1 --> I1, Q2 --> I1, Q3 --> I3, Q4 --> I4
// *               That means the execution and validation of the test requiers
// *               a tester.
// *****************************************************************************
void lcf_io_test_run();

#endif