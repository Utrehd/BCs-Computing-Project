// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_memory_manager_test.c
// *
// * @brief        Used for testing the memory manager.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_memory_manager_test.h"

// *****************************************************************************
// **** INITIALIZATION *********************************************************
// *****************************************************************************
// memory for testing containing ecoding
uint8_t mem[LCF_MEMORY_SIZE] = 
{
  0x04, // Size of Payload
  0xA2, // Version
  0x13, // START OF PAYLOAD
  0x14,
  0x15,
  0x16, // END OF PAYLOAD
  0xFF, // Checksum
  0x00, // Remaining space of memory which is not used
  0x00, 
};

// *****************************************************************************
// **** TEST FUNCTION **********************************************************
// *****************************************************************************

// **** GET NEXT ELEMENT1 *******************************************************
static lcf_memory_manager_test_error_e lcf_memory_manager_test_next_element1()
{
  // ARRANGE
  lcf_memory_manager_init(mem);
  uint8_t should = 0x15;

  // ACT
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();
  uint8_t output = lcf_memory_manager_get_next_payload_element();
  
  // ASSERT
  if(output == should)
  {
    return eMEMMA_NO_ERROR;
  }
  return eGET_NEXT_ELEMENT;
}

// **** GET NEXT ELEMENT2 *******************************************************
static lcf_memory_manager_test_error_e lcf_memory_manager_test_next_element2()
{
  // ARRANGE
  lcf_memory_manager_init(mem);
  uint8_t should = 0x13;

  // ACT
  uint8_t output = lcf_memory_manager_get_next_payload_element();
  
  // ASSERT
  if(output == should)
  {
    return eMEMMA_NO_ERROR;
  }
  return eGET_NEXT_ELEMENT;
}

// **** CHECK NOT LAST ELEMENT1 ************************************************
static lcf_memory_manager_test_error_e lcf_memory_manager_test_check_pointer1()
{
  // ARRANGE
  lcf_memory_manager_init(mem);
  // Move 5 times
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();

  // ACT & ASSERT
  if(lcf_memory_manager_check_pointer_within_payload())
  {
    return eMEMORY_SPACE;    
  }
  return eMEMMA_NO_ERROR;
}

// **** CHECK NOT LAST ELEMENT2 ************************************************
static lcf_memory_manager_test_error_e lcf_memory_manager_test_check_pointer2()
{
  // ARRANGE
  lcf_memory_manager_init(mem);
  // Move 4 times
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();
  
  // ACT & ASSERT
  if(lcf_memory_manager_check_pointer_within_payload())
  {
    return eMEMMA_NO_ERROR;
  }
  return eMEMORY_SPACE;
}

// **** SET POINTER TO START ***************************************************
static lcf_memory_manager_test_error_e lcf_memory_manager_test_set_pointer()
{
  // ARRANGE
  lcf_memory_manager_init(mem);
  uint8_t should = 0x13;
  
  // Move 3 times
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();
  lcf_memory_manager_get_next_payload_element();
  
  // ACT
  lcf_memory_manager_set_pointer_to_start_of_payload();
  uint8_t output =   lcf_memory_manager_get_next_payload_element();
  
  // ASSERT
  if(output == should)
  {
    return eMEMMA_NO_ERROR;
  }
  return ePOINTER_TO_START;
}

// **** GET CHECKSUM ***********************************************************
static lcf_memory_manager_test_error_e lcf_memory_manager_test_get_checksum()
{
  // ARRANGE
  lcf_memory_manager_init(mem);
  uint8_t should =  0xFF;

  // ACT
  uint8_t output =   lcf_memory_manager_get_checksum();
  
  //ASSERT
  if(should == output)
  {
    return eMEMMA_NO_ERROR;
  }
  return eCHECKSUM;
}

// **** GET VERSION ***********************************************************
static lcf_memory_manager_test_error_e lcf_memory_manager_test_get_version()
{
  // ARRANGE
  lcf_memory_manager_init(mem);
  uint8_t should =  0xA2;

  // ACT
  uint8_t output =   lcf_memory_manager_get_version();
  
  //ASSERT
  if(should == output)
  {
    return eMEMMA_NO_ERROR;
  }
  return eVERSION;
}

// **** TEST ALL ***************************************************************
lcf_memory_manager_test_error_e lcf_memory_manager_test_run_all()
{
  lcf_memory_manager_test_error_e error = eMEMMA_NO_ERROR;
  
  error |= lcf_memory_manager_test_next_element1();
  error |= lcf_memory_manager_test_next_element2();
  error |= lcf_memory_manager_test_check_pointer1();
  error |= lcf_memory_manager_test_check_pointer2();
  error |= lcf_memory_manager_test_set_pointer();
  error |= lcf_memory_manager_test_get_checksum();
  error |= lcf_memory_manager_test_get_version();
  
  return error;
}



