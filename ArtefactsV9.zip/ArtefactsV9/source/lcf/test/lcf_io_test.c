// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_io_test.c
// *
// * @brief        Used for testing the IO functionalities of the LCF, handler
// *               reader and writer
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_io_test.h"

// *****************************************************************************
// **** TEST FUNCTION **********************************************************
// *****************************************************************************

// **** TEST ALL ***************************************************************
void lcf_io_test_run()
{
  // Read all IO's into buffer
  lcf_io_reader_read_io_to_input_register();
  
  // Assing Input buffers to output buffers
  lcf_io_writer_save_value_in_output_register(eQ0, 
      lcf_io_reader_get_value_from_input_register(eI0));
  lcf_io_writer_save_value_in_output_register(eQ1, 
      lcf_io_reader_get_value_from_input_register(eI1));
  lcf_io_writer_save_value_in_output_register(eQ2, 
      lcf_io_reader_get_value_from_input_register(eI2));
  lcf_io_writer_save_value_in_output_register(eQ3, 
      lcf_io_reader_get_value_from_input_register(eI3));
  
  // Write IO's from buffer
  lcf_io_writer_write_output_register_to_io();
}
