// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_stack_machine_test.h
// *
// * @brief        Defines the io test functions, of the lcf handler, writer and
// *               reader.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// * @defgroup     LCF Tests
// * @brief        Functions for testing the LCF code.
// *****************************************************************************

#ifndef __LCF_STACK_MACHINE_TEST__
#define __LCF_STACK_MACHINE_TEST__

#include <lcf_stack_machine.h>

// *****************************************************************************
// * @brief        Enum for returning error messages.
// ***************************************************************************** 
typedef enum
{
  eNO_ERROR,
  ePOP_PUSH_POSITIVE,
  ePOP_PUSH_NEGATIVE,
  eMAX_POSITIVE,
  eMAX_NEGATIVE,
  eMIN_NEGATIVE,
  eMIN_POSITIVE,
  eSUB_NEGATIVE1,
  eSUB_NEGATIVE2,
  eSUB_POSITIVE,
  eCOMPARE_NEQ_NEGATIVE,
  eCOMPARE_NEQ_POSITIVE
} lcf_stack_machine_test_error_e;

// *****************************************************************************
// * @brief        Will run all stack machine unit tests.
// * @return       bool; Error = True. False = all good.
// *****************************************************************************
lcf_stack_machine_test_error_e lcf_stack_machine_test_run_all();

#endif