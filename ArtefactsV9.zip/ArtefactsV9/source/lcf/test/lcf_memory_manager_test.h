// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_stack_machine_test.h
// *
// * @brief        Defines the io test functions, of the lcf handler, writer and
// *               reader.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// * @defgroup     LCF Tests
// * @brief        Functions for testing the LCF code.
// *****************************************************************************

#ifndef __LCF_MEMORY_MANAGER_TEST__
#define __LCF_MEMORY_MANAGER_TEST__

#include <lcf_memory_manager.h>

// *****************************************************************************
// * @brief        Enum for returning error messages.
// ***************************************************************************** 
typedef enum
{
  eMEMMA_NO_ERROR,
  eGET_NEXT_ELEMENT,
  eMEMORY_SPACE,
  ePOINTER_TO_START,
  eCHECKSUM,
  eVERSION
} lcf_memory_manager_test_error_e;

// *****************************************************************************
// * @brief        Will run all stack machine unit tests.
// * @return       bool; Error = True. False = all good.
// *****************************************************************************
lcf_memory_manager_test_error_e lcf_memory_manager_test_run_all();

#endif