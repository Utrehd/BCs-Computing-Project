// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_stack_machine_test.c
// *
// * @brief        Used for testing the stack machine functionalities of LCF.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_stack_machine_test.h"

// *****************************************************************************
// **** TEST FUNCTION **********************************************************
// *****************************************************************************

// **** TEST PUSH & POP POSITIVE ***********************************************
static lcf_stack_machine_test_error_e lcf_stack_machine_test_push_pop_positive()
{
  // ARRANGE
  uint8_t input = true;
  uint8_t should = true;
  uint8_t output;
  
  // ACT
  lcf_stack_machine_push(input);
  output = lcf_stack_machine_pop();
  // ASSERT
  if(output == should)
  {
    return eNO_ERROR;
  }
  return ePOP_PUSH_POSITIVE;
}

// **** TEST PUSH & POP NEGATIVE ***********************************************
static lcf_stack_machine_test_error_e lcf_stack_machine_test_push_pop_negative()
{
  // ARRANGE
  uint8_t input = false;
  uint8_t should = false;
  uint8_t output;
  
  // ACT
  lcf_stack_machine_push(input);
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return ePOP_PUSH_NEGATIVE;
}

// **** TEST MAX POSITIVE ******************************************************
static lcf_stack_machine_test_error_e lcf_stack_machine_test_max_positive()
{
  // ARRANGE
  uint8_t input1 = false;
  uint8_t input2 = true;
  uint8_t should = true;
  uint8_t output;
  
  lcf_stack_machine_push(input1);
  lcf_stack_machine_push(input2);
  
  // ACT
  lcf_stack_machine_max();
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return eMAX_POSITIVE;
}

// **** TEST MAX NEGATIVE ******************************************************
static lcf_stack_machine_test_error_e lcf_stack_machine_test_max_negative()
{
  // ARRANGE
  uint8_t input1 = false;
  uint8_t input2 = false;
  uint8_t should = false;
  uint8_t output;
  
  lcf_stack_machine_push(input1);
  lcf_stack_machine_push(input2);
  
  // ACT
  lcf_stack_machine_max();
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return eMAX_NEGATIVE;
}

// **** TEST MIN NEGATIVE ******************************************************
static lcf_stack_machine_test_error_e lcf_stack_machine_test_min_negative()
{
  // ARRANGE
  uint8_t input1 = false;
  uint8_t input2 = true;
  uint8_t should = false;
  uint8_t output;
  
  lcf_stack_machine_push(input1);
  lcf_stack_machine_push(input2);
  
  // ACT
  lcf_stack_machine_min();
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return eMIN_NEGATIVE;
}

// **** TEST MIN POSITIVE ******************************************************
static lcf_stack_machine_test_error_e lcf_stack_machine_test_min_positive()
{
  // ARRANGE
  uint8_t input1 = true;
  uint8_t input2 = true;
  uint8_t should = true;
  uint8_t output;
  
  lcf_stack_machine_push(input1);
  lcf_stack_machine_push(input2);
  
  // ACT
  lcf_stack_machine_min();
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return eMIN_POSITIVE;
}

// **** TEST SUB NEGATIVE ******************************************************
static lcf_stack_machine_test_error_e lcf_stack_machine_test_sub_negative1()
{
  // ARRANGE
  uint8_t input1 = true;
  uint8_t input2 = true;
  uint8_t should = false;
  uint8_t output;
  
  lcf_stack_machine_push(input1);
  lcf_stack_machine_push(input2);
  
  // ACT
  lcf_stack_machine_sub();
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return eSUB_NEGATIVE1;
}

// **** TEST SUB NEGATIVE2 ******************************************************
static lcf_stack_machine_test_error_e lcf_stack_machine_test_sub_negative2()
{
  // ARRANGE
  uint8_t input1 = true;
  uint8_t input2 = false;
  uint8_t should = false;
  uint8_t output;
  
  lcf_stack_machine_push(input1);
  lcf_stack_machine_push(input2);
  
  // ACT
  lcf_stack_machine_sub();
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return eSUB_NEGATIVE2;
}

// **** TEST SUB POSITIVE ******************************************************
static lcf_stack_machine_test_error_e lcf_stack_machine_test_sub_positive()
{
  // ARRANGE
  uint8_t input1 = false;
  uint8_t input2 = true;
  uint8_t should = true;
  uint8_t output;
  
  lcf_stack_machine_push(input1);
  lcf_stack_machine_push(input2);
  
  // ACT
  lcf_stack_machine_sub();
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return eSUB_POSITIVE;
}

// **** TEST COMPARE NEQ NEGATIVE **********************************************
static lcf_stack_machine_test_error_e 
    lcf_stack_machine_test_compare_neq_negative()
{
  // ARRANGE
  uint8_t input1 = true;
  uint8_t input2 = true;
  uint8_t should = false;
  uint8_t output;
  
  lcf_stack_machine_push(input1);
  lcf_stack_machine_push(input2);
  
  // ACT
  lcf_stack_machine_compare_neq();
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return eCOMPARE_NEQ_NEGATIVE;
}

// **** TEST COMPARE NEQ POSITIVE **********************************************
static lcf_stack_machine_test_error_e 
    lcf_stack_machine_test_compare_neq_positive()
{
  // ARRANGE
  uint8_t input1 = false;
  uint8_t input2 = true;
  uint8_t should = true;
  uint8_t output;
  
  lcf_stack_machine_push(input1);
  lcf_stack_machine_push(input2);
  
  // ACT
  lcf_stack_machine_compare_neq();
  
  // ASSERT
  output = lcf_stack_machine_pop();
  if(output == should)
  {
    return eNO_ERROR;
  }
  return eCOMPARE_NEQ_POSITIVE;
}

// **** TEST ALL ***************************************************************
lcf_stack_machine_test_error_e lcf_stack_machine_test_run_all()
{
  lcf_stack_machine_test_error_e error = false;
  error |= lcf_stack_machine_test_push_pop_positive();
  error |= lcf_stack_machine_test_push_pop_negative();
  error |= lcf_stack_machine_test_max_positive();
  error |= lcf_stack_machine_test_max_negative();
  error |= lcf_stack_machine_test_min_negative();
  error |= lcf_stack_machine_test_min_positive();
  error |= lcf_stack_machine_test_sub_negative1();

  error |= lcf_stack_machine_test_sub_negative2();
  error |= lcf_stack_machine_test_sub_positive();

  error |= lcf_stack_machine_test_compare_neq_negative();
  error |= lcf_stack_machine_test_compare_neq_positive();
  
  return error;
}



