// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_io_reader.c
// *
// * @brief        Defines the IO reader functions for the LCF Interpreter.
// *               Based on the 4D4D.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_io_reader.h"

// *****************************************************************************
// **** INITALIZATION **********************************************************
// *****************************************************************************
bool lcf_io_reader_input_register[4] = {false, false, false, false};

// *****************************************************************************
// **** FUNCTIONS **************************************************************
// *****************************************************************************

// **** GET REGISTER VALUE *****************************************************
// Will get a value from the input register
bool lcf_io_reader_get_value_from_input_register(
        lcf_io_handler_input_e input)
{
  return lcf_io_reader_input_register[input];
}

// **** READ IO'S TO REGISTER **************************************************
// Will write the whole output register to the IO.
void lcf_io_reader_read_io_to_input_register()
{
  // Read IO zero value to register
  lcf_io_reader_input_register[eI0] = lcf_io_handler_read_input(eI0);
  // Read IO one value to register
  lcf_io_reader_input_register[eI1] = lcf_io_handler_read_input(eI1);
  // Read IO tow value to register
  lcf_io_reader_input_register[eI2] = lcf_io_handler_read_input(eI2);
  // Read IO three value to register
  lcf_io_reader_input_register[eI3] = lcf_io_handler_read_input(eI3);
}