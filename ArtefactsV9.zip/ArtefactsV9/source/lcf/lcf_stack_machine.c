// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_stack_machine.c
// *
// * @brief        Implements the stack machine with its functions.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_stack_machine.h"
#define STACK_SIZE 140 //size of stack machine.

// *****************************************************************************
// **** INITIALIZATION *********************************************************
// *****************************************************************************

// Define the stack
uint8_t stack[STACK_SIZE];
// Define the top of the stack. 
// The top is defined as the highest index, which is empty.
uint8_t top_of_stack = STACK_SIZE;

// *****************************************************************************
// **** STACK MACHINE FUNCTIONS ************************************************
// *****************************************************************************

// **** STACK IS EMPTY *********************************************************
static bool stack_is_empty()
{
  if(top_of_stack >= STACK_SIZE)
  {
    return true;
  }
  return false;
}

// **** STACK IS FULL **********************************************************
static bool stack_is_full()
{
  if(top_of_stack == 0x00)
  {
    return true;
  }
  return false;
}

// **** PUSH Value on Stack ****************************************************
void lcf_stack_machine_push(uint8_t value)
{
  if(!stack_is_full())
  {
    // Write value to top position of stack machine.
    stack[top_of_stack] = value;
    // Decrement the position
    top_of_stack--;
  }
  else
  {
    // Set Error
    lcf_error_manager_set_error(eError_LCF_Stack_Machine_Full);
  }
}

// **** PUSH_P address value on Stack ******************************************
void lcf_stack_machine_push_p(lcf_io_handler_input_e input)
{
  // Get the value of the address from the input register
  uint8_t value = lcf_io_reader_get_value_from_input_register(input);
  // push value onto the stack machine.
  lcf_stack_machine_push(value);
}

// **** POP value from stack ***************************************************
uint8_t lcf_stack_machine_pop()
{
  if(!stack_is_empty())
  {
    // Increment the position
    top_of_stack++;
    // Read the value
    uint8_t value = stack[top_of_stack];
    // Reamove the value from the stack.
    stack[top_of_stack] = 0;
    // return value
    return value;
  }
  else
  {
    // Set Error
    lcf_error_manager_set_error(eError_LCF_Stack_Machine_Empty);
    return 0x00;
  }
}

// **** POP_P address from stack ***********************************************
void lcf_stack_machine_pop_p(lcf_io_handler_output_e output)
{
  // get value
  uint8_t value = lcf_stack_machine_pop();
  // return value
  lcf_io_writer_save_value_in_output_register(output, value);
}

// **** MAX Values *************************************************************
// Will determind the biggest value of the topmost two elemenst, remove both, 
// and place the result back on the stack. 
void lcf_stack_machine_max()
{
  // get value one
  uint8_t value_one = lcf_stack_machine_pop();
  // get value two
  uint8_t value_two = lcf_stack_machine_pop();
  // if nr. one is bigger or equal put back nr. one stack else put nr. two
  if(value_one >= value_two)
  {
    lcf_stack_machine_push(value_one);
  }
  else
  {
    lcf_stack_machine_push(value_two);
  }
}

// **** MIN Values *************************************************************
// Will determind the smallest value of the topmost two elemenst, remove both, 
// and place the result back on the stack. 
void lcf_stack_machine_min()
{
  // get value one
  uint8_t value_one = lcf_stack_machine_pop();
  // get value two
  uint8_t value_two = lcf_stack_machine_pop();
  // if nr. one is smaller or equal put back nr. one stack else put nr. two
  if(value_one <= value_two)
  {
    lcf_stack_machine_push(value_one);
  }
  else
  {
    lcf_stack_machine_push(value_two);
  }
}

// **** SUB Values *************************************************************
// Substract second element from the top from the first element,
// removes both values from the stack, and puts the result back.
void lcf_stack_machine_sub()
{
  // get value one
  uint8_t value_one = lcf_stack_machine_pop();
  // get value two
  uint8_t value_two = lcf_stack_machine_pop();
  // Check is substraction is plausible and not less than 0
  if (value_one < value_two)
  {
    // Push 0, so that there will be no overflow
    lcf_stack_machine_push(0);    
  }
  else
  {
    // Substract and put result onto stack
    lcf_stack_machine_push(value_one - value_two);
  }
}

// **** COMPARE_NEQ ************************************************************
// Compares the top most elements of the stack if they are unequal
// if so remove both and push 1 if they are equal if not 0.
void lcf_stack_machine_compare_neq()
{
  // POP value one
  uint8_t value_one = lcf_stack_machine_pop();
  // POP value two
  uint8_t value_two = lcf_stack_machine_pop();
  // Check equal
  if(value_one != value_two)
  {
    lcf_stack_machine_push(true);
  }
  else
  {
    lcf_stack_machine_push(false);
  }
}




