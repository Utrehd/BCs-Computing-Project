/**
********************************************************************************
********************************************************************************
**** @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
****               Cezchia, All rights reserved
****
**** @file         lcf_io_writer.c
****
**** @brief        Defines the IO writer functions for the LCF Interpreter.
****               Based on the 4D4D.
****
**** @author       Samuel A. Marti
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
**** @defgroup     LCF_IO_Writer
**** @brief        Contains functions for writing the output regsiter to the 
****               4D4D IO.
********************************************************************************
*/
#ifndef __LCF_IO_WRITER__
#define __LCF_IO_WRITER__

#include "lcf_io_handler.h"

/**
********************************************************************************
**** @brief        Allows to write a value into the outptu register
**** @param        output       The target output for which the value is
****                            Meant for.
**** @param        value        The value for the target output.
**** @remark       This function will not write the values to the IO.
****               Therefor us the write output register function.
******************************************************************************** 
*/
void lcf_io_writer_save_value_in_output_register(
        lcf_io_handler_output_e output, bool value);
        
/**
********************************************************************************
**** @brief        Will write the values of the output register to the 
****               particular all 4D4D IO's.
********************************************************************************
*/
void lcf_io_writer_write_output_register_to_io();

#endif