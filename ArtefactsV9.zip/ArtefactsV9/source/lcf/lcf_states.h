/**
********************************************************************************
********************************************************************************
**** @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
****               Cezchia, All rights reserved
****
**** @file         lcf_states.h
****
**** @brief        Declears the states of the LCF state machine.
****
**** @author       Samuel A. Marti
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
**** @defgroup     LCF_States
**** @brief        Declears the states of the state machine.
********************************************************************************
*/
#ifndef __LCF_STATES__
#define __LCF_STATES__

#include "lcf_io_handler.h"
#include "lcf_memory_manager.h"
#include "lcf_io_reader.h"
#include "lcf_io_writer.h"
#include "lcf_instruction_executor.h"
***The application configs contain the construct with the LCF Instructions.
#include "application_config.h"

/**
********************************************************************************
**** @brief        Runs the state machine of the interpreter.
********************************************************************************
*/
void lcf_state_initalization();

/**
********************************************************************************
**** @brief        Will read all IO's into to input register. 
********************************************************************************
*/
void lcf_state_reading_io();

/**
********************************************************************************
**** @brief        Will interpret the lcf code. 
********************************************************************************
*/
void lcf_state_interpreting();

/**
********************************************************************************
**** @brief        Will write all values in the output register to the IO's. 
********************************************************************************
*/
void lcf_state_writing_io();

/**
********************************************************************************
**** @brief        The Error state.
**** @remark       Any error should result the machine to stay in this state.
****               until a restart of the device has happend.
********************************************************************************
*/
void lcf_state_error();

#endif