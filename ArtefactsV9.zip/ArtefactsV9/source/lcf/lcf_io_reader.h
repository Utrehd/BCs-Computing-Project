/**
********************************************************************************
********************************************************************************
**** @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
****               Cezchia, All rights reserved
****
**** @file         lcf_io_reader.c
****
**** @brief        Defines the IO Reader functions for the LCF Interpreter.
****               Based on the 4D4D.
****
**** @author       Samuel A. Marti
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
**** @defgroup     LCF_IO_Reader
**** @brief        Contains functions for reading IO's to the input regsiter of 
****               the 4D4D.
********************************************************************************
*/
#ifndef __LCF_IO_READER__
#define __LCF_IO_READER__

#include "lcf_io_handler.h"

/**
********************************************************************************
**** @brief        Allows to get a value from the input register
**** @param        input       The target input to read from.
**** @return       bool        The value of the target input of the register.
**** @remark       This function will not read the values directly from the IO.
****               Therefor us the read input to register function.
******************************************************************************** 
*/
bool lcf_io_reader_get_value_from_input_register(
        lcf_io_handler_input_e input);

/**
********************************************************************************
**** @brief        Read all phsyical inputs of the 4D4D to the input register.
********************************************************************************
*/
void lcf_io_reader_read_io_to_input_register();

#endif