/**
********************************************************************************
********************************************************************************
**** @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
****               Cezchia, All rights reserved
****
**** @file         lcf_memory_manager.h
****
**** @brief        Declreas the functions and variables for the memory 
****               management of the encoded LCF code in the ASIC2.
****
**** @author       Samuel A. Marti
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
**** @defgroup     LCF_Memory_Manager
**** @brief        Manages the memory of the LCF code.
********************************************************************************
*/
#ifndef __LCF_MEMORY_MANAGER__
#define __LCF_MEMORY_MANAGER__

#include "application_config.h"

#define LCF_MEMORY_SIZE 140 ***Size of the memory used for the LCF code.

/**
********************************************************************************
**** @brief        Initializes the memory manager, must be called
****               before the manager is used.
**** @param        target_memory[] pass the memory which should be managed.
******************************************************************************** 
*/
void lcf_memory_manager_init(const uint8_t target_memory[LCF_MEMORY_SIZE]);

/**
********************************************************************************
**** @brief        Will move the payload index and return the next 
****               element of the memory. 
**** @return       The value of the memory
**** @remark       depends on the memory_index.
********************************************************************************
*/
uint8_t lcf_memory_manager_get_next_payload_element();

/**
********************************************************************************
**** @brief        Will check if the memory index is still within the payload.
**** @return       bool; True if the end was not reached, False if it has.
**** @remark       depends on the memory_index.
********************************************************************************
*/
bool lcf_memory_manager_check_index_within_payload();

/**
********************************************************************************
**** @brief        Will set the memory index to the start of the payload.  
**** @remark       Will set the memory index back to the start of the
****               LCF code(payload) which starts at the end of the header.
********************************************************************************
*/
void lcf_memory_manager_reset_payload_index();

/**
********************************************************************************
**** @brief        Will get the checksum from the memory and return it.
**** @return       uint8_t; The checksum of the LCF memory.
********************************************************************************
*/
uint8_t lcf_memory_manager_get_checksum();

/**
********************************************************************************
**** @brief        Will get the version from the memory and return it.
**** @return       uint8_t; The version of the lcf memory encoding used.
********************************************************************************
*/
uint8_t lcf_memory_manager_get_version();

#endif