// *****************************************************************************
// *****************************************************************************
// * @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
// *               Cezchia, All rights reserved
// *
// * @file         lcf_instruction_executor.c
// *
// * @brief        Decodes the instructions of the device to be used by the
// *               parser.
// *
// * @author       Samuel A. Marti
// *****************************************************************************
// *****************************************************************************

#include "lcf_instruction_executor.h"

// *****************************************************************************
// **** EXECUTOR FUNCTIONS *****************************************************
// *****************************************************************************

// **** EXECUTOR PUSH **********************************************************
static void lcf_instruction_executor_push()
{
  // Get value from memory
  uint8_t value = lcf_memory_manager_get_next_payload_element();
  // Run command
  lcf_stack_machine_push(value);
}

// **** EXECUTOR PUSH_P ********************************************************
static void lcf_instruction_executor_push_p()
{   
  // Get address from memory
  uint8_t address = lcf_memory_manager_get_next_payload_element();
  // Cast value as input enum.
  lcf_io_handler_input_e e_address = (lcf_io_handler_input_e)address;
  // Run command with appropiate address for the register
  lcf_stack_machine_push_p(e_address);
}

// **** EXEUCTOR POP_P *********************************************************
static void lcf_instruction_executor_pop_p()
{ 
  // Get address from memory
  uint8_t address = lcf_memory_manager_get_next_payload_element();
  // Get value from memory and cast as input enum.
  lcf_io_handler_output_e e_address = (lcf_io_handler_output_e)address;
  // Run command with appropiate address for the register
  lcf_stack_machine_pop_p(e_address);
}

// **** EXEUCTOR POP ***********************************************************
static void lcf_instruction_executor_pop()
{
  // NOTE: THIS FUNCTION IS CURRENTLY NOT USED. 
  // Its,a protoype for future versions.
}

// **** EXEUCTOR MAX ***********************************************************
static void lcf_instruction_executor_max()
{ 
  // Run stack machine operation
  lcf_stack_machine_max();
}

// **** EXEUCTOR MIN ***********************************************************
static void lcf_instruction_executor_min()
{
  // Run stack machine operation
  lcf_stack_machine_min();
}

// **** EXEUCTOR SUB ***********************************************************
static void lcf_instruction_executor_sub()
{
  // Run stack machine operation
  lcf_stack_machine_sub();
}

// **** EXEUCTOR COMPARE NEQ ***************************************************
static void lcf_instruction_compare_neq()
{ 
  // Run stack machine operation
  lcf_stack_machine_compare_neq();
}

// *****************************************************************************
// **** INITALIZATION FUNCTION TABLE *******************************************
// *****************************************************************************
// Defines the function table which includes all functions
void (*lcf_instruction_execution_table[LCF_INSTRUCTION_AMOUNT])(void)=
{
  &lcf_instruction_executor_push,
  &lcf_instruction_executor_push_p,
  &lcf_instruction_executor_pop_p,
  &lcf_instruction_executor_pop,
  &lcf_instruction_executor_max,
  &lcf_instruction_executor_min, 
  &lcf_instruction_executor_sub,
  &lcf_instruction_compare_neq
};

// *****************************************************************************
// **** PUBLIC FUNCTION ********************************************************
// *****************************************************************************
// For running the instruction based on their index defined in the instruction
// table.
void lcf_instruction_execution_run_instruction(uint8_t instruction_index)
{
  // Run function associated with instruction.
  (*lcf_instruction_execution_table[instruction_index])();
}

