/**
********************************************************************************
********************************************************************************
**** @copyright    Copyright (c) 2019 Eaton European Innovation Center, 
****               Cezchia, All rights reserved
****
**** @file         lcf_instruction_executor.h
****
**** @brief        Defines the instruction parser functions
****
**** @author       Samuel A. Marti
********************************************************************************
********************************************************************************
*/

/**
********************************************************************************
**** @defgroup     LCF_Instruction_Executor
**** @brief        Used for running the instructions which were given by the 
****               memory.
********************************************************************************
*/
#ifndef __LCF_INSTRUCTION_EXECUTOR__
#define __LCF_INSTRUCTION_EXECUTOR__

#define LCF_INSTRUCTION_AMOUNT 8

#include "lcf_stack_machine.h"
#include "lcf_memory_manager.h"

/**
********************************************************************************
**** @brief        Will execute the instruction by given index.
**** @param        instruction_index; the index of the instruction within the
****               instruction table
**** @remark       The instruction table is defined according to documentation.
****   https://confluence-prod.tcc.etn.com/pages/viewpage.action?pageId=62685861
****
****               The instruction execution uses the memory manager and 
****               the stack machine.
********************************************************************************
*/
void lcf_instruction_execution_run_instruction(uint8_t instruction_index);

#endif